"""Overlay reconstructed KM (from committed ipd.csv) on the source figure. Usage: python overlay.py fig outdir"""
import sys, os, json
import pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
fig_path, out = sys.argv[1], sys.argv[2]
cal = json.load(open(os.path.join(out, 'extracted_curves.json')))['calibration']
im = Image.open(fig_path); df = pd.read_csv(os.path.join(out, 'ipd.csv'))
px = lambda t: cal['x0_px'] + t / 36 * (cal['x36_px'] - cal['x0_px'])
py = lambda s: cal['y0_px'] - s * (cal['y0_px'] - cal['y1_px'])
f, ax = plt.subplots(figsize=(12, 9)); ax.imshow(im)
for g, c in (('A', 'k'), ('B', 'm')):
    d = df[df.group == g].sort_values('observed_time'); S = 1.0; xs = [0]; ys = [1.0]
    for t in sorted(d[d.event == 1].observed_time.unique()):
        n = (d.observed_time >= t).sum(); k = ((d.observed_time == t) & (d.event == 1)).sum()
        xs += [t, t]; ys += [S, S * (1 - k / n)]; S *= 1 - k / n
    xs.append(d.observed_time.max()); ys.append(S)
    ax.plot([px(x) for x in xs], [py(y) for y in ys], c, lw=0.7, ls='--', label='reconstructed ' + g)
    cz = d[d.event == 0].observed_time
    ax.plot([px(x) for x in cz], [py(S) * 0 + 480 + (6 if g == 'B' else 0)] * len(cz), c + '|', ms=5)
ax.legend(); ax.set_xlim(120, 870); ax.set_ylim(500, 80); f.savefig(os.path.join(out, 'overlay.png'), dpi=110)
