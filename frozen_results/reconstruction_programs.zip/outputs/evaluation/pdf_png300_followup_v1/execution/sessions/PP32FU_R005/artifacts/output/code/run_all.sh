#!/bin/sh
# Usage: sh run_all.sh [path/to/figure.png] [outdir]   (defaults: ../../../input/figure.png, ..)
set -e
D=$(cd "$(dirname "$0")" && pwd)
FIG=${1:-$D/../../../input/figure.png}; OUT=${2:-$D/..}
python3 "$D/extract.py" "$FIG" "$OUT"
python3 "$D/recon.py" "$OUT/extracted_curves.json" "$OUT"
python3 "$D/recon.py" "$OUT/extracted_curves.json" "$OUT" --alt
python3 "$D/checks.py" "$OUT"
python3 "$D/overlay.py" "$FIG" "$OUT"
