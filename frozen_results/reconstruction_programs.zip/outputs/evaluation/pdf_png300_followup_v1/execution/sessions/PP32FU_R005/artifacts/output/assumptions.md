# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (raster, 900×675) and `../input/manifest.json` (n = 100 per arm, months, seed 790512406). No arm-specific event totals are supplied. Event totals are therefore derived quantities (A: 75 events / 25 censored; B: 59 / 41) and are not checked against an external total. The risk table was read visually from the figure:
A 100/65/42/25/18/9/0 and B 100/66/53/42/36/12/0 at 0, 6, …, 36 months. All digits are clearly legible.

**Code:** `output/code/run_all.sh [figure] [outdir]` runs `extract.py`, then `recon.py` (primary), `recon.py --alt` (sensitivity), `checks.py` and `overlay.py`. The code is deterministic. The seed is set and recorded, but no random draws are made. No KM-to-IPD package was used.

## Measurement (`extract.py` → `extracted_curves.json`)
- **Calibration.** Detected axis tick marks give x = 0 at pixel column 134.5 and x = 36 at 854.5 (20 px/month), and S = 1.0 at row 89.5 and S = 0.0 at row 464.5 (375 px/unit). All 7 x ticks and 6 y ticks are equally spaced, so this is a linear calibration. No rescaling or running-minimum correction was applied.
- **Series detection.** Each series is identified by its exact color. Lines are 2 px thick with no antialiasing. Horizontal levels come from runs of at least 3 px. A drop's time is the center of its 2-px vertical, and its level is the band center.
- **Origin.** B starts exactly at S = 1.0. A's first ~0.25 months (columns 135–139) are partly hidden under B's line. The local neighborhood shows a vertical of about 3 events down to S = 0.971 by t ≈ 0.25 (100 → 97). These 3 events are recorded as tied at t = 0.2, because the intermediate 1-px levels cannot be separated. This is a time error of ≤0.1 month, and no global correction was applied.
- **Merged steps.** Closely spaced steps (<3 px apart) are merged into one drop. These are tied events at the merged time, with time error ≤0.1 month.
- **Hidden columns.** Columns where one arm is hidden under the other were filled from the union mask, constrained to lie between the neighboring levels of that arm.
- **Censor ticks.** A censor tick is any colored pixel extending more than 1 px beyond the line or drop span. Adjacent tick columns are grouped into blocks. Ticks render 1 px wide, but some single ticks render 2 px wide. Counting columns therefore overcounted censorings relative to the risk table (B, months 24–30: 24 columns versus 20 implied censorings). Each block is therefore treated as **at least one** censoring. Its multiplicity is not identified: tick visibility is not tick multiplicity.

## Reconstruction (`recon.py`)
- **Algorithm.** The data are processed one risk-table interval [T_k, T_{k+1}) at a time, starting from the reconstructed number at risk.
- **Events per drop.** For each drop, d = round(n_risk · (1 − S_meas_after / S_KM_before)). Using the reconstructed KM value before the drop as the denominator avoids drift. Each visible drop gets d ≥ 1. Multi-event drops arise where the measured ratio implies them, for example 3 events at t = 0.2 in A. d = 1 is not assumed.
- **Censorings per interval.** The number of censorings C_k is chosen by search so that the reconstructed number at risk at T_{k+1} equals the displayed count, which is achieved exactly in every interval. Ties go to the smallest |S error| at the interval end, then to the fewest censorings beyond the tick blocks. Censoring at a time equal to an event time is counted as at risk at that event.
- **Censoring placement (assumption).** Censorings are placed at the tick-block times. Censorings beyond the block count are assumed to be overlapping ticks. They go first to blocks wider than 1 px, then evenly over the interval's blocks, or are spread uniformly if the interval has no ticks. Extras required: A 2, 1, 0, 0, 2, 1 and B 2, 0, 1, 0, 2, 2 across the six intervals. No interval needed fewer censorings than visible blocks.
- **Final interval.** The displayed 0 at 36 months is met because every record ends before 36. A's last record is at 33.425 and B's at 35.625, which are the last plotted tick/curve ends. No follow-up beyond the plotted curve was invented.

## Checks (`checks.py` → `checks.json`)
`checks.py` reloads the committed CSV and recomputes the right-continuous KM. It compares that curve with the measured staircase at 1–35 months plus the last plotted column (tail).
- **Probe placement.** Probes within 0.1 month of a measured step are moved off the step. A first version of the checker moved probes onto adjacent steps and produced false failures. That was a probe-placement bug; the tolerance was not changed.
- **Tolerance.** |ΔS| ≤ 0.01 (about 3.75 px). This is below half of the smallest single-event jump in either tail.
- **Results.** All curve probes pass, with maximum |residual| 0.0031 (B, 30–32 months). Probes beyond A's curve end (34 and 35 months) are marked unavailable. All 14 risk-table counts match exactly (observed_time ≥ t). Arm sizes are 100/100, and event indicators are integers.
- **Supplied event totals:** unavailable.

## Sensitivity (`sensitivity.csv`, one alternative)
The alternative spreads censorings beyond the tick blocks uniformly over their interval instead of stacking them on ticks. At the common supported horizon of 33.43 months (end of A's plotted curve), the primary and alternative results are:

| Arm | S, primary | S, alternative | RMST, primary (months) | RMST, alternative (months) |
|---|---|---|---|---|
| A | 0.169 | 0.169 | 13.92 | 13.91 |
| B | 0.300 | 0.310 | 18.03 | 18.06 |

B's difference comes from the risk set at its 32.9-month drop. This single alternative is not an uncertainty bound.

## Unresolved limitations
- **Tick multiplicity and extra censorings.** The number of overlapping ticks, and the location of the extra censorings, are not identified by the figure. They are an assumption constrained only by the risk table and the tick positions.
- **Within-interval timing.** Censoring times within an interval are only as good as the tick positions (±0.05 month). Event times within merged or hidden steps are only as good as the 0.1-month pixel resolution.
- **Tail.** The tail after the last risk-table time (30 months) is constrained only by the ticks, the last drop and the displayed 0 at 36 months.
- **Possible misread drops.** A drop could theoretically hide one more or one fewer event if a censoring falls between closely spaced events. The interval totals are pinned by the risk table.
