"""Pixel extraction of KM step curves and censor ticks from figure.png.
Usage: python extract.py [path/to/figure.png] [outdir]
Calibration from labelled axis ticks (detected below):
  x: tick columns 134/135 -> 0 mo, 854/855 -> 36 mo  (20 px per month)
  y: tick rows 89/90 -> 1.0, 464/465 -> 0.0         (375 px per unit)
"""
import sys, json, os
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input', 'figure.png')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), '..')
COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}

a = np.array(Image.open(FIG).convert('RGB')).astype(float)
dark = a.sum(2) < 150

# --- axis calibration from tick marks (verified, not assumed) ---
xt = np.where(dark[468, :])[0]; xt = xt[xt > 125]
xticks = [(xt[i] + xt[i + 1]) / 2 for i in range(0, len(xt), 2)]          # 7 ticks 0..36
yt = np.where(dark[:, 131])[0]; yt = yt[yt < 470]
yticks = [(yt[i] + yt[i + 1]) / 2 for i in range(0, len(yt), 2)]          # 1.0..0.0
X0, X36 = xticks[0], xticks[-1]; Y1, Y0 = yticks[0], yticks[-1]
assert len(xticks) == 7 and len(yticks) == 6, (xticks, yticks)
tx = lambda px: (px - X0) / (X36 - X0) * 36.0
sy = lambda py: (Y0 - py) / (Y0 - Y1)            # py = band centre row (pixel index + 0.5 offset handled below)

def mask(col):
    return np.sqrt(((a - np.array(col)) ** 2).sum(2)) < 60

def hruns(m, minlen=3):
    H = np.zeros_like(m)
    for r in range(m.shape[0]):
        row = m[r]; x = 0; W = len(row)
        while x < W:
            if row[x]:
                e = x
                while e + 1 < W and row[e + 1]: e += 1
                if e - x + 1 >= minlen: H[r, x:e + 1] = True
                x = e + 1
            else: x += 1
    return H

def bands(colmask):
    r = np.where(colmask)[0]
    if len(r) == 0: return []
    groups = np.split(r, np.where(np.diff(r) > 1)[0] + 1)
    return [(g.min(), g.max()) for g in groups]

mA, mB = mask(COLORS['A']), mask(COLORS['B'])
union = mA | mB
res = {'calibration': dict(x0_px=X0, x36_px=X36, y1_px=Y1, y0_px=Y0, xticks=xticks, yticks=yticks)}
for g, m in (('A', mA), ('B', mB)):
    H = hruns(m); Hu = hruns(union)
    xs = np.where(m[int(Y1) - 3:int(Y0) - 2, :].any(0))[0]
    xmin, xmax = int(X0) + 1, xs.max()
    lev = {}       # column -> list of band (top,bottom)
    hidden = []
    for x in range(xmin, xmax + 1):
        b = bands(H[int(Y1) - 2:int(Y0), x]); b = [(t + int(Y1) - 2, u + int(Y1) - 2) for t, u in b]
        b = [bb for bb in b if bb[1] - bb[0] <= 3]
        if not b:
            hidden.append(x)
        lev[x] = b
    # fill hidden columns from union mask, constrained between neighbouring known levels
    for x in hidden:
        L = next((lev[k] for k in range(x - 1, xmin - 1, -1) if lev[k]), [(int(Y1), int(Y1) + 1)])
        R = next((lev[k] for k in range(x + 1, xmax + 1) if lev[k]), L)
        lo, hi = L[-1][0] - 1, R[0][1] + 1
        b = bands(Hu[:, x]); b = [bb for bb in b if lo <= bb[0] and bb[1] <= hi and bb[1] - bb[0] <= 3]
        lev[x] = b if b else [L[-1]]
    # sequence of levels (band centres)
    # band centre (t+u)/2 in pixel-index coordinates, same convention as tick centres (e.g. rows 89/90 -> 89.5 = S 1.0)
    segs = []      # (level_center, first_col, last_col)
    for x in range(xmin, xmax + 1):
        for bb in lev[x]:
            c = (bb[0] + bb[1]) / 2.0
            hit = [s for s in segs if abs(s[0] - c) <= 1.0 and s[2] >= x - 3]
            if hit: hit[-1][2] = x
            else: segs.append([c, x, x])
    segs.sort(key=lambda s: s[1])
    # merge / order as a monotone staircase
    stairs = []
    for s in segs:
        if stairs and s[0] < stairs[-1][0] - 1.0:      # higher than current: spurious (e.g. tick/legend); skip
            continue
        if stairs and abs(s[0] - stairs[-1][0]) <= 1.0:
            stairs[-1][2] = max(stairs[-1][2], s[2]); continue
        stairs.append(list(s))
    drops = []
    for p, q in zip(stairs[:-1], stairs[1:]):
        xc = (q[1] + p[2]) / 2.0                    # centre of 2-px vertical, continuous coords
        drops.append(dict(x_px=xc, t=tx(xc), s_before=sy(p[0]), s_after=sy(q[0]),
                          px_before=p[0], px_after=q[0]))
    # censor ticks: coloured pixels > 1 px beyond the band(s) in that column
    tickcols = []
    for x in range(xmin, xmax + 1):
        r = np.where(m[int(Y1) - 6:int(Y0), x])[0] + int(Y1) - 6
        if len(r) == 0: continue
        bl = lev[x]
        top, bot = min(b[0] for b in bl), max(b[1] for b in bl)
        # vertical drop spans rows between bands; tick shows as pixels above top or below bottom
        if r.min() <= top - 2 or r.max() >= bot + 2:
            # exclude drop verticals: those extend only between adjacent stair levels
            prev = next((lev[k] for k in range(x - 3, xmin - 1, -1) if lev[k]), bl)
            nxt = next((lev[k] for k in range(x + 3, xmax + 1) if lev[k]), bl)
            vtop, vbot = min(prev[0][0], top), max(nxt[-1][1], bot)
            if r.min() <= vtop - 2 or r.max() >= vbot + 2:
                tickcols.append((x, int(r.min()), int(r.max())))
    ticks = []
    for x, t0, t1 in tickcols:
        if ticks and x - ticks[-1]['cols'][-1] <= 1:
            ticks[-1]['cols'].append(x)
        else:
            ticks.append(dict(cols=[x], rows=[t0, t1]))
    for tk in ticks:
        xc = np.mean(tk['cols'])
        tk['x_px'] = xc; tk['t'] = tx(xc); tk['s'] = sy((tk['rows'][0] + tk['rows'][1]) / 2)
        tk['col_times'] = [tx(c) for c in tk['cols']]
        tk['width_cols'] = len(tk['cols'])
    res[g] = dict(x_end_px=int(xmax), t_end=tx(xmax), hidden_cols=hidden,
                  stairs=[dict(level_px=s[0], s=sy(s[0]), t_from=tx(s[1]), t_to=tx(s[2])) for s in stairs],
                  drops=drops, ticks=ticks)
    print(g, 'stairs', len(stairs), 'drops', len(drops), 'ticks', len(ticks), 'hidden cols', len(hidden), 'end t', round(tx(xmax), 3))
json.dump(res, open(os.path.join(OUT, 'extracted_curves.json'), 'w'), indent=1, default=float)
