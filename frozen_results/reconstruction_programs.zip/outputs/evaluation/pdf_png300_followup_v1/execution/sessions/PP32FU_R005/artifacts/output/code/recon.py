"""Interval-wise KM-to-records reconstruction (own implementation, Guyot-type logic).
Usage: python recon.py [extracted_curves.json] [outdir] [--alt]
  primary : censorings beyond visible tick columns are placed at the visible ticks of that
            risk-table interval (overlapping-tick assumption); uniform spacing if none visible.
  --alt   : sensitivity; extra censorings spread uniformly over the interval instead.
Deterministic; seed 790512406 is set and recorded although no random draws are used.
"""
import sys, json, os, hashlib
import numpy as np

SEED = 790512406
np.random.seed(SEED)
args = [a for a in sys.argv[1:] if not a.startswith('--')]
ALT = '--alt' in sys.argv
HERE = os.path.dirname(os.path.abspath(__file__))
EXT = args[0] if args else os.path.join(HERE, '..', 'extracted_curves.json')
OUT = args[1] if len(args) > 1 else os.path.join(HERE, '..')
ext = json.load(open(EXT))

# risk table read visually from the figure (times 0,6,...,36 months)
RT_TIMES = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 65, 42, 25, 18, 9, 0], 'B': [100, 66, 53, 42, 36, 12, 0]}
N = {'A': 100, 'B': 100}   # manifest
WIDTH = {}

def build_interval(n0, target, drops, cens_marks, lo, hi, C, S_prev, alt):
    """Place C censorings and compute events for drops in [lo,hi). Returns records, n_end, S_end."""
    m = len(cens_marks)
    if C <= 0: ctimes = []
    elif m == 0 or alt and C > m:
        base = list(cens_marks) if alt else []
        k = C - len(base)
        ctimes = base + [lo + (hi - lo) * (i + 0.5) / k for i in range(k)]
    elif C >= m:
        ctimes = list(cens_marks)
        extra = C - m
        # extras = overlapping ticks: first to blocks wider than 1 px (evidence of >1 tick), then all blocks
        wide = [t for t in cens_marks if WIDTH[t] >= 2]
        pool = (wide * extra)[:extra] if wide and extra <= len(wide) else None
        if pool is None:
            pool = list(wide)
            rest = extra - len(pool)
            pool += [cens_marks[int((i + 0.5) * m / rest)] for i in range(rest)]
        ctimes += pool
    else:                                    # fewer censorings than tick blocks: evenly spaced subset (flagged)
        ctimes = [cens_marks[int((i + 0.5) * m / C)] for i in range(C)]
    ctimes = sorted(ctimes)
    recs = []; n = n0; S = S_prev; ci = 0
    for d in drops:
        t = d['t']
        while ci < len(ctimes) and ctimes[ci] < t:
            recs.append((ctimes[ci], 0)); n -= 1; ci += 1
        if n <= 0: break
        k = int(round(n * (1 - d['s_after'] / S)))
        k = min(max(k, 1), n)                # a visible drop implies >=1 event
        recs += [(t, 1)] * k
        S *= (1 - k / n); n -= k
    while ci < len(ctimes):
        recs.append((ctimes[ci], 0)); n -= 1; ci += 1
    return recs, n, S

def reconstruct(g, alt=False):
    e = ext[g]
    drops = e['drops']
    marks = sorted(tk['t'] for tk in e['ticks'])     # one censoring per contiguous tick block (lower bound)
    WIDTH.update({tk['t']: tk['width_cols'] for tk in e['ticks']})
    t_end = e['t_end']
    recs = []; n = N[g]; S = 1.0; log = []
    for k in range(len(RT_TIMES) - 1):
        lo, hi = RT_TIMES[k], RT_TIMES[k + 1]
        target = RISK[g][k + 1]
        hi_eff = min(hi, t_end + 1e-9) if target == 0 else hi
        dk = [d for d in drops if lo <= d['t'] < hi]
        mk = [t for t in marks if lo <= t < hi]
        best = None
        for C in range(0, n + 1):
            r, n_end, S_end = build_interval(n, target, dk, mk, lo, hi_eff, C, S, alt)
            if n_end < 0: continue
            # S error at end of interval vs measured stair
            meas = dk[-1]['s_after'] if dk else S
            score = (abs(n_end - target), abs(S_end - meas), abs(C - len(mk)))
            if best is None or score < best[0]:
                best = (score, C, r, n_end, S_end)
        score, C, r, n_end, S_end = best
        log.append(dict(interval=[lo, hi], n_start=n, risk_target=target, n_end=n_end,
                        events=sum(x[1] for x in r), censored=C, tick_blocks=len(mk),
                        extra_censor_vs_ticks=C - len(mk), S_end=S_end))
        recs += r; n = n_end; S = S_end
        if n == 0: break
    if n > 0:   # should not happen (risk 0 at 36); censor remaining at last observed time
        recs += [(t_end, 0)] * n
        log.append(dict(note='remaining censored at curve end', n=n))
    return recs, log

if __name__ == '__main__':
    rows = []; logs = {}
    for g in 'AB':
        r, log = reconstruct(g, ALT)
        assert len(r) == N[g], (g, len(r))
        rows += [(g, round(t, 4), ev) for t, ev in r]; logs[g] = log
    name = 'sensitivity.csv' if ALT else 'ipd.csv'
    path = os.path.join(OUT, name); tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        f.write('group,observed_time,event\n')
        for g, t, ev in rows: f.write(f'{g},{t},{ev}\n')
    os.replace(tmp, path)                     # atomic commit
    json.dump(dict(seed=SEED, alt=ALT, intervals=logs), open(os.path.join(OUT, ('recon_log_alt.json' if ALT else 'recon_log.json')), 'w'), indent=1)
    print(name, hashlib.sha256(open(path, 'rb').read()).hexdigest())
    for g in 'AB':
        for l in logs[g]: print(g, l)
