"""Reload committed CSV(s), recompute right-continuous KM, compare to measured curve and risk table.
Usage: python checks.py [outdir]   (expects ipd.csv, extracted_curves.json; sensitivity.csv optional)"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
sys.path.insert(0, HERE)
from recon import RT_TIMES, RISK, N
ext = json.load(open(os.path.join(OUT, 'extracted_curves.json')))
TOL = 0.01   # ~3.75 px; < half of the smallest single-event jump on the tail of either arm (A: ~0.021 at n=9)

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S))
    return out
def S_at(steps, x):          # right-continuous step
    s = 1.0
    for u, v in steps:
        if u <= x: s = v
        else: break
    return s
def meas_at(g, x):
    for st in ext[g]['stairs']:
        if st['t_from'] <= x <= st['t_to']: return st['s']
    return None
def rmst(steps, h):
    pts = [0.0] + [u for u, _ in steps if u < h] + [h]; a = 0.0
    for i in range(len(pts) - 1): a += S_at(steps, pts[i]) * (pts[i + 1] - pts[i])
    return a

path = os.path.join(OUT, 'ipd.csv')
df = pd.read_csv(path)
res = dict(csv_sha256=hashlib.sha256(open(path, 'rb').read()).hexdigest(), tolerance_S=TOL,
           tolerance_note='0.01 survival (~3.75 px); line is 2 px thick, band centre read to 0.5 px; smaller than half of one tail event jump',
           arms={})
allpass = True
for g in 'AB':
    d = df[df.group == g]; steps = km(d)
    drops = [x['t'] for x in ext[g]['drops']]
    end = ext[g]['t_end']
    times = [1, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 31, 32, 33, 34, 35]
    curve = []
    for x in times:
        if x > end: curve.append(dict(t=x, status='unavailable', note='beyond plotted curve end %.3f' % end)); continue
        if min(abs(x - u) for u in drops) < 0.1:   # move probe off a step (pixel time uncertainty ~0.05 mo)
            cand = [x + k * 0.05 for k in (1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6)]
            x = max(cand, key=lambda c: (min(abs(c - u) for u in drops) >= 0.1, -abs(c - x)) if min(abs(c - u) for u in drops) >= 0.1 else (False, min(abs(c - u) for u in drops)))
        m = meas_at(g, x); r = S_at(steps, x)
        if m is None: curve.append(dict(t=x, status='unavailable')); continue
        ok = abs(r - m) <= TOL; allpass &= ok
        curve.append(dict(t=round(x, 3), measured=round(m, 4), reconstructed=round(r, 4), residual=round(r - m, 4), status='pass' if ok else 'fail'))
    tail_t = round(end - 0.05, 3); m = meas_at(g, tail_t); r = S_at(steps, tail_t)
    curve.append(dict(t=tail_t, label='tail (last plotted column)', measured=round(m, 4), reconstructed=round(r, 4), residual=round(r - m, 4), status='pass' if abs(r - m) <= TOL else 'fail'))
    risk = []
    for T, n in zip(RT_TIMES, RISK[g]):
        c = int((d.observed_time >= T).sum()); ok = c == n; allpass &= ok
        risk.append(dict(t=T, displayed=n, reconstructed=c, residual=c - n, status='pass' if ok else 'fail'))
    res['arms'][g] = dict(n_records=len(d), n_expected=N[g], size_ok=len(d) == N[g],
                          event_integer_ok=bool(d.event.isin([0, 1]).all()),
                          events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                          supplied_event_total='unavailable (not in manifest)',
                          max_time=float(d.observed_time.max()), plotted_curve_end=end,
                          km_vs_measured=curve, risk_table=risk)
res['all_required_checks_pass'] = bool(allpass)
# sensitivity comparison at common supported horizon
sp = os.path.join(OUT, 'sensitivity.csv')
if os.path.exists(sp):
    H = round(min(ext['A']['t_end'], ext['B']['t_end']), 2)
    sd = pd.read_csv(sp); comp = {}
    for g in 'AB':
        p = km(df[df.group == g]); a = km(sd[sd.group == g])
        comp[g] = dict(S_primary=round(S_at(p, H), 4), S_alt=round(S_at(a, H), 4),
                       RMST_primary=round(rmst(p, H), 3), RMST_alt=round(rmst(a, H), 3))
    res['sensitivity'] = dict(file='sensitivity.csv', sha256=hashlib.sha256(open(sp, 'rb').read()).hexdigest(),
                              assumption='censorings beyond visible tick blocks spread uniformly over their risk-table interval instead of stacked on ticks',
                              common_horizon_months=H, comparison=comp)
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    a = res['arms'][g]; print(g, a['n_records'], a['events'], a['censored'], a['max_time'])
    for c in a['km_vs_measured']: print('  ', c)
    print('  risk', [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table']])
print('ALL PASS', allpass); print(res.get('sensitivity'))
