# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json` (n = 1000 per arm, time in months, seed 754076957). Nothing else was used. The manifest gives no arm-specific event totals, so `checks.json` marks that constraint "unavailable".

**Code:** `code/reconstruct.py` (run from `work/`: `python3 output/code/reconstruct.py [--input ../input --out output]`). It is deterministic. The seed is set and recorded, but no random draws affect the output.

## Measurement
- **Calibration.** Time and survival were calibrated by linear fits to the tick-mark pixel centres: x ticks for 0–36 months and y ticks for 0.0–1.0. Residuals at the ticks are 0 (0.025 months/px; 0.001333 survival/px). No global rescaling was applied to either arm.
- **Curve extraction.** Each arm was extracted by its exact line colour (A = blue, B = orange). The plotted line is about 6 px thick. In each pixel column, the right-continuous level is the centre of the lowest line band. Per-column measurements are saved in `measured_curve_A.csv` and `measured_curve_B.csv`.
- **Origin.** Both arms start at 1.0. Orange is drawn over blue near t = 0. In the first visible column (t = 0.0375), A already measures 0.993 and B 0.999. I inspected these columns: blue is visible below the orange band, so A's early drop looks genuine and was kept rather than flattened.
- **Monotonicity.** A running minimum removes pixel noise. I checked the early columns first and found no isolated misreads.
- **Censor marks.** None are visible at 300 dpi. Censoring times therefore come from the allocation model below, not from tick marks.

## Reconstruction algorithm
I used my own Guyot-type interval algorithm. The risk-table times are 0, 6, …, 36 months, and the counts were read visually:
- A: 1000, 667, 463, 312, 198, 78, 0
- B: 1000, 758, 564, 419, 323, 129, 0

Within each interval, events are placed at the pixel columns where the curve drops. The event count at a column is d = round(n_risk·(1 − S_meas/S_recon,prev)). Using the reconstructed previous survival lets rounding errors correct themselves. A visible drop can therefore hold several tied events (one pixel ≈ 1.3 events at n = 1000). I did not assume d = 1.

The number of censorings in each interval was searched so that the reconstructed number at risk at the next table time equals the displayed count.

- **Censoring assumption (primary).** Censoring times are spread evenly (uniform quantiles) within each risk interval. This is an assumption: only the interval totals are constrained by the risk table.
- **Last interval (30–36).** The displayed 0 at 36 means everyone must have an observed time below 36. Participants still at risk after the last plotted drop are censored at the end of the plotted curve (A: 35.86, B: 35.96 months). The flat tail does not identify the follow-up or censoring distribution. This endpoint is chosen only because the plotted line ends there.

## Results and checks (see `checks.json`, computed from the reloaded final CSV)
- **Records.** 1000 per arm with integer 0/1 event indicators. Events: A 796, B 668. These totals are not externally verifiable.
- **Risk table.** Counting observed_time ≥ t, with events placed before censoring at ties, matches every displayed count exactly in both arms (residual 0).
- **Survival.** The right-continuous KM of the records differs from the measured curve by at most 0.0005 at 0.5–32 months. In the tail (34–35.5 months), residuals reach −0.002 (A) and −0.0035 (B). This is because one event there is worth a 0.01–0.02 drop at n_risk ≈ 10–20, so it is a rounding effect. The tolerance of 0.01 (about 7 px) is explained in `checks.json`.

## Sensitivity (one alternative; `sensitivity.csv`)
The alternative uses a late-loaded censoring density within each interval (density ∝ t − t_start), compared with uniform in the primary. Over the common horizon of 35.5 months:

| Arm | S(35.5) primary → alternative | RMST primary → alternative | Events primary → alternative |
|---|---|---|---|
| A | 0.095 → 0.096 | 14.62 → 14.61 | 796 → 809 |
| B | 0.242 → 0.246 | 18.44 → 18.45 | 668 → 680 |

The event-count difference shows that the event/censoring split is only weakly identified. This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- The exact censoring times and the event/censoring split within intervals are not identified.
- Events within a pixel column (0.025 months) are tied at the column's right edge.
- The risk counts were read by eye from the image, with no OCR. They are clear, but they are a transcription.
