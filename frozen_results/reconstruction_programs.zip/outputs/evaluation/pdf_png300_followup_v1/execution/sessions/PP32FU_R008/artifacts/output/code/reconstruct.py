#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python3 reconstruct.py [--input ../input] [--out output]
Paths default to <work>/../input and <work>/output relative to this file.
Steps: (1) pixel extraction of each arm's step curve by colour,
(2) axis calibration from tick-mark pixels, (3) Guyot-type interval
reconstruction constrained by the number-at-risk table (risk counts
transcribed by visual reading of the figure; see assumptions.md),
(4) atomic CSV write, (5) verification checks -> checks.json,
(6) one censoring-allocation sensitivity analysis -> sensitivity.csv.
"""
import argparse, hashlib, json, os, tempfile
import numpy as np, pandas as pd
from PIL import Image

SEED = 754076957
HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("--input", default=os.path.join(HERE, "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(HERE, ".."))
args = ap.parse_args()
INP, OUT = os.path.abspath(args.input), os.path.abspath(args.out)
rng = np.random.default_rng(SEED)  # recorded; algorithm itself is deterministic

man = json.load(open(os.path.join(INP, "manifest.json")))
N = man["groups"]
im = np.array(Image.open(os.path.join(INP, "figure.png")).convert("RGB")).astype(int)
H, W, _ = im.shape

# ---------------- axis calibration from tick pixels ----------------
dark = im.sum(2) < 200
xt = np.where(dark[936])[0]; xt = xt[xt >= 260]          # x ticks below axis
xt_c = [g.mean() for g in np.split(xt, np.where(np.diff(xt) > 1)[0] + 1)]
yt = np.where(dark[:, 265])[0]; yt = yt[yt < 935]          # y ticks left of axis
yt_c = [g.mean() for g in np.split(yt, np.where(np.diff(yt) > 1)[0] + 1)]
xlab = np.arange(0, 37, 6.0); ylab = np.array([1.0, .8, .6, .4, .2, 0.0])
assert len(xt_c) == len(xlab) and len(yt_c) == len(ylab), (xt_c, yt_c)
ax_, bx_ = np.polyfit(xt_c, xlab, 1)        # time = ax*px + bx
ay_, by_ = np.polyfit(yt_c, ylab, 1)        # surv = ay*py + by
calib = dict(x_tick_px=xt_c, y_tick_px=yt_c, months_per_px=ax_, surv_per_px=ay_,
             x_resid=list(np.polyval([ax_, bx_], xt_c) - xlab),
             y_resid=list(np.polyval([ay_, by_], yt_c) - ylab))
t_of = lambda px: ax_ * px + bx_
s_of = lambda py: ay_ * py + by_

# ---------------- curve extraction ----------------
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
x_axis = int(round(xt_c[0])); y_axis = int(round(yt_c[-1]))

def mask(c, tol=40):
    return (np.abs(im - np.array(c)).sum(2) < tol)

# line thickness from flat regions: median vertical run length
def runs(col):
    ys = np.where(col)[0]
    if len(ys) == 0: return []
    return np.split(ys, np.where(np.diff(ys) > 1)[0] + 1)

def extract(g):
    m = mask(COL[g]); m[:, :x_axis + 1] = False; m[y_axis - 1:, :] = False
    m[:150, :] = False  # legend excluded
    lens = [len(r) for x in range(x_axis + 1, W) for r in runs(m[:, x])]
    th = int(np.median(lens))
    rec = []
    for x in range(x_axis + 1, W):
        rs = runs(m[:, x])
        if not rs: continue
        bot = rs[-1][-1]; top = rs[0][0]
        # right-continuous level in this column = centre of lowest line band
        rec.append((x, t_of(x), s_of(bot - (th - 1) / 2), s_of(top + (th - 1) / 2), top, bot))
    d = pd.DataFrame(rec, columns=["px", "time", "s_low", "s_high", "ytop", "ybot"])
    return d, th

meas, thick = {}, {}
for g in COL:
    meas[g], thick[g] = extract(g)
    meas[g].to_csv(os.path.join(OUT, f"measured_curve_{g}.csv"), index=False)

# risk table read visually from the figure (rows "Group A", "Group B")
RT = np.arange(0, 37, 6.0)
RISK = {"A": [1000, 667, 463, 312, 198, 78, 0], "B": [1000, 758, 564, 419, 323, 129, 0]}

def measured_S(g):
    """Monotone measured step function on the pixel-column grid.
    Origin: first columns can be hidden by overlap of the two arms (B drawn on
    top of A); S(0)=1 by definition; no rescaling of the curve is applied."""
    d = meas[g]
    t = d.time.values; s = np.clip(d.s_low.values, 0, 1)
    # local origin check only: values within one line-width of 1 at t<0.1 are set to 1
    s = np.where((t < 0.1) & (s > 1 - 2 * abs(ay_) * thick[g]), np.minimum(1, s), s)
    s_mono = np.minimum.accumulate(s)  # pixel noise; inspected: no isolated early outliers
    return t, s, s_mono

# ---------------- Guyot-type reconstruction ----------------
def reconstruct(g, cens_shape="uniform"):
    t, s_raw, S = measured_S(g)
    t_end = t[-1]
    nrisk = RISK[g]; n0 = N[g]
    assert nrisk[0] == n0
    events, cens = [], []
    S_rec = 1.0; n_cur = n0
    for i in range(len(RT) - 1):
        lo, hi = RT[i], RT[i + 1]
        idx = np.where((t >= lo) & (t < hi))[0]
        if len(idx) == 0: continue
        target_next = nrisk[i + 1]
        last = (target_next == 0)
        hi_c = min(hi, t_end) if last else hi
        def sim(nc, commit=False):
            # censor times in [lo, hi_c)
            if cens_shape == "uniform":
                u = (np.arange(nc) + 0.5) / max(nc, 1)
            else:  # 'late': density proportional to (t-lo)
                u = np.sqrt((np.arange(nc) + 0.5) / max(nc, 1))
            ct = lo + u * (hi_c - lo)
            if last and nc > 0:
                ct = np.minimum(ct, t_end)
            n = n_cur; Sr = S_rec; ev = []; ci = 0
            for k in idx:
                tk = t[k]
                while ci < nc and ct[ci] < tk:   # censored before this column
                    n -= 1; ci += 1
                if n <= 0: break
                d = int(round(n * (1 - S[k] / Sr))) if Sr > 0 else 0
                d = max(0, min(d, n))
                if d:
                    ev += [tk] * d; Sr *= (1 - d / n); n -= d
            n_rem_cens = nc - ci
            n_end = n - n_rem_cens
            return n_end, ev, list(ct), Sr
        # search nc so that n at hi equals target (for last interval: n_end==0)
        nc_max = n_cur
        best = None
        for nc in range(0, nc_max + 1):
            n_end, ev, ct, Sr = sim(nc)
            err = n_end - target_next
            if best is None or abs(err) < abs(best[0]) or (abs(err) == abs(best[0]) and nc < best[1]):
                best = (err, nc, ev, ct, Sr, n_end)
            if err <= 0 and n_end >= 0 and err < 0: break
            if err == 0: break
        err, nc, ev, ct, Sr, n_end = best
        if err != 0 and not last:
            print(f"[{g}] interval {lo}-{hi}: could not hit risk {target_next}, residual {err}")
        if last and n_end > 0:
            # remaining participants censored at the end of the plotted curve (< 36)
            ct = ct + [t_end] * n_end; n_end = 0
        events += ev; cens += ct
        S_rec = Sr; n_cur = n_end if not last else 0
    df = pd.DataFrame({"group": g,
                       "observed_time": np.r_[events, cens],
                       "event": np.r_[np.ones(len(events), int), np.zeros(len(cens), int)]})
    assert len(df) == n0, (g, len(df))
    return df.sort_values(["observed_time", "event"], ascending=[True, False])

def atomic_write(df, path):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        df.to_csv(f, index=False, float_format="%.4f")
    os.chmod(tmp, 0o644); os.replace(tmp, path)

def km(df):
    d = df.sort_values("observed_time")
    ts = np.unique(d.observed_time[d.event == 1])
    S = 1.0; out = []
    for u in ts:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((u, S))
    return np.array(out)

def km_at(curve, tq):  # right-continuous step evaluation
    i = np.searchsorted(curve[:, 0], tq, side="right") - 1
    return 1.0 if i < 0 else curve[i, 1]

def rmst(curve, tau):
    pts = np.r_[0, curve[curve[:, 0] < tau, 0], tau]
    vals = [1.0] + list(curve[curve[:, 0] < tau, 1])
    return float(np.sum(np.diff(pts) * np.array(vals)))

if __name__ == "__main__":
    prim = {g: reconstruct(g) for g in ["A", "B"]}
    ipd = pd.concat([prim["A"], prim["B"]], ignore_index=True)
    ipd_path = os.path.join(OUT, "ipd.csv")
    atomic_write(ipd, ipd_path)

    # ---------- checks on the reloaded committed CSV ----------
    R = pd.read_csv(ipd_path)
    sha = hashlib.sha256(open(ipd_path, "rb").read()).hexdigest()
    TOL = 0.01  # ~1.5 line-widths of pixel measurement uncertainty (1 px = %.5f)
    checks = {"csv_sha256": sha, "seed": SEED, "calibration": calib,
              "line_thickness_px": thick, "km_tolerance": TOL,
              "km_tolerance_justification": "1 px = %.5f survival; line ~%s px thick; tolerance ~7 px allows for antialias/line-centre ambiguity and step rounding" % (abs(ay_), thick["A"]),
              "arms": {}}
    tq = [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5]
    for g in ["A", "B"]:
        d = R[R.group == g]
        c = km(d)
        t, s_raw, S = measured_S(g)
        kmrows = []
        for q in tq:
            if q > t[-1]: kmrows.append(dict(t=q, status="unavailable (beyond curve)")); continue
            k = np.searchsorted(t, q, side="right") - 1
            mv = float(S[k]) if k >= 0 else 1.0; rv = km_at(c, q)
            kmrows.append(dict(t=q, measured=round(mv, 4), reconstructed=round(rv, 4),
                               residual=round(rv - mv, 4), status="pass" if abs(rv - mv) <= TOL else "fail"))
        rk = []
        for q, n_obs in zip(RT, RISK[g]):
            n_rec = int((d.observed_time >= q).sum())
            rk.append(dict(t=q, displayed=n_obs, reconstructed=n_rec, residual=n_rec - n_obs,
                           status="pass" if n_rec == n_obs else "fail"))
        checks["arms"][g] = dict(
            n_records=len(d), n_expected=N[g], n_ok=bool(len(d) == N[g]),
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            n_events=int(d.event.sum()), n_censored=int((d.event == 0).sum()),
            supplied_event_total="unavailable (not in manifest)",
            max_time=float(d.observed_time.max()), curve_end_time=float(t[-1]),
            km_checks=kmrows, risk_checks=rk,
            tail=dict(measured_last=float(S[-1]), reconstructed_last=float(c[-1, 1]),
                      residual=float(c[-1, 1] - S[-1])))

    # ---------- one sensitivity allocation ----------
    sens = pd.concat([reconstruct(g, "late") for g in ["A", "B"]], ignore_index=True)
    atomic_write(sens, os.path.join(OUT, "sensitivity.csv"))
    tau = 35.5
    comp = {"assumption": "censoring density within each risk interval increasing linearly (late-loaded) instead of uniform",
            "horizon_months": tau}
    for g in ["A", "B"]:
        c1 = km(R[R.group == g]); c2 = km(sens[sens.group == g])
        comp[g] = dict(S_primary=round(km_at(c1, tau), 4), S_sens=round(km_at(c2, tau), 4),
                       S12_primary=round(km_at(c1, 12), 4), S12_sens=round(km_at(c2, 12), 4),
                       RMST_primary=round(rmst(c1, tau), 3), RMST_sens=round(rmst(c2, tau), 3),
                       events_primary=int(R[R.group == g].event.sum()),
                       events_sens=int(sens[sens.group == g].event.sum()))
    checks["sensitivity"] = comp
    json.dump(checks, open(os.path.join(OUT, "checks.json"), "w"), indent=1, default=float)

    # overlay plot
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 6))
    for g, col in [("A", "tab:blue"), ("B", "tab:orange")]:
        t, s_raw, S = measured_S(g); c = km(R[R.group == g])
        ax.plot(t, s_raw, ".", ms=1, color="k")
        ax.step(np.r_[0, c[:, 0]], np.r_[1, c[:, 1]], where="post", color=col, lw=0.8)
    ax.set_xlabel("months"); ax.set_ylabel("S(t)"); fig.savefig(os.path.join(OUT, "overlay.png"), dpi=120)
    print(json.dumps({g: {k: v for k, v in checks["arms"][g].items() if k not in ("km_checks",)} for g in "AB"}, indent=1, default=float))
    print(json.dumps(checks["sensitivity"], indent=1))
    for g in "AB":
        print(g, [(r["t"], r.get("residual"), r["status"]) for r in checks["arms"][g]["km_checks"]])
