#!/usr/bin/env python3
"""KM -> participant-level reconstruction from the vector paths in figure.pdf.

Usage: python reconstruct.py [--input ../input] [--out ../output] [--alt]
Paths default to locations relative to this file (output/code/ -> ../../../input).
No KM-to-IPD package is used; deterministic (seed recorded for completeness).
"""
import argparse, json, os, sys, tempfile
import numpy as np, pandas as pd, pdfplumber

SEED = 981674807
np.random.seed(SEED)  # nothing stochastic below; recorded per instructions

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument('--input', default=os.path.join(HERE, '..', '..', '..', 'input'))
ap.add_argument('--out', default=os.path.join(HERE, '..'))
ap.add_argument('--alt', action='store_true',
                help='sensitivity: take 2nd-best multiplicity solution where ambiguous')
args = ap.parse_args()

man = json.load(open(os.path.join(args.input, 'manifest.json')))
pg = pdfplumber.open(os.path.join(args.input, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks (tick lines + their text labels)
words = pg.extract_words()
def num(s):
    try: return float(s)
    except ValueError: return None
xt = {}; yt = {}
for l in pg.lines:
    (x0, y0), (x1, y1) = l['pts']
    if abs(x0 - x1) < 1e-6 and abs(abs(y1 - y0) - 3) < 0.1:      # x ticks
        lab = [w for w in words if abs((w['x0'] + w['x1']) / 2 - x0) < 4 and w['top'] > max(y0, y1)
               and w['top'] - max(y0, y1) < 10 and num(w['text']) is not None]
        if lab: xt[num(lab[0]['text'])] = x0
    if abs(y0 - y1) < 1e-6 and abs(abs(x1 - x0) - 3) < 0.1:      # y ticks
        lab = [w for w in words if abs((w['top'] + w['bottom']) / 2 - y0) < 4 and w['x1'] < min(x0, x1)
               and num(w['text']) is not None]
        if lab: yt[num(lab[0]['text'])] = y0
xv = np.array(sorted(xt)); yv = np.array(sorted(yt))
ax_, bx_ = np.polyfit([xt[v] for v in xv], xv, 1)
ay_, by_ = np.polyfit([yt[v] for v in yv], yv, 1)
xres = max(abs(ax_ * xt[v] + bx_ - v) for v in xv); yres = max(abs(ay_ * yt[v] + by_ - v) for v in yv)
T = lambda px: ax_ * px + bx_
S = lambda py: ay_ * py + by_

# ---- risk table (rows labelled "Group A"/"Group B" below "Number at risk")
hdr = [w for w in words if w['text'] == 'Number'][0]['top']
risk = {}
for g in ('A', 'B'):
    lab = [w for w in words if w['text'] == g and w['top'] > hdr][0]
    row = [w for w in words if abs(w['top'] - lab['top']) < 1 and w['x0'] > lab['x1'] + 2]
    risk[g] = {}
    for w in row:
        t = T((w['x0'] + w['x1']) / 2)
        risk[g][int(round(t))] = int(w['text'])

# ---- curves: match by legend colour
legend = {}
for l in pg.lines:
    if l['stroking_color'] != (0.0, 0.0, 0.0) and l['stroking_color'] != (0, 0, 0):
        lx = l['pts'][1][0]
        g = min((w for w in words if w['text'] in ('A', 'B') and w['top'] < 40),
                key=lambda w: abs(w['x0'] - lx))['text']
        legend[tuple(l['stroking_color'])] = g
curves = {legend[tuple(c['stroking_color'])]: c['pts'] for c in pg.curves}

obs_rows = []
steps = {}
for g, pts in curves.items():
    pts = [(T(x), S(y)) for x, y in pts]
    for (t, s) in pts: obs_rows.append((g, t, s))
    drops = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-9 and s1 < s0 - 1e-9:
            drops.append((t0, s0, s1))
    steps[g] = dict(start=pts[0], end=pts[-1], drops=drops)
pd.DataFrame(obs_rows, columns=['group', 'time', 'surv']).to_csv(
    os.path.join(args.out, 'extracted_curve_vertices.csv'), index=False)

# ---- multiplicity inference: n_k = d_k * S_before / (S_before - S_after)
# DP over drops; state = n_k. Constraints: n_1 <= N, n_{k+1} <= n_k - d_k,
# risk table R(T) for T between drops: n_k - d_k >= R(T) >= n_{k+1}; R(T) with
# T before first drop: R(T) <= N and >= n_1.  Cost = relative rounding error
# of n_k (measurement) + LAMBDA*(d_k-1)  (mild parsimony preference, an assumption).
LAMBDA = 0.02; DMAX = 6; TOL = 0.02  # TOL: max |n_cont-n_int| allowed (coords given to ~1e-2 pt)
def solve(g, N, rank=0):
    D = steps[g]['drops']; R = risk[g]
    cand = []
    for (t, sb, sa) in D:
        c = []
        for d in range(1, DMAX + 1):
            nc = d * sb / (sb - sa); ni = int(round(nc))
            # tolerance scaled by derivative wrt 0.005pt coordinate rounding
            tol = max(TOL, 3 * nc * (0.005 / 180) * (1 / (sb - sa) + 1 / sb))
            if ni >= d and abs(nc - ni) <= tol:
                c.append((d, ni, abs(nc - ni) / ni + LAMBDA * (d - 1)))
        cand.append(c)
    times = [d[0] for d in D]
    def rt_ok(k, n_after_prev, n_next):
        lo = times[k - 1] if k > 0 else -1; hi = times[k] if k < len(times) else 1e9
        for tt, r in R.items():
            if (lo < tt <= hi) if k > 0 else (tt <= hi):
                if not (n_after_prev >= r >= n_next): return False
        return True
    # DP: list of (cost, path) per state, keep top-3 for alternatives
    layer = {None: [(0.0, [])]}
    for k, c in enumerate(cand):
        new = {}
        for prev, lst in layer.items():
            n_after = N if prev is None else prev[1] - prev[0]
            for (d, n, cost) in c:
                if n > n_after or not rt_ok(k, n_after, n): continue
                for (pc, path) in lst:
                    new.setdefault((d, n), []).append((pc + cost, path + [(d, n)]))
        layer = {s: sorted(v)[:3] for s, v in new.items()}
    # tail: remaining must be >= risk at table times after last drop (until curve end)
    sols = []
    for s, lst in layer.items():
        rem = s[1] - s[0]
        ok = all(rem >= r for tt, r in R.items() if tt > times[-1] and tt <= steps[g]['end'][0])
        ok = ok and all(r == 0 for tt, r in R.items() if tt > steps[g]['end'][0])
        if ok: sols += lst
    sols.sort()
    return sols, cand

def place(lo, hi, m, include_hi=False):
    if m <= 0: return []
    if include_hi:
        return list(lo + (hi - lo) * np.arange(1, m + 1) / m)
    return list(lo + (hi - lo) * np.arange(1, m + 1) / (m + 1))

records = []; report = {}
for g in ('A', 'B'):
    N = man['groups'][g]
    sols, cand = solve(g, N)
    if not sols:
        print(f'group {g}: no feasible solution', file=sys.stderr); continue
    pick = sols[1] if (args.alt and len(sols) > 1) else sols[0]
    path = pick[1]
    D = steps[g]['drops']; R = risk[g]; tend = steps[g]['end'][0]
    recs = []
    # interval boundaries: censoring between drops split at risk-table times
    bounds = [steps[g]['start'][0]] + [d[0] for d in D] + [tend]
    n_after = [N] + [n - d for d, n in path]
    n_next = [n for d, n in path] + [0]
    issues = []
    for k in range(len(bounds) - 1):
        lo, hi = bounds[k], bounds[k + 1]
        m = n_after[k] - n_next[k]          # censored in (lo, hi) (or (lo, tend] in tail)
        tail = (k == len(bounds) - 2)
        cut = [lo] + sorted(tt for tt in R if lo < tt <= hi and tt > 0) + [hi]
        prev_count = n_after[k]
        segs = []
        for j in range(1, len(cut)):
            if j < len(cut) - 1:
                r = R[cut[j]]; mj = prev_count - r; prev_count = r
            else:
                mj = prev_count - n_next[k]
            if mj < 0: issues.append((k, cut[j], mj)); mj = 0
            segs.append((cut[j - 1], cut[j], mj))
        for j, (a, b, mj) in enumerate(segs):
            inc = tail and j == len(segs) - 1
            recs += [(g, t, 0) for t in place(a, b, mj, include_hi=inc)]
        if k < len(D):
            recs += [(g, D[k][0], 1)] * path[k][0]
    report[g] = dict(path=path, cost=pick[0], n_solutions=len(sols),
                     alt_cost=(sols[1][0] if len(sols) > 1 else None), issues=issues,
                     n_records=len(recs))
    if len(recs) != N:
        print(f'group {g}: record count {len(recs)} != {N}', file=sys.stderr); continue
    records += recs

df = pd.DataFrame(records, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(4)
fn = 'sensitivity.csv' if args.alt else 'ipd.csv'
fd, tmp = tempfile.mkstemp(dir=args.out, suffix='.tmp')
os.close(fd); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(args.out, fn))

# diagnostics for inspection
diag = dict(calibration=dict(x_ticks=xt, y_ticks=yt, x_fit=[ax_, bx_], y_fit=[ay_, by_],
                             max_tick_residual=[xres, yres]),
            risk_table=risk, groups={})
for g in report:
    D = steps[g]['drops']
    diag['groups'][g] = dict(start=steps[g]['start'], end=steps[g]['end'],
        n_solutions=report[g]['n_solutions'], cost=report[g]['cost'], alt_cost=report[g]['alt_cost'],
        issues=report[g]['issues'],
        drops=[dict(t=round(t, 4), s_before=round(sb, 5), s_after=round(sa, 5),
                    n_if_d1=round(sb / (sb - sa), 3), d=p[0], n_risk=p[1],
                    candidates=[(c[0], c[1]) for c in cand_])
               for (t, sb, sa), p, cand_ in zip(D, report[g]['path'], solve(g, man['groups'][g])[1])])
json.dump(diag, open(os.path.join(args.out, 'diag_alt.json' if args.alt else 'diag.json'), 'w'), indent=1, default=float)
print(json.dumps({g: {k: v for k, v in r.items() if k != 'path'} for g, r in report.items()}, default=float))
