#!/usr/bin/env python3
"""Reload committed CSV(s), recompute right-continuous KM, compare with measured
vector curve and risk table; write checks.json. Usage: python checks.py [--out ..]"""
import argparse, hashlib, json, os
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser(); ap.add_argument('--out', default=os.path.join(HERE, '..'))
a = ap.parse_args(); O = a.out
diag = json.load(open(os.path.join(O, 'diag.json')))
verts = pd.read_csv(os.path.join(O, 'extracted_curve_vertices.csv'))
N = {'A': 100, 'B': 100}

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n; out.append((u, s))
    return out
def S_at(steps, x):  # right-continuous
    s = 1.0
    for u, v in steps:
        if u <= x + 1e-12: s = v
        else: break
    return s
def meas_at(g, x):   # measured step curve: value after all vertices with t<=x
    v = verts[verts.group == g]; v = v[v.time <= x + 1e-9]
    return float(v.surv.iloc[-1])
def rmst(steps, h):
    pts = [0.0] + [u for u, _ in steps if u < h] + [h]; area = 0
    for i in range(len(pts) - 1): area += S_at(steps, pts[i]) * (pts[i + 1] - pts[i])
    return area

def check(fn):
    path = os.path.join(O, fn); raw = open(path, 'rb').read()
    df = pd.read_csv(path); res = dict(file=fn, sha256=hashlib.sha256(raw).hexdigest(), arms={})
    assert list(df.columns) == ['group', 'observed_time', 'event']
    for g in ('A', 'B'):
        d = df[df.group == g]; steps = km(d); gd = diag['groups'][g]; tend = gd['end'][0]
        drops = [r['t'] for r in gd['drops']]
        # check times: grid, plus just after each of first 3 and last 3 drops, plus curve end (tail)
        times = sorted(set([0.0] + list(np.arange(1, 36, 1.5)[np.arange(1, 36, 1.5) <= tend]) +
                           [t + 1e-3 for t in drops[:3] + drops[-3:]] + [tend]))
        # tolerance: vector coordinates are given to ~0.01 pt => survival ~6e-5; KM of integer
        # counts cannot match better than rounding; tolerance 0.002 (well below 1 event at n=100: 0.01)
        tol = 0.002
        comp = []
        for t in times:
            m = meas_at(g, t); r = S_at(steps, t)
            comp.append(dict(t=round(t, 4), measured=round(m, 5), reconstructed=round(r, 5),
                             residual=round(r - m, 5), status='pass' if abs(r - m) <= tol else 'fail'))
        rt = []
        for t, r in diag['risk_table'][g].items():
            t = float(t); c = int((d.observed_time >= t).sum())
            rt.append(dict(t=t, displayed=r, reconstructed=c, residual=c - r,
                           status='pass' if c == r else 'fail'))
        res['arms'][g] = dict(
            n_records=len(d), n_expected=N[g], size_status='pass' if len(d) == N[g] else 'fail',
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            supplied_event_total='unavailable (not in manifest)',
            max_time=float(d.observed_time.max()), curve_end_time=tend,
            km_vs_measured_tolerance=tol, km_vs_measured=comp,
            max_abs_residual=max(abs(c['residual']) for c in comp), risk_table=rt,
            censor_marks='unavailable (no censor-mark objects drawn in figure)')
    return res, df

out = {'primary': check('ipd.csv')[0]}
if os.path.exists(os.path.join(O, 'sensitivity.csv')):
    s, sdf = check('sensitivity.csv'); out['sensitivity'] = s
    p = pd.read_csv(os.path.join(O, 'ipd.csv'))
    h = min(diag['groups'][g]['end'][0] for g in ('A', 'B'))
    cmp = {'common_horizon_months': h}
    for g in ('A', 'B'):
        k1 = km(p[p.group == g]); k2 = km(sdf[sdf.group == g])
        cmp[g] = dict(S_primary=S_at(k1, h), S_alt=S_at(k2, h),
                      RMST_primary=rmst(k1, h), RMST_alt=rmst(k2, h),
                      S36_primary_last=S_at(k1, 36), S36_alt_last=S_at(k2, 36))
    out['sensitivity_comparison'] = cmp
json.dump(out, open(os.path.join(O, 'checks.json'), 'w'), indent=1, default=float)
for k in ('primary', 'sensitivity'):
    if k in out:
        for g, v in out[k]['arms'].items():
            print(k, g, v['n_records'], v['events'], v['max_abs_residual'],
                  [(r['t'], r['displayed'], r['reconstructed']) for r in v['risk_table']],
                  sum(c['status'] == 'fail' for c in v['km_vs_measured']))
print(out.get('sensitivity_comparison'))
