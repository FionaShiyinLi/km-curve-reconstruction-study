# Reconstruction assumptions (figure.pdf, groups A and B)

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 981674807). The manifest gives no arm-specific event totals, so that check is marked unavailable. No other information was used.

**Measurement.** The PDF draws each KM curve as one vector polyline (blue = A, orange = B, matched to the legend by colour). I read the vertices directly from the PDF instead of from pixels. Time and survival were calibrated by a linear fit to the labelled tick marks: x ticks at 0–36 months, y ticks at 0–1. The fit residuals were about 1e-14, so no global correction was applied. Both curves start exactly at (0, 1.0); there is no antialiased or obscured origin. I checked the start, the middle and the tail of each arm against the vertices (`extracted_curve_vertices.csv`; per-drop details are in `diag.json`). The risk table was parsed from the PDF text:
A: 100, 65, 42, 25, 18, 9, 0; B: 100, 66, 53, 42, 36, 12, 0 at months 0, 6, …, 36. The figure contains no censor-mark objects, so censoring times are not observed.

**Algorithm (own code, `code/reconstruct.py`).** For each vertical drop, KM gives n_k = d_k · S_before / (S_before − S_after). I solved for the pair (d_k, n_k) by dynamic programming over all drops, using these constraints:
- n_k must be close to an integer, within the coordinate-rounding tolerance;
- n_1 ≤ N and n_{k+1} ≤ n_k − d_k;
- for each risk-table time T between two drops, n_k − d_k ≥ R(T) ≥ n_{k+1};
- the tail must reach R(36) = 0 by the end of the drawn curve.

The cost is the relative rounding error plus a small penalty of 0.02 per extra event, a stated parsimony assumption. **In arm A, d = 1 is forced at every drop:** any d ≥ 2 needs n greater than the number available. **In arm B the same holds except at the last drop (t = 32.88).** There, (d, n) = (1, 6) and (2, 12) both satisfy every supplied constraint. The primary result uses (1, 6) via the parsimony penalty; this is an assumption, not something the data show.

**Censoring.** The number censored in each inter-drop interval is n_k − d_k − n_{k+1}. Each interval is split further at risk-table times so that the displayed counts hold exactly. Within each sub-interval, censorings are spaced evenly at interior points. This placement is an assumption: without marks, within-interval censoring times cannot be identified. After the last drop, the remaining participants are censored evenly up to the end of the drawn curve (A: 33.43 months, B: 35.63 months), with the last one placed at the curve end. Nobody is placed at or after 36, consistent with the displayed 0 at risk. The flat tail does not identify the follow-up distribution.

**Checks (`code/checks.py` → `checks.json`).** The script reloads the committed CSV and recomputes the right-continuous KM curve.
- **KM vs measured curve:** at 25–29 times per arm (a 1.5-month grid, just after the first and last three drops, and the curve end), the maximum absolute residual is below 1e-5. The tolerance was 0.002, against coordinate precision of about 6e-5.
- **Risk table:** counting records with time ≥ t (events before censoring at ties), all 14 counts match exactly.
- **Arm sizes and events:** 100/100 records, event indicators in {0, 1}. Events: A 75, B 59 (60 under the sensitivity allocation).

**Sensitivity (`sensitivity.csv`, run once).** Arm B's last drop is taken as d = 2, n = 12, so no censoring falls between 30 and 32.88 and 10 censorings fall in the tail. Arm A is unchanged. At the common supported horizon of 33.43 months (the end of A's curve), S and the area under the curve (RMST) are identical in both versions, because the KM steps are reproduced exactly: A has S = 0.1685 and RMST = 13.90; B has S = 0.3019 and RMST = 18.05. The allocations differ in B's event count and in the risk sets over 30–33 months, so variance estimates can differ slightly. A single alternative is not an uncertainty bound.

**Limitations.**
- Within-interval censoring times are unidentified (no marks).
- Drops at nearly coincident x positions, e.g. A at 2.918 and 2.920, were treated as separate times, as drawn.
- Event times are exact only to the drawing precision, about 0.001 month.
- The d = 2 versus d = 1 ambiguity at B's last drop remains unresolved.
