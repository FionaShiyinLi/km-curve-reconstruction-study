"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [figure.jpg] [outdir] [--censor-mode ticks|uniform]
  outdir defaults to ./output ; writes measured_curves.json, plateaus/ticks, ipd.csv
  (or sensitivity.csv when --censor-mode uniform).
Seed 790512406 is set although the algorithm is deterministic.
"""
import sys, os, json, tempfile, itertools
from math import comb
import numpy as np
from PIL import Image

SEED = 790512406
np.random.seed(SEED)

args = [a for a in sys.argv[1:] if not a.startswith("--")]
FIG = args[0] if len(args) > 0 else "../input/figure.jpg"
OUT = args[1] if len(args) > 1 else "output"
MODE = "uniform" if "--censor-mode=uniform" in sys.argv else "ticks"

# ---- calibration from tick marks located by pixel scan (x: 0..36 every 6; y: 0..1 every .2)
X0, X36, Y1, Y0 = 90.0, 570.0, 60.0, 310.0
def t_of(x): return (np.asarray(x, float) - X0) * 36.0 / (X36 - X0)
def s_of(y): return (Y0 - np.asarray(y, float)) / (Y0 - Y1)

# ---- risk table (read visually from figure; times 0,6,...,36)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 65, 42, 25, 18, 9, 0], "B": [100, 66, 53, 42, 36, 12, 0]}
N = {"A": 100, "B": 100}

a = np.array(Image.open(FIG).convert("RGB")).astype(float)
R, G, B = a[..., 0], a[..., 1], a[..., 2]
W = {"A": np.clip((255 - R) / 224.0, 0, 1) * ((B - R) > 30),
     "B": np.clip((255 - B) / 241.0, 0, 1) * ((R - B) > 50) * (R > 150)}
for k in W:
    W[k][:50, :] = 0; W[k][309:, :] = 0; W[k][:, :91] = 0


def levels(w):
    m = w > 0.25
    hz = m & np.roll(m, 1, 1) & np.roll(m, -1, 1)
    cols = np.where(m.any(0))[0]
    xs, ys = [], []
    for x in range(cols.min(), cols.max() + 1):
        rows = np.where(hz[:, x])[0]
        if len(rows) == 0:
            continue
        groups = np.split(rows, np.where(np.diff(rows) > 1)[0] + 1)
        g = min(groups, key=lambda g: abs(g.mean() - ys[-1])) if ys else groups[0]
        lo, hi = g.min() - 1, g.max() + 1
        yy = np.arange(lo, hi + 1); ww = w[lo:hi + 1, x]
        ys.append(float((yy * ww).sum() / ww.sum())); xs.append(x)
    return np.array(xs), np.array(ys)


def plateaus(xs, ys, tol=0.7):
    """Group columns into flat runs; a new run starts when level moves > tol px."""
    out = []  # [x_first, x_last, level_px]
    cur = [xs[0], xs[0], [ys[0]]]
    for x, y in zip(xs[1:], ys[1:]):
        if abs(y - np.median(cur[2])) <= tol and x - cur[1] <= 2:
            cur[1] = x; cur[2].append(y)
        else:
            out.append((cur[0], cur[1], float(np.median(cur[2])))); cur = [x, x, [y]]
    out.append((cur[0], cur[1], float(np.median(cur[2]))))
    # enforce monotone (a rise is a mis-tracked column, e.g. at a crossing): drop it
    clean = []
    for p in out:
        if clean and p[2] < clean[-1][2] - 0.3:
            continue  # higher on screen than previous = artefact
        clean.append(p)
    return clean


def ticks(w, xs, ys):
    lev = dict(zip(xs, ys)); hits = []
    for x in xs:
        nb = [xx for xx in range(x - 4, x + 5) if xx != x and xx in lev and abs(lev[xx] - lev[x]) < 0.7]
        if len(nb) < 4:
            continue
        c = int(round(lev[x]))
        base = np.median(np.stack([w[c - 5:c + 6, xx] for xx in nb]), 0)
        ex = w[c - 5:c + 6, x] - base
        off = np.abs(np.arange(-5, 6))
        if ex[off >= 2].max() >= 0.3 and ex[ex > 0].sum() >= 0.6:
            hits.append(x)
    groups = []
    for x in hits:
        if groups and x - groups[-1][-1] <= 1: groups[-1].append(x)
        else: groups.append([x])
    return [float(np.mean(g)) for g in groups]


meas = {}
for arm in ["A", "B"]:
    xs, ys = levels(W[arm])
    pl = plateaus(xs, ys)
    tk = ticks(W[arm], xs, ys)
    meas[arm] = dict(px_x=xs.tolist(), px_y=ys.tolist(), t=t_of(xs).tolist(), S=s_of(ys).tolist(),
                     plateaus=[dict(t_start=float(t_of(p[0])), t_end=float(t_of(p[1])), S=float(s_of(p[2])),
                                    x0=int(p[0]), x1=int(p[1])) for p in pl],
                     ticks_t=t_of(tk).tolist(), last_t=float(t_of(xs.max())))

# ---- origin handling. Measured plateau at start of each arm is checked locally:
# B: first plateau starts at x=91-92 at S~1 (visible). A: columns 90-100 are overdrawn by B
# (grey blend pixels); local remeasurement of the blend pixels gives A ~1.0 at x<=91,
# ~0.982 (row 64.5) at x=92-94, and the first clean blue plateau at x>=100 (S~0.962).
# We insert these local readings; no global rescaling is applied to either arm.
pa = meas["A"]["plateaus"]
if pa[0]["S"] < 0.99:
    pre = [dict(t_start=0.0, t_end=float(t_of(91)), S=1.0, x0=90, x1=91),
           dict(t_start=float(t_of(92)), t_end=float(t_of(94)), S=float(s_of(64.5)), x0=92, x1=94),
           dict(t_start=float(t_of(95)), t_end=float(t_of(97)), S=float(s_of(67.0)), x0=95, x1=97)]
    meas["A"]["plateaus"] = pre + pa
    meas["A"]["origin_note"] = "A origin obscured by B; plateaus at x<=97 from local blend-pixel reading"
for arm in meas:
    p0 = meas[arm]["plateaus"][0]
    if p0["S"] > 0.985:  # first plateau is the S=1 start (antialiased reading 0.98-1.0 -> 1)
        p0["S"] = 1.0
    elif p0["x0"] > 92:
        # B: the S=1 segment at x=90-93 is drawn in grey blend (both arms overlap) and is not
        # tracked by the colour mask; insert it so the first measured drop (to ~0.98) is retained.
        meas[arm]["plateaus"].insert(0, dict(t_start=0.0, t_end=float(t_of(p0["x0"] - 2)), S=1.0,
                                             x0=90, x1=int(p0["x0"] - 2)))
        meas[arm]["origin_note"] = "S=1 start segment overdrawn; inserted at x=90..%d" % (p0["x0"] - 2)
json.dump(meas, open(os.path.join(OUT, "measured_curves.json"), "w"), indent=1)


def km(times, events):
    o = np.lexsort((1 - np.asarray(events), times))
    t = np.asarray(times)[o]; e = np.asarray(events)[o]
    n = len(t); S = 1.0; out = []
    for u in np.unique(t[e == 1]):
        nr = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / nr; out.append((u, S))
    return out


def reconstruct(arm, mode):
    pl = meas[arm]["plateaus"]
    # drop events: (time of drop, target S after drop)
    drops = []
    for p0, p1 in zip(pl[:-1], pl[1:]):
        if p1["S"] < p0["S"] - 1e-9:
            tx = 0.5 * (t_of(p0["x1"]) + t_of(p1["x0"]))
            drops.append((float(tx), p1["S"]))
    tk = np.array(meas[arm]["ticks_t"]); last_t = meas[arm]["last_t"]
    nrisk = RISK[arm]
    recs = []  # (time, event)
    n_cur = N[arm]; S_cur = 1.0
    log = []
    def sim(ct, dr):
        S = S_cur; ev = []; sse = 0.0
        for (td, St) in dr:
            n_at = n_cur - sum(e[1] for e in ev) - (ct < td).sum()
            if n_at <= 0: break
            d = int(round(n_at * (1 - St / S))) if S > 0 else 0
            d = max(0, min(d, n_at))
            if d > 0:
                ev.append((td, d)); S *= 1 - d / n_at
            sse += (S - St) ** 2
        return ev, S, sse
    for i in range(len(RISK_T) - 1):
        lo, hi = RISK_T[i], RISK_T[i + 1]
        dr = [d for d in drops if lo <= d[0] < hi]
        tki = tk[(tk >= lo) & (tk < hi)]
        if hi == 36:  # final interval: curve end is a censoring (flat end) - ensure it is a censor slot
            tki = np.unique(np.append(tki, last_t))
        target_next = nrisk[i + 1]
        best = None
        for c in range(0, n_cur + 1):
            # censor times
            if c == 0:
                ct = np.array([])
            elif mode == "ticks" and len(tki) > 0:
                if c <= len(tki):
                    idx = np.unique(np.round(np.linspace(0, len(tki) - 1, c)).astype(int))
                    while len(idx) < c:  # fill
                        idx = np.unique(np.append(idx, [j for j in range(len(tki)) if j not in idx][0]))
                    ct = tki[idx]
                else:  # more censorings than visible marks: assume tick multiplicity; extra
                    # censorings go greedily to the tick slot that best fits the measured plateaus
                    # (exhaustive over slot multisets when tractable, otherwise greedy)
                    ct = np.array(tki, float); k = c - len(tki)
                    if comb(len(tki) + k - 1, k) <= 5000:
                        ct = min((np.sort(np.append(tki, list(e))) for e in
                                  itertools.combinations_with_replacement(tki, k)), key=lambda z: sim(z, dr)[2])
                    else:
                        for _ in range(k):
                            ct = min((np.sort(np.append(ct, s)) for s in tki), key=lambda z: sim(z, dr)[2])
            else:  # uniform within interval (and within supported follow-up in final interval)
                end = min(hi, last_t) if hi == 36 else hi
                ct = lo + (end - lo) * (np.arange(c) + 0.5) / c
                if hi == 36: ct[-1] = last_t
            ev, S, _ = sim(ct, dr)
            ne = sum(e[1] for e in ev)
            pred = n_cur - ne - c
            if pred < 0: break
            err = abs(pred - target_next)
            if best is None or err < best[0]:
                best = (err, c, ct, ev, S, pred)
            if pred < target_next: break
        err, c, ct, ev, S, pred = best
        for td, d in ev: recs += [(td, 1)] * d
        recs += [(float(x), 0) for x in ct]
        log.append(dict(interval=[lo, hi], n_start=n_cur, censored=int(c), events=int(sum(e[1] for e in ev)),
                        ticks_visible=int(len(tki)), n_end_pred=int(pred), n_end_table=target_next))
        n_cur = pred; S_cur = S
    assert n_cur == 0, (arm, n_cur)
    return recs, log


rows = []; logs = {}
for arm in ["A", "B"]:
    recs, log = reconstruct(arm, MODE)
    assert len(recs) == N[arm], (arm, len(recs))
    logs[arm] = log
    rows += [(arm, round(t, 4), e) for t, e in sorted(recs)]
json.dump(logs, open(os.path.join(OUT, f"reconstruction_log_{MODE}.json"), "w"), indent=1)
fn = "ipd.csv" if MODE == "ticks" else "sensitivity.csv"
fd, tmp = tempfile.mkstemp(dir=OUT, suffix=".tmp")
with os.fdopen(fd, "w") as f:
    f.write("group,observed_time,event\n")
    for g, t, e in rows: f.write(f"{g},{t},{e}\n")
os.replace(tmp, os.path.join(OUT, fn))
for arm in logs:
    print(arm, json.dumps(logs[arm]))
    print(arm, "ticks", len(meas[arm]["ticks_t"]), "plateaus", len(meas[arm]["plateaus"]))
