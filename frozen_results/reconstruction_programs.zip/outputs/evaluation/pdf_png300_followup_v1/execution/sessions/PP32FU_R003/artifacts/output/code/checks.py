"""Reload committed CSV, recompute right-continuous KM, compare with measurements and risk table.

Usage: python checks.py [outdir]   (reads outdir/ipd.csv, outdir/measured_curves.json;
       writes outdir/checks.json; if outdir/sensitivity.csv exists, adds a same-horizon comparison)
"""
import sys, os, json, hashlib
import numpy as np
import pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 65, 42, 25, 18, 9, 0], "B": [100, 66, 53, 42, 36, 12, 0]}
N = {"A": 100, "B": 100}
TOL_S = 0.02  # ~5 px vertical: line width (~2 px) + JPEG blur + tracking at crossings; 1 event at n=100 = 0.01


def km_fn(t, e):
    t = np.asarray(t, float); e = np.asarray(e, int)
    ut = np.unique(t[e == 1]); S = 1.0; st = []
    for u in ut:
        S *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); st.append(S)
    ut = np.array(ut); st = np.array(st)
    def f(x):  # right-continuous step
        i = np.searchsorted(ut, x, side="right")
        return 1.0 if i == 0 else float(st[i - 1])
    return f, ut, st


def rmst(f, ut, tau):
    pts = np.concatenate([[0], ut[ut < tau], [tau]])
    return float(sum(f(pts[i]) * (pts[i + 1] - pts[i]) for i in range(len(pts) - 1)))


path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path)
meas = json.load(open(os.path.join(OUT, "measured_curves.json")))
res = {"csv": "ipd.csv", "sha256": sha, "tolerance_S": TOL_S,
       "tolerance_note": "measured curve read at 250 px per unit S; tolerance 0.02 = ~5 px", "arms": {}}
allpass = True
for arm in ["A", "B"]:
    d = df[df.group == arm]
    f, ut, st = km_fn(d.observed_time, d.event)
    m = meas[arm]; mt = np.array(m["t"]); ms = np.array(m["S"])
    ck = {"n": int(len(d)), "n_expected": N[arm], "n_pass": bool(len(d) == N[arm]),
          "event_int_pass": bool(set(d.event.unique()) <= {0, 1}),
          "events": int(d.event.sum()), "censored": int((d.event == 0).sum()),
          "event_total_supplied": "unavailable (manifest has no event totals)"}
    # survival checks at supported times incl. beginning and tail; use measured plateau readings
    times = [0.25, 0.5, 1, 2, 3, 3.3, 4.5, 6, 8, 10, 12, 15, 18, 21, 24, 27, 30, round(float(m["last_t"]) - 0.2, 2)]
    sv = []
    pls = m["plateaus"]
    for tt in times:
        p = [q for q in pls if q["t_start"] - 1e-9 <= tt <= q["t_end"] + 1e-9]
        r = f(tt)
        if not p:
            j = np.argmin(np.abs(mt - tt))
            sv.append(dict(t=tt, reconstructed=round(r, 4), nearest_column_t=round(float(mt[j]), 3),
                           nearest_column_S=round(float(ms[j]), 4),
                           status="unresolved: time falls on a step/untracked column (no plateau reading)"))
            continue
        resid = r - p[0]["S"]
        ok = abs(resid) <= TOL_S; allpass &= ok
        sv.append(dict(t=tt, measured=round(float(p[0]["S"]), 4), reconstructed=round(r, 4),
                       residual=round(float(resid), 4), status="pass" if ok else "fail"))
    ck["survival"] = sv
    allres = [f(t) - s for t, s in zip(mt, ms)]
    ck["all_columns_max_abs_resid"] = round(float(np.max(np.abs(allres))), 4)
    ck["all_columns_mean_abs_resid"] = round(float(np.mean(np.abs(allres))), 4)
    rk = []
    for t, n in zip(RISK_T, RISK[arm]):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, table=n, reconstructed=c, residual=c - n, status="pass" if c == n else "fail"))
        allpass &= c == n
    ck["risk_table"] = rk
    ck["max_observed_time"] = float(d.observed_time.max()); ck["last_curve_t"] = m["last_t"]
    res["arms"][arm] = ck
res["overall"] = "pass" if allpass else "fail (see per-item status)"

sp = os.path.join(OUT, "sensitivity.csv")
if os.path.exists(sp):
    ds = pd.read_csv(sp)
    tau = 33.0  # common supported horizon: A curve ends at ~33.3 months
    comp = {"horizon_months": tau}
    for arm in ["A", "B"]:
        fp, up, _ = km_fn(df[df.group == arm].observed_time, df[df.group == arm].event)
        fs, us, _ = km_fn(ds[ds.group == arm].observed_time, ds[ds.group == arm].event)
        comp[arm] = dict(S_primary=round(fp(tau), 4), S_sensitivity=round(fs(tau), 4),
                         RMST_primary=round(rmst(fp, up, tau), 3), RMST_sensitivity=round(rmst(fs, us, tau), 3),
                         S_at_12_primary=round(fp(12), 4), S_at_12_sensitivity=round(fs(12), 4),
                         events_primary=int(df[df.group == arm].event.sum()),
                         events_sensitivity=int(ds[ds.group == arm].event.sum()))
    comp["sensitivity_sha256"] = hashlib.sha256(open(sp, "rb").read()).hexdigest()
    res["sensitivity_comparison"] = comp
json.dump(res, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
print(json.dumps(res, indent=None)[:6000])
