# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.jpg` (600×450 raster JPEG). Arm A is blue and arm B is orange.
- `../input/manifest.json`: n_A = n_B = 100; time in months; seed 790512406 (set in code; the algorithm itself is deterministic).
- Risk table (read visually from the figure at 0, 6, …, 36 months): A 100/65/42/25/18/9/0, B 100/66/53/42/36/12/0. All values were clearly legible.
- The figure gives no arm-specific event totals and no other auxiliary data. Event totals are therefore **unavailable** and were not checked. Their absence was not treated as zero events.

## Reproduction
From the work directory:

```
python output/code/reconstruct.py ../input/figure.jpg output
python output/code/reconstruct.py ../input/figure.jpg output --censor-mode=uniform   # sensitivity
python output/code/checks.py output
```

## Measurement
- **Calibration.** Tick marks were located by pixel scan: x = 90 → 0 months and x = 570 → 36 months (80 px per 6 months); y = 60 → S = 1 and y = 310 → S = 0 (50 px per 0.2). Both axes are linear and the tick spacings agree exactly, so no other global transform was applied to either arm. One pixel equals 0.075 months or 0.004 survival; one event at n = 100 equals 2.5 px.
- **Curve tracking.** The curve level is the antialias-weighted centroid of colour-masked pixels that belong to horizontal runs (at least 3 columns), taken column by column. Columns are grouped into plateaus with a 0.7 px tolerance. A one-column "plateau" inside a vertical segment can occur; it is kept as an intermediate target, which is harmless because the KM drop is computed against the next plateau. Plateaus that rise were dropped as tracking artefacts; this mainly affects the A/B crossing near 6–7 months.
- **Origin.** Both arms overlap at the start and are drawn as grey blend pixels, so the origin was remeasured locally rather than rescaled.
  - B: the S = 1 segment (x = 90–93) is not captured by the colour mask, so it was inserted. The first measured B drop, to about 0.98 at about 0.4 months, is retained.
  - A: columns 90–100 are overdrawn by B. Local blend-pixel readings gave S ≈ 1 up to x = 91, about 0.982 at x = 92–94 and about 0.972 at x = 95–97, followed by the first clean blue plateau at about 0.962 from 0.9 months. These early A drops (about 4 events in the first 0.9 months) come from blend pixels and are uncertain by about 1 event in timing and split.
  - No running-minimum or reciprocal rescaling was applied.
- **Censor marks.** A tick is a column on a flat run whose pixel profile exceeds the median of neighbouring columns by at least 0.3 at 2 or more px from the line. Adjacent hit columns are merged. Tick visibility is **not** multiplicity: overlapping marks, especially in B between 24 and 30 months, and marks in steep segments may be merged or missed. For example, B's early segment (0–6 months) yielded no detected ticks. Some marks visible by eye were also missed, e.g. B at about 32.4 months.

## Reconstruction algorithm (own implementation, Guyot-type logic)
1. Drops between consecutive plateaus give drop times (midpoint of the vertical segment) and target survival values.
2. Within each risk-table interval [t_i, t_{i+1}):
   - Search for the number of censorings c so that n_i − events − c equals the tabulated n_{i+1}.
   - At each drop, d = round(n_risk × (1 − S_target / S_current)). This uses the reconstructed S, so rounding error does not accumulate. d is **not** fixed at 1; multi-event drops arise wherever the relative drop implies them.
3. **Censoring times, primary.** Censorings are placed at the detected tick positions in the interval.
   - If c is at most the number of ticks, ticks are subsampled evenly.
   - If c exceeds the number of ticks, the extra censorings are assigned to tick slots (an assumed tick multiplicity). The assignment minimises squared error against the measured plateaus: exhaustively when there are at most 5000 multisets, otherwise greedily.
   - If an interval has no ticks (B, 0–6 months), censorings are spread uniformly over the interval.
   - In the final interval, the curve's end (A 33.3, B 35.55 months) is always a censoring slot, because both curves end flat. No follow-up beyond the drawn curve was created.
4. All intervals reconcile exactly with the risk table.

| Arm | Events | Censorings |
|-----|--------|------------|
| A   | 75     | 25         |
| B   | 59     | 41         |

These totals are derived; they were not supplied. Ties at the same time are stored with events before censorings in the at-risk convention (observed_time ≥ t).

## Checks (see `checks.json`)
- Arm sizes are 100/100, and event indicators are integer 0/1.
- Every risk-table count matches exactly, including 0 at 36 months, which no record reaches.
- Right-continuous KM from the reloaded CSV was compared with plateau readings at 18 times per arm, including 0.25–1 months and the tail. The tolerance is 0.02 (about 5 px: line width, JPEG blur, and roughly 2 events' worth of resolution at the reading level).
  - Arm A: maximum |residual| over plateau checks is 0.004.
  - Arm B: maximum |residual| over plateau checks is 0.008. That value is at t = 30, where the reading is a one-column point inside the vertical drop at 29.9–30.1 months; the plateau before it (0.394) and the plateau after it (0.365) both fit.
  - Over all tracked columns, the maximum |residual| is 0.005 for A and 0.013 for B, both at step columns.
- Times that fall exactly on a step or an untracked column are labelled "unresolved" rather than forced to pass. These are B at 0.5, 1, 2, 3, 3.3 and 6 months (B's steep early staircase) and A at 10 months. Nearest-column values are given for them.

## Unresolved limitations
- Censoring times are approximated at tick resolution (about 0.075 months). The multiplicity at each tick is an assumption, constrained only by the risk-table totals and by drop sizes.
  - In B, 5 censorings were assigned to the tick at 31.16 months, because the 32.85-month drop (0.365 → 0.303) fits 1 event with 6 at risk.
  - The alternative fit, 2 events with 12 at risk, would require no censoring between 30 and 32.85 months. That contradicts the visible ticks, so it was not adopted, but it cannot be strictly excluded.
- Event times within a drop are placed at the pixel-resolved drop time. Events tied within one raster column cannot be separated.
- A's first approximately 0.9 months are read from overlapping, blended pixels.
- The reconstruction is one feasible approximation. It does not claim unique recovery, and the sensitivity run below is not an error bound.

## Sensitivity (one alternative, `sensitivity.csv`)
**Alternative assumption:** within each risk-table interval, censorings are spaced uniformly. In the final interval this spacing runs up to the curve end, and the last censoring falls at the curve end. Tick positions are ignored. Event allocation follows the same rules as the primary.

Comparison at the common supported horizon of 33.0 months (A's curve ends at 33.3 months):

| Arm | S(33), primary | S(33), alternative | RMST(0–33), primary | RMST(0–33), alternative | Events, primary | Events, alternative |
|-----|----------------|--------------------|---------------------|-------------------------|-----------------|---------------------|
| A   | 0.169          | 0.169              | 13.80               | 13.79                   | 75              | 75                  |
| B   | 0.303          | 0.303              | 17.93               | 17.93                   | 59              | 59                  |

The KM curve and survival area are insensitive to this choice. Censoring-time placement, and therefore individual follow-up, does differ between the two.
