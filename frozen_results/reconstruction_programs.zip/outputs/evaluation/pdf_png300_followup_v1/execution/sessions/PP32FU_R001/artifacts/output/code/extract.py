"""Measure KM step curves and censor ticks from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'

# Axis calibration from labelled ticks (located by pixel scan of tick marks):
# x ticks 0,6,...,36 months at columns 90,170,...,570; y ticks 0,0.2,...,1 at rows 310,260,...,60
X0, XPM = 90.0, 80.0 / 6.0
Y0, YPU = 310.0, 250.0
t_of = lambda x: (x - X0) / XPM
s_of = lambda y: (Y0 - y) / YPU

im = np.array(Image.open(FIG).convert('RGB')).astype(float)
R, G, B = im[..., 0], im[..., 1], im[..., 2]
alpha = {'A': np.clip((B - R) / 149.0, 0, 1),      # tab:blue (31,119,180)
         'B': np.clip((R - B) / 241.0, 0, 1)}      # tab:orange (255,127,14)
ROW_LO, ROW_HI = 55, 309   # plot panel rows (exclude legend above row 55 and axis at 310)

def measure(arm):
    a = alpha[arm][ROW_LO:ROW_HI, :]
    other = alpha['B' if arm == 'A' else 'A'][ROW_LO:ROW_HI, :]
    m = a > 0.3
    cols = [x for x in range(int(X0), 600) if m[:, x].any()]
    xend = max(cols)
    top = np.full(600, np.nan); bot = np.full(600, np.nan); hidden = []
    for x in range(int(X0), xend + 1):
        rows = np.where(m[:, x])[0]
        if len(rows) == 0:
            # line hidden under the other arm (drawn on top): use other arm's pixels
            rows = np.where(other[:, x] > 0.3)[0]
            if len(rows):
                # keep only the run nearest the previous level
                prev = bot[x - 1]
                rows = rows[np.abs(rows + ROW_LO - prev) <= 4]
            hidden.append(x)
        if len(rows):
            top[x] = rows.min() + ROW_LO; bot[x] = rows.max() + ROW_LO
        else:
            top[x], bot[x] = top[x - 1], bot[x - 1]
    # tick detection: column top extends >=2 px above the reference line top
    tick = np.zeros(600, bool); ref_top = top[int(X0)]; ref_bot = bot[int(X0)]
    for x in range(int(X0) + 1, xend + 1):
        if top[x] <= ref_top - 2 and bot[x] >= ref_bot + 1:
            tick[x] = True
        else:
            ref_top, ref_bot = top[x], bot[x]
    # tick at the plot origin column cannot be separated; last column handled same way
    botc = bot.copy()
    botc[tick] = bot[tick] - 2           # tick half-length below the line bottom = 2 px
    # monotone envelope (from the right) only removes residual upward spikes
    E = botc.copy()
    for x in range(xend - 1, int(X0) - 1, -1):
        E[x] = min(E[x], E[x + 1])
    # line-centre offset from pure horizontal columns
    hz = [x for x in range(int(X0), xend + 1) if not tick[x] and bot[x] - top[x] <= 2
          and x not in hidden]
    offs = []
    for x in hz:
        col = alpha[arm][int(top[x]) - 1:int(bot[x]) + 2, x]
        rr = np.arange(int(top[x]) - 1, int(bot[x]) + 2)
        offs.append(bot[x] - (col * rr).sum() / col.sum())
    off_med = float(np.median(offs))
    # lines are aliased 1-2 px; centre = bottom - 0.5 px for both arms (+/-0.5 px = +/-0.002 S)
    off = 0.5
    S = np.minimum(s_of(E - off), 1.0)
    # tick multiplicity from antialiased strength below the line
    runs = []; x = int(X0)
    while x <= xend:
        if tick[x]:
            x1 = x
            while x1 + 1 <= xend and tick[x1 + 1]: x1 += 1
            st = sum(alpha[arm][int(E[c]) + 1:int(E[c]) + 3, c].sum() for c in range(x, x1 + 1))
            runs.append(dict(x0=x, x1=x1, strength=float(st)))
            x = x1 + 1
        else:
            x += 1
    single = [r['strength'] for r in runs if r['x0'] == r['x1']]
    K = float(np.median(single)) if single else 2.0
    for r in runs:
        w = r['x1'] - r['x0'] + 1
        # strokes are aliased to 1-2 px, so a run of <=2 columns is read as one visible tick;
        # wider runs as ceil(w/2) overlapping ticks. Visibility != multiplicity (see assumptions.md)
        r['width'] = w
        r['count_est'] = 1 if w <= 2 else int(np.ceil(w / 2))
        r['time'] = t_of((r['x0'] + r['x1']) / 2.0)
    return dict(arm=arm, xend=int(xend), t_end=t_of(xend), offset=off, offset_median_horiz=off_med, K=K,
                hidden_cols=hidden,
                curve=[dict(x=int(x), t=t_of(x), S=float(S[x]), top=float(top[x]),
                            bot=float(bot[x]), tick=bool(tick[x]))
                       for x in range(int(X0), xend + 1)],
                ticks=runs)

if __name__ == '__main__':
    res = {arm: measure(arm) for arm in 'AB'}
    json.dump(dict(calibration=dict(X0=X0, px_per_month=XPM, Y0=Y0, px_per_unit=YPU), arms=res),
              open(f'{OUT}/measured_curve.json', 'w'), indent=1)
    for arm in 'AB':
        r = res[arm]
        print(arm, 'xend', r['xend'], 't_end %.2f' % r['t_end'], 'offset %.2f' % r['offset'],
              'K %.2f' % r['K'], 'hidden', r['hidden_cols'][:20], len(r['hidden_cols']))
        print(' ticks', [(round(k['time'], 2), k['count_est'], round(k['strength'], 2)) for k in r['ticks']])
        c = r['curve']
        print(' S@0..', [round(p['S'], 3) for p in c[:12]])
        print(' S at 6-mo marks', [(round(p['t'], 1), round(p['S'], 3)) for p in c if p['x'] % 40 == 10])
