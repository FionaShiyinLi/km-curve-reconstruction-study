from PIL import Image; import numpy as np, sys
im=np.array(Image.open('../input/figure.png').convert('RGB')).astype(float)
r,g,b=im[...,0],im[...,1],im[...,2]
blue=(b-r>40); orange=(r-b>60)
x0,x1=int(sys.argv[1]),int(sys.argv[2]); m=blue if sys.argv[3]=='A' else orange
for x in range(x0,x1):
    rows=np.where(m[60:312,x])[0]+60
    print(x, list(rows))
