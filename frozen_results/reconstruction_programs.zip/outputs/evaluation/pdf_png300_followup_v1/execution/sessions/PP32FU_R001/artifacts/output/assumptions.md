# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (600x450 raster, aliased, with no antialiasing on the curves) and `../input/manifest.json` (A = 100, B = 100, time in months, code seed 790512406).
- I read the number-at-risk table from the figure. A: 100, 65, 42, 25, 18, 9, 0 and B: 100, 66, 53, 42, 36, 12, 0 at 0, 6, ..., 36 months. All values were legible.
- The manifest gives no arm-specific event totals, so that constraint is **unavailable**. I did not assume zero events or any particular total.

## Measurement (`code/extract.py`)
- **Calibration.** I located the axis tick marks by pixel scan. The x ticks for 0–36 months are at columns 90–570 (13.333 px/month). The y ticks for 0–1 are at rows 310–60 (250 px/unit). Calibration is linear from these anchors. No global rescaling was applied to either arm.
- **Curve isolation.** Each arm was isolated by color (A blue, B orange). The plotted lines are aliased to 1–2 px. The level in each column is taken as the bottom of the line minus 0.5 px, which gives about ±0.002 in S.
- **Hidden segments.** B is drawn over A. Where A was hidden (columns 96–98), I used the overlapping orange pixels within 4 px of A's previous level.
- **Censor ticks.** A censor tick is a column whose stroke extends at least 2 px above the reference line top. I removed the tick's 2 px lower extension before reading the level. A right-to-left monotone envelope removes only residual upward spikes. It was not used to propagate an early reading forward.
- **Origin.** At column 90, B sits at S = 1. A's visible pixels are already 2 px lower (S ≈ 0.994), while A's line at 1.0 would be hidden under B. I treated this as a genuine early drop rather than rescaling the curve. It yields one A event at 0.0375 months (half a pixel), and the curve is not otherwise rescaled.
- **Tick multiplicity.** A run of 1–2 adjacent tick columns is read as one visible tick, because strokes are 1–2 px wide. Wider runs are read as ceil(width/2) ticks. A visible tick does not establish how many censorings it represents.
- **Outputs.** The measured per-column curve and ticks are saved in `measured_curve.json`.

## Reconstruction (`code/reconstruct.py`)
- **Approach.** This is my own Guyot-type allocation, applied separately within each risk-table interval [t_i, t_{i+1}).
- **Events at drops.** For each candidate censoring count c, I simulate the interval. At every measured drop column, d = round(n_risk × (1 − S_measured_after / S_reconstructed_before)). The reference is the *reconstructed* KM, so rounding errors self-correct. A drop can contain several events, or none if it is a sub-event pixel artefact. I did not assume d = 1.
- **Choosing c.** The value of c is chosen so that the number at risk at t_{i+1} equals the risk table. Among ties, I prefer c closest to the number of visible ticks.
- **Placing censorings (primary assumption).**
  - If c ≤ the number of visible ticks in the interval, censorings go at evenly selected tick times.
  - If c is larger, the extra, unseen censorings are spread uniformly over the interval. The interval is truncated at the last displayed curve time (A 33.38, B 35.62 months), so no follow-up beyond the displayed curve is invented.
  - At tied times, events precede censorings.
- **Where unseen censorings were needed.**
  - A needed 6 censorings vs 3 visible ticks in 0–6 months, 3 vs 2 in 6–12, 7 vs 5 in 24–30, and 8 vs 7 in 30–36.
  - B needed 3 vs 0 in 0–6, 2 vs 1 in 12–18, 20 vs 17 in 24–30, and 11 vs 9 in 30–36.
  - The timing of these extra censorings is an assumption. Only the interval totals are constrained, by the risk table.
- **Result.** A has 75 events and 25 censorings. B has 59 events and 41 censorings. These are reconstruction outputs, not supplied totals.
- **Randomness.** No step is stochastic. The seed 790512406 is set and recorded anyway.

## Checks (`code/checks.py` → `checks.json`)
- **Method.** The script reloads the committed CSV, computes the right-continuous KM step function, and compares it with the measured curve every 1.5 months plus two tail points.
- **Tolerance.** I fixed the tolerance in advance at 0.004 + S/n_risk. The 0.004 covers the ±0.5 px line-centre and reading error. The S/n_risk term is one event step, covering a one-column drop-time offset.
- **Curve agreement.** All points pass for both arms. Across all columns, the mean absolute residual is 0.004 for A and 0.003 for B.
  - The maximum absolute residual is 0.028 in each arm. It occurs at single columns next to drops (one-pixel timing).
  - Tail plateaus: A is 0.168 reconstructed vs 0.170 measured. B is 0.312 vs 0.306, which is within one event step at n ≈ 6.
- **Risk table.** Counts of records with observed_time ≥ t match the risk table exactly at every time, including 0 at 36 months. No records sit at 36.
- **Other checks.** Arm sizes are 100/100 and event indicators are integer 0/1. The CSV SHA-256 is recorded in `checks.json`.

## Sensitivity (`sensitivity.csv`, one alternative only)
- **Alternative assumption.** Unseen censorings are treated as hidden multiplicity at the visible tick positions within the interval, rather than spread uniformly. Intervals with no visible ticks still use uniform placement.
- **Comparison at the common horizon τ = 33 months.** Both curves are displayed past 33.38 months.

  | Arm | S(33) primary | S(33) alternative | RMST to 33, primary (months) | RMST to 33, alternative (months) |
  |---|---|---|---|---|
  | A | 0.168 | 0.165 | 13.81 | 13.78 |
  | B | 0.312 | 0.300 | 17.91 | 17.87 |

- **Interpretation.** This single alternative is not a confidence interval and does not bound reconstruction error.

## Unresolved limitations
- The exact times of censorings without visible ticks, and the multiplicity of overlapping ticks, are not identified by the figure.
- Event times are resolved only to one pixel column (0.075 months). Events within a column are tied.
- Small drops (1–2 px) near n ≈ 100 are close to the measurement resolution, so individual early event counts may be off by ±1 with compensating shifts nearby.
- No event totals were supplied to cross-check.
- `code/dump_columns.py` is a diagnostic helper only.
- Run from the work directory: `python3 output/code/reconstruct.py ../input/figure.png output`, then `python3 output/code/checks.py ../input/figure.png output`.
