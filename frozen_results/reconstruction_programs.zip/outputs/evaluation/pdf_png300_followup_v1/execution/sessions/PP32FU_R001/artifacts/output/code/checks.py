"""Reload committed CSV(s), recompute right-continuous KM, compare with measurement and risk table.
Usage: python checks.py [figure.png] [outdir]"""
import sys, os, json, hashlib, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
FIG = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
import extract
from reconstruct import RT_T, RT, N, km, S_at, meas
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

def rmst(step, tau):
    a, last_t, last_s = 0.0, 0.0, 1.0
    for t, s in step:
        if t > tau: break
        a += last_s * (t - last_t); last_t, last_s = t, s
    return a + last_s * (tau - last_t)

def check_file(path):
    df = pd.read_csv(path)
    res = dict(file=path, sha256=hashlib.sha256(open(path, 'rb').read()).hexdigest(), arms={})
    for arm in 'AB':
        d = df[df.group == arm]; m = meas[arm]; step = km(d)
        curve = {round(p['t'], 4): p['S'] for p in m['curve']}
        xs = [p for p in m['curve']]
        # comparison times: every 1.5 months plus tail points, all within displayed follow-up
        tgrid = sorted(set([round(x, 2) for x in np.arange(0.5, m['t_end'], 1.5)] +
                           [round(m['t_end'] - 0.5, 2), round(m['t_end'], 2)]))
        comps = []
        for t in tgrid:
            p = min(xs, key=lambda q: abs(q['t'] - t))
            sm = p['S']; sr = S_at(step, p['t'])
            nr = int((d.observed_time >= p['t']).sum())
            tol = 0.004 + sm / max(nr, 1)       # pixel/line-centre error + one event step at that risk set
            comps.append(dict(t=round(p['t'], 3), measured=round(sm, 4), reconstructed=round(sr, 4),
                              residual=round(sr - sm, 4), tol=round(tol, 4),
                              status='pass' if abs(sr - sm) <= tol else 'fail'))
        allres = [S_at(step, p['t']) - p['S'] for p in xs]
        risk = []
        for t, n_disp in zip(RT_T, RT[arm]):
            n_rec = int((d.observed_time >= t).sum())
            risk.append(dict(t=t, displayed=n_disp, reconstructed=n_rec, residual=n_rec - n_disp,
                             status='pass' if n_rec == n_disp else 'fail'))
        res['arms'][arm] = dict(
            n=len(d), n_expected=N[arm], n_status='pass' if len(d) == N[arm] else 'fail',
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            supplied_event_total='unavailable (not in manifest)',
            max_followup=float(d.observed_time.max()), curve_end_measured=round(m['t_end'], 3),
            curve_comparisons=comps,
            all_column_residual=dict(max_abs=round(float(np.max(np.abs(allres))), 4),
                                     mean_abs=round(float(np.mean(np.abs(allres))), 4)),
            risk_table=risk)
    return res, df

if __name__ == '__main__':
    out = {}
    prim, dfp = check_file(f'{OUT}/ipd.csv'); out['primary'] = prim
    out['tolerance_note'] = ('curve tol = 0.004 (+/-0.5 px centre ambiguity at 250 px/unit plus 0.5 px read) '
                             '+ S/n_risk (one event step, covers 1-column drop-time offset); risk counts exact')
    if os.path.exists(f'{OUT}/sensitivity.csv'):
        sen, dfs = check_file(f'{OUT}/sensitivity.csv')
        tau = 33.0   # common supported horizon: both curves displayed through >=33.38 months
        cmp = {}
        for arm in 'AB':
            sp, ss = km(dfp[dfp.group == arm]), km(dfs[dfs.group == arm])
            cmp[arm] = dict(tau=tau, S_tau_primary=round(S_at(sp, tau), 4), S_tau_sens=round(S_at(ss, tau), 4),
                            RMST_primary=round(rmst(sp, tau), 3), RMST_sens=round(rmst(ss, tau), 3),
                            S_12_primary=round(S_at(sp, 12), 4), S_12_sens=round(S_at(ss, 12), 4),
                            S_24_primary=round(S_at(sp, 24), 4), S_24_sens=round(S_at(ss, 24), 4))
        out['sensitivity'] = dict(sha256=sen['sha256'],
                                  risk_table_all_pass=all(r['status'] == 'pass' for a in 'AB' for r in sen['arms'][a]['risk_table']),
                                  comparison=cmp)
    json.dump(out, open(f'{OUT}/checks.json', 'w'), indent=1)
    # overlay plot
    fig, ax = plt.subplots(figsize=(8, 5))
    for arm, col in zip('AB', ['tab:blue', 'tab:orange']):
        c = meas[arm]['curve']
        ax.plot([p['t'] for p in c], [p['S'] for p in c], '.', ms=2, color=col, label=f'{arm} measured')
        st = km(dfp[dfp.group == arm]); ax.step([0] + [s[0] for s in st], [1] + [s[1] for s in st], where='post', color='k', lw=0.7)
    ax.legend(); fig.savefig(f'{OUT}/overlay.png', dpi=120)
    for arm in 'AB':
        a = prim['arms'][arm]
        print(arm, a['n'], a['events'], 'maxabs', a['all_column_residual'],
              'fails', [c for c in a['curve_comparisons'] if c['status'] != 'pass'],
              'risk', [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table']])
    print(prim['sha256']); print(json.dumps(out.get('sensitivity', {}), indent=0))
