"""Reconstruct IPD from measured KM curves + risk table (own implementation, Guyot-style
interval allocation with tick-guided censoring). Usage: python reconstruct.py [figure.png] [outdir] [variant]
variant 'primary' (default) or 'sensitivity'."""
import sys, os, json, hashlib, subprocess, numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
VARIANT = sys.argv[3] if len(sys.argv) > 3 else 'primary'
SEED = 790512406
np.random.seed(SEED)   # no stochastic step is used; seed recorded per manifest

sys.path.insert(0, HERE)
import extract
meas = {arm: extract.measure(arm) for arm in 'AB'}
N = {'A': 100, 'B': 100}                                  # manifest
RT_T = [0, 6, 12, 18, 24, 30, 36]                         # risk-table times (months), read from figure
RT = {'A': [100, 65, 42, 25, 18, 9, 0], 'B': [100, 66, 53, 42, 36, 12, 0]}
TMIN = 0.5 / extract.XPM                                  # half-pixel: earliest resolvable time

def drops_of(m):
    c = m['curve']; out = []
    prev = 1.0
    for p in c:
        if p['S'] < prev - 1e-9:
            out.append((max(p['t'], TMIN), p['S']))
        prev = min(prev, p['S'])
    return out   # (time, measured S after)

def place_censors(ticks, c, lo, hi, variant):
    tt = []
    for k in ticks:
        if lo <= k['time'] < hi:
            tt += [k['time']] * k['count_est']
    tt = sorted(tt); m = len(tt)
    if c <= m:
        idx = np.unique(np.round(np.linspace(0, m - 1, c)).astype(int)) if c > 0 else []
        sel = [tt[i] for i in idx]
        j = 0
        while len(sel) < c:   # duplicates from rounding
            sel.append(tt[j]); j += 1
        return sorted(sel)
    extra = c - m
    if variant == 'sensitivity' and m > 0:
        # alternative: unseen censorings hidden as multiplicity at visible tick positions
        add = [tt[i % m] for i in range(extra)]
    else:
        # primary: unseen censorings spread uniformly over the interval (Guyot-type)
        add = list(lo + (np.arange(extra) + 0.5) * (hi - lo) / extra)
    return sorted(tt + add)

def simulate(drops, cens, n0, S0, lo, hi):
    """Events within [lo,hi) given censor times; returns event list, n at hi, S at hi."""
    n, S = n0, S0; ev = []; ci = 0; cens = sorted(cens)
    for t, Sm in drops:
        if not (lo <= t < hi): continue
        while ci < len(cens) and cens[ci] < t:   # censor strictly before; ties: events first
            n -= 1; ci += 1
        if n <= 0 or S <= 0: break
        d = int(round(n * (1 - Sm / S)))
        d = max(0, min(d, n))
        if d:
            ev += [t] * d; S *= (1 - d / n); n -= d
    n -= len(cens) - ci
    return ev, n, S

def reconstruct(arm, variant):
    m = meas[arm]; drops = drops_of(m); recs = []; n, S = N[arm], 1.0; log = []
    for i in range(len(RT_T) - 1):
        lo, hi = RT_T[i], RT_T[i + 1]
        hi_eff = min(hi, m['t_end'] + 1e-6)
        target = RT[arm][i + 1]
        best = None
        for c in range(0, n + 1):
            cens = place_censors(m['ticks'], c, lo, hi_eff, variant)
            ev, n_end, S_end = simulate(drops, cens, n, S, lo, hi)
            if n_end < 0: continue
            key = (abs(n_end - target), abs(c - sum(k['count_est'] for k in m['ticks'] if lo <= k['time'] < hi_eff)))
            if best is None or key < best[0]:
                best = (key, c, cens, ev, n_end, S_end)
        _, c, cens, ev, n_end, S_end = best
        nt = sum(k['count_est'] for k in m['ticks'] if lo <= k['time'] < hi_eff)
        log.append(dict(interval=[lo, hi], n_start=n, events=len(ev), censored=c, visible_ticks=nt,
                        n_end=n_end, risk_table_end=target))
        recs += [(arm, t, 1) for t in ev] + [(arm, t, 0) for t in cens]
        n, S = n_end, S_end
    assert len(recs) == N[arm], (arm, len(recs))
    return recs, log

def km(df):
    times = np.sort(df.observed_time.unique()); S = 1.0; out = []
    for t in times:
        n = (df.observed_time >= t).sum(); d = ((df.observed_time == t) & (df.event == 1)).sum()
        if d: S *= 1 - d / n
        out.append((t, S))
    return out

def S_at(step, t):
    s = 1.0
    for tt, v in step:
        if tt <= t: s = v
        else: break
    return s

def write_atomic(df, path):
    tmp = path + '.tmp'
    df.to_csv(tmp, index=False, float_format='%.4f')
    os.replace(tmp, path)

if __name__ == '__main__':
    allrec, logs = [], {}
    for arm in 'AB':
        r, lg = reconstruct(arm, VARIANT); allrec += r; logs[arm] = lg
        for l in lg: print(arm, l)
    df = pd.DataFrame(allrec, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    df['observed_time'] = df.observed_time.round(4)
    path = f'{OUT}/ipd.csv' if VARIANT == 'primary' else f'{OUT}/sensitivity.csv'
    write_atomic(df, path)
    json.dump(logs, open(f'{OUT}/allocation_log_{VARIANT}.json', 'w'), indent=1)
    print('wrote', path, len(df))
