"""Reload committed CSVs, recompute right-continuous KM, compare to measured curve and risk table."""
import json, hashlib, os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
from recon import km, km_at, RT, RISK, N
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
TOL = 0.006   # ~ line width (4 px = 0.0053) + 0.5 px reading error; level read from 4-5 px band centre
meas = json.load(open(os.path.join(OUT, 'measured_steps.json')))
p = os.path.join(OUT, 'ipd.csv'); raw = open(p, 'rb').read()
df = pd.read_csv(p)
chk = {'csv': 'output/ipd.csv', 'sha256': hashlib.sha256(raw).hexdigest(), 'tolerance_S': TOL,
       'tolerance_note': 'Measured S from centre of 4-5 px anti-aliased line band; 1 px = 0.00133 S; tol = line width + 0.5 px',
       'arms': {}}
ok_all = True
for g in 'AB':
    d = df[df.group == g]; st = km(d)
    a = {'n': int(len(d)), 'n_expected': N[g], 'n_pass': bool(len(d) == N[g]),
         'event_values_integer_01': bool(set(d.event.unique()) <= {0, 1}),
         'times_finite_nonneg': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
         'events_total': int(d.event.sum()), 'supplied_event_total': 'unavailable (not in manifest)'}
    lv = meas[g]['levels']; end_t = meas[g]['end_time']; curve = []
    for i, l in enumerate(lv):
        t1 = lv[i + 1]['t'] if i + 1 < len(lv) else end_t
        if t1 - l['t'] < 0.1: continue   # plateau too short to be read reliably
        tm = (l['t'] + t1) / 2; r = km_at(st, tm)
        res = r - l['S']; occl = l.get('npure', 1) == 0   # no unobstructed horizontal pixel column for this level
        stt = 'pass' if abs(res) <= TOL else ('unresolved_occluded_level' if occl else 'fail')
        curve.append(dict(t=round(tm, 3), measured=round(l['S'], 4), recon=round(r, 4), resid=round(res, 4),
                          clean_level_columns=l.get('npure'), status=stt))
    a['curve_checks'] = curve
    a['curve_max_abs_resid'] = max(abs(c['resid']) for c in curve)
    a['tail_check'] = dict(t=round(end_t, 3), measured=curve[-1]['measured'], recon=round(km_at(st, end_t), 4),
                           last_record_time=float(d.observed_time.max()), drawn_curve_end=round(end_t, 4))
    rk = []
    for t, n in zip(RT, RISK[g]):
        r = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, table=n, recon=r, resid=r - n, status='pass' if r == n else 'fail'))
    a['risk_checks'] = rk
    ok_all &= a['n_pass'] and all(c['status'] != 'fail' for c in curve + rk)
    chk['arms'][g] = a
chk['overall'] = ('pass_with_unresolved' if any(c['status'].startswith('unres') for g in 'AB' for c in chk['arms'][g]['curve_checks']) else 'pass') if ok_all else 'fail'
# sensitivity comparison (if present) at common supported horizon = min drawn curve end
sp = os.path.join(OUT, 'sensitivity.csv')
if os.path.exists(sp):
    H = round(min(meas[g]['end_time'] for g in 'AB'), 3); s2 = pd.read_csv(sp); comp = {'horizon_months': H}
    def rmst(st, H):
        ts = [0] + [u for u, _ in st if u < H] + [H]; ss = [1] + [s for u, s in st if u < H]
        return float(sum((ts[i + 1] - ts[i]) * ss[i] for i in range(len(ss))))
    for g in 'AB':
        k1 = km(df[df.group == g]); k2 = km(s2[s2.group == g])
        comp[g] = dict(S_primary=round(km_at(k1, H), 4), S_sens=round(km_at(k2, H), 4),
                       RMST_primary=round(rmst(k1, H), 3), RMST_sens=round(rmst(k2, H), 3),
                       S_at_6_12_18_24_30_primary=[round(km_at(k1, t), 4) for t in (6, 12, 18, 24, 30)],
                       S_at_6_12_18_24_30_sens=[round(km_at(k2, t), 4) for t in (6, 12, 18, 24, 30)],
                       events_primary=int(df[df.group == g].event.sum()), events_sens=int(s2[s2.group == g].event.sum()))
    chk['sensitivity_comparison'] = comp
json.dump(chk, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
print(json.dumps({g: dict(n=chk['arms'][g]['n'], ev=chk['arms'][g]['events_total'], maxres=chk['arms'][g]['curve_max_abs_resid'],
      fails=[c for c in chk['arms'][g]['curve_checks'] + chk['arms'][g]['risk_checks'] if c['status'] != 'pass'],
      tail=chk['arms'][g]['tail_check']) for g in 'AB'}, indent=1))
print(chk['overall'], chk['sha256']); print(json.dumps(chk.get('sensitivity_comparison'), indent=0))
