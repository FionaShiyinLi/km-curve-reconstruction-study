"""KM-figure -> approximate IPD reconstruction (own implementation, Guyot-style logic).
Run from the work directory:  python3 output/code/extract.py [path/to/figure.png]; python3 output/code/recon.py
Inputs: output/measured_steps.json (from extract.py), risk table transcribed below from the figure."""
import json, os, sys, hashlib
import numpy as np, pandas as pd

SEED = 790512406
np.random.seed(SEED)  # recorded; algorithm below is deterministic
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
MODE = sys.argv[2] if len(sys.argv) > 2 else 'uniform'   # 'uniform' (primary) or 'late' (sensitivity)
N = {'A': 100, 'B': 100}
RT = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 65, 42, 25, 18, 9, 0], 'B': [100, 66, 53, 42, 36, 12, 0]}
meas = json.load(open(os.path.join(OUT, 'measured_steps.json')))

def drops_of(g):
    lv = meas[g]['levels']
    d = [(l['t'], l['S']) for l in lv[1:]]
    # first visible drop column is partly under the y-axis/other arm: place at vertical-segment centre
    if d and d[0][0] < 0.075: d[0] = (0.075, d[0][1])
    return d

def ctimes(c, lo, hi, mode, last_at_hi):
    if c == 0: return []
    if mode == 'late':
        return [hi - 1e-3 * (i + 1) if not last_at_hi else hi for i in range(c)]
    if last_at_hi:  # final interval: spread over (lo, hi], last censor at end of drawn curve
        return list(lo + (hi - lo) * (np.arange(c) + 1) / c)
    return list(lo + (hi - lo) * (np.arange(c) + 0.5) / c)

def simulate(drops, n0, Srec, c, lo, hi, mode, last):
    ct = sorted(ctimes(c, lo, hi, mode, last))
    n = n0; ev = []; ci = 0; S = Srec
    for t, St in drops:
        while ci < len(ct) and ct[ci] < t: n -= 1; ci += 1
        if n <= 0: break
        d = int(np.clip(round(n * (1 - St / S)), 0, n))
        if d: ev.append((t, d)); S *= 1 - d / n; n -= d
    n -= len(ct) - ci
    sse = 0.0; S2 = Srec; nn = n0; ci = 0; ed = dict(ev)
    for t, St in drops:
        while ci < len(ct) and ct[ci] < t: nn -= 1; ci += 1
        d = ed.get(t, 0)
        if d: S2 *= 1 - d / nn; nn -= d
        sse += (S2 - St) ** 2
    return n, ev, ct, S, sse

def reconstruct(g, mode):
    drops = drops_of(g); end_t = meas[g]['end_time']
    recs = []; S = 1.0; log = []
    for k in range(6):
        lo, hi = RT[k], RT[k + 1]; last = (k == 5)
        if last: hi = end_t
        dk = [x for x in drops if lo <= x[0] < hi] if not last else [x for x in drops if x[0] >= lo]
        n0 = RISK[g][k]; target = RISK[g][k + 1]
        best = None
        for c in range(0, n0 + 1):
            nend, ev, ct, S1, sse = simulate(dk, n0, S, c, lo, hi, mode, last)
            key = (abs(nend - target), sse)
            if best is None or key < best[0]: best = (key, c, nend, ev, ct, S1)
        (_, sse), c, nend, ev, ct, S1 = best
        for t, d in ev: recs += [(g, round(t, 4), 1)] * d
        recs += [(g, round(t, 4), 0) for t in ct]
        log.append(dict(interval=[lo, RT[k + 1]], n_start=n0, n_next_table=target, n_next_recon=nend,
                        events=int(sum(d for _, d in ev)), censored=c, km_sse=sse))
        S = S1
    assert len(recs) == N[g], (g, len(recs))
    return recs, log

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S))
    return out
def km_at(steps, x):
    S = 1.0
    for u, s in steps:
        if u <= x: S = s
        else: break
    return S

if __name__ == '__main__':
    fname = 'ipd.csv' if MODE == 'uniform' else 'sensitivity.csv'
    allrecs = []; logs = {}
    for g in 'AB':
        r, lg = reconstruct(g, MODE); allrecs += r; logs[g] = lg
    df = pd.DataFrame(allrecs, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = os.path.join(OUT, fname + '.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, fname))
    json.dump(logs, open(os.path.join(OUT, 'interval_log_%s.json' % MODE), 'w'), indent=1)
    print(json.dumps(logs, indent=0))
