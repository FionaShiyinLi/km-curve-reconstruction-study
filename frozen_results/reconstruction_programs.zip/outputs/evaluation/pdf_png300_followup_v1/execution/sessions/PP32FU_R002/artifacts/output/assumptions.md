# Reconstruction assumptions and method

**Inputs used:** `../input/figure.png` (raster, 1800×1350) and `../input/manifest.json` (n = 100 per arm, months, seed 790512406). The manifest gives no arm-specific event totals, so that check is marked unavailable. Nothing else was used.

**Reproduce (from the work directory):**
1. `python3 output/code/extract.py [../input/figure.png]`
2. `python3 output/code/recon.py output uniform` (primary, produces `ipd.csv`)
3. `python3 output/code/recon.py output late` (sensitivity, produces `sensitivity.csv`)
4. `python3 output/code/checks.py output`

The seed is set in `recon.py`. The algorithm itself is deterministic.

## Measurement
- **Calibration.** Both axes were calibrated from the tick-mark pixel centers. On the x-axis, 0 to 36 months maps to columns 269.5 to 1709.5 (40 px/month). On the y-axis, S = 1.0 to 0.0 maps to rows 179.5 to 929.5 (750 px/unit). No global rescaling or running-minimum correction was applied.
- **Curve extraction.** Curves were separated by exact line color (blue = A, orange = B). For each column, the colored vertical run was recorded (`column_runs.json`).
- **Levels.** A step level is the center of the 4–5 px horizontal line band, i.e. the median over unobstructed columns. When no clean column exists, the level is the band top + 2 px.
- **Drop times.** Each drop time is the center of its 4-px-wide vertical segment. The measured levels and times are in `measured_steps.json`.
- **Start of arm A.** The orange line hides arm A at the start. I zoomed in on this region and inspected it directly (`zoom1.png`). Arm A starts at 1.0 underneath orange. It then drops to 0.99 at about 0.075 mo, to 0.98 at about 0.125 mo (partly hidden), and to 0.97 at about 0.225–0.25 mo. A spurious occluded level (0.994) was left in the measured file rather than overwritten. The reconstruction steps to the true 0.99/0.98/0.97 levels.
- **Arm crossing.** The arms cross near 6.1–6.3 mo, where B's horizontal line hides part of A's vertical segment. A's two drops there were taken from the visible segment ends.
- **Censor marks.** The figure has no visible censor marks, so the plot gives no information on censoring times.

## Reconstruction algorithm (own implementation, Guyot-style)
- **Risk table.** Transcribed from the figure at 0, 6, …, 36 mo:
  - A: 100, 65, 42, 25, 18, 9, 0
  - B: 100, 66, 53, 42, 36, 12, 0
- **Censoring count per interval.** For each interval [T_k, T_k+1), every censoring count c = 0…n_k is tried. The c chosen gives a reconstructed count at T_k+1 matching the table; ties are broken by squared error against the measured levels. Every interval in both arms reconciled exactly.
- **Event counts.** Events at each measured drop are d = round(n_risk·(1 − S_target/S_recon)), where S_recon is the running reconstructed KM. Using S_recon makes each step self-correcting, so pixel errors do not accumulate. d is not forced to 1: drops of about 2/n receive 2 events. These are A at 2.925, 3.5, 4.0, 6.15, 12.45 and 19.05 mo, and B at 2.10 mo. Each is a tied pair at the measured column, an assumption where two separate drops could fall within one raster column. At the A/B crossing (6.15–6.25 mo), the total of 3 events is fixed by the levels on either side. Because B hides part of A there, the 2 + 1 split is ambiguous.
- **Censoring placement (primary assumption).** Within an interval, censorings are spaced evenly. In the final interval, they are spread over (30, end of drawn curve], with the last record at the curve end (A 33.41, B 35.61 mo).
  - This is an **assumption**. The figure constrains only the number censored per interval (via the risk table) and the follow-up endpoint (the drawn line's extent). It does not constrain where in the interval censoring occurs.
  - No record is placed at 36: the displayed risk of 0 at 36 is respected.
- **Ties and counting convention.** Events take priority over censorings at tied times. Risk checks count records with time ≥ t.

## Results and checks (`checks.json`)
- **Records.** 100 records per arm. A has 75 events and B has 59. These totals are reconstruction outputs, not supplied values.
- **Risk table.** All 14 risk-table counts match exactly.
- **KM agreement.** The KM recomputed from the reloaded CSV (right-continuous step) was compared at the midpoint of every plateau at least 0.1 mo long. A: 55 comparisons; B: 44. Tolerance is 0.006 S (the 4 px line width plus 0.5 px reading error).
  - All comparisons pass except one: A at t = 0.06. There the measured value is the occluded spurious level, marked `unresolved_occluded_level` (residual 0.006).
  - Tail at the curve end: A measured 0.168 vs reconstructed 0.171; B measured 0.301 vs reconstructed 0.300.

## Sensitivity (one alternative, `sensitivity.csv`)
- **Alternative assumption.** All censorings in each interval are placed just before the next risk-table time (the final interval is unchanged at the curve end).
- **Comparison.** Made at the common supported horizon, 33.41 mo (end of A's drawn curve):

| Arm | S primary | S sensitivity | RMST primary (mo) | RMST sensitivity (mo) | Events primary | Events sensitivity |
|---|---|---|---|---|---|---|
| A | 0.171 | 0.173 | 13.86 | 13.93 | 75 | 76 |
| B | 0.300 | 0.290 | 18.06 | 17.98 | 59 | 62 |

This is one alternative. It is not a confidence interval and not a bound on reconstruction error.

## Limitations
- **Censoring times are not identified.** Only the per-interval counts and the follow-up endpoint come from the figure. The individual censoring times are an allocation assumption.
- **Event counts depend on that allocation.** Because n_risk at each drop depends on where censoring falls, event counts can shift by about ±1–3 per arm (see the sensitivity analysis).
- **Close or tied events.** Events closer together than about 4 px (0.1 mo) cannot be separated in time. They are assigned to the measured drop columns, and drop multiplicity comes from the drop size.
- **Time resolution.** Event times are quantized to the pixel grid (0.025 mo).
- **Occluded segments.** Small parts of A (the start and the crossing near 6 mo) are hidden by B and were read as described above.
