"""Pixel extraction of KM step curves from ../input/figure.png (path overridable by argv[1])."""
import sys, json
import numpy as np
from PIL import Image
inp = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
a = np.asarray(Image.open(inp).convert('RGB')).astype(float)
# axis calibration from tick-mark pixel centres (measured: x ticks at cols 269.5+240k, y ticks at rows 179.5+150k)
X0, XPM = 269.5, 40.0        # col of t=0, px per month (0..36 at 269.5..1709.5)
Y1, YPU = 179.5, 750.0       # row of S=1, px per unit S (1.0..0.0 at 179.5..929.5)
cols = {'A': np.array([31, 119, 180.]), 'B': np.array([255, 127, 14.])}
def mask(c, tol=60):
    return np.sqrt(((a - c) ** 2).sum(2)) < tol
out = {}
for g, c in cols.items():
    m = mask(c)
    m[:150] = False; m[935:] = False  # exclude legend and below axis
    rows = []
    for x in range(260, 1720):
        ys = np.where(m[:, x])[0]
        if len(ys):
            rows.append((x, int(ys.min()), int(ys.max()), len(ys)))
    out[g] = rows
json.dump(out, open('output/column_runs.json', 'w'))

# ---- derive step levels and drop times from column runs ----
def steps(runs, start_level_row=Y1):
    runs = [r for r in runs if r[0] >= 271]
    x = np.array([r[0] for r in runs]); top = np.array([r[1] for r in runs])
    bot = np.array([r[2] for r in runs]); cnt = np.array([r[3] for r in runs])
    # group consecutive columns by identical top row -> one level each
    segs = []
    i = 0
    while i < len(x):
        j = i
        while j + 1 < len(x) and top[j + 1] == top[i] and x[j + 1] == x[j] + 1:
            j += 1
        pure = [(top[k] + bot[k]) / 2 for k in range(i, j + 1) if cnt[k] <= 5 and bot[k] - top[k] <= 4]
        lvl_row = float(np.median(pure)) if pure else top[i] + 2.0
        segs.append(dict(x0=int(x[i]), x1=int(x[j]), top=int(top[i]), row=lvl_row, npure=len(pure)))
        i = j + 1
    # drops: transition between successive segments; drop column = first col of new seg - 2.5
    levels = [dict(t=0.0, row=start_level_row, S=1.0)]
    out_segs = []
    for s in segs:
        S = 1 - (s['row'] - Y1) / YPU
        if S > levels[-1]['S'] + 1e-9 - 0.002:
            # not lower than previous (occlusion artefact or same level) -> merge
            continue
        t = (s['x0'] - 2.5 - X0) / XPM
        levels.append(dict(t=max(t, 0.0), row=s['row'], S=S, npure=s['npure'], x0=s['x0'], x1=s['x1']))
    end_t = (runs[-1][0] - X0) / XPM
    return levels, end_t, segs

if __name__ == '__main__':
    res = {}
    for g in 'AB':
        lv, et, segs = steps(out[g])
        res[g] = dict(levels=lv, end_time=et)
        print(g, 'end', et, 'nlevels', len(lv))
        for l in lv: print('  %.3f  S=%.4f  npure=%s' % (l['t'], l['S'], l.get('npure')))
    json.dump(res, open('output/measured_steps.json', 'w'), indent=1)
