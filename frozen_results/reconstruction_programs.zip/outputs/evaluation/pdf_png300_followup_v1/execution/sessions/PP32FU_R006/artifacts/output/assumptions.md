# Reconstruction assumptions (groups A and B)

**Inputs used:** `input/figure.png` (600x450 raster) and `input/manifest.json` (n = 1000 per arm, time unit months, seed 754076957). No event totals, hazard ratio (HR) or restricted mean survival time (RMST) were supplied or used. The seed is recorded but not used, because the algorithm is deterministic.

**Code:** `output/code/reconstruct.py` (run `python3 reconstruct.py [--input DIR] [--out DIR]`; by default it uses paths relative to the script). `probe.py` was the pixel probe used to locate the axes. Both were written for this task. No KM-to-IPD package was used.

## Measurement
- **Calibration** comes from the labelled tick marks: x ticks at pixel columns 90, 170, …, 570 for 0, 6, …, 36 months (13.33 px/month), and y ticks at rows 60…310 for 1.0…0.0 (250 px per unit S). No global rescaling was applied to either arm.
- **Curve reading:** each arm is read by color (A blue, B orange) in every pixel column. The value is an antialiasing-weighted row centroid inside a window around the column median, so symmetric censor ticks don't bias it.
- **Monotonicity:** the per-column readings were made non-increasing with pool-adjacent-violators isotonic regression, not a running minimum.
- **Overlap:** orange is drawn over blue near t = 0. Where the top of the blue line is hidden by orange, blue is read from its bottom edge minus half the line width.
- **Origin:** both curves start at S ≈ 1.0 at column 89/90. Both drop by about 3–4 px (about 0.012–0.016) by t ≈ 0.1 month. The drop shows in the unoccluded orange arm too, so it is kept as a genuine early drop.
- **Measured data:** saved in `output/measured_curve.csv` (raw S, isotonic S, tick flag per column).
- **Resolution:** 1 px is 0.004 in S (about 4 events at n = 1000) and 0.075 months in time. Event times are therefore quantized to pixel-column times, and ties are common.

## Event/censor allocation
- **Method:** a Guyot-style iterative allocation, implemented from scratch, within the risk-table intervals [0,6), [6,12), …, [24,30).
- **Risk table:** risk counts were read from the figure. A: 1000, 667, 463, 312, 198, 78, 0. B: 1000, 758, 564, 419, 323, 129, 0.
- **Censoring count per interval:** iterated until the reconstructed number at risk at the next table time matched the table exactly.
- **Event counts per column:** d = round(n_risk × (1 − S_col / Ŝ_prev)), where Ŝ_prev is the reconstructed KM, so rounding error does not accumulate. Multiple events per column are allowed; d = 1 is not assumed.
- **Censoring times within an interval:** spread according to columns showing a visible censor tick, plus a small uniform floor. A visible tick shows only that at least one censoring occurred there; its multiplicity is not identified.
- **Last interval (30–36 months):** the table gives only n(36) = 0, so this part is an assumption, not data.
  - The plotted curves end at 35.85 months (A) and 35.93 months (B).
  - Censoring before the end of the plot uses the previous interval's censoring rate per person-month, with a floor of one censoring per visible tick column. The tick floor was the binding constraint.
  - Everyone still at risk at the end of the plot is censored at that time: 14 in A, 50 in B. This is consistent with the 0 at 36, since no one is placed at 36.
  - A flat tail does not identify the censoring distribution, so this allocation is not unique.
- **Totals:** reconstructed events are 792 for A and 665 for B. No supplied totals were available to reconcile against.

## Checks (`output/checks.json`)
- The KM is recomputed from the committed CSV as a right-continuous step function.
- Survival was compared at 16 times per arm, from 0.5 to 35.8 months. All residuals are within ±0.008 (2 px, justified by the ~2 px line width plus centroid error). The largest is at the tail: +0.002 for A and +0.0014 for B.
- Every risk-table count matches exactly (counting observed_time ≥ t).
- Arm sizes and 0/1 event indicators pass. Event totals are marked unavailable.

## Sensitivity (`output/sensitivity.csv`)
- **Alternative assumption:** censoring times spread uniformly within each interval, ignoring tick positions, and no tick floor in the last interval.
- **Common horizon:** 35.8 months.
- **Arm A:** S = 0.100 (primary) vs 0.097 (alternative); RMST 14.71 vs 14.70 months; events 792 vs 799.
- **Arm B:** S = 0.247 vs 0.246; RMST 18.58 vs 18.58 months; events 665 vs 668.
- One alternative is not a bound on the reconstruction error.

## Limitations
- Individual event times are known only to about ±0.04 months, and event counts per column to about ±4 events (both from pixel resolution).
- Censoring times within intervals, and the split in the last interval between censoring before the end and censoring at the end, are model assumptions.
- The risk-table values were read visually, and the text is clear.
- Antialiasing and overlap make the first 0.2 months of arm A the least certain region.
