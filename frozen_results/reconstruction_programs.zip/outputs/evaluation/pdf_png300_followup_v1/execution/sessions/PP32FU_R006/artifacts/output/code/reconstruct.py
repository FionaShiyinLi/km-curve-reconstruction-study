"""KM-to-IPD reconstruction for groups A and B (own implementation).
Usage: python3 reconstruct.py [--input ../../../input] [--out ..]
Paths default relative to this file (output/code -> ../../../input)."""
import argparse, json, os, hashlib, tempfile
import numpy as np, pandas as pd
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument('--input', default=os.path.join(HERE, '..', '..', '..', 'input'))
ap.add_argument('--out', default=os.path.join(HERE, '..'))
args = ap.parse_args()
man = json.load(open(os.path.join(args.input, 'manifest.json')))
SEED = man['code_seed']; rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic
NS = man['groups']

# ---------- calibration from labelled axis ticks (found by probe.py) ----------
# x ticks at cols 90,170,...,570 labelled 0,6,...,36 ; y ticks rows 60..310 labelled 1.0..0.0
X0, XPX = 90.0, 80.0 / 6.0          # px per month
Y0, YPX = 310.0, 250.0              # row of S=0, px per unit S
t_of = lambda x: (x - X0) / XPX
s_of = lambda y: (Y0 - y) / YPX
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 667, 463, 312, 198, 78, 0], 'B': [1000, 758, 564, 419, 323, 129, 0]}  # read from figure table

im = np.array(Image.open(os.path.join(args.input, 'figure.png')).convert('RGB')).astype(float)
r, g, b = im[..., 0], im[..., 1], im[..., 2]
# colour membership weights (antialiased), plot region rows 50..312 only (excludes legend)
wB = np.where((b > r + 25), np.clip((255 - r) / (255 - 31), 0, 1), 0.0)
wO = np.where((r > b + 60) & (r > 180), np.clip((255 - b) / (255 - 14), 0, 1), 0.0)
for w in (wB, wO):
    w[:50] = 0; w[313:] = 0; w[:, :90] = 0
W = {'A': wB, 'B': wO}

def measure(w, occl=None):
    rows = []
    for x in range(90, 571):
        col = w[:, x]
        idx = np.where(col > 0.15)[0]
        if len(idx) == 0:
            rows.append((x, np.nan, 0, 0.0)); continue
        med = np.median(idx)
        sel = np.arange(max(0, int(med) - 3), int(med) + 5)
        sel = sel[col[sel] > 0]
        yc = np.sum(sel * col[sel]) / np.sum(col[sel]) + 0.0
        top = idx.min()
        if occl is not None and top > 50 and occl[top - 1, x] > 0.5 and len(idx) <= 3:
            yc = idx.max() - 0.5   # top of line hidden by the other arm: use bottom edge - half width
        # tick score: colored extent beyond a 2px line on BOTH sides of the core
        ext = idx.max() - idx.min() + 1
        up = med - idx.min(); dn = idx.max() - med
        tick = int(ext >= 5 and min(up, dn) >= 2)
        rows.append((x, yc, tick, ext))
    d = pd.DataFrame(rows, columns=['px', 'row_centroid', 'tick', 'extent'])
    d['t'] = t_of(d.px); d['S_raw'] = s_of(d.row_centroid)
    return d

def pava_dec(y):
    # isotonic non-increasing fit (pool adjacent violators), not a running minimum
    y = list(-np.asarray(y)); blocks = []
    for v in y:
        blocks.append([v, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            v2, n2 = blocks.pop(); v1, n1 = blocks.pop()
            blocks.append([(v1 * n1 + v2 * n2) / (n1 + n2), n1 + n2])
    out = []
    for v, n in blocks: out += [-v] * n
    return np.array(out)

def km(times, events):
    o = np.lexsort((1 - events, times)); t = times[o]; e = events[o]
    ut = np.unique(t[e == 1]); S = 1.0; st = []; n = len(t)
    for u in ut:
        nr = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d / nr; st.append((u, S))
    return st
def km_at(st, x):
    s = 1.0
    for u, v in st:
        if u <= x: s = v
        else: break
    return s

def reconstruct(meas, risk, mode):
    d = meas.dropna(subset=['S_raw']).copy()
    S = pava_dec(d.S_raw.values); S = np.minimum(S, 1.0)
    T = d.t.values; tickw = d.tick.values.astype(float)
    tend = T[-1]
    # step times: column times; S at col k = level after events in that column
    recs = []; Shat = 1.0; nrisk = risk[0]; info = []; prev_rate = 0.0
    for i in range(len(RISK_T) - 1):
        lo, hi = RISK_T[i], RISK_T[i + 1]
        n_lo, n_hi = nrisk, risk[i + 1]
        m = ((T >= lo) & (T < hi) & (T <= tend)) if i > 0 else ((T > 0) & (T < hi))
        if hi > tend: m = m | ((T >= lo) & (T <= tend))
        Ti, Si, wi = T[m], S[m], tickw[m]
        if hi > tend: hi_eff = tend
        else: hi_eff = hi
        # censor-time density within interval
        if mode == 'ticks' and wi.sum() > 0: dens = wi + 0.05
        else: dens = np.ones_like(Ti)
        cdf = np.cumsum(dens) / dens.sum()
        def run(nc):
            cts = np.array([Ti[min(np.searchsorted(cdf, (j + 0.5) / nc), len(Ti) - 1)] for j in range(nc)]) if nc > 0 else np.array([])
            n = n_lo; Sh = Shat; ev = []; ce = list(cts)
            for k in range(len(Ti)):
                dk = int(round(n * (1 - Si[k] / Sh))) if Sh > 0 else 0
                dk = max(0, min(dk, n))
                if dk > 0:
                    ev.append((Ti[k], dk)); Sh *= 1 - dk / n; n -= dk
                c_here = int(np.sum(cts == Ti[k]))
                c_here = min(c_here, n); n -= c_here
            return n, ev, cts, Sh
        target = n_hi if hi <= tend else 0
        nc = max(0, int(round(n_lo * (Si[-1] / max(Shat, 1e-9)) - target)))
        if hi > tend:
            # risk table gives only n(36)=0: censoring before end of plot not identified.
            # Assumption: censoring hazard per person-month equals that of the previous interval,
            # floored at the number of visible tick columns; survivors censored at end of curve.
            nmin = int(wi.sum()) if mode == 'ticks' else 0
            nc = nmin
            for it in range(50):
                nleft, ev, cts, Sh = run(nc)
                ptime = sum((tt - lo) * dk for tt, dk in ev) + sum(min(c, tend) - lo for c in cts[:n_lo]) + nleft * (tend - lo)
                nc_new = max(nmin, int(round(prev_rate * ptime)))
                if nc_new == nc: break
                nc = nc_new
            nleft, ev, cts, Sh = run(nc); target = nleft
            info.append({'interval': [lo, round(tend, 3)], 'censor_rate_used': prev_rate, 'n_censored_before_end': int(min(nc, n_lo)), 'n_censored_at_end': int(nleft), 'tick_columns': int(wi.sum())})
        for it in range(200 if hi <= tend else 0):
            nleft, ev, cts, Sh = run(nc)
            if nleft == target: break
            nc_new = max(0, min(n_lo, nc + (nleft - target)))
            if nc_new == nc: break
            nc = nc_new
        # censor list may be truncated by n; rebuild consistent records
        n = n_lo; ncens_used = []
        evd = dict(ev)
        for k in range(len(Ti)):
            dk = evd.get(Ti[k], 0); n -= dk
            c_here = min(int(np.sum(cts == Ti[k])), n); n -= c_here
            ncens_used += [Ti[k]] * c_here
        for tt, dk in ev: recs += [(tt, 1)] * dk
        if hi <= tend:
            ptime = sum((tt - lo) * dk for tt, dk in ev) + sum(c - lo for c in ncens_used) + n * (hi - lo)
            prev_rate = len(ncens_used) / ptime
            info.append({'interval': [lo, hi], 'n_censored': len(ncens_used), 'n_events': int(sum(dk for _, dk in ev)), 'n_end': int(n), 'target': n_hi, 'tick_columns': int(wi.sum())})
        recs += [(c, 0) for c in ncens_used]
        Shat = Sh; nrisk = n
        if hi > tend:
            # anyone left (should be 0) censored at end of plotted follow-up
            recs += [(tend, 0)] * n; nrisk = 0
        else:
            if n != n_hi: print('WARN interval', lo, hi, 'n', n, 'target', n_hi)
    return pd.DataFrame(recs, columns=['observed_time', 'event']), S, d, info

def atomic_write_csv(df, path):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix='.tmp'); os.close(fd)
    df.to_csv(tmp, index=False); os.replace(tmp, path)

out = {}; meas_all = []; INFO = {}
for mode, fname in [('ticks', 'ipd.csv'), ('uniform', 'sensitivity.csv')]:
    parts = []
    for gname in ['A', 'B']:
        meas = measure(W[gname], W['B'] if gname == 'A' else None)
        rec, Siso, dm, info = reconstruct(meas, RISK[gname], mode); INFO[(gname, mode)] = info
        assert len(rec) == NS[gname], (gname, mode, len(rec))
        rec.insert(0, 'group', gname); parts.append(rec)
        if mode == 'ticks':
            dm = dm.assign(group=gname, S_iso=Siso); meas_all.append(dm)
    df = pd.concat(parts).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    df['observed_time'] = df.observed_time.round(4)
    atomic_write_csv(df[['group', 'observed_time', 'event']], os.path.join(args.out, fname))
pd.concat(meas_all).to_csv(os.path.join(args.out, 'measured_curve.csv'), index=False)

# ---------- checks from the committed CSV ----------
ipd = pd.read_csv(os.path.join(args.out, 'ipd.csv'))
sha = hashlib.sha256(open(os.path.join(args.out, 'ipd.csv'), 'rb').read()).hexdigest()
meas = pd.read_csv(os.path.join(args.out, 'measured_curve.csv'))
TOL = 0.008  # 2 px: line is ~2 px thick, antialiasing/centroid error ~0.5-1 px, plus column quantization
chk = {'csv_sha256': sha, 'seed': SEED, 'survival_tolerance': TOL,
       'tolerance_justification': '2 px at 250 px per unit S (line width ~2 px plus antialias/centroid error)',
       'arms': {}}
sens = pd.read_csv(os.path.join(args.out, 'sensitivity.csv'))
H = 35.8
def rmst(st, h):
    a = 0; s = 1; prev = 0
    for u, v in st:
        if u > h: break
        a += s * (u - prev); prev = u; s = v
    return a + s * (h - prev)
for gname in ['A', 'B']:
    sub = ipd[ipd.group == gname]
    st = km(sub.observed_time.values, sub.event.values)
    mg = meas[meas.group == gname]
    surv = []
    for tt in [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.8]:
        k = (mg.t - tt).abs().idxmin(); ms = float(mg.loc[k, 'S_iso']); tt = round(float(mg.loc[k, 't']), 4); rs = km_at(st, tt)
        surv.append({'t': tt, 'measured': round(ms, 4), 'reconstructed': round(rs, 4),
                     'residual': round(rs - ms, 4), 'status': 'pass' if abs(rs - ms) <= TOL else 'fail'})
    risk = []
    for tt, nr in zip(RISK_T, RISK[gname]):
        c = int((sub.observed_time >= tt).sum())
        risk.append({'t': tt, 'displayed': nr, 'reconstructed': c, 'residual': c - nr,
                     'status': 'pass' if c == nr else 'fail'})
    ss = sens[sens.group == gname]; st2 = km(ss.observed_time.values, ss.event.values)
    chk['arms'][gname] = {
        'n_records': int(len(sub)), 'n_expected': NS[gname], 'n_status': 'pass' if len(sub) == NS[gname] else 'fail',
        'event_indicator_integer_01': bool(sub.event.isin([0, 1]).all()),
        'events_total': int(sub.event.sum()), 'supplied_event_total': 'unavailable',
        'max_time': float(sub.observed_time.max()), 'interval_allocation': INFO[(gname, 'ticks')], 'sensitivity_allocation': INFO[(gname, 'uniform')], 'survival': surv, 'risk_table': risk,
        'sensitivity_uniform_censoring': {'horizon': H, 'S_primary': round(km_at(st, H), 4), 'S_alt': round(km_at(st2, H), 4),
            'RMST_primary': round(rmst(st, H), 3), 'RMST_alt': round(rmst(st2, H), 3),
            'events_primary': int(sub.event.sum()), 'events_alt': int(ss.event.sum())}}
chk['common_horizon_months'] = H
json.dump(chk, open(os.path.join(args.out, 'checks.json'), 'w'), indent=1)

# overlay plot for visual review
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(8, 5))
for gname, c in [('A', 'tab:blue'), ('B', 'tab:orange')]:
    mg = meas[meas.group == gname]; ax.plot(mg.t, mg.S_raw, '.', ms=2, color=c, alpha=.4)
    sub = ipd[ipd.group == gname]; st = km(sub.observed_time.values, sub.event.values)
    ax.step([0] + [u for u, _ in st], [1] + [v for _, v in st], where='post', color='k', lw=.7)
ax.set_xlim(0, 36); ax.set_ylim(0, 1.02); fig.savefig(os.path.join(args.out, 'overlay.png'), dpi=120)
print(json.dumps({g: {'events': chk['arms'][g]['events_total'],
      'surv_fail': [s for s in chk['arms'][g]['survival'] if s['status'] != 'pass'],
      'risk': [(r['t'], r['reconstructed'], r['displayed']) for r in chk['arms'][g]['risk_table']],
      'ticks': int(meas[meas.group == g].tick.sum()),
      'sens': chk['arms'][g]['sensitivity_uniform_censoring']} for g in 'AB'}, indent=0))
