import numpy as np
from PIL import Image
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
H,W,_=im.shape
dark=(im.sum(2)<200)
# axis lines: columns/rows with long dark runs
cs=dark.sum(0); rs=dark.sum(1)
print('cols',[(i,cs[i]) for i in np.argsort(cs)[-5:]])
print('rows',[(i,rs[i]) for i in np.argsort(rs)[-5:]])
r,g,b=im[...,0],im[...,1],im[...,2]
blue=(b>r+40)&(b>100); orange=(r>200)&(g>80)&(g<190)&(b<100)
print('blue px',blue.sum(),'orange',orange.sum())
for nm,m in [('blue',blue),('orange',orange)]:
    xs=np.where(m.any(0))[0]; ys=np.where(m.any(1))[0]; print(nm,xs.min(),xs.max(),ys.min(),ys.max())
# x ticks: dark pixels in rows 311-315
print('xticks',np.where(dark[312:315].any(0))[0])
print('yticks',np.where(dark[:,85:89].any(1))[0])
# print curve column profile at a few columns
for x in [90,91,92,93,95,100,170,250,330,410,490,560,566,568,569,570]:
    print(x,'B',np.where(blue[:,x])[0],'O',np.where(orange[:,x])[0])
