# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.jpg` (600×450 JPEG raster) and `../input/manifest.json` (n = 1000 per arm, time unit months, seed 754076957). The manifest gives no arm-specific event totals, so they are marked unavailable. No other information was used.

**Program:** `output/code/reconstruct.py`. It takes optional `--input` and `--output` arguments, which default to paths relative to the script. The algorithm is deterministic; the seed is set and recorded but no random draws are used. Exploratory probe scripts are in `output/work/`. The measured curve per pixel column is in `output/measured_curve.csv`, and `output/overlay.png` is a visual check.

## Measurement
- **Calibration** comes from the labelled tick anchors. The x-axis ticks at 0, 6, …, 36 sit at pixels 90, 170, …, 570 (13.33 px/month). The y-axis ticks at 0.0, …, 1.0 sit at pixel rows 310, …, 60 (1 px = 0.004 survival). The ticks are evenly spaced, so the axes are linear. No global rescaling was applied to either arm.
- **Curve reading.** Each arm's color weight is blue − red for A and red − blue for B. In each column, the arm's survival is the weighted centroid of the main line run. Censor ticks are centered on the line, so they barely shift the centroid. Columns with weak signal (JPEG; summed weight ≤ 0.5) are treated as missing and linearly interpolated.
- **Start of the curves.** Both arms overlap near t = 0, and orange (B) is drawn over blue (A). So for t < 0.5, A columns need strong signal to count as readable. A's first readable reading is S = 0.974 at t = 0.30. It is linearly interpolated from S(0) = 1, which keeps the genuine early drop rather than forcing a flat start. B is readable from t = 0.075.
- **Monotonicity.** A decreasing isotonic (PAV) fit is applied, not a running minimum, so a single misread point is averaged with its neighbors rather than carried forward.
- **Curve ends.** The last readable column is 35.85 months for A and 35.925 for B.

## Event and censoring allocation
- **Risk table** (read from the figure): A 1000/667/463/312/198/78/0 and B 1000/758/564/419/323/129/0 at 0, 6, …, 36 months. All entries were legible.
- **Events.** Within each risk-table interval, events in a pixel column are d = round(n_risk × (1 − S_meas/Ŝ_prev)), where Ŝ is the running reconstructed Kaplan–Meier (KM) estimate. This keeps tracking the measured curve and allows several events per column; d = 1 is not assumed. A column covers 0.075 months, so its events share one tied time. Within a column, events come before censorings.
- **Censoring, intervals before 30 months.** The censoring total for each interval is found by integer search so that the number at risk at the next risk-table time matches the table exactly. **Primary assumption:** censoring times are spread uniformly across the interval's columns. Censor ticks are only partly resolved in the JPEG: they add only 1–2 px to a 3–5 px antialiased line, and tick visibility says nothing about how many participants a tick represents. So ticks are not used in the primary run.
- **Censoring, 30–36 months.** The risk count of 0 at 36 only means every observed time is below 36. It does not say when the survivors were censored, and the flat tail does not identify the censoring distribution. **Assumption:** the censoring hazard estimated in [24, 30) (0.094/person-month for A, 0.106 for B) continues into [30, 36). Events come from the curve, and everyone still at risk at the last plotted time is censored there: 26 participants in A at 35.85 and 58 in B at 35.925. This is a modeling choice, not recovered information.
- **Resulting event counts.** A: 798 events and 202 censored. B: 667 events and 333 censored. These cannot be checked against any supplied totals.

## Checks (`output/checks.json`, computed from the reloaded final CSV)
- **Survival.** I recomputed the right-continuous KM curve at 16 times per arm from 0.5 months to the curve end and compared it with the measured curve. Tolerance is 0.01 (about 2.5 px, given a 3–5 px antialiased JPEG line). All comparisons pass; the largest absolute residual is about 0.001 in each arm.
- **Risk table.** The number at risk was counted as observed_time ≥ t at every table time. All 14 counts match exactly, including 0 at 36.
- **Records.** Both arms have n = 1000, and event indicators are 0/1.

## Sensitivity (one alternative, `output/sensitivity.csv`)
Censoring within each interval is weighted by detected tick excess thickness instead of spread uniformly. The interval totals and the tail rule are the same as in the primary run. Comparison at the common horizon of 35.85 months:

| Arm | S, primary | S, sensitivity | RMST, primary | RMST, sensitivity | Events, primary | Events, sensitivity |
|---|---|---|---|---|---|---|
| A | 0.0954 | 0.0966 | 14.711 | 14.708 | 798 | 794 |
| B | 0.2454 | 0.2469 | 18.592 | 18.591 | 667 | 664 |

RMST is restricted mean survival time (months). This single alternative is not an uncertainty bound.

## Unresolved limitations
- Censoring times within intervals and the tail censoring model are assumptions; the figure and table do not identify them.
- No event totals were supplied, so the event and censoring split within each interval depends on the measured curve. Each pixel is 0.004 survival, which is larger than one event at n = 1000, so single events early in follow-up cannot be resolved.
- The start of arm A (t < 0.3) is interpolated because orange overlaps it.
- Times are quantized to the 0.075-month pixel grid, which creates many ties.
