#!/usr/bin/env python3
"""Reconstruct approximate participant-level records from a KM figure (raster).

Usage: python3 reconstruct.py [--input DIR] [--output DIR]
Defaults: input = <script>/../../../input, output = <script>/..  (i.e. work/output)

Steps
1. Calibrate axes from labelled tick anchors (x: 0..36 months at px 90..570;
   y: 0..1 at px 310..60; ticks every 80 px / 50 px verified by probe).
2. Per pixel column, colour-weighted centroid of each arm's line -> S_meas.
   Columns where the arm is hidden (blue under orange near t=0) are missing
   and linearly interpolated from S(0)=1 to the first valid reading.
   A decreasing isotonic (PAV) fit is applied (not a running minimum).
3. Within each risk-table interval [t_k, t_{k+1}), events per column are
   d_j = round(n_j * (1 - S_meas_j / S_hat_{j-1})) (self-correcting to the
   measured curve, multiple events per column allowed); the interval's total
   censoring count c_k is chosen so n(t_{k+1}) matches the risk table.
   Censoring times within the interval: 'uniform' (primary) or weighted by
   detected censor-tick excess thickness ('ticks', sensitivity).
"""
import argparse, os, json, hashlib
import numpy as np, pandas as pd
from PIL import Image

SEED = 754076957
X0, X36, Y0, Y1 = 90.0, 570.0, 310.0, 60.0
PXM = (X36 - X0) / 36.0
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 667, 463, 312, 198, 78, 0],
        "B": [1000, 758, 564, 419, 323, 129, 0]}   # read from figure risk table

def t_of(x): return (x - X0) / PXM
def s_of(y): return (Y0 - y) / (Y0 - Y1)

def pav_decreasing(y, w):
    # isotonic non-increasing fit
    vals, wts, lens = [], [], []
    for yi, wi in zip(y, w):
        vals.append(yi); wts.append(wi); lens.append(1)
        while len(vals) > 1 and vals[-2] < vals[-1]:
            v = (vals[-2]*wts[-2] + vals[-1]*wts[-1]) / (wts[-2] + wts[-1])
            wts[-2] += wts[-1]; lens[-2] += lens[-1]; vals[-2] = v
            vals.pop(); wts.pop(); lens.pop()
    return np.repeat(vals, lens)

def extract(img_path):
    a = np.asarray(Image.open(img_path).convert("RGB")).astype(float)
    wts = {"A": np.clip((a[..., 2] - a[..., 0]) / 149, 0, 1),   # blue
           "B": np.clip((a[..., 0] - a[..., 2]) / 241, 0, 1)}   # orange
    rows = np.arange(a.shape[0])
    out = {}
    for g, w in wts.items():
        recs = []
        for x in range(91, 570):
            col = w[52:314, x]; r = rows[52:314]
            m = col > 0.3
            if m.sum() == 0:
                recs.append((x, np.nan, 0, 0.0)); continue
            # largest contiguous run of strong pixels (the line, incl. any tick)
            idx = np.where(m)[0]
            runs = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
            run = max(runs, key=lambda q: col[q].sum())
            lo, hi = run[0], run[-1]
            sl = slice(max(lo - 1, 0), hi + 2)
            yc = (col[sl] * r[sl]).sum() / col[sl].sum()
            recs.append((x, yc, len(run), col[run].sum()))
        df = pd.DataFrame(recs, columns=["x", "y", "extent", "mass"])
        df["t"] = t_of(df.x)
        df["S_raw"] = s_of(df.y)
        # tick score: extent beyond local median line thickness
        med = df.extent.where(df.extent > 0).rolling(25, center=True, min_periods=5).median()
        df["tick_excess"] = np.clip(df.extent - med, 0, None).fillna(0)
        # missing (occluded) columns at start: interpolate from S(0)=1
        # weak JPEG columns (mass<=0.5) are unreadable; in the start overlap
        # region (t<0.5) the lower-drawn arm is partly hidden, require mass>0.8
        valid = df.S_raw.notna() & (df.mass > 0.5) & ((df.t >= 0.5) | (df.mass > 0.8))
        df.loc[~valid, "S_raw"] = np.nan
        last_valid = df.index[valid].max()
        s = pd.concat([pd.Series([1.0]), df.S_raw]).reset_index(drop=True)
        tt = pd.concat([pd.Series([0.0]), df.t]).reset_index(drop=True)
        s_i = np.interp(tt, tt[s.notna()], s[s.notna()])
        df["S_interp"] = s_i[1:]
        df["occluded"] = ~valid
        df = df.loc[:last_valid].copy()        # curve ends at last valid column
        iso = pav_decreasing(np.r_[1.0, df.S_interp.values], np.r_[1e6, np.ones(len(df))])
        df["S_meas"] = np.minimum(iso[1:], 1.0)
        out[g] = df
    return out

def alloc_counts(total, weights):
    w = np.asarray(weights, float)
    if total == 0: return np.zeros(len(w), int)
    if w.sum() <= 0: w = np.ones(len(w))
    cum = np.round(np.cumsum(w) / w.sum() * total).astype(int)
    return np.diff(np.r_[0, cum])

def simulate_interval(n0, S0, t, S, cw, c_tot):
    cs = alloc_counts(c_tot, cw)
    n, Sh = n0, S0
    ev, ce = [], []
    for tj, Sj, cj in zip(t, S, cs):
        d = int(round(n * (1 - Sj / Sh))) if Sh > 0 else 0
        d = max(0, min(d, n))
        if n > 0: Sh *= (1 - d / n)
        n -= d
        ev.append(d)
        cj = min(cj, n); n -= cj; ce.append(cj)
    return n, Sh, np.array(ev), np.array(ce)

def last_interval(n, Sh, seg, lam):
    """Final interval [30,36): risk count 0 at 36 only says all times < 36.
    Assumption: censoring hazard lam (per person-month) carried forward from the
    previous interval; events from the curve; remaining at-risk participants
    are censored at the last plotted time (curve end)."""
    ev, ce = [], []; acc = 0.0; dt = 1 / PXM
    for j, (tj, Sj) in enumerate(zip(seg.t.values, seg.S_meas.values)):
        d = max(0, min(int(round(n * (1 - Sj / Sh))), n)) if Sh > 0 else 0
        if n > 0: Sh *= (1 - d / n)
        n -= d; ev.append(d)
        if j == len(seg) - 1:
            cj = n
        else:
            acc += n * lam * dt; cj = min(int(acc), n); acc -= cj
        n -= cj; ce.append(cj)
    return n, Sh, np.array(ev), np.array(ce)

def reconstruct(df, risk, mode):
    recs = []
    n, Sh = risk[0], 1.0
    t_end = float(df.t.max())
    lam = 0.0
    for k in range(len(RISK_T) - 1):
        seg = df[(df.t >= RISK_T[k]) & (df.t < RISK_T[k + 1])]
        if len(seg) == 0: break
        if k == len(RISK_T) - 2:
            ne, Se, ev, ce = last_interval(n, Sh, seg, lam)
            for tj, d, cc in zip(seg.t.values, ev, ce):
                recs += [(round(tj, 4), 1)] * int(d) + [(round(tj, 4), 0)] * int(cc)
            print(f"  [{RISK_T[k]},{RISK_T[k+1]}) n0={n} events={ev.sum()} cens={ce.sum()} "
                  f"(at curve end {ce[-1]}) lam={lam:.4f}")
            n = ne; break
        cw = np.ones(len(seg)) if mode == "uniform" else seg.tick_excess.values + 1e-9
        target = risk[k + 1]
        best = None
        for c in range(0, n + 1):
            ne, Se, ev, ce = simulate_interval(n, Sh, seg.t.values, seg.S_meas.values, cw, c)
            err = abs(ne - target)
            if best is None or err < best[0]: best = (err, c, ne, Se, ev, ce)
            if ne < target: break
        err, c, ne, Se, ev, ce = best
        # censoring hazard in this interval (person-time approx. by column at-risk)
        nr = n - np.cumsum(ev) - np.cumsum(ce)
        lam = ce.sum() / max(1e-9, (np.r_[n, nr[:-1]].sum()) / PXM)
        for tj, d, cc in zip(seg.t.values, ev, ce):
            recs += [(round(tj, 4), 1)] * int(d) + [(round(tj, 4), 0)] * int(cc)
        print(f"  [{RISK_T[k]},{RISK_T[k+1]}) n0={n} events={ev.sum()} cens={ce.sum()} "
              f"n_end={ne} target={target}")
        n, Sh = ne, Se
    assert n == 0 and len(recs) == risk[0], (n, len(recs))
    return recs

def km(times, events):
    o = np.lexsort((-events, times)); t = times[o]; e = events[o]
    ut = np.unique(t[e == 1]); S = []; s = 1.0
    for u in ut:
        nr = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / nr; S.append(s)
    return ut, np.array(S)

def km_at(ut, S, x):
    i = np.searchsorted(ut, x, side="right") - 1
    return 1.0 if i < 0 else float(S[i])

def rmst(ut, S, h):
    pts = np.r_[0, ut[ut <= h], h]; vals = np.r_[1, S[ut <= h]]
    return float(np.sum(np.diff(pts) * vals))

def atomic_csv(df, path):
    tmp = path + ".tmp"
    df.to_csv(tmp, index=False); os.replace(tmp, path)

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
    ap.add_argument("--output", default=os.path.join(here, ".."))
    a = ap.parse_args()
    np.random.seed(SEED)   # recorded; algorithm is deterministic
    man = json.load(open(os.path.join(a.input, "manifest.json")))
    curves = extract(os.path.join(a.input, "figure.jpg"))
    pd.concat([d.assign(group=g) for g, d in curves.items()]).to_csv(
        os.path.join(a.output, "measured_curve.csv"), index=False)
    results = {}
    for mode in ("uniform", "ticks"):
        rows = []
        for g in ("A", "B"):
            print(mode, g)
            recs = reconstruct(curves[g], RISK[g], mode)
            assert len(recs) == man["groups"][g]
            rows += [(g, t, e) for t, e in recs]
        ipd = pd.DataFrame(rows, columns=["group", "observed_time", "event"])
        results[mode] = ipd
        atomic_csv(ipd, os.path.join(a.output, "ipd.csv" if mode == "uniform" else "sensitivity.csv"))
    # ---- checks from the committed CSV ----
    path = os.path.join(a.output, "ipd.csv")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    ipd = pd.read_csv(path); sens = pd.read_csv(os.path.join(a.output, "sensitivity.csv"))
    TOL = 0.01   # ~2.5 px: line ~3-5 px thick after JPEG smearing, centroid jitter ~1 px
    chk = {"csv_sha256": sha, "survival_tolerance": TOL,
           "tolerance_justification": "1 px = 0.004 survival; antialiased JPEG line 3-5 px thick; 2.5 px allowance",
           "supplied_event_totals": "unavailable (not in manifest)", "arms": {}}
    hor = min(curves["A"].t.max(), curves["B"].t.max())
    for g in ("A", "B"):
        d = ipd[ipd.group == g]; df = curves[g]
        ut, S = km(d.observed_time.values, d.event.values)
        ck = {"n": int(len(d)), "n_expected": man["groups"][g],
              "event_values_ok": bool(set(d.event.unique()) <= {0, 1}),
              "events": int(d.event.sum()), "max_time": float(d.observed_time.max()),
              "survival": [], "risk_table": []}
        for tt in [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, float(df.t.max())]:
            row = df.iloc[(df.t - tt).abs().argmin()]
            # measured: column at/just before tt
            sub = df[df.t <= tt + 1e-9]; m = float(sub.S_meas.iloc[-1]) if len(sub) else 1.0
            r = km_at(ut, S, tt)
            ck["survival"].append({"t": round(tt, 3), "measured": round(m, 4), "reconstructed": round(r, 4),
                                   "residual": round(r - m, 4),
                                   "status": "pass" if abs(r - m) <= TOL else "fail"})
        for tt, nr in zip(RISK_T, RISK[g]):
            rc = int((d.observed_time >= tt).sum())
            ck["risk_table"].append({"t": tt, "displayed": nr, "reconstructed": rc,
                                     "residual": rc - nr, "status": "pass" if rc == nr else "fail"})
        ds = sens[sens.group == g]; ut2, S2 = km(ds.observed_time.values, ds.event.values)
        ck["sensitivity_vs_primary"] = {"horizon": round(hor, 3),
            "S_primary": round(km_at(ut, S, hor), 4), "S_sensitivity": round(km_at(ut2, S2, hor), 4),
            "RMST_primary": round(rmst(ut, S, hor), 3), "RMST_sensitivity": round(rmst(ut2, S2, hor), 3),
            "events_primary": int(d.event.sum()), "events_sensitivity": int(ds.event.sum())}
        chk["arms"][g] = ck
    tmp = os.path.join(a.output, "checks.json.tmp")
    json.dump(chk, open(tmp, "w"), indent=1); os.replace(tmp, os.path.join(a.output, "checks.json"))
    # overlay plot for visual inspection
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 5))
    for g, c in (("A", "tab:blue"), ("B", "tab:orange")):
        d = ipd[ipd.group == g]; ut, S = km(d.observed_time.values, d.event.values)
        ax.step(np.r_[0, ut], np.r_[1, S], where="post", color=c, lw=1, label=f"{g} reconstructed")
        ax.plot(curves[g].t, curves[g].S_meas, "k:", lw=0.8)
    ax.legend(); fig.savefig(os.path.join(a.output, "overlay.png"), dpi=110)
    print(json.dumps({g: {k: v for k, v in chk["arms"][g].items() if k in ("events", "sensitivity_vs_primary")} for g in "AB"}, indent=1))
    print("fails:", [(g, c["t"]) for g in "AB" for key in ("survival", "risk_table")
                     for c in chk["arms"][g][key] if c["status"] != "pass"])

if __name__ == "__main__":
    main()
