"""Verify committed IPD against measured curve and risk table.

Usage: python checks.py [ipd.csv] [extracted_dir] [checks.json] [sensitivity.csv]
"""
import sys, os, json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
IPD = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "ipd.csv")
EXT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "extracted")
OUT = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "checks.json")
SENS = sys.argv[4] if len(sys.argv) > 4 else os.path.join(HERE, "..", "sensitivity.csv")
N_EXPECTED = {"A": 100, "B": 100}
TOL_S = 0.006   # ~4.5 px: line half-width (2 px) + antialias/centering (~1 px) + margin
HORIZON = 33.0  # common supported horizon (B curve ends at ~33.1 months)

def km(df):
    """Right-continuous KM: returns event times and S just after each."""
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s, out = 1.0, []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; out.append((u, s))
    return np.array([o[0] for o in out]), np.array([o[1] for o in out])

def S_at(times, surv, x):
    i = np.searchsorted(times, x, side="right") - 1
    return 1.0 if i < 0 else float(surv[i])

def area(times, surv, h):
    grid = np.concatenate([[0], times[times < h], [h]])
    vals = [S_at(times, surv, g) for g in grid[:-1]]
    return float(np.sum(np.diff(grid) * vals))

raw = open(IPD, "rb").read()
sha = hashlib.sha256(raw).hexdigest()
df = pd.read_csv(IPD)
risk = pd.read_csv(os.path.join(HERE, "risk_table.csv"))
res = dict(csv=os.path.basename(IPD), sha256=sha, tolerance_S=TOL_S,
           tolerance_justification="measured line is ~4 px thick (0.0053 S units); "
           "tolerance 0.006 ~ half-width + 1 px antialias + margin; evaluated only at columns "
           "with a clean horizontal-line reading",
           columns_ok=list(df.columns) == ["group", "observed_time", "event"],
           arms={})
fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
for j, g in enumerate(["A", "B"]):
    d = df[df.group == g]
    lev = pd.read_csv(os.path.join(EXT, f"levels_{g}.csv"))
    tt, ss = km(d)
    arm = dict(n=int(len(d)), n_expected=N_EXPECTED[g], n_pass=len(d) == N_EXPECTED[g],
               events=int(d.event.sum()), censored=int((d.event == 0).sum()),
               event_integer_ok=bool(d.event.isin([0, 1]).all()),
               times_ok=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
               max_time=float(d.observed_time.max()),
               supplied_event_total="unavailable (not in manifest)")
    # curve comparison at targets incl. early and tail
    targets = [0.5, 1, 2, 3, 4.5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 31.5, 32.8]
    targets += [34.5] if g == "A" else []
    cc = []
    for x in targets:
        k = (lev.t - x).abs().idxmin()
        tm, sm = float(lev.t[k]), float(lev.S[k])
        if abs(tm - x) > 0.1:
            cc.append(dict(t=x, status="unavailable", reason="no clean level reading within 0.1 mo"))
            continue
        sr = S_at(tt, ss, tm)
        cc.append(dict(t=round(tm, 4), measured=round(sm, 4), reconstructed=round(sr, 4),
                       residual=round(sr - sm, 4), status="pass" if abs(sr - sm) <= TOL_S else "fail"))
    # dense summary over all clean columns
    resid = np.array([S_at(tt, ss, t) - s for t, s in zip(lev.t, lev.S)])
    # exclude columns within 2 px (0.05 mo) of a reconstructed event time (edge ambiguity)
    near = np.array([np.min(np.abs(tt - t)) <= 0.05 for t in lev.t])
    arm["curve_checks"] = cc
    arm["all_clean_columns"] = dict(n=int((~near).sum()), max_abs_resid=round(float(np.abs(resid[~near]).max()), 4),
                                    mean_abs_resid=round(float(np.abs(resid[~near]).mean()), 4),
                                    frac_within_tol=round(float((np.abs(resid[~near]) <= TOL_S).mean()), 4))
    rc = []
    for r in risk.itertuples():
        obs = int(getattr(r, g)); rec = int((d.observed_time >= r.time).sum())
        rc.append(dict(t=r.time, displayed=obs, reconstructed=rec, residual=rec - obs,
                       status="pass" if rec == obs else "fail",
                       convention="count observed_time >= t"))
    arm["risk_checks"] = rc
    arm["tail"] = dict(last_event=float(tt.max()), S_last=round(float(ss[-1]), 4),
                       last_record=float(d.observed_time.max()),
                       last_record_event=int(d.sort_values("observed_time").event.iloc[-1]))
    arm["area_to_horizon"] = dict(horizon=HORIZON, value=round(area(tt, ss, HORIZON), 4))
    res["arms"][g] = arm
    a = ax[j]; a.plot(lev.t, lev.S, ".", ms=1.5, color="grey", label="measured (clean columns)")
    a.step(np.r_[0, tt], np.r_[1, ss], where="post", color="C0" if g == "A" else "C1", label="reconstructed KM")
    a.set_title(f"Group {g}"); a.set_ylim(0, 1.02); a.legend()
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(OUT), "overlay.png"), dpi=110)

if os.path.exists(SENS):
    sd = pd.read_csv(SENS); comp = {}
    for g in ["A", "B"]:
        t1, s1 = km(df[df.group == g]); t2, s2 = km(sd[sd.group == g])
        comp[g] = dict(horizon=HORIZON,
                       S_primary={str(h): round(S_at(t1, s1, h), 4) for h in [6, 12, 18, 24, 30, HORIZON]},
                       S_sensitivity={str(h): round(S_at(t2, s2, h), 4) for h in [6, 12, 18, 24, 30, HORIZON]},
                       area_primary=round(area(t1, s1, HORIZON), 4),
                       area_sensitivity=round(area(t2, s2, HORIZON), 4),
                       events_primary=int(df[df.group == g].event.sum()),
                       events_sensitivity=int(sd[sd.group == g].event.sum()))
    res["sensitivity"] = dict(file=os.path.basename(SENS),
                              sha256=hashlib.sha256(open(SENS, "rb").read()).hexdigest(), comparison=comp)
tmp = OUT + ".tmp"
json.dump(res, open(tmp, "w"), indent=1); os.replace(tmp, OUT)
for g, arm in res["arms"].items():
    print(g, "n", arm["n"], "events", arm["events"], "fails:",
          [c for c in arm["curve_checks"] if c.get("status") != "pass"],
          [c for c in arm["risk_checks"] if c["status"] != "pass"], arm["all_clean_columns"], arm["tail"])
print("sha256", sha)
