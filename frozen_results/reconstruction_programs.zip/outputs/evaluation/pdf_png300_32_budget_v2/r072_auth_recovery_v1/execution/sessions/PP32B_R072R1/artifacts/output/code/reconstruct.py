"""IPD reconstruction from extracted KM drops/ticks + risk table (own implementation).

Usage: python reconstruct.py [extracted_dir] [out_csv] [--extras=uniform|ticks]
Requires extract.py output (drops_<g>.csv, ticks_<g>.csv) and risk_table.csv here.

Per risk-table interval [T_k, T_k+1) with n_k at risk, choose the number censored c_k.
Given c_k, censor times are placed (visible ticks first, with width-based multiplicity;
extra censorings spread uniformly over the interval by default), then each drop is
processed in time order with d = round(n_risk * (1 - S_meas_after / S_recon_before)),
d >= 1 for a visible drop.  c_k is chosen lexicographically by
(|n_end - n_k+1|, SSE of reconstructed vs measured S after each drop, |c_k - ticks|).
No random numbers are used; the manifest seed is recorded for completeness.
"""
import sys, os, json
import numpy as np
import pandas as pd

SEED = 1425780059
np.random.seed(SEED)   # not used for any draw; set for reproducibility policy
HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith("--")]
EXT = args[0] if len(args) > 0 else os.path.join(HERE, "..", "extracted")
OUTCSV = args[1] if len(args) > 1 else os.path.join(HERE, "..", "ipd.csv")
EXTRAS = "uniform"
for a in sys.argv[1:]:
    if a.startswith("--extras="): EXTRAS = a.split("=", 1)[1]
PX = 1 / 40.0  # months per pixel column

risk = pd.read_csv(os.path.join(HERE, "risk_table.csv"))

def censor_times(ticks_in, c, lo, hi):
    """ticks_in: list of (t, mult). Return c censor times."""
    pool = [t for t, m in ticks_in for _ in range(m)]
    if c <= len(pool):
        if c == 0: return []
        idx = np.round(np.linspace(0, len(pool) - 1, c)).astype(int)
        return sorted(pool[i] for i in idx)
    extra = c - len(pool)
    if EXTRAS == "ticks" and pool:
        # assumption: extra censorings hidden as overlapping ticks at visible marks
        add = [pool[i % len(pool)] for i in range(extra)]
    else:
        add = list(lo + (hi - lo) * (np.arange(extra) + 0.5) / extra)
    return sorted(pool + add)

def simulate(drops_in, cens, n0, s0):
    """Return events list [(t,d)], n_end, sse, s_end."""
    n, s, ev, sse = n0, s0, [], 0.0
    ci = 0
    for dr in drops_in:
        while ci < len(cens) and cens[ci] < dr["t_first"]:
            n -= 1; ci += 1
        if n <= 0: break
        if dr["S_after"] <= 0:
            d = n
        else:
            d = int(round(n * (1 - dr["S_after"] / s)))
            d = min(max(d, 1), n)
        ev.append((dr, d))
        s *= (1 - d / n); n -= d
        sse += (s - dr["S_after"]) ** 2
    n -= len(cens) - ci
    return ev, n, sse, s

def event_times(dr, d):
    if dr["located"] or d == 1 or dr["gap"] <= 1:
        return [dr["t"]] * d
    # unresolved staircase: spread d events across the gap columns
    lo, hi = dr["t"] - (dr["gap"] - 1) / 2 * PX, dr["t"] + (dr["gap"] - 1) / 2 * PX
    return list(np.linspace(lo, hi, d))

def reconstruct(g):
    drops = pd.read_csv(os.path.join(EXT, f"drops_{g}.csv")).to_dict("records")
    ticks = pd.read_csv(os.path.join(EXT, f"ticks_{g}.csv"))
    for dr in drops:
        dr["t_first"] = dr["t"] if (dr["located"] or dr["gap"] <= 1) else dr["t"] - (dr["gap"] - 1) / 2 * PX
    T = risk["time"].tolist(); N = risk[g].tolist()
    recs, s, log = [], 1.0, []
    for k in range(len(T) - 1):
        lo, hi = T[k], T[k + 1]
        n0, n1 = N[k], N[k + 1]
        n_start_recon = n0
        d_in = [dr for dr in drops if lo <= dr["t"] < hi]
        t_in = [(r.t, int(r.n_visible_est)) for r in ticks.itertuples() if lo <= r.t < hi]
        nt = sum(m for _, m in t_in)
        best = None
        for c in range(0, n0 + 1):
            cens = censor_times(t_in, c, lo, hi)
            ev, nend, sse, s_end = simulate(d_in, cens, n0, s)
            key = (abs(nend - n1), round(sse, 10), abs(c - nt))
            if best is None or key < best[0]:
                best = (key, c, cens, ev, nend, s_end)
        key, c, cens, ev, nend, s_end = best
        for dr, d in ev:
            for t in event_times(dr, d): recs.append((g, t, 1))
        for t in cens: recs.append((g, t, 0))
        D = sum(d for _, d in ev)
        log.append(dict(interval=[lo, hi], n_start=n0, n_end_table=n1, n_end_recon=nend,
                        events=D, censored=c, visible_ticks=nt, drops=len(d_in)))
        s = s_end
        if nend != n1:
            print(f"[{g}] interval {lo}-{hi}: cannot match risk table ({nend} vs {n1})")
        N[k + 1] = nend  # carry reconstructed count forward
    return recs, log

all_recs, logs = [], {}
for g in ["A", "B"]:
    r, lg = reconstruct(g)
    all_recs += r; logs[g] = lg
    print(g, "n =", len(r), "events =", sum(e for _, _, e in r))
    for l in lg: print("  ", l)
df = pd.DataFrame(all_recs, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0).round(4)
df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
tmp = OUTCSV + ".tmp"
df.to_csv(tmp, index=False)
os.replace(tmp, OUTCSV)
with open(os.path.splitext(OUTCSV)[0] + "_allocation_log.json", "w") as f:
    json.dump(dict(seed=SEED, extras=EXTRAS, intervals=logs), f, indent=1)
print("wrote", OUTCSV)
