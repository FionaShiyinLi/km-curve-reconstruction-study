# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster KM plot, two arms, number-at-risk table).
- `../input/manifest.json`: n = 100 per arm, time in months, seed 1425780059. No arm-specific
  event totals are supplied, so the event totals were not checked against any external total (marked unavailable in `checks.json`).
- Number-at-risk table, read by eye from the figure and stored in `code/risk_table.csv`
  (A: 100, 70, 44, 26, 17, 5, 0; B: 100, 82, 62, 46, 34, 11, 0 at 0, 6, ..., 36 months). The text is
  crisp and I consider these readings certain.

## Measurement (`code/extract.py`)
- Calibration came only from the labelled axis ticks, located in pixels: x = 269.5 px -> 0 and
  1709.5 px -> 36 months (40 px/month); y = 929.5 px -> S = 0 and 179.5 px -> S = 1 (750 px/unit).
  No global rescaling or running-minimum correction was applied.
- Arm A was masked by the exact blue RGB and arm B by the exact orange RGB. Orange is drawn over blue, so for A, orange pixels
  that are contiguous with blue pixels are treated as possibly hiding blue.
- The level at each column is the centre of a short run of 3-6 px, which is the horizontal line. A drop is a level change
  between clean columns. Its time is the centre of the 4 px vertical segment, or the centre of the gap
  when several steps merge into one unresolved staircase (flagged `located=False`).
- Origin: the blue start is hidden under orange at S = 1. I remeasured the local neighbourhood
  from the bottoms of the blue vertical segments. This recovered two genuine early drops (1 -> 0.989 at about 0.05 mo
  and -> 0.980 at about 0.10 mo). Arm B's line starts at exactly S = 1.000.
- Terminal drop: B's vertical line reaches the axis at 33.10 mo, so S falls to 0 and everyone still at risk has an event.
  A's drop at 33.10 is hidden under B's vertical line. It was recovered from the level change across the
  occluded columns (0.129 -> 0.086, ratio 0.665).
- Censor ticks: own-colour pixels extending at least 5 px above and below the local level. The multiplicity of
  merged ticks was estimated from their width (about 3 px per tick). This is only a visibility-based guess: overlapping ticks at the same
  time cannot be counted from pixels. Ticks hidden inside vertical drop segments are not detectable.
- Extracted observations are saved in `extracted/levels_*.csv`, `drops_*.csv` and `ticks_*.csv`.

## Reconstruction (`code/reconstruct.py`, own implementation, deterministic)
- The algorithm processes each risk-table interval in turn and chooses the number censored, c. For a given c, censor times
  go first to the visible ticks. If c exceeds the visible ticks, the extra censorings are spread uniformly over the interval. This is an
  assumption, and the sensitivity analysis varies it.
- Each drop in time order gets d = round(n_risk x (1 - S_measured_after / S_reconstructed_before)), with
  d >= 1 for a visible drop. d is not fixed at 1: multi-event drops (for example A at 0.86 and 16.0 mo) come out
  from the ratio. Censorings tied with an event are counted after the event.
- c is chosen lexicographically: first match the next displayed risk count, then minimise the squared curve error after drops, then stay
  closest to the visible tick count.
- For events in an unresolved staircase, the d events are spread evenly across the gap columns (within about 0.2 mo).
- No random draws are used. The seed is still set and recorded.

## Results and checks (`code/checks.py` -> `checks.json`, `overlay.png`)
- A: 100 records, 84 events, 16 censored. B: 100 records, 65 events, 35 censored.
- Every displayed risk count is reproduced exactly (count of observed_time >= t).
- Right-continuous KM from the reloaded CSV, compared with measured levels over all clean columns more than
  0.05 mo from an event: max |residual| is 0.0015 (A) and 0.0039 (B), against a tolerance of 0.006 (about 4.5 px: line half-width plus antialiasing).
  The 16-month check for A is unavailable because no clean horizontal reading lies within 0.1 mo of that time.
- Censored counts per interval compared with visible ticks: A 6-12 mo needs 3 censorings but shows 2 ticks. B 18-24 needs
  2 against 1 visible, and B 24-30 needs 15 against 13 visible. The extras are unobserved censoring times, placed by assumption.
- Tail: A's last record is a censoring at 34.76 mo (end of line). B ends with 2 events at 33.10 mo. That count depends
  on the multiplicity of the tick cluster at about 31.4 mo, which was read as 3 ticks.

## Sensitivity (single alternative, `sensitivity.csv`)
- Alternative assumption: censorings beyond the visible ticks are placed at the visible tick times (hidden
  overlapping marks) rather than spread uniformly (`reconstruct.py --extras=ticks`). The risk table is still matched exactly and the
  event totals are unchanged.
- Common supported horizon: 33.0 mo (B's curve ends at 33.1 mo). Area under the survival curve to 33 mo:
  A 13.436 (primary) vs 13.415 (alternative); B 19.364 vs 19.315. S(30): A 0.129 vs 0.129; B 0.284 vs 0.278.
  Full values are in `checks.json`. This single alternative is neither a confidence interval nor a bound on
  reconstruction error. It was not used to choose the primary result.

## Reproduction
From `output/code/`: `python extract.py [figure.png] [outdir]`, then `python reconstruct.py`, then
`python checks.py`. The defaults resolve `../../../input/figure.png` relative to the script.

## Unresolved limitations
- Censoring times that no tick shows are not identified by the figure. Tick multiplicity is uncertain in the
  dense B tail (29.7-31.6 mo). Event times within merged staircases are uncertain to about ±0.1 mo.
- The time resolution is 0.025 mo per pixel. Recovered records are one feasible reconstruction, not unique
  recovery, and no quantified error bound is claimed.
