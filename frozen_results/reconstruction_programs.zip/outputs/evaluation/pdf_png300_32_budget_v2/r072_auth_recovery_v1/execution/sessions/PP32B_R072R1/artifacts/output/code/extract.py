"""Pixel extraction of KM step curves and censor ticks from ../input/figure.png.

Usage: python extract.py [path/to/figure.png] [outdir]
Writes levels_<g>.csv (per-column level), drops_<g>.csv, ticks_<g>.csv to outdir.
Calibration from labelled axis ticks (measured in pixels, see assumptions.md):
  x: col 269.5 -> 0 months, col 1709.5 -> 36 months  (40 px / month)
  y: row 929.5 -> S=0,      row 179.5 -> S=1         (750 px / unit)
"""
import sys, os
import numpy as np
import pandas as pd
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "..", "input", "figure.png")
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "extracted")
os.makedirs(OUT, exist_ok=True)

X0, X1, T1 = 269.5, 1709.5, 36.0
Y0, Y1 = 929.5, 179.5
def x2t(x): return (x - X0) / (X1 - X0) * T1
def y2s(y): return (Y0 - y) / (Y0 - Y1)

a = np.asarray(Image.open(FIG).convert("RGB")).astype(int)
def mask(c): return np.abs(a - np.array(c)).sum(2) < 60
BLUE, ORANGE = mask((31, 119, 180)), mask((255, 127, 14))
R0, R1 = 150, 945          # plot rows (exclude legend and risk table)
C0, C1 = 268, 1712

def runs(col):
    r = np.where(col)[0]
    if len(r) == 0: return []
    out, s, p = [], r[0], r[0]
    for v in r[1:]:
        if v != p + 1: out.append((s, p)); s = v
        p = v
    out.append((s, p)); return out

def column_runs(own, occl):
    """Runs of own|occl that contain >=1 own pixel (occluder may hide part of line).
    Returns list of (top,bottom,own_top,own_bottom)."""
    res = {}
    for x in range(C0, C1):
        ext = own[R0:R1, x] | (occl[R0:R1, x] if occl is not None else False)
        lst = []
        for s, e in runs(ext):
            o = np.where(own[R0 + s:R0 + e + 1, x])[0]
            if len(o):
                lst.append((s + R0, e + R0, s + R0 + o[0], s + R0 + o[-1]))
        res[x] = lst
    return res

def extract(name, own, occl):
    cr = column_runs(own, occl)
    # horizontal level where the column shows a short run (line thickness ~4px)
    lev = {}
    for x, lst in cr.items():
        short = [(t + b) / 2 for t, b, _, _ in lst if 2 <= b - t <= 5]
        if len(short) == 1: lev[x] = short[0]
    xs = sorted(lev)
    rows = [dict(x=x, t=x2t(x), row=lev[x], S=y2s(lev[x])) for x in xs]
    pd.DataFrame(rows).to_csv(os.path.join(OUT, f"levels_{name}.csv"), index=False)
    # drops: consecutive known-level columns whose level changes
    drops = []
    for i in range(1, len(xs)):
        xa, xb = xs[i - 1], xs[i]
        la, lb = lev[xa], lev[xb]
        if lb - la > 1.0:
            gap = list(range(xa + 1, xb))
            dcols = []
            for x in gap:
                for t, b, ot, ob in cr[x]:
                    if abs(t - (la - 1.5)) <= 2.5 and abs(b - (lb + 1.5)) <= 2.5:
                        dcols.append(x)
            xc = np.mean(dcols) if dcols else (np.mean(gap) if gap else (xa + xb) / 2)
            drops.append(dict(x=xc, t=x2t(xc), row_before=la, row_after=lb,
                              S_before=y2s(la), S_after=y2s(lb), gap=len(gap),
                              located=bool(dcols)))
        elif lb - la < -1.0:
            print(f"[{name}] warning: level rises at x={xb} ({la}->{lb})")
    # local remeasurement of the origin neighbourhood (line may be occluded by the
    # other arm near S=1): each new bottom row of own pixels before the first clean
    # level marks the lower end of a vertical (drop) segment, 4 px wide.
    x_first, first_row = xs[0], lev[xs[0]]
    prev_row, pre = Y1, []
    for x in range(C0, x_first):
        bots = [ob for t, b, ot, ob in cr[x] if ob <= first_row + 2]
        if not bots: continue
        r = max(bots) - 1.5
        if r > prev_row + 1.0:
            pre.append(dict(x=x + 1.5, t=x2t(x + 1.5), row_before=prev_row, row_after=r,
                            S_before=y2s(prev_row), S_after=y2s(r), gap=0, located=True,
                            note="origin remeasured (occluded)"))
            prev_row = r
    if pre:
        print(f"[{name}] origin drops recovered: {[(round(p['t'],3), round(p['S_after'],4)) for p in pre]}")
        drops = pre + drops
    # terminal drop to the time axis (level 0 merges with black axis line)
    for x in range(xs[-1] + 1, C1):
        if any(b >= Y0 - 5 and t <= lev[xs[-1]] for t, b, _, _ in cr[x]):
            xe = x
            while any(b >= Y0 - 5 for t, b, _, _ in cr.get(xe + 1, [])): xe += 1
            xc = (x + xe) / 2
            drops.append(dict(x=xc, t=x2t(xc), row_before=lev[xs[-1]], row_after=Y0,
                              S_before=y2s(lev[xs[-1]]), S_after=0.0, gap=xe - x + 1,
                              located=True, note="terminal drop to 0"))
            print(f"[{name}] terminal drop to 0 at t={x2t(xc):.3f}")
            break
    pd.DataFrame(drops).to_csv(os.path.join(OUT, f"drops_{name}.csv"), index=False)
    # ticks: own pixels extend >=5px above and below the local level
    xs_arr = np.array(xs)
    tickcols = []
    for x, lst in cr.items():
        if not len(xs_arr): break
        j = np.searchsorted(xs_arr, x)
        cands = [lev[xs_arr[k]] for k in (j - 1, j) if 0 <= k < len(xs_arr)]
        for t, b, ot, ob in lst:
            for L in cands:
                if ot <= L - 5 and ob >= L + 5 and ob - ot <= 22:
                    tickcols.append((x, L)); break
            else:
                continue
            break
    ticks = []
    for x, L in tickcols:
        if ticks and x - ticks[-1]["x_end"] <= 1:
            ticks[-1]["x_end"] = x
        else:
            ticks.append(dict(x_start=x, x_end=x, row=L))
    for tk in ticks:
        tk["width"] = tk["x_end"] - tk["x_start"] + 1
        tk["x"] = (tk["x_start"] + tk["x_end"]) / 2
        tk["t"] = x2t(tk["x"]); tk["S"] = y2s(tk["row"])
        tk["n_visible_est"] = max(1, int(round(tk["width"] / 3)))
    pd.DataFrame(ticks).to_csv(os.path.join(OUT, f"ticks_{name}.csv"), index=False)
    print(f"[{name}] levels={len(xs)} drops={len(drops)} ticks={len(ticks)} "
          f"first level S={y2s(lev[xs[0]]):.4f} at t={x2t(xs[0]):.3f}; last t={x2t(xs[-1]):.3f}")
    return drops, ticks

extract("A", BLUE, ORANGE)   # blue (A) is drawn beneath orange (B)
extract("B", ORANGE, None)
