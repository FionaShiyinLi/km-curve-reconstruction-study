import numpy as np; from PIL import Image
a=np.array(Image.open('../input/figure.png').convert('RGB')).astype(int)
blk=(a.sum(2)<200)
# axis lines
cols=blk.sum(0); rows=blk.sum(1)
print('dense cols',[ (i,cols[i]) for i in np.argsort(cols)[-5:]])
print('dense rows',[ (i,rows[i]) for i in np.argsort(rows)[-5:]])
# y ticks: left of y-axis
x0=np.argmax(cols)
for r in range(150,960):
    if blk[r,x0-8:x0-2].all(): print('ytick row',r)
y0=np.argmax(rows)
for c in range(250,1730):
    if blk[y0+3:y0+8,c].all(): print('xtick col',c)
