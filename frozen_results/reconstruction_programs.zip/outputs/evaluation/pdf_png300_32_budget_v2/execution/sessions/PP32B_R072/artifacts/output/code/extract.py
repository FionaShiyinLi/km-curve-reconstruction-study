"""Measure KM step curves and censor marks from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
a = np.array(Image.open(fig).convert('RGB')).astype(float)
# Axis calibration from labelled tick marks (2-px ticks; centres measured by probe.py)
X0, XPM = 269.5, 40.0           # t=0 at col 269.5, 6 months per 240 px
Y0, YPU = 929.5, 750.0          # S=0 at row 929.5, S=1 at row 179.5
t_of = lambda c: (c - X0) / XPM
s_of = lambda r: (Y0 - r) / YPU
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
PLOT = (slice(170, 935), slice(266, 1715))

def mask_for(rgb):
    c = np.array(rgb, float); w = np.array([255.] * 3)
    # blending fraction toward colour along white->colour segment, plus residual
    d = c - w; v = a - w
    f = (v @ d) / (d @ d)
    res = np.linalg.norm(v - f[..., None] * d, axis=2)
    m = (f > 0.5) & (res < 40)
    mm = np.zeros_like(m); mm[PLOT] = m[PLOT]
    return mm

result = {}
for g, rgb in COL.items():
    m = mask_for(rgb)
    H, W = m.shape
    # horizontal pixels: coloured over a 7-px horizontal window
    hz = np.zeros_like(m)
    for dx in range(-3, 4):
        sh = np.roll(m, dx, axis=1); hz = hz & sh if dx != -3 else sh.copy()
    cols = np.where(m.any(0))[0]
    levels = {}
    for c in range(cols.min(), cols.max() + 1):
        rr = np.where(hz[:, c])[0]
        if len(rr) == 0: continue
        # cluster rows
        grp = np.split(rr, np.where(np.diff(rr) > 1)[0] + 1)
        levels[int(c)] = [float(x.mean()) for x in grp]
    # step segments: runs of columns with a single level of similar row
    segs = []
    for c in sorted(levels):
        for r in levels[c]:
            if segs and abs(segs[-1]['row'] - r) < 1.0 and c - segs[-1]['c1'] <= 2:
                s = segs[-1]; s['c1'] = c; s['rows'].append(r); s['row'] = float(np.mean(s['rows']))
            else:
                # allow matching to an earlier open segment (corner columns)
                hit = [s for s in segs[-3:] if abs(s['row'] - r) < 1.0 and c - s['c1'] <= 2]
                if hit:
                    s = hit[-1]; s['c1'] = c; s['rows'].append(r); s['row'] = float(np.mean(s['rows']))
                else:
                    segs.append({'c0': c, 'c1': c, 'rows': [r], 'row': r})
    segs = [s for s in segs if s['c1'] - s['c0'] >= 1]
    segs.sort(key=lambda s: s['c0'])
    # censor ticks: coloured pixels more than 4 px above the local level
    lev_at = np.full(W, np.nan)
    for s in segs:
        for c in range(s['c0'], s['c1'] + 1):
            lev_at[c] = s['row'] if np.isnan(lev_at[c]) else min(lev_at[c], s['row'])
    above = []
    for c in cols:
        if np.isnan(lev_at[c]): continue
        rr = np.where(m[:, c])[0]
        up = rr[rr < lev_at[c] - 4]
        # restrict to pixels contiguous with the line (within 12 px above)
        up = up[up > lev_at[c] - 14]
        if len(up) >= 4: above.append(int(c))
    ticks = []
    if above:
        for grp in np.split(np.array(above), np.where(np.diff(above) > 1)[0] + 1):
            ticks.append({'c0': int(grp[0]), 'c1': int(grp[-1]), 'width': int(len(grp)),
                          'col': float(grp.mean()), 't': t_of(grp.mean()),
                          'S': s_of(lev_at[int(round(grp.mean()))])})
    result[g] = {
        'segments': [{'t0': t_of(s['c0']), 't1': t_of(s['c1']), 'c0': s['c0'], 'c1': s['c1'],
                      'row': s['row'], 'S': s_of(s['row'])} for s in segs],
        'ticks': ticks,
        'last_col': int(cols.max()), 't_last': t_of(cols.max()),
        'vertical_extent_last_col': [int(np.where(m[:, cols.max()])[0].min()), int(np.where(m[:, cols.max()])[0].max())]}
json.dump(result, open(f'{out}/extracted_curves.json', 'w'), indent=1)
for g in result:
    print(g, 'nseg', len(result[g]['segments']), 'nticks', len(result[g]['ticks']), 'last t', result[g]['t_last'])
    for s in result[g]['segments']:
        print('  seg %6.2f-%6.2f  S=%.4f row=%.1f' % (s['t0'], s['t1'], s['S'], s['row']))
    for k in result[g]['ticks']:
        print('  tick t=%.3f w=%d S=%.4f' % (k['t'], k['width'], k['S']))
