import numpy as np; from PIL import Image
a=np.array(Image.open('../input/figure.png').convert('RGB')).astype(int)
def show(r0,r1,c0,c1,col):
    c=np.array(col); 
    for r in range(r0,r1):
        print(r, ''.join('#' if np.abs(a[r,x]-c).sum()<60 else ('+' if np.abs(a[r,x]-c).sum()<300 else '.') for x in range(c0,c1)))
print('A tick ~24.6'); show(788,812,1238,1270,(31,119,180))
print('B 31.4'); show(706,732,1505,1545,(255,127,14))
print('A start'); show(176,262,266,310,(31,119,180))
