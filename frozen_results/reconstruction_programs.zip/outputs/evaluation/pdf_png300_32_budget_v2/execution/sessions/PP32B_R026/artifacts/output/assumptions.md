# Reconstruction assumptions and limitations

## Inputs
- `../input/figure.png` (1800 x 1350 raster KM plot) and `../input/manifest.json` (n = 100 per arm, months, code seed 1343877745).
- Number-at-risk table, read visually from the figure at 0, 6, ..., 36 months:
  A = 100, 72, 47, 31, 20, 7, 0; B = 100, 65, 56, 46, 41, 16, 0. All digits were clearly legible.
- No arm-specific event totals are supplied, so the event-total check is marked unavailable. That absence was not read as zero events.
- The algorithm is deterministic. The seed is set and recorded but is never used for sampling.

## Algorithm (`code/reconstruct.py`; run from the work directory with `--input ../input`)
1. **Calibration.** Axis tick marks were located in pixels (x: 0 to 36 at 40 px/month; y: 1.0 to 0.0 at 750 px/unit). A linear fit fits all tick anchors exactly. No global rescaling was applied. The first segment of each arm is centered on the 1.0 tick, so no correction of the origin was needed.
2. **Curve measurement.** Arms were separated by color (A blue, B orange). For each pixel column:
   - A "clean" column (vertical extent at most 5 px; the line is 4 px thick) gives the level at the line center.
   - A riser column gives the new level at its bottom edge minus half the line width.
   - A censor tick is identified as an extent of 13 to 20 px, vertically centered (within 2 px) on the adjacent horizontal level. Tick columns carry the level forward.
   - Columns where one arm is hidden by the other also carry the level forward.
   - No running minimum or monotonicity was imposed on clean readings. One riser reading in arm A at about 29.2 months was contaminated by a tick drawn on the riser (it read 0.121). The clean line segment immediately after it reads 0.130, and the level was corrected back to that direct measurement. This correction is logged. Drops within 2 adjacent columns were merged as antialiased edges of one riser. Measurements are saved in `extracted_curve_*.csv`, `extracted_drops_*.csv` and `extracted_ticks_*.csv`.
3. **Allocation (Guyot-type, per risk-table interval).**
   - At each measured drop, d = round(n_risk × (1 − S_meas_after / S_recon_before)). This uses the reconstructed S before the drop and the measured S after it, so rounding errors do not accumulate. It allows d > 1 wherever the drop size implies it; d = 1 was never assumed.
   - The number censored per interval is iterated until the reconstructed number at risk at the next table time equals the table value.
   - Censorings go first at the visible ticks. Each visible tick counts as at least one censoring.
   - If more censorings are needed than there are visible ticks, the extras represent tick multiplicity or ticks hidden under risers or the other arm. They are placed one at a time (greedily) at the visible tick or drop time that best reproduces the measured post-drop levels.
   - If fewer censorings are needed than there are visible ticks, an evenly spaced subset of ticks is used. This did not occur in the final result.
   - At tied times, events precede censorings.
   - The table shows 0 at risk at 36 months, so every record has observed_time < 36. The last censorings sit at the last visible ticks (A 35.13, B 35.44). No follow-up was extrapolated beyond the drawn curve.

## Final allocation (events / censored / visible ticks per interval)
- A: [0,6) 25/3/2; [6,12) 24/1/1; [12,18) 16/0/0; [18,24) 11/0/0; [24,30) 6/7/6; [30,36) 0/7/7. Total 82 events, 18 censored.
- B: [0,6) 31/4/3; [6,12) 8/1/1; [12,18) 10/0/0; [18,24) 3/2/2; [24,30) 6/19/18; [30,36) 2/14/11. Total 60 events, 40 censored.

Every interval required at least as many censorings as ticks were detected, so the tick detection is consistent with the risk table. The excess (at most 3 per interval) is plausibly due to overlapping ticks (for example the clusters at B 28.8, 29.5 and 31.0) or ticks drawn on risers.

## Verification (`code/check.py`, output in `checks.json`)
- The check script reloads the committed CSV and recomputes the right-continuous KM step function. It compares that function with the measured curve at 19 times per arm, from 0.25 to 34.9 months (tail included). Times within 3 px of a measured drop are shifted by 0.1 month.
- Tolerance is 0.015 in S: about 2 px of line-center precision plus one event step at typical risk sets.
- Results:
  - All 38 curve checks pass. The maximum absolute residual is 0.0054 (B at 1.1 months, during a dense early staircase); all others are at most 0.0007.
  - All 14 risk-table checks match exactly, counting observed_time ≥ t.
  - Arm sizes are 100/100, event indicators are integer 0/1, and all times are finite and nonnegative.
- `checks.json` records the SHA-256 of the final `ipd.csv`.
- Primary revisions: one correction cycle after the first committed file, which introduced the greedy placement of extra censorings. Under the earlier even spread, arm A's tail sat at 0.137 against a measured 0.130. Checks were regenerated from the final CSV.

## Sensitivity (`sensitivity.csv`; comparison in `sensitivity_comparison.json`)
- The alternative assumption places extra censorings uniformly within each risk interval (a Guyot-style spread) instead of at ticks or drops.
- It also passes every curve and risk check (`sensitivity_checks.json`). This shows that the checks do not identify a unique allocation.
- At the common supported horizon of 35.0 months (the minimum of the two arms' last observed times):
  - A: S(35) is 0.1296 (primary) vs 0.1379 (sensitivity); area under the curve over 0 to 35 months is 14.855 vs 14.912 months; events 82 vs 81.
  - B: S(35) is 0.3244 vs 0.3260; area 18.935 vs 18.987 months; events 60 vs 60.
- This single alternative is neither a confidence interval nor a bound on reconstruction error.

## Unresolved limitations
- Exact censoring times within intervals are not identified. Ticks that overlap, sit on risers, or are hidden by the other arm cannot be counted, and a tick's visibility says nothing about its multiplicity. The placement of extras is an assumption, constrained only by the risk-table counts and the measured step heights.
- Event times carry about ±1 px (±0.025 month) of error. Closely spaced events in B's early staircase may be merged or split between adjacent columns. This mainly affects exact tie structure, not survival levels.
- The flat tails do not identify the censoring distribution or the accrual period. Censored times in the tails are placed only at the drawn ticks.
