#!/usr/bin/env python3
"""Reconstruct approximate participant-level records from a raster KM figure.

Usage: python reconstruct.py [--input ../input] [--out output] [--extras ticks|uniform]
                             [--csv ipd.csv]

Steps
1. Axis calibration from tick marks (x: 0..36 months, y: 0..1).
2. Per-arm pixel extraction by colour: column-wise bottom edge of the line gives the
   step level; columns whose mask extends >= 5 px above the running level are censor ticks.
3. Interval-wise (risk-table intervals) Guyot-type allocation: events at each measured
   drop d = round(n_risk * (1 - S_meas_after / S_recon_before)); censoring count per
   interval chosen so that the number at risk at the next risk-table time matches;
   censor times placed at visible ticks (extras: see --extras).
No randomness is used; the seed is recorded for completeness.
"""
import argparse, json, os, hashlib
import numpy as np
import pandas as pd
from PIL import Image

SEED = 1343877745
np.random.seed(SEED)

ap = argparse.ArgumentParser()
ap.add_argument('--input', default='../input')
ap.add_argument('--out', default='output')
ap.add_argument('--extras', default='ticks', choices=['ticks', 'uniform'])
ap.add_argument('--csv', default='ipd.csv')
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)

man = json.load(open(os.path.join(args.input, 'manifest.json')))
im = np.array(Image.open(os.path.join(args.input, 'figure.png')).convert('RGB')).astype(int)
H, W, _ = im.shape

# ---------------- 1. calibration from axis ticks ----------------
dark = im.sum(2) < 200
ax_row = int(np.argmax(dark.sum(1)))            # x-axis line row (lower of the 2-px pair)
ax_col = int(np.argmax(dark.sum(0)))            # y-axis line col
# x ticks: dark columns just below the axis line
xt = np.where(dark[ax_row + 5:ax_row + 12].sum(0) >= 5)[0]
xt = xt[xt >= ax_col - 1]
groups = np.split(xt, np.where(np.diff(xt) > 1)[0] + 1)
xtick_px = np.array([g.mean() for g in groups])
xtick_val = np.arange(len(xtick_px)) * 6.0      # labels 0,6,...,36 read from figure
yt = np.where(dark[:, ax_col - 11:ax_col - 3].sum(1) >= 6)[0]
groups = np.split(yt, np.where(np.diff(yt) > 1)[0] + 1)
ytick_px = np.array([g.mean() for g in groups])
ytick_val = 1.0 - np.arange(len(ytick_px)) * 0.2  # labels 1.0..0.0 top to bottom
bx = np.polyfit(xtick_px, xtick_val, 1)
by = np.polyfit(ytick_px, ytick_val, 1)
calib = dict(xtick_px=xtick_px.tolist(), xtick_val=xtick_val.tolist(),
             ytick_px=ytick_px.tolist(), ytick_val=ytick_val.tolist(),
             x_resid=(np.polyval(bx, xtick_px) - xtick_val).tolist(),
             y_resid=(np.polyval(by, ytick_px) - ytick_val).tolist())
px2t = lambda x: float(np.polyval(bx, x))
py2s = lambda y: float(np.polyval(by, y))
t2px = lambda t: (t - bx[1]) / bx[0]
x0 = int(round(xtick_px[0])); x1 = int(round(xtick_px[-1]))
y_top = int(ytick_px[0]) - 12; y_bot = int(ytick_px[-1]) + 5

r, g, b = im[..., 0], im[..., 1], im[..., 2]
masks = {'A': (b - r > 60) & (b > g), 'B': (r - b > 80) & (r > 180)}
HALF = 1.5   # half line width (line is 4 px: rows L-1.5..L+1.5)

# risk table read visually from the figure (times 0,6,...,36)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 72, 47, 31, 20, 7, 0], 'B': [100, 65, 56, 46, 41, 16, 0]}


def extract(m):
    """Return per-column level (px), list of drops (x, level_before, level_after), tick clusters."""
    xs_all = range(x0, x1 + 3)
    top = np.full(W, np.nan); bot = np.full(W, np.nan)
    for x in xs_all:
        ys = np.where(m[y_top:y_bot, x])[0] + y_top
        if len(ys):
            top[x], bot[x] = ys.min(), ys.max()
    ext_ = bot - top
    clean = ext_ <= 5
    cleanlev = np.where(clean, (top + bot) / 2, np.nan)

    def nearest_clean(x, step):
        for k in range(1, 12):
            j = x + step * k
            if x0 <= j <= x1 + 2 and clean[j]:
                return cleanlev[j]
        return np.nan
    # censor tick signature: ~17 px tall, vertically centred on an adjacent horizontal level
    tickcol = np.zeros(W, bool)
    for x in xs_all:
        if np.isfinite(ext_[x]) and 13 <= ext_[x] <= 20:
            c = (top[x] + bot[x]) / 2
            if abs(c - nearest_clean(x, -1)) <= 2 or abs(c - nearest_clean(x, 1)) <= 2:
                tickcol[x] = True
    level = float(ytick_px[0])  # curve starts at S=1 (checked: top segment centred on 1.0 tick)
    lev = np.full(W, np.nan); raw = []; anomalies = []; last_clean = level
    for x in xs_all:
        raw.append((x, top[x], bot[x]))
        if not np.isfinite(top[x]) or tickcol[x]:
            lev[x] = level; continue        # hidden by other arm or tick: carry level
        new = cleanlev[x] if clean[x] else bot[x] - HALF   # riser: bottom edge = new level
        if new > level + 0.75:
            level = new
        elif new < level - 1.0:
            if clean[x] and new >= last_clean - 1.0:
                # riser reading overshot (e.g. tick on riser); clean line segment is the
                # direct measurement -> correct back, never above the previous clean level
                anomalies.append((x, level, new, 'corrected'))
                level = new
                for j in range(x - 1, x - 12, -1):   # revise the overshot columns
                    if lev[j] > new:
                        lev[j] = new
                    else:
                        break
            else:
                anomalies.append((x, level, new, 'ignored'))
        if clean[x]:
            last_clean = level
        lev[x] = level
    print('anomalies (x, level, new):', anomalies[:20], len(anomalies))
    # drops: merge increments in consecutive columns (antialiased riser edges)
    drops = []
    x = x0 + 1
    while x <= x1 + 2:
        if lev[x] > lev[x - 1] + 0.75:
            xs = x; before = lev[x - 1]
            while x + 1 <= x1 + 2 and lev[x + 1] > lev[x] + 0.75 and x + 1 - xs <= 1:
                x += 1
            drops.append((xs + 2.0, before, lev[x]))  # riser is 4 px wide; centre ~ first col + 2
        x += 1
    # tick clusters
    tc = np.where(tickcol)[0]
    ticks = []
    if len(tc):
        for grp in np.split(tc, np.where(np.diff(tc) > 1)[0] + 1):
            w = len(grp); k = max(1, int(round(w / 3.0)))
            centres = grp[0] + 1 + 3 * np.arange(k) if k > 1 else [grp.mean()]
            for c in centres:
                ticks.append(dict(x=float(c), width=int(w), n_in_cluster=k))
    return lev, drops, ticks, raw


def allocate(c, ticks_t, a, bnd, mode):
    """Censor times in [a,bnd): visible ticks first; extras per mode."""
    m = len(ticks_t)
    if c <= 0:
        return []
    if c <= m:
        idx = np.unique(np.round(np.linspace(0, m - 1, c)).astype(int)) if c > 1 else [m // 2]
        # guarantee exactly c distinct ticks
        idx = list(idx)
        rest = [i for i in range(m) if i not in idx]
        while len(idx) < c:
            idx.append(rest.pop(0))
        return sorted(ticks_t[i] for i in idx)
    extra = c - m
    out = list(ticks_t)
    if mode == 'ticks' and m > 0:
        for i in range(extra):             # added multiplicity on visible ticks, spread evenly
            out.append(ticks_t[int((i + 0.5) * m / extra) % m])
    else:
        lo = a; hi = bnd
        out += list(lo + (np.arange(extra) + 0.5) / extra * (hi - lo))
    return sorted(out)


def reconstruct(drops_t, ticks_t, risk, mode):
    recs = []; log = []
    S = 1.0
    for k in range(len(RISK_T) - 1):
        a, bnd = RISK_T[k], RISK_T[k + 1]
        n0, n1 = risk[k], risk[k + 1]
        dk = [(t, s) for t, s in drops_t if a <= t < bnd]
        tk = [t for t in ticks_t if a <= t < bnd]
        c = max(0, n0 - n1 - sum(0 for _ in dk))
        # start: estimate with no censoring
        best = None
        def simulate(cens):
            n = n0; Sc = S; ev = []; cs = []; sse = 0.0
            ci = 0
            for t, s_after in dk:
                while ci < len(cens) and cens[ci] < t:     # censor at a tie -> after events
                    cs.append(cens[ci]); n -= 1; ci += 1
                d = int(round(n * (1 - s_after / Sc))) if Sc > 0 and n > 0 else 0
                d = max(0, min(d, n))
                if d > 0:
                    ev.append((t, d)); Sc *= (1 - d / n); n -= d
                sse += (Sc - s_after) ** 2
            while ci < len(cens):
                cs.append(cens[ci]); n -= 1; ci += 1
            return ev, cs, Sc, n, sse

        for it in range(60):
            m = len(tk)
            if mode == 'ticks' and c > m:
                # visible ticks are each >= 1 censoring; extra censorings (tick multiplicity
                # or ticks hidden under risers) placed greedily at a visible tick or a drop
                # time so as to best reproduce the measured post-drop levels
                cand = sorted(set(tk) | {t for t, _ in dk}) or [(a + bnd) / 2]
                cens = sorted(tk)
                for _ in range(c - m):
                    scores = [(simulate(sorted(cens + [p]))[4], i) for i, p in enumerate(cand)]
                    cens = sorted(cens + [cand[min(scores)[1]]])
            else:
                cens = allocate(c, tk, a, bnd, mode)
            ev, cs, Sc, n, sse = simulate(cens)
            best = (c, ev, cs, Sc, n)
            if n == n1:
                break
            newc = c + (n - n1)
            if newc < 0:
                newc = 0
            if newc == c:
                break
            c = newc
        c, ev, cs, Sc, n = best
        log.append(dict(interval=[a, bnd], n_start=n0, n_end_table=n1, n_end_recon=int(n),
                        events=int(sum(d for _, d in ev)), censored=len(cs),
                        visible_ticks=len(tk), drops=len(dk), iterations=it + 1))
        for t, d in ev:
            recs += [(t, 1)] * d
        recs += [(t, 0) for t in cs]
        S = Sc
    return recs, log


results = {}; ext = {}
for grp in ['A', 'B']:
    lev, drops, ticks, raw = extract(masks[grp])
    drops_t = [(px2t(x), py2s(la)) for x, lb, la in drops]
    ticks_t = sorted(px2t(t['x']) for t in ticks)
    recs, log = reconstruct(drops_t, ticks_t, RISK[grp], args.extras)
    assert len(recs) == man['groups'][grp], (grp, len(recs))
    results[grp] = (recs, log)
    ext[grp] = dict(lev=lev, drops=drops, ticks=ticks)
    if args.csv == 'ipd.csv':
        pd.DataFrame([dict(x=x, time=px2t(x), level_before_px=lb, level_after_px=la,
                           S_before=py2s(lb), S_after=py2s(la)) for x, lb, la in drops]
                     ).to_csv(os.path.join(args.out, f'extracted_drops_{grp}.csv'), index=False)
        pd.DataFrame([dict(**t, time=px2t(t['x'])) for t in ticks]
                     ).to_csv(os.path.join(args.out, f'extracted_ticks_{grp}.csv'), index=False)
        pd.DataFrame(dict(x=np.arange(x0, x1 + 3), time=[px2t(x) for x in range(x0, x1 + 3)],
                          level_px=lev[x0:x1 + 3], S=[py2s(v) for v in lev[x0:x1 + 3]])
                     ).to_csv(os.path.join(args.out, f'extracted_curve_{grp}.csv'), index=False)

rows = [dict(group=g, observed_time=round(max(0.0, t), 4), event=e)
        for g in ['A', 'B'] for t, e in results[g][0]]
df = pd.DataFrame(rows)
tmp = os.path.join(args.out, args.csv + '.tmp')
df.to_csv(tmp, index=False)
os.replace(tmp, os.path.join(args.out, args.csv))
json.dump(dict(seed=SEED, extras_mode=args.extras, calibration=calib,
               interval_log={g: results[g][1] for g in results}),
          open(os.path.join(args.out, args.csv.replace('.csv', '_reconlog.json')), 'w'), indent=1)
print(json.dumps({g: results[g][1] for g in results}, indent=0))
print('calib resid', calib['x_resid'], calib['y_resid'])
