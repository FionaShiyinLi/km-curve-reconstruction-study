#!/usr/bin/env python3
"""Reload committed CSV, recompute right-continuous KM, compare with measured curve and
risk table; write checks.json and an overlay plot.
Usage: python check.py [--input ../input] [--out output] [--csv ipd.csv]"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument('--input', default='../input'); ap.add_argument('--out', default='output')
ap.add_argument('--csv', default='ipd.csv')
args = ap.parse_args()
path = os.path.join(args.out, args.csv)
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
man = json.load(open(os.path.join(args.input, 'manifest.json')))
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 72, 47, 31, 20, 7, 0], 'B': [100, 65, 56, 46, 41, 16, 0]}
TOL_S = 0.015  # line centre measurable to ~1-2 px (0.002); allow ~1 event step at n~70 for
               # event-count rounding under uncertain risk sets


def km(t, e):
    ts = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ts:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S))
    return out


def S_at(steps, x):  # right-continuous
    s = 1.0
    for u, v in steps:
        if u <= x: s = v
        else: break
    return s


checks = dict(csv=args.csv, sha256=sha, structure={}, curve={}, risk={},
              event_totals='unavailable: manifest supplies no arm-specific event totals',
              tolerance_S=TOL_S,
              tolerance_note='~1-2 px line-centre precision (0.002) plus one-event rounding '
                             'at typical risk sets; points within 3 px of a measured drop are '
                             'skipped because the step edge position is ambiguous')
fig, ax = plt.subplots(figsize=(9, 5))
for g in ['A', 'B']:
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    checks['structure'][g] = dict(n=int(len(d)), manifest_n=man['groups'][g],
                                  n_ok=bool(len(d) == man['groups'][g]),
                                  events=int(e.sum()), censored=int((e == 0).sum()),
                                  event_integer_01=bool(set(np.unique(e)) <= {0, 1}),
                                  finite_nonneg=bool(np.all(np.isfinite(t)) and np.all(t >= 0)),
                                  max_time=float(t.max()))
    steps = km(t, e)
    cur = pd.read_csv(os.path.join(args.out, f'extracted_curve_{g}.csv'))
    drops = pd.read_csv(os.path.join(args.out, f'extracted_drops_{g}.csv'))
    rows = []
    for tt in [0.25, 1, 2, 3, 4.5, 6.5, 9, 11, 13, 16, 18, 20, 22.5, 25, 27, 28.5, 31, 33, 34.9]:
        if tt > cur.time.max(): continue
        if np.min(np.abs(drops.time.values - tt)) < 0.075:
            tt = tt + 0.1
        meas = float(np.interp(tt, cur.time, cur.S))
        rec = S_at(steps, tt)
        rows.append(dict(t=round(tt, 3), measured=round(meas, 4), reconstructed=round(rec, 4),
                         residual=round(rec - meas, 4),
                         status='pass' if abs(rec - meas) <= TOL_S else 'fail'))
    checks['curve'][g] = rows
    rk = []
    for tt, n in zip(RISK_T, RISK[g]):
        c = int((t >= tt).sum())
        rk.append(dict(t=tt, table=n, reconstructed=c, residual=c - n,
                       status='pass' if c == n else 'fail'))
    checks['risk'][g] = rk
    ts = np.r_[0, [u for u, _ in steps]]; ss = np.r_[1, [v for _, v in steps]]
    ax.step(np.r_[ts, t.max()], np.r_[ss, ss[-1]], where='post', lw=1, label=f'{g} recon KM')
    ax.plot(cur.time, cur.S, lw=3, alpha=.35, label=f'{g} measured')
    cz = t[e == 0]; ax.plot(cz, [S_at(steps, u) for u in cz], '|', ms=6, color='k')
ax.legend(); ax.set_ylim(0, 1.02); ax.set_xlabel('months')
fig.savefig(os.path.join(args.out, args.csv.replace('.csv', '_overlay.png')), dpi=110)
allp = [r['status'] for g in checks['curve'] for r in checks['curve'][g]] + \
       [r['status'] for g in checks['risk'] for r in checks['risk'][g]]
checks['summary'] = dict(pass_=allp.count('pass'), fail=allp.count('fail'))
json.dump(checks, open(os.path.join(args.out, 'checks.json' if args.csv == 'ipd.csv'
                                    else args.csv.replace('.csv', '_checks.json')), 'w'), indent=1)
print(json.dumps(checks['summary']), [ (g,r['t'],r['residual']) for g in checks['curve'] for r in checks['curve'][g] if r['status']!='pass'],
      [(g, r['t'], r['residual']) for g in checks['risk'] for r in checks['risk'][g] if r['status'] != 'pass'])
print(checks['structure'])
