#!/usr/bin/env python3
"""Compare primary (ipd.csv) and sensitivity (sensitivity.csv) KM at a common horizon.
Usage: python sens_compare.py [--out output] [--horizon 35.0]"""
import argparse, json, os
import numpy as np, pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument('--out', default='output')
ap.add_argument('--horizon', type=float, default=35.0)
args = ap.parse_args()


def km(t, e):
    S = 1.0; out = [(0.0, 1.0)]
    for u in np.unique(t[e == 1]):
        S *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); out.append((u, S))
    return out


def summ(steps, h):
    area = 0.0; s_at = 1.0
    for i, (u, s) in enumerate(steps):
        if u > h: break
        nxt = steps[i + 1][0] if i + 1 < len(steps) else np.inf
        area += s * (min(nxt, h) - u); s_at = s
    return s_at, area


res = {'horizon_months': args.horizon}
for f in ['ipd.csv', 'sensitivity.csv']:
    d = pd.read_csv(os.path.join(args.out, f))
    for g in ['A', 'B']:
        x = d[d.group == g]
        s, a = summ(km(x.observed_time.values, x.event.values), args.horizon)
        res.setdefault(g, {})[f] = dict(S_h=round(s, 4), area_0_h=round(a, 3),
                                        events=int(x.event.sum()))
for g in ['A', 'B']:
    res[g]['diff_sens_minus_primary'] = dict(
        S_h=round(res[g]['sensitivity.csv']['S_h'] - res[g]['ipd.csv']['S_h'], 4),
        area_0_h=round(res[g]['sensitivity.csv']['area_0_h'] - res[g]['ipd.csv']['area_0_h'], 3))
json.dump(res, open(os.path.join(args.out, 'sensitivity_comparison.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
