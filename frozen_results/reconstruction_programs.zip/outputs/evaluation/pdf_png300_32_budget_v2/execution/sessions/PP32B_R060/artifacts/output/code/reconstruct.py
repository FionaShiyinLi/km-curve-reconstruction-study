#!/usr/bin/env python3
"""Reconstruct approximate participant-level time-to-event records from a
Kaplan-Meier raster figure (groups A and B).

Usage:  python reconstruct.py [--input ../input] [--out output] [--mode primary|sensitivity]

Steps
 1. Axis calibration from tick marks detected in the raster (x: 0..36 months,
    y: 0..1). Tick positions found by pixel search; mapping is linear.
 2. Column-wise measurement of each arm's curve (colour mask), classifying
    each column as plain line / censor tick / vertical drop, then an isotonic
    (PAVA) non-increasing fit of survival vs time. Hidden columns are
    interpolated; the origin is anchored at S(0)=1 (KM definition).
 3. Censor-tick detection (vertical marks extending >=5 px both sides of the
    fitted line); adjacent tick columns grouped, multiplicity weight
    max(1, round(width/3)) (ticks are 3 px wide).  Visibility != multiplicity.
 4. Guyot-type interval algorithm (own implementation): in each risk-table
    interval the number of censorings is iterated until the reconstructed
    number at risk at the next table time equals the printed value; events at
    each column are d = round(n_risk * (1 - S_meas/S_km_reconstructed)).
    Censoring times are placed at quantiles of the tick distribution
    (primary) or uniformly over the interval (sensitivity).
"""
import argparse, json, os, hashlib
import numpy as np
import pandas as pd
from PIL import Image

SEED = 1530622172
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
# Risk table read from the figure (visual reading of printed digits)
RISK_TIMES = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 667, 444, 290, 197, 65, 0],
        "B": [1000, 775, 568, 440, 339, 143, 0]}


def calibrate(im):
    dark = im.sum(2) < 200
    cols = dark[150:940].sum(0)
    yaxis_x = np.where(cols > 300)[0]
    rows = dark[:, 200:1750].sum(1)
    xaxis_y = np.where(rows > 500)[0]
    r = xaxis_y.max() + 5                     # row just below x axis: x ticks
    xs = np.where(dark[r, yaxis_x.min() - 2:])[0] + yaxis_x.min() - 2
    groups = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1)
    xt = np.array([g.mean() for g in groups])
    c = yaxis_x.min() - 6                     # column left of y axis: y ticks
    ys = np.where(dark[100:960, c])[0] + 100
    groups = np.split(ys, np.where(np.diff(ys) > 1)[0] + 1)
    yt = np.array([g.mean() for g in groups])
    assert len(xt) == 7 and len(yt) == 6, (xt, yt)
    xlab = np.arange(0, 37, 6.0)
    ylab = np.linspace(1.0, 0.0, 6)
    px, bx = np.polyfit(xlab, xt, 1)          # x_px = px*t + bx
    py, by = np.polyfit(ylab, yt, 1)          # y_px = py*S + by
    cal = dict(x_ticks_px=xt.tolist(), y_ticks_px=yt.tolist(),
               px_per_month=px, x0_px=bx, px_per_unitS=py, y0_px=by,
               x_resid_px=float(np.abs(np.polyval([px, bx], xlab) - xt).max()),
               y_resid_px=float(np.abs(np.polyval([py, by], ylab) - yt).max()))
    return cal


def pava_increasing(y, w):
    """Weighted isotonic regression, non-decreasing."""
    blocks = []  # [mean, weight, count]
    for yi, wi in zip(y, w):
        blocks.append([yi, wi, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            m2, w2, c2 = blocks.pop(); m1, w1, c1 = blocks.pop()
            blocks.append([(m1 * w1 + m2 * w2) / (w1 + w2), w1 + w2, c1 + c2])
    out = []
    for m, _, c in blocks:
        out += [m] * c
    return np.array(out)


def measure_arm(im, g, cal, other_mask):
    M = np.abs(im - np.array(COLORS[g])).sum(2) < 60
    M[:140] = False; M[935:] = False
    x0 = int(round(cal["x0_px"]))
    xcols = np.where(M[:, x0 - 2:1760].any(0))[0] + x0 - 2
    xlast = xcols.max()
    xs = np.arange(x0, xlast + 1)
    band = np.full(len(xs), np.nan); tick = np.full(len(xs), np.nan)
    runlen = np.zeros(len(xs), int)
    for i, x in enumerate(xs):
        r = np.where(M[:, x])[0]
        if len(r) == 0:
            continue
        runs = np.split(r, np.where(np.diff(r) > 1)[0] + 1)
        run = max(runs, key=len)
        runlen[i] = len(run)
        if len(runs) == 1 and len(run) <= 6:
            band[i] = run.mean()
        elif len(runs) == 1 and 14 <= len(run) <= 17:
            tick[i] = run.mean()
    ok = ~np.isnan(band)
    band_interp = np.interp(xs, xs[ok], band[ok])
    use = band.copy(); w = np.where(ok, 1.0, 0.0)
    tk = (~np.isnan(tick)) & (np.abs(tick - band_interp) <= 3)
    use[tk] = tick[tk]; w[tk] = 0.5
    # origin anchor: S(0)=1 at the x-axis origin column (KM definition)
    y1 = cal["y0_px"] + cal["px_per_unitS"] * 1.0
    use[0] = y1; w[0] = 5.0
    good = ~np.isnan(use)
    filled = np.interp(xs, xs[good], use[good])      # hidden columns: linear
    # drop columns (visible but not a plain line/tick) followed within 3 px by
    # a clean column: right-continuous, take that next measured level instead
    # of a linear ramp across the drop; longer ambiguous runs stay linear
    nxt = pd.Series(np.where(good, use, np.nan)).bfill(limit=3).values
    dropcol = (~good) & (runlen > 0) & ~np.isnan(nxt)
    filled[dropcol] = nxt[dropcol]
    wf = np.where(good, w, 0.0)
    # hidden columns / drop columns receive small weight so that PAVA carries
    # neighbouring measured levels (no global rescaling)
    wf = np.where(good, wf, 1e-6)
    iso = pava_increasing(filled, wf)
    # right-continuity at drop columns: value after drop = next column's level
    S = (iso - cal["y0_px"]) / cal["px_per_unitS"]
    S = np.clip(S, 0, 1)
    t = (xs - cal["x0_px"]) / cal["px_per_month"]
    # censor ticks: pixels >=5 px above and below the fitted line
    is_tick = np.zeros(len(xs), bool)
    for i, x in enumerate(xs):
        L = int(round(iso[i]))
        is_tick[i] = M[L + 5:L + 8, x].any() and M[L - 7:L - 4, x].any()
    idx = np.where(is_tick)[0]
    ticks = []
    if len(idx):
        for grp in np.split(idx, np.where(np.diff(idx) > 1)[0] + 1):
            width = len(grp)
            ticks.append((float(t[grp].mean()), max(1, int(round(width / 3.0))), width))
    meas = pd.DataFrame(dict(x_px=xs, t=t, raw_band_row=band, raw_tick_row=tick,
                             runlen=runlen, fitted_row=iso, S=S, tick_col=is_tick))
    return meas, ticks


def place_censors(C, lo, hi, ticks, mode):
    if C <= 0:
        return np.array([])
    hi = hi - 0.0125   # keep censorings strictly inside [lo, hi) (half pixel)
    tk = [(tt, w) for tt, w, _ in ticks if lo <= tt < hi]
    if mode == "sensitivity" or not tk:
        return lo + (hi - lo) * (np.arange(C) + 0.5) / C
    tt = np.minimum(np.array([a for a, _ in tk]), hi)
    ww = np.array([b for _, b in tk], float)
    cw = np.cumsum(ww) / ww.sum()
    q = (np.arange(C) + 0.5) / C
    return tt[np.searchsorted(cw, q)]


def reconstruct_arm(meas, ticks, risk, mode):
    t = meas.t.values; S = meas.S.values
    tend = t[-1]
    bounds = RISK_TIMES[:]
    records = []
    S_km = 1.0
    info = []
    for k in range(len(bounds) - 1):
        lo, hi = bounds[k], bounds[k + 1]
        n0, n1 = risk[k], risk[k + 1]
        hi_eff = min(hi, tend + 1e-9)
        sel = (t >= lo) & (t < hi) if k > 0 else (t > 0) & (t < hi)
        tj, sj = t[sel], S[sel]
        C = max(0, n0 - n1 - int(round(n0 * (1 - sj[-1] / S_km))) if len(sj) else n0 - n1)
        best = None
        for it in range(200):
            cens = np.sort(place_censors(C, lo, hi_eff, ticks, mode))
            n = n0; Sk = S_km; ev = []; ci = 0
            for a, b in zip(tj, sj):
                while ci < len(cens) and cens[ci] < a:
                    n -= 1; ci += 1
                if n <= 0:
                    continue
                d = int(round(n * (1 - b / Sk)))
                d = min(max(d, 0), n)
                if d:
                    ev.append((a, d)); Sk *= 1 - d / n; n -= d
            n -= len(cens) - ci
            best = (C, cens, ev, Sk, n)
            if n == n1:
                break
            Cn = max(0, C + (n - n1))
            if Cn == C:
                break
            C = Cn
        C, cens, ev, Sk, n = best
        # hard reconciliation of any residual (should not normally be needed)
        resid = n - n1
        info.append(dict(interval=[lo, hi], n_start=n0, n_end_table=n1, censored=int(C),
                         events=int(sum(d for _, d in ev)), n_end_recon=int(n),
                         iterations=it + 1, residual=int(resid)))
        for a, d in ev:
            records += [(a, 1)] * d
        records += [(c, 0) for c in cens]
        S_km = Sk
    return records, info


def km(times, events):
    order = np.lexsort((1 - events, times))
    ts, es = times[order], events[order]
    ut = np.unique(ts[es == 1]); S = 1.0; out_t = [0.0]; out_s = [1.0]
    for u in ut:
        n = (ts >= u).sum(); d = ((ts == u) & (es == 1)).sum()
        S *= 1 - d / n; out_t.append(u); out_s.append(S)
    return np.array(out_t), np.array(out_s)


def km_at(kt, ks, q):
    return ks[np.searchsorted(kt, q, side="right") - 1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input")
    ap.add_argument("--out", default="output")
    ap.add_argument("--mode", default="primary", choices=["primary", "sensitivity"])
    a = ap.parse_args()
    np.random.seed(SEED)  # recorded; algorithm is deterministic
    man = json.load(open(os.path.join(a.input, "manifest.json")))
    im = np.asarray(Image.open(os.path.join(a.input, "figure.png")).convert("RGB")).astype(int)
    cal = calibrate(im)
    os.makedirs(os.path.join(a.out, "intermediate"), exist_ok=True)
    frames = []; allinfo = {}; meas_all = {}
    for g in ["A", "B"]:
        meas, ticks = measure_arm(im, g, cal, None)
        meas_all[g] = meas
        if a.mode == "primary":
            meas.to_csv(os.path.join(a.out, "intermediate", f"curve_{g}.csv"), index=False)
            pd.DataFrame(ticks, columns=["t", "weight", "width_px"]).to_csv(
                os.path.join(a.out, "intermediate", f"ticks_{g}.csv"), index=False)
        recs, info = reconstruct_arm(meas, ticks, RISK[g], a.mode)
        assert len(recs) == man["groups"][g], (g, len(recs))
        allinfo[g] = dict(intervals=info, n_tick_groups=len(ticks),
                          tick_weight_total=int(sum(w for _, w, _ in ticks)))
        frames.append(pd.DataFrame(dict(group=g, observed_time=[r[0] for r in recs],
                                        event=[r[1] for r in recs])))
    df = pd.concat(frames, ignore_index=True)
    df["observed_time"] = df.observed_time.round(4)
    fname = "ipd.csv" if a.mode == "primary" else "sensitivity.csv"
    tmp = os.path.join(a.out, fname + ".tmp")
    df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(a.out, fname))
    json.dump(dict(calibration=cal, seed=SEED, mode=a.mode, arms=allinfo),
              open(os.path.join(a.out, "intermediate", f"recon_log_{a.mode}.json"), "w"), indent=1,
              default=float)
    print("wrote", fname, len(df))


if __name__ == "__main__":
    main()
