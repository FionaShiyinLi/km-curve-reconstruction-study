# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster). I found no PDF objects, so all measurement comes from pixels.
- `../input/manifest.json`: n = 1000 per group, time in months, code seed 1530622172. The manifest has **no arm-specific event totals**, so no event-total constraint was applied. The event counts below are outputs of the reconstruction and were not supplied.
- Risk table, read by eye from the figure (the digits are sharp and unambiguous):
  A: 1000, 667, 444, 290, 197, 65, 0; B: 1000, 775, 568, 440, 339, 143, 0, at 0, 6, ..., 36 months.

## Reproduction
`python output/code/reconstruct.py --input ../input --out output` (primary), then `... --mode sensitivity`, then `python output/code/checks.py --out output`. The algorithm is deterministic. The seed is set and recorded, but no random draws are used.

## Measurement (separate from correction)
- **Calibration.** Axis tick marks were detected in the raster. t = 0, 6, ..., 36 fall at x = 269.5 + 40·t px, and S = 1.0, ..., 0.0 fall at y = 929.5 − 750·S px. The linear fit residual is 0 px. No global rescaling was applied to either arm.
- **Curve reading.** Each arm was isolated by its exact line colour. Every column was classified from its pixel runs:
  - a plain line (≤6 px run): centre used;
  - a censor tick (14–17 px run, symmetric about the line and within 3 px of neighbouring line levels): centre used;
  - a vertical drop or ambiguous blob: level not read directly.
- **Drop columns.** These take the next clean level if one follows within 3 px (right-continuous). Otherwise they are interpolated linearly. A weighted isotonic (PAVA) fit then gives a non-increasing curve. There is no running-minimum propagation. In the 663 (A) and 581 (B) clean columns, the fit is within 0.0008 of the raw pixel centres.
- **Origin.** Both arms are anchored at S(0) = 1 by the KM definition. B is drawn over A for t < ~0.12 months. A emerges already at S ≈ 0.983, so its early drop is genuine and was kept. Only the 4 hidden columns were linearly interpolated.
- **Tails.** A ends at t = 35.86 (S = 0.081) and B at t = 35.99 (S = 0.172). Both end with censor ticks, so no follow-up was extended beyond the drawn curve.
- The column readings are saved in `intermediate/curve_{A,B}.csv` and the tick groups in `ticks_{A,B}.csv`.

## Reconstruction algorithm (own implementation, Guyot-type)
- **Events and censorings per interval.** Within each risk-table interval, the number censored, C, is iterated until the reconstructed number at risk at the next table time equals the printed value exactly. At each pixel column, events are d = round(n_risk·(1 − S_measured/S_KM,reconstructed)). Censorings strictly before a column leave the risk set first. At tied times, events precede censorings.
- **Censor times (primary).** C is placed at quantiles of the detected tick distribution in that interval. Adjacent tick columns are grouped and weighted max(1, round(width/3 px)).
  - This is an **assumption**: tick visibility does not reveal multiplicity. Dense tick blocks, especially after 24 months, overlap. Where C exceeds the visible ticks, several censorings share one tick time.
  - Censor times are capped half a pixel below each interval end, so a tick drawn on a boundary counts in the earlier interval, as the printed risk count at that boundary implies.
- **Multiple events.** Column drops are not assumed to be d = 1. d follows from the measured relative drop and the reconstructed risk set. At 1 px ≈ 0.0013 in S, single events are below pixel resolution for most of the follow-up, so the within-column timing of events is not identified.
- **Final interval.** The table gives 0 at risk at 36, so everyone remaining is censored at detected tick times no later than the curve's end. No record is placed at 36.

## Result and checks (`checks.json`)
- A: 807 events, 193 censored. B: 642 events, 358 censored.
- All 14 risk-table counts (count of observed_time ≥ t) match exactly.
- 20 checkpoint times per arm, 0.25–35.8 months, use the right-continuous KM from the reloaded CSV. All are within the tolerance of |ΔS| ≤ 0.01 (≈7.5 px, roughly twice the 4 px line width plus integer-event granularity). Through 34 months the residuals are ≤0.0017. The mean absolute residual over all columns is 0.001 in both arms.

## Unresolved limitations
- **Tails.** With n_risk < ~20, one event moves S by ≥0.01.
  - A: the final drop at 35.35 months (measured 0.108 → 0.081) is reconstructed as 0.108 → 0.091, one event short. The residual at 35.5–35.8 is +0.0098, just inside tolerance.
  - B: the column residual peaks at 0.018 near 35.8.
  - Both come from where the censorings are allocated in the 30–36 interval, which the figure does not identify. Both allowed correction cycles were used, so these are left unresolved.
- **Censoring pattern.** The pattern within intervals, accrual, and the event-free follow-up endpoint are not identified by the figure. The heavy censoring after 24 months follows the tick density and the risk table, not any known design.
- The reconstruction is one feasible approximation, not a unique recovery. No uncertainty bound is claimed.

## Sensitivity analysis (one alternative, `sensitivity.csv`)
- **Alternative assumption.** Censorings are spread uniformly within each risk interval, ignoring tick positions. Same curve and same risk table.
- **Common supported horizon: 35.8 months.**

| Arm | S(35.8), primary | S(35.8), sensitivity | Area to 35.8 mo, primary | Area to 35.8 mo, sensitivity | Events, primary | Events, sensitivity |
|---|---|---|---|---|---|---|
| A | 0.091 | 0.075 | 14.17 | 14.17 | 807 | 810 |
| B | 0.191 | 0.210 | 19.27 | 19.27 | 642 | 642 |

- S(12) and S(24) differ by ≤0.0005. The tail survival is materially allocation-dependent; the area is not.
- This single alternative is not a confidence interval.
