#!/usr/bin/env python3
"""Verify committed records against measured curve and risk table.
Usage: python checks.py [--out output]   (run after reconstruct.py)"""
import argparse, json, os, hashlib, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reconstruct import km, km_at, RISK, RISK_TIMES, SEED

TOL = 0.01  # absolute survival tolerance, justified in assumptions.md


def rmst(kt, ks, h):
    grid = np.append(kt[kt < h], h)
    s = ks[:len(grid) - 1]
    return float(np.sum(np.diff(grid) * s))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="output")
    a = ap.parse_args()
    path = os.path.join(a.out, "ipd.csv")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    df = pd.read_csv(path)
    man_n = {"A": 1000, "B": 1000}
    res = dict(csv_sha256=sha, seed=SEED, tolerance_S=TOL, arms={})
    qtimes = [0.25, 0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.8]
    for g in ["A", "B"]:
        d = df[df.group == g]
        meas = pd.read_csv(os.path.join(a.out, "intermediate", f"curve_{g}.csv"))
        kt, ks = km(d.observed_time.values, d.event.values)
        arm = dict(n=int(len(d)), n_expected=man_n[g], n_pass=bool(len(d) == man_n[g]),
                   event_values_ok=bool(set(d.event.unique()) <= {0, 1}),
                   times_ok=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                   n_events=int(d.event.sum()), n_censored=int((d.event == 0).sum()),
                   max_time=float(d.observed_time.max()),
                   supplied_event_total="unavailable (not in manifest)")
        surv = []
        for q in qtimes:
            if q > meas.t.max():
                surv.append(dict(t=q, status="unavailable (beyond curve end)")); continue
            m = float(meas.S[meas.t <= q].iloc[-1]) if (meas.t <= q).any() else 1.0
            r = float(km_at(kt, ks, q))
            surv.append(dict(t=q, measured=round(m, 4), reconstructed=round(r, 4),
                             residual=round(r - m, 4), status="pass" if abs(r - m) <= TOL else "fail"))
        arm["survival_checks"] = surv
        allres = np.array([km_at(kt, ks, q) for q in meas.t.values]) - meas.S.values
        okb = meas.raw_band_row.notna()
        dev = (meas.fitted_row - meas.raw_band_row)[okb].abs() / 750.0
        arm["measurement_fit_vs_raw_band"] = dict(
            n_clean_columns=int(okb.sum()), max_abs_S=round(float(dev.max()), 4),
            p99_abs_S=round(float(dev.quantile(0.99)), 4), mean_abs_S=round(float(dev.mean()), 5))
        arm["max_abs_residual_all_columns"] = round(float(np.abs(allres).max()), 4)
        arm["mean_abs_residual_all_columns"] = round(float(np.abs(allres).mean()), 5)
        risk = []
        for tt, nr in zip(RISK_TIMES, RISK[g]):
            c = int((d.observed_time >= tt).sum())
            risk.append(dict(t=tt, table=nr, reconstructed=c, residual=c - nr,
                             status="pass" if c == nr else "fail"))
        arm["risk_checks"] = risk
        arm["tail"] = dict(last_curve_time=round(float(meas.t.max()), 4),
                           measured_S_last=round(float(meas.S.iloc[-1]), 4),
                           reconstructed_S_last=round(float(ks[-1]), 4),
                           records_at_or_after_36=int((d.observed_time >= 36).sum()))
        res["arms"][g] = arm
    # sensitivity comparison if present
    sp = os.path.join(a.out, "sensitivity.csv")
    if os.path.exists(sp):
        s = pd.read_csv(sp); h = 35.8
        comp = {"horizon_months": h}
        for g in ["A", "B"]:
            out = {}
            for lab, dd in [("primary", df), ("sensitivity", s)]:
                x = dd[dd.group == g]; kt, ks = km(x.observed_time.values, x.event.values)
                out[lab] = dict(S_at_12=round(float(km_at(kt, ks, 12)), 4),
                                S_at_24=round(float(km_at(kt, ks, 24)), 4),
                                S_at_h=round(float(km_at(kt, ks, h)), 4),
                                area_to_h=round(rmst(kt, ks, h), 3),
                                events=int(x.event.sum()))
            comp[g] = out
        res["sensitivity_comparison"] = comp
    json.dump(res, open(os.path.join(a.out, "checks.json"), "w"), indent=1)
    # overlay plot
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 6))
    for g, c in [("A", "tab:blue"), ("B", "tab:orange")]:
        meas = pd.read_csv(os.path.join(a.out, "intermediate", f"curve_{g}.csv"))
        d = df[df.group == g]; kt, ks = km(d.observed_time.values, d.event.values)
        ax.plot(meas.t, meas.S, color="k", lw=0.8)
        ax.step(kt, ks, where="post", color=c, lw=1, alpha=0.8, label=f"{g} reconstructed")
    ax.legend(); ax.set_xlabel("months"); ax.set_ylabel("S"); fig.savefig(
        os.path.join(a.out, "intermediate", "overlay.png"), dpi=110)
    for g in ["A", "B"]:
        ar = res["arms"][g]
        print(g, ar["n"], ar["n_events"], "maxres", ar["max_abs_residual_all_columns"],
              "meas", ar["measurement_fit_vs_raw_band"],
              [r["status"] for r in ar["risk_checks"]],
              [s.get("status") for s in ar["survival_checks"]])
    print(json.dumps(res.get("sensitivity_comparison")))


if __name__ == "__main__":
    main()
