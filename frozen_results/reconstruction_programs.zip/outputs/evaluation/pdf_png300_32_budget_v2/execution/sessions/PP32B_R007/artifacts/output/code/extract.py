"""Measure KM curves and censor ticks from the raster figure.
Usage: python extract.py [path/to/figure.png]  (default ../../../input/figure.png relative to this file)
Outputs (in ../): extracted_levels_{A,B}.csv, extracted_drops.csv, extracted_ticks.csv"""
import sys, os, json
import numpy as np, pandas as pd
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__))
FIG=sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'../../../input/figure.png')
OUT=os.path.join(HERE,'..')
im=np.array(Image.open(FIG).convert('RGB')).astype(int)
# Calibration from labelled axis ticks (measured in probe: x tick columns 269-270 .. 1709-1710;
# y tick rows 179-180 (1.0) .. 929-930 (0.0)).
X0,X36=269.5,1709.5; Y1,Y0=179.5,929.5
t_of=lambda x:(x-X0)/(X36-X0)*36
s_of=lambda y:(Y0-y)/(Y0-Y1)
COL={'A':(31,119,180),'B':(255,127,14)}
H,W,_=im.shape
def mask(c):
    m=(np.abs(im-np.array(c)).sum(2)<150); m[:150]=False; m[945:]=False; m[:, :266]=False
    return m
M={g:mask(c) for g,c in COL.items()}
def hlevels(m,x,r=3):
    """row groups where a horizontal run of >=2r+1 px passes through column x"""
    lo,hi=max(0,x-r),min(W,x+r+1)
    rows=np.where(m[:,lo:hi].all(1))[0]
    if len(rows)==0: return []
    grp=np.split(rows,np.where(np.diff(rows)>1)[0]+1)
    return [(g[0],g[-1]) for g in grp]
res={}
for g in 'AB':
    m=M[g]; other=M['B' if g=='A' else 'A']
    xs=np.arange(271,1710); lev=[]; occl=[]
    prev=179.5
    for x in xs:
        L=hlevels(m,x)
        # a genuine line group is ~4 px thick; partially occluded groups can be thinner
        L=[l for l in L if l[1]-l[0]<=6]
        if L:
            # choose lowest group not above the previous level (monotone curve), else nearest
            cand=[l for l in L if (l[0]+l[1])/2>=prev-2.5]
            l=max(cand,key=lambda l:l[1]) if cand else min(L,key=lambda l:abs((l[0]+l[1])/2-prev))
            y=(l[0]+l[1])/2
            # thin group (<4 px) adjacent to other colour => partially occluded; use full 4px convention
            if l[1]-l[0]<3:
                if other[l[1]+1,x]: y=l[0]+1.5
                elif other[l[0]-1,x]: y=l[1]-1.5
            lev.append(y); occl.append(0); prev=y
        else:
            lev.append(np.nan); occl.append(1)
    lev=np.array(lev); 
    df=pd.DataFrame({'x':xs,'t':t_of(xs),'y':lev,'S':s_of(lev),'occluded':occl})
    # stop after last visible column
    last=np.where(~np.isnan(lev))[0].max(); df=df.iloc[:last+1]
    res[g]=df
    df.to_csv(os.path.join(OUT,f'extracted_levels_{g}.csv'),index=False)
# ticks: columns where colour extends >=4px both above and below the local line band
ticks=[]
for g in 'AB':
    m=M[g]; df=res[g]
    flag=[]
    for x,y in zip(df.x,df.y):
        if np.isnan(y): flag.append(False); continue
        yi=int(round(y))
        up=m[yi-9:yi-3,x].sum(); dn=m[yi+4:yi+10,x].sum()
        flag.append(up>=4 and dn>=4)
    flag=np.array(flag); xs=df.x.values
    idx=np.where(flag)[0]
    if len(idx):
        for grp in np.split(idx,np.where(np.diff(idx)>1)[0]+1):
            xc=xs[grp].mean(); w=len(grp)
            ticks.append({'group':g,'x':xc,'t':t_of(xc),'width_px':w,'S':float(np.nanmedian(df.S.values[grp]))})
tk=pd.DataFrame(ticks); tk.to_csv(os.path.join(OUT,'extracted_ticks.csv'),index=False)
# drops: changes in level between consecutive visible columns
drops=[]
for g in 'AB':
    df=res[g].dropna(subset=['y']); y=df.y.values; x=df.x.values
    for i in range(1,len(y)):
        if y[i]-y[i-1]>=1.0:
            drops.append({'group':g,'x_before':x[i-1],'x_after':x[i],'t':t_of((x[i-1]+x[i])/2),
                          'S_before':s_of(y[i-1]),'S_after':s_of(y[i]),'dy_px':y[i]-y[i-1]})
dr=pd.DataFrame(drops); dr.to_csv(os.path.join(OUT,'extracted_drops.csv'),index=False)
print(tk.groupby('group').size()); print(tk.width_px.value_counts())
pd.set_option('display.width',200); pd.set_option('display.max_rows',500)
print(dr.round(4).to_string())
for g in 'AB': print(g,'occluded cols',res[g].occluded.sum(), res[g].x[res[g].occluded==1].values[:80])
