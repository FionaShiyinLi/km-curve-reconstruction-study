"""Reload committed CSVs, recompute right-continuous KM, compare to measurements; write ../checks.json.
Usage: python checks.py [path/to/figure.png]"""
import os, sys, json, hashlib
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__)); OUT=os.path.join(HERE,'..')
FIG=sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'../../../input/figure.png')
RISK_T=[0,6,12,18,24,30,36]; RISK={'A':[100,65,42,25,18,9,0],'B':[100,66,53,42,36,12,0]}
TOL=0.015  # prespecified: +-1.5 px line-centre reading (0.002) + one-event granularity at n~100 (0.01)
def km(t,e):
    ut=np.unique(t[e==1]); S=1; out=[]
    for u in ut:
        n=np.sum(t>=u); d=np.sum((t==u)&(e==1)); S*=1-d/n; out.append((u,S))
    return out
def km_at(st,x):
    s=1.0
    for u,v in st:
        if u<=x: s=v
        else: break
    return s
def rmst(st,h):
    area=0; prev=0; s=1.0
    for u,v in st:
        if u>h: break
        area+=s*(u-prev); prev=u; s=v
    return area+s*(h-prev)
ipd=pd.read_csv(os.path.join(OUT,'ipd.csv'))
sha=hashlib.sha256(open(os.path.join(OUT,'ipd.csv'),'rb').read()).hexdigest()
drops=pd.read_csv(os.path.join(OUT,'extracted_drops.csv'))
chk={'ipd_sha256':sha,'tolerance_survival_abs':TOL,
     'tolerance_justification':'prespecified: line-centre reading +-1.5 px (0.002) plus one-event KM granularity near n=100 (0.01); not tuned',
     'event_totals':'unavailable (not supplied in manifest)','arms':{}}
fig,ax=plt.subplots(figsize=(10,6))
img=np.array(Image.open(FIG).convert('RGB'))
for g,colr in [('A','tab:blue'),('B','tab:orange')]:
    d=ipd[ipd.group==g]; t=d.observed_time.values; e=d.event.values
    st=km(t,e); lv=pd.read_csv(os.path.join(OUT,f'extracted_levels_{g}.csv'))
    dx=drops[drops.group==g][['x_before','x_after']].values
    arm={'n_records':int(len(d)),'n_expected':100,'n_events':int(e.sum()),
         'event_values_integer_01':bool(set(np.unique(e))<={0,1}),
         'times_finite_nonneg':bool(np.all(np.isfinite(t))&np.all(t>=0)),'max_time':float(t.max())}
    # survival comparisons at columns away from risers (>=3 px from any drop) and visible
    grid=list(np.arange(0.5,t.max(),1.0))+[t.max()-0.05]
    comp=[]
    for tt in grid:
        x=int(round(269.5+40*tt))
        for off in range(0,12):
            xx=x+off
            row=lv[lv.x==xx]
            if len(row) and not np.isnan(row.y.values[0]) and not any((xx>=a-2)&(xx<=b+2) for a,b in dx): break
        else: comp.append({'t':round(tt,3),'status':'unavailable (occluded)'}); continue
        tm=(xx-269.5)/40; Sm=float(row.S.values[0]); Sr=km_at(st,tm)
        comp.append({'t':round(tm,4),'measured':round(Sm,4),'reconstructed':round(Sr,4),'residual':round(Sr-Sm,4),
                     'status':'pass' if abs(Sr-Sm)<=TOL else 'fail','tail':bool(tm>t.max()-4)})
    arm['survival_checks']=comp
    rk=[]
    for tk,nr in zip(RISK_T,RISK[g]):
        m=int(np.sum(t>=tk))
        rk.append({'t':tk,'table':nr,'reconstructed':m,'residual':m-nr,'status':'pass' if m==nr else 'fail'})
    arm['risk_checks']=rk
    arm['zero_risk_at_36_not_placed_at_36']=bool(np.all(t<36))
    arm['summary']={'survival_pass':sum(c.get('status')=='pass' for c in comp),'survival_fail':sum(c.get('status')=='fail' for c in comp),
                    'max_abs_residual':max(abs(c['residual']) for c in comp if 'residual' in c),
                    'risk_pass':sum(r['status']=='pass' for r in rk)}
    chk['arms'][g]=arm
    xs=np.r_[0,[u for u,_ in st]]; ys=np.r_[1,[v for _,v in st]]
    ax.step(np.r_[xs,t.max()],np.r_[ys,ys[-1]],where='post',color=colr,lw=1,label=f'{g} reconstructed')
    ax.plot(lv.t,lv.S,'.',ms=1.5,color='k')
# sensitivity comparison
sp=os.path.join(OUT,'sensitivity.csv')
if os.path.exists(sp):
    sen=pd.read_csv(sp); H=33.0; sc={'horizon_months':H,'assumption':'extra censorings (risk table minus visible ticks) placed as multiplicities at visible ticks instead of uniformly over the interval','arms':{}}
    for g in 'AB':
        a=ipd[ipd.group==g]; b=sen[sen.group==g]
        sa=km(a.observed_time.values,a.event.values); sb=km(b.observed_time.values,b.event.values)
        sc['arms'][g]={'S_primary':round(km_at(sa,H),4),'S_sensitivity':round(km_at(sb,H),4),
                       'RMST_primary':round(rmst(sa,H),4),'RMST_sensitivity':round(rmst(sb,H),4),
                       'events_primary':int(a.event.sum()),'events_sensitivity':int(b.event.sum())}
    chk['sensitivity']=sc
ax.legend(); ax.set_xlabel('months'); ax.set_ylabel('S'); fig.savefig(os.path.join(OUT,'overlay_check.png'),dpi=110)
tmp=os.path.join(OUT,'checks.json.tmp'); json.dump(chk,open(tmp,'w'),indent=1); os.replace(tmp,os.path.join(OUT,'checks.json'))
for g in 'AB':
    print(g,chk['arms'][g]['summary'],[ (r['t'],r['table'],r['reconstructed']) for r in chk['arms'][g]['risk_checks']])
    print([ (c['t'],c.get('residual'),c['status']) for c in chk['arms'][g]['survival_checks'] if c['status']!='pass'])
print(json.dumps(chk.get('sensitivity'),indent=0))
