import numpy as np
from PIL import Image
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
dark=(im.sum(2)<150)
print('ytick rows',np.where(dark[:,262])[0])
def mask(c):
    return (np.abs(im-np.array(c)).sum(2)<120)
for name,c in [('A',(31,119,180)),('B',(255,127,14))]:
    m=mask(c); m[:150]=False; m[950:]=False
    ys,xs=np.where(m); print(name,xs.min(),xs.max(),ys.min(),ys.max())
    for x in [271,272,273,275,280,300,600,1000,1590,1600,1605,1690,1695,1700]:
        print(' ',x,np.where(m[:,x])[0])
