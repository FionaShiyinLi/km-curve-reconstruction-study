"""Reconstruct approximate IPD from measured KM steps, censor ticks and the number-at-risk table.
Run after extract.py:  python reconstruct.py [--mode uniform|tickmult]
uniform  (primary): censorings required by the risk table beyond visible ticks are spread uniformly
                    over the risk interval (truncated at the last visible curve time).
tickmult (sensitivity): the same extra censorings are assigned as multiplicities at visible ticks.
Writes ../ipd.csv (primary) or ../sensitivity.csv, via temp file + atomic rename."""
import os, sys, json
import numpy as np, pandas as pd
np.random.seed(790512406)   # manifest code seed; algorithm is deterministic, seed recorded for completeness
HERE=os.path.dirname(os.path.abspath(__file__)); OUT=os.path.join(HERE,'..')
MODE='tickmult' if '--mode' in sys.argv and sys.argv[sys.argv.index('--mode')+1]=='tickmult' else 'uniform'
t_of=lambda x:(x-269.5)/40.0
RISK_T=[0,6,12,18,24,30,36]
RISK={'A':[100,65,42,25,18,9,0],'B':[100,66,53,42,36,12,0]}   # read from figure
N={'A':100,'B':100}
drops=pd.read_csv(os.path.join(OUT,'extracted_drops.csv'))
ticks=pd.read_csv(os.path.join(OUT,'extracted_ticks.csv'))
# ---- visual adjudication of tick detections (see assumptions.md, zoom_check.png, ASCII dumps) ----
# width-1 detections at staircase corners are not ticks; A x=506 is a genuine tick merged with a riser.
false_ticks={('A',428.0),('A',543.0),('A',754.0),('A',798.0),
             ('B',292.0),('B',295.0),('B',301.0),('B',304.0),('B',309.0)}
ticks=ticks[[ (g,x) not in false_ticks for g,x in zip(ticks.group,ticks.x)]].copy()
# B x=1269.5 (8 px) is a tick at x=1267 merged with the drop riser at ~1270
ticks.loc[(ticks.group=='B')&(ticks.x==1269.5),['x','t','width_px']]=[1267.0,t_of(1267.0),3]
# clipped end-of-line ticks missed by the detector (need +-3 px horizontal run)
ticks=pd.concat([ticks,pd.DataFrame([{'group':'A','x':1606.5,'t':t_of(1606.5),'width_px':2,'S':0.168},
                                     {'group':'B','x':1695.0,'t':t_of(1695.0),'width_px':3,'S':0.301}])])
T_END={'A':t_of(1606.5),'B':t_of(1695.0)}
# ---- origin of A is occluded by B; local remeasurement: riser at x=271-274 ending at row 189 (S=0.99),
# riser at x=277-280 from 0.99 to 0.97 (row 202). Calibration elsewhere untouched.
origin=pd.DataFrame([{'group':'A','t':t_of(272.5),'S_after':0.99},{'group':'A','t':t_of(278.5),'S_after':0.97}])
def steps(g):
    d=drops[drops.group==g][['t','S_after']]
    if g=='A': d=pd.concat([origin[['t','S_after']],d])
    return d.sort_values('t').reset_index(drop=True)

def run_interval(k,n0,evs,cens_times):
    """process drops evs (list of (t,Smeas)) in interval with censor times; return events list, S"""
    return None

def reconstruct(g,mode,shift=None):
    st=steps(g).copy()
    if shift is not None:
        for i,tk in shift: st.loc[i,'t']=tk-0.0125
    tk_all=ticks[ticks.group==g].sort_values('t')
    events=[]; cens=[]; S=1.0; log=[]
    n_k=N[g]
    for k in range(len(RISK_T)-1):
        a,b=RISK_T[k],RISK_T[k+1]; n_next=RISK[g][k+1]; n_k=RISK[g][k] if k>0 else N[g]
        ev_k=st[(st.t>=a)&(st.t<b)]
        tk_k=tk_all[(tk_all.t>=a)&(tk_all.t<b)]
        hi=min(b,T_END[g])
        c=len(tk_k); S0=S; seen=set()
        for it in range(100):
            ct=list(tk_k.t.values)
            extra=c-len(ct)
            if extra>0:
                if mode=='uniform' or len(ct)==0:
                    ct+= list(a+(np.arange(extra)+0.5)*(hi-a)/extra)
                else:   # multiplicity at visible ticks, widest ticks first
                    order=list(tk_k.sort_values('width_px',ascending=False,kind='stable').t.values)
                    ct+= [order[i%len(order)] for i in range(extra)]
            elif extra<0:   # fewer censorings allowed than visible ticks: keep evenly spaced subset
                idx=np.round(np.linspace(0,len(ct)-1,c)).astype(int) if c>0 else []
                ct=[ct[i] for i in idx]
            ct=np.sort(np.array(ct))
            S=S0; evl=[]; nleft=n_k; ci=0
            for t,Sm in zip(ev_k.t,ev_k.S_after):
                nr=nleft-sum(1 for x in ct if x<t)-sum(e[1] for e in evl) if False else n_k-np.sum(ct<t)-sum(e[1] for e in evl)
                d=int(round(nr*(1-Sm/S))) if S>0 else 0
                d=max(0,min(d,nr))
                if d>0: evl.append((t,d)); S*=1-d/nr
            D=sum(e[1] for e in evl)
            if b==36: need=n_k-D     # risk 0 at 36: everyone remaining exits in the interval
            else: need=n_k-D-n_next
            if need==c or (c,need) in seen: break
            seen.add((c,need)); c=max(0,need)
        conflict = (need<0) or (need!=c)
        log.append({'interval':[a,b],'n_start':int(n_k),'n_next_table':int(n_next),'events':int(D),
                    'visible_ticks':int(len(tk_k)),'censored':int(len(ct)),
                    'extra_censored_vs_ticks':int(len(ct)-len(tk_k)),'unreconciled':bool(conflict)})
        events+=evl; cens+=list(ct)
    rec=[(t,1) for t,d in events for _ in range(d)]+[(t,0) for t in cens]
    df=pd.DataFrame(rec,columns=['observed_time','event']); df.insert(0,'group',g)
    return df,log,st

def km(df):
    t=df.observed_time.values; e=df.event.values; ut=np.unique(t[e==1]); S=1; out=[]
    for u in ut:
        n=np.sum(t>=u); d=np.sum((t==u)&(e==1)); S*=1-d/n; out.append((u,S))
    return out
def km_at(steps_,x):
    s=1.0
    for u,v in steps_:
        if u<=x: s=v
        else: break
    return s
def sse(df,st):
    k=km(df); return sum((km_at(k,t+1e-9)-s)**2 for t,s in zip(st.t,st.S_after))

res={}; logs={}
for g in 'AB':
    st=steps(g)
    best=reconstruct(g,MODE)
    # boundary ambiguity: drop within 1.2 px after a risk time may belong to the preceding interval
    cand=[(i,tk) for i,t in enumerate(st.t) for tk in RISK_T[1:-1] if 0<=t-tk<0.03]
    choice='none'
    for c_ in cand:
        alt=reconstruct(g,MODE,shift=[c_])
        if len(alt[0])==N[g] and sse(alt[0],alt[2])<sse(best[0],best[2]):
            best=alt; choice=f'drop at t={st.t[c_[0]]:.4f} assigned to t={c_[1]-0.0125:.4f} (before risk time {c_[1]})'
    df,log,_=best
    assert len(df)==N[g], (g,len(df))
    res[g]=df; logs[g]={'intervals':log,'boundary_choice':choice}
out=pd.concat([res['A'],res['B']]); out['observed_time']=out.observed_time.round(4)
out=out.sort_values(['group','observed_time','event'],ascending=[True,True,False])
fn=os.path.join(OUT,'ipd.csv' if MODE=='uniform' else 'sensitivity.csv')
tmp=fn+'.tmp'; out.to_csv(tmp,index=False); os.replace(tmp,fn)
json.dump(logs,open(os.path.join(OUT,f'reconstruction_log_{MODE}.json'),'w'),indent=1)
print(json.dumps(logs,indent=0)); print(out.groupby('group').event.agg(['size','sum']))
