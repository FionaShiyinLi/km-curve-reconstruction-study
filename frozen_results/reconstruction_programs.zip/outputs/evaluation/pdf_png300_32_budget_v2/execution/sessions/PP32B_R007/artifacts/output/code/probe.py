import numpy as np
from PIL import Image
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
dark=(im.sum(2)<150)
# axis lines
cols=dark.sum(0); rows=dark.sum(1)
print('dark cols',[ (i,c) for i,c in enumerate(cols) if c>300])
print('dark rows',[ (i,c) for i,c in enumerate(rows) if c>300])
# ticks below x axis
for r in range(925,945): print(r, np.where(dark[r,250:1750])[0][:40]+250)
