# Reconstruction assumptions and method

**Inputs used:** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (n=100 per arm, months, seed 790512406). No arm-specific event totals are supplied, so that check is marked unavailable. No HR, RMST or other summaries were used.

**Run order** (from `output/code/`): `python extract.py && python reconstruct.py && python reconstruct.py --mode tickmult && python checks.py`. Each script also accepts an explicit figure path. The seed is set but not used, because the algorithm is deterministic.

## Measurement (`extract.py`)
- **Calibration** comes from labelled axis tick pixels. t=0 is at x=269.5 and t=36 at x=1709.5 (40 px/month). S=1 is at y=179.5 and S=0 at y=929.5 (750 px/unit). No global rescaling was applied.
- **Curves** were segmented by line colour. The level in each column is the centre of a 4-px horizontal-run band (run of at least 7 px), and drops are level changes between visible columns. Early drops fall in 7.5-px (0.01) quanta, which fits n=100.
- **Origin of A:** it is hidden under B's line. I remeasured that local neighbourhood only, and the ASCII dump shows two risers: 1.00→0.99 at x≈272.5 (t≈0.075) and 0.99→0.97 at x≈278.5 (t≈0.225). Both were inserted as drops. The 0.99→0.97 riser is a single column, so it is read as 2 tied events. That is a pixel-resolution assumption: it could be 2 events up to about 1 px apart.
- **Censor ticks:** these are columns where colour extends at least 4 px above and below the line band. Detections were adjudicated visually (`zoom_check.png` and ASCII dumps):
  - One-pixel detections at staircase corners were removed. These are A at 3.96, 6.84, 12.11 and 13.21 months, and B at 0.56–0.99 months.
  - A's mark at 5.91 months was kept; it is a real tick whose upper half merges with a riser.
  - B's 8-px mark at 25.0 months was split into a tick at 24.94 months plus the drop.
  - Two clipped end-of-line ticks were added: A at 33.44 and B at 35.63 months.
  - Each visible tick counts as one censoring. Visibility does not establish multiplicity; some 4-px ticks may be two overlapping ticks.
- **Outputs:** `extracted_levels_{A,B}.csv`, `extracted_drops.csv` and `extracted_ticks.csv` (raw, before adjudication).

## Reconstruction (`reconstruct.py`)
This is a Guyot-type interval algorithm that I implemented myself, not a package. It works through each number-at-risk interval [6k, 6k+6).
- **Events at each measured drop:** d = round(n_risk·(1 − S_meas_after / S_rec_before)), clipped to [0, n_risk]. The ratio uses the reconstructed KM, so errors do not accumulate, and 1-px jitter "drops" round to 0. d is not fixed at 1.
- **At-risk count:** n_risk counts people with time ≥ t (censorings tied with an event remain at risk).
- **Censorings per interval** are set iteratively to n_start − events − n_next from the risk table. For the interval ending at 36 (displayed risk 0), everyone remaining leaves before 36; nobody is placed at 36.
- **Extra censorings:** when the risk table needs more censorings than there are visible ticks, the extras are placed uniformly across the interval (primary assumption). The interval is truncated at the last visible curve time, so no follow-up is invented beyond the plotted curve.
  - The number of extras is set by the risk table.
  - Their timing is an assumption; the curve and ticks do not identify it.
  - Extras by interval: A has 1 each in 24–30 and 30–36. B has 2 in 0–6, 1 in 12–18, 3 in 24–30 and 1 in 30–36.
  - Plausible explanations are ticks hidden where the curves overlap (early on) or ticks stacked in the dense tails.
- **Boundary drop:** B's drop at x≈1469.5 sits at t=30.0 within pixel resolution. It was assigned to t=29.9875, before the risk time, because that assignment fits the measured step better (n=13 rather than 12). The choice between the two assignments was made by curve SSE.
- **Totals:** A has 75 events and 25 censorings; B has 59 events and 41 censorings. Every interval reconciled with the risk table; none was left unreconciled.

## Checks (`checks.py` → `checks.json`)
- **Survival curve:** I reloaded `ipd.csv` and recomputed the right-continuous KM. It was compared with measured levels at about 1-month steps, avoiding risers, and includes a tail point for each arm.
  - The tolerance of 0.015 was prespecified, not tuned.
  - Maximum absolute residual: A 0.0005, B 0.0012. All available points pass.
  - Points in occluded regions near the origin are marked unavailable.
- **Risk table:** counts of records with observed_time ≥ t match the table exactly at all 7 times in both arms.
- **Integrity:** SHA-256 of the CSV is recorded. Arm sizes, 0/1 event indicators and finite, nonnegative times are also checked.

## Sensitivity (`sensitivity.csv`)
- The one alternative places the same extra censorings as multiplicities at visible ticks.
- At a common supported horizon of 33 months (A's curve ends at 33.44):
  - A is unchanged: S=0.1685, RMST 13.83.
  - B changes slightly: S 0.3024 vs 0.2998, RMST 17.93 vs 17.90.
- This is a single alternative. It is not an interval or a bound on reconstruction error.

## Limitations
- Exact event times are known only to about ±0.025 months (1 px).
- Tied or near-tied events within one raster column cannot be separated.
- Censoring times hidden by overlap or stacked ticks are not identified.
- The flat tails do not identify a censoring or accrual distribution.
- No event totals were available to cross-check the event counts.
