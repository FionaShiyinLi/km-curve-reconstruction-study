"""Reload committed ipd.csv, recompute right-continuous KM, compare with extracted curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
p = os.path.join(out, 'ipd.csv'); sha = hashlib.sha256(open(p, 'rb').read()).hexdigest()
df = pd.read_csv(p); ob = json.load(open(os.path.join(out, 'extracted_observations.json')))
man = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'input', 'manifest.json'))) \
    if len(sys.argv) < 3 else json.load(open(sys.argv[2]))
TOL_S = 1e-3  # vector coordinates: S resolution ~1e-5; 1e-3 allows 4-decimal time rounding in CSV

def km(t, e, at):
    ts = np.unique(t[e == 1]); S = 1.0; res = []
    steps = []
    for u in ts:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1-d/n; steps.append((u, S))
    for a in at:
        s = 1.0
        for u, v in steps:
            if u <= a: s = v
        res.append(s)
    return res

def meas(curve, a):  # right-continuous read of extracted step polyline
    s = curve[0][1]
    for t, v in curve:
        if t <= a + 1e-9: s = v
    return s

checks = dict(csv_sha256=sha, tolerance=dict(survival_abs=TOL_S, risk_count='exact'), groups={})
for g in ['A', 'B']:
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    cur = ob['observations'][g]['curve']; end = ob['observations'][g]['end']
    drop_t = sorted({c[0] for c in cur[1:]})
    # probe times: fixed grid + just after each 3rd step + tail/end
    probe = sorted(set([0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 28, 30, 33, round(end - 0.01, 4)] +
                       [round(x + 0.005, 4) for x in drop_t[::3]]))
    probe = [x for x in probe if x <= end]
    rk = km(t, e, probe); ms = [meas(cur, x) for x in probe]
    surv = [dict(t=x, measured=round(m, 6), reconstructed=round(r, 6), resid=round(r - m, 6),
                 status='pass' if abs(r - m) <= TOL_S else 'fail') for x, m, r in zip(probe, ms, rk)]
    rt = ob['risk_table']['times']; rv = ob['risk_table'][g]
    riskc = [dict(t=x, displayed=v, reconstructed=int((t >= x).sum()), resid=int((t >= x).sum()) - v,
                  status='pass' if int((t >= x).sum()) == v else 'fail') for x, v in zip(rt, rv)]
    checks['groups'][g] = dict(
        n=dict(expected=man['groups'][g], reconstructed=len(d), status='pass' if len(d) == man['groups'][g] else 'fail'),
        event_indicator_integer_01=bool(set(e) <= {0, 1}),
        events=dict(reconstructed=int(e.sum()), supplied_total='unavailable (not in manifest)'),
        max_time=float(t.max()), curve_end=end, time_nonneg_finite=bool(np.isfinite(t).all() and (t >= 0).all()),
        survival=surv, risk_table=riskc,
        all_pass=all(s['status'] == 'pass' for s in surv + riskc) and len(d) == man['groups'][g])
json.dump(checks, open(os.path.join(out, 'checks.json'), 'w'), indent=1)
for g, c in checks['groups'].items():
    print(g, c['n'], c['events'], 'allpass', c['all_pass'], 'maxresid',
          max(abs(s['resid']) for s in c['survival']), [(r['t'], r['displayed'], r['reconstructed']) for r in c['risk_table']])
print(sha)
