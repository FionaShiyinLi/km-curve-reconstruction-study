"""KM -> participant-level reconstruction from vector PDF (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]
Defaults: ../input and ./output relative to the working directory."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 2076627168
rng = np.random.default_rng(SEED)  # not used for allocation (deterministic), recorded per protocol
inp = sys.argv[1] if len(sys.argv) > 1 else '../input'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
os.makedirs(out, exist_ok=True)
man = json.load(open(os.path.join(inp, 'manifest.json')))
pg = pdfplumber.open(os.path.join(inp, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks (pdf coords, top-down y)
# x ticks at 64.8..410.4 labelled 0..36; y ticks 223.2..43.2 labelled 0..1
xt = sorted({round(l['x0'], 3) for l in pg.lines if abs(l['x0']-l['x1']) < 1e-6 and l['bottom'] > 223 and l['top'] >= 223.1})
yt = sorted({round(l['top'], 3) for l in pg.lines if abs(l['top']-l['bottom']) < 1e-6 and l['x0'] < 62})
xl = np.array([0, 6, 12, 18, 24, 30, 36.]); yl = np.array([1, .8, .6, .4, .2, 0.])
ax, bx = np.polyfit(np.array(xt), xl, 1); ay, by = np.polyfit(np.array(yt), yl, 1)
fx = lambda x: ax*x+bx; fy = lambda y: ay*y+by
calib = dict(x_ticks_pt=xt, y_ticks_pt=yt, x_resid=float(np.abs(np.polyval([ax, bx], xt)-xl).max()),
             y_resid=float(np.abs(np.polyval([ay, by], yt)-yl).max()))

BLUE = (0.121569, 0.466667, 0.705882); ORANGE = (1.0, 0.498039, 0.054902)
col = lambda c: 'A' if tuple(round(v, 6) for v in c) == BLUE else ('B' if tuple(round(v, 6) for v in c) == ORANGE else None)
# legend: blue line next to "Group A", orange next to "Group B" (checked in figure text positions)
curves = {col(c['stroking_color']): [(fx(x), fy(y)) for x, y in c['pts']] for c in pg.curves}
ticks = {'A': [], 'B': []}
for l in pg.lines:
    g = col(l['stroking_color'])
    if g and abs(l['x0']-l['x1']) < 1e-6 and 3.5 < l['bottom']-l['top'] < 4.5:
        ticks[g].append((fx(l['x0']), fy((l['top']+l['bottom'])/2)))
risk_times = [0, 6, 12, 18, 24, 30, 36]
risk = {'A': [100, 66, 42, 28, 23, 5, 0], 'B': [100, 67, 44, 33, 25, 6, 0]}  # read from PDF text layer

def steps(pts):
    """Return list of drops (t, S_before, S_after) and curve end time."""
    drops = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1-t0) < 1e-9 and s1 < s0-1e-7:
            drops.append((t1, s0, s1))
    return drops, pts[-1][0], pts[0][1]

obs, recs, diag = {}, {}, {}
for g in ['A', 'B']:
    N = man['groups'][g]
    drops, tend, s0 = steps(curves[g])
    obs[g] = dict(curve=curves[g], ticks=sorted(ticks[g]), end=tend)
    # infer (n_risk, d) at each drop from exact step ratios: n = d*S_b/(S_b-S_a)
    n_avail = N; rows = []
    for t, sb, sa in drops:
        best = None
        for d in range(1, 11):
            nr = d*sb/(sb-sa); ni = int(round(nr))
            if ni > n_avail or ni < d: continue
            err = abs(nr-ni)
            if err < 0.35 and best is None: best = (d, ni, nr, err)  # smallest d with near-integer n
        if best is None:  # fallback: d=1 capped at availability
            best = (1, n_avail, sb/(sb-sa), float('nan'))
        d, ni, nr, err = best
        rows.append(dict(t=t, S_before=sb, S_after=sa, d=d, n_risk=ni, n_raw=nr, int_err=err,
                         cens_before=n_avail-ni))
        n_avail = ni-d
    tail_cens = n_avail
    diag[g] = rows
    # censoring times: place censorings of each inter-drop interval at visible tick times
    tk = sorted(t for t, _ in ticks[g])
    bounds = [0.0]+[r['t'] for r in rows]
    cens_times = []; unmatched = []
    for i, r in enumerate(rows+[dict(t=np.inf, cens_before=tail_cens)]):
        lo, hi = bounds[i], r['t']
        # ticks on [lo, hi): tick at exact drop time belongs after that drop (censor after event at ties)
        cand = [x for x in tk if lo-1e-6 <= x < hi-1e-6] if np.isfinite(hi) else [x for x in tk if x >= lo-1e-6]
        c = r['cens_before']
        hi_eff = hi if np.isfinite(hi) else tend
        if c <= len(cand):
            # choose c ticks; if fewer censorings than ticks keep ticks spread over interval
            idx = np.round(np.linspace(0, len(cand)-1, c)).astype(int) if c > 0 else []
            cens_times += [cand[j] for j in idx]
            if c < len(cand): unmatched.append(dict(interval=[lo, hi_eff], ticks=len(cand), cens=c))
        else:
            cens_times += cand
            extra = c-len(cand)
            if not np.isfinite(hi):
                # tail: remaining unmarked censorings put at last curve time (end of plotted follow-up)
                cens_times += [tend]*extra
            else:
                cens_times += list(lo+(hi-lo)*(np.arange(extra)+0.5)/extra)
            unmatched.append(dict(interval=[lo, hi_eff], ticks=len(cand), cens=c, extra_unmarked=extra))
    ev = [(r['t'], 1) for r in rows for _ in range(r['d'])]
    rec = ev+[(t, 0) for t in cens_times]
    assert len(rec) == N, (g, len(rec))
    recs[g] = rec
    diag[g] = dict(drops=rows, tail_censored=tail_cens, n_events=sum(r['d'] for r in rows),
                   n_ticks=len(tk), n_censored=len(cens_times), tick_mismatch=unmatched, s_start=s0, curve_end=tend)

df = pd.DataFrame([(g, round(t, 4), e) for g in recs for t, e in recs[g]], columns=['group', 'observed_time', 'event'])
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
tmp = os.path.join(out, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(out, 'ipd.csv'))
json.dump(dict(calibration=calib, observations=obs, risk_table=dict(times=risk_times, **risk)),
          open(os.path.join(out, 'extracted_observations.json'), 'w'), indent=1)
json.dump(diag, open(os.path.join(out, 'reconstruction_diagnostics.json'), 'w'), indent=1, default=float)
for g in diag:
    d = diag[g]; print(g, 'events', d['n_events'], 'cens', d['n_censored'], 'ticks', d['n_ticks'], 'tail', d['tail_censored'])
    print('  max int_err', max(r['int_err'] for r in d['drops']), 'd>1:', [(round(r['t'],3), r['d']) for r in d['drops'] if r['d'] > 1])
    print('  mismatch', d['tick_mismatch'])
print(calib)
