# Reconstruction assumptions and method

**Inputs.** `../input/figure.pdf` (a vector PDF) and `../input/manifest.json` (n = 1000 per arm, time in months, seed 1263834032). The manifest does not give event totals, so none were used; `checks.json` marks that constraint as unavailable. The number-at-risk table was read from the PDF text layer.

**Measurement.** `extract.py` reads the PDF drawing objects directly; no pixels are processed. The arms are identified by the legend line colors: blue is A and orange is B. Each arm is one step-path object. Censor marks are vertical ticks of the same color, 4 pt long. Calibration comes from a least-squares fit to the labelled axis ticks: time = (x − 64.8)/9.6 and S = (223.2 − y)/180. The fit is exact. Both paths start exactly at (0, 1.0), so no origin correction or global rescaling was needed or applied. The raw observations are in `extracted.json`.

**Algorithm (`reconstruct.py`, deterministic).** Each arm starts with n at risk = 1000. For each vertical drop, in time order:
1. Subtract the censor ticks strictly before the drop from the number at risk.
2. Solve d = n·(1 − S_after/S_before), with d required to be an integer.

The code allowed for unticked censorings (up to 30 per interval) where the tick-implied n gave a non-integer d. None were needed. With the tick-implied n, every drop gave an integer d within 5.3e-4 (the maximum residual). All drops were single events; the solved d came out as 1 each time rather than being assumed. d ≥ 2 would require an n larger than the number at risk. Each tick is treated as one censoring at its x position. There are no duplicate tick positions, no ticks at event times, and no tied event times. The minimum spacing between B ticks is 0.0001 months, and those ticks are drawn as separate objects.

Result: A has 775 events and 225 censorings; B has 612 events and 388 censorings. The ticks account for all 2000 participants. No participants were added at the curve end, and no follow-up was invented beyond the last tick, which is at 35.95 months for A and 35.84 for B. The seed is set but never used; there is no stochastic step.

**Checks (`checks.py`, run on the reloaded CSV).** The right-continuous KM was recomputed from the records. At 16 times per arm, including 0, the early part and the tail end, it matches the drawn path with |residual| < 1e-6, against a tolerance of 0.002. Every displayed risk count at 0, 6, …, 36 months is reproduced exactly using the count observed_time ≥ t, including 0 at 36. Arm sizes are 1000 each and event indicators are 0/1. `overlay.png` shows the reconstructed KM over the figure path.

**Limitations.** Times are exact only up to the precision of the PDF coordinates (about 1e-5 months). A censor tick drawn on top of another at the same coordinate would be indistinguishable from a single tick. However, the integer consistency of every drop and the exact risk-table agreement leave no evidence of hidden multiplicity. No material alternative allocation was identified, so no sensitivity analysis was run.
