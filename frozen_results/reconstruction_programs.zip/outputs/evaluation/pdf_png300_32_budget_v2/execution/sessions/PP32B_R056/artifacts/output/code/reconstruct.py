"""KM -> IPD reconstruction from extracted vector observations (own implementation).
Usage: python reconstruct.py [extracted.json] [outdir]
"""
import sys, json, os, hashlib, tempfile
import numpy as np, pandas as pd
SEED = 1263834032
rng = np.random.default_rng(SEED)  # recorded; algorithm below is deterministic
src = sys.argv[1] if len(sys.argv) > 1 else 'output/extracted.json'
outdir = sys.argv[2] if len(sys.argv) > 2 else 'output'
N = json.load(open(sys.argv[3] if len(sys.argv) > 3 else '../input/manifest.json'))['groups']
E = json.load(open(src))
cal = E['calibration']
# least-squares linear calibration from labelled axis ticks
ax = np.polyfit(cal['x_ticks_pt'], cal['x_tick_labels'], 1)
ay = np.polyfit(cal['y_ticks_pt'], cal['y_tick_labels'], 1)
T = lambda x: np.polyval(ax, x)
S = lambda y: np.polyval(ay, y)
TOL = 0.02   # max |d - n(1-r)| accepted as integer (coordinate rounding ~1e-4 pt)
MAXEXTRA = 30
log = {}
def steps(path):
    """Return list of (x, y_before, y_after) vertical drops and final x."""
    drops = []
    for (x0, y0), (x1, y1) in zip(path[:-1], path[1:]):
        if abs(x0 - x1) < 1e-9 and y1 > y0 + 1e-9:
            drops.append((x0, y0, y1))
    # merge consecutive drops at identical x (tied times drawn in pieces)
    m = []
    for d in drops:
        if m and abs(m[-1][0] - d[0]) < 1e-9: m[-1] = (m[-1][0], m[-1][1], d[2])
        else: m.append(d)
    return m, path[-1][0], path[0]
recs = []
for g in ['A', 'B']:
    arm = E['arms'][g]
    drops, xend, p0 = steps(arm['path'])
    ticks = np.array(sorted(t[0] for t in arm['censor_ticks']))
    n = N[g]; s_prev = 1.0; ti = 0; rows = []; info = []
    assert abs(S(p0[1]) - 1) < 1e-9 and abs(T(p0[0])) < 1e-9
    for x, yb, ya in drops:
        # censor ticks strictly before this event time (ticks at the event x are at risk)
        k = ti
        while k < len(ticks) and ticks[k] < x - 1e-6: k += 1
        cens_x = list(ticks[ti:k]); ti = k
        sb, sa = S(yb), S(ya); r = sa / sb
        n0 = n - len(cens_x)
        best = None
        for extra in range(0, MAXEXTRA + 1):   # allow unticked/overlapping censorings
            for sgn in ([0] if extra == 0 else [1, -1]):
                nn = n0 - sgn * extra
                if nn <= 0 or nn > n: continue
                dd = nn * (1 - r); res_ = abs(dd - round(dd))
                if round(dd) >= 1 and res_ < TOL:
                    best = (nn, int(round(dd)), sgn * extra, res_); break
            if best: break
        if best is None:
            nn = n0; dd = max(1, int(round(nn * (1 - r)))); best = (nn, dd, 0, abs(nn*(1-r)-dd))
        nn, dd, extra, res_ = best
        for cx in cens_x: rows.append((T(cx), 0))
        if extra > 0:   # hidden censorings: place at times of last ticks / uniformly in gap
            prev_t = max([r_[0] for r_ in rows], default=0.0)
            for j in range(extra): rows.append((prev_t + (T(x) - prev_t) * (j + 1) / (extra + 1), 0))
        rows += [(T(x), 1)] * dd
        info.append(dict(t=T(x), S_before=sb, S_after=sa, n_risk=nn, d=dd, ticks_before=len(cens_x), extra_cens=extra, resid=res_))
        n = nn - dd; s_prev = sa
    tail = list(ticks[ti:])
    for cx in tail: rows.append((T(cx), 0))
    n_left = N[g] - len(rows)
    log[g] = dict(n_drops=len(drops), n_events=sum(r_[1] for r_ in rows), ticks=len(ticks), tail_ticks=len(tail),
                  left_after_ticks=n_left, t_end=T(xend), max_resid=max(i['resid'] for i in info),
                  n_extra=sum(i['extra_cens'] for i in info), n_neg=sum(i['extra_cens'] < 0 for i in info))
    pd.DataFrame(info).to_csv(f'{outdir}/event_table_{g}.csv', index=False)
    if n_left > 0:  # remaining participants: censored at the last curve x (end of drawn follow-up), flagged
        rows += [(T(xend), 0)] * n_left
    recs += [(g, t, e) for t, e in rows]
print(json.dumps(log, indent=1))
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(5)
fd, tmp = tempfile.mkstemp(dir=outdir, suffix='.tmp'); os.close(fd)
df.to_csv(tmp, index=False); os.replace(tmp, f'{outdir}/ipd.csv')
json.dump(log, open(f'{outdir}/recon_log.json', 'w'), indent=1)
print(df.groupby('group').agg(n=('event', 'size'), ev=('event', 'sum')))
