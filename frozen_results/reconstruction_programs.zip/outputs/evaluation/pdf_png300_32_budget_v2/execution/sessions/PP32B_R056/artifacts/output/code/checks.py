"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve and risk table."""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
E = json.load(open(f'{out}/extracted.json')); cal = E['calibration']
ax = np.polyfit(cal['x_ticks_pt'], cal['x_tick_labels'], 1); ay = np.polyfit(cal['y_ticks_pt'], cal['y_tick_labels'], 1)
df = pd.read_csv(f'{out}/ipd.csv')
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
RISK = {'A': [1000, 689, 475, 336, 222, 71, 0], 'B': [1000, 676, 544, 438, 358, 165, 0]}  # printed table
RT = [0, 6, 12, 18, 24, 30, 36]
def km(d, t):  # right-continuous: S(t) includes events at t
    s = 1.0
    for u in np.sort(d.observed_time[d.event == 1].unique()):
        if u > t: break
        n = (d.observed_time >= u).sum(); k = ((d.observed_time == u) & (d.event == 1)).sum(); s *= 1 - k / n
    return s
def measured(path, t):  # step path value at time t (right-continuous: take lowest y at x<=t)
    P = np.array(path); x = np.polyval(ax, P[:, 0]); y = np.polyval(ay, P[:, 1])
    return float(y[x <= t + 1e-9].min())
TOLS = 0.002  # survival tolerance: well above vector-coordinate rounding (~1e-6) and below one event step at n>=500
C = {'csv_sha256': sha, 'survival_tolerance': TOLS, 'risk_convention': 'count observed_time >= t (events precede censoring at ties)', 'arms': {}}
for g in ['A', 'B']:
    d = df[df.group == g]; P = E['arms'][g]['path']
    tmax = float(np.polyval(ax, P[-1][0]))
    times = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, round(tmax, 4)]
    surv = []
    for t in times:
        m, r = measured(P, t), km(d, t)
        surv.append(dict(t=t, measured=round(m, 6), reconstructed=round(r, 6), resid=round(r - m, 6), status='pass' if abs(r - m) <= TOLS else 'fail'))
    risk = []
    for t, v in zip(RT, RISK[g]):
        r = int((d.observed_time >= t).sum()); risk.append(dict(t=t, displayed=v, reconstructed=r, resid=r - v, status='pass' if r == v else 'fail'))
    C['arms'][g] = dict(n=int(len(d)), n_expected=json.load(open('../input/manifest.json'))['groups'][g],
                        events=int(d.event.sum()), event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
                        supplied_event_total='unavailable (not in manifest)', max_time=float(d.observed_time.max()),
                        survival=surv, risk_table=risk)
json.dump(C, open(f'{out}/checks.json', 'w'), indent=1)
for g in C['arms']:
    a = C['arms'][g]; print(g, a['n'], a['events'], max(abs(s['resid']) for s in a['survival']), [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table']])
