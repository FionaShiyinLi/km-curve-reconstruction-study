#!/bin/sh
# Run from the work directory: sh output/code/run_all.sh [path/to/figure.pdf]
set -e
python3 output/code/extract.py "${1:-../input/figure.pdf}" output/extracted.json
python3 output/code/reconstruct.py output/extracted.json output ../input/manifest.json
python3 output/code/checks.py output
