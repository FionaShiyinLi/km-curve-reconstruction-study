"""Extract KM step paths and censor ticks from the vector PDF; save raw observations."""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output/extracted.json'
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}  # legend line colours
pg = pdfplumber.open(pdf).pages[0]
res = {'calibration': {}, 'arms': {}}
# axis anchors: x ticks at t=0..36 step 6; y ticks at S=0..1 step 0.2
bl = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted({round(l['pts'][0][0], 4) for l in bl if l['pts'][0][0] == l['pts'][1][0] and l['pts'][1][1] > 223.2})
yt = sorted({round(l['pts'][0][1], 4) for l in bl if l['pts'][0][1] == l['pts'][1][1] and l['pts'][0][0] < 64})
res['calibration'] = {'x_ticks_pt': xt, 'x_tick_labels': [0, 6, 12, 18, 24, 30, 36],
                      'y_ticks_pt': yt, 'y_tick_labels': [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]}
for g, col in COL.items():
    cv = [c for c in pg.curves if c['stroking_color'] == col][0]['pts']
    ticks = [[l['pts'][0][0], (l['pts'][0][1] + l['pts'][1][1]) / 2] for l in pg.lines
             if l['stroking_color'] == col and l['linewidth'] == 0.65]
    res['arms'][g] = {'path': [list(p) for p in cv], 'censor_ticks': sorted(ticks)}
json.dump(res, open(out, 'w'))
print({g: (len(a['path']), len(a['censor_ticks'])) for g, a in res['arms'].items()}, xt, yt)
