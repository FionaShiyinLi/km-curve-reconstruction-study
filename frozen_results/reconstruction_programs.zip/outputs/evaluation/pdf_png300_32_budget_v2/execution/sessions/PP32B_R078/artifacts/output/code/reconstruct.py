#!/usr/bin/env python3
"""Reconstruct approximate participant-level records from a raster KM figure.

Usage: python reconstruct.py [--input ../input] [--out output]
Own implementation (pixel extraction + Guyot-style iterative allocation).
No KM-to-IPD package is used.
"""
import argparse, json, os, hashlib
import numpy as np
import pandas as pd
from PIL import Image

SEED = 849950788
np.random.seed(SEED)  # algorithm is deterministic; seed recorded per instructions

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
man = json.load(open(os.path.join(args.input, "manifest.json")))
img = np.asarray(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(int)

# ---------------------------------------------------------------- calibration
# Axis anchors measured from black tick marks (2-px wide): x ticks at columns
# 269/270 (0), 509/510 (6), ..., 1709/1710 (36); y ticks at rows 929/930 (0.0),
# 779/780, ..., 179/180 (1.0). Linear fit on all anchors.
def dark(a): return a.sum(2) < 150
D = dark(img)
xt = [c for c in range(1800) if D[935:942, c].sum() >= 5 and 250 < c < 1720]
xcent = [np.mean(g) for g in np.split(np.array(xt), np.where(np.diff(xt) > 1)[0] + 1)]
yt = [r for r in range(150, 950) if D[r, 258:266].sum() >= 6]
ycent = [np.mean(g) for g in np.split(np.array(yt), np.where(np.diff(yt) > 1)[0] + 1)]
assert len(xcent) == 7 and len(ycent) == 6, (xcent, ycent)
bx = np.polyfit(xcent, np.arange(0, 37, 6), 1)
by = np.polyfit(ycent, np.linspace(0, 1, 6)[::-1], 1)
t_of = lambda x: np.polyval(bx, x)
s_of = lambda y: np.polyval(by, y)
calib = dict(x_anchor_px=xcent, x_anchor_months=list(range(0, 37, 6)),
             y_anchor_px=ycent, y_anchor_surv=list(np.linspace(0, 1, 6)[::-1]),
             months_per_px=bx[0], surv_per_px=by[0],
             x_fit_resid=list(np.polyval(bx, xcent) - np.arange(0, 37, 6)),
             y_fit_resid=list(np.polyval(by, ycent) - np.linspace(0, 1, 6)[::-1]))

COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 692, 485, 334, 221, 69, 0],   # read from the printed table
        "B": [1000, 635, 521, 422, 342, 148, 0]}
TICK_MIN = 13   # a censor mark spans 16-17 px; the plotted line spans 2-5 px


def pava_dec(y, w=None):
    """Isotonic (non-increasing) least-squares fit."""
    y = -np.asarray(y, float); w = np.ones_like(y) if w is None else np.asarray(w, float)
    v, ww, n = [], [], []
    for yi, wi in zip(y, w):
        v.append(yi); ww.append(wi); n.append(1)
        while len(v) > 1 and v[-2] > v[-1]:
            tot = ww[-2] + ww[-1]; v[-2] = (v[-2]*ww[-2] + v[-1]*ww[-1]) / tot
            ww[-2] = tot; n[-2] += n[-1]; v.pop(); ww.pop(); n.pop()
    return -np.repeat(v, n)


def extract(g):
    M = np.abs(img - np.array(COL[g])).sum(2) < 60
    M[:, :268] = False; M[:, 1712:] = False; M[935:, :] = False
    M[:170, :] = False  # exclude legend samples above the plot panel
    rows = []
    for x in range(268, 1712):
        r = np.where(M[:, x])[0]
        if len(r) == 0:
            rows.append((x, np.nan, 0, 0)); continue
        span = r.max() - r.min() + 1
        if span >= TICK_MIN:            # censor-mark column: mark is centred on line
            lvl, tick = (r.min() + r.max()) / 2, 1
        elif span <= 6:
            lvl, tick = (r.min() + r.max()) / 2, 0
        else:                            # vertical drop inside column: take lower level
            lvl, tick = r.max() - 2.0, 0
        rows.append((x, lvl, tick, span))
    df = pd.DataFrame(rows, columns=["px", "row", "tick", "span"])
    df["t"] = t_of(df.px); df["S_raw"] = s_of(df.row)
    df = df[df.row.notna()].reset_index(drop=True)
    # isotonic non-increasing fit (not a running minimum) for event allocation
    df["S_iso"] = np.minimum(pava_dec(df.S_raw.values), 1.0)
    # tick blocks -> censor mark positions and a visual width
    tk = df[df.tick == 1].px.values
    blocks = np.split(tk, np.where(np.diff(tk) > 1)[0] + 1) if len(tk) else []
    marks = pd.DataFrame([dict(px_start=b[0], px_end=b[-1], width=len(b),
                               t=t_of((b[0] + b[-1]) / 2)) for b in blocks])
    return df, marks


curves, marks = {}, {}
for g in "AB":
    curves[g], marks[g] = extract(g)
    curves[g].to_csv(os.path.join(args.out, f"extracted_curve_{g}.csv"), index=False)
    marks[g].to_csv(os.path.join(args.out, f"censor_marks_{g}.csv"), index=False)
# single-mark width = modal width of isolated marks
TICK_W = int(pd.concat([marks[g].width for g in "AB"]).mode().iloc[0])


def censor_times(c, lo, hi, mk, mode):
    """Place c censorings in [lo, hi) using visible marks."""
    if c <= 0: return []
    m = mk[(mk.t >= lo) & (mk.t < hi)]
    if len(m) == 0:
        return list(lo + (np.arange(c) + 0.5) * (hi - lo) / c)
    ts = m.t.values
    if mode == "primary":
        mult = np.maximum(1, np.round(m.width.values / TICK_W)).astype(int)
    else:
        mult = np.ones(len(m), int)
    base = np.repeat(ts, mult)
    if c <= len(base):          # fewer censorings than visible marks: even subset
        idx = np.round(np.linspace(0, len(base) - 1, c)).astype(int)
        return list(base[idx])
    extra = c - len(base)
    if mode == "primary":       # surplus assigned to marks in proportion to multiplicity
        idx = np.round(np.linspace(0, len(base) - 1, extra)).astype(int) if extra > 1 else [len(base)//2]
        return list(base) + list(base[idx])
    # sensitivity: surplus spread uniformly over the interval
    return list(base) + list(lo + (np.arange(extra) + 0.5) * (hi - lo) / extra)


def reconstruct(g, mode):
    df, mk, nr = curves[g], marks[g], RISK[g]
    tt, SS = df.t.values, df.S_iso.values
    recs, S_hat, n_start = [], 1.0, nr[0]
    t_end = min(tt.max() + 1e-9, RISK_T[-1] - 1e-6)
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        hi_eff = min(hi, t_end + 1e-6)
        sel = (tt >= lo) & (tt < hi)
        tj, Sj = tt[sel], SS[sel]
        target = nr[k + 1]
        c = max(0, n_start - target - int(round(n_start * (1 - Sj[-1] / S_hat))) if len(Sj) else 0)
        for it in range(200):
            ct = np.sort(censor_times(c, lo, hi_eff, mk, mode))
            n, Sh, ev, ci = n_start, S_hat, [], 0
            for t, s in zip(tj, Sj):
                while ci < len(ct) and ct[ci] < t:  # censored strictly before t
                    n -= 1; ci += 1
                d = int(round(n * (1 - s / Sh))) if Sh > 0 and n > 0 else 0
                d = max(0, min(d, n))
                if d:
                    ev += [t] * d; Sh *= 1 - d / n; n -= d
            n -= len(ct) - ci
            if n == target or it == 199: break
            c = max(0, c + (n - target))
            if n < target and c == 0: break
        recs += [(g, t, 1) for t in ev] + [(g, t, 0) for t in ct]
        S_hat, n_start = Sh, n
    out = pd.DataFrame(recs, columns=["group", "observed_time", "event"])
    return out, n_start


def km(times, events):
    o = np.lexsort((1 - events, times)); t, e = times[o], events[o]
    ut = np.unique(t[e == 1]); S, s = [], 1.0
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n; S.append(s)
    return ut, np.array(S)


def km_at(ut, S, x):
    i = np.searchsorted(ut, x, side="right") - 1
    return 1.0 if i < 0 else S[i]


def commit(df, path):
    tmp = path + ".tmp"
    df.to_csv(tmp, index=False, float_format="%.4f"); os.replace(tmp, path)


results = {}
for mode, fname in [("primary", "ipd.csv"), ("sensitivity", "sensitivity.csv")]:
    parts = []
    for g in "AB":
        r, left = reconstruct(g, mode)
        assert len(r) == man["groups"][g], (g, mode, len(r), left)
        parts.append(r)
    ipd = pd.concat(parts, ignore_index=True)
    assert (ipd.observed_time >= 0).all() and np.isfinite(ipd.observed_time).all()
    commit(ipd, os.path.join(args.out, fname))
    results[mode] = pd.read_csv(os.path.join(args.out, fname))   # reload committed file

# ---------------------------------------------------------------- checks
ipd = results["primary"]
sha = hashlib.sha256(open(os.path.join(args.out, "ipd.csv"), "rb").read()).hexdigest()
TOL_S = 0.01  # ~7.5 px; line width 2-5 px plus column-level step discretisation
chk = dict(csv_sha256=sha, seed=SEED, calibration=calib, tick_width_px=TICK_W,
           survival_tolerance=TOL_S,
           tolerance_note="line centre measurable to ~+-2 px (0.003); tolerance allows "
                          "for integer-event rounding at low risk sets in tails",
           arms={})
check_t = [0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.9]
for g in "AB":
    d = ipd[ipd.group == g]
    ut, S = km(d.observed_time.values, d.event.values)
    cv = curves[g]
    surv = []
    for t in check_t:
        # measured raw value: median of raw column values within +-2 px of t
        w = cv[(cv.t > t - 0.05) & (cv.t <= t)]
        meas = float(np.median(w.S_raw)) if len(w) else None
        rec = km_at(ut, S, t)
        surv.append(dict(t=t, measured=meas, reconstructed=round(rec, 4),
                         resid=None if meas is None else round(rec - meas, 4),
                         status="unavailable" if meas is None else
                         ("pass" if abs(rec - meas) <= TOL_S else "fail")))
    risk = []
    for t, n in zip(RISK_T, RISK[g]):
        m = int((d.observed_time >= t).sum())
        risk.append(dict(t=t, displayed=n, reconstructed=m, resid=m - n,
                         status="pass" if m == n else "fail"))
    raw_dev = (np.array([km_at(ut, S, t) for t in cv.t]) - cv.S_raw.values)
    chk["arms"][g] = dict(
        n=int(len(d)), n_expected=man["groups"][g], n_status="pass" if len(d) == man["groups"][g] else "fail",
        events=int(d.event.sum()), censored=int((d.event == 0).sum()),
        event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
        supplied_event_total="unavailable (not in manifest)",
        max_time=float(d.observed_time.max()),
        visible_censor_mark_blocks=int(len(marks[g])),
        survival_checks=surv, risk_checks=risk,
        all_columns_max_abs_dev_vs_raw=round(float(np.abs(raw_dev).max()), 4),
        all_columns_mean_abs_dev_vs_raw=round(float(np.abs(raw_dev).mean()), 4))

# sensitivity comparison at common supported horizon
H = float(min(ipd.observed_time.max(), results["sensitivity"].observed_time.max(), 35.9))
def rmst(ut, S, h):
    grid = np.concatenate([[0], ut[ut < h], [h]]); vals = [km_at(ut, S, x) for x in grid[:-1]]
    return float(np.sum(np.diff(grid) * vals))
sens = dict(horizon_months=H, arms={})
for g in "AB":
    row = {}
    for mode in ["primary", "sensitivity"]:
        d = results[mode][results[mode].group == g]
        ut, S = km(d.observed_time.values, d.event.values)
        row[mode] = dict(S_at_12=round(km_at(ut, S, 12), 4), S_at_24=round(km_at(ut, S, 24), 4),
                         S_at_H=round(km_at(ut, S, H), 4), area_to_H=round(rmst(ut, S, H), 3),
                         events=int(d.event.sum()))
    sens["arms"][g] = row
chk["sensitivity_comparison"] = sens
json.dump(chk, open(os.path.join(args.out, "checks.json"), "w"), indent=1, default=float)
print(json.dumps({g: {k: v for k, v in chk["arms"][g].items() if k not in ("survival_checks",)}
                  for g in "AB"}, indent=1, default=float))
for g in "AB":
    print(g, [(s["t"], s["measured"] and round(s["measured"], 4), s["reconstructed"], s["status"])
              for s in chk["arms"][g]["survival_checks"]])
print(json.dumps(sens, indent=1))
print("calib", calib["months_per_px"], calib["surv_per_px"], "tickw", TICK_W)
