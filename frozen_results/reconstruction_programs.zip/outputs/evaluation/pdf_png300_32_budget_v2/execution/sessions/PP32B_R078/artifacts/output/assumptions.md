# Reconstruction assumptions and limitations

**Inputs used.** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json`: n = 1000 per arm, time in months, seed 849950788. I read the risk table visually from the figure: A 1000/692/485/334/221/69/0 and B 1000/635/521/422/342/148/0 at 0, 6, …, 36 months. The manifest gives no arm-specific event totals, so that check is marked unavailable. That is not taken to mean zero events. Source: `code/reconstruct.py`. Run it as `python output/code/reconstruct.py --input ../input --out output`. It is deterministic, and the seed is set and recorded anyway.

**Calibration.** Time and survival are linear fits to the labelled black axis ticks: x at columns 269.5 to 1709.5 for 0 to 36 months (0.025 months/px), and y at rows 929.5 to 179.5 for 0 to 1 (0.00133/px). Fit residuals are 0. No global rescaling was applied to either arm.

**Curve measurement.** Pixels are classified by exact line color (A blue, B orange), restricted to the plot panel; the legend is excluded. Each column is then handled as follows:
- A column spanning 13 px or more is a censor mark (marks are 16–17 px tall and centered on the line). The level is the mark's center.
- A column spanning 6 px or less is line only. The level is the line's center.
- Anything in between contains a vertical drop. The level is the lower level (right-continuous).

A non-increasing isotonic fit (PAVA; not a running minimum) removes pixel jitter, and the reconstruction uses that fit. Raw values are in `extracted_curve_{A,B}.csv`, and the detected mark blocks are in `censor_marks_{A,B}.csv`.

I remeasured the origin locally. B has a real vertical segment at t ≈ 0.01, from the 1.0 level (row 178) down to row 185. That is about a 0.005 drop, which the reconstruction keeps as 5 events. A starts about 1 px below 1.0 and has its first event at 0.14 months. Columns left of the y-axis (line caps) are ignored.

**Algorithm.** I implemented a Guyot-style iterative allocation myself. For each risk-table interval [t_k, t_{k+1}):
1. Place a proposed number of censorings c at the censor-mark positions in the interval.
2. Walk the columns in time order. At each column, set d = round(n_risk·(1 − S_meas/Ŝ)), where Ŝ is the reconstructed KM so far. Because Ŝ is the reconstruction rather than the measured curve, rounding errors correct themselves instead of accumulating. d is not fixed at 1; a column can carry several tied events.
3. Adjust c until the number at risk at t_{k+1} equals the printed count.

Events are timed at the column where the drop appears, so times are quantized to 0.025 months. Censorings sit at the mark centers. At tied times, events are counted before censorings.

**Censoring.** How many censorings fall in each interval comes from the risk table. Where they go within the interval comes from the visible marks. Mark visibility is not mark multiplicity: overlapping marks hide counts. Primary rule (assumption): a mark block gets multiplicity round(width / 3 px), with a minimum of 1. If the interval needs more censorings than that, the surplus is spread over the marks in proportion to their multiplicity. If it needs fewer, an evenly spaced subset of marks is used.

In the last interval, the printed 0 at 36 months means everyone left after the last event is censored at a visible mark before 36. The latest times are A 35.925 and B 35.875, which is where the curves end. I did not infer any accrual pattern or event-free follow-up beyond what the marks and the risk table show.

**Checks** (`checks.json`, which records the SHA-256 of the final CSV):
- The saved CSV was reloaded and the right-continuous KM recomputed from it.
- Survival was compared at 17 times from 0.5 to 35.9 months, tails included. All pass at a tolerance of 0.01 (roughly the line width plus integer rounding in the small tail risk sets). Maximum absolute deviation over all columns is 0.004 for A and 0.0075 for B.
- Counting records with time ≥ t reproduces every printed risk count exactly, including 0 at 36.
- Group sizes are 1000 and 1000, and event indicators are integer 0/1.
- Totals: A has 799 events and 201 censorings; B has 634 events and 366 censorings.

**Sensitivity** (`sensitivity.csv`, one alternative). Each visible mark counts as exactly one censoring, and any surplus is spread uniformly over the interval. Compared over the common supported horizon of 35.9 months:

| Arm | S(35.9) primary vs alternative | Area under curve to 35.9 (months) | Events |
|---|---|---|---|
| A | 0.1288 vs 0.1263 | 14.972 vs 14.965 | 799 vs 803 |
| B | 0.2559 vs 0.2530 | 18.077 vs 18.080 | 634 vs 634 |

Survival at 12 and 24 months differs by 0.001 or less. This is one alternative, not an interval or a bound on reconstruction error.

**Limitations.**
- The original records cannot be uniquely recovered from the figure.
- Censoring times inside each interval, and the split of dense or overlapping marks, rest on the assumption above.
- Event times carry about ±0.0125-month quantization.
- Near the crossing (about 7.5 months) and the origin, one color can partly cover the other. Those columns are measured from whichever pixels remain visible.
- The risk-table numbers are read visually. They are clear, crisp text, so I treat them as certain.
- There was one primary correction cycle: the first committed file had picked up the legend samples as curve pixels. I fixed that and regenerated every output and check from the final CSV.
