# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster KM figure with number-at-risk table) and `../input/manifest.json`
  (n = 100 per group, time in months, code seed 530912982). The manifest has no arm-specific event
  totals, so event counts come only from the curve and the risk table. No event-total check was possible
  (marked `unavailable` in checks.json).
- Risk table was read visually: A 100/64/40/28/21/6/0 and B 100/73/53/40/29/16/0 at 0, 6, ..., 36 months.
  The numbers are cleanly rendered and I consider them unambiguous.

## Pipeline (run from the work directory)
`python output/code/extract.py` -> `output/digitized.json`;
`python output/code/reconstruct.py` -> `output/ipd.csv` (primary);
`python output/code/reconstruct.py --alt` -> `output/sensitivity.csv`;
`python output/code/check.py` -> `output/checks.json`. All paths can be passed as arguments.
The procedure is deterministic. The seed is set and recorded, but no random draws are used.

## Measurement
- Calibration: linear fits to the 7 labeled x-axis tick marks (0-36 months, 40 px/month) and the 6 labeled
  y-axis ticks (0-1, 750 px/unit), with zero residual. No global transform beyond this.
- Curves isolated by their exact plot colors. The survival level in each column is the center of the lowest
  horizontal run at least 5 px wide (line width 4 px). Drops are level changes of more than 1 px. Drops closer than 4 px
  (0.1 month) are merged into one drop, keeping the total drop; this removes antialias/split artifacts.
- Origin: Group B (orange) is drawn over Group A near t = 0, so A's measured start was 0.998. Only that first
  level was reset to 1.0 (the KM origin). A's first measured step (to 0.99 at ~0.33-0.45 month) is kept as a
  genuine early drop. No rescaling or running minimum was applied elsewhere. Group A has 10 columns with the level
  hidden by B; the level there was carried forward.
- Censor ticks: narrow marks extending at least 4 px above and below the line. I added marks extending only
  above the pre-drop level at a drop (tick drawn just before an event). After inspecting zoomed crops
  (`output/zoom_check.png`), I rejected detector hits in A at 1.45, 3.21 and 3.58 months (no tick visible;
  adjacent drop segments). Tick visibility does not establish multiplicity: overlapping ticks cannot be
  counted from the image. Some ticks in the crowded early part of B (e.g., near 2.5 months) were not
  detected. In those intervals the censoring count is still set by the risk table; only its timing is
  approximated.

## Reconstruction algorithm (own implementation, Guyot-type)
For each risk-table interval [t_k, t_{k+1}), starting from the displayed n at t_k:
1. Proposed censoring count c = number of visible ticks in the interval, at the tick times.
2. Events at each measured drop: d = round(n_risk * (1 - S_meas_after / S_hat_before)), where S_hat is the
   reconstructed KM so far. This avoids assuming d = 1 per drop and prevents rounding drift. Events precede
   censorings at tied times.
3. c is adjusted until the number still at risk at t_{k+1} equals the displayed count. When c exceeds the
   visible ticks, the extra censorings are spread uniformly over the interval, capped at the curve's last
   plotted time (**assumption**). If c were smaller than the number of ticks, ticks would be thinned evenly;
   this did not occur.
All 12 interval counts matched exactly. Results: A has 79 events and 21 censored (max follow-up 35.68 months);
B has 72 events and 28 censored (max 34.71 months). The zero at-risk count at 36 is honored: every record has
time < 36, with the last censorings at each curve's final tick.

Unobserved features are not identified. These include censoring times between visible ticks, possible
multiple ticks at one pixel, and exact event times within a drop's 1-2 px column. The flat tails do not
identify the censoring distribution or accrual. The reconstruction is one feasible approximation, not a
unique recovery, and no error bound is claimed.

## Checks (output/checks.json, regenerated from the final CSV; SHA-256 recorded there)
- Arm sizes 100/100 and event indicators in {0,1}: pass. The risk table (count of observed_time >= t) matches
  exactly at all 7 times for both arms.
- I recomputed the right-continuous KM from the reloaded CSV and compared it with the measured level at 18
  times per arm, from the start through the tail (A to 35.46, B to 34.51 months). The maximum
  |residual| is 0.0024 for A and 0.0038 for B, against a tolerance of 0.01 (4 px line width plus
  integer-event granularity); all pass. Measured values are taken from columns more than 0.1 month from a
  vertical drop segment, where the level is ill-defined because of line caps. For this reason the nominal
  check times 0.5 and 1 month for A were evaluated at 0.56/0.59 months (dense early drops). This sampling
  rule was introduced after a first run in which 3 A checks failed only because the sampled column lay
  within 2 px of a drop. The tolerance was not changed.
- Residual B tail offset (reconstructed 0.1958 vs measured 0.192 after 32 months): this reflects integer-event
  rounding with 16 or fewer at risk and is within the line width.

## Sensitivity (one alternative, output/sensitivity.csv)
Alternative assumption: censorings not explained by visible ticks are placed as extra multiplicity on the
visible ticks of the same interval instead of uniformly. Common horizon: 34.5 months, within both curves'
support. Survival probability S(t) at 34.5 months, primary vs alternative: A 0.1717 vs 0.1711, B 0.1958 vs 0.1946.
Restricted mean survival time (area under the curve, 0-34.5 months): A 13.541 vs 13.535, B 17.097 vs
17.092. S(t) at 6, 12, 18 and 24 months is identical. Differences arise only in the censoring-heavy intervals after
24 months, where extra censorings shift the at-risk counts at later drops. This single alternative is not a confidence interval
and does not bound total reconstruction error. The primary was chosen before the comparison, using the
standard uniform-within-interval assumption.
