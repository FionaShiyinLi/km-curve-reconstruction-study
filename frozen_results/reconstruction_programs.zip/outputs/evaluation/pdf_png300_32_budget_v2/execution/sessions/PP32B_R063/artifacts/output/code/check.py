"""Reload committed CSV, recompute right-continuous KM, compare with measured curve and risk table.

Usage: python check.py [ipd.csv] [digitized.json] [checks.json] [sensitivity.csv]
"""
import sys, json, hashlib, os
import numpy as np
import pandas as pd

CSV = sys.argv[1] if len(sys.argv) > 1 else "output/ipd.csv"
DIG = sys.argv[2] if len(sys.argv) > 2 else "output/digitized.json"
OUT = sys.argv[3] if len(sys.argv) > 3 else "output/checks.json"
SENS = sys.argv[4] if len(sys.argv) > 4 else "output/sensitivity.csv"
N = {"A": 100, "B": 100}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 64, 40, 28, 21, 6, 0], "B": [100, 73, 53, 40, 29, 16, 0]}
TOL_S = 0.01   # ~7.5 px at 750 px/unit: line width 4 px + one-step granularity (~1/n_risk) near tails


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; out.append((u, s))
    return out


def S_at(steps, x):  # right-continuous step function
    s = 1.0
    for u, v in steps:
        if u <= x:
            s = v
        else:
            break
    return s


def measured_at(samples, x, drop_t):
    # nearest sampled column level (every image column, 0.025 mo) that is > 4 px (0.1 mo) from
    # any vertical drop segment, where the measured level is ill-defined; no interpolation of KM
    ts = np.array([p["t"] for p in samples]); ss = np.array([p["s"] for p in samples])
    far = np.array([np.min(np.abs(np.array(drop_t) - t)) > 0.1 for t in ts])
    i = np.argmin(np.where(far, abs(ts - x), np.inf))
    return float(ss[i]), float(ts[i])


def rmst(steps, tau):
    grid = [0.0] + [u for u, _ in steps if u < tau] + [tau]
    area = 0.0
    for a, b in zip(grid[:-1], grid[1:]):
        area += S_at(steps, a) * (b - a)
    return area


def main():
    df = pd.read_csv(CSV)
    sha = hashlib.sha256(open(CSV, "rb").read()).hexdigest()
    dig = json.load(open(DIG))
    res = dict(csv=CSV, sha256=sha, tolerance_survival=TOL_S,
               tolerance_note="measurement tolerance 0.01 survival (~7.5 px): 4-px line width, sampling "
                              "offset of up to 0.125 mo from the check time, integer-event granularity",
               arms={})
    for g in "AB":
        d = df[df.group == g]
        steps = km(d)
        arm = dig["arms"][g]
        r = dict(n=int(len(d)), n_expected=N[g], n_pass=bool(len(d) == N[g]),
                 event_indicator_integer_01=bool(set(d.event.unique()) <= {0, 1}),
                 events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                 supplied_event_total="unavailable (not in manifest)",
                 max_time=float(d.observed_time.max()), curve_end_measured=arm["t_end"])
        checks = []
        tpts = [0.5, 1, 2, 3, 4.5, 6, 8, 10, 12, 15, 18, 21, 24, 27, 30, 32, 33, arm["t_end"] - 0.2]
        for x in tpts:
            ms, mt = measured_at(arm["level_samples"], x, [q["t"] for q in arm["drops"]])
            rs = S_at(steps, mt)
            checks.append(dict(t=round(mt, 3), measured=round(ms, 4), reconstructed=round(rs, 4),
                               residual=round(rs - ms, 4), status="pass" if abs(rs - ms) <= TOL_S else "fail"))
        r["curve_checks"] = checks
        rk = []
        for t, n in zip(RISK_T, RISK[g]):
            c = int((d.observed_time >= t).sum())
            rk.append(dict(t=t, displayed=n, reconstructed=c, residual=c - n,
                           status="pass" if c == n else "fail"))
        r["risk_checks"] = rk
        r["rmst_to_34.5"] = round(rmst(steps, 34.5), 4)
        res["arms"][g] = r
    if os.path.exists(SENS):
        sd = pd.read_csv(SENS); tau = 34.5
        comp = dict(file=SENS, sha256=hashlib.sha256(open(SENS, "rb").read()).hexdigest(),
                    common_horizon_months=tau, arms={})
        for g in "AB":
            p, s = km(df[df.group == g]), km(sd[sd.group == g])
            comp["arms"][g] = dict(
                S_primary={t: round(S_at(p, t), 4) for t in [6, 12, 18, 24, 30, tau]},
                S_sensitivity={t: round(S_at(s, t), 4) for t in [6, 12, 18, 24, 30, tau]},
                rmst_primary=round(rmst(p, tau), 4), rmst_sensitivity=round(rmst(s, tau), 4))
        res["sensitivity_comparison"] = comp
    else:
        res["sensitivity_comparison"] = "not run"
    json.dump(res, open(OUT, "w"), indent=1)
    for g in "AB":
        r = res["arms"][g]
        print(g, "n", r["n"], "events", r["events"], "max", r["max_time"])
        print("  curve fails:", [(c["t"], c["measured"], c["reconstructed"]) for c in r["curve_checks"] if c["status"] != "pass"])
        print("  max|res|", max(abs(c["residual"]) for c in r["curve_checks"]))
        print("  risk:", [(c["t"], c["displayed"], c["reconstructed"]) for c in r["risk_checks"]])
    if isinstance(res["sensitivity_comparison"], dict):
        print(json.dumps(res["sensitivity_comparison"]["arms"]))


if __name__ == "__main__":
    main()
