"""Reconstruct approximate IPD from digitized KM curves + number-at-risk table.

Usage: python reconstruct.py [digitized.json] [figure.png] [out.csv] [--alt]
  default: output/digitized.json ../input/figure.png output/ipd.csv
  --alt  : sensitivity allocation (censorings not explained by visible ticks are placed as
           extra multiplicity on the visible ticks of the interval instead of spread uniformly).
Deterministic; seed 530912982 is set and recorded although no random draws are used.
"""
import sys, json, os, tempfile
import numpy as np
from PIL import Image

SEED = 530912982
np.random.seed(SEED)

args = [a for a in sys.argv[1:] if not a.startswith("--")]
ALT = "--alt" in sys.argv
DIG = args[0] if len(args) > 0 else "output/digitized.json"
FIG = args[1] if len(args) > 1 else "../input/figure.png"
OUTCSV = args[2] if len(args) > 2 else ("output/sensitivity.csv" if ALT else "output/ipd.csv")

N = {"A": 100, "B": 100}                      # manifest
RISK_T = [0, 6, 12, 18, 24, 30, 36]           # read from the figure's risk table
RISK = {"A": [100, 64, 40, 28, 21, 6, 0],
        "B": [100, 73, 53, 40, 29, 16, 0]}
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
# Candidate ticks rejected after visual inspection of zoomed crops (dense early region where the
# detector fired on adjacent drop segments / other-arm overlap; no tick visible).
REJECT_TICKS = {"A": [1.45, 3.21, 3.58], "B": []}
MERGE_PX = 4                                  # drops closer than this (0.1 mo) are one drop


def load(g, dig, a):
    cal = dig["calibration"]
    px, py = cal["time_per_px"], cal["surv_per_px"]
    arm = dig["arms"][g]
    # merge near-coincident drops (antialias / 1px split artefacts)
    drops = []
    for d in arm["drops"]:
        if drops and d["x"] - drops[-1]["x_last"] < MERGE_PX:
            drops[-1]["s_after"] = d["s_after"]; drops[-1]["x_last"] = d["x"]
        else:
            drops.append(dict(t=d["t"], s_before=d["s_before"], s_after=d["s_after"], x=d["x"], x_last=d["x"]))
    # origin: the start of A is partly covered by B (drawn on top); KM starts at 1 by definition,
    # so only the first level is remeasured as 1.0 when it is within 0.005 of 1 (no global rescale)
    if drops and abs(drops[0]["s_before"] - 1) < 0.005:
        drops[0]["s_before"] = 1.0
    ticks = [t["t"] for t in arm["ticks"]
             if not any(abs(t["t"] - r) < 0.03 for r in REJECT_TICKS[g])]
    # additional ticks drawn at the upper level just before/at a drop: pixels >=5px above the
    # pre-drop line within +-3 columns of the drop (vertical drop segment lies below that line)
    m = np.abs(a - np.array(COLORS[g])).sum(2) < 60
    s2y = lambda s: (s - py[1]) / py[0]
    for d in drops:
        yb = int(round(s2y(d["s_before"])))
        x = int(round(d["x"]))
        cols = [c for c in range(x - 4, x + 2) if m[yb - 9:yb - 3, c].sum() >= 5]
        # exclude columns where the previous drop's vertical segment sits (that also lies above)
        prev = [p for p in drops if p["x"] < d["x"] and d["x"] - p["x_last"] < 8]
        if cols and not prev:
            tt = float(np.polyval(px, np.mean(cols)))
            if not any(abs(tt - t) < 0.1 for t in ticks):
                ticks.append(tt)
    ticks = sorted(ticks)
    return drops, ticks, arm["t_end"]


def allocate(c, tks, lo, hi):
    """censoring times for c censorings in [lo,hi) given visible tick times tks"""
    tks = sorted(tks)
    if c <= 0:
        return []
    if c <= len(tks):
        if c == len(tks):
            return list(tks)
        idx = np.round(np.linspace(0, len(tks) - 1, c)).astype(int)  # conflict: fewer than ticks
        return [tks[i] for i in idx]
    extra = c - len(tks)
    if ALT and tks:
        out = list(tks) + [tks[i % len(tks)] for i in np.round(np.linspace(0, len(tks) - 1, extra)).astype(int)]
    else:
        L = hi - lo
        out = list(tks) + [lo + (j + 0.5) * L / extra for j in range(extra)]
    return sorted(out)


def simulate(n0, drops, cens, s_hat0):
    """KM-consistent event counts: d = round(n_risk*(1 - S_meas_after/S_hat_before))."""
    n, s_hat = n0, s_hat0
    ev, ci = [], 0
    cens = sorted(cens)
    for d in drops:
        while ci < len(cens) and cens[ci] < d["t"]:   # events precede censorings at ties
            n -= 1; ci += 1
        if n <= 0:
            ev.append(0); continue
        k = int(round(n * (1 - d["s_after"] / s_hat)))
        k = max(0, min(n, k))
        ev.append(k)
        s_hat *= (1 - k / n); n -= k
    n -= len(cens) - ci
    return ev, n, s_hat


def reconstruct(g, drops, ticks, t_end, log):
    recs = []
    n_start, s_hat = RISK[g][0], 1.0
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        hi_eff = min(hi, t_end)
        dk = [d for d in drops if lo <= d["t"] < hi]
        tk = [t for t in ticks if lo <= t < hi and t <= t_end + 1e-9]
        target = RISK[g][k + 1]
        c = len(tk)
        seen = set()
        for it in range(100):
            cens = allocate(c, tk, lo, hi_eff)
            ev, n_end, s_new = simulate(n_start, dk, cens, s_hat)
            if n_end == target or (c, n_end) in seen:
                break
            seen.add((c, n_end))
            c = max(0, c + (n_end - target))
        status = "matched" if n_end == target else "unmatched"
        log.append(dict(group=g, interval=[lo, hi], n_start=n_start, risk_next=target, n_end=int(n_end),
                        events=int(sum(ev)), censored=len(cens), visible_ticks=len(tk), status=status))
        for d, e in zip(dk, ev):
            recs += [(g, round(d["t"], 4), 1)] * e
        recs += [(g, round(t, 4), 0) for t in cens]
        n_start, s_hat = n_end, s_new
    if n_start > 0:   # should not happen when the final risk count (0) is matched
        log.append(dict(group=g, note="%d left after last interval; censored at curve end" % n_start))
        recs += [(g, round(t_end, 4), 0)] * n_start
    return recs


def main():
    dig = json.load(open(DIG))
    a = np.asarray(Image.open(FIG).convert("RGB")).astype(int)
    log, allrec, used = [], [], {}
    for g in "AB":
        drops, ticks, t_end = load(g, dig, a)
        used[g] = dict(drops=[dict(t=d["t"], s_before=d["s_before"], s_after=d["s_after"]) for d in drops],
                       ticks=ticks, t_end=t_end)
        r = reconstruct(g, drops, ticks, t_end, log)
        assert len(r) == N[g], (g, len(r))
        allrec += r
    base = os.path.dirname(OUTCSV) or "."
    fd, tmp = tempfile.mkstemp(dir=base, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in allrec:
            f.write("%s,%.4f,%d\n" % (g, t, e))
    os.replace(tmp, OUTCSV)
    tag = "sensitivity" if ALT else "primary"
    json.dump(dict(seed=SEED, allocation=tag, intervals=log, used_observations=used),
              open(os.path.join(base, "reconstruction_log_%s.json" % tag), "w"), indent=1)
    for l in log:
        print(l)


if __name__ == "__main__":
    main()
