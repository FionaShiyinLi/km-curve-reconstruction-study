"""Digitize the two KM step curves and censor ticks from the raster figure.

Usage: python extract.py [path/to/figure.png] [outdir]
Defaults: ../input/figure.png, output/
Calibration comes from axis tick marks detected in the image (see calibrate()).
"""
import sys, json, os
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
LINE_W = 4  # px, measured from the figure


def load():
    return np.asarray(Image.open(FIG).convert("RGB")).astype(int)


def calibrate(a):
    dark = a.sum(2) < 200
    # x-axis ticks: short dark marks just below the axis line (rows 935-945)
    r = dark[935:945].sum(0)
    xs = [i for i in range(len(r)) if r[i] > 5 and i > 250]
    # group adjacent columns
    groups = []
    for i in xs:
        if groups and i - groups[-1][-1] <= 1:
            groups[-1].append(i)
        else:
            groups.append([i])
    xc = [np.mean(g) for g in groups]  # labels 0,6,...,36
    c = dark[:, 255:268].sum(1)
    ys = [i for i in range(len(c)) if c[i] > 5]
    g2 = []
    for i in ys:
        if g2 and i - g2[-1][-1] <= 1:
            g2[-1].append(i)
        else:
            g2.append([i])
    yc = [np.mean(g) for g in g2]  # labels 1.0,0.8,...,0.0 top to bottom
    tlab = np.arange(0, 37, 6)
    slab = np.array([1.0, 0.8, 0.6, 0.4, 0.2, 0.0])
    assert len(xc) == len(tlab) and len(yc) == len(slab), (xc, yc)
    px = np.polyfit(xc, tlab, 1)
    py = np.polyfit(yc, slab, 1)
    resx = np.polyval(px, xc) - tlab
    resy = np.polyval(py, yc) - slab
    return px, py, dict(x_anchor_px=list(map(float, xc)), y_anchor_px=list(map(float, yc)),
                        max_abs_resid_time=float(abs(resx).max()), max_abs_resid_surv=float(abs(resy).max()))


def mask(a, col, occl=None):
    m = np.abs(a - np.array(col)).sum(2) < 60
    m[:150] = False
    m[935:] = False
    m[:, :265] = False
    return m


def horiz(m):
    """pixels that belong to horizontal runs >= 5 px wide"""
    h = np.zeros_like(m)
    for k in range(-4, 1):
        ok = np.ones_like(m)
        for j in range(5):
            ok &= np.roll(m, -(k + j), axis=1)
        h |= ok
    return h


def bands(col):
    """list of (top,bottom) runs of True in a column"""
    ys = np.flatnonzero(col)
    if len(ys) == 0:
        return []
    out, s = [], ys[0]
    for p, q in zip(ys[:-1], ys[1:]):
        if q != p + 1:
            out.append((s, p)); s = q
    out.append((s, ys[-1]))
    return out


def extract(a, g, other=None):
    m = mask(a, COLORS[g])
    h = horiz(m)
    xs = np.flatnonzero(m.any(0))
    x0, x1 = xs.min(), xs.max()
    # per column lowest horizontal band centre (step curve is non-increasing -> lowest band is the
    # level after any drop in that column)
    level = np.full(a.shape[1], np.nan)
    for x in range(x0, x1 + 1):
        b = bands(h[:, x])
        if b:
            t, bt = b[-1]
            level[x] = (t + bt) / 2 if bt - t + 1 >= LINE_W - 1 else (bt - (LINE_W - 1) / 2)
    return m, h, level, x0, x1


def ticks(m, level, x0, x1):
    """Censor ticks: narrow (~2px) vertical marks extending >=4px above and below the line."""
    out = []
    x = x0
    cand = []
    for x in range(x0, x1 + 1):
        L = level[x]
        if np.isnan(L):
            # use neighbour level
            nb = level[max(x0, x - 6):x + 7]
            nb = nb[~np.isnan(nb)]
            if len(nb) == 0:
                continue
            L = nb.max()
        yc = int(round(L))
        below = m[yc + 3:yc + 3 + 6, x].sum()  # pixels below the 4px line
        above = m[yc - 3 - 6:yc - 3, x].sum()
        if below >= 4 and above >= 4:
            cand.append(x)
    # group adjacent columns
    groups = []
    for x in cand:
        if groups and x - groups[-1][-1] <= 1:
            groups[-1].append(x)
        else:
            groups.append([x])
    for gr in groups:
        out.append(dict(x=float(np.mean(gr)), width=len(gr)))
    return out


def steps(level, x0, x1):
    """Convert the per-column level into a list of drops (x position, y_before, y_after)."""
    xs = np.arange(x0, x1 + 1)
    lv = level[x0:x1 + 1].copy()
    # fill gaps (occlusion) by carrying last value forward; flagged separately
    gaps = np.isnan(lv)
    for i in range(len(lv)):
        if np.isnan(lv[i]):
            lv[i] = lv[i - 1] if i > 0 else np.nanmin(lv)
    drops = []
    i = 0
    cur = lv[0]
    for i in range(1, len(lv)):
        if lv[i] > cur + 1.0:  # a drop of > 1 px
            # line cap: new horizontal starts ~LINE_W/2 before the vertical centre
            drops.append(dict(x=float(xs[i] + (LINE_W - 1) / 2), y_before=float(cur), y_after=float(lv[i])))
            cur = lv[i]
        elif lv[i] > cur:
            cur = lv[i]
    return drops, int(gaps.sum())


def main():
    a = load()
    px, py, cal = calibrate(a)
    T = lambda x: float(np.polyval(px, x))
    S = lambda y: float(np.polyval(py, y))
    res = dict(calibration=dict(time_per_px=px.tolist(), surv_per_px=py.tolist(), **cal), arms={})
    os.makedirs(OUT, exist_ok=True)
    for g in "AB":
        m, h, level, x0, x1 = extract(a, g)
        drops, ngap = steps(level, x0, x1)
        tk = ticks(m, level, x0, x1)
        # remove ticks coinciding with a drop's vertical segment (within 3 px)
        dx = np.array([d["x"] for d in drops])
        for t in tk:
            t["near_drop"] = bool(len(dx) and np.min(np.abs(dx - t["x"])) <= 3)
        valid = level[x0:x1 + 1]
        res["arms"][g] = dict(
            x_start=int(x0), x_end=int(x1), t_start=T(x0), t_end=T(x1 - 0.5),
            s_start=S(np.nanmin(valid)), n_missing_level_columns=ngap,
            drops=[dict(t=T(d["x"]), s_before=S(d["y_before"]), s_after=S(d["y_after"]), **d) for d in drops],
            ticks=[dict(t=T(t["x"]), **t) for t in tk],
            level_samples=[dict(x=int(x), t=T(x), s=S(level[x])) for x in range(x0, x1 + 1)
                           if not np.isnan(level[x])],
        )
    with open(os.path.join(OUT, "digitized.json"), "w") as f:
        json.dump(res, f, indent=1)
    for g in "AB":
        r = res["arms"][g]
        print(g, "t_end %.2f s_start %.4f drops %d ticks %d missing cols %d" % (
            r["t_end"], r["s_start"], len(r["drops"]), len(r["ticks"]), r["n_missing_level_columns"]))
    print(json.dumps(res["calibration"]))


if __name__ == "__main__":
    main()
