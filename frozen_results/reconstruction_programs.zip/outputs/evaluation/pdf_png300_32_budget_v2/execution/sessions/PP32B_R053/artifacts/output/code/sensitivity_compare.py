"""Same-horizon comparison of primary (ipd.csv) vs sensitivity (sensitivity.csv) reconstructions."""
import json, os, sys
import numpy as np, pandas as pd
OUT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
def km(df):
    ts = np.sort(df.observed_time.unique()); S = 1.0; out = [(0.0, 1.0)]
    for t in ts:
        n = (df.observed_time >= t).sum(); e = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return np.array(out)
def at(K, t): return K[np.searchsorted(K[:, 0], t, side="right") - 1, 1]
def rmst(K, h):
    tt = np.r_[K[:, 0][K[:, 0] < h], h]; ss = K[:, 1][K[:, 0] < h]
    return float(np.sum(np.diff(tt) * ss))
P, Q = pd.read_csv(os.path.join(OUT, "ipd.csv")), pd.read_csv(os.path.join(OUT, "sensitivity.csv"))
H = min(P.observed_time.max(), Q.observed_time.max())
res = dict(horizon_months=float(H), assumption="censoring times uniform within each risk-table interval "
           "(primary: censoring times at weighted quantiles of detected tick columns)", groups={})
for g in "AB":
    Kp, Kq = km(P[P.group == g]), km(Q[Q.group == g])
    res["groups"][g] = dict(
        S={str(t): [round(float(at(Kp, t)), 4), round(float(at(Kq, t)), 4)] for t in [6, 12, 18, 24, 30, 33, H]},
        rmst=[round(rmst(Kp, H), 3), round(rmst(Kq, H), 3)])
json.dump(res, open(os.path.join(OUT, "work", "sensitivity_comparison.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
