"""Reload committed CSV, recompute right-continuous KM, compare to measurements and risk table."""
import hashlib, json, os, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

OUT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
IN = os.path.abspath(sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, "..", "..", "input"))
man = json.load(open(os.path.join(IN, "manifest.json")))
csv = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(csv, "rb").read()).hexdigest()
d = pd.read_csv(csv)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 695, 478, 341, 224, 83, 0], "B": [1000, 755, 550, 401, 289, 86, 0]}
PX = 1 / 750  # one pixel in survival units

def km(df):
    ts = np.sort(df.observed_time.unique()); S = 1.0; out = []
    for t in ts:
        n = (df.observed_time >= t).sum(); e = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return np.array(out)
def km_at(K, t):
    i = np.searchsorted(K[:, 0], t, side="right") - 1
    return 1.0 if i < 0 else K[i, 1]

checks = dict(csv_sha256=sha, csv=os.path.relpath(csv, OUT), tolerance=dict(
    survival=0.01, justification="~7.5 px; line is 4 px thick, 1 px=0.00133; allows column-level tie/rounding "
    "of the KM inversion (1 event at n~80 moves S by ~0.002-0.003) plus measurement error of about 2 px"), groups={})
fig, ax = plt.subplots(figsize=(10, 6))
for g in ["A", "B"]:
    dg = d[d.group == g]; K = km(dg)
    m = pd.read_csv(os.path.join(OUT, "work", f"measured_{g}.csv"))
    res = dict(n=int(len(dg)), n_expected=man["groups"][g], n_pass=bool(len(dg) == man["groups"][g]),
               event_values_ok=bool(set(dg.event.unique()) <= {0, 1}),
               times_finite_nonneg=bool(np.isfinite(dg.observed_time).all() and (dg.observed_time >= 0).all()),
               events=int(dg.event.sum()), censored=int((dg.event == 0).sum()),
               event_total_supplied="unavailable (manifest has no event totals)")
    rt = []
    for t, nt in zip(RISK_T, RISK[g]):
        nr = int((dg.observed_time >= t).sum())
        rt.append(dict(t=t, table=nt, reconstructed=nr, residual=nr - nt, status="pass" if nr == nt else "fail"))
    res["risk_table"] = rt
    cmp = []
    for t in [0.25, 0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.7]:
        row = m.iloc[(m.t - t).abs().argmin()]
        # measured value: median of reliable columns within +-0.1 month
        w = m[(m.t >= t - 0.1) & (m.t <= t + 0.1) & m.reliable]
        if len(w) == 0:
            cmp.append(dict(t=t, status="unavailable")); continue
        meas = float(w.S_meas.median()); rec = float(km_at(K, t))
        cmp.append(dict(t=t, measured=round(meas, 4), reconstructed=round(rec, 4), residual=round(rec - meas, 4),
                        status="pass" if abs(rec - meas) <= 0.01 else "fail"))
    res["curve"] = cmp
    rel = m[m.reliable]
    resid = np.array([km_at(K, t) for t in rel.t]) - rel.S_meas.values
    res["curve_all_columns"] = dict(n_cols=int(len(rel)), max_abs=round(float(np.abs(resid).max()), 4),
                                    mean_abs=round(float(np.abs(resid).mean()), 4))
    res["last_time"] = float(dg.observed_time.max())
    checks["groups"][g] = res
    c = "tab:blue" if g == "A" else "tab:orange"
    ax.plot(m.t, m.S_meas, color=c, lw=3, alpha=0.35, label=f"{g} measured")
    ax.step(K[:, 0], K[:, 1], where="post", color=c, lw=0.8, label=f"{g} reconstructed KM")
ax.set_xlim(0, 36); ax.set_ylim(0, 1.02); ax.legend(); ax.set_xlabel("months")
fig.savefig(os.path.join(OUT, "work", "overlay.png"), dpi=110)
json.dump(checks, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
for g in "AB":
    r = checks["groups"][g]
    print(g, r["n"], r["events"], [x["status"] for x in r["risk_table"]], r["curve_all_columns"])
    for x in r["curve"]: print("  ", x)
