"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input ../input] [--out output]
Steps: (1) pixel measurement of each arm's step curve and censor ticks,
(2) interval-wise KM inversion constrained by the number-at-risk table,
(3) atomic write of output/ipd.csv.
"""
import argparse, json, os, sys
import numpy as np
import pandas as pd
from PIL import Image

SEED = 797957695
rng = np.random.default_rng(SEED)  # recorded; algorithm below is deterministic

ap = argparse.ArgumentParser()
ap.add_argument("--input", default=os.path.join(os.path.dirname(__file__), "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), ".."))
ap.add_argument("--censor-model", default="ticks", choices=["ticks", "uniform"])
ap.add_argument("--csv-name", default="ipd.csv")
args = ap.parse_args()
IN, OUT = os.path.abspath(args.input), os.path.abspath(args.out)
man = json.load(open(os.path.join(IN, "manifest.json")))

# ---------------- calibration (from axis pixel analysis) ----------------
# x-axis ticks: label 0 at cols 269-270, 36 at cols 1709-1710 (every 6 months = 240 px)
# y-axis ticks: 1.0 at rows 179-180, 0.0 at rows 929-930 (every 0.2 = 150 px)
X0, X36 = 269.5, 1709.5
Y1, Y0 = 179.5, 929.5
def t_of(x): return (x - X0) / (X36 - X0) * 36.0
def s_of(y): return (Y0 - y) / (Y0 - Y1)

# number-at-risk table read visually from the figure
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 695, 478, 341, 224, 83, 0],
        "B": [1000, 755, 550, 401, 289, 86, 0]}
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}

img = np.array(Image.open(os.path.join(IN, "figure.png")).convert("RGB")).astype(int)
def mask(c, tol=60): return np.abs(img - np.array(c)).sum(2) < tol
MB, MO = mask(COL["A"]), mask(COL["B"])
R0, R1 = 150, 928  # plot rows (exclude axis line at 929-930)

def measure(g):
    M = MB if g == "A" else MO
    other = MO if g == "A" else None   # orange drawn over blue
    rows = []
    last = Y1  # line center row at t=0 is S=1 by definition
    xs = range(270, 1712)
    for x in xs:
        pix = np.where(M[R0:R1, x])[0] + R0
        occl = False
        if other is not None:
            op = np.where(other[R0:R1, x])[0] + R0
            # blue reading is usable only if its bottom edge lies below all orange pixels
            # (bottom visible) and is not an isolated fragment (< 3 px run)
            if len(op) and (len(pix) == 0 or pix.max() <= op.max() + 1
                            or (pix.max() - pix.min() < 3 and pix.min() <= op.max() + 1)):
                occl = True
        if len(pix) == 0:
            rows.append(dict(x=x, top=np.nan, bot=np.nan, level=np.nan, tick=False, occluded=occl, present=False))
            continue
        top, bot = pix.min(), pix.max()
        # a censor tick is 16 px tall, 3 px wide, centred on the line (line is 4 px thick)
        tick = (bot - top + 1 >= 15) and (top <= last - 5)
        level = bot - 7.5 if tick else bot - 1.5
        rows.append(dict(x=x, top=top, bot=bot, level=level, tick=tick, occluded=occl, present=True))
    df = pd.DataFrame(rows)
    # sequential re-check of tick classification against the previous accepted level
    lev = df.level.values.copy()
    prev = Y1
    for i in range(len(df)):
        if not df.present[i]:
            continue
        top, bot = df.top[i], df.bot[i]
        tick = (bot - top + 1 >= 15) and (top <= prev - 4.5)
        lev[i] = bot - 7.5 if tick else bot - 1.5
        df.loc[i, "tick"] = tick
        if not (df.occluded[i] and g == "A"):
            prev = lev[i] if lev[i] >= prev - 1 else prev
    df["level"] = lev
    # local (4-column look-ahead, non-propagating) fix of undetected tick bumps
    fixed = lev.copy()
    for i in range(len(lev)):
        w = lev[i + 1:i + 5]
        w = w[~np.isnan(w)]
        if len(w) and lev[i] - np.median(w) > 4:
            fixed[i] = np.median(w)
    df["level_fixed"] = fixed
    # unreliable columns: missing, or blue partly hidden under orange -> interpolate
    bad = ~df.present.values | (df.occluded.values & (g == "A"))
    df["reliable"] = ~bad
    ok = ~bad & ~np.isnan(fixed)
    xx = df.x.values
    lv = np.interp(xx, np.r_[269.5, xx[ok]], np.r_[Y1, fixed[ok]])
    df["level_used"] = lv
    df["t"] = t_of(xx)
    df["S_meas"] = s_of(lv)
    return df

def ticks_of(df):
    """Censor-tick columns (time) -> used as within-interval censoring density."""
    tc = df.loc[df.tick.astype(bool) & df.present, "x"].values
    # group contiguous tick columns into clusters; record centre and width
    clusters = []
    if len(tc):
        start = prev = tc[0]
        for x in list(tc[1:]) + [None]:
            if x is not None and x == prev + 1:
                prev = x; continue
            clusters.append((start, prev));
            if x is not None: start = prev = x
    return tc, clusters

def reconstruct(g, df, censor_model):
    n_tab = RISK[g]
    N = man["groups"][g]
    assert n_tab[0] == N
    t = df.t.values
    S = np.minimum(1.0, df.S_meas.values)
    # no running-minimum: a column reading above the current KM value simply yields d=0
    tickx, _ = ticks_of(df)
    tick_t = t_of(tickx.astype(float))
    t_end = t[df.present.values].max()  # end of drawn curve
    recs = []
    n_start = N
    S_km = 1.0
    info = []
    for k in range(len(RISK_T) - 1):
        a, b = RISK_T[k], RISK_T[k + 1]
        n_next = n_tab[k + 1]
        idx = np.where((t > a - 1e-9) & (t < b - 1e-9))[0] if k > 0 else np.where(t < b - 1e-9)[0]
        tt = t[idx]; ss = S[idx]
        tk = tick_t[(tick_t >= a) & (tick_t < b)]
        def censor_times(c):
            if c <= 0: return np.array([])
            if censor_model == "ticks" and len(tk):
                q = (np.arange(c) + 0.5) / c
                return np.quantile(np.sort(tk), q, method="inverted_cdf")
            hi = min(b, t_end)
            return a + (np.arange(c) + 0.5) / c * (hi - a)
        def run(c):
            ct = np.sort(censor_times(c))
            n = n_start; skm = S_km; ev = []; ci = 0
            for j in range(len(tt)):
                # censorings strictly before this column time leave the risk set
                while ci < len(ct) and ct[ci] < tt[j] - 1e-9:
                    n -= 1; ci += 1
                if n <= 0: break
                d = int(round(n * (1 - ss[j] / skm))) if skm > 0 else 0
                d = max(0, min(d, n))
                if d > 0:
                    ev += [tt[j]] * d
                    skm *= (1 - d / n); n -= d
            n -= (len(ct) - ci)
            return ev, ct, n, skm
        c = max(0, n_start - n_next - int(round(n_start * (1 - ss[-1] / S_km))))
        for it in range(200):
            ev, ct, n_end, skm = run(c)
            diff = n_end - n_next
            if diff == 0: break
            c_new = max(0, c + diff)
            if c_new == c: break
            c = c_new
        if n_end != n_next:
            info.append(f"{g} interval [{a},{b}): at-risk mismatch {n_end} vs {n_next}")
        recs += [(g, x, 1) for x in ev] + [(g, x, 0) for x in ct]
        info.append(dict(interval=[a, b], n_start=int(n_start), events=len(ev), censored=int(len(ct)),
                         n_end=int(n_end), n_table=int(n_next)))
        n_start = n_end; S_km = skm
    if n_start > 0:
        # remaining participants (only if table said >0 at 36): censor at end of drawn curve
        recs += [(g, float(t_end), 0)] * n_start
    return recs, info

if __name__ == "__main__":
    os.makedirs(os.path.join(OUT, "work"), exist_ok=True)
    allrec, allinfo = [], {}
    for g in ["A", "B"]:
        df = measure(g)
        df.to_csv(os.path.join(OUT, "work", f"measured_{g}.csv"), index=False)
        _, cl = ticks_of(df)
        pd.DataFrame([dict(x0=a, x1=b, t_center=t_of((a + b) / 2), width_px=b - a + 1,
                           S_center=s_of(df.set_index("x").level_used[a:b].median()))
                      for a, b in cl]).to_csv(os.path.join(OUT, "work", f"ticks_{g}.csv"), index=False)
        recs, info = reconstruct(g, df, args.censor_model)
        assert len(recs) == man["groups"][g], (g, len(recs))
        allrec += recs; allinfo[g] = info
    out = pd.DataFrame(allrec, columns=["group", "observed_time", "event"])
    out["observed_time"] = out.observed_time.round(4)
    out = out.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    path = os.path.join(OUT, args.csv_name); tmp = path + ".tmp"
    out.to_csv(tmp, index=False); os.replace(tmp, path)
    json.dump(allinfo, open(os.path.join(OUT, "work", f"interval_log_{args.censor_model}.json"), "w"), indent=1)
    print(json.dumps(allinfo, indent=1))
