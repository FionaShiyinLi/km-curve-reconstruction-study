# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800×1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 797957695).
- I read the number-at-risk table from the figure by eye. At 0/6/12/18/24/30/36 months it shows A: 1000, 695, 478, 341, 224, 83, 0 and B: 1000, 755, 550, 401, 289, 86, 0. The digits are clearly rendered, and I treat them as exact.
- The manifest gives no arm-specific event totals. That constraint is therefore **unavailable**. It is not taken to mean zero events.

## Measurement (`code/reconstruct.py`, outputs in `work/`)
- **Calibration.** Axis tick pixels anchor the axes: t = 0 at column 269.5 and t = 36 at column 1709.5 (40 px/month). S = 1 is at row 179.5 and S = 0 at row 929.5 (750 px per unit). This is a linear map from labeled anchors, with no global rescaling.
- **Curve reading.** Curve pixels are selected by exact line color: A is (31,119,180) and B is (255,127,14). The line is 4 px thick. Censor ticks are 3×16 px and centered on the line.
  - For each column, the level is bottom − 1.5 px for a line column (the right-continuous lower level after any drop in that column).
  - For a tick column, the level is bottom − 7.5 px. A column counts as a tick if the run is ≥ 15 px and rises above the previous level.
  - A 4-column look-ahead median replaces isolated bumps larger than 4 px (tick misclassification). This correction is local. No running minimum is applied, and a column reading above the current KM value simply gives d = 0.
- **Origin and occlusion.** The orange B curve is drawn over the blue A curve. For t ≲ 0.8 months the blue line is mostly hidden.
  - A column of arm A is used only where its bottom edge is visible below the orange pixels. Visible columns include a blue tick at t ≈ 0.11 (S ≈ 0.996) and all columns from t ≈ 0.8 onward.
  - Between these points, and from S(0) = 1, arm A is linearly interpolated. Within that window arm A is known only to lie within a few pixels of arm B. Its early event timing (about 0.03 in S) is therefore approximate, and `checks.json` marks those check times unavailable.
  - B's start is read directly and shows genuine drops from t ≈ 0.
- **Censor ticks.** Tick columns are saved to `work/ticks_{A,B}.csv` (about 105 clusters per arm). Overlapping ticks form wider blobs, so tick visibility does not give multiplicity.

## Reconstruction algorithm (own implementation, deterministic)
This is an interval-wise inversion of the KM estimator, in the spirit of Guyot-type methods but coded here from scratch.
- **Intervals.** Within each risk-table interval [t_k, t_{k+1}), the number censored, c, is iterated until n_start − events − c equals the tabulated n at t_{k+1}.
- **Events.** For a given c, the columns in the interval are scanned. At each column, d = round(n_risk · (1 − S_meas/S_KM,prev)), truncated to [0, n_risk], and all d events are placed at that column's time.
  - A column can therefore contain several tied events. I did not assume d = 1 per visible step.
  - Time resolution is 1 px = 0.025 months.
- **Censoring (primary assumption).** Within each interval, the c censoring times sit at equally spaced quantiles of the detected tick columns in that interval. Wider tick blobs get proportionally more censorings. Censorings that tie an event column are removed after the events (events first).
- **Constraints.** The risk table fixes c per interval. Tick positions constrain only the within-interval timing. Tick multiplicity, and any censoring hidden under drops, are not identified.
- **Last interval.** The table gives 0 at risk at 36, so every participant has observed_time < 36. The remaining participants in [30, 36) are censored at tick positions, up to the last drawn tick: A 35.99, B 35.84 months. The flat tails are not used to infer any follow-up beyond the drawn marks.
- **Result.**
  - A: 781 events, 219 censored.
  - B: 699 events, 301 censored.
  - Censoring is concentrated in 24–36 months (A 148, B 229).
  - The seed is recorded in the code, but the algorithm uses no randomness.

## Verification (`code/check.py` → `checks.json`)
- `check.py` reloads `ipd.csv`, recomputes the right-continuous KM step function, and evaluates it at 20 times per arm from 0.25 to 35.7 months, including the tail.
- The measured value at each time is the median over reliable columns within ±0.1 month. Tolerance is 0.01 (about 7.5 px), which allows for about 2 px of measurement error plus integer rounding of d at small n_risk.
- **Curve agreement.** Every available check time passes, with |residual| ≤ 0.002. The maximum absolute residual over all reliable columns is 0.008 for A and 0.005 for B.
- **Risk table.** All 14 counts (#{observed_time ≥ t}) match exactly, including the zeros at 36.
- **Arm sizes and indicators.** Arm sizes are 1000/1000 and event indicators are 0/1.
- **Unavailable checks.** Arm A at t = 0.25 and 0.5 is unavailable because of occlusion. Event totals are unavailable.

## Sensitivity (one alternative, `sensitivity.csv`)
- **Alternative assumption.** Censorings are placed uniformly within each risk interval, ignoring the tick positions.
- **Comparison.** At the common horizon of 35.94 months (`work/sensitivity_comparison.json`), per-arm survival at 6–33 months differs by ≤ 0.0006. The RMST to that horizon is A 15.427 vs 15.428 and B 17.711 vs 17.713 months.
- **Interpretation.** Agreement is close because the curve and the risk table tightly constrain events per interval. This single alternative is not an uncertainty bound. Individual event/censoring orderings within columns, tie structure, and early arm-A timing remain unidentified.

## Limitations
- Raster resolution limits event times to 0.025-month bins, and tied events within a column are an artifact of that resolution.
- The censoring distribution within intervals and hidden censorings are assumptions.
- Early arm A (before about 0.8 months) is interpolated.
- The reconstruction approximates the original records. It does not recover them uniquely.
