"""Reconstruct participant-level records from the vector KM figure.

Usage: python reconstruct.py [--input ../input] [--out output]
Reads figure.pdf (vector paths) and manifest.json; writes ipd.csv, extracted
observations, and checks.json. Deterministic; the seed is set and recorded
although no random draws are used by the primary algorithm.
"""
import argparse, json, os, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(here, ".."))
a = ap.parse_args()
man = json.load(open(os.path.join(a.input, "manifest.json")))
SEED = man["code_seed"]; np.random.seed(SEED)
N = man["groups"]

pg = pdfplumber.open(os.path.join(a.input, "figure.pdf")).pages[0]

# ---- axis calibration from labelled tick marks -------------------------
xt = sorted({round(l["x0"], 3) for l in pg.lines if l["x0"] == l["x1"] and abs(l["top"] - 223.2) < 1e-6 and l["bottom"] > l["top"] + 2})
yt = sorted({round(l["top"], 3) for l in pg.lines if l["top"] == l["bottom"] and l["x1"] - l["x0"] < 4})
# x labels 0..36 by 6 at xt; y labels 1.0..0.0 at yt (top->bottom)
xl = np.arange(0, 37, 6); yl = np.linspace(1, 0, 6)
assert len(xt) == 7 and len(yt) == 6
px, py = np.polyfit(xt, xl, 1), np.polyfit(yt, yl, 1)
fx = lambda x: np.polyval(px, x); fy = lambda y: np.polyval(py, y)
calib = dict(x_ticks_pt=xt, y_ticks_pt=yt, x_fit=list(px), y_fit=list(py),
             x_resid=list(fx(np.array(xt)) - xl), y_resid=list(fy(np.array(yt)) - yl))

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}  # legend order
def col(o, g): return o.get("stroking_color") is not None and np.allclose(o["stroking_color"], COL[g], atol=1e-4)

obs = {}; recs = []; summary = {}
for g in ["A", "B"]:
    cur = [c for c in pg.curves if col(c, g)]; assert len(cur) == 1
    pts = np.array(cur[0]["pts"])
    t, s = fx(pts[:, 0]), fy(pts[:, 1])
    # step path: horizontal then vertical segments; collect drops at each x
    steps = []  # (time, S_before, S_after)
    for i in range(1, len(pts)):
        if abs(pts[i, 0] - pts[i - 1, 0]) < 1e-9 and s[i] < s[i - 1] - 1e-9:
            steps.append((t[i], s[i - 1], s[i]))
    ticks = [l for l in pg.lines if col(l, g) and l["x0"] == l["x1"] and l["bottom"] - l["top"] < 5]
    ct = np.array(sorted(fx(l["x0"]) for l in ticks))
    # duplicate tick coordinates would indicate overplotted multiplicity
    dup = int(len(ticks) - len({(round(l["x0"], 4), round(l["top"], 4)) for l in ticks}))
    end_t = t[-1]
    obs[g] = dict(curve_pts_time=list(t), curve_pts_surv=list(s), drops=steps, censor_times=list(ct),
                  duplicate_ticks=dup, path_end_time=float(end_t), path_end_surv=float(s[-1]))
    # ---- KM inversion: walk drops in time order, censor ticks strictly before
    # a drop time are removed from the risk set first (ticks at a drop time are
    # treated as after the events, KM convention).
    n = N[g]; rec = []; ci = 0; Sprev = 1.0; drec = []
    for (tt, sb, sa) in steps:
        while ci < len(ct) and ct[ci] < tt - 1e-6:
            rec.append((ct[ci], 0)); n -= 1; ci += 1
        draw = n * (1 - sa / sb)
        d = int(round(draw)); d = max(1, min(d, n))
        drec.append(dict(time=float(tt), S_before=float(sb), S_after=float(sa), n_risk=n, d_raw=float(draw), d=d))
        rec += [(tt, 1)] * d; n -= d
    while ci < len(ct):
        rec.append((ct[ci], 0)); n -= 1; ci += 1
    leftover = n
    if n > 0:  # remaining participants: censored at last displayed follow-up
        rec += [(max(end_t, ct.max() if len(ct) else end_t), 0)] * n
    if n < 0:
        raise SystemExit(f"group {g}: tick/drop counts exceed n ({n})")
    summary[g] = dict(n_ticks=len(ct), n_drops=len(steps), events=sum(e for _, e in rec),
                      leftover_censored_at_end=leftover, max_abs_d_residual=float(max(abs(r["d_raw"] - r["d"]) for r in drec)))
    obs[g]["drop_inversion"] = drec
    recs += [(g, float(x), int(e)) for x, e in rec]

df = pd.DataFrame(recs, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0)
os.makedirs(a.out, exist_ok=True)
fd, tmp = tempfile.mkstemp(dir=a.out, suffix=".tmp"); os.close(fd)
df.to_csv(tmp, index=False, float_format="%.6f"); os.replace(tmp, os.path.join(a.out, "ipd.csv"))
json.dump(dict(calibration=calib, groups=obs, summary=summary), open(os.path.join(a.out, "extracted_observations.json"), "w"), indent=1, default=float)
print(json.dumps(summary, indent=1))
