"""Reload committed ipd.csv, recompute right-continuous KM, compare with the
vector-extracted curve and the printed risk table; write checks.json."""
import argparse, json, os, hashlib
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--out", default=os.path.join(here, ".."))
ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
a = ap.parse_args()
p = os.path.join(a.out, "ipd.csv")
sha = hashlib.sha256(open(p, "rb").read()).hexdigest()
df = pd.read_csv(p); ob = json.load(open(os.path.join(a.out, "extracted_observations.json")))
man = json.load(open(os.path.join(a.input, "manifest.json")))
# risk table read from PDF text layer (exact digits, no OCR)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 70, 44, 26, 17, 5, 0], "B": [100, 82, 62, 46, 34, 11, 0]}

def km(d):
    ts = np.sort(d.loc[d.event == 1, "observed_time"].unique()); S = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return out
def Sat(steps, t):  # right-continuous
    s = 1.0
    for tt, v in steps:
        if tt <= t + 1e-9: s = v
    return s
def meas(g, t):  # measured step curve from vector path (right-continuous)
    s = 1.0
    for tt, sb, sa in ob["groups"][g]["drops"]:
        if tt <= t + 1e-9: s = sa
    return s

TOL_S = 0.002  # vector coordinates: calibration residual ~1e-12; tolerance covers float formatting (6 d.p.)
res = dict(csv_sha256=sha, tolerance_survival=TOL_S,
           tolerance_note="Curve read from exact PDF vector coordinates; tolerance covers float formatting only.",
           groups={})
for g in ["A", "B"]:
    d = df[df.group == g]; st = km(d); r = {}
    r["n"] = dict(expected=man["groups"][g], observed=int(len(d)), status="pass" if len(d) == man["groups"][g] else "fail")
    r["event_indicator_integer_01"] = bool(d.event.isin([0, 1]).all())
    r["events_total"] = dict(supplied="unavailable (manifest has no event totals)", reconstructed=int(d.event.sum()))
    drops = ob["groups"][g]["drops"]; tend = ob["groups"][g]["path_end_time"]
    times = sorted(set([0.5, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, round(tend - 0.01, 3), round(tend, 3)]))
    cc = []
    for t in times:
        m, rc = meas(g, t), Sat(st, t)
        cc.append(dict(t=t, measured=round(m, 5), reconstructed=round(rc, 5), residual=round(rc - m, 5),
                       status="pass" if abs(rc - m) <= TOL_S else "fail"))
    # all step times, max abs deviation just after each drop
    dev = max(abs(Sat(st, tt + 1e-5) - sa) for tt, sb, sa in drops)
    r["curve_checks"] = cc; r["max_abs_dev_after_every_drop"] = round(dev, 6)
    rk = []
    for t, n in zip(RISK_T, RISK[g]):
        m = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, printed=n, reconstructed=m, residual=m - n, status="pass" if m == n else "fail"))
    r["risk_table"] = rk
    tm = d.observed_time.max()
    r["tail"] = dict(max_time=float(tm), last_status_event=int(d.loc[d.observed_time == tm, "event"].max()),
                     S_at_max=round(Sat(st, tm), 5), measured_path_end_surv=round(ob["groups"][g]["path_end_surv"], 5))
    res["groups"][g] = r
json.dump(res, open(os.path.join(a.out, "checks.json"), "w"), indent=1)
for g in res["groups"]:
    r = res["groups"][g]
    print(g, r["n"], "events", r["events_total"]["reconstructed"], "maxdev", r["max_abs_dev_after_every_drop"],
          [ (x["t"], x["printed"], x["reconstructed"]) for x in r["risk_table"]],
          [x["status"] for x in r["curve_checks"]].count("fail"), "curve fails", r["tail"])
print(sha)
