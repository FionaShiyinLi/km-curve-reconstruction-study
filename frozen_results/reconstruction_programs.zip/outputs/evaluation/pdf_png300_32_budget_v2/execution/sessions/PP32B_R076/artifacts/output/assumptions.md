# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`: a vector PDF. The Kaplan–Meier (KM) step paths, censor tick marks, axis ticks, labels and the number-at-risk table are all stored as PDF objects, and I read them directly with pdfplumber (no raster measurement or OCR).
- `../input/manifest.json`: n = 100 per group, time in months, code seed 1580932065. The manifest has no arm-specific event totals, so that check is marked unavailable.
- Group identity comes from the legend order and stroke colors: blue (0.122, 0.467, 0.706) is Group A and orange (1.0, 0.498, 0.055) is Group B. This matches the legend line segments placed before the "Group A" and "Group B" labels.

## Calibration
- Time: the 7 labelled x-axis ticks (0–36 months in steps of 6) were fitted linearly, giving 9.6 pt per month.
- Survival: the 6 labelled y-axis ticks (0.0–1.0) were fitted linearly, giving 180 pt per unit.
- Fit residuals are at floating-point level (see `extracted_observations.json`).
- Both paths start exactly at (0, 1.0). No global rescaling, origin correction or running-minimum correction was applied.

## Algorithm
1. Extract each arm's step path. Each vertical segment is a drop (t, S_before, S_after). Short vertical strokes in the arm's color are its censor ticks: 16 for Group A and 36 for Group B. No two ticks share coordinates, so there is no evidence of overplotted multiplicity.
2. Walk the drops in time order. Ticks strictly earlier than a drop leave the risk set first. At each drop, d = n_risk·(1 − S_after/S_before), rounded to an integer.
   - Every drop gave d = 1, with |d_raw − d| < 5e-5 for all drops.
   - This is not just the "integer reciprocal means d = 1" heuristic. Because each step follows from the tracked risk set, d = 2 would give a residual of about 1, which is ruled out.
   - No tick coincides with a drop time (tolerance 1e-3 months), so no tie-ordering rule was needed.
3. Events are placed at drop times and censorings at tick times. After the path ends, no participants are left over in either arm:
   - Group A: 84 events + 16 censorings. The last record is a censoring at 34.76 months (the path ends flat at S = 0.0859).
   - Group B: 64 events + 36 censorings. The last record is an event at 33.10 months, with 1 participant at risk, so S drops to 0.
4. No randomness is used. The seed is set and recorded anyway.

## Checks (`checks.json`, computed from the reloaded CSV)
- **Curve agreement:** the right-continuous KM recomputed from `ipd.csv` matches the extracted step path after every drop, with a maximum absolute deviation of 0 at 6 d.p. The 14 checkpoints per arm include t = 0.5, the tail and the path end.
- **Risk table:** printed at 0, 6, …, 36 months (A: 100/70/44/26/17/5/0; B: 100/82/62/46/34/11/0). The counts of records with observed_time ≥ t match exactly at all 7 times in both arms. The counts were not used as fitting constraints, so this is an independent check.
- **Other checks:** arm sizes are 100/100 and event indicators are 0/1 integers.

## Limitations
- The only remaining ambiguity is the exact censoring time within the rendering precision of the tick x-coordinate, which is negligible.
- A tick hidden under another tick at the identical position cannot be ruled out from the figure alone. However, the independent agreement with the risk table and the exact d_raw integrality make undisplayed censorings very unlikely.
- Because the allocation is essentially determined, I did not run an alternative allocation, and there is no `sensitivity.csv`.
- The records reproduce the published curve; they are not the original data, and no covariates are implied.

## Reproduce
`python output/code/reconstruct.py && python output/code/check.py`
Both scripts accept `--input` and `--out` arguments. Their default paths are relative to the script location.
