# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster Kaplan–Meier figure, two arms).
- `../input/manifest.json`: n = 100 per arm, time unit months, code seed 299857055. The manifest gives no arm-specific event totals, so the event-total check is marked unavailable. That does not mean zero events.
- Number-at-risk table, read visually from the figure. A: 100, 74, 56, 32, 26, 9, 0; B: 100, 83, 59, 48, 37, 11, 0 at 0, 6, …, 36 months. All digits are clearly rendered, so I treat these readings as reliable.

## Algorithm (`code/reconstruct.py`, own implementation; no KM-to-IPD package)
1. **Calibration.** Axis tick marks were located from dark pixels, and linear maps were fitted to the labelled anchors (x: 0–36 at 40 px/month; y: 1.0–0.0 at 750 px/unit). Residuals at the anchors are 0. No global rescaling or running-minimum correction was applied.
2. **Curve measurement.** Each arm was isolated by its line color. A horizontal level is a 3–7 px band continuous over a 7-column window, so censor ticks and vertical risers (2–3 px wide) are excluded. Columns with a constant level were joined into segments, bridging short occluded gaps. Some wide transition gaps contain short staircases (for example, A at 1.2–1.6 months). These were split into sub-levels using the lowest arm-colored pixel per column, adjusted by half the line width. Drop times are the centers of the arm-colored riser columns.
   - Origin: the S = 1.0 level of each arm is hidden under the other arm's line near t = 0. S(0) = 1 was set by definition, and the local riser was used. The genuine early drops (A at about 0.03 months; B at 0.13, 0.23 and 0.33) were kept.
   - Measured drops and ticks are saved in `extraction_ipd.json`.
3. **Censor ticks.** A tick is a column with arm-colored pixels 5–8 px both above and below the local level. Visible multiplicity was taken as 1 for clusters 2–3 px wide, plus 1 for every further 2 px. Ticks that overlap exactly, or are hidden by the other arm, are not identifiable. This is a count of visible marks, not of true multiplicity.
4. **Allocation.** This is interval-wise between risk-table times, following the Guyot et al. logic but written from scratch. For each candidate total censoring count c in an interval:
   - Events at each drop are d = round(n_at × (1 − S_after,measured / S_reconstructed,before)), with d ≥ 1 for a visible drop. So d is inferred from the ratio and n at risk, not assumed to be 1. Using the reconstructed S_before limits drift.
   - Censorings go first to the visible ticks. If c is smaller than the number of visible ticks, an evenly spaced subset of ticks is used. Additional non-visible censorings are placed greedily at between-drop midpoints, choosing the midpoint that minimizes the squared error between reconstructed and measured post-drop levels.
   - c was chosen to reproduce the displayed count at the next risk time exactly, with the curve fit breaking ties.
   - In the last interval (risk 0 at 36), everyone remaining is censored no later than the end of the drawn curve (A 35.34, B 35.39 months). Censorings tied with an event time are ordered after the event.
5. The CSV was written through a temporary file and `os.replace`. The algorithm is deterministic. The seed is recorded and set, but no random draws are used.

## Checks (`code/checks.py` → `checks.json`, `overlay.png`)
- I reloaded the committed CSV and recomputed the right-continuous KM curve, without interpolation. It was compared with the measured step curve at 20 times per arm, including 29–35.3 months and the curve end.
- The tolerance was fixed before checking: 0.003 (about 2 px) plus half of one KM step (0.5·S/n at risk). All points pass. The largest absolute residuals are 0.0053 (A) and 0.0042 (B). The largest is in A at 29–35 months, where reconstructed survival is about 0.004–0.005 above the measured curve after the 28.9-month drop. That drop implies about 13 at risk, and it is placed within rounding of an integer event count.
- Risk-table counts (#{observed_time ≥ t}) match exactly at all 7 times for both arms. The zero counts at 36 are met because every time is below 36.
- The CSV has 100 records per arm, event values in {0,1}, and finite nonnegative times. Events: A 74, B 65 (not checkable against supplied totals).

## Unresolved limitations
- **Censoring counts.** The number and timing of censorings not shown as distinct ticks are not identified by the figure. The risk table fixes only per-interval totals.
  - In some intervals, fewer censorings than visible tick clusters were needed: A 12–18 (2 of 3) and 24–30 (13 of 15); B 24–30 (18 of 19). The likely cause is tick clusters overlapping risers (for example, A at 28.9) or tick-width over-counting. Which ticks were dropped is arbitrary.
  - Elsewhere, more censorings than visible ticks were needed. Those times are model-based, not observed.
- **Events.** Event counts at tied or near-coincident drops within a raster column are inferred from step heights and are subject to ±1 rounding when the risk set is small.
- **Precision.** Time resolution is about 0.025 months per pixel. Short occluded stretches where the arms overlap (around 9–10 months at S ≈ 0.68) were bridged by constant levels.
- **Follow-up.** The flat tails do not identify the censoring distribution or the maximum follow-up beyond the drawn curve.

## Sensitivity (`sensitivity.csv`, one alternative)
The alternative puts the extra non-visible censorings at the visible tick times of the same interval instead of at the fitted between-drop positions. Comparison at the common supported horizon of 35.29 months:
- A: S = 0.157 (primary) vs 0.148; RMST 16.66 vs 16.64 months.
- B: identical (S = 0.265; RMST 19.81 months).

Event totals are unchanged. This single alternative is not a confidence interval or a bound on reconstruction error. The primary allocation was chosen for its fit to the measured post-drop levels, not for any treatment contrast.

## Correction cycles
There was one primary correction after the first complete file. Spreading extra censorings evenly had left A's tail after 30 months about 0.015 above the measured curve, so I replaced it with fitted greedy placement. The checks were regenerated from the final CSV (SHA-256 in `checks.json`).
