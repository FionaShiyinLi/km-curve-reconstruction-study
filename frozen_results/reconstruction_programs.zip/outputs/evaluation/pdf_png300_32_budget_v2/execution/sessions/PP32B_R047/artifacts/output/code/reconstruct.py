#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input ../input] [--out output] [--alt]
Stages: (1) axis calibration from tick marks, (2) per-arm curve measurement
(horizontal levels, drops, censor ticks), (3) interval-wise event/censor
allocation constrained by the number-at-risk table (Guyot-style iteration,
implemented from scratch), (4) atomic CSV write.
"""
import argparse, json, os, tempfile
import numpy as np
from PIL import Image

SEED = 299857055
HW = 3  # half-width of horizontal-support window (7 columns)
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
# Risk table read visually from the figure (text below the axis).
RISK_TIMES = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 74, 56, 32, 26, 9, 0], "B": [100, 83, 59, 48, 37, 11, 0]}
X_LABELS = [0, 6, 12, 18, 24, 30, 36]
Y_LABELS = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]


def runs(idx):
    out = []
    if len(idx) == 0:
        return out
    s = p = idx[0]
    for v in idx[1:]:
        if v != p + 1:
            out.append((s, p)); s = v
        p = v
    out.append((s, p))
    return out


def calibrate(a):
    dk = a.sum(2) < 150
    colsum, rowsum = dk.sum(0), dk.sum(1)
    x_axis_row = int(np.argmax(rowsum))            # long horizontal axis line
    y_axis_col = int(np.argmax(colsum))
    xt = np.where(dk[x_axis_row + 5:x_axis_row + 15].sum(0) > 5)[0]
    xt = [np.mean(r) for r in map(lambda t: range(t[0], t[1] + 1), runs(xt))]
    xt = [c for c in xt if c > y_axis_col - 5]      # drop label text left of axis
    yt = np.where(dk[:, y_axis_col - 14:y_axis_col - 2].sum(1) > 5)[0]
    yt = [np.mean(range(s, e + 1)) for s, e in runs(yt)]
    assert len(xt) == len(X_LABELS) and len(yt) == len(Y_LABELS), (xt, yt)
    px, py = np.polyfit(xt, X_LABELS, 1), np.polyfit(yt, Y_LABELS, 1)
    resx = np.polyval(px, xt) - X_LABELS
    resy = np.polyval(py, yt) - np.array(Y_LABELS)
    return dict(x_ticks_px=xt, y_ticks_px=yt, px=px.tolist(), py=py.tolist(),
                max_abs_resid_x=float(np.abs(resx).max()),
                max_abs_resid_y=float(np.abs(resy).max()))


def measure_arm(a, color, cal, x0px):
    M = np.abs(a - np.array(color)).sum(2) < 60
    H, W = M.shape
    top = int(min(cal["y_ticks_px"])) - 15
    bot = int(max(cal["y_ticks_px"])) + 5
    # horizontal support: pixel set over a 7-column window (ticks/verticals are 2-3 px wide)
    level = np.full(W, np.nan)
    for x in range(3, W - 3):
        rows = [r for r in range(top, bot) if M[r, x - HW:x + HW + 1].all()]
        rr = runs(rows)
        if len(rr) == 1 and 3 <= rr[0][1] - rr[0][0] + 1 <= 7:
            level[x] = (rr[0][0] + rr[0][1]) / 2.0
    xs = np.where(~np.isnan(level))[0]
    xend = int(max(np.where(M[top:bot].any(0))[0]))
    # segments of constant level
    segs = []
    for x in xs:
        if segs and abs(level[x] - segs[-1]["y"]) <= 1.5 and x - segs[-1]["x1"] <= 40:
            s = segs[-1]; s["x1"] = x; s["ys"].append(level[x]); s["y"] = float(np.median(s["ys"]))
        elif segs and abs(level[x] - segs[-1]["y"]) <= 1.5:
            s = segs[-1]; s["x1"] = x; s["ys"].append(level[x])  # gap (occlusion), same level
        else:
            segs.append(dict(x0=x, x1=x, ys=[level[x]], y=float(level[x])))
    segs = [s for s in segs if s["x1"] - s["x0"] >= 1 or len(s["ys"]) >= 2]
    y1 = cal["py"]; S = lambda y: float(np.polyval(y1, y))
    T = lambda x: float(np.polyval(cal["px"], x))
    ytop = float(np.polyval(np.polyfit(Y_LABELS, cal["y_ticks_px"], 1), 1.0))
    # Starting level: S(0)=1 by definition of KM; prepend if the first measured
    # segment is lower (the 1.0 level may be hidden under the other arm).
    notes = []
    if S(segs[0]["y"]) < 0.995:
        segs.insert(0, dict(x0=int(x0px), x1=int(x0px), ys=[ytop], y=ytop))
        notes.append("level 1.0 at origin not visible (occluded); prepended S=1 at t=0")
    # Staircases too short for the 7-column window: inside a wide transition gap,
    # the lowest own pixel of each column (minus half the line width, 2 px)
    # tracks the current level; plateaus of >= 2 columns become sub-segments.
    refined = [segs[0]]
    for s0, s1 in zip(segs[:-1], segs[1:]):
        if s1["y"] - s0["y"] > 2 and s1["x0"] - s0["x1"] > 5:
            bots = {}
            for x in range(s0["x1"] + 1, s1["x0"]):
                r = np.where(M[int(s0["y"]) - 3:int(s1["y"]) + 4, x])[0]
                if len(r):
                    bots[x] = int(s0["y"]) - 3 + r.max() - 2
            xs_ = sorted(bots)
            i = 0
            while i < len(xs_):
                j = i
                while j + 1 < len(xs_) and xs_[j + 1] == xs_[j] + 1 and abs(bots[xs_[j + 1]] - bots[xs_[i]]) <= 1:
                    j += 1
                yv = float(np.median([bots[x] for x in xs_[i:j + 1]]))
                if j > i and refined[-1]["y"] + 2 < yv < s1["y"] - 2:
                    refined.append(dict(x0=xs_[i], x1=xs_[j], ys=[yv], y=yv, sub=True))
                i = j + 1
        refined.append(s1)
    segs = refined
    drops, anomalies = [], []
    for s0, s1 in zip(segs[:-1], segs[1:]):
        dy = s1["y"] - s0["y"]
        if dy < -2:
            anomalies.append(("upward_level", T(s1["x0"]), S(s0["y"]), S(s1["y"])))
            continue
        if dy <= 2:
            continue
        mid = int(round((s0["y"] + s1["y"]) / 2))
        cand = [x for x in range(max(s0["x1"] - 3, 0), s1["x0"] + 4) if M[mid - 1:mid + 2, x].any()]
        xd = float(np.mean(cand)) if cand else (s0["x1"] + s1["x0"]) / 2.0
        drops.append(dict(x=xd, t=max(T(xd), 0.0), y_before=s0["y"], y_after=s1["y"],
                          S_before=S(s0["y"]), S_after=S(s1["y"]),
                          vertical_seen=bool(cand)))
    # censor ticks: own pixels both 5..8 px above and below the local level
    tickcols = []
    for s in segs:
        if s.get("sub"):
            continue  # staircase interiors: vertical pixels would mimic ticks
        yl = int(round(s["y"]))
        for x in range(s["x0"] - 2, min(s["x1"] + 3, W)):
            if M[yl - 8:yl - 4, x].any() and M[yl + 5:yl + 9, x].any():
                tickcols.append(x)
    ticks = []
    for c0, c1 in runs(sorted(set(tickcols))):
        w = c1 - c0 + 1
        mult = 1 + max(0, (w - 2) // 2)  # 2-3 px = one tick; wider = overlapping ticks
        ticks.append(dict(x0=int(c0), x1=int(c1), t=T((c0 + c1) / 2.0), width=int(w), count_visible=int(mult)))
    return dict(segments=[dict(t0=T(s["x0"]), t1=T(s["x1"]), y=s["y"], S=S(s["y"])) for s in segs],
                drops=drops, ticks=ticks, t_end=T(xend), anomalies=anomalies, notes=notes)


def allocate(meas, times, risk, alt=False):
    """Interval-wise allocation. Within [T_k, T_k+1) choose the total censor
    count c so that the reconstructed number at risk at T_k+1 matches the table.
    Events at each drop: d = round(n_at * (1 - S_after / S_recon_before)), >= 1.
    Censor times: visible ticks first; extra censorings placed greedily at
    between-drop midpoints minimising squared error to the measured post-drop
    levels (primary) or at the visible tick times (alt)."""
    drops, ticks = meas["drops"], meas["ticks"]
    t_end = meas["t_end"]
    recs, log = [], []
    n = risk[0]; S_rec = 1.0
    for k in range(len(times) - 1):
        a, b = times[k], min(times[k + 1], t_end + 1e-9)
        last = (k == len(times) - 2) or times[k + 1] > t_end
        target = 0 if risk[k + 1] == 0 or last else risk[k + 1]
        dk = [d for d in drops if a <= d["t"] < times[k + 1]]
        tk = []
        for t in ticks:
            if a <= t["t"] < times[k + 1]:
                tk += [t["t"]] * t["count_visible"]
        def sim(cens):
            nn, S, ev, sse, ci = n, S_rec, [], 0.0, 0
            for d in dk:
                while ci < len(cens) and cens[ci] < d["t"]:
                    nn -= 1; ci += 1
                if nn <= 0:
                    return None
                dd = int(round(nn * (1 - d["S_after"] / S)))
                dd = min(max(dd, 1), nn)
                ev.append((d["t"], dd)); S *= 1 - dd / nn; nn -= dd
                sse += (S - d["S_after"]) ** 2
            nn -= len(cens) - ci
            return (nn, S, ev, sse) if nn >= 0 else None
        hi = b if not last else t_end
        edges = [a] + [d["t"] for d in dk] + [hi]
        slots = [(u + v) / 2 for u, v in zip(edges[:-1], edges[1:]) if v - u > 1e-6]
        best = None
        for c in range(0, n + 1):
            if c <= len(tk):
                idx = np.linspace(0, len(tk) - 1, c).round().astype(int) if c else []
                cens = sorted(tk[i] for i in idx)
            elif alt and tk:
                cens = sorted(tk + [tk[i % len(tk)] for i in range(c - len(tk))])
            else:
                # greedy: each non-visible censoring goes to the between-drop slot
                # that best reproduces the measured post-drop levels
                cens = list(tk)
                for _ in range(c - len(tk)):
                    opts = []
                    for sl in slots:
                        r = sim(sorted(cens + [sl]))
                        opts.append(((r[3] if r else 1e9), sl))
                    cens.append(min(opts)[1])
                cens = sorted(cens)
            r = sim(cens)
            if r is None:
                continue
            nn, S, ev, sse = r
            key = (abs(nn - target), sse, abs(c - len(tk)))
            if best is None or key < best[0]:
                best = (key, c, cens, ev, S, nn)
        key, c, cens, ev, S, nn = best
        for t, dd in ev:
            recs += [(t, 1)] * dd
        recs += [(t, 0) for t in cens]
        log.append(dict(interval=[a, times[k + 1]], n_start=n, target=target, n_end=nn,
                        events=sum(dd for _, dd in ev), censored=c, visible_ticks=len(tk),
                        resolved=(key[0] == 0)))
        n, S_rec = nn, S
        if n == 0:
            break
    if n > 0:  # anything left is censored at the end of drawn follow-up
        recs += [(t_end, 0)] * n
        log.append(dict(note=f"{n} remaining censored at curve end {t_end:.3f}"))
    return recs, log


def write_atomic(path, rows):
    d = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in rows:
            f.write(f"{g},{t:.4f},{int(e)}\n")
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input")
    ap.add_argument("--out", default="output")
    ap.add_argument("--alt", action="store_true", help="sensitivity allocation")
    args = ap.parse_args()
    np.random.seed(SEED)  # recorded; the algorithm itself is deterministic
    man = json.load(open(os.path.join(args.input, "manifest.json")))
    a = np.array(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(int)
    cal = calibrate(a)
    x0px = cal["x_ticks_px"][0]
    rows, meta = [], {"calibration": cal, "seed": SEED, "arms": {}}
    for g in ["A", "B"]:
        m = measure_arm(a, COLORS[g], cal, x0px)
        recs, log = allocate(m, RISK_TIMES, RISK[g], alt=args.alt)
        assert len(recs) == man["groups"][g], (g, len(recs))
        rows += [(g, max(t, 0.0), e) for t, e in sorted(recs)]
        meta["arms"][g] = dict(measurement=m, allocation_log=log,
                               n_events=int(sum(e for _, e in recs)))
    os.makedirs(args.out, exist_ok=True)
    name = "sensitivity" if args.alt else "ipd"
    json.dump(meta, open(os.path.join(args.out, f"extraction_{name}.json"), "w"), indent=1, default=float)
    write_atomic(os.path.join(args.out, f"{name}.csv"), rows)
    for g in ["A", "B"]:
        print(g, "events", meta["arms"][g]["n_events"], "drops", len(meta["arms"][g]["measurement"]["drops"]),
              "ticks", len(meta["arms"][g]["measurement"]["ticks"]), meta["arms"][g]["measurement"]["notes"],
              meta["arms"][g]["measurement"]["anomalies"])
        for l in meta["arms"][g]["allocation_log"]:
            print("  ", l)


if __name__ == "__main__":
    main()
