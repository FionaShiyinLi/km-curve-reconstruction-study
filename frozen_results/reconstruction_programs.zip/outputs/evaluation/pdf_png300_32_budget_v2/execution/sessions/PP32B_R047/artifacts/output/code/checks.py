#!/usr/bin/env python3
"""Reload committed CSV(s), recompute right-continuous KM per arm, compare with
the measured curve (extraction_ipd.json) and the risk table; write checks.json,
an overlay plot and (if present) the sensitivity comparison.
Usage: python checks.py [--input ../input] [--out output]"""
import argparse, hashlib, json, os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reconstruct import RISK, RISK_TIMES

CHECK_T = [0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 29, 30, 31, 33, 34.5, 35.2]


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return out


def step(curve, t):  # right-continuous
    s = 1.0
    for u, v in curve:
        if u <= t:
            s = v
        else:
            break
    return s


def measured(meas, t):
    s = 1.0
    for d in meas["drops"]:
        if d["t"] <= t:
            s = d["S_after"]
    return s


def rmst(curve, tau):
    area, last, s = 0.0, 0.0, 1.0
    for u, v in curve:
        if u > tau:
            break
        area += s * (u - last); last, s = u, v
    return area + s * (tau - last)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input"); ap.add_argument("--out", default="output")
    args = ap.parse_args()
    man = json.load(open(os.path.join(args.input, "manifest.json")))
    path = os.path.join(args.out, "ipd.csv")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    df = pd.read_csv(path)
    meta = json.load(open(os.path.join(args.out, "extraction_ipd.json")))
    res = {"csv_sha256": sha, "columns_ok": list(df.columns) == ["group", "observed_time", "event"],
           "event_totals_supplied": "unavailable (manifest has no event totals)",
           "tolerance_rule": "|KM - measured| <= 0.003 + 0.5*S_measured/n_at_risk(t): 0.003 = ~2 px "
                             "measurement error (1 px = 0.00133 in S); second term = half of one KM "
                             "event step, the rounding error an integer reconstruction can incur. Fixed before checking.",
           "arms": {}}
    fig_data = {}
    for g in ["A", "B"]:
        d = df[df.group == g]
        cur = km(d); meas = meta["arms"][g]["measurement"]
        arm = {"n": int(len(d)), "n_expected": man["groups"][g], "n_ok": len(d) == man["groups"][g],
               "event_values_ok": bool(d.event.isin([0, 1]).all()),
               "times_ok": bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
               "n_events": int(d.event.sum()), "max_time": float(d.observed_time.max()),
               "curve_end_measured": meas["t_end"], "curve": [], "risk_table": []}
        for t in CHECK_T + [meas["t_end"] - 0.01]:
            m = measured(meas, t); r = step(cur, t)
            n = int((d.observed_time >= t).sum())
            tol = 0.003 + 0.5 * m / max(n, 1)
            arm["curve"].append(dict(t=round(t, 3), measured=round(m, 4), reconstructed=round(r, 4),
                                     residual=round(r - m, 4), tol=round(tol, 4),
                                     status="pass" if abs(r - m) <= tol else "fail"))
        for t, n_obs in zip(RISK_TIMES, RISK[g]):
            n = int((d.observed_time >= t).sum())
            arm["risk_table"].append(dict(t=t, displayed=n_obs, reconstructed=n, residual=n - n_obs,
                                          status="pass" if n == n_obs else "fail"))
        arm["summary"] = {"curve_fail": sum(c["status"] == "fail" for c in arm["curve"]),
                          "risk_fail": sum(c["status"] == "fail" for c in arm["risk_table"])}
        res["arms"][g] = arm; fig_data[g] = (cur, meas)
    spath = os.path.join(args.out, "sensitivity.csv")
    if os.path.exists(spath):
        sd = pd.read_csv(spath)
        tau = float(min(df.groupby("group").observed_time.max().min(), sd.groupby("group").observed_time.max().min()))
        comp = {"assumption": "extra (non-visible) censorings placed at visible tick times of the same "
                              "risk interval instead of greedy placement at between-drop midpoints fitted to measured post-drop levels",
                "common_horizon_months": round(tau, 3), "sha256": hashlib.sha256(open(spath, "rb").read()).hexdigest()}
        for g in ["A", "B"]:
            p, s = km(df[df.group == g]), km(sd[sd.group == g])
            comp[g] = {"S_tau_primary": round(step(p, tau), 4), "S_tau_sensitivity": round(step(s, tau), 4),
                       "RMST_tau_primary": round(rmst(p, tau), 3), "RMST_tau_sensitivity": round(rmst(s, tau), 3),
                       "events_primary": int(df[df.group == g].event.sum()),
                       "events_sensitivity": int(sd[sd.group == g].event.sum())}
        res["sensitivity"] = comp
    else:
        res["sensitivity"] = "not run"
    json.dump(res, open(os.path.join(args.out, "checks.json"), "w"), indent=1)
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        from PIL import Image
        img = np.array(Image.open(os.path.join(args.input, "figure.png")))
        cal = meta["calibration"]; px, py = cal["px"], cal["py"]
        fig, ax = plt.subplots(figsize=(12, 9)); ax.imshow(img)
        for g, col in [("A", "k"), ("B", "m")]:
            cur, _ = fig_data[g]
            ts = [0] + [u for u, _ in cur] + [res["arms"][g]["max_time"]]
            ss = [1] + [v for _, v in cur] + [cur[-1][1]]
            X = [(t - px[1]) / px[0] for t in ts]; Y = [(s - py[1]) / py[0] for s in ss]
            ax.step(X, Y, where="post", color=col, lw=0.7, ls="--")
        fig.savefig(os.path.join(args.out, "overlay.png"), dpi=150); plt.close(fig)
    except Exception as ex:
        print("overlay skipped:", ex)
    for g in "AB":
        print(g, res["arms"][g]["summary"], res["arms"][g]["n_events"])
        for c in res["arms"][g]["curve"]:
            if c["status"] == "fail":
                print("   FAIL", c)
    print(json.dumps(res["sensitivity"], indent=1) if isinstance(res["sensitivity"], dict) else "sens not run")


if __name__ == "__main__":
    main()
