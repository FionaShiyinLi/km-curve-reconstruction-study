"""Stage 2: reconstruct participant records from measured curves, ticks and risk table.

Usage: python reconstruct.py [measurement_dir] [output_dir] [manifest.json]
Own implementation of an iterative (Guyot-type) event/censor allocation; no
KM-to-IPD package is used. Deterministic; the manifest seed is set and recorded
even though no random draws are made.
"""
import sys, os, json, hashlib
import numpy as np
import pandas as pd

MEAS = sys.argv[1] if len(sys.argv) > 1 else os.path.join("output", "measurements")
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
MAN = sys.argv[3] if len(sys.argv) > 3 else os.path.join("..", "input", "manifest.json")
man = json.load(open(MAN))
SEED = int(man["code_seed"]); np.random.seed(SEED)
NS = man["groups"]

# Number-at-risk table read from the figure (OCR by visual inspection)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 663, 469, 309, 217, 89, 0],
        "B": [1000, 727, 519, 391, 294, 109, 0]}
PX_PER_MONTH = 40.0
EVENT_SHIFT = 1.5 / PX_PER_MONTH   # lower-edge drop leads true step by half line width
T_MAX_OBS = 36.0 - 0.5 / PX_PER_MONTH  # zero at risk at 36 -> all times < 36


def load(g):
    c = pd.read_csv(os.path.join(MEAS, f"curve_{g}.csv"))
    tk = pd.read_csv(os.path.join(MEAS, f"ticks_{g}.csv"))
    c = c[c.t >= 0].reset_index(drop=True)
    s = c.S_meas.to_numpy().copy()
    # monotonicity diagnostic before any correction
    viol = np.maximum.accumulate(s[::-1])[::-1] - s  # later value above current
    later_above = float(np.max(np.minimum.accumulate(s) - s + 0))  # 0 by construction
    rising = np.max(s[1:] - np.minimum.accumulate(s)[:-1])
    s_mono = np.minimum(np.minimum.accumulate(s), 1.0)
    return c.t.to_numpy(), s, s_mono, tk, float(rising)


def alloc_int(total, weights):
    """Largest-remainder integer allocation of total across weights."""
    w = np.asarray(weights, float)
    if total <= 0 or len(w) == 0: return np.zeros(len(w), int)
    q = total * w / w.sum(); base = np.floor(q).astype(int)
    rem = total - base.sum()
    order = np.argsort(-(q - base), kind="stable")
    base[order[:rem]] += 1
    return base


def censor_times(c, lo, hi, tk, use_ticks):
    """Place c censorings in [lo, hi)."""
    if c <= 0: return np.array([])
    sel = tk[(tk.t_centre >= lo) & (tk.t_centre < hi)] if use_ticks else tk.iloc[0:0]
    uni = lambda k: lo + (np.arange(k) + 0.5) * (hi - lo) / k if k > 0 else np.array([])
    if len(sel):
        mult = sel.est_multiplicity.to_numpy()
        if c >= mult.sum():
            # each visible tick keeps its estimated multiplicity; censorings required
            # by the risk table but not visible (hidden by overlap/steep drops) are
            # spread uniformly over the interval
            return np.concatenate([np.repeat(sel.t_centre.to_numpy(), mult), uni(c - mult.sum())])
        n = alloc_int(c, mult)
        return np.repeat(sel.t_centre.to_numpy(), n)
    return uni(c)


def run_interval(tt, ss, n_start, S_last, cens, hi=np.inf):
    """Walk columns: events from KM ratio given censor times; returns events list."""
    cens = np.sort(cens); ci = 0
    n = n_start; ev = []
    for t, s in zip(tt, ss):
        while ci < len(cens) and cens[ci] < t:   # censored before this column's step
            n -= 1; ci += 1
        if n <= 0: continue
        d = int(round(n * (1 - s / S_last))) if S_last > 0 else 0
        d = max(0, min(d, n))
        if d:
            ev.append((min(t + EVENT_SHIFT, hi - 0.001), d))
            S_last *= (1 - d / n); n -= d
    n -= (len(cens) - ci)
    return ev, n, S_last


def reconstruct(g, use_ticks=True):
    t, s_raw, s, tk, rising = load(g)
    nr = RISK[g]
    recs = []; S_last = 1.0; log = []
    for i in range(len(RISK_T) - 1):
        lo, hi = RISK_T[i], RISK_T[i + 1]
        m = (t >= lo) & (t < hi)
        n0, n1 = nr[i], nr[i + 1]
        if i == len(RISK_T) - 2:
            # final interval: remaining after the last event are all censored before 36
            # iterate censor count so that events + censorings == n0
            c = max(0, n0 - int(round(n0 * (1 - s[m][-1] / S_last))))
            for _ in range(100):
                ct = np.minimum(censor_times(c, lo, hi, tk, use_ticks), T_MAX_OBS)
                ev, nend, Sl = run_interval(t[m], s[m], n0, S_last, ct, hi)
                d = sum(k for _, k in ev)
                if d + c == n0: break
                c = n0 - d
        else:
            c = max(0, n0 - n1 - int(round(n0 * (1 - s[m][-1] / S_last))))
            best = None
            for _ in range(100):
                ct = censor_times(c, lo, hi, tk, use_ticks)
                ev, nend, Sl = run_interval(t[m], s[m], n0, S_last, ct, hi)
                err = nend - n1
                if best is None or abs(err) < abs(best[0]): best = (err, c, ct, ev, Sl)
                if err == 0: break
                c = max(0, c + err)
            err, c, ct, ev, Sl = best
        d = sum(k for _, k in ev)
        log.append(dict(interval=[lo, hi], n_start=n0, n_end_table=n1, events=d, censored=int(len(ct)),
                        n_end_recon=n0 - d - len(ct)))
        for te, k in ev: recs += [(g, te, 1)] * k
        recs += [(g, float(x), 0) for x in ct]
        S_last = Sl
    return recs, log, dict(max_rise_px_equiv=rising * 750)


def km(df):
    """Right-continuous KM step function (events before censorings at ties)."""
    d = df.sort_values(["observed_time", "event"], ascending=[True, False])
    times = np.unique(d.observed_time[d.event == 1])
    S = 1.0; out_t = [0.0]; out_s = [1.0]
    for u in times:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        S *= 1 - e / n; out_t.append(u); out_s.append(S)
    return np.array(out_t), np.array(out_s)


def km_at(kt, ks, x): return ks[np.searchsorted(kt, x, side="right") - 1]


def rmst(kt, ks, h):
    tt = np.append(kt[kt < h], h); return float(np.sum(np.diff(tt) * ks[:len(tt) - 1]))


def atomic_csv(df, path):
    tmp = path + ".tmp"; df.to_csv(tmp, index=False); os.replace(tmp, path)


def sha(path): return hashlib.sha256(open(path, "rb").read()).hexdigest()


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    allrec = []; logs = {}; diag = {}
    for g in ["A", "B"]:
        r, lg, dg = reconstruct(g, use_ticks=True)
        assert len(r) == NS[g], (g, len(r))
        allrec += r; logs[g] = lg; diag[g] = dg
    ipd = pd.DataFrame(allrec, columns=["group", "observed_time", "event"])
    ipd["observed_time"] = ipd.observed_time.round(4)
    ipd = ipd.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    atomic_csv(ipd, os.path.join(OUT, "ipd.csv"))
    json.dump(dict(seed=SEED, interval_log=logs, diag=diag),
              open(os.path.join(OUT, "measurements", "recon_log.json"), "w"), indent=1)

    # ---------- checks from the committed file ----------
    f = os.path.join(OUT, "ipd.csv"); back = pd.read_csv(f)
    checks = dict(csv_sha256=sha(f), seed=SEED, arms={})
    TOL = 0.005
    for g in ["A", "B"]:
        d = back[back.group == g]; kt, ks = km(d)
        c = pd.read_csv(os.path.join(MEAS, f"curve_{g}.csv"))
        ct = [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.9]
        surv = []
        for x in ct:
            row = c.iloc[(c.t - x).abs().argmin()]
            meas = float(row.S_meas); rec = float(km_at(kt, ks, x))
            surv.append(dict(t=x, measured=round(meas, 4), reconstructed=round(rec, 4),
                             residual=round(rec - meas, 4), status="pass" if abs(rec - meas) <= TOL else "fail"))
        risk = []
        for x, n in zip(RISK_T, RISK[g]):
            k = int((d.observed_time >= x).sum())
            risk.append(dict(t=x, table=n, reconstructed=k, residual=k - n, status="pass" if k == n else "fail"))
        checks["arms"][g] = dict(
            n_records=int(len(d)), n_expected=NS[g], n_ok=bool(len(d) == NS[g]),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
            max_time=float(d.observed_time.max()),
            supplied_event_total="unavailable (not in manifest)",
            survival=surv, risk_table=risk)
    checks["survival_tolerance"] = dict(
        value=TOL, justification="about 3.75 px on the 750 px/unit survival axis: +-1 px edge quantization, "
        "+-0.5 px line-centre estimate, and integer-event granularity; fixed before viewing residuals")

    # ---------- one sensitivity allocation: uniform censoring within risk intervals ----------
    alt = []
    for g in ["A", "B"]:
        r, _, _ = reconstruct(g, use_ticks=False); assert len(r) == NS[g]; alt += r
    alt = pd.DataFrame(alt, columns=["group", "observed_time", "event"])
    alt["observed_time"] = alt.observed_time.round(4)
    alt = alt.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    atomic_csv(alt, os.path.join(OUT, "sensitivity.csv"))
    H = 35.9
    sens = dict(assumption="censor times spread uniformly within each risk-table interval (tick positions ignored); "
                "same measured curve and risk counts", horizon_months=H, arms={})
    for g in ["A", "B"]:
        k1 = km(back[back.group == g]); k2 = km(alt[alt.group == g])
        sens["arms"][g] = dict(S_primary=round(float(km_at(*k1, H)), 4), S_alt=round(float(km_at(*k2, H)), 4),
                               RMST_primary=round(rmst(*k1, H), 3), RMST_alt=round(rmst(*k2, H), 3),
                               events_primary=int(back[back.group == g].event.sum()),
                               events_alt=int(alt[alt.group == g].event.sum()),
                               S_at_12_primary=round(float(km_at(*k1, 12)), 4), S_at_12_alt=round(float(km_at(*k2, 12)), 4))
    checks["sensitivity"] = dict(sens, csv_sha256=sha(os.path.join(OUT, "sensitivity.csv")))
    json.dump(checks, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
    print(json.dumps(logs, indent=0)); print(json.dumps(diag))
    for g in "AB":
        a = checks["arms"][g]
        print(g, a["events"], a["censored"], [(s["t"], s["residual"], s["status"]) for s in a["survival"]])
        print(" risk", [(r["t"], r["residual"]) for r in a["risk_table"]])
    print(json.dumps(checks["sensitivity"]["arms"]))
