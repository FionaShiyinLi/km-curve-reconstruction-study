# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800×1350 raster Kaplan–Meier (KM) plot, two arms, number-at-risk table).
- `../input/manifest.json`: n = 1000 per arm, time in months, code seed 2066078804. The seed is set
  and recorded. The algorithm is deterministic and makes no random draws.
- The manifest has no arm-specific event totals, so there is no event-total check (`unavailable` in
  checks.json). The reconstructed totals (A 792, B 709 events) come from the curve and risk table.
- Risk table, read visually at 0, 6, …, 36 months: A 1000, 663, 469, 309, 217, 89, 0;
  B 1000, 727, 519, 391, 294, 109, 0. The digits are crisp, so I consider the readings reliable.

## Measurement (`code/extract.py`)
- Calibration uses the labelled axis ticks: x = 0 and x = 36 at pixel columns 269.5 and 1709.5
  (40 px/month); S = 1.0 and S = 0.0 at rows 179.5 and 929.5 (750 px/unit). The mapping is linear and
  there is no other global transform or rescaling.
- Arms are separated by exact line colour (blue A, orange B; no antialiasing in the raster). For each
  column the curve level is the lower line edge minus half the measured line width (4 px). The lower
  edge is used because orange is drawn over blue. Where the curves overlap (about 0–1 month), blue's
  upper edge is hidden but its lower edge stays visible. Only one blue column was flagged as possibly
  occluded.
- Censor ticks (about 16 px tall, 2–3 px wide) are removed with a local forward minimum of the
  lower edge over 40 px. A clean column's own value is always included, so this correction cannot
  carry a misread point forward. The trailing tick cluster at the right end uses the top edge plus
  line width. After this step the measured curves are monotone (maximum rise 0 px), so no
  running-minimum correction was applied. At the origin, the local pixels show real steep early
  drops in both arms (about 20 events in A within 0.3 months). These drops are kept. The curve is
  not forced flat or rescaled.
- There is an ambiguous blue vertical mark at t ≈ 0 (cols 269–271, centred about 3 px below S = 1).
  It was not classified as a censor tick and is not used.
- Measurements are saved in `measurements/curve_{A,B}.csv` and `measurements/ticks_{A,B}.csv`.
  Tick multiplicity is estimated as round(cluster width / 3 px). This is a visibility-based estimate:
  overlapping ticks in the dense tails (24–36 months) cannot be counted reliably.

## Reconstruction (`code/reconstruct.py`, my own Guyot-type iteration)
- The algorithm works through each risk-table interval [t_i, t_{i+1}) column by column. The number
  of events at a column is d = round(n_risk · (1 − S_meas/S_KM,last)). Here S_KM,last is the
  reconstructed KM value, so rounding does not accumulate. This means d is set by the size of the
  drop and n_risk, not fixed at 1. A column-level drop can represent tied or near-tied events
  (resolution 0.025 months). Event times are shifted by +1.5 px (half the line width), because the
  lower edge leads the drawn step. Event times are clamped to stay inside their interval.
- The censoring count c_i in each interval is iterated until the reconstructed count at risk at
  t_{i+1} equals the table value. All intervals converged exactly.
- **Censor placement is an assumption.** Each visible tick gets its estimated multiplicity. If the
  risk table requires more censorings than there are visible ticks (true in every interval: for
  example A 0–6 needs 20 censorings but shows 5 ticks), the excess is spread uniformly over the
  interval. If fewer are required, the ticks share the count in proportion to their multiplicity.
  The constraints on this choice are the risk counts, the tick positions and the curve drops.
  Nothing constrains exact censor times between ticks.
- Last interval: 0 at risk at 36 means every record must have observed_time < 36. Censorings are
  capped at 35.9875 months and none are placed at 36. I did not infer an accrual pattern or any
  follow-up beyond the drawn curve from the flat tails.

## Verification (checks.json, recomputed from the reloaded final CSV)
- Right-continuous KM step estimate vs. measured curve at 18 times (0.5–35.9 months, including the
  tails). All absolute residuals are ≤ 0.0023. The tolerance of 0.005 (about 3.75 px) was fixed before
  looking at residuals. It allows ±1 px edge quantization, ±0.5 px line-centre error, and integer-event
  granularity.
- Counts with observed_time ≥ t match the risk table exactly at all 7 times in both arms, including
  0 at 36. Each arm has 1000 records, event is 0/1, and all times are finite and nonnegative.
- The checks compare against my own measurements. Agreement shows internal consistency, not
  recovery of the original records.

## Sensitivity (one alternative, `sensitivity.csv`)
- Alternative assumption: all censorings are spread uniformly within each risk interval, ignoring
  tick positions. Same curve and risk counts. The common horizon is 35.9 months (both curves are
  drawn to about 36).
- S(35.9): A 0.1252 vs 0.1237; B 0.2052 vs 0.2024. Restricted mean survival time (RMST) to 35.9: A 14.760 vs 14.758;
  B 17.396 vs 17.395 months. Event counts are unchanged. This is one alternative, not an
  uncertainty bound.

## Unresolved limitations
- Individual censor times are not identified. Hidden ticks (early overlap region, steep drops) and
  merged tail tick clusters make tick counts lower bounds at best. The risk table fixes censoring
  counts only per 6-month interval.
- The event/censoring split inside an interval relies on pixel-resolution drops (1 px ≈ 0.0013 in S,
  or about 1.3 events at n = 1000). Events within one 0.025-month column are tied.
- Primary correction cycles after the first complete file: (1) clamped boundary event times and
  widened the de-spike window, fixing risk-count mismatches of 1–3 at 6, 12 and 30 months and a
  4-px local misread near 27.6 months in A; (2) changed the tick allocation so excess censorings are
  no longer piled onto visible ticks. checks.json was regenerated from the final CSV.
