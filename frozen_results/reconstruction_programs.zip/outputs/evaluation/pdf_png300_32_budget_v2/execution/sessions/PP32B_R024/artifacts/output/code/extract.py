"""Stage 1: measure KM curves and censor ticks from the raster figure.

Usage: python extract.py [path/to/figure.png] [outdir]
Writes curve_<G>.csv (per-column measurement) and ticks_<G>.csv.
"""
import sys, os, json
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join("..", "input", "figure.png")
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join("output", "measurements")
os.makedirs(OUT, exist_ok=True)

# Axis calibration from labelled ticks (measured tick pixel pairs, see assumptions.md):
# x: "0" tick cols 269-270, "36" tick cols 1709-1710 -> centres 269.5, 1709.5
# y: "1.0" tick rows 179-180, "0.0" tick rows 929-930 -> centres 179.5, 929.5
X0, X36 = 269.5, 1709.5
Y1, Y0 = 179.5, 929.5
def col2t(x): return (x - X0) / (X36 - X0) * 36.0
def row2s(y): return (Y0 - y) / (Y0 - Y1)

COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
im = np.array(Image.open(FIG).convert("RGB")).astype(int)
H, W, _ = im.shape
masks = {g: (np.abs(im - np.array(c)).sum(2) < 60) for g, c in COLORS.items()}
# restrict to plotting region
for g in masks:
    masks[g][:170, :] = False
    masks[g][935:, :] = False
    masks[g][:, :268] = False

def edges(m):
    top = np.full(W, np.nan); bot = np.full(W, np.nan)
    for x in range(W):
        r = np.where(m[:, x])[0]
        if len(r):
            top[x], bot[x] = r.min(), r.max()
    return top, bot

diag = {}
for g in ["A", "B"]:
    m = masks[g]
    other = masks["B" if g == "A" else "A"]
    top, bot = edges(m)
    xs = np.where(~np.isnan(top))[0]
    xmin, xmax = xs.min(), xs.max()
    # occlusion flag: coloured pixel of the other arm directly below the lower edge
    # or directly above the upper edge -> that edge may be hidden
    occl_bot = np.zeros(W, bool); occl_top = np.zeros(W, bool)
    for x in range(xmin, xmax + 1):
        if np.isnan(bot[x]):
            occl_bot[x] = occl_top[x] = True; continue
        b, t = int(bot[x]), int(top[x])
        if other[b + 1:b + 3, x].any(): occl_bot[x] = True
        if other[max(t - 2, 0):t, x].any(): occl_top[x] = True
    # Lower edge: remove tick spikes. The true lower edge is nondecreasing in row
    # (curve falls). A tick raises bot for ~2-3 columns and then returns, so the
    # local forward minimum over a 40 px window (wide tail tick clusters) removes it without
    # propagating anything globally.
    Wwin = 40
    L = bot.copy()
    for x in range(xmin, xmax + 1):
        seg = bot[x:min(x + Wwin + 1, xmax + 1)]
        seg = seg[~np.isnan(seg)]
        if len(seg): L[x] = seg.min()
    T = top.copy()
    for x in range(xmin, xmax + 1):
        seg = top[max(x - Wwin, xmin):x + 1]
        seg = seg[~np.isnan(seg)]
        if len(seg): T[x] = seg.max()
    # line thickness from flat columns (T and L unchanged over +-3 columns, no ticks)
    thick = []
    for x in range(xmin + 5, xmax - 5):
        if (not occl_bot[x] and not occl_top[x] and np.all(L[x - 3:x + 4] == L[x])
                and np.all(T[x - 3:x + 4] == T[x]) and bot[x] == L[x] and top[x] == T[x]):
            thick.append(L[x] - T[x] + 1)
    thick = np.array(thick)
    w = float(np.median(thick))
    # Trailing tick cluster at the right end has no clean column after it, so the
    # forward minimum cannot remove its lower spike; there use the top edge
    # (backward max, tick-free) plus line width instead.
    x = xmax
    while x > xmin and L[x] - T[x] + 1 > w + 1:
        L[x] = T[x] + w - 1
        x -= 1
    # ticks: column where raw top is well above T (upper extension) AND raw bottom
    # well below L -> a vertical censor mark crossing the line
    ext_up = T - top; ext_dn = bot - L
    tickcol = (ext_up >= 3) & (ext_dn >= 3)
    ticks = []
    x = xmin
    while x <= xmax:
        if tickcol[x]:
            x2 = x
            while x2 + 1 <= xmax and tickcol[x2 + 1]: x2 += 1
            ticks.append((x, x2))
            x = x2 + 1
        else:
            x += 1
    # tick width in isolated clusters
    widths = np.array([b - a + 1 for a, b in ticks])
    tw = float(np.median(widths)) if len(widths) else 2.0
    diag[g] = dict(xmin=int(xmin), xmax=int(xmax), thickness_median=w,
                   thickness_q=[float(np.percentile(thick, q)) for q in (10, 50, 90)],
                   n_tick_clusters=len(ticks), tick_width_median=tw,
                   n_occluded_bot=int(occl_bot[xmin:xmax + 1].sum()))
    # Level of curve centre: lower edge minus half line width (w-1)/2
    half = (w - 1) / 2.0
    with open(os.path.join(OUT, f"curve_{g}.csv"), "w") as f:
        f.write("col,t,top_raw,bot_raw,T,L,occl_bot,S_meas\n")
        for x in range(xmin, xmax + 1):
            s = row2s(L[x] - half) if not np.isnan(L[x]) else np.nan
            f.write(f"{x},{col2t(x):.4f},{top[x]},{bot[x]},{T[x]},{L[x]},{int(occl_bot[x])},{s:.5f}\n")
    with open(os.path.join(OUT, f"ticks_{g}.csv"), "w") as f:
        f.write("col_start,col_end,width,t_centre,est_multiplicity\n")
        for a, b in ticks:
            wd = b - a + 1
            mult = max(1, int(round(wd / tw)))
            f.write(f"{a},{b},{wd},{col2t((a + b) / 2):.4f},{mult}\n")
json.dump(dict(calibration=dict(X0=X0, X36=X36, Y1=Y1, Y0=Y0), arms=diag),
          open(os.path.join(OUT, "extract_diag.json"), "w"), indent=1)
print(json.dumps(diag, indent=1))
