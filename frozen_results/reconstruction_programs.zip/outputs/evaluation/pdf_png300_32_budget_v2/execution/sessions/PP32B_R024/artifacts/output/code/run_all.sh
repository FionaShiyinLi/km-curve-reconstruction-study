#!/bin/sh
# Run from the work directory (sibling of ../input). Optional: $1 = figure, $2 = manifest.
set -e
FIG=${1:-../input/figure.png}; MAN=${2:-../input/manifest.json}
HERE=$(dirname "$0")
python3 "$HERE/extract.py" "$FIG" output/measurements
python3 "$HERE/reconstruct.py" output/measurements output "$MAN"
