# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 1917141806). No other information was used. The manifest gives no event totals, so none were used; this is recorded as *unavailable* in `checks.json`.

## Measurement
- The figure is a vector PDF. Each arm's KM curve is one stroked path (A: blue, 156 vertices; B: orange, 128 vertices), and each censor mark is a separate 4-pt vertical line object in the arm's color. Coordinates were read directly with pdfplumber, so no pixel tracing or OCR was needed. The risk table and axis labels come from the PDF text layer.
- Calibration is a linear fit to the labelled axis ticks: x = 0…36 months ↔ 64.8…410.4 pt (9.6 pt/month); S = 1…0 ↔ 43.2…223.2 pt. The fit residual is about 1e-13 pt. The curve starts exactly at (0, 1.0), so no origin correction or global rescaling was applied. Running-minimum smoothing was not used.
- Measured vertices are saved in `curve_points_{A,B}.csv`. Per-drop and per-tick readings are in `extraction_diagnostics.json`.

## Algorithm (`code/reconstruct.py`)
1. Vertical path segments give the event times t_j and the levels S_before and S_after.
2. Censor ticks give the censoring times (tick centers; each line object counts as one participant).
3. A forward pass runs from n = 100. At each drop, n_risk is 100 minus prior events minus censorings strictly before t_j, and d_j = round(n_risk·(1 − S_after/S_before)). A censor tick at the same time as a drop (one case, A at 2.84 months) stays in the risk set for that drop, i.e. event before censoring. The unrounded d_j equalled an integer to within 1e-3 at every drop, and all d_j = 1. This d = 1 result is inferred from the exact vector ratio together with the reconstructed risk set; it was not assumed.
4. Risk-table reconciliation: in each interval [6k, 6k+6), unmarked censorings = table decrease − events − ticks. The code would place any positive count uniformly within the interval. In practice it was **zero in every interval for both arms**, so no unmarked censorings were added. Every tick maps to exactly one participant, and the counts add up exactly. The displayed 0 at risk at 36 months holds because the last records are at 35.41 (A) and 35.29 (B), both < 36.
5. No randomness is used. The seed is set and recorded anyway. Output is written to a temporary file and then atomically renamed to `ipd.csv`. Times are rounded to 1e-4 months.

## Results
- A: 77 events and 23 censorings. B: 63 events and 37 censorings.
- `code/checks.py` reloads the committed CSV and recomputes the right-continuous KM. The maximum absolute difference from the measured step levels, taken at the midpoints of all horizontal segments, is 0 (tail included). All 7 risk-table counts per arm match exactly, counted as observed_time ≥ t. See `checks.json`, which includes the SHA-256.

## Limitations
- If two or more participants were censored at identical plotted coordinates, their ticks could overlap as one object. The risk table rules out any extra censorings within each 6-month interval, but not their exact placement if a tick hid more than one participant. Given the exact interval reconciliation, no such case is needed.
- Times are limited by the plotting resolution of the source figure. Ties in the original data cannot be separated from plotted coincidence.
- **Sensitivity analysis not run.** The supplied constraints (exact integer drop ratios, tick counts, and risk table) leave no materially different allocation of events and censorings, so an alternative allocation would be artificial. This is not a claim that the original records have been uniquely recovered: timing within plotting precision and any hidden coincident ticks remain unidentified.
