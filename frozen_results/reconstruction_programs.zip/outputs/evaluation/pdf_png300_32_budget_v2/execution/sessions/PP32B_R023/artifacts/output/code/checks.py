"""Reload committed output/ipd.csv, recompute right-continuous KM, compare with PDF-measured curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path)
diag = json.load(open(os.path.join(OUT, "extraction_diagnostics.json")))
risk_t = [0, 6, 12, 18, 24, 30, 36]
risk = {"A": [100, 68, 52, 39, 25, 7, 0], "B": [100, 64, 57, 48, 38, 15, 0]}
N = {"A": 100, "B": 100}
TOL_S = 0.002  # vector coordinates are exact to ~0.01 pt (5.6e-5 in S); 0.002 allows rounding of path coordinates

def km(d):
    t = np.sort(d.observed_time.unique()); s = 1.0; out = []
    for u in t:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((u, s))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for u, v in steps:
        if u <= t + 1e-12: s = v
        else: break
    return s

res = {"csv_sha256": sha, "columns_ok": list(df.columns) == ["group", "observed_time", "event"], "arms": {}}
allpass = True
for g in "AB":
    d = df[df.group == g]
    steps = km(d)
    cp = pd.read_csv(os.path.join(OUT, f"curve_points_{g}.csv"))
    # measured: midpoints of each horizontal segment of the vector path (+ tail endpoint)
    hs = [(cp.t[i], cp.t[i + 1], cp.S[i]) for i in range(len(cp) - 1) if abs(cp.S[i] - cp.S[i + 1]) < 1e-9 and cp.t[i + 1] > cp.t[i]]
    idx = sorted(set(np.linspace(0, len(hs) - 1, 12).astype(int)) | {0, 1, len(hs) - 1})
    comps = []
    for i in idx:
        a, b, s = hs[i]; t = (a + b) / 2 if i < len(hs) - 1 else b
        r = S_at(steps, t); comps.append(dict(t=round(t, 4), measured=round(s, 5), reconstructed=round(r, 5), resid=round(r - s, 5),
                                              status="pass" if abs(r - s) <= TOL_S else "fail"))
    maxres_all = max(abs(S_at(steps, (a + b) / 2) - s) for a, b, s in hs)
    rc = []
    for t, n in zip(risk_t, risk[g]):
        m = int((d.observed_time >= t).sum())
        rc.append(dict(t=t, table=n, reconstructed=m, resid=m - n, status="pass" if m == n else "fail"))
    arm = dict(n=len(d), n_ok=len(d) == N[g], event_values_ok=bool(set(d.event.unique()) <= {0, 1}),
               n_events=int(d.event.sum()), supplied_event_total="unavailable (not in manifest)",
               max_time=float(d.observed_time.max()), measured_curve_end=diag[g]["curve_end_time"],
               max_abs_resid_all_segments=round(float(maxres_all), 6), curve_checks=comps, risk_checks=rc,
               tail_check=dict(t=comps[-1]["t"], measured=comps[-1]["measured"], reconstructed=comps[-1]["reconstructed"]))
    arm["status"] = "pass" if (arm["n_ok"] and arm["event_values_ok"] and maxres_all <= TOL_S and all(x["status"] == "pass" for x in rc)) else "fail"
    allpass &= arm["status"] == "pass"
    res["arms"][g] = arm
res["tolerance_S"] = TOL_S
res["tolerance_justification"] = "Curve read from exact PDF vector path; calibration residual ~1e-13 pt; 0.002 in S covers coordinate rounding only."
res["overall"] = "pass" if allpass else "fail"
json.dump(res, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
print(json.dumps({g: {k: v for k, v in res["arms"][g].items() if k not in ("curve_checks",)} for g in "AB"}, indent=1), res["overall"], sha)
