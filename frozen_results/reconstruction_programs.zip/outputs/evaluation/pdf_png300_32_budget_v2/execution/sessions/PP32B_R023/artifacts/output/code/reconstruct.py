"""KM -> IPD reconstruction from vector PDF paths (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]   (defaults ../input, output)
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
man = json.load(open(os.path.join(IN, "manifest.json")))
np.random.seed(man["code_seed"])  # no randomness used; seed recorded
page = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]

# ---- axis calibration from labelled tick marks (PDF top-down coordinates)
lines = page.lines
xt = sorted({round(l["x0"], 3) for l in lines if l["top"] == 223.2 and l["bottom"] > 225 and l["x0"] == l["x1"]})
yt = sorted({round(l["top"], 3) for l in lines if l["x0"] < 62 and l["x1"] == 64.8})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax, bx = np.polyfit(xlab, xt, 1); ay, by = np.polyfit(ylab, yt, 1)
T = lambda x: (x - bx) / ax
S = lambda y: (y - by) / ay
calib = dict(x_ticks_pt=xt, y_ticks_pt=yt, pt_per_month=ax, x0=bx, pt_per_unitS=ay, y_at_S0=by,
             x_resid=float(np.max(np.abs(np.polyval([ax, bx], xlab) - xt))),
             y_resid=float(np.max(np.abs(np.polyval([ay, by], ylab) - yt))))

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}
risk_t = [0, 6, 12, 18, 24, 30, 36]
risk = {"A": [100, 68, 52, 39, 25, 7, 0], "B": [100, 64, 57, 48, 38, 15, 0]}  # read from PDF text layer

def extract(g):
    cv = [c for c in page.curves if tuple(c["stroking_color"]) == COL[g]]
    assert len(cv) == 1
    pts = cv[0]["pts"]
    drops, horiz = [], []
    for (x1, y1), (x2, y2) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x2) < 1e-6 and y2 > y1 + 1e-6:
            drops.append((T(x1), S(y1), S(y2)))
        elif abs(y1 - y2) < 1e-6:
            horiz.append((T(x1), T(x2), S(y1)))
    ticks = [l for l in lines if tuple(l["stroking_color"]) == COL[g] and l["x0"] == l["x1"] and abs(l["bottom"] - l["top"] - 4) < 1e-6]
    ticks = sorted((T(l["x0"]), S((l["top"] + l["bottom"]) / 2)) for l in ticks)
    return pts, drops, horiz, ticks, T(pts[-1][0])

def reconstruct(g, extra_rule="uniform"):
    pts, drops, horiz, ticks, tend = extract(g)
    N = man["groups"][g]; R = risk[g]
    extra = []  # unmarked censorings (times)
    for it in range(50):
        # forward KM pass with current censor set
        cens = sorted([t for t, _ in ticks] + extra)
        events = []; n = N; ci = 0; Sprev = 1.0
        for (t, s0, s1) in drops:
            while ci < len(cens) and cens[ci] < t - 1e-9:
                n -= 1; ci += 1
            d = int(round(n * (1 - s1 / s0)))
            events.append((t, d, n, s0, s1)); n -= d
        # risk-table reconciliation per interval
        new_extra = []
        ok = True
        for k in range(len(risk_t) - 1):
            a, b = risk_t[k], risk_t[k + 1]
            ev = sum(d for t, d, *_ in events if a <= t < b)
            tk = sum(1 for t, _ in ticks if a <= t < b)
            need = R[k] - R[k + 1] - ev - tk
            if need < 0:
                ok = False; need = 0
            if need > 0:
                # place unmarked censorings uniformly within the interval (strictly inside, before b)
                hi = min(b, tend) if b > tend else b
                new_extra += list(a + (np.arange(need) + 0.5) / need * (hi - a))
        if sorted(new_extra) == sorted(extra):
            break
        extra = new_extra
    rec = [(t, 1) for t, d, *_ in events for _ in range(d)] + [(t, 0) for t, _ in ticks] + [(t, 0) for t in extra]
    return rec, events, ticks, extra, ok, it, (pts, drops, horiz, tend)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    allrec, diag = [], {"calibration": calib}
    for g in ["A", "B"]:
        rec, events, ticks, extra, ok, it, geo = reconstruct(g)
        diag[g] = dict(n_records=len(rec), n_events=sum(e for _, e in rec), n_ticks=len(ticks),
                       n_unmarked_censor=len(extra), reconcile_ok=ok, iterations=it,
                       curve_end_time=geo[3],
                       drops=[dict(t=round(t, 4), S_before=round(s0, 5), S_after=round(s1, 5), n_risk=n, d=d,
                                   d_raw=round(n * (1 - s1 / s0), 3)) for t, d, n, s0, s1 in events],
                       ticks=[dict(t=round(t, 4), S=round(s, 5)) for t, s in ticks],
                       unmarked_censor_times=[round(x, 4) for x in extra])
        assert len(rec) == man["groups"][g], (g, len(rec))
        allrec += [(g, round(t, 4), e) for t, e in rec]
        pd.DataFrame(geo[0], columns=["x_pt", "y_pt"]).assign(t=lambda d: T(d.x_pt), S=lambda d: S(d.y_pt)) \
            .to_csv(os.path.join(OUT, f"curve_points_{g}.csv"), index=False)
    df = pd.DataFrame(allrec, columns=["group", "observed_time", "event"]).sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    tmp = os.path.join(OUT, "ipd.csv.tmp")
    df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, "ipd.csv"))
    json.dump(diag, open(os.path.join(OUT, "extraction_diagnostics.json"), "w"), indent=1)
    print(json.dumps({g: {k: v for k, v in diag[g].items() if k not in ("drops", "ticks")} for g in "AB"}, indent=1))
    print(calib)
    for g in "AB":
        print(g, "d>1 or non-integer drops:", [x for x in diag[g]["drops"] if x["d"] != 1 or abs(x["d_raw"] - x["d"]) > 0.15])
