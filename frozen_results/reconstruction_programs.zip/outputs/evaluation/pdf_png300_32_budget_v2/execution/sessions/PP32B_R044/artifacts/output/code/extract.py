"""Extract KM step paths and censor ticks from the vector PDF (no pixel work needed).
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
# axis anchors: x ticks at labels 0..36, y ticks at 0.0..1.0
xt = sorted({round(l['pts'][0][0], 4) for l in blk if abs(l['pts'][0][0]-l['pts'][1][0]) < 1e-6 and abs(l['pts'][0][1]-l['pts'][1][1]) == 3})
yt = sorted({round(l['pts'][0][1], 4) for l in blk if abs(l['pts'][0][1]-l['pts'][1][1]) < 1e-6 and abs(l['pts'][0][0]-l['pts'][1][0]) == 3})
x0, x36 = xt[0], xt[-1]; ytop, ybot = yt[0], yt[-1]
tx = lambda x: (x - x0) / (x36 - x0) * 36.0
sy = lambda y: (ybot - y) / (ybot - ytop)
col = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
res = {'calibration': {'x_ticks_pt': xt, 'y_ticks_pt': yt, 'x0': x0, 'x36': x36, 'y_S1': ytop, 'y_S0': ybot}}
for g, c in col.items():
    cv = [k for k in pg.curves if k['stroking_color'] == c]
    assert len(cv) == 1
    pts = [(tx(x), sy(y)) for x, y in cv[0]['pts']]
    ticks = [l for l in pg.lines if l['stroking_color'] == c and l['linewidth'] < 0.9]
    tk = [(tx(l['pts'][0][0]), sy((l['pts'][0][1] + l['pts'][1][1]) / 2)) for l in ticks]
    res[g] = {'path': pts, 'ticks': sorted(tk)}
json.dump(res, open(f'{out}/extracted_vector.json', 'w'))
print('calib', res['calibration'])
