# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 1000 per arm, months, seed 680119195). No event totals are supplied, so none were checked (marked unavailable in `checks.json`).

**Measurement.** The figure is native vector graphics, so no rasterization, OCR or pixel tracing was used. `code/extract.py` reads the PDF with pdfplumber:
- Each arm is a single step path drawn only with horizontal and vertical segments. Blue is Group A and orange is Group B, identified from the legend line colors.
- Censor marks are 4-pt vertical ticks in the arm's color.
- Calibration is linear from the labelled axis tick anchors: x = 64.8 pt at 0 and 410.4 pt at 36 months; y = 223.2 pt at S = 0 and 43.2 pt at S = 1.
- Both paths start exactly at S = 1.0 at t = 0, so no origin correction or global rescaling was applied. Genuine early drops are preserved (the first drop in each arm is 1 − 1/1000).
- Raw extracted geometry is saved in `extracted_vector.json`.
- The risk table was read from the PDF text layer at 0, 6, ..., 36 months.

**Algorithm** (`code/reconstruct.py`, deterministic, no randomness). The program walks the drops in time order, starting from n = 1000:
- n_risk = N − (events so far) − (ticks strictly before t). A tick at the same time as a drop would remain at risk (events before censoring), but none coincide.
- At each drop, d = round(n_risk·(1 − S_after/S_before)). The values of d are not assumed to be 1; they are solved from the ratio. In practice all solved d equal 1, and the largest deviation from an integer is 0.0005, so the solution is tightly determined.
- Each tick becomes one censored record at the tick's time.
- Result: A has 762 events and 238 censorings; B has 624 events and 376 censorings. Both total exactly 1000.
- No tick x-position is duplicated. The tick-per-participant assumption is supported by exact closure to n and by exact agreement with every risk-table count. It is still an assumption, because coincident marks of tied censorings would be indistinguishable.
- Censoring times are the drawn tick positions. No censoring distribution or follow-up was invented. The last record in each arm is a censoring at the curve end (A 35.98, B 35.90 months), consistent with 0 at risk at 36.

**Verification** (`checks.json`, computed from the reloaded committed CSV and recording its SHA-256):
- **KM curve:** the right-continuous KM was compared with the measured path at 17 times per arm, including the tail up to the curve end, and at the midpoint of every horizontal path segment. Maximum absolute residual is 2.8e-7. The tolerance is 0.001 in S (about 0.18 pt), which is well above PDF coordinate rounding.
- **Risk table:** counts of observed_time ≥ t match the table exactly at all seven times in both arms, including 0 at 36.
- **Other checks:** arm sizes and 0/1 event indicators pass.

**Limitations.**
- Times are recovered only to the precision of the plotted coordinates (about 1e-4 months).
- If the original data had tied censorings drawn as a single tick, or ties between events and censorings, the figure cannot show them. The exact risk-table agreement makes material hidden ties unlikely but does not rule them out.
- No sensitivity allocation was run. The event and censoring allocation is fully constrained by the drop ratios, tick counts, sample sizes and risk table, so there was no materially different plausible alternative to test.
