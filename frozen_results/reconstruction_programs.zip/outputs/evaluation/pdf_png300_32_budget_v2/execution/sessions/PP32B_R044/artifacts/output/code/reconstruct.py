"""KM-figure -> participant records, from vector PDF geometry.
Usage: python output/code/reconstruct.py [../input/figure.pdf] [../input/manifest.json] [output]
Deterministic; seed recorded (680119195) but no randomness is used."""
import sys, os, json, hashlib, subprocess
import numpy as np, pandas as pd
here = os.path.dirname(os.path.abspath(__file__))
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
man = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
out = sys.argv[3] if len(sys.argv) > 3 else 'output'
M = json.load(open(man)); SEED = M['code_seed']; np.random.seed(SEED)
subprocess.run([sys.executable, os.path.join(here, 'extract.py'), pdf, out], check=True)
R = json.load(open(f'{out}/extracted_vector.json'))
# risk table read from PDF text layer (pdfplumber words), times 0..36 step 6
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 686, 480, 337, 232, 83, 0], 'B': [1000, 637, 530, 439, 371, 140, 0]}
EPS = 1e-9
recs, solve_log = [], {}
for g in 'AB':
    N = M['groups'][g]; p = R[g]['path']; tk = np.array([t[0] for t in R[g]['ticks']])
    drops = [(p[i][0], p[i-1][1], p[i][1]) for i in range(1, len(p))
             if abs(p[i][0]-p[i-1][0]) < 1e-12 and p[i][1] < p[i-1][1] - 1e-12]
    D = 0; res = []; dlist = []
    for t, sb, sa in drops:
        n_r = N - D - int(np.sum(tk < t - EPS))  # censor tick at the same time stays at risk
        dd = n_r * (1 - sa / sb); d = int(round(dd)); assert d >= 1
        res.append(dd - d); D += d; dlist.append(d)
        recs += [(g, t, 1)] * d
    recs += [(g, t, 0) for t in tk]
    assert D + len(tk) == N, (g, D, len(tk), N)
    solve_log[g] = {'n_drops': len(drops), 'events': D, 'censored_ticks': int(len(tk)),
                    'max_abs_d_residual': float(np.max(np.abs(res))),
                    'drops_with_d_gt_1': int(sum(1 for d in dlist if d > 1)),
                    'ticks_coinciding_with_drop_time': int(sum(np.any(np.abs(tk - t) < EPS) for t, _, _ in drops))}
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
df['observed_time'] = df['observed_time'].round(6)
tmp = f'{out}/ipd.csv.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')

# ---------- verification from the committed CSV ----------
d2 = pd.read_csv(f'{out}/ipd.csv')
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
def km(sub):
    t = sub.observed_time.values; e = sub.event.values; S = 1.0; ut = np.unique(t[e == 1]); st = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d / n; st.append((u, S))
    return np.array(st)
def step_eval(st, x):  # right-continuous
    i = np.searchsorted(st[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else float(st[i, 1])
def path_eval(p, x):  # measured vector path, right-continuous
    s = 1.0
    for tt, yy in p:
        if tt <= x + 1e-12: s = yy
        else: break
    return s
TOL = 0.001  # ~0.18 pt; PDF coordinates carry >=3 decimals in pt (S resolution ~6e-6)
checks = {'csv_sha256': sha, 'seed': SEED, 'calibration': R['calibration'], 'solve': solve_log, 'arms': {}}
for g in 'AB':
    sub = d2[d2.group == g]; st = km(sub); p = R[g]['path']; tend = p[-1][0]
    times = [0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 34, 35, 35.5, round(tend, 4)]
    kc = []
    for x in times:
        m, r_ = path_eval(p, x), step_eval(st, x)
        kc.append({'t': x, 'measured': round(m, 6), 'reconstructed': round(r_, 6), 'residual': round(r_ - m, 6), 'status': 'pass' if abs(r_ - m) <= TOL else 'fail'})
    # all path vertices
    # every horizontal segment of the measured path, evaluated at its midpoint
    allres = max(abs(step_eval(st, (p[i][0] + p[i+1][0]) / 2) - p[i][1]) for i in range(len(p) - 1)
                 if abs(p[i][1] - p[i+1][1]) < 1e-12 and p[i+1][0] > p[i][0])
    rc = []
    for t, n in zip(RISK_T, RISK[g]):
        c = int(np.sum(sub.observed_time.values >= t))
        rc.append({'t': t, 'table': n, 'reconstructed': c, 'residual': c - n, 'status': 'pass' if c == n else 'fail'})
    checks['arms'][g] = {
        'n_records': int(len(sub)), 'n_manifest': M['groups'][g], 'size_status': 'pass' if len(sub) == M['groups'][g] else 'fail',
        'event_indicator_integer_01': bool(set(sub.event.unique()) <= {0, 1}),
        'events': int(sub.event.sum()), 'supplied_event_total': 'unavailable (not in manifest)',
        'max_obs_time': float(sub.observed_time.max()), 'curve_end_time': tend,
        'km_checks': kc, 'max_abs_residual_all_path_vertices': allres, 'tolerance': TOL,
        'tolerance_justification': 'vector coordinates; 0.001 in S = 0.18 pt, far above PDF coordinate rounding',
        'risk_checks': rc, 'risk_convention': 'count observed_time >= t'}
json.dump(checks, open(f'{out}/checks.json', 'w'), indent=1)
for g in 'AB':
    a = checks['arms'][g]
    print(g, a['n_records'], a['events'], 'maxres', a['max_abs_residual_all_path_vertices'],
          [c['status'] for c in a['km_checks']].count('fail'), 'km fails', [c['reconstructed'] for c in a['risk_checks']])
print('sha', sha)
