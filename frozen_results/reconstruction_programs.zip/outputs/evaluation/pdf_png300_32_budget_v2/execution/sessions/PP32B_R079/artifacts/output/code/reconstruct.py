#!/usr/bin/env python3
"""KM figure -> approximate participant-level records (own implementation).

Usage: python3 reconstruct.py [--input ../input] [--out output] [--alt]
Paths default relative to the work directory (run from work/).
Steps: (1) pixel extraction of each arm's step curve and censor ticks,
(2) axis calibration from labelled tick anchors, (3) isotonic cleanup,
(4) interval-wise event/censor reconstruction constrained by the risk table.
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
from PIL import Image

SEED = 91326020
ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
ap.add_argument("--alt", action="store_true",
                help="sensitivity: censors uniform within risk-table intervals")
args = ap.parse_args()
rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic

man = json.load(open(os.path.join(args.input, "manifest.json")))
img = np.asarray(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(float)

# ---- calibration (from axis tick pixels found by inspection: x ticks at
# columns 269-270 (0), 509-510 (6) ... 1709-1710 (36); y ticks at rows
# 179-180 (1.0) ... 929-930 (0.0)).  Linear fit over all labelled anchors.
xt_px = np.array([269.5, 509.5, 749.5, 989.5, 1229.5, 1469.5, 1709.5]); xt_v = np.arange(0, 37, 6)
yt_px = np.array([179.5, 329.5, 479.5, 629.5, 779.5, 929.5]); yt_v = np.array([1, .8, .6, .4, .2, 0])
ax_, bx_ = np.polyfit(xt_px, xt_v, 1)
ay_, by_ = np.polyfit(yt_px, yt_v, 1)
t_of = lambda x: ax_ * x + bx_
s_of = lambda r: ay_ * r + by_

# risk table read visually from the figure (times 0,6,...,36)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 701, 483, 317, 217, 69, 0], "B": [1000, 645, 529, 427, 353, 135, 0]}
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
X0, X1 = 270, 1709          # columns with t in (0, 36)
R0, R1 = 165, 935           # plot rows (legend excluded)


def extract(g):
    d = np.sqrt(((img - np.array(COL[g])) ** 2).sum(2))
    m = d < 90
    m[:R0] = False; m[R1:] = False
    xs = np.arange(X0, X1 + 1)
    lvl = np.full(len(xs), np.nan)
    k = 4
    for i, x in enumerate(xs):
        c = m[:, x]
        l = m[:, max(x - k, X0)] if x - k >= X0 else c
        r = m[:, x + k]
        sup = np.where(c & l & r)[0]
        if len(sup) == 0:
            continue
        med = np.median(sup)
        sup = sup[np.abs(sup - med) <= 3]
        lvl[i] = sup.mean()
    raw = lvl.copy()
    ok = ~np.isnan(lvl)
    lvl = np.interp(xs, xs[ok], lvl[ok])  # fill obscured columns (e.g. overlap)
    s_raw = s_of(lvl)
    # Origin neighbourhood (t < ORIGIN_T): both arms overlap and fall steeply,
    # the y-axis and a tick coincide, so the support-based reading is not
    # reliable there.  Local remeasurement only: per-column centroid of the
    # arm's colour inside a +/-6 row band around a line from the axis anchor
    # (t=0, S=1; both curves visibly start at 1.0) to the first reliable
    # reading at ORIGIN_T.  Calibration elsewhere is untouched.
    ORIGIN_T = 0.5
    tt = t_of(xs); j0 = np.argmax(tt >= ORIGIN_T)
    r_end = lvl[j0]; r_top = 179.5
    for i in range(j0):
        guide = r_top + (r_end - r_top) * tt[i] / tt[j0]
        band = np.arange(int(guide - 6), int(guide + 7))
        hit = band[m[band, xs[i]]]
        rr = hit.mean() if len(hit) else guide
        s_raw[i] = s_of(rr)
        ok[i] = len(hit) > 0
    s_iso = pava_dec(s_raw)
    # censor ticks: colored pixels 4..11 rows below the local line centre
    # (step curves never extend below the level to their right)
    tick = np.zeros(len(xs), bool)
    for i, x in enumerate(xs):
        ref = lvl[i:i + 4].max()
        rr = np.arange(int(np.ceil(ref + 4)), int(ref + 12))
        tick[i] = m[rr, x].sum() >= 3
    marks = []
    i = 0
    while i < len(xs):
        if tick[i]:
            j = i
            while j + 1 < len(xs) and tick[j + 1]:
                j += 1
            w = j - i + 1
            marks.append((t_of((xs[i] + xs[j]) / 2), w, max(1, int(round(w / 3)))))
            i = j + 1
        else:
            i += 1
    return xs, t_of(xs), s_raw, s_iso, ok, marks


def pava_dec(y):
    """isotonic (non-increasing) least-squares fit; no running minimum."""
    v = list(-np.asarray(y)); w = [1.0] * len(v); idx = [[i] for i in range(len(v))]
    out_v, out_w, out_i = [], [], []
    for a, b, c in zip(v, w, idx):
        out_v.append(a); out_w.append(b); out_i.append(c)
        while len(out_v) > 1 and out_v[-2] > out_v[-1]:
            nv = (out_v[-2] * out_w[-2] + out_v[-1] * out_w[-1]) / (out_w[-2] + out_w[-1])
            nw = out_w[-2] + out_w[-1]; ni = out_i[-2] + out_i[-1]
            out_v[-2:] = [nv]; out_w[-2:] = [nw]; out_i[-2:] = [ni]
    res = np.empty(len(v))
    for a, c in zip(out_v, out_i):
        res[c] = -a
    return res


def censor_times(c, lo, hi, marks, tgrid, uniform):
    """c censor times in [lo,hi): quantiles of tick-mark weights (primary)
    or uniform over the interval (sensitivity / no ticks)."""
    if c <= 0:
        return np.array([])
    mk = [(t, wt) for t, _, wt in marks if lo <= t < hi]
    q = (np.arange(c) + 0.5) / c
    if uniform or not mk:
        tt = lo + q * (hi - lo)
    else:
        tm = np.array([a for a, _ in mk]); wm = np.array([b for _, b in mk], float)
        cdf = np.cumsum(wm) / wm.sum()
        tt = tm[np.searchsorted(cdf, q, side="left").clip(0, len(tm) - 1)]
    # snap to pixel-column grid, keep strictly inside [lo, hi)
    tt = tgrid[np.clip(np.searchsorted(tgrid, tt), 0, len(tgrid) - 1)]
    tt = np.where(tt >= hi, tgrid[tgrid < hi].max(), tt)
    return np.sort(tt)


def sweep(tg, sg, n0, km0, cts):
    """events per column so KM tracks measured S; censors after events at ties."""
    n, km, ev = n0, km0, []
    ci = 0
    for t, s in zip(tg, sg):
        if n <= 0:
            break
        d = int(round(n * (1 - s / km))) if km > 0 else 0
        d = max(0, min(d, n))
        if d:
            ev += [t] * d; km *= 1 - d / n; n -= d
        while ci < len(cts) and cts[ci] <= t + 1e-9:
            n -= 1; ci += 1
    n -= len(cts) - ci
    return ev, n, km


def reconstruct(g, tg, sg, marks, uniform):
    rt = RISK[g]
    km, recs, info = 1.0, [], []
    for k in range(len(RT_T) - 1):
        lo, hi = RT_T[k], RT_T[k + 1]
        n0, n1 = rt[k] if k == 0 else nstart, rt[k + 1]
        sel = (tg >= lo) & (tg < hi)
        best = None
        for c in range(0, n0 - n1 + 1):
            cts = censor_times(c, lo, hi, marks, tg[sel], uniform)
            ev, nend, km1 = sweep(tg[sel], sg[sel], n0, km, cts)
            err = abs(nend - n1)
            if best is None or err < best[0]:
                best = (err, c, ev, nend, km1, cts)
            if nend < n1 and err > best[0]:
                break
        err, c, ev, nend, km1, cts = best
        if nend != n1:  # residual mismatch: adjust censors at interval end, record it
            info.append(f"{g} [{lo},{hi}): end-risk mismatch {nend} vs {n1}")
        recs += [(g, t, 1) for t in ev] + [(g, t, 0) for t in cts]
        info.append(dict(interval=[lo, hi], n_start=n0, n_end_target=n1, n_end=nend,
                         events=len(ev), censored=int(c)))
        km = km1; nstart = nend
    # anyone left (should be 0 because risk at 36 is 0) censored at last column
    if nstart > 0:
        recs += [(g, float(tg.max()), 0)] * nstart
    return recs, info


def main():
    out = args.out; os.makedirs(out, exist_ok=True)
    allrecs, meta = [], {}
    for g in ["A", "B"]:
        xs, tg, s_raw, s_iso, ok, marks = extract(g)
        pd.DataFrame(dict(x=xs, t=tg, s_raw=s_raw, s_iso=s_iso, directly_measured=ok)).to_csv(
            os.path.join(out, f"curve_{g}.csv"), index=False)
        pd.DataFrame(marks, columns=["t", "width_px", "weight"]).to_csv(
            os.path.join(out, f"ticks_{g}.csv"), index=False)
        recs, info = reconstruct(g, tg, s_iso, marks, args.alt)
        assert len(recs) == man["groups"][g], (g, len(recs))
        allrecs += recs
        meta[g] = dict(intervals=info, n_marks=len(marks),
                       first_cols=[round(v, 4) for v in s_raw[:6]],
                       missing_cols=int((~ok).sum()))
        print(g, json.dumps(meta[g]))
    df = pd.DataFrame(allrecs, columns=["group", "observed_time", "event"])
    df["observed_time"] = df.observed_time.round(4)
    fn = os.path.join(out, "sensitivity.csv" if args.alt else "ipd.csv")
    tmp = fn + ".tmp"
    df.to_csv(tmp, index=False); os.replace(tmp, fn)
    json.dump(meta, open(os.path.join(out, "recon_meta_alt.json" if args.alt else "recon_meta.json"), "w"), indent=1)
    print("wrote", fn, hashlib.sha256(open(fn, "rb").read()).hexdigest())


main()
