# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 91326020). The manifest has no arm-specific event totals, so there was nothing to reconcile against. The event counts below are outputs of the reconstruction, not supplied constraints. No other information was used. The runtime provides only Python, so the code is in Python (numpy/pandas/PIL/matplotlib) rather than R. The seed is set in the code, but the algorithm is deterministic.

**Run (from `work/`):** `python3 output/code/reconstruct.py` writes the primary `ipd.csv`. `--alt` writes `sensitivity.csv`. `python3 output/code/checks.py` writes `checks.json` and `overlay.png`. Both scripts take `--input`/`--out` arguments.

## Measurement
- **Calibration:** linear, fitted to the tick pixels of every labelled axis anchor. Time 0, 6, …, 36 sits at columns 269.5 + 40k (40 px/month). Survival 1.0 to 0.0 runs from row 179.5 to row 929.5 (750 px/unit). No global rescaling was applied.
- **Curve level:** each arm is classified by colour distance (< 90 RGB units) from its line colour. For each column, the level is the mean of coloured rows that are also coloured 4 px to the left and to the right (the horizontal line), after trimming to ±3 rows of their median. Censor ticks are about 3 px wide and roughly symmetric about the line, so they are rejected or cancel out. Columns with no support (curve overlap near the crossing at about 8–9 months, vertical drops, clutter at the origin) are filled by linear interpolation of the pixel readings only. The number of such columns is in `recon_meta.json`.
- **Monotonicity:** enforced with isotonic least-squares (PAVA), not a running minimum. A single misread point therefore cannot propagate forward through the curve.
- **Origin:** the first reading gave B = 0.986 at t = 0.01. This was a misread: the y-axis, a tick, and both steeply falling curves overlap there. The first 0.5 months only were remeasured as the per-column colour centroid inside a ±6-row band around a guide line from (0, 1.0) to the reading at 0.5 months. Both arms now start at about 0.999, and the early drop is kept (B about 0.954 at 0.5 months). Calibration elsewhere is unchanged.
- **Extracted data:** `curve_A.csv` and `curve_B.csv` (raw and isotonic S per column) and `ticks_A.csv` and `ticks_B.csv` (detected tick marks).

## Reconstruction algorithm (own implementation, Guyot-type)
- **Risk table:** read visually. A: 1000/701/483/317/217/69/0; B: 1000/645/529/427/353/135/0, at 0, 6, …, 36 months.
- **Events:** within each 6-month interval, events at each pixel column (0.025-month resolution) are d = round(n_risk · (1 − S_meas/S_KM,current)). This tracks the *cumulative* measured curve, so a drop can represent several tied events. d = 1 is not assumed, and sub-pixel events are emitted when the accumulated gap exceeds half an event.
- **Censoring counts:** in each interval, the censoring count c is the integer that makes the number at risk at the next table time equal the displayed value. This was achieved exactly in every interval for both arms.
- **Censoring times (assumption):** censored observations are placed at quantiles of the detected censor-tick positions in that interval. Each tick cluster is weighted by width/3 px. Tick *visibility* is not tick *multiplicity*: overlapping ticks in the dense 24–36 month region cannot be counted, so these weights only shape timing. Counts come from the risk table. At tied times, events come before censorings.
- **Tail:** the displayed risk at 36 is 0. All remaining participants therefore exit before 36: last censoring at 35.9875 months (the final pixel column < 36). The flat tail does not identify the censoring distribution or the end of follow-up. Placing censorings at the visible ticks is an assumption.
- **Outcome:** A has 791 events and 209 censored; B has 634 events and 366 censored. These are reconstruction outputs, not supplied totals.

## Checks (`checks.json`; values recomputed from the reloaded final CSV)
- **Risk table:** counts of observed_time ≥ t match the displayed numbers at all 7 times for both arms (0 at 36 is met because no record is ≥ 36).
- **Curve fit:** the right-continuous KM step function was compared with the measured curve at 21 times (0.25 to 35.9 months, including the tail). All are within the tolerance of 0.01. The tolerance is about 7.5 px: 3 px line width plus tick clutter and quantisation. Over all columns, the maximum absolute residual is 0.0039 (A) and 0.0046 (B); the mean is 0.0005.
- **Record checks:** n = 1000 per arm, event indicators in {0, 1}, finite nonnegative times.
- **Event totals:** the supplied-totals check is marked unavailable.

## Sensitivity (one alternative, executed)
- **Alternative:** `sensitivity.csv` places each interval's censorings uniformly over the interval instead of at tick positions. Event counts per interval are unchanged.
- **Common supported horizon:** 35.9 months.
- **A:** S(35.9) is 0.121 (primary) vs 0.124 (alternative). The area under the curve to 35.9 months (RMST) is 15.09 vs 15.11 months.
- **B:** S(35.9) is 0.286 vs 0.284. RMST is 18.18 vs 18.18 months.
- **Scope:** both versions pass all risk and curve checks. This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- Exact event and censoring times within pixel columns, the true tie structure, and censorings hidden under dense or overlapping ticks are not identifiable. The records are one feasible approximation, not a unique recovery.
- The risk-table numbers were read by eye from clear text and are treated as certain. The origin segment (< 0.5 months) and the crossover region depend on local remeasurement and interpolation.
