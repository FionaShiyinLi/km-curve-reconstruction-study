#!/usr/bin/env python3
"""Reload committed CSV(s), recompute right-continuous KM, compare with measured
curve and risk table, write output/checks.json and an overlay figure.
Usage: python3 checks.py [--input ../input] [--out output]"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input"); ap.add_argument("--out", default="output")
a = ap.parse_args()
RT_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 701, 483, 317, 217, 69, 0], "B": [1000, 645, 529, 427, 353, 135, 0]}
N = json.load(open(os.path.join(a.input, "manifest.json")))["groups"]
CHK_T = [0.25, 0.5, 1, 2, 3, 4.5, 6, 8, 10, 12, 15, 18, 21, 24, 26, 28, 30, 32, 34, 35, 35.9]
TOL = 0.01  # ~7.5 px: line width (3 px) + censor-tick clutter + pixel quantisation


def km(df):
    """right-continuous KM step function; events before censors at ties."""
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; st = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; st.append(s)
    st = np.array(st)
    f = lambda x: 1.0 if x < ut[0] else st[np.searchsorted(ut, x, side="right") - 1]
    return ut, st, f


def rmst(ut, st, h):
    grid = np.concatenate([[0], ut[ut < h], [h]]); vals = np.concatenate([[1], st[ut < h]])
    return float((np.diff(grid) * vals).sum())


def check(fn):
    df = pd.read_csv(fn)
    res = dict(file=os.path.basename(fn), sha256=hashlib.sha256(open(fn, "rb").read()).hexdigest(),
               columns_ok=list(df.columns) == ["group", "observed_time", "event"], arms={})
    for g in ["A", "B"]:
        d = df[df.group == g]
        cur = pd.read_csv(os.path.join(a.out, f"curve_{g}.csv"))
        ut, st, f = km(d)
        rows = []
        for t in CHK_T:
            i = int(np.argmin(np.abs(cur.t - t)))
            meas = float(cur.s_raw[i]); rec = f(t)
            rows.append(dict(t=t, measured=round(meas, 4), reconstructed=round(rec, 4),
                             residual=round(rec - meas, 4),
                             status="pass" if abs(rec - meas) <= TOL else "fail"))
        # dense check on all columns
        dense = np.array([f(t) for t in cur.t]) - cur.s_raw.values
        rk = []
        for t, n in zip(RT_T, RISK[g]):
            c = int((d.observed_time >= t).sum())
            rk.append(dict(t=t, displayed=n, reconstructed=c, residual=c - n,
                           status="pass" if c == n else "fail"))
        res["arms"][g] = dict(
            n=len(d), n_expected=N[g], n_ok=len(d) == N[g],
            event_integer_ok=bool(d.event.isin([0, 1]).all()),
            times_ok=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            max_time=float(d.observed_time.max()),
            supplied_event_total="unavailable (not in manifest)",
            curve_checks=rows, curve_tolerance=TOL,
            dense_abs_resid_max=round(float(np.abs(dense).max()), 4),
            dense_abs_resid_mean=round(float(np.abs(dense).mean()), 4),
            risk_checks=rk, km_at_35_9=round(f(35.9), 4), rmst_35_9=round(rmst(ut, st, 35.9), 3))
    return res, df


out = {}
res, df = check(os.path.join(a.out, "ipd.csv")); out["primary"] = res
sens = os.path.join(a.out, "sensitivity.csv")
if os.path.exists(sens):
    r2, _ = check(sens)
    out["sensitivity"] = dict(assumption="censor times uniform within each risk-table interval "
                              "(primary: placed at quantiles of detected censor-tick positions)",
                              horizon_months=35.9, sha256=r2["sha256"],
                              comparison={g: dict(primary_S=res["arms"][g]["km_at_35_9"],
                                                  alt_S=r2["arms"][g]["km_at_35_9"],
                                                  primary_RMST=res["arms"][g]["rmst_35_9"],
                                                  alt_RMST=r2["arms"][g]["rmst_35_9"],
                                                  alt_risk_all_pass=all(x["status"] == "pass" for x in r2["arms"][g]["risk_checks"]),
                                                  alt_curve_fail=[x["t"] for x in r2["arms"][g]["curve_checks"] if x["status"] != "pass"])
                                          for g in "AB"})
else:
    out["sensitivity"] = "not run"
json.dump(out, open(os.path.join(a.out, "checks.json"), "w"), indent=1)

img = Image.open(os.path.join(a.input, "figure.png"))
fig, ax = plt.subplots(figsize=(18, 13.5), dpi=100)
ax.imshow(img, alpha=0.45)
for g, c in [("A", "navy"), ("B", "red")]:
    ut, st, _ = km(df[df.group == g])
    tt = np.concatenate([[0], np.repeat(ut, 2), [36]]); ss = np.concatenate([[1, 1], np.repeat(st, 2)])[:len(tt)]
    ax.plot(269.5 + 40 * tt, 929.5 - 750 * ss, color=c, lw=0.8)
ax.set_xlim(250, 1730); ax.set_ylim(950, 160)
fig.savefig(os.path.join(a.out, "overlay.png"), bbox_inches="tight")
for g in "AB":
    r = res["arms"][g]
    print(g, r["n"], r["events"], "dense max/mean", r["dense_abs_resid_max"], r["dense_abs_resid_mean"],
          [(x["t"], x["residual"]) for x in r["curve_checks"] if x["status"] != "pass"],
          [x["status"] for x in r["risk_checks"]])
print(res["sha256"])
