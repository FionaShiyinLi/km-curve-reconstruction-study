"""Extract KM step curves and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
blk = [l for l in pg.lines if l['stroking_color'] in ((0.0, 0.0, 0.0), 0, [0])]
# axis ticks: x ticks are vertical 3pt below axis, y ticks horizontal 3pt
xt = sorted(round(l['x0'], 4) for l in blk if abs(l['x1']-l['x0']) < 1e-6 and abs(l['bottom']-l['top']-3) < 1e-6)
yt = sorted(round(l['top'], 4) for l in blk if abs(l['bottom']-l['top']) < 1e-6 and abs(l['x1']-l['x0']-3) < 1e-6)
words = pg.extract_words()
xlab = [float(w['text']) for w in words if abs(w['top']-229.7) < 1 ]
ylab = [float(w['text']) for w in words if w['x0'] < 45 and w['top'] < 230 and w['text'][0].isdigit()]
cal = dict(xtick_pos=xt, xtick_lab=sorted(xlab), ytick_pos=yt, ytick_lab=sorted(ylab, reverse=True))
# legend line colour -> group from neighbouring text
leg = {}
for l in pg.lines:
    if abs(l['x1']-l['x0']-18) < 1e-6:
        near = min((w for w in words if w['text'] in 'AB' and abs(w['top']-16.2) < 1), key=lambda w: abs(w['x0']-l['x1']))
        leg[str(tuple(l['stroking_color']))] = near['text']
cal['legend'] = leg
res = {'calibration': cal, 'curves': {}, 'ticks': {}}
for c in pg.curves:
    g = leg[str(tuple(c['stroking_color']))]
    res['curves'][g] = [list(p) for p in c['pts']]
for l in pg.lines:
    col = str(tuple(l['stroking_color'])) if isinstance(l['stroking_color'], (tuple, list)) else None
    if col in leg and abs(l['x1']-l['x0']) < 1e-6 and abs(l['bottom']-l['top']-4) < 1e-6:
        res['ticks'].setdefault(leg[col], []).append([l['x0'], (l['top']+l['bottom'])/2])
json.dump(res, open(f'{out}/extracted_vectors.json', 'w'))
print(json.dumps(cal), {g: len(v) for g, v in res['curves'].items()}, {g: len(v) for g, v in res['ticks'].items()})
