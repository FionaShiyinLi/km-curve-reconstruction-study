"""Reload committed ipd.csv, recompute right-continuous KM and compare with the measured vector curve and risk table.
Usage: python checks.py [output_dir]"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
V = json.load(open(os.path.join(out, 'extracted_vectors.json'))); cal = V['calibration']
ax = np.polyfit(cal['xtick_pos'], cal['xtick_lab'], 1); ay = np.polyfit(cal['ytick_pos'], cal['ytick_lab'], 1)
path = os.path.join(out, 'ipd.csv'); sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 695, 478, 341, 224, 83, 0], 'B': [1000, 755, 550, 401, 289, 86, 0]}
def km(d):
    ut = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out_t, out_s = [0.0], [1.0]
    for u in ut:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        S *= 1 - e / n; out_t.append(u); out_s.append(S)
    return np.array(out_t), np.array(out_s)
def step(tt, ss, x): return ss[np.searchsorted(tt, x, side='right') - 1]
TOL_S = 1e-4   # vector coords carry ~1e-4 pt precision (~6e-7 in S); 1e-4 allows for rounding of written times
res = {'ipd_sha256': sha, 'survival_tolerance': TOL_S,
       'tolerance_justification': 'vector PDF coordinates (4-5 decimals in pt; 180 pt = 1.0 survival); times rounded to 1e-6 months in CSV',
       'groups': {}}
allpass = True
for g in 'AB':
    d = df[df.group == g]; kt, ks = km(d)
    p = np.array(V['curves'][g]); mt = np.polyval(ax, p[:, 0]); ms = np.polyval(ay, p[:, 1])
    # measured value at time x: right-continuous => take last vertex with t <= x (post-drop)
    def meas(x):
        i = np.where(mt <= x + 1e-9)[0][-1]; return float(ms[i])
    times = [0.0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, float(mt[-1])]
    sc = []
    for x in times:
        m = meas(x); r = float(step(kt, ks, x)); sc.append(dict(time=round(x, 4), measured=m, reconstructed=r, residual=r - m,
                                                                status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # every step vertex
    um = np.unique(np.round(mt, 6)); mids = (um[:-1] + um[1:]) / 2  # between-vertex midpoints avoid rounding at jump times
    allres = [abs(float(step(kt, ks, x)) - meas(x)) for x in mids]
    rk = []
    for t0, n0 in zip(RISK_T, RISK[g]):
        c = int((d.observed_time >= t0).sum()); rk.append(dict(time=t0, displayed=n0, reconstructed=c, residual=c - n0,
                                                              status='pass' if c == n0 else 'fail'))
    ne = int(d.event.sum())
    gres = dict(n=int(len(d)), n_expected=1000, events=ne, censored=int(len(d) - ne),
                supplied_event_total='unavailable (not in manifest)',
                event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
                max_time=float(d.observed_time.max()), plotted_curve_end=float(mt[-1]),
                survival_checks=sc, max_abs_residual_all_intervertex_midpoints=float(max(allres)),
                n_censor_ticks=len(V['ticks'][g]), risk_table_checks=rk)
    allpass &= all(c['status'] == 'pass' for c in sc + rk) and len(d) == 1000
    res['groups'][g] = gres
    print(g, len(d), ne, 'max vertex resid', max(allres), [(c['time'], c['reconstructed'], c['displayed']) for c in rk])
res['overall'] = 'pass' if allpass else 'fail'
json.dump(res, open(os.path.join(out, 'checks.json'), 'w'), indent=1)
print(res['overall'], sha)
