"""KM -> IPD reconstruction from vector-extracted step curves (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]
Requires extracted_vectors.json produced by extract.py in output_dir."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
inp = sys.argv[1] if len(sys.argv) > 1 else '../input'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
man = json.load(open(os.path.join(inp, 'manifest.json')))
SEED = man['code_seed']; np.random.seed(SEED)  # no stochastic step is used; seed recorded
V = json.load(open(os.path.join(out, 'extracted_vectors.json')))
cal = V['calibration']
# linear calibration from labelled tick anchors (least squares over all anchors)
ax = np.polyfit(cal['xtick_pos'], cal['xtick_lab'], 1); ay = np.polyfit(cal['ytick_pos'], cal['ytick_lab'], 1)
X = lambda x: np.polyval(ax, x); Y = lambda y: np.polyval(ay, y)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 695, 478, 341, 224, 83, 0], 'B': [1000, 755, 550, 401, 289, 86, 0]}

def steps(g):
    p = np.array(V['curves'][g]); t = X(p[:, 0]); s = Y(p[:, 1])
    dr = [(t[i], s[i-1], s[i]) for i in range(1, len(p)) if abs(p[i, 0]-p[i-1, 0]) < 1e-9 and s[i] < s[i-1]-1e-9]
    return t, s, dr

diag = {}
def reconstruct(g):
    N = man['groups'][g]; t, s, dr = steps(g)
    ticks = sorted(X(x) for x, _ in V['ticks'][g])
    ev = [(tt, 0, sb, sa) for tt, sb, sa in dr] + [(tt, 1, None, None) for tt in ticks]
    ev.sort(key=lambda e: (round(e[0], 6), e[1]))  # events before censorings at tied times
    n = N; S = 1.0; rec = []; dlog = []
    for tt, kind, sb, sa in ev:
        if kind == 0:
            r = sa / sb
            d = int(round(n * (1 - r)))           # multiplicity from drop size and current risk set
            d = max(d, 1)
            n_impl = d / (1 - r)                  # risk set implied by drop, for consistency check
            dlog.append(dict(t=tt, n=n, d=d, n_implied=n_impl, S_meas=sa, S_rec=S*(1-d/n)))
            S *= 1 - d / n; rec += [(g, tt, 1)] * d; n -= d
        else:
            rec.append((g, tt, 0)); n -= 1
    diag[g] = dlog
    return rec, n

recs = {}; left = {}
for g in 'AB':
    recs[g], left[g] = reconstruct(g)
    dl = pd.DataFrame(diag[g])
    print(g, 'records', len(recs[g]), 'remaining', left[g], 'd>1:', int((dl.d > 1).sum()),
          'max |n-n_impl|', round((dl.n - dl.n_implied).abs().max(), 3),
          'max |S_rec-S_meas|', (dl.S_rec - dl.S_meas).abs().max())
    dl.to_csv(os.path.join(out, f'drop_diagnostics_{g}.csv'), index=False)
ok = all(len(recs[g]) == man['groups'][g] and left[g] == 0 for g in 'AB')
if not ok: sys.exit('reconstruction inconsistent with sample sizes; not committing')
df = pd.DataFrame(recs['A'] + recs['B'], columns=['group', 'observed_time', 'event'])
df['observed_time'] = df.observed_time.clip(lower=0).round(6)
tmp = os.path.join(out, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(out, 'ipd.csv'))
print('committed', len(df))
