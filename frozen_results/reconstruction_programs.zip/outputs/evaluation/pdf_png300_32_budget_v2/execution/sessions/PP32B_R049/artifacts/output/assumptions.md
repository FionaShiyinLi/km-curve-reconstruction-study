# Reconstruction assumptions and methods

## Inputs
- `../input/figure.pdf` (vector PDF), `../input/manifest.json` (n = 1000 per arm, months, seed 1806052182).
- Number-at-risk table read from the PDF text layer (exact strings, no OCR): A 1000/695/478/341/224/83/0, B 1000/755/550/401/289/86/0 at 0/6/12/18/24/30/36 months.
- No arm-specific event totals are supplied, so the event-total check is marked unavailable.

## Measurement (`code/extract.py`)
- The figure is vector. Each arm's KM curve is a single stroked path (A: blue, 1554 vertices; B: orange, 1396). The arm labels come from the legend line nearest each "Group A/B" label. Censor marks are 4-pt vertical strokes in the arm colour (A: 224, B: 303). None coincide in x, and every mark's centre lies on its arm's curve (|Δy| < 1e-15).
- Calibration is a linear least-squares fit to the labelled axis tick strokes: x 64.8→0 and 410.4→36 months; y 223.2→0 and 43.2→1.0. The fit is exact. The curve starts at exactly S = 1.0 at t = 0, so no origin correction or global rescaling was applied. Real early drops are kept: the first drops are at 0.009 months (A) and 0.074 months (B).
- Raw extracted vectors are saved as `extracted_vectors.json`.

## Algorithm (`code/reconstruct.py`)
- The program processes the drops and censor marks in time order. At tied times, events come before censorings. It starts with n = 1000 at risk.
- At each vertical drop, d = round(n_risk·(1 − S_after/S_before)), using the forward risk set rather than assuming d = 1. The risk set implied by the drop, d/(1 − ratio), is logged in `drop_diagnostics_{A,B}.csv`. It agreed with the forward risk set to within 0.48, the resolution limit of the 4–5-decimal coordinates when n is near 1000. At small n the agreement is much tighter.
- Result: every drop resolves to d = 1. The cumulative reconstructed KM matches every measured vertex to within 2.8e-7. Error does not accumulate, which would happen if any multiplicity or risk set were wrong.
- Each censor mark is one censoring at the mark's x position. This multiplicity is an assumption, but the data constrain it tightly: events plus marks equal exactly 1000 in both arms (A 776 + 224, B 697 + 303). Any extra hidden censoring would push the later drop ratios off the measured values.
- The latest censorings fall at the plotted curve end (35.96 months for A, 35.82 for B), which is before 36. This agrees with the displayed zero at 36 without placing anyone at exactly 36. No follow-up beyond the plotted curve was invented.
- The procedure is deterministic. The seed is set and recorded but not used.

## Verification (`code/checks.py` → `checks.json`)
- The committed CSV is reloaded and the right-continuous KM is recomputed (no interpolation). It is compared with the measured step curve at 18 times per arm, including the start and the tail, and at every midpoint between vertices. The maximum absolute residual is 2.8e-7; the tolerance is 1e-4, justified by the coordinate precision and 1e-6 time rounding.
- The count of records with observed_time ≥ t equals the displayed risk count at all 7 risk-table times in both arms.
- Each arm has 1000 records with integer 0/1 event indicators.

## Limitations
- Event and censoring times are the plotted x positions, rounded to 1e-6 months. The original data's precision (for example, whole days) cannot be recovered.
- Several events at exactly the same time would show up as one larger drop, and the drop-ratio test would have detected this. It found none. Censorings at identical times would draw overlapping marks. The exact closure of totals and the risk table leaves no room for hidden ones, but coincident marks between drops cannot be ruled out in principle if they were offset by an equal number of missing marks elsewhere. Such an offset would also have to preserve every drop ratio, so this is very unlikely.
- Sensitivity analysis was not run. No materially different allocation is consistent with the inputs, and no `sensitivity.csv` exists. This is not a claim of a quantified error bound.
