# Reconstruction assumptions

**Inputs used:** `../input/figure.pdf` (a vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 1300004219). The manifest has no arm-specific event totals, so that check is marked unavailable.

**Measurement:** `pdfplumber` gives the vector objects directly, so the figure was not rasterized. Axis calibration uses a linear fit to the labelled tick marks: x ticks at 0–36 months, y ticks at 0.0–1.0. The fit residual is 0 at every anchor, and no global rescaling was applied. Arm identity comes from the legend colours: A is blue and B is orange. Each arm is a single step path starting at (0, 1.0), so the start is exact and a genuine drop at t > 0 is kept. Censor marks are short vertical segments in the arm colour, and the censoring time is the segment's x. The risk table was read from the PDF text layer at 0, 6, …, 36 months. All extracted observations are saved in `extraction_uniform.json`.

**Algorithm (own code, `code/reconstruct.py`):** a forward pass over the vertical segments of each path.
- **Event count and number at risk at each drop:** for d = 1..7, I solved S_after/S_before = 1 − d/n and kept candidates where n is an integer no larger than the previous remaining count. The chosen (d, n) minimizes non-integrality plus the mismatch between the implied censorings, n_prev_after − n, and the visible ticks in that interval. So d = 1 was not assumed. In practice every drop gave d = 1 with n within 0.05 of an integer.
- **Censoring between drops:** the implied number of censorings between successive drops equalled the number of visible ticks in every interval for both arms. That includes the near-coincident pair of A ticks at about 28.75 months (x = 341.01 and 341.04 pt), which the arithmetic shows are two separate censorings. Censorings are therefore placed at the tick times. The code includes fallback rules for extra or missing ticks (hidden censorings spread evenly, or duplicate ticks dropped), but neither was triggered.
- **After the last drop:** the remaining participants (A: 11, B: 9) matched the number of ticks after the last drop, and each is censored at its tick. The last tick coincides with the end of the curve (A 33.77 months, B 35.63 months). No follow-up beyond the plotted curve was invented.
- **Ties:** an event and a censoring at the same time are ordered event first. The code is deterministic, so the seed is recorded but not used.

**Result:** A has 78 events and 22 censorings; B has 63 events and 37 censorings.

**Checks (`checks.json`, from the reloaded CSV):**
- **KM curve:** the right-continuous KM matches the measured step curve at every drop time (max |ΔS| ≈ 3e-7) and at 0–33 months, including the tail and the curve end.
- **Risk table:** counts of observed_time ≥ t match every displayed count exactly, including 0 at 36 months, with no records at or beyond 36.
- **Tolerance:** 0.002 on S, justified by the 0.01-pt coordinate precision.
- **Correction cycle:** the first run of the checks flagged 4 points lying exactly on step boundaries. The cause was a precision mismatch: the check compared unrounded drop times with CSV times rounded to 1e-4 month. After the checker's measured drop times were set to the same storage precision, all points pass. No tolerance or counting convention was changed.

**Limitations:**
- The records reproduce the displayed estimator and risk table. They cannot recover anything the figure does not encode, such as the exact event times within the PDF's 0.01-pt resolution (about 0.001 month).
- A tick could hide several simultaneous censorings. The step arithmetic and the risk table rule this out here, because every count reconciles exactly, but it cannot be excluded for patients censored at exactly the same time as an event.

**Sensitivity analysis:** not run. No material alternative allocation arose, since every censoring count was pinned down by the drop sizes and matched the visible ticks.
