#!/usr/bin/env python3
"""KM -> IPD reconstruction from a vector PDF figure (own implementation).
Usage: python output/code/reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: INPUT_DIR=../input, OUTPUT_DIR=output (relative to cwd)."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 1300004219          # manifest code seed; algorithm is deterministic, seed recorded only
np.random.seed(SEED)
IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
man = json.load(open(os.path.join(IN, "manifest.json")))
pg = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]

# ---- axis calibration from labelled tick marks (black lines) ----
blk = [l for l in pg.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
words = pg.extract_words()
xt = sorted([(l["x0"]) for l in blk if abs(l["x0"]-l["x1"]) < 1e-6 and l["bottom"]-l["top"] < 4])
xlab = [float(w["text"]) for w in words if abs(w["top"]-229.7) < 1 and w["text"].isdigit()]
yt = sorted([l["top"] for l in blk if abs(l["top"]-l["bottom"]) < 1e-6 and l["x1"]-l["x0"] < 4])
ylab = [float(w["text"]) for w in words if abs(w["x0"]-43.5) < 1 and "." in w["text"]]
xlab = sorted(xlab); ylab = sorted(ylab, reverse=True)  # y labels top->bottom 1.0..0.0
assert len(xt) == len(xlab) and len(yt) == len(ylab)
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
calib = dict(x_ticks_pt=xt, x_labels=xlab, y_ticks_pt=yt, y_labels=ylab,
             x_resid=float(np.max(np.abs(np.polyval([ax, bx], xt)-xlab))),
             y_resid=float(np.max(np.abs(np.polyval([ay, by], yt)-ylab))))
T = lambda x: ax*x+bx; S = lambda y: ay*y+by

# ---- risk table (words on rows labelled Group A / Group B below 'Number at risk') ----
risk = {}
for g in ("A", "B"):
    lab = [w for w in words if w["text"] == g and w["top"] > 270][0]
    row = sorted([w for w in words if abs(w["top"]-lab["top"]) < 1 and w["x0"] > 50], key=lambda w: w["x0"])
    risk[g] = []
    for w in row:
        xc = (w["x0"]+w["x1"])/2
        tt = xlab[int(np.argmin([abs(xc-x) for x in xt]))]
        risk[g].append((tt, int(w["text"])))

# ---- legend colours ----
col = {}
for g in ("A", "B"):
    lw = [w for w in words if w["text"] == g and w["top"] < 30][0]
    seg = min([l for l in pg.lines if l["top"] < 30], key=lambda l: abs(lw["x0"]-l["x1"]))
    col[g] = tuple(seg["stroking_color"])

obs = {}
for g in ("A", "B"):
    cv = [c for c in pg.curves if tuple(c["stroking_color"]) == col[g]][0]
    pts = cv["pts"]
    drops = []
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x0-x1) < 1e-9 and y1 > y0+1e-9:
            drops.append((T(x0), S(y0), S(y1)))
    ticks = sorted(T(l["x0"]) for l in pg.lines if tuple(l["stroking_color"]) == col[g]
                   and abs(l["x0"]-l["x1"]) < 1e-9 and l["bottom"]-l["top"] > 3)
    obs[g] = dict(start=(T(pts[0][0]), S(pts[0][1])), end=(T(pts[-1][0]), S(pts[-1][1])),
                  drops=drops, ticks=ticks, steps=[(T(x), S(y)) for x, y in pts])

def reconstruct(g, hidden="uniform"):
    """Forward pass. At each drop infer (d, n_risk) from S_a/S_b = 1-d/n; censorings between
    drops = n_prev_after - n_risk; place at tick times in that interval, adding/removing as needed."""
    N = man["groups"][g]; o = obs[g]; drops = o["drops"]; ticks = np.array(o["ticks"])
    rt = dict(risk[g]); recs = []; log = []
    n_after = N; t_prev = 0.0
    for j, (t, sb, sa) in enumerate(drops):
        cands = []
        for d in range(1, 8):
            n = d*sb/(sb-sa)
            ni = int(round(n))
            if ni > n_after or ni < d: continue
            c = n_after-ni
            tk = ((ticks > t_prev) | ((ticks == t_prev) & (j > 0))) & (ticks < t) if j else (ticks >= 0) & (ticks < t)
            ntk = int(tk.sum())
            # risk-table consistency for any table time in (t_prev, t]
            rpen = 0
            for tt, rv in rt.items():
                if t_prev < tt <= t: rpen += abs(ni - rv) if not any(t_prev < tt2 < tt for tt2 in [x for x in ticks[tk]]) else 0
            cands.append((abs(n-ni)/max(n, 1)*50 + abs(c-ntk) + 0.0*rpen, d, ni, n, c, ntk))
        best = min(cands)
        _, d, ni, n, c, ntk = best
        tk_mask = ((ticks > t_prev) if j else (ticks >= 0)) & (ticks < t)
        tks = list(ticks[tk_mask])
        cens = place(tks, c, t_prev, t, rt, g, hidden, n_after)
        recs += [(g, x, 0) for x in cens] + [(g, t, 1)]*d
        log.append(dict(t=t, S_before=sb, S_after=sa, d=d, n_risk=ni, n_exact=n, censored_before=c, ticks_in_interval=ntk))
        n_after = ni-d; t_prev = t
    # tail: remaining n_after all censored; ticks at/after last drop
    tks = list(ticks[ticks >= t_prev]) if drops else list(ticks)
    tend = o["end"][0]
    cens = place(tks, n_after, t_prev, tend, rt, g, hidden, n_after, tail=True)
    recs += [(g, x, 0) for x in cens]
    log.append(dict(t="tail", remaining=n_after, ticks_in_interval=len(tks), curve_end=tend))
    return recs, log

def place(tks, c, lo, hi, rt, g, hidden, n_start, tail=False):
    tks = sorted(tks)
    if len(tks) == c: return tks
    if len(tks) > c:  # drop ticks that are nearest-duplicates first (likely overplotted repeats... or hidden)
        tks = list(tks)
        while len(tks) > c:
            gaps = np.diff(tks) if len(tks) > 1 else np.array([np.inf])
            k = int(np.argmin(gaps)); tks.pop(k+1)
        return tks
    extra = c-len(tks)
    if tail:  # unmarked remainder: censor at last supported time (curve end), not beyond
        add = [hi]*extra
    elif hidden == "uniform":
        add = list(lo+(hi-lo)*(np.arange(1, extra+1)/(extra+1)))
    else:  # "at_ticks": duplicate existing tick marks (overplotted multiplicity), else uniform
        add = [tks[i % len(tks)] for i in range(extra)] if tks else list(lo+(hi-lo)*(np.arange(1, extra+1)/(extra+1)))
    return sorted(tks+add)

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1-d/n; out.append((u, s))
    return out
def S_at(curve, x):
    s = 1.0
    for u, v in curve:
        if u <= x: s = v
        else: break
    return s
def rmst(curve, tau):
    a = 0; tp = 0; s = 1.0
    for u, v in curve:
        if u > tau: break
        a += s*(u-tp); tp = u; s = v
    return a+s*(tau-tp)

def write_atomic(df, path):
    tmp = path+".tmp"; df.to_csv(tmp, index=False); os.replace(tmp, path)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    mode = os.environ.get("HIDDEN", "uniform")
    allrec, logs = [], {}
    for g in ("A", "B"):
        r, lg = reconstruct(g, mode); logs[g] = lg
        assert len(r) == man["groups"][g], (g, len(r))
        allrec += r
    df = pd.DataFrame(allrec, columns=["group", "observed_time", "event"])
    df["observed_time"] = df.observed_time.round(4)
    json.dump(dict(calibration=calib, risk_table=risk, colours={k: list(v) for k, v in col.items()},
                   observations={g: dict(start=o["start"], end=o["end"], drops=o["drops"], ticks=o["ticks"])
                                 for g, o in obs.items()}, step_log=logs),
              open(os.path.join(OUT, f"extraction_{mode}.json"), "w"), indent=1, default=float)
    target = os.path.join(OUT, "ipd.csv" if mode == "uniform" else "sensitivity.csv")
    write_atomic(df, target)
    print("wrote", target, df.groupby("group").event.agg(["size", "sum"]).to_dict())
    for g in ("A", "B"):
        for L in logs[g]:
            if L.get("t") == "tail" or L["censored_before"] != L["ticks_in_interval"] or abs(L["n_exact"]-L["n_risk"]) > 0.05 or L["d"] > 1:
                print(g, L)
