#!/usr/bin/env python3
"""Reload committed output/ipd.csv, recompute right-continuous KM, compare to vector-measured curve & risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
sys.argv = sys.argv[:1] + sys.argv[1:3]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reconstruct as R
OUT = R.OUT; man = R.man
path = os.path.join(OUT, "ipd.csv"); df = pd.read_csv(path)
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
chk = dict(csv=path, sha256=sha, calibration=R.calib, tolerance_note=(
    "Curve is a vector path; S read to ~3e-5 (0.01 pt / 180 pt). Tolerance 0.002 on S allows for coordinate "
    "rounding; risk counts must match exactly."), arms={})
def meas(g, x):  # measured right-continuous step value from the PDF path
    s = 1.0
    for t, sb, sa in R.obs[g]["drops"]:
        if round(t, 4) <= x: s = sa  # drop times at CSV storage precision (1e-4 month)
    return s
allpass = True
for g in ("A", "B"):
    d = df[df.group == g]; cur = R.km(d)
    a = dict(n=int(len(d)), n_expected=man["groups"][g], n_pass=bool(len(d) == man["groups"][g]),
             event_integer=bool(set(d.event.unique()) <= {0, 1}), events=int(d.event.sum()),
             times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
             supplied_event_total="unavailable (not in manifest)")
    end = R.obs[g]["end"][0]
    times = [0, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, round(end, 3)]
    drops = [t for t, _, _ in R.obs[g]["drops"]]
    times += [round(drops[0], 4), round(drops[-1], 4), round(drops[-1]-1e-3, 4)]
    sv = []
    for t in sorted(set(times)):
        m = meas(g, t); r = R.S_at(cur, t); ok = abs(m-r) <= 0.002; allpass &= ok
        sv.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), resid=round(r-m, 5), status="pass" if ok else "fail"))
    a["survival"] = sv
    # full-step comparison: max abs diff over every drop time
    md = max(abs(meas(g, t)-R.S_at(cur, t)) for t in drops)
    a["max_abs_diff_all_drop_times"] = md
    rk = []
    for t, v in R.risk[g]:
        n = int((d.observed_time >= t).sum()); ok = n == v; allpass &= ok
        rk.append(dict(t=t, displayed=v, reconstructed=n, resid=n-v, status="pass" if ok else "fail"))
    a["risk_table"] = rk
    a["tail"] = dict(curve_end=end, max_record_time=float(d.observed_time.max()),
                     records_beyond_curve_end=int((d.observed_time > end+1e-3).sum()),
                     status="pass" if (d.observed_time <= end+1e-3).all() else "fail")
    tau = 33.0
    a["rmst_to_33"] = dict(reconstructed=R.rmst(cur, tau))
    chk["arms"][g] = a
chk["overall"] = "pass" if allpass else "fail"
chk["common_horizon_months"] = 33.0
if os.path.exists(os.path.join(OUT, "sensitivity.csv")):
    chk["sensitivity"] = "see sensitivity.csv"
else:
    chk["sensitivity"] = "not run: every between-drop interval had implied censor count equal to visible tick count, so no hidden allocation choice arose"
tmp = os.path.join(OUT, "checks.json.tmp"); json.dump(chk, open(tmp, "w"), indent=1, default=float); os.replace(tmp, os.path.join(OUT, "checks.json"))
print(chk["overall"], sha)
for g in ("A","B"):
    a = chk["arms"][g]; print(g, a["n"], a["events"], a["max_abs_diff_all_drop_times"], [ (r["t"],r["displayed"],r["reconstructed"]) for r in a["risk_table"]], a["tail"], a["rmst_to_33"])
    print([ (s["t"], s["measured"], s["reconstructed"], s["status"]) for s in a["survival"]])
