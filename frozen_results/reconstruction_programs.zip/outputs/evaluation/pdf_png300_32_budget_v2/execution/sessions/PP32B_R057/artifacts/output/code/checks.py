"""Reload committed ipd.csv, recompute right-continuous KM, compare with extracted vector curve and risk table."""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
ex = json.load(open(f'{out}/extracted.json'))
df = pd.read_csv(f'{out}/ipd.csv')
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
def km(d, t):
    s = 1.0
    for u in np.unique(d.observed_time[(d.event == 1) & (d.observed_time <= t)]):
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum(); s *= 1 - e / n
    return s
def path_s(p, t):  # right-continuous reading of the vector step path
    s = 1.0
    for x, y in p:
        if x <= t + 1e-9: s = y
        else: break
    return s
TOL = 0.002  # vector coordinates rounded in 4th decimal of pt; and 4-decimal rounding of times in CSV
res = {'ipd_sha256': sha, 'tolerance_km': TOL, 'tolerance_note': 'vector path read exactly; tol covers CSV time rounding (1e-4 mo) and PDF coordinate rounding',
       'arm_sizes': {}, 'event_indicator_integer_01': bool(df.event.isin([0, 1]).all()),
       'supplied_event_totals': 'unavailable (manifest has none)', 'km': {}, 'risk_table': {}}
rt = ex['risk_times']
for g in 'AB':
    d = df[df.group == g]; p = ex['arms'][g]['path']
    res['arm_sizes'][g] = {'expected': 100, 'observed': int(len(d)), 'status': 'pass' if len(d) == 100 else 'fail'}
    # times: fixed grid incl. tail, plus just before/after several drops
    drops = [p[i][0] for i in range(1, len(p)) if abs(p[i][0]-p[i-1][0]) < 1e-9 and p[i][1] < p[i-1][1]]
    ts = sorted(set([0, 1, 3, 6, 9, 12, 18, 24, 27, 30, 33, round(p[-1][0], 3)] +
                    [round(drops[k] + 0.001, 4) for k in (0, len(drops)//2, -1)] + [round(drops[-1] - 0.001, 4)]))
    rows = []
    for t in ts:
        m, r = path_s(p, t), km(d, t)
        rows.append({'t': t, 'measured': round(m, 5), 'reconstructed': round(r, 5), 'residual': round(r - m, 5),
                     'status': 'pass' if abs(r - m) <= TOL else 'fail'})
    res['km'][g] = rows
    rr = []
    for t, n in zip(rt, ex['risk'][g]):
        c = int((d.observed_time >= t).sum())
        rr.append({'t': t, 'displayed': n, 'reconstructed': c, 'residual': c - n, 'status': 'pass' if c == n else 'fail'})
    res['risk_table'][g] = rr
    res.setdefault('follow_up_max', {})[g] = {'max_time': float(d.observed_time.max()), 'curve_end': p[-1][0]}
res['all_pass'] = all(r['status'] == 'pass' for g in 'AB' for r in res['km'][g] + res['risk_table'][g]) and all(v['status'] == 'pass' for v in res['arm_sizes'].values())
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
for g in 'AB':
    print(g, [(r['t'], r['residual'], r['status']) for r in res['km'][g]])
    print(g, [(r['t'], r['displayed'], r['reconstructed']) for r in res['risk_table'][g]])
print('all_pass', res['all_pass'], sha)
