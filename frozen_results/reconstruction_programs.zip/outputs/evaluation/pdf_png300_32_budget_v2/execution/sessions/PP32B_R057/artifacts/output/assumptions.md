# Reconstruction assumptions

**Inputs used:** `../input/figure.pdf` (a vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 499789102). No other information was used. The manifest gives no arm-specific event totals, so that check is marked unavailable.

**Measurement.** I read the figure's PDF objects directly with pdfplumber, not its pixels (`code/extract.py`).
- **Axis calibration** comes from the labelled tick marks. On the x-axis, 0 to 36 months spans x = 64.8 to 410.4 pt. On the y-axis, survival 0 to 1 spans y = 223.2 to 43.2 pt. I applied no other transform.
- **Arms** were identified by stroke colour, matched to the legend line next to each label: blue is Group A and orange is Group B.
- **Curves:** each arm is a single step path, and both start exactly at S = 1.
- **Censor marks** are 4-pt vertical segments in the arm's colour. Their x position is taken as the censoring time. There are 16 in A and 46 in B.
- **Risk table:** read from the PDF text. A: 100, 68, 47, 35, 21, 7, 0. B: 100, 73, 63, 55, 43, 15, 0, at 0, 6, …, 36 months.
- The extracted paths and ticks are saved in `extracted.json`.

**Algorithm** (`code/reconstruct.py`, deterministic; the seed is recorded but no randomness is used):
- For each vertical drop, the ratio r = S_after/S_before gives the risk set n = d/(1 − r).
- For d = 1..5, I take the smallest d that gives an integer n (within 0.02) not exceeding the number still under observation.
- Censorings in the gap before a drop are (previous n − previous d) − n. They are placed at that gap's tick positions. The code would add multiplicity at ticks, or at the gap midpoint, if the implied count exceeded the visible ticks, but this never happened.
- Everyone still at risk after the last drop is censored at the tail ticks.

**Result:**
- **Every drop is d = 1**, with an integer n (deviation < 0.004). The d = 2 alternatives would need risk sets of about 2n, which is impossible given n ≤ 100 and the declining counts. So d = 1 rests on the risk-set bound, not just on the reciprocal pattern.
- **Censor counts match the ticks:** in every gap and in both tails, the implied count equals the number of visible ticks. None were hidden or overlapping.
- **Totals:** A has 84 events and 16 censored; B has 54 events and 46 censored.
- **Risk table:** the reconstructed counts (records with time ≥ t) match every displayed count, including 0 at 36 months. The last records are at 35.41 months (A) and 35.75 months (B).
- **Ties:** no tick coincides with a drop, so no tie convention was needed. The code orders events before censorings at equal times.

**Checks** (`code/checks.py` → `checks.json`): I reloaded the committed CSV and recomputed the right-continuous KM estimate. It matches the vector path to within 1e-5 at 16 times per arm, including just before and after the first, middle and last drops and the tail end. The tolerance of 0.002 allows for coordinate and CSV rounding. Arm sizes and 0/1 event indicators pass.

**Limitations:**
- Times are recovered only to the precision of the PDF coordinates, about 1e-4 months. CSV times are rounded to 4 decimals.
- The censoring times assume each tick is drawn at the censoring time itself.
- The reconstruction reproduces the plotted curve, not any underlying unplotted data.
- **No sensitivity analysis was run:** the drop ratios, tick counts and risk table together leave no materially different feasible allocation.

**Rerun** (from the work directory): `python output/code/extract.py ../input/figure.pdf output && python output/code/reconstruct.py output && python output/code/checks.py output`
