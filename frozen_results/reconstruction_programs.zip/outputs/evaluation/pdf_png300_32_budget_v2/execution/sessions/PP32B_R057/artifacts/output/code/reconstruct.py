"""Reconstruct IPD from extracted vector KM paths + censor ticks.
Usage: python reconstruct.py [output_dir]   (run extract.py first; deterministic, seed recorded only)
For each vertical drop, the risk set is inferred from the exact KM ratio: n = d/(1 - S_after/S_before),
choosing the smallest d in 1..5 giving an integer n (tol 0.02) that does not exceed the number still
under observation. Censorings in each gap = (n_prev - d_prev) - n_next, placed at the visible ticks of that gap
(extra ones, if any, are added as multiplicity on the gap's ticks, or at the gap midpoint if it has no tick)."""
import sys, os, json, hashlib, numpy as np, pandas as pd
SEED = 499789102; np.random.seed(SEED)  # no stochastic step is used
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
ex = json.load(open(f'{out}/extracted.json'))
N = {'A': 100, 'B': 100}  # manifest group sizes
log = {}
recs = []
for g in 'AB':
    p = ex['arms'][g]['path']; ticks = sorted(t for t, s in ex['arms'][g]['ticks'])
    drops = [(p[i][0], p[i-1][1], p[i][1]) for i in range(1, len(p))
             if abs(p[i][0]-p[i-1][0]) < 1e-9 and p[i][1] < p[i-1][1]-1e-9]
    avail, prev_t, notes, rows = N[g], -1.0, [], []
    for t, b, a in drops:
        r = a / b
        gap_ticks = [x for x in ticks if prev_t < x < t]  # ticks exactly at an event time: none found
        ch = None
        for d in range(1, 6):
            n = d / (1 - r)
            if abs(n - round(n)) < 0.02 and round(n) <= avail:
                ch = (d, int(round(n))); break
        assert ch, (g, t)
        d, n = ch; c = avail - n
        if c != len(gap_ticks):
            notes.append(f'gap before t={t:.3f}: implied censors {c} vs visible ticks {len(gap_ticks)}')
        ct = gap_ticks[:c] if c <= len(gap_ticks) else gap_ticks + [gap_ticks[i % len(gap_ticks)] if gap_ticks else (prev_t+t)/2 for i in range(c-len(gap_ticks))]
        rows += [(x, 0) for x in ct] + [(t, 1)] * d
        avail = n - d; prev_t = t
    tail = [x for x in ticks if x > prev_t]
    if avail != len(tail): notes.append(f'tail: remaining {avail} vs ticks {len(tail)}')
    last = p[-1][0]
    ct = tail[:avail] if avail <= len(tail) else tail + [last] * (avail - len(tail))
    rows += [(x, 0) for x in ct]
    assert len(rows) == N[g]
    recs += [(g, x, e) for x, e in rows]
    log[g] = {'events': sum(e for _, e in rows), 'censored': sum(1 - e for _, e in rows), 'n_drops': len(drops),
              'n_ticks': len(ticks), 'notes': notes}
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
df['observed_time'] = df['observed_time'].round(4)
tmp = f'{out}/ipd.csv.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(log, open(f'{out}/reconstruction_log.json', 'w'), indent=1)
print(json.dumps(log, indent=1))
