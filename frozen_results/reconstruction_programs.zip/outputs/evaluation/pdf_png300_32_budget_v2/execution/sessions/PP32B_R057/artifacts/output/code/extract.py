"""Extract KM step curves and censor ticks from the vector PDF (no pixels needed).
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
# axis calibration from labelled tick marks: x ticks 0..36 at 64.8..410.4; y ticks 0..1 at 223.2..43.2 (top-down coords)
X0, X1, T1 = 64.8, 410.4, 36.0
Y0, Y1 = 223.2, 43.2
tx = lambda x: (x - X0) / (X1 - X0) * T1
sy = lambda y: (Y0 - y) / (Y0 - Y1)
col = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}  # from legend lines next to "Group A"/"Group B"
res = {}
for g, c in col.items():
    cur = [cv for cv in pg.curves if tuple(round(v, 6) for v in cv['stroking_color']) == c]
    assert len(cur) == 1
    pts = [(tx(x), sy(y)) for x, y in cur[0]['pts']]
    ticks = sorted(tx(l['x0']) for l in pg.lines if tuple(round(v, 6) for v in l['stroking_color']) == c
                   and abs(l['x0'] - l['x1']) < 1e-6 and abs(l['bottom'] - l['top'] - 4) < 1e-3)
    tick_s = sorted((tx(l['x0']), sy((l['top'] + l['bottom']) / 2)) for l in pg.lines
                    if tuple(round(v, 6) for v in l['stroking_color']) == c and abs(l['bottom'] - l['top'] - 4) < 1e-3)
    res[g] = {'path': pts, 'ticks': tick_s}
json.dump({'calibration': dict(X0=X0, X1=X1, T1=T1, Y0=Y0, Y1=Y1), 'risk_times': [0, 6, 12, 18, 24, 30, 36],
           'risk': {'A': [100, 68, 47, 35, 21, 7, 0], 'B': [100, 73, 63, 55, 43, 15, 0]}, 'arms': res},
          open(f'{out}/extracted.json', 'w'), indent=1)
