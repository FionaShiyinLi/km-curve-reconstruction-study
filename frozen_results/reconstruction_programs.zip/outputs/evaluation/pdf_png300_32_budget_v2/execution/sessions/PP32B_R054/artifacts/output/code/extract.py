"""Pixel extraction of the KM figure. Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../../../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else '..'
im = np.asarray(Image.open(fig).convert('RGB')).astype(float)
H, W, _ = im.shape
dark = im.sum(2) < 200
# axis lines: longest dark column / row
col = dark.sum(0); row = dark.sum(1)
xaxis_col = int(np.argmax(col)); yaxis_row = int(np.argmax(row))
# x ticks: dark pixels just below the x-axis row
def clusters(v):
    idx = np.where(v)[0]; cl = []; 
    for i in idx:
        if cl and i - cl[-1][-1] <= 1: cl[-1].append(i)
        else: cl.append([i])
    return [float(np.mean(c)) for c in cl]
axrow = np.where(row > 0.5 * row.max())[0]; axcol = np.where(col > 0.5 * col.max())[0]
xt = [v for v in clusters(dark[axrow.max() + 4, :]) if v >= axcol.min() - 2]
yt = [v for v in clusters(dark[:, axcol.min() - 4]) if v <= axrow.max() + 2]
xt_vals = np.arange(0, 37, 6); yt_vals = np.round(np.arange(0, 1.01, 0.2), 1)[::-1]
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
ax_ = np.polyfit(xt_vals, xt, 1); ay_ = np.polyfit(yt_vals, yt, 1)
cal = dict(x_ticks_px=xt, y_ticks_px=yt, px_per_month=ax_[0], x0_px=ax_[1],
           px_per_unit_S=ay_[0], y0_px=ay_[1],
           x_resid=list(np.polyval(ax_, xt_vals) - xt), y_resid=list(np.polyval(ay_, yt_vals) - yt))
t_of = lambda x: (x - ax_[1]) / ax_[0]; s_of = lambda y: (y - ay_[1]) / ay_[0]
colors = {'A': (31, 119, 180), 'B': (255, 127, 14)}
res = {'calibration': cal}
x_lo = int(round(ax_[1])) ; x_hi = int(round(np.polyval(ax_, 36)))
y_top = int(round(np.polyval(ay_, 1.0))) - 15; y_bot = int(round(ay_[1])) - 1
for g, c in colors.items():
    d = np.sqrt(((im - np.array(c)) ** 2).sum(2))
    m = d < 90
    m[:y_top] = False; m[y_bot:] = False; m[:, :x_lo] = False; m[:, x_hi + 3:] = False
    cols = []
    for x in range(x_lo, x_hi + 3):
        ys = np.where(m[:, x])[0]
        if len(ys): cols.append([x, [int(v) for v in ys]])
    res[g] = cols
json.dump(res, open(f'{out}/pixels_raw.json', 'w'))
print(json.dumps(cal, indent=1))
