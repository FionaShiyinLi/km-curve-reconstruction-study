"""Overlay reconstructed KM (from committed ipd.csv) on the figure. Usage: python overlay.py [figure] [outdir]"""
import sys, json, pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../../../input/figure.png'; out = sys.argv[2] if len(sys.argv) > 2 else '..'
cal = json.load(open(f'{out}/pixels_raw.json'))['calibration']; im = np.asarray(Image.open(fig))
d = pd.read_csv(f'{out}/ipd.csv'); plt.figure(figsize=(12, 9)); plt.imshow(im)
for g, c in zip('AB', ['k', 'm']):
    x = d[d.group == g]; t = x.observed_time.values; e = x.event.values; S = 1; ts = [0]; ss = [1]
    for u in np.unique(t[e == 1]):
        S *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); ts.append(u); ss.append(S)
    ts.append(t.max()); ss.append(S)
    plt.step(cal['x0_px'] + cal['px_per_month'] * np.array(ts), cal['y0_px'] + cal['px_per_unit_S'] * np.array(ss), where='post', color=c, lw=0.7)
    cz = t[e == 0]; Sc = [ss[max(i for i in range(len(ts) - 1) if ts[i] <= u)] for u in cz]
    plt.plot(cal['x0_px'] + cal['px_per_month'] * cz, cal['y0_px'] + cal['px_per_unit_S'] * np.array(Sc) - 14, 'v', color=c, ms=2)
plt.xlim(250, 1730); plt.ylim(950, 160); plt.axis('off'); plt.savefig(f'{out}/overlay.png', dpi=150, bbox_inches='tight')
