"""Trace step levels, drops and censor ticks from pixels_raw.json. Usage: python trace.py [outdir]"""
import sys, json, numpy as np
out = sys.argv[1] if len(sys.argv) > 1 else '..'
r = json.load(open(f'{out}/pixels_raw.json')); cal = r['calibration']
t_of = lambda x: (x - cal['x0_px']) / cal['px_per_month']
s_of = lambda y: (y - cal['y0_px']) / cal['px_per_unit_S']
K = 2  # horizontal half-width for "core" (horizontal-line) pixels
res = {}
for g in 'AB':
    cols = {x: set(ys) for x, ys in r[g]}
    xs = sorted(cols)
    core = {}
    for x in xs:
        c = cols[x] & cols.get(x - K, set()) & cols.get(x + K, set())
        if c:
            c = sorted(c); blocks = [[c[0]]]
            for y in c[1:]:
                if y - blocks[-1][-1] <= 1: blocks[-1].append(y)
                else: blocks.append([y])
            b = max(blocks, key=len)
            core[x] = (np.mean(b), len(b))
    segs = []
    for x in sorted(core):
        y, n = core[x]
        if segs and abs(y - segs[-1]['y']) <= 1.0 and x - segs[-1]['x1'] <= 12:
            s = segs[-1]; s['x1'] = x; s['ys'].append(y); s['y'] = float(np.median(s['ys']))
        else:
            segs.append(dict(x0=x, x1=x, y=y, ys=[y]))
    clean = []
    for s in segs:
        if clean and s['y'] < clean[-1]['y'] - 1.0:
            if s['x1'] - s['x0'] < clean[-1]['x1'] - clean[-1]['x0']:
                continue
        clean.append(s)
    for s in clean: s.pop('ys')
    tickcols = []
    for x in xs:
        lev = [s for s in clean if s['x0'] - 3 <= x <= s['x1'] + 3]
        if not lev: continue
        yc = min(s['y'] for s in lev)
        if min(cols[x]) <= yc - 5: tickcols.append(x)
    ticks = []
    for x in tickcols:
        if ticks and x - ticks[-1][-1] <= 1: ticks[-1].append(x)
        else: ticks.append([x])
    res[g] = dict(segments=[dict(t0=t_of(s['x0']), t1=t_of(s['x1']), S=s_of(s['y']), x0=s['x0'], x1=s['x1'], y=s['y']) for s in clean],
                  ticks=[dict(t=t_of(np.mean(c)), width_px=len(c), x=float(np.mean(c))) for c in ticks])
json.dump(res, open(f'{out}/trace.json', 'w'), indent=1)
for g in 'AB':
    print(g, 'segments', len(res[g]['segments']), 'ticks', len(res[g]['ticks']))
    for s in res[g]['segments']: print('  seg %6.3f-%6.3f S=%.4f (y=%.1f)' % (s['t0'], s['t1'], s['S'], s['y']))
    print('  ticks', [(round(k['t'], 2), k['width_px']) for k in res[g]['ticks']])
