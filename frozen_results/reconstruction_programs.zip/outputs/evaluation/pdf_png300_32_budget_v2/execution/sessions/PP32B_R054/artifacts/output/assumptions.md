# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json`: n = 100 per arm, time in months, seed 1109432055.
- The number-at-risk table was read visually from the figure. Times are 0, 6, ..., 36. Group A: 100, 74, 47, 30, 21, 7, 0. Group B: 100, 68, 55, 42, 32, 14, 0. The digits are clean text, so I treat these readings as certain.
- The manifest supplies no arm-specific event totals, so that check is marked unavailable. Without totals, event counts rest on the curve and risk table alone. No reported hazard ratio (HR), restricted mean survival time (RMST) or standard error was used.

## Pipeline (`output/code/`, run in order from `output/code/`; paths are arguments with relative defaults)
1. `extract.py [figure] [outdir]`: calibrates both axes from the labelled tick marks (x ticks 0 to 36 found at pixels 269.5 to 1709.5, i.e. 40 px/month; y ticks 0 to 1.0 give 750 px per unit). Linear fit residuals are 0 px. No global rescaling was applied; the curves start at S = 1 at the calibrated y = 1 anchor. It then classifies each arm's pixels by RGB distance (< 90) to the arm colours (blue #1f77b4 = A, orange #ff7f0e = B) and writes `pixels_raw.json`.
2. `trace.py [outdir]`: for each column, finds horizontal-line pixels, meaning pixels also coloured 2 px to the left and right. This excludes narrow censor ticks and vertical drop lines. These pixels are grouped into constant-level segments (`trace.json`). Tick candidates are columns with colour at least 5 px above the local level; clusters of adjacent columns give each tick's time and width.
3. `reconstruct.py [outdir]`: builds the records, writes `ipd.csv` atomically (temporary file, then rename), reloads it, writes `checks.json`, then runs one sensitivity allocation (`sensitivity.csv`).
4. `overlay.py`: draws the KM curve from the committed CSV over the figure (`overlay.png`).

## Algorithm
- **Event times and sizes.** An event time is the midpoint of the gap between consecutive segments; one-column corner fragments are discarded. Each drop's event count is d = round(n_risk x (1 - S_after,measured / S_before,reconstructed)). This uses the reconstructed KM level before the drop, so rounding does not accumulate. Because d is estimated from the ratio and the number at risk, multi-event drops are allowed; for example, A has d = 2 at 0.056 months. d = 1 is never assumed.
- **Starting point.** Near t = 0, A is partly hidden under B. A's first visible level is 0.98, with a vertical line starting at S = 1. That supports two events very close to 0.06 months (1 → 0.98) rather than a flat start.
- **Censoring within intervals.** Within each risk interval [t_k, t_k+1), the number censored is c_k = n_k - n_k+1 - D_k, iterated with D_k to a fixed point.
  - Detected ticks are used as censoring times. A tick drawn 2-3 px wide counts as one censoring; 4-7 px counts as two overlapping ticks. This multiplicity rule is an assumption, and a tick's visibility does not establish its multiplicity. The B tail supports the rule: its drop ratios (1/14, 1/12, 1/6, 1/5) reconcile with the risk table only if the 4-px mark at 33.8 months holds two censorings.
  - Tick candidates were rejected at the axis start line (A 0.06, B 0.02) and at A 6.39 months, which is a pixel artefact where A's drop crosses B's line.
  - If the risk table requires more censorings than the visible ticks, the extra (unmarked) censorings are spread uniformly across the interval (assumption). This occurred for 1-2 records per interval in A [24,30), A [30,36), B [0,6), B [6,12) and B [24,30).
  - A probable tick hidden in the A drop at about 24.5 months is one likely source of the extras.
- **Ties and tail.** At tied times, events come before censorings. No record goes beyond the last visible mark: A ends at 34.475 months and B at 35.35. No one is placed at the risk-table time where zero are at risk (t = 36). The flat tails are not used to infer a censoring distribution or an accrual period.
- **Randomness.** The seed 1109432055 is set, but the algorithm is deterministic.

## Verification (`checks.json`; final CSV SHA-256 recorded there)
- Arm sizes are 100 and 100. Event indicators are integer 0/1. There are 78 events in A and 66 in B; these are reconstructed values, not supplied totals.
- **Risk table.** For every table time t, the number of records with observed_time >= t equals the displayed count for both arms (14/14 exact).
- **Survival.** The right-continuous KM step function from the reloaded CSV was compared with the measured segment levels at 23 times from 0.5 to 34 months, including the tails. All comparable times pass. The maximum absolute residual is 0.0022 (A) and 0.0014 (B). The tolerance of 0.01 was set in advance: it is one event at n = 100, and about 7 px against a pixel error of about 0.0013 per px. Times inside drop gaps are marked unavailable.
- **Correction cycles.** There were two primary correction cycles after the first complete file, both fixes to tick rules:
  1. Cycle 1 fixed the crossing-artefact rule, which had wrongly dropped the A 34.47 tail tick, and changed 4-px ticks to count as two. Before that fix, B at 34 months was reconstructed as 0.172 against a measured 0.191.
  2. Cycle 2 fixed the handling of corner fragments so the A 6.39 artefact is rejected and the genuine 7.4 tick is kept.

## Sensitivity (one alternative only)
The alternative stacks the unmarked extra censorings on detected tick times within the same interval, instead of spreading them uniformly. The common supported horizon is 34.475 months (the shorter arm's last observation).

| Arm | Survival at horizon, primary vs alternative | RMST, primary vs alternative |
|---|---|---|
| A | 0.1822 vs 0.1822 | 14.949 vs 14.949 months |
| B | 0.1910 vs 0.1909 | 17.721 vs 17.714 months |

One alternative is not a bound on reconstruction error.

## Unresolved limitations
- Tick multiplicity, and the timing of unmarked censorings, cannot be identified from the figure.
- Where the arms overlap (0-1 month and 5-6.5 months), some A drops are partly hidden. Their timing may be off by up to about 0.1 month, although the levels on either side agree with the figure.
- Event times are resolved only to about 0.025 months (one pixel). Very close events may be merged into one tied drop.
- Supporting observations are saved in `pixels_raw.json`, `trace.json`, `zoom_check.png`, `overlay.png` and `run_log.txt`.
- Environment: Python 3.12.14, numpy 2.5.3, pandas 3.0.6, Pillow 12.3.0.
