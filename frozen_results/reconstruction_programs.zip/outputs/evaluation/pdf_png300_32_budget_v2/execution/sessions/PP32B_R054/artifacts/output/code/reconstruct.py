"""Reconstruct IPD from trace.json + risk table read from the figure.
Usage: python reconstruct.py [outdir]   (run extract.py and trace.py first)"""
import sys, os, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else '..'
SEED = 1109432055; np.random.seed(SEED)  # recorded; the algorithm is deterministic
tr = json.load(open(f'{out}/trace.json')); cal = json.load(open(f'{out}/pixels_raw.json'))['calibration']
T = [0, 6, 12, 18, 24, 30, 36]  # risk table read visually from the figure
RISK = {'A': [100, 74, 47, 30, 21, 7, 0], 'B': [100, 68, 55, 42, 32, 14, 0]}
N = {'A': 100, 'B': 100}

def prep(g):
    segs = [s for s in tr[g]['segments'] if s['x1'] > s['x0']]  # drop 1-column corner artefacts
    segs = [dict(t0=0.0, t1=0.0, S=1.0, y=cal['y0_px'] + cal['px_per_unit_S'])] + segs
    other = [s for s in tr['B' if g == 'A' else 'A']['segments']]
    drops = []
    for a, b in zip(segs[:-1], segs[1:]):
        if b['S'] < a['S'] - 1e-9:
            drops.append(dict(t=(a['t1'] + b['t0']) / 2, Sb=a['S'], Sa=b['S']))
    ticks, rejected = [], []
    allseg = tr[g]['segments']
    for k in tr[g]['ticks']:
        t = k['t']
        inside = any(s['t0'] <= t <= s['t1'] for s in allseg if s['x1'] - s['x0'] >= 2)  # ignore corner fragments
        yb = [s['y'] for s in allseg if s['t1'] < t and s['x1'] - s['x0'] >= 2]; ya = [s['y'] for s in allseg if s['t0'] > t and s['x1'] - s['x0'] >= 2]
        yo = [o['y'] for o in other if o['t0'] - 0.1 <= t <= o['t1'] + 0.1]
        # tick candidate inside a drop of this arm through which the other arm's line passes = crossing artefact
        crossing = (not inside) and yb and ya and any(yb[-1] - 2 <= y <= ya[0] + 2 for y in yo)
        if k['width_px'] <= 1 or t < 0.15 or crossing:
            rejected.append(dict(k, reason='start line' if t < 0.15 else ('1px' if k['width_px'] <= 1 else 'crossing other arm'))); continue
        # single tick renders 2-3 px wide; >=4 px taken as two overlapping ticks, >=8 px as three
        ticks.append(dict(t=t, mult=1 if k['width_px'] <= 3 else (2 if k['width_px'] < 8 else 3), width=k['width_px']))
    return segs, drops, ticks, rejected

def simulate(n0, S0, drops, cens):
    ev = sorted([(d['t'], 0, d) for d in drops] + [(c, 1, None) for c in cens], key=lambda z: (z[0], z[1]))
    n, S, rec = n0, S0, []
    for t, kind, d in ev:
        if kind == 0:
            k = int(round(n * (1 - d['Sa'] / S))) if S > 0 else 0
            k = min(max(k, 0), n)
            if k: S *= 1 - k / n; n -= k; rec += [(t, 1)] * k
        else:
            if n > 0: n -= 1; rec.append((t, 0))
    return n, S, rec

def reconstruct(g, mode='uniform'):
    segs, drops, ticks, rej = prep(g)
    tmax = max(segs[-1]['t1'], max([k['t'] for k in ticks], default=0))
    recs, S, log = [], 1.0, []
    for i in range(len(T) - 1):
        a, b = T[i], T[i + 1]; n0 = RISK[g][i] if i == 0 else n_cur; target = RISK[g][i + 1]
        dr = [d for d in drops if a <= d['t'] < b]
        tk = [k for k in ticks if a <= k['t'] < b]
        base = [k['t'] for k in tk for _ in range(k['mult'])]
        hi = min(b, tmax); c = len(base)
        for _ in range(50):
            if c <= len(base):
                keep = sorted(tk, key=lambda k: -k['width'])  # trim lowest-confidence ticks if too many
                cens = sorted(base)[:c] if c == len(base) else sorted([k['t'] for k in keep][:c])
            else:
                extra = c - len(base)
                if mode == 'uniform' or not tk:
                    lo = a; cens = base + [lo + (j + 0.5) * (hi - lo) / extra for j in range(extra)]
                else:  # sensitivity: extra censors stacked on detected tick positions (round robin)
                    tt = sorted(k['t'] for k in tk); cens = base + [tt[j % len(tt)] for j in range(extra)]
            n_end, S_end, rec = simulate(n0, S, dr, cens)
            D = sum(e for _, e in rec)
            c_new = max(0, n0 - target - D)
            if c_new == c: break
            c = c_new
        log.append(dict(interval=[a, b], n_start=n0, target_next=target, n_end=n_end, events=D,
                        censored=c, ticks_detected=len(tk), tick_multiplicity_total=len(base),
                        extra_unmarked_censors=max(0, c - len(base))))
        recs += rec; S = S_end; n_cur = n_end
    if n_cur > 0:  # anyone left: censor at last supported time (should not happen with risk 0 at 36)
        recs += [(tmax, 0)] * n_cur; log.append(dict(note=f'{n_cur} left, censored at {tmax:.3f}'))
    df = pd.DataFrame(recs, columns=['observed_time', 'event']); df.insert(0, 'group', g)
    return df, log, segs, rej, ticks

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S))
    return out
def S_at(steps, t):
    s = 1.0
    for u, v in steps:
        if u <= t: s = v
        else: break
    return s
def rmst(steps, h):
    tt = [0] + [u for u, _ in steps if u < h] + [h]; area = 0; s = 1.0
    for j in range(len(tt) - 1):
        s = S_at(steps, tt[j]) if j else 1.0; area += s * (tt[j + 1] - tt[j])
    return area

def write_atomic(df, path):
    tmp = path + '.tmp'; df.to_csv(tmp, index=False, float_format='%.4f'); os.replace(tmp, path)

res = {g: reconstruct(g) for g in 'AB'}
ipd = pd.concat([res[g][0] for g in 'AB'], ignore_index=True)
assert all((ipd.group == g).sum() == N[g] for g in 'AB')
write_atomic(ipd, f'{out}/ipd.csv')

# ---- checks from reloaded committed CSV ----
ipd = pd.read_csv(f'{out}/ipd.csv'); sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
TOL = 0.01  # prespecified: ~one event at n=100 (0.01) and ~7 px, well above 1-2 px measurement error
checks = dict(csv_sha256=sha, tolerance_S=TOL, tolerance_note='0.01 survival = one event quantum at n=100; pixel reading error ~0.0013/px',
              event_totals='unavailable (not supplied in manifest)', groups={})
for g in 'AB':
    d = ipd[ipd.group == g]; st = km(d); segs = res[g][2]
    cg = dict(n=int(len(d)), n_expected=N[g], events=int(d.event.sum()),
              event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
              min_time=float(d.observed_time.min()), max_time=float(d.observed_time.max()), log=res[g][1],
              rejected_ticks=res[g][3], survival=[], risk=[])
    ts = sorted(set([0.5, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 34.0]))
    for t in ts:
        sg = [s for s in segs if s['t0'] + 0.05 <= t <= s['t1'] - 0.05]
        if not sg: cg['survival'].append(dict(t=t, status='unavailable (in a drop gap / beyond curve)')); continue
        m = sg[0]['S']; r = S_at(st, t)
        cg['survival'].append(dict(t=t, measured=round(m, 4), reconstructed=round(r, 4), resid=round(r - m, 4),
                                   status='pass' if abs(r - m) <= TOL else 'fail'))
    for t, n in zip(T, RISK[g]):
        r = int((d.observed_time >= t).sum())
        cg['risk'].append(dict(t=t, displayed=n, reconstructed=r, resid=r - n, status='pass' if r == n else 'fail'))
    checks['groups'][g] = cg
json.dump(checks, open(f'{out}/checks.json', 'w'), indent=1, default=float)
for g in 'AB':
    c = checks['groups'][g]
    print(g, 'n', c['n'], 'events', c['events'], 'max', c['max_time'])
    print('  risk', [(r['t'], r['displayed'], r['reconstructed']) for r in c['risk']])
    print('  S fails', [s for s in c['survival'] if s.get('status') == 'fail'])
    print('  max|resid|', max(abs(s['resid']) for s in c['survival'] if 'resid' in s))
    for l in c['log']: print('  ', l)

# ---- one sensitivity allocation ----
sens = {g: reconstruct(g, mode='at_ticks')[0] for g in 'AB'}
sdf = pd.concat([sens[g] for g in 'AB'], ignore_index=True); write_atomic(sdf, f'{out}/sensitivity.csv')
H = float(min(ipd[ipd.group == g].observed_time.max() for g in 'AB'))
comp = dict(assumption='unmarked extra censors stacked on detected tick times within each risk interval (primary: spread uniformly over interval)',
            horizon=H, arms={})
for g in 'AB':
    p = km(ipd[ipd.group == g]); s = km(sdf[sdf.group == g])
    comp['arms'][g] = dict(S_primary=S_at(p, H), S_sens=S_at(s, H), RMST_primary=rmst(p, H), RMST_sens=rmst(s, H),
                           S12_primary=S_at(p, 12), S12_sens=S_at(s, 12), S24_primary=S_at(p, 24), S24_sens=S_at(s, 24))
checks['sensitivity'] = comp
json.dump(checks, open(f'{out}/checks.json', 'w'), indent=1, default=float)
print(json.dumps(comp, indent=1))
