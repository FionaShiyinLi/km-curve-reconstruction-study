"""Reconstruct participant-level records from parsed KM steps, censor ticks and the risk table.
Usage: python reconstruct.py [outdir] [--mode ticks|uniform] [--out file.csv]
  ticks   (primary): censorings required beyond one-per-visible-tick are added as hidden
                     multiplicity at visible ticks of the same risk interval.
  uniform (sensitivity): the same extra censorings are spread evenly over the interval.
Deterministic; seed recorded for completeness (no random draws are made)."""
import sys, os, json, argparse, numpy as np
SEED = 826684418
np.random.seed(SEED)
ap = argparse.ArgumentParser(); ap.add_argument('outdir', nargs='?', default='output')
ap.add_argument('--mode', default='ticks'); ap.add_argument('--out', default=None)
a = ap.parse_args(); out = a.outdir
P = json.load(open(f'{out}/parsed_steps.json'))
N = {'A': 100, 'B': 100}                                   # manifest
RT = [0, 6, 12, 18, 24, 30, 36]                            # risk-table times (read from figure)
RISK = {'A': [100, 68, 44, 30, 22, 13, 0], 'B': [100, 76, 55, 44, 31, 9, 0]}
# Arm A 0-0.6 mo is overdrawn by arm B; remeasured from an 8x crop (see assumptions.md):
# blue vertical at x~280-283 px down to the 0.98 level, second vertical at x~289-292 px to 0.96.
MANUAL_EARLY = {'A': [dict(t=(281.5 - 269.5) / 40, S_before=1.0, S_after=(929.5 - 193.5) / 750),
                      dict(t=(290.5 - 269.5) / 40, S_before=(929.5 - 193.5) / 750, S_after=0.96)],
                'B': []}

def simulate(n0, S0, drops, cens):
    """Forward KM with events before censorings at tied times. Returns losses, events, S, sq error."""
    pts = [(d['t'], 0, d) for d in drops] + [(c, 1, None) for c in cens]
    pts.sort(key=lambda p: (p[0], p[1]))
    n, S, ev, err, recs = n0, S0, 0, 0.0, []
    for t, kind, d in pts:
        if kind == 0:
            if n <= 0: return None
            cands = range(1, n + 1)
            k = min(cands, key=lambda k: abs(S * (1 - k / n) - d['S_after']))
            S *= (1 - k / n); n -= k; ev += k
            err += (S - d['S_after']) ** 2
            recs += [(t, 1)] * k
        else:
            if n <= 0: return None
            n -= 1; recs.append((t, 0))
    return dict(n=n, S=S, ev=ev, err=err, recs=recs)

log = {}
records = []
for g in 'AB':
    drops = MANUAL_EARLY[g] + P[g]['drops']
    ticks = P[g]['ticks']
    n, S = N[g], 1.0
    glog = []
    for k in range(len(RT) - 1):
        lo_t, hi_t = RT[k], RT[k + 1]
        dk = [d for d in drops if lo_t <= d['t'] < hi_t]
        tk = [c for c in ticks if lo_t <= c['t'] < hi_t]
        target = RISK[g][k + 1]
        tick_t = [c['t'] for c in tk]
        # order for receiving hidden multiplicity: wider ticks first, then by time
        order = [c['t'] for c in sorted(tk, key=lambda c: (-c['width'], c['t']))]
        best = None
        for extra in range(0, n + 1):
            if a.mode == 'ticks' and order:
                ext = [order[i % len(order)] for i in range(extra)]
            else:   # evenly spaced within the interval (also fallback when no tick is visible)
                ext = list(lo_t + (hi_t - lo_t) * (np.arange(extra) + 0.5) / extra) if extra else []
            if hi_t == RT[-1]:      # displayed 0 at risk at 36: keep every record strictly < 36
                ext = [min(x, P[g]['end_t']) for x in ext]
            sim = simulate(n, S, dk, tick_t + ext)
            if sim is None: break
            score = (abs(sim['n'] - target), sim['err'])
            if best is None or score < best[0]: best = (score, extra, sim)
            if sim['n'] < target: break
        score, extra, sim = best
        glog.append(dict(interval=[lo_t, hi_t], n_start=n, n_end=sim['n'], table_end=target,
                         visible_ticks=len(tk), extra_censor=extra, events=sim['ev'],
                         censored=len(tk) + extra, S_end=sim['S'], sq_err=sim['err']))
        records += [(g, t, e) for t, e in sim['recs']]
        n, S = sim['n'], sim['S']
    if n > 0:   # should not happen with a displayed 0 at 36; censor at last drawn time if it does
        glog.append(dict(note=f'{n} left after last interval censored at curve end'))
        records += [(g, P[g]['end_t'], 0)] * n
    log[g] = glog

import pandas as pd
df = pd.DataFrame(records, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False]).reset_index(drop=True)
for g in 'AB': assert (df.group == g).sum() == N[g], (g, (df.group == g).sum())
dest = a.out or f'{out}/ipd.csv'
tmp = dest + '.tmp'
df.to_csv(tmp, index=False); os.replace(tmp, dest)
json.dump(log, open(dest.replace('.csv', '_reconstruction_log.json'), 'w'), indent=1)
for g in 'AB':
    for r in log[g]: print(g, r)
print('wrote', dest, len(df))
