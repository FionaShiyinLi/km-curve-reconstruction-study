"""Measure KM step curves and censor ticks from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.array(Image.open(fig).convert('RGB')).astype(int)
# Axis calibration from tick marks (pixel centres of 2-px ticks, measured in exploration):
# x: 0 -> 269.5, 36 -> 1709.5 (ticks every 6 mo at 240 px); y: 1.0 -> 179.5, 0.0 -> 929.5
X0, XS = 269.5, 40.0
Y0, YS = 929.5, 750.0
t_of = lambda px: (px - X0) / XS
s_of = lambda py: (Y0 - py) / YS
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
res = {}
for g, c in COL.items():
    d = np.abs(im - np.array(c)).sum(2)
    m = d < 60
    m[:150] = False; m[935:] = False       # restrict to plot panel (exclude legend)
    xs = np.arange(265, 1715)
    lo = np.full(len(xs), -1); hi = np.full(len(xs), -1)
    for i, x in enumerate(xs):
        r = np.where(m[:, x])[0]
        if len(r): lo[i], hi[i] = r.min(), r.max()
    res[g] = dict(xs=xs.tolist(), lo=lo.tolist(), hi=hi.tolist())
json.dump(res, open(f'{out}/raw_columns.json', 'w'))
