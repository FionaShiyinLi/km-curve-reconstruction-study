# Reconstruction assumptions and method

## Inputs
- `../input/figure.png` (1800 x 1350 raster) and `../input/manifest.json` (n = 100 per arm, months, seed 826684418).
- The manifest gives no arm-specific event totals. Event totals are therefore unconstrained by supplied data and are reported as "unavailable" in `checks.json`.
- Risk table read from the figure at 0, 6, ..., 36 months: A 100/68/44/30/22/13/0; B 100/76/55/44/31/9/0. All labels were legible.

## Measurement (`code/extract.py`, `code/parse_steps.py`)
- Calibration comes from the axis tick marks. x: 0 mo at pixel 269.5 and 36 mo at 1709.5 (40 px/mo, ticks every 240 px, all 7 consistent). y: S=1 at row 179.5 and S=0 at row 929.5 (750 px/unit, all 6 ticks consistent). No global rescaling was applied. The measured starting level of B is 1.000, and A's first unobscured level is 0.960.
- Arm colors are exact RGB values (A #1f77b4, B #ff7f0e). For each pixel column, the vertical span of the colored pixels was recorded (`raw_columns.json`). A column counts as a horizontal run when its span is 4-5 px (line width). The level is the span center. A drop is a level change between consecutive horizontal runs, with its time at the center of the vertical segment. When several drops occur with no horizontal pixel between them, they are measured as one lumped drop, so event times there are uncertain by about ±0.1 mo.
- Censor ticks are marks that extend beyond the line (about ±7 px) above the left level or below the right level (`parsed_steps.json`).
- **Early region.** Arm B's curve covers arm A's between 0 and 0.6 mo. I remeasured it from an 8x crop (`crop_early.png`). A drops 1.00→0.98 at about 0.30 mo (x ≈ 281.5 px) and 0.98→0.96 at about 0.53 mo (x ≈ 290.5 px). These values are hard-coded in `reconstruct.py` and `check.py` as `MANUAL_EARLY`. Any A censor tick hidden in this region cannot be seen. A short blue fragment at x ≈ 283-286 px is ambiguous and was not treated as a tick.
- **Tail.** Near 33.8 mo (x ≈ 1620 px) arm B's vertical segment hides part of arm A's line (`crop_tail.png`). A hidden A tick there cannot be ruled out. A's final mark at 35.94 mo is 5 px wide, so it may be one or two ticks.

## Reconstruction (`code/reconstruct.py`, deterministic; the seed is set but no random draws are made)
The algorithm works forward, one risk-table interval [t_k, t_{k+1}) at a time.
1. At each measured drop, the event count d is the integer ≥1 that brings the reconstructed KM, S_prev·(1 − d/n_risk), closest to the **absolute** measured level after the drop. I did not assume d = 1, and matching the absolute level keeps errors from accumulating. Events come before censorings at tied times.
2. Each visible tick counts as at least one censoring at its measured time.
3. After that, the interval usually still needs extra censorings to reach the displayed n at the next risk-table time. The number of extras was chosen so that the reconstructed count equals the table value, breaking ties by curve fit. **Primary assumption:** the extras are hidden multiplicity at visible ticks in the same interval (wider ticks first, then by time), because a censoring with no drawn mark is more likely a tied or overlapping tick than an unmarked time. Extras by interval: A 1,1,0,0,0,2; B 2,1,0,0,4,0. This is an assumption. Only the risk counts and the drop sizes, through n_risk, constrain it.
4. The risk table shows 0 at 36 mo, so every record is placed strictly before 36. The last observed times are A 35.94 and B 35.53, both at measured final ticks. No follow-up was extended beyond the drawn curves.
- Result: A has 76 events and 24 censorings; B has 65 events and 35 censorings. These totals follow from the reconstruction and are not supplied values.

## Verification (`code/check.py` → `checks.json`)
The script reloads `ipd.csv` and recomputes the right-continuous KM curve, with no interpolation. That curve is compared with the measured step function at every plateau midpoint and near the end of each curve. The tolerance is 0.004 (about 3 px of line-center uncertainty) plus half of one event step, 0.5·S/n_risk. All points pass. The largest absolute residual is 0.0013 for A and 0.0043 for B; B's largest residuals are on the 28.8-33.5 mo plateau, where the measured value is 0.256 and the reconstruction gives 0.252. Risk counts use n(t) = #{observed_time ≥ t} and match the table exactly at all seven times in both arms.

## Limitations
- The exact censoring times of hidden or overlapping ticks, and the split of events within lumped adjacent drops, are not identified. The reconstruction is one feasible solution, not a unique recovery, and no error bound is claimed.
- Censorings in intervals with no visible ticks: none were needed (A and B at 12-24 mo).
- A censoring hidden in A's first 0.6 mo would shift A's early n_risk by 1. The absolute-level matching of later drops would absorb this.

## Sensitivity analysis (one alternative, `sensitivity.csv`)
- Assumption: the same number of extra censorings in each interval, spread evenly over the interval instead of placed at visible ticks (`reconstruct.py --mode uniform`). The risk table is still matched exactly, and event totals are unchanged (A 76, B 65).
- Common supported horizon: 35.5 mo, the floor of the shortest last observed time across both arms and both files. Values below are primary vs. sensitivity; the full set of times (6, 12, 18, 24, 30, 35.5 mo) is in `checks.json`.
  - A: S(35.5) 0.183 vs 0.186; area under the survival curve to 35.5 mo, 14.86 vs 14.92 mo.
  - B: S(30) 0.252 vs 0.261; S(35.5) 0.126 vs 0.130; area to 35.5 mo, 19.11 vs 19.21 mo.
- The largest difference is B at 24-30 mo, where 4 extra censorings are needed. This is one alternative. It is not a confidence interval and does not bound total reconstruction error. The primary allocation was chosen on the grounds in step 3 above, not on the resulting treatment contrast.
- `checks.json` was regenerated after the sensitivity run. `ipd.csv` did not change (same SHA-256), and no primary correction cycles were used.
