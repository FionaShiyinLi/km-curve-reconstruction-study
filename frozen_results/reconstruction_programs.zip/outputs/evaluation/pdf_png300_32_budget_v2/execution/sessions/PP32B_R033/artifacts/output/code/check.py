"""Reload committed CSV(s), recompute right-continuous KM, compare to measured curve and risk table.
Usage: python check.py [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
P = json.load(open(f'{out}/parsed_steps.json'))
RT = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 68, 44, 30, 22, 13, 0], 'B': [100, 76, 55, 44, 31, 9, 0]}
N = {'A': 100, 'B': 100}
MANUAL = {'A': [((281.5 - 269.5) / 40, (929.5 - 193.5) / 750), ((290.5 - 269.5) / 40, 0.96)], 'B': []}

def km(df):
    t = np.sort(df.observed_time.unique()); S = 1.0; ts, ss = [0.0], [1.0]
    for u in t:
        n = (df.observed_time >= u).sum(); d = ((df.observed_time == u) & (df.event == 1)).sum()
        if d: S *= 1 - d / n; ts.append(u); ss.append(S)
    return np.array(ts), np.array(ss)
def step_eval(ts, ss, x):          # right-continuous step function
    return ss[np.searchsorted(ts, x, side='right') - 1]
def measured(g):
    ts = [0.0] + [m[0] for m in MANUAL[g]] + [d['t'] for d in P[g]['drops']]
    ss = [1.0] + [m[1] for m in MANUAL[g]] + [d['S_after'] for d in P[g]['drops']]
    return np.array(ts), np.array(ss)
def rmst(ts, ss, h):
    grid = np.append(ts[ts < h], h); return float(np.sum(np.diff(grid) * ss[:len(grid) - 1]))

df = pd.read_csv(f'{out}/ipd.csv')
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
chk = dict(csv='ipd.csv', sha256=sha, conventions=dict(
    km='right-continuous product-limit step function from the committed CSV (no interpolation)',
    risk='n(t) = #records with observed_time >= t; events precede censorings at tied times',
    curve_tolerance='|diff| <= 0.004 + 0.5*S/n_risk: 0.004 = ~3 px of line-centre/antialiasing '
                    'uncertainty (1 px = 0.00133); half an event step is the KM integer granularity'),
    arms={})
for g in 'AB':
    d = df[df.group == g]; ts, ss = km(d); mt, ms = measured(g)
    basic = dict(n_records=int(len(d)), expected=N[g], n_ok=bool(len(d) == N[g]),
                 event_values_ok=bool(d.event.isin([0, 1]).all()),
                 times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                 events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                 supplied_event_total='unavailable (not in manifest)', max_time=float(d.observed_time.max()))
    # curve checks at plateau midpoints between measured drops plus tail points
    pts = [0.5 * (mt[i] + mt[i + 1]) for i in range(len(mt) - 1)] + [0.5 * (mt[-1] + P[g]['end_t'])]
    pts = sorted(set([round(p, 3) for p in pts] + [0.05, P[g]['end_t'] - 0.02]))
    curve = []
    for x in pts:
        m = float(step_eval(mt, ms, x)); r = float(step_eval(ts, ss, x))
        nr = int((d.observed_time >= x).sum()); tol = 0.004 + 0.5 * m / max(nr, 1)
        curve.append(dict(t=x, measured=round(m, 4), reconstructed=round(r, 4), resid=round(r - m, 4),
                          tol=round(tol, 4), status='pass' if abs(r - m) <= tol else 'fail'))
    risk = []
    for t, nt in zip(RT, RISK[g]):
        c = int((d.observed_time >= t).sum())
        risk.append(dict(t=t, table=nt, reconstructed=c, resid=c - nt, status='pass' if c == nt else 'fail'))
    chk['arms'][g] = dict(basic=basic, curve=curve, risk_table=risk,
                          curve_fail=sum(c['status'] == 'fail' for c in curve),
                          max_abs_curve_resid=max(abs(c['resid']) for c in curve),
                          tail=[c for c in curve if c['t'] >= 30])
# sensitivity comparison if present
try:
    sd = pd.read_csv(f'{out}/sensitivity.csv')
    H = float(min(df.groupby('group').observed_time.max().min(), sd.groupby('group').observed_time.max().min()))
    H = float(np.floor(H * 10) / 10)
    comp = dict(horizon=H, note='common supported horizon = floor(min last observed time over arms and files)')
    for g in 'AB':
        a1, a2 = km(df[df.group == g]), km(sd[sd.group == g])
        comp[g] = {f'S({x})': [round(float(step_eval(*a1, x)), 4), round(float(step_eval(*a2, x)), 4)] for x in [6, 12, 18, 24, 30, H]}
        comp[g]['RMST_to_H'] = [round(rmst(*a1, H), 3), round(rmst(*a2, H), 3)]
        comp[g]['columns'] = ['primary', 'sensitivity']
        comp[g]['risk_table_sensitivity'] = [int((sd[sd.group == g].observed_time >= t).sum()) for t in RT]
    chk['sensitivity'] = comp
except FileNotFoundError:
    chk['sensitivity'] = 'not run'
json.dump(chk, open(f'{out}/checks.json', 'w'), indent=1)
for g in 'AB':
    A = chk['arms'][g]; print(g, A['basic']); print(' curve fails', A['curve_fail'], 'max resid', A['max_abs_curve_resid'])
    print(' fails:', [c for c in A['curve'] if c['status'] == 'fail'])
    print(' risk', [(r['t'], r['table'], r['reconstructed']) for r in A['risk_table']])
    print(' tail', A['tail'])
print(json.dumps(chk['sensitivity'], indent=0)); print(sha)
