"""Turn per-column pixel spans (raw_columns.json) into step drops and censor ticks.
Usage: python parse_steps.py [outdir]"""
import sys, json, numpy as np
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
X0, XS, Y0, YS = 269.5, 40.0, 929.5, 750.0
t_of = lambda px: (px - X0) / XS
s_of = lambda py: (Y0 - py) / YS
raw = json.load(open(f'{out}/raw_columns.json'))
LW = 3          # line drawn 4 px thick: hi-lo == 3 on a pure horizontal column
TICK_W = 3      # a single censor tick is ~3 px wide
result = {}
for g in 'AB':
    xs = np.array(raw[g]['xs']); lo = np.array(raw[g]['lo']); hi = np.array(raw[g]['hi'])
    pure = (lo >= 0) & ((hi - lo == LW) | (hi - lo == LW + 1))   # 4 or 5 px (fractional row position)
    pidx = np.where(pure)[0]
    drops, ticks = [], []
    # walk consecutive pure columns; the region between them is a drop and/or tick region
    for a, b in zip(pidx[:-1], pidx[1:]):
        lt, rt = lo[a], lo[b]                     # top rows of left/right levels
        lc, rc = 0.5 * (lo[a] + hi[a]), 0.5 * (lo[b] + hi[b])   # level centres
        reg = np.arange(a + 1, b)
        reg = reg[lo[reg] >= 0]                   # skip columns hidden by the other curve
        if abs(rc - lc) >= 2:
            # vertical segment columns: those whose span covers rows between the levels
            vcols = [i for i in reg if lo[i] <= lt + 1 and hi[i] >= rt + LW - 1]
            xv = xs[vcols].mean() if vcols else 0.5 * (xs[a] + xs[b])
            drops.append(dict(px=float(xv), t=t_of(xv), row_before=lc, row_after=rc,
                              S_before=s_of(lc), S_after=s_of(rc), pure_gap=[int(xs[a]), int(xs[b])]))
        # ticks: columns rising >2 px above the left level, or extending >2 px below the right level
        tc = [i for i in reg if lo[i] < min(lt, rt) - 2 or hi[i] > max(hi[a], hi[b]) + 2]
        if tc:
            # group contiguous columns
            groups, cur = [], [tc[0]]
            for i in tc[1:]:
                if xs[i] - xs[cur[-1]] <= 1: cur.append(i)
                else: groups.append(cur); cur = [i]
            groups.append(cur)
            for gg in groups:
                xc = xs[gg].mean(); w = len(gg)
                ctr = 0.5 * (lo[gg].min() + hi[gg].max())
                ticks.append(dict(px=float(xc), t=t_of(xc), width=int(w), centre_row=float(ctr),
                                  S_at=s_of(ctr), top=int(lo[gg].min()), bottom=int(hi[gg].max())))
    # tick after the last pure column (end of curve)
    last = pidx[-1]; tail = [i for i in range(last + 1, len(xs)) if lo[i] >= 0 and lo[i] < lo[last] - 2]
    if tail:
        xc = xs[tail].mean()
        ticks.append(dict(px=float(xc), t=t_of(xc), width=len(tail), centre_row=None, S_at=s_of(lo[last] + 1.5),
                          top=int(lo[tail].min()), bottom=int(hi[tail].max())))
    # curve end = last coloured column
    end_px = xs[np.where(lo >= 0)[0].max()]
    result[g] = dict(drops=drops, ticks=ticks, end_px=int(end_px), end_t=t_of(end_px),
                     first_level_S=s_of(0.5 * (lo[pidx[0]] + hi[pidx[0]])), first_pure_px=int(xs[pidx[0]]))
json.dump(result, open(f'{out}/parsed_steps.json', 'w'), indent=1)
for g in 'AB':
    r = result[g]; print(g, 'first level S', round(r['first_level_S'], 4), 'at px', r['first_pure_px'], 'end t', r['end_t'])
    print(' drops:', ' '.join(f"{d['t']:.2f}:{d['S_before']:.4f}>{d['S_after']:.4f}" for d in r['drops']))
    print(' ticks:', ' '.join(f"{k['t']:.2f}(w{k['width']},S{k['S_at']:.3f})" for k in r['ticks']))
