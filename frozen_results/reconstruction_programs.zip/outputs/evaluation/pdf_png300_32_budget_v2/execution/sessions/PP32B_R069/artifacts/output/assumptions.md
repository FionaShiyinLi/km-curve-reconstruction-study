# Reconstruction assumptions and method

## Inputs
- `../input/figure.pdf`: a single-page vector PDF with no embedded raster images.
- `../input/manifest.json`: N_A = N_B = 1000, time unit is months, code seed is 1470061102.
- The manifest has no arm-specific event totals. That constraint is marked unavailable, and its absence was not read as zero events.

## Measurement
- Arm identity comes from the legend. The blue stroke (RGB 0.12/0.47/0.71) labels Group A and the orange stroke (1.0/0.50/0.05) labels Group B.
- Calibration is a least-squares fit to the labelled axis ticks. Time: x = 64.8 pt is 0 months and x = 410.4 pt is 36 months, with seven ticks. Survival: y = 223.2 pt is 0.0 and y = 43.2 pt is 1.0, with six ticks. The calibration residuals are below 1e-13.
- No global rescaling or running-minimum correction was applied. Both curves start exactly at S = 1.0 (y = 43.2 pt). The early drops were kept as drawn, including the first A event at 0.0099 months.
- Each KM curve is one step path with no diagonal segments. A has 798 vertical drops and B has 630. Censor marks are 4-pt vertical strokes in the arm's colour: 202 for A and 370 for B. No two strokes coincide, so there are no hidden multiple ticks.
- Extracted observations are in `extracted_observations.json` (vertices, tick positions and the risk table). Per-drop diagnostics are in `reconstruction_diagnostics.json`.

## Algorithm (`code/reconstruct.py`, deterministic)
- The program walks forward in time. Each censor stroke is one censoring at its x-time. At each drop, n_risk = N minus prior events minus prior censorings. A censoring tied with an event time is placed after the event.
- The event count at each drop is computed, not assumed: d = n_risk(1 − S_after/S_before). Across all drops, the largest |d − round(d)| is 5.2e-4. This means d = 1 at every drop, a conclusion supported by the vector precision (about 1e-5 pt, where 1 event at n = 1000 is 0.18 pt) together with the independently counted risk sets. It does not rest on the reciprocal-drop pattern alone.
- Events plus ticks equal N exactly in both arms: A has 798 + 202 and B has 630 + 370. No participants were left over, so no extra censorings were invented at the curve end.
- The seed is recorded in the code, but nothing in the program is random.
- Times are stored to 8 decimals. The closest pair of drops is about 1.0e-5 months apart. An earlier 5-decimal version merged or shifted near-tied times. It was corrected in one primary correction cycle.

## Checks (`code/checks.py` → `checks.json`)
- The committed CSV was reloaded and the right-continuous KM curve recomputed from it. It was compared with the measured step curve at 18 grid times from 0 to 35.93 months, including the tail, and at every vertex. The largest absolute residual is 2.8e-7 against a tolerance of 1e-4.
- For the risk table, records with observed_time ≥ t were counted at 0, 6, 12, 18, 24, 30 and 36 months. All match the printed counts exactly (A: 1000/692/485/334/221/69/0; B: 1000/635/521/422/342/148/0). The zero at 36 months holds because the last observations are about 35.93 months.

## Limitations
- The exact times are as drawn, limited by figure precision. If the original times were rounded or jittered before plotting, that cannot be recovered.
- The last observations (A: 35.929 months, B: 35.938 months) are censor marks. Nothing is implied about follow-up beyond them.
- No sensitivity analysis was run. The drops, tick counts and risk table fit one allocation to within 1e-3 events, so no materially different allocation exists. The remaining ambiguity is sub-pixel: whether a tick at an event time falls before or after that event.
