"""Reconstruct participant-level records from the vector KM figure.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: INPUT_DIR=../input, OUTPUT_DIR=output (relative to the work dir).

Algorithm (deterministic; the seed is recorded but no randomness is used):
1. Parse the PDF vector paths with pdfplumber. Calibrate time from the labelled
   x-axis ticks (0..36 months) and survival from the labelled y-axis ticks
   (0.0..1.0) by linear least squares on the tick positions.
2. Each arm's KM curve is a single step path (no diagonal segments). Every
   vertical segment is a drop: S_before -> S_after at time t.
3. Censor marks are short vertical 4-pt strokes in the arm colour; their
   x-position gives the censoring time. Each stroke object is counted once
   (coincident strokes are counted as separate participants).
4. Walk forward in time: n_risk = N - (#events before t) - (#censored before t)
   (censoring at a tied time is placed after the event, the usual KM
   convention). d = n_risk * (1 - S_after/S_before), rounded to an integer;
   the non-integer residual is saved for inspection.
5. Participants unaccounted for after the last drop/tick are censored at the
   end of the drawn curve (assumption; reported in checks).
"""
import json, sys, os, hashlib, collections
import numpy as np
import pdfplumber

SEED = 1470061102
np.random.seed(SEED)  # recorded; not used

inp = sys.argv[1] if len(sys.argv) > 1 else "../input"
out = sys.argv[2] if len(sys.argv) > 2 else "output"
man = json.load(open(os.path.join(inp, "manifest.json")))
pg = pdfplumber.open(os.path.join(inp, "figure.pdf")).pages[0]

BLUE = (0.121569, 0.466667, 0.705882)
ORANGE = (1.0, 0.498039, 0.054902)
# Legend: the blue stroke precedes the text "Group A", the orange one "Group B".
COLOR = {"A": BLUE, "B": ORANGE}

# --- axis calibration from labelled ticks ---
black = [l for l in pg.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted(l["pts"][0][0] for l in black
            if l["pts"][0][0] == l["pts"][1][0] and abs(l["pts"][1][1] - l["pts"][0][1]) < 5)
yt = sorted(l["pts"][0][1] for l in black
            if l["pts"][0][1] == l["pts"][1][1] and abs(l["pts"][1][0] - l["pts"][0][0]) < 5)
xlab = [0, 6, 12, 18, 24, 30, 36]
ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # top-down (pdfplumber y grows downward)
ax, bx = np.polyfit(xt, xlab, 1)
ay, by = np.polyfit(yt, ylab, 1)
tfun = lambda x: ax * x + bx
sfun = lambda y: ay * y + by
calib = {"x_ticks_pt": xt, "y_ticks_pt": yt,
         "x_resid": list(np.array(xlab) - tfun(np.array(xt))),
         "y_resid": list(np.array(ylab) - sfun(np.array(yt)))}

# risk table (text-parsed)
risk_times = xlab
def risk_row(label):
    words = pg.extract_words()
    row = [w for w in words if abs(w["top"] - [v["top"] for v in words if v["text"] == label][0]) < 1]
    return row
rt = {}
lines = pg.extract_text().splitlines()
for g in ("A", "B"):
    ln = [l for l in lines if l.startswith(f"Group {g} ") and l.split()[-1].isdigit()][0]
    rt[g] = [int(v) for v in ln.split()[2:]]

records, obs, diag = [], {}, {}
for g in ("A", "B"):
    N = man["groups"][g]
    cv = [c for c in pg.curves if tuple(c["stroking_color"]) == COLOR[g]][0]
    pts = cv["pts"]
    drops, verts = [], []
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if x0 == x1 and y1 != y0:
            drops.append((tfun(x0), sfun(y0), sfun(y1)))
        verts.append((tfun(x0), sfun(y0)))
    verts.append((tfun(pts[-1][0]), sfun(pts[-1][1])))
    t_end = tfun(pts[-1][0])
    ticks = sorted(tfun(l["pts"][0][0]) for l in pg.lines
                   if tuple(l["stroking_color"]) == COLOR[g] and l["linewidth"] < 0.9)
    tick_y = [(tfun(l["pts"][0][0]), sfun((l["pts"][0][1] + l["pts"][1][1]) / 2)) for l in pg.lines
              if tuple(l["stroking_color"]) == COLOR[g] and l["linewidth"] < 0.9]
    ci = 0
    n = N
    ev, dres = [], []
    for t, s0, s1 in drops:
        while ci < len(ticks) and ticks[ci] < t - 1e-9:
            records.append((g, ticks[ci], 0)); ci += 1; n -= 1
        draw = n * (1 - s1 / s0)
        d = int(round(draw))
        dres.append({"t": t, "n_risk": n, "d_raw": draw, "d": d})
        for _ in range(d):
            records.append((g, t, 1))
        n -= d
        ev.append(d)
    rem_ticks = ticks[ci:]
    for t in rem_ticks:
        records.append((g, t, 0)); n -= 1
    n_extra = n
    for _ in range(max(n, 0)):
        records.append((g, t_end, 0))
    obs[g] = {"verts": verts, "ticks": tick_y, "t_end": t_end}
    diag[g] = {"n_drops": len(drops), "n_events": int(sum(ev)), "n_ticks": len(ticks),
               "coincident_tick_groups": sum(1 for v in collections.Counter(np.round(ticks, 6)).values() if v > 1),
               "max_abs_d_resid": float(max(abs(r["d_raw"] - r["d"]) for r in dres)),
               "drops_with_d_gt1": int(sum(r["d"] > 1 for r in dres)),
               "unaccounted_after_last_tick": int(n_extra), "t_end": t_end,
               "d_table": dres}

os.makedirs(out, exist_ok=True)
import pandas as pd
df = pd.DataFrame(records, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0).round(8)
df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
assert all((df.group == g).sum() == man["groups"][g] for g in ("A", "B")), diag
tmp = os.path.join(out, "ipd.csv.tmp")
df.to_csv(tmp, index=False)
os.replace(tmp, os.path.join(out, "ipd.csv"))

json.dump({"calibration": calib, "risk_table": rt, "risk_times": risk_times,
           "curves": obs}, open(os.path.join(out, "extracted_observations.json"), "w"))
json.dump(diag, open(os.path.join(out, "reconstruction_diagnostics.json"), "w"), indent=1)
for g in diag:
    print(g, {k: v for k, v in diag[g].items() if k != "d_table"})
print("calib", calib)
print("risk table", rt)
