"""Reload output/ipd.csv, recompute right-continuous KM per arm, compare to the
measured vector curve and the printed risk table; write output/checks.json.
Usage: python checks.py [OUTPUT_DIR]"""
import json, sys, os, hashlib
import numpy as np, pandas as pd

out = sys.argv[1] if len(sys.argv) > 1 else "output"
csv = os.path.join(out, "ipd.csv")
sha = hashlib.sha256(open(csv, "rb").read()).hexdigest()
df = pd.read_csv(csv)
obs = json.load(open(os.path.join(out, "extracted_observations.json")))
man = json.load(open(os.path.join(out, "..", "..", "input", "manifest.json"))) if os.path.exists(
    os.path.join(out, "..", "..", "input", "manifest.json")) else {"groups": {"A": 1000, "B": 1000}}

# Tolerance: vector coordinates are given to ~1e-5 pt; 1 pt = 1/180 survival,
# so measurement error is <1e-6 in S. Use 1e-4 (well under one event, 1e-3).
TOL_S = 1e-4

def km(t, e):
    ut = np.unique(t[e == 1]); S = 1.0; st = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d / n; st.append((u, S))
    return st

def km_at(st, x):  # right-continuous step
    S = 1.0
    for u, s in st:
        if u <= x: S = s
        else: break
    return S

def meas_at(verts, x):  # measured curve, right-continuous: last vertex with t<=x
    S = verts[0][1]
    for t, s in verts:
        if t <= x + 1e-12: S = s
        else: break
    return S

res = {"csv_sha256": sha, "tolerance_S": TOL_S,
       "tolerance_justification": "vector PDF coordinates, calibration residual <1e-13; 1 event at n=1000 is 1e-3",
       "groups": {}}
for g in ("A", "B"):
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    st = km(t, e); verts = obs["curves"][g]["verts"]; tend = obs["curves"][g]["t_end"]
    grid = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, round(tend - 1e-3, 4)]
    # also check at every measured vertex (max residual)
    allres = max(abs(km_at(st, v[0] + 1e-7) - meas_at(verts, v[0] + 1e-7)) for v in verts)
    curve = [{"t": x, "measured": meas_at(verts, x), "reconstructed": km_at(st, x),
              "residual": km_at(st, x) - meas_at(verts, x),
              "status": "pass" if abs(km_at(st, x) - meas_at(verts, x)) <= TOL_S else "fail"} for x in grid]
    rtab = []
    for tt, r in zip(obs["risk_times"], obs["risk_table"][g]):
        c = int(np.sum(t >= tt))
        rtab.append({"t": tt, "displayed": r, "reconstructed": c, "residual": c - r,
                     "status": "pass" if c == r else "fail"})
    res["groups"][g] = {
        "n_records": int(len(d)), "n_expected": man["groups"][g],
        "n_status": "pass" if len(d) == man["groups"][g] else "fail",
        "event_indicator_integer_01": bool(set(np.unique(e)) <= {0, 1}),
        "n_events": int(e.sum()), "n_censored": int((1 - e).sum()),
        "supplied_event_total": "unavailable (not in manifest)",
        "max_time": float(t.max()), "curve_end_time": tend,
        "max_abs_residual_all_vertices": allres,
        "all_vertices_status": "pass" if allres <= TOL_S else "fail",
        "curve_checks": curve, "risk_table_checks": rtab}
json.dump(res, open(os.path.join(out, "checks.json"), "w"), indent=1)
for g in res["groups"]:
    r = res["groups"][g]
    print(g, r["n_records"], r["n_events"], r["max_abs_residual_all_vertices"],
          [c["status"] for c in r["curve_checks"]].count("fail"),
          [(c["t"], c["displayed"], c["reconstructed"]) for c in r["risk_table_checks"]])
print(sha)
