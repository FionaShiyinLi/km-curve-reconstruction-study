"""KM -> participant-record reconstruction (own implementation, Guyot-style
interval iteration).  Usage: python reconstruct.py [input_dir] [output_dir]
Defaults: input_dir=../../../input (relative to this file), output_dir=../ ."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
INP = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..')
man = json.load(open(os.path.join(INP, 'manifest.json')))
SEED = man['code_seed']; rng = np.random.default_rng(SEED)  # no stochastic step used; recorded

im = np.asarray(Image.open(os.path.join(INP, 'figure.png')).convert('RGB')).astype(int)
# ---- calibration from labelled axis ticks (measured pixel rows/cols, 2-px wide ticks)
X0, X36 = 269.5, 1709.5          # x tick centres for 0 and 36 months
Y1, Y0 = 179.5, 929.5            # y tick centres for 1.0 and 0.0
HALF = 2.0                        # half line-thickness (5-px runs on flat segments)
t_of = lambda x: (x - X0) * 36.0 / (X36 - X0)
s_of = lambda r: (Y0 - r) / (Y0 - Y1)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 692, 485, 334, 221, 69, 0], 'B': [1000, 635, 521, 422, 342, 148, 0]}  # read from figure
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}

def mask(c): return np.abs(im - np.array(c)).sum(2) < 60
def runs(v):
    idx = np.where(v)[0]
    if len(idx) == 0: return []
    br = np.where(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br + 1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st, en))

def measure(g):
    own = mask(COL[g]); other = mask(COL['B' if g == 'A' else 'A'])
    xs = np.arange(int(X0) + 1, int(X36) + 1)
    top = np.full(len(xs), np.nan); bot = np.full(len(xs), np.nan)
    for i, x in enumerate(xs):
        # B drawn over A: merge touching orange runs into A only after 1 month (crossing
        # region); near the origin the merge picks up B's own ticks/drops (correction 2)
        comb = own[150:940, x] | (other[150:940, x] if (g == 'A' and t_of(x) >= 1.0) else False)
        rr = [(a, b) for a, b in runs(comb) if own[150 + a:150 + b + 1, x].any()]
        if rr:
            top[i] = min(a for a, b in rr) + 150; bot[i] = max(b for a, b in rr) + 150
    # origin neighbourhood (t < 0.5): a 15-17 px run is a censor tick (+/-8 px about the
    # line); use its centre so the tick is not read as a drop. Not applied elsewhere.
    L = bot - top + 1
    orig = (t_of(xs) < 0.5) & (L >= 15) & (L <= 17)
    bot = np.where(orig, 0.5 * (top + bot) + HALF, bot)
    ok = ~np.isnan(bot)
    lastx = xs[ok].max()
    top = np.interp(xs, xs[ok], top[ok]); bot = np.interp(xs, xs[ok], bot[ok])
    # envelopes: ticks extend both ways; KM rows are nondecreasing in x
    T = np.maximum.accumulate(top)                 # pre-drop level edge
    # right-edge sentinel: bottom of last thin (non-tick, non-drop) run, so that a
    # terminal tick cluster is not read as a final drop
    thin = np.where(ok & (bot - top <= 6))[0]
    sent = bot[thin[-1]] if len(thin) else bot[ok][-1]
    Bm = np.minimum.accumulate(np.minimum(bot, np.where(xs > xs[thin[-1]], sent, np.inf))[::-1])[::-1]
    tick = (top < T - 3.5) & (bot > Bm + 3.5)
    S = np.clip(s_of(Bm - HALF), 0, 1)
    valid = xs <= lastx
    return dict(x=xs[valid], t=t_of(xs[valid]), S=S[valid], top=top[valid], bot=bot[valid],
                tick=tick[valid], lastx=lastx)

def tick_times(m):
    tk = m['tick']; x = m['x']; out = []
    for a, b in runs(tk):
        w = b - a + 1; k = max(1, int(round(w / 3.5)))      # merged ticks: width-based count (visibility only)
        centers = np.linspace(x[a], x[b], k + 2)[1:-1] if k > 1 else [0.5 * (x[a] + x[b])]
        out += [t_of(c) for c in centers]
    return np.array(out)

def place_censors(c, lo, hi, ticks):
    if c <= 0: return np.array([])
    tt = np.sort(ticks[(ticks >= lo) & (ticks < hi)])
    if len(tt) == 0:
        return lo + (hi - lo) * (np.arange(c) + 0.5) / c
    # each visible tick gets >=1 censoring when c allows (visibility, not multiplicity);
    # the remainder is spread over the empirical distribution of tick positions
    if c < len(tt):
        return tt[np.round(np.linspace(0, len(tt) - 1, c)).astype(int)]
    rem = c - len(tt); q = (np.arange(rem) + 0.5) / max(rem, 1)
    return np.r_[tt, tt[np.minimum((q * len(tt)).astype(int), len(tt) - 1)][:rem]]

def reconstruct(g, m):
    t, S = m['t'], m['S']
    ticks = tick_times(m); nR = RISK[g]
    events, cens = [], []
    n = nR[0]; Shat = 1.0; log = []
    for i in range(len(RISK_T) - 1):
        lo, hi = RISK_T[i], RISK_T[i + 1]
        sel = (t > lo) & (t <= hi) if i > 0 else (t >= lo) & (t <= hi)
        tt, SS = t[sel], S[sel]
        target = nR[i + 1]
        # simple explicit simulation to keep risk-set arithmetic transparent
        def sim(c):
            ct = np.sort(place_censors(c, lo, min(hi, t_of(m['lastx']) + 1e-9), ticks))
            nn, sh, ev, ci = n, Shat, [], 0
            for tj, sj in zip(tt, SS):
                while ci < len(ct) and ct[ci] < tj: nn -= 1; ci += 1
                if nn <= 0: break
                d = int(max(0, round(nn * (1 - sj / sh)))) if sh > 0 else 0
                d = min(d, nn)
                if d: ev.append((tj, d)); sh *= 1 - d / nn; nn -= d
            while ci < len(ct): nn -= 1; ci += 1
            return ct, ev, nn, sh
        c = max(0, n - target - int(round(n * (1 - SS[-1] / Shat))))
        seen = {}
        for it in range(200):
            ct, ev, nn, sh = sim(c)
            if nn == target or c in seen: break
            seen[c] = nn
            c = max(0, c + (nn - target))
        if nn != target:   # oscillation: choose c giving closest risk count
            best = min(seen, key=lambda k: (abs(seen[k] - target), k))
            c = best; ct, ev, nn, sh = sim(c)
        log.append(dict(interval=[lo, hi], n_start=int(n), censored=int(c),
                        events=int(sum(d for _, d in ev)), n_end_recon=int(nn), n_end_table=target))
        events += ev; cens += list(ct); n = nn; Shat = sh
    rows = [(g, tj, 1) for tj, d in events for _ in range(d)] + [(g, tc, 0) for tc in cens]
    return rows, log, ticks

def main():
    allrows, logs, meas = [], {}, {}
    for g in ['A', 'B']:
        m = measure(g); rows, log, ticks = reconstruct(g, m)
        assert len(rows) == man['groups'][g], (g, len(rows), log)
        allrows += rows; logs[g] = log
        meas[g] = m
        pd.DataFrame(dict(x_px=m['x'], time=m['t'], S_measured=m['S'], top_px=m['top'], bottom_px=m['bot'],
                          tick=m['tick'].astype(int))).to_csv(os.path.join(OUT, f'measured_{g}.csv'), index=False)
        pd.DataFrame(dict(tick_time=ticks)).to_csv(os.path.join(OUT, f'ticks_{g}.csv'), index=False)
    df = pd.DataFrame(allrows, columns=['group', 'observed_time', 'event'])
    df['observed_time'] = df.observed_time.round(4)
    df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
    json.dump(logs, open(os.path.join(OUT, 'interval_log.json'), 'w'), indent=1)
    print(json.dumps(logs, indent=1))

if __name__ == '__main__':
    main()
