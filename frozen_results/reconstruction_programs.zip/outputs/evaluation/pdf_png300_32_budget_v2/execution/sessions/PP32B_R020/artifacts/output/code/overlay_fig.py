"""Draw reconstructed KM (from committed ipd.csv) on the source raster for visual review."""
import os, sys, numpy as np, pandas as pd
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__)); sys.argv = sys.argv[:1]
import reconstruct as R, checks as C
OUT = os.path.join(HERE, '..'); df = pd.read_csv(os.path.join(OUT, 'ipd.csv'))
img = Image.open(os.path.join(R.INP, 'figure.png')).convert('RGB'); dr = ImageDraw.Draw(img)
px = lambda t: R.X0 + t * (R.X36 - R.X0) / 36; py = lambda s: R.Y0 - s * (R.Y0 - R.Y1)
for g in 'AB':
    k = C.km(df[df.group == g]); pts = [(px(0), py(1))]; s = 1
    for t, v in k: pts += [(px(t), py(s)), (px(t), py(v))]; s = v
    pts.append((px(df[df.group == g].observed_time.max()), py(s)))
    dr.line(pts, fill=(0, 0, 0), width=1)
img.save(os.path.join(OUT, 'overlay_on_figure.png'))
img.crop((260, 160, 760, 520)).resize((1000, 720)).save(os.path.join(OUT, 'overlay_zoom_early.png'))
img.crop((1200, 560, 1720, 860)).resize((1040, 600)).save(os.path.join(OUT, 'overlay_zoom_tail.png'))
