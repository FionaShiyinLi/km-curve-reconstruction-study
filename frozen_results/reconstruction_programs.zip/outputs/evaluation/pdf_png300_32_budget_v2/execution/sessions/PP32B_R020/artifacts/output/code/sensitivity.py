"""Alternative allocation: censorings spread uniformly within each risk-table interval
(visible tick positions ignored). Writes ../sensitivity.csv and ../sensitivity_compare.json."""
import os, sys, json, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.argv = sys.argv[:1]
import reconstruct as R, checks as C
R.tick_times = lambda m: np.array([])
OUT = os.path.join(HERE, '..'); rows = []; logs = {}
for g in 'AB':
    m = R.measure(g); r, log, _ = R.reconstruct(g, m); assert len(r) == R.man['groups'][g]; rows += r; logs[g] = log
df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event']); df['observed_time'] = df.observed_time.round(4)
tmp = os.path.join(OUT, 'sensitivity.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'sensitivity.csv'))
prim = pd.read_csv(os.path.join(OUT, 'ipd.csv')); H = 35.9; cmp = {'horizon_months': H, 'arms': {}}
for g in 'AB':
    kp, ks = C.km(prim[prim.group == g]), C.km(df[df.group == g])
    cmp['arms'][g] = dict(
        events_primary=int(prim[prim.group == g].event.sum()), events_sens=int(df[df.group == g].event.sum()),
        S_primary={t: round(C.S_at(kp, t), 4) for t in [6, 12, 18, 24, 30, H]},
        S_sens={t: round(C.S_at(ks, t), 4) for t in [6, 12, 18, 24, 30, H]},
        area_primary=round(C.rmst(kp, H), 3), area_sens=round(C.rmst(ks, H), 3))
json.dump(cmp, open(os.path.join(OUT, 'sensitivity_compare.json'), 'w'), indent=1); print(json.dumps(cmp, indent=1))
