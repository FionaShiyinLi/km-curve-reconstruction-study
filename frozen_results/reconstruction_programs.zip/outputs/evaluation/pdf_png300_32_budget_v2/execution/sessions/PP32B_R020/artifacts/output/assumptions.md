# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 1778140504).
- Number-at-risk table read from the figure at 0, 6, ..., 36 months:
  A 1000/692/485/334/221/69/0; B 1000/635/521/422/342/148/0. These values are clearly legible, and I treat them as exact.
- The manifest gives no arm-level event totals, so I could not check against any. The reconstructed totals (A 805, B 643 events) are outputs of the method, not supplied values.
- No other auxiliary information was used. The seed is recorded in the code, but no step of the algorithm is stochastic.

## Curve measurement (`code/reconstruct.py`, `measure`)
- Calibration used the labelled axis ticks, located by pixel: x = 0 at column 269.5 and x = 36 at 1709.5 (40 px/month); S = 1.0 at row 179.5 and S = 0.0 at row 929.5 (750 px per unit). I applied no global rescaling. S(0) = 1 is the KM definition. Near the origin the orange curve (B) hides the start of the blue curve (A); I did not use those hidden pixels to renormalize anything.
- Arm pixels were identified by exact line color. B is drawn over A, so for A, any orange run touching a blue run is merged into it from 1 month onward (occlusion near the ~7.5-month crossing; see correction cycle 2 for the origin).
- For each column I recorded the top and bottom edges of the curve's run. Censor ticks extend about 8 px both above and below the line. Monotonicity was therefore imposed separately on the two edges: a running maximum from the left on the top edge, and a running minimum from the right on the bottom edge. The level after any drop is taken as bottom edge minus the 2-px half line width. Unlike a running minimum on a single level series, this does not carry an early misreading forward.
- Right-edge sentinel (correction cycle 1): the last few columns of each arm are a tick cluster, which the first version read as a false final drop (about 0.01). The fix caps the bottom edge beyond the last thin, tick-free run at that run's bottom edge.
- Origin remeasure (correction cycle 2, the last allowed): in the first version, merging orange into A near the origin picked up B's tick and early drops, putting 13 spurious A events at 0.0125 months. Now orange is merged into A only from 1 month onward (the crossing region). In addition, for t < 0.5 months only, a 15-17 px run is read as a censor tick centered on the line, so a tick at the origin is not read as a drop. Calibration elsewhere is unchanged. Effect: A now starts flat at S = 1 and has its first event at 0.16 months. In B, some early drops shift by about 0.1-0.25 months (for example, 11 events in the 0.39-month column where a tick and a steep drop coincide). All column residuals remain within tolerance.
- Measured series: `measured_A.csv`, `measured_B.csv`. Detected tick positions: `ticks_A.csv`, `ticks_B.csv`.

## Event and censoring allocation (`reconstruct`)
- This is my own interval-wise iteration in the style of Guyot et al., run between consecutive risk-table times. Within an interval, the number censored c is iterated until the reconstructed number at risk at the next table time equals the table value exactly (achieved for all 12 intervals; see `interval_log.json`).
- Events: at each pixel column, d = round(n_risk x (1 - S_measured / S_reconstructed_previous)). This lets one column hold several events. The value of d follows from the measured drop and the risk set; it is not assumed to be 1. With n ≈ 1000, one pixel (0.00133) is about one event, so individual event times early on are only resolved to about one pixel column (0.025 months).
- Censoring times: tick detection shows *visibility*, not multiplicity. Only 80 (A) and 98 (B) tick positions could be separated, against 195 and 357 censorings implied by the risk table. Where c is at least the number of ticks in an interval, each visible tick receives one censoring and the remainder is spread over the empirical distribution of tick positions. Where there are fewer censorings than ticks, an evenly spaced subset of ticks is used. An interval with no ticks would receive uniform spacing. This allocation is an assumption. What constrains it: interval censoring totals (from the risk table), tick locations, and the last visible tick (A 35.93, B 35.90 months).
- Displayed zero at risk at 36: every remaining participant is censored before 36 (maximum observed time A 35.925, B 35.904). No follow-up beyond the last visible mark was invented.
- Ties: an event and a censoring at the same time are ordered events first. Risk counts use observed_time >= t.

## Checks (`code/checks.py`, `checks.json`)
- The committed CSV is reloaded and a right-continuous KM step function is recomputed. It is compared with the measured curve at 18 named times (0.25 to 35.9 months, including the tail) and at all ~1440 pixel columns.
- Tolerance is 0.004 (about 3 px: the 2-px half line width plus 1 px of quantization).
- Results: maximum absolute residual 0.0019 (A) and 0.0014 (B); no column exceeds the tolerance; all 14 risk-table counts match exactly; n = 1000 per arm; event indicators are 0/1.
- Visual overlays: `overlay_on_figure.png`, `overlay_zoom_early.png`, `overlay_zoom_tail.png`.
- `checks.json` stores the SHA-256 of the final `ipd.csv`.

## Sensitivity (one alternative, `code/sensitivity.py`)
- Alternative assumption: censorings spread uniformly within each risk interval, ignoring tick positions. Output: `sensitivity.csv`; comparison: `sensitivity_compare.json`.
- At the common horizon of 35.9 months:
  - S_A: 0.1267 (primary) vs 0.1300 (alternative)
  - S_B: 0.2566 vs 0.2564
  - Area under the survival curve, A: 14.947 vs 14.951 months
  - Area under the survival curve, B: 18.042 vs 18.044 months
  - Events: A 805 vs 803; B 643 vs 636
- This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- Censoring times within intervals are not identified. Dense or overlapping ticks (especially from 24 to 36 months) hide how many censorings each mark represents.
- In steep early segments (B, first ~0.5 months), coincident ticks and drops make the event timing within a few columns ambiguous.
- Event times are quantized to pixel columns, and exact event multiplicity within a column cannot be recovered.
- Event totals could not be verified because none were supplied.
- The reconstruction is a feasible approximation consistent with the curve and the risk table. It is not a unique recovery of the original records.
