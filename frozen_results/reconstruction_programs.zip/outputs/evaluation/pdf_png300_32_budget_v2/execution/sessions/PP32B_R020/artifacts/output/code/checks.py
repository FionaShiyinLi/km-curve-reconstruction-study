"""Reload committed output/ipd.csv, recompute right-continuous KM, compare to measurements."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
sys.argv = sys.argv[:1]
import reconstruct as R

def km(df):
    ts = np.sort(df.observed_time[df.event == 1].unique()); S = 1.0; out = []
    for u in ts:
        n = (df.observed_time >= u).sum(); d = ((df.observed_time == u) & (df.event == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return np.array(out)
def S_at(k, t):  # right-continuous step
    i = np.searchsorted(k[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else k[i, 1]
def rmst(k, h):
    grid = np.r_[0, k[k[:, 0] < h, 0], h]; vals = [1.0] + [S_at(k, g) for g in grid[1:-1]]
    return float(np.sum(np.diff(grid) * np.array(vals)))

def main():
    path = os.path.join(OUT, 'ipd.csv'); raw = open(path, 'rb').read()
    df = pd.read_csv(path); res = {'ipd_sha256': hashlib.sha256(raw).hexdigest(), 'arms': {}}
    TOL = 0.004  # ~3 px: line half-width (2 px) + 1 px quantisation, in S units (1 px = 1/750)
    fig, ax = plt.subplots(figsize=(10, 6))
    for g in ['A', 'B']:
        d = df[df.group == g]; k = km(d); m = pd.read_csv(os.path.join(OUT, f'measured_{g}.csv'))
        a = {'n': int(len(d)), 'n_expected': R.man['groups'][g], 'events': int(d.event.sum()),
             'event_indicator_integer_01': bool(d.event.isin([0, 1]).all()),
             'supplied_event_total': 'unavailable (not in manifest)',
             'max_time': float(d.observed_time.max())}
        a['risk_table'] = []
        for t, nt in zip(R.RISK_T, R.RISK[g]):
            r = int((d.observed_time >= t).sum())
            a['risk_table'].append(dict(t=t, table=nt, recon=r, resid=r - nt, status='pass' if r == nt else 'fail'))
        a['survival'] = []
        for t in [0.25, 0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.9]:
            # measured value = column whose pixel centre is nearest t (row edge-derived level)
            j = int(np.argmin(np.abs(m.time - t))); sm = float(m.S_measured[j]); sr = float(S_at(k, m.time[j]))
            a['survival'].append(dict(t=round(float(m.time[j]), 4), measured=round(sm, 4), recon=round(sr, 4),
                                      resid=round(sr - sm, 4), status='pass' if abs(sr - sm) <= TOL else 'fail'))
        diffs = np.array([S_at(k, t) for t in m.time]) - m.S_measured.values
        a['all_columns'] = dict(n_cols=int(len(m)), max_abs_resid=round(float(np.abs(diffs).max()), 4),
                                mean_abs_resid=round(float(np.abs(diffs).mean()), 5), tolerance=TOL,
                                n_over_tol=int((np.abs(diffs) > TOL).sum()))
        a['rmst_35.9'] = round(rmst(k, 35.9), 3)
        res['arms'][g] = a
        ax.plot(m.time, m.S_measured, lw=3, alpha=.4, label=f'{g} measured')
        ax.step(np.r_[0, k[:, 0]], np.r_[1, k[:, 1]], where='post', lw=.8, label=f'{g} recon KM')
    res['tolerance_justification'] = '1 px = 0.00133 S; line 5 px thick; level read from bottom edge -2 px; tol ~3 px'
    ax.legend(); fig.savefig(os.path.join(OUT, 'overlay.png'), dpi=110)
    json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
    for g in res['arms']:
        a = res['arms'][g]; print(g, a['n'], a['events'], a['all_columns'], a['rmst_35.9'],
              [x['status'] for x in a['risk_table']], [(x['t'], x['resid']) for x in a['survival'] if x['status'] != 'pass'])
if __name__ == '__main__': main()
