"""Reconstruct participant-level (time, event) records from extracted KM curves.

Usage: python reconstruct.py [workdir_with_curve_jsons] [outdir] [--sensitivity]
Requires curve_A.json / curve_B.json produced by extract.py.
Algorithm (own implementation, Guyot-style interval balancing):
  * events: every drop between consecutive plateaus; d chosen as
    round(n_risk * (1 - S_measured_after / S_reconstructed_before)), minimum 1
    (a visible drop implies >= 1 event; d>1 when the drop size says so).
  * censorings: accepted visible ticks (with multiplicity 2 for ticks
    >= 5 px wide on a long plateau), plus, where the risk table requires more
    removals than ticks, extra censorings
    placed greedily in the inter-event gap (gap midpoint) that best reproduces
    the measured post-drop survival levels (primary, 'fit'), or spaced evenly
    over the interval as in Guyot et al.'s approach (sensitivity, --sensitivity).
  * n at risk at every risk-table time is forced to the published value.
"""
import sys, json, os, hashlib
import numpy as np

WORK = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "output/work"
OUT = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else "output"
SENS = "--sensitivity" in sys.argv
SEED = 1304099582
np.random.seed(SEED)  # no stochastic step is used; seed recorded per protocol

X0, X36 = 269.5, 1709.5
T_RISK = [0, 6, 12, 18, 24, 30, 36]
N_RISK = {"A": [100, 68, 52, 39, 25, 7, 0], "B": [100, 64, 57, 48, 38, 15, 0]}
N_TOTAL = {"A": 100, "B": 100}


def t_of(px):
    return (px - X0) / (X36 - X0) * 36.0


def load(g):
    d = json.load(open(os.path.join(WORK, f"curve_{g}.json")))
    # bands thicker than the ~4 px line are tick/drop overlaps, not KM levels
    pl = [p for p in d["plateaus"] if p["y_bot"] - p["y_top"] <= 6]
    # merge consecutive plateaus at the same level (gaps caused by overplotting/ticks)
    merged = []
    for p in sorted(pl, key=lambda p: p["x_start"]):
        if merged and abs(merged[-1]["y_c"] - p["y_c"]) < 2:
            merged[-1]["x_end"] = max(merged[-1]["x_end"], p["x_end"])
        else:
            merged.append(dict(p))
    # origin: B's first plateau is at S=1.0.  A's S=1.0 segment is hidden under
    # B's line; its first visible plateau (0.98) begins at px 272 and the drop
    # vertical is visible at px 270-271, i.e. a genuine early drop at ~0.025 mo.
    if merged[0]["s"] < 0.995:
        merged.insert(0, {"x_start": 269, "x_end": 272, "y_c": 179.5, "s": 1.0})
        first_drop_px = {1: 270.5}
    else:
        first_drop_px = {}
    events = []
    for i in range(1, len(merged)):
        a, b = merged[i - 1], merged[i]
        px = first_drop_px.get(i, (a["x_end"] + b["x_start"]) / 2)
        events.append({"t": t_of(px), "s_before": a["s"], "s_after": b["s"]})
    plat_len = {}
    ticks = []
    for tk in d["ticks"]:
        # attach tick to the plateau it sits on
        host = [p for p in pl if p["x_start"] - 2 <= tk["x_first"] and tk["x_last"] <= p["x_end"] + 2
                and abs(p["s"] - tk["s_plateau"]) < 0.002]
        L = max((p["x_end"] - p["x_start"] + 1) for p in host) if host else 0
        near_end = any(min(abs(tk["x_first"] - p["x_start"]), abs(tk["x_last"] - p["x_end"])) <= 4
                       for p in host)
        accept = tk["width"] >= 2 and L >= 10
        mult = 2 if (tk["width"] >= 5 and not near_end) else 1
        ticks.append({**tk, "host_len": L, "accepted": accept, "mult": mult if accept else 0})
    t_last = t_of(merged[-1]["x_end"] - 1.5)   # right end of the drawn curve
    return events, ticks, t_last


def km_sim(n0, evs, cens):
    """sequential KM through one interval; returns event list with d and n_end"""
    items = [(e["t"], 0, e) for e in evs] + [(c, 1, None) for c in cens]
    items.sort(key=lambda z: (z[0], z[1]))   # events before censorings at ties
    return items


def reconstruct(g, mode):
    events, ticks, t_last = load(g)
    tick_times = []
    for tk in ticks:
        tick_times += [tk["t"]] * tk["mult"]
    n = N_TOTAL[g]
    s_hat = 1.0
    recs, log = [], []
    for k in range(len(T_RISK) - 1):
        lo, hi = T_RISK[k], T_RISK[k + 1]
        hi_eff = min(hi, t_last)
        evs = [e for e in events if lo <= e["t"] < hi]
        tk_in = [t for t in tick_times if lo <= t < hi]
        target = N_RISK[g][k + 1]
        extra_pos = []
        status = "balanced"

        def simulate(xc):
            items = km_sim(n, evs, tk_in + xc)
            nr, sh, out, sse = n, s_hat, [], 0.0
            for (t, typ, e) in items:
                if typ == 0:
                    d = int(round(nr * (1 - e["s_after"] / sh)))
                    d = max(1, min(d, nr))
                    sh *= (1 - d / nr)
                    sse += (np.log(sh) - np.log(e["s_after"])) ** 2
                    out += [(t, 1)] * d
                    nr -= d
                elif nr > 0:
                    out.append((t, 0)); nr -= 1
            return out, nr, sh, sse

        # candidate positions for unseen censorings: midpoints of gaps between
        # successive drops/interval limits (never beyond the drawn curve end)
        cuts = sorted(set([lo] + [e["t"] for e in evs] + [hi_eff]))
        cand = [(a + b) / 2 for a, b in zip(cuts[:-1], cuts[1:]) if b > a]
        for it in range(200):
            if mode == "even":
                m = len(extra_pos)
                extra_pos = [lo + (j + 0.5) * (hi_eff - lo) / m for j in range(m)]
            out, nr, sh, sse = simulate(extra_pos)
            diff = nr - target
            if diff == 0:
                break
            if diff > 0:
                if mode == "even":
                    extra_pos = extra_pos + [0.0] * diff
                else:
                    best = min(cand, key=lambda c: (round(simulate(extra_pos + [c])[3], 10),
                                                    abs(c - (lo + hi_eff) / 2)))
                    extra_pos = extra_pos + [best]
            else:
                if extra_pos:
                    extra_pos = extra_pos[:max(0, len(extra_pos) + diff)]
                else:
                    status = f"conflict: {-diff} fewer at risk than table"
                    break
        extra = len(extra_pos)
        log.append({"interval": [lo, hi], "n_start": n, "events": sum(o[1] for o in out),
                    "visible_censor": len(tk_in), "extra_censor": extra, "extra_times": [round(x, 3) for x in extra_pos],
                    "log_sse": sse,
                    "n_end": nr, "table_n_end": target, "status": status})
        recs += out
        n, s_hat = nr, sh
    # anyone left after 36 (should be none, table says 0)
    return recs, log, ticks, events


def main():
    mode = "even" if SENS else "fit"
    rows, info = [], {}
    for g in ["A", "B"]:
        recs, log, ticks, events = reconstruct(g, mode)
        assert len(recs) == N_TOTAL[g], (g, len(recs))
        rows += [(g, round(t, 4), e) for (t, e) in recs]
        info[g] = {"intervals": log, "n_events": int(sum(e for _, e in recs)),
                   "ticks": ticks, "drops": events}
    name = "sensitivity.csv" if SENS else "ipd.csv"
    tmp = os.path.join(OUT, name + ".tmp")
    with open(tmp, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in rows:
            f.write(f"{g},{max(0.0, t):.4f},{e}\n")
    os.replace(tmp, os.path.join(OUT, name))
    json.dump(info, open(os.path.join(WORK, f"recon_log_{mode}.json"), "w"), indent=1, default=float)
    for g in info:
        print(g, "events", info[g]["n_events"])
        for L in info[g]["intervals"]:
            print("  ", L)


if __name__ == "__main__":
    main()
