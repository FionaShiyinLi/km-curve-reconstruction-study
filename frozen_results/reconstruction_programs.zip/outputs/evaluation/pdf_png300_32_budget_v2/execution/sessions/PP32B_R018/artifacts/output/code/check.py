"""Checks of committed CSV(s) against measured curve, risk table and sizes.

Usage: python check.py [workdir] [outdir]
Reloads output/ipd.csv (and sensitivity.csv if present), recomputes the
right-continuous KM step function per arm and writes output/checks.json.
"""
import sys, json, os, hashlib
import numpy as np
import pandas as pd

WORK = sys.argv[1] if len(sys.argv) > 1 else "output/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
X0, X36 = 269.5, 1709.5
T_RISK = [0, 6, 12, 18, 24, 30, 36]
N_RISK = {"A": [100, 68, 52, 39, 25, 7, 0], "B": [100, 64, 57, 48, 38, 15, 0]}
N_TOTAL = {"A": 100, "B": 100}
TOL_S = 0.006   # ~4.5 px: 4 px line width + 0.5 px rounding of the band centre
HORIZON = 35.0  # common supported horizon: both drawn curves extend past 35.2


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; steps = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; steps.append((u, s))
    return steps


def S_at(steps, x):  # right-continuous
    s = 1.0
    for u, v in steps:
        if u <= x:
            s = v
        else:
            break
    return s


def rmst(steps, h):
    area, last_t, last_s = 0.0, 0.0, 1.0
    for u, v in steps:
        if u > h:
            break
        area += last_s * (u - last_t); last_t, last_s = u, v
    return area + last_s * (h - last_t)


def main():
    path = os.path.join(OUT, "ipd.csv")
    raw = open(path, "rb").read()
    df = pd.read_csv(path)
    out = {"csv": "output/ipd.csv", "sha256": hashlib.sha256(raw).hexdigest(),
           "tolerance_S": TOL_S,
           "tolerance_note": "measured plateau centre +/- half line width (2 px) + rounding; 750 px per unit S",
           "columns_ok": list(df.columns) == ["group", "observed_time", "event"],
           "arms": {}}
    for g in ["A", "B"]:
        d = df[df.group == g]
        steps = km(d)
        arm = {"n": int(len(d)), "n_expected": N_TOTAL[g], "n_pass": len(d) == N_TOTAL[g],
               "event_integer_01": bool(d.event.isin([0, 1]).all()),
               "times_finite_nonneg": bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
               "n_events": int(d.event.sum()), "n_censored": int((d.event == 0).sum()),
               "supplied_event_total": "unavailable (manifest gives none)"}
        rk = []
        for t, nr in zip(T_RISK, N_RISK[g]):
            c = int((d.observed_time >= t).sum())
            rk.append({"t": t, "table": nr, "reconstructed": c, "residual": c - nr,
                       "status": "pass" if c == nr else "fail"})
        arm["risk_table"] = rk
        cv = json.load(open(os.path.join(WORK, f"curve_{g}.json")))
        cmp_ = []
        for p in cv["plateaus"]:
            if p["x_end"] - p["x_start"] + 1 < 10 or p["y_bot"] - p["y_top"] > 6:
                continue
            xm = (p["x_start"] + p["x_end"]) / 2
            tm = (xm - X0) / (X36 - X0) * 36
            r = S_at(steps, tm)
            cmp_.append({"t": round(tm, 3), "measured": round(p["s"], 4), "reconstructed": round(r, 4),
                         "residual": round(r - p["s"], 4),
                         "status": "pass" if abs(r - p["s"]) <= TOL_S else "fail"})
        arm["curve_comparison"] = cmp_
        arm["curve_max_abs_residual"] = max(abs(c["residual"]) for c in cmp_)
        arm["curve_n_fail"] = sum(c["status"] == "fail" for c in cmp_)
        tail = cmp_[-1]
        arm["tail_check"] = {**tail, "max_observed_time": float(d.observed_time.max()),
                             "last_record_is_censor": bool(d.sort_values("observed_time").event.iloc[-1] == 0)}
        arm["S_horizon"] = round(S_at(steps, HORIZON), 4)
        arm["RMST_horizon"] = round(rmst(steps, HORIZON), 4)
        out["arms"][g] = arm
    sp = os.path.join(OUT, "sensitivity.csv")
    if os.path.exists(sp):
        ds = pd.read_csv(sp); sens = {"csv": "output/sensitivity.csv", "horizon_months": HORIZON,
                                      "assumption": "unseen censorings spaced evenly over each risk interval"}
        for g in ["A", "B"]:
            st = km(ds[ds.group == g])
            sens[g] = {"S_horizon_primary": out["arms"][g]["S_horizon"],
                       "S_horizon_sensitivity": round(S_at(st, HORIZON), 4),
                       "RMST_primary": out["arms"][g]["RMST_horizon"],
                       "RMST_sensitivity": round(rmst(st, HORIZON), 4),
                       "n_events_sensitivity": int(ds[ds.group == g].event.sum()),
                       "risk_table_sensitivity": [int((ds[ds.group == g].observed_time >= t).sum()) for t in T_RISK]}
        out["sensitivity"] = sens
    json.dump(out, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
    for g in out["arms"]:
        a = out["arms"][g]
        print(g, a["n"], a["n_events"], [r["reconstructed"] for r in a["risk_table"]],
              "maxres", a["curve_max_abs_residual"], "nfail", a["curve_n_fail"], "of", len(a["curve_comparison"]),
              "S35", a["S_horizon"], "RMST35", a["RMST_horizon"])
        for c in a["curve_comparison"]:
            if c["status"] == "fail": print("   FAIL", c)
    if "sensitivity" in out: print(json.dumps(out["sensitivity"]))
    print(out["sha256"])


if __name__ == "__main__":
    main()
