#!/bin/sh
# Usage: sh output/code/run_all.sh [path/to/figure.png]   (run from the work directory)
set -e
FIG=${1:-../input/figure.png}
mkdir -p output/work
python3 output/code/extract.py "$FIG" output/work
python3 output/code/reconstruct.py output/work output
python3 output/code/reconstruct.py output/work output --sensitivity
python3 output/code/check.py output/work output
python3 output/code/overlay.py "$FIG" output
