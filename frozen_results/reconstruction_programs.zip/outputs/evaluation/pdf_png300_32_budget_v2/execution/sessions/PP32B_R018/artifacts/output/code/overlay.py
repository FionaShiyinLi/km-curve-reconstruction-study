"""Overlay reconstructed KM (from committed CSV) on the source figure for review."""
import sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
FIG = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
X0, X36, Y1, Y0 = 269.5, 1709.5, 179.5, 929.5
im = np.asarray(Image.open(FIG).convert("RGB"))
df = pd.read_csv(f"{OUT}/ipd.csv")
fig, ax = plt.subplots(figsize=(12, 9), dpi=150)
ax.imshow(im)
for g, c in [("A", "black"), ("B", "magenta")]:
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    xs, ys, s = [0.0], [1.0], 1.0
    for u in np.unique(t[e == 1]):
        s *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); xs.append(u); ys.append(s)
    xs.append(t.max()); ys.append(s)
    ax.step(X0 + np.array(xs) / 36 * (X36 - X0), Y0 - np.array(ys) * (Y0 - Y1), where="post", color=c, lw=0.6)
    cz = t[e == 0]
    sc = [ys[max(0, np.searchsorted(xs[:-1], u, side="right") - 1)] for u in cz]
    ax.plot(X0 + cz / 36 * (X36 - X0), Y0 - np.array(sc) * (Y0 - Y1), "x", color=c, ms=3)
ax.set_xlim(250, 1720); ax.set_ylim(950, 160); ax.axis("off")
fig.savefig(f"{OUT}/work/overlay.png", bbox_inches="tight")
