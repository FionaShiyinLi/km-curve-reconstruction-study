# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster, Kaplan–Meier (KM) curves for groups A and B, with a number-at-risk table).
- `../input/manifest.json`: n = 100 per group, time unit months, code seed 1304099582. The manifest supplies **no arm-specific event totals**. Event-total checks are therefore marked unavailable. This does not mean that zero events were reported.
- Risk table (read visually, all digits clear): at months 0/6/12/18/24/30/36, A = 100/68/52/39/25/7/0 and B = 100/64/57/48/38/15/0.

## Measurement (`code/extract.py`)
- **Calibration** uses the black axis tick marks. The x-axis ticks sit at px 269.5 + 240k (k = 0..6, i.e., 0–36 months, 40 px per month). The y-axis ticks sit at px 929.5 − 150j (S = 0, 0.2, …, 1.0; 750 px per unit). The mapping is linear, and no global rescaling was applied to either arm.
- **Curve pixels** are selected by RGB distance < 60 from the line colors (A blue, B orange). A plateau is a horizontal run of at least 7 px. Its level is the center of the modal 4-px line band. Bands thicker than 6 px are overlaps between a tick and a drop vertical, and are discarded as levels.
- **Origin:** B starts on a plateau at exactly S = 1.000. A's S = 1 segment is hidden under B's line, which is drawn on top. A's drop vertical is visible at px 270–271, and A's first plateau (0.980) starts at px 272. This is treated as a genuine early drop of 2 events at about 0.025 months, anchored at S = 1 by definition. The curve was not rescaled and no flat start was forced.
- **Censor ticks** are vertical runs extending at least 5 px both above and below a plateau band (drop verticals extend on one side only). Accepted ticks need a width of at least 2 px on a plateau of at least 10 px. The zoomed inspection (`work/zoom1.png`) showed that width-1 hits and hits on very short plateaus within dense drop runs are artifacts of adjacent drop verticals (A: 1.34, 1.54, 11.59, 15.41, 22.82, 22.91; B: 0.41, 0.55, 1.45, 1.53, 5.54, 25.21, 27.49 months).
- **Tick multiplicity:** a tick 5–6 px wide that does not sit at a plateau end is counted as 2 overlapping marks (A 24.09 and 29.32; B 29.84, 30.99 and 31.77). Width shows only whether a mark is visible, not how many marks coincide. Exactly coincident ticks cannot be distinguished, and the risk table absorbs such hidden censorings (next section).
- Extracted observations are saved in `work/curve_A.json` and `work/curve_B.json` (plateaus and ticks), with `work/raw_pixels.json` as the raw pixel data.

## Reconstruction (`code/reconstruct.py`, own implementation; no KM-to-IPD package)
- **Events:** each drop between consecutive plateaus is placed at the pixel midpoint of the drop vertical. The number of events is d = round(n_risk × (1 − S_measured_after / S_reconstructed_before)), with a minimum of 1. The ratio is taken against the running reconstructed curve, so rounding errors do not accumulate. Every drop is allowed d > 1. Several early drops of about 0.02 correspond to d = 2, and d is never assumed to be 1.
- **Censorings:** accepted ticks are censorings at the tick time. Within each risk interval [t_k, t_{k+1}), the number at risk at t_{k+1} is forced to match the table. Where visible ticks are too few, additional unseen censorings are added. In the primary analysis, each unseen censoring is placed greedily at the midpoint of the inter-event gap that minimizes the squared log error of the reconstructed post-drop levels against the measured ones. Ties are broken toward the interval center.
  - A: 1 unseen censoring in [0, 6) at 2.375 months.
  - B: 2 unseen censorings in [24, 30) at 27.056 and 29.113 months, and 1 in [30, 36) at 34.275 months. B's drop at 33.3 months (0.326 → 0.261, ratio 0.80) requires exactly 5 at risk, which rules out placing that censoring before 33.3 months.
  - No interval required removing a visible tick. The table count never conflicted with the ticks.
- **Ties:** events are ordered before censorings. No record lies beyond the drawn end of each curve (A 35.41, B 35.29 months), and none lies at t = 36, where both arms have 0 at risk.
- The seed 1304099582 is set, although no step is stochastic.
- **Result:** A has 77 events and 23 censorings; B has 63 events and 37 censorings.

## Verification (`code/check.py` → `checks.json`)
The check script reloads the committed `ipd.csv` and recomputes the right-continuous KM step function.
- Arm sizes are 100/100, event indicators are integers in {0, 1}, and times are finite and nonnegative.
- The count of records with time ≥ t equals the risk table at all 7 times in both arms.
- The recomputed KM is compared with every measured plateau of at least 10 px at its midpoint time (A 52 points, B 38 points), including the tails (A 34.0 months, S = 0.149; B 34.3 months, S = 0.261). All comparisons pass with a tolerance of 0.006. The tolerance allows 4.5 px: 2 px for half the line width plus rounding of the band center. The maximum absolute residual is 0.0021 in A and 0.0005 in B.
- `work/overlay.png` overlays the reconstructed curves on the source figure.
- These checks establish agreement with the figure. They do not establish that individual records are correct.

## Sensitivity (`sensitivity.csv`)
- **Assumption:** the unseen censorings (the same number per interval) are spaced evenly across each risk interval instead of being placed by curve fit. Visible ticks and events are unchanged.
- **Common supported horizon:** 35 months.
  - A: S(35) = 0.149 (primary) vs 0.149 (sensitivity); restricted mean survival time (RMST) to 35 months = 15.97 vs 15.98.
  - B: S(35) = 0.261 vs 0.244; RMST = 18.64 vs 18.60.
- B's evenly placed censoring at 32.6 months falls before the 33.3-month drop, which makes that drop inconsistent with the measured level. This is why the curve-informed placement was chosen as primary. Only one alternative was run. It is not a confidence interval and does not bound reconstruction error.

## Unresolved limitations
- Exact censoring times of unseen censorings (A: 1; B: 3) are not identified. Censoring marks that exactly coincide, whether with each other or with drops, cannot be counted from the raster.
- Event times are resolved only to about 0.025 months (1 px). Tied or near-tied events within a raster column are pooled into a single time.
- In the overlap region (0–4 months), parts of A's line are hidden under B's line. Levels there are inferred from visible fragments. A thin (1-px) visible band gives a slightly biased level, which the integer rounding of d absorbs.
- The flat tails do not identify the censoring distribution or the length of follow-up beyond the last drawn mark. No follow-up beyond the drawn curves was invented.

## Reproduce
From the work directory: `sh output/code/run_all.sh ../input/figure.png`
