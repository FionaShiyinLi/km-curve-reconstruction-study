"""Pixel extraction of KM step curves and censor ticks from figure.png.

Usage: python extract.py [path/to/figure.png] [outdir]
Calibration (from black axis tick marks, see assumptions.md):
  x: 0 months at px 269.5, 36 months at px 1709.5 (ticks every 240 px = 6 months)
  y: S=1.0 at px 179.5, S=0.0 at px 929.5 (ticks every 150 px = 0.2)
Line width in the raster is ~4 px; censor ticks are ~3 px wide, ~17 px tall.
Outputs <outdir>/curve_<g>.json with horizontal levels, drops and ticks.
"""
import sys, json
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output/work"
X0, X36, Y1, Y0 = 269.5, 1709.5, 179.5, 929.5
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
MINRUN = 7      # horizontal run length (px) that defines a plateau
TICK_EXT = 5    # px a tick must extend beyond the plateau band


def t_of(px):
    return (px - X0) / (X36 - X0) * 36.0


def s_of(py):
    return (Y0 - py) / (Y0 - Y1)


def mask_for(a, rgb, tol=60):
    return np.sqrt(((a - np.array(rgb)) ** 2).sum(2)) < tol


def runs(idx):
    """group sorted integer indices into contiguous runs"""
    out = []
    for i in idx:
        if out and i == out[-1][-1] + 1:
            out[-1].append(i)
        else:
            out.append([i])
    return out


def analyse(a, g):
    m = mask_for(a, COLORS[g])
    m[:150, :] = False
    m[936:, :] = False
    m[:, :268] = False
    m[:, 1714:] = False
    H, W = m.shape
    # plateau mask: pixel belongs to a horizontal run >= MINRUN
    hm = np.zeros_like(m)
    for y in range(150, 936):
        for r in runs(np.where(m[y])[0]):
            if len(r) >= MINRUN:
                hm[y, r[0]:r[-1] + 1] = True
    # per column plateau bands
    band = {}
    for x in range(268, 1714):
        rs = runs(np.where(hm[:, x])[0])
        # keep bands of thickness 2..6 (line), wider = merged, keep anyway
        band[x] = [(r[0], r[-1]) for r in rs]
    # plateau segments: follow bands column-wise
    segs = []  # [y_top, y_bot, x_start, x_end]
    for x in range(268, 1714):
        for (t, b) in band[x]:
            hit = None
            for s in segs:
                if s[3] == x - 1 and abs((s[0] + s[1]) / 2 - (t + b) / 2) < 1.5:
                    hit = s; break
            if hit:
                hit[3] = x
                hit[0] = min(hit[0], t); hit[1] = max(hit[1], b)
            else:
                segs.append([t, b, x, x])
    segs = [s for s in segs if s[3] - s[2] + 1 >= MINRUN]
    segs.sort(key=lambda s: s[2])
    # a band thicker than line (e.g. tick merged) -> centre from mode thickness
    # level per segment: use most common (top,bottom) among columns
    for s in segs:
        tops = []; bots = []
        for x in range(s[2], s[3] + 1):
            for (t, b) in band[x]:
                if s[0] <= t and b <= s[1]:
                    tops.append(t); bots.append(b)
        vals, cnt = np.unique(np.array(tops) * 10000 + np.array(bots), return_counts=True)
        k = vals[np.argmax(cnt)]
        s.append(k // 10000); s.append(k % 10000)
    # ticks: a vertical run that extends >= TICK_EXT px both above and below the
    # band of a plateau covering that column (drop verticals extend on one side only)
    ticks_cols = []
    for x in range(270, 1712):
        col = np.where(m[:, x])[0]
        if len(col) == 0:
            continue
        near = [s for s in segs if s[2] - 2 <= x <= s[3] + 2]
        for r in runs(col):
            for s in near:
                if r[0] <= s[4] - TICK_EXT and r[-1] >= s[5] + TICK_EXT:
                    ticks_cols.append((x, r[0], r[-1], s[4], s[5]))
                    break
    tick_groups = []
    for tc in ticks_cols:
        if tick_groups and tc[0] <= tick_groups[-1][-1][0] + 1:
            tick_groups[-1].append(tc)
        else:
            tick_groups.append([tc])
    ticks = []
    for tg in tick_groups:
        xs = [c[0] for c in tg]
        ticks.append({"x_first": xs[0], "x_last": xs[-1], "width": len(xs),
                      "t": t_of(np.mean(xs)),
                      "y_top": min(c[1] for c in tg), "y_bot": max(c[2] for c in tg),
                      "s_plateau": s_of((tg[0][3] + tg[0][4]) / 2)})
    plateaus = [{"x_start": s[2], "x_end": s[3], "y_top": int(s[4]), "y_bot": int(s[5]),
                 "y_c": (s[4] + s[5]) / 2, "s": s_of((s[4] + s[5]) / 2),
                 "t_start": t_of(s[2]), "t_end": t_of(s[3])} for s in segs]
    return plateaus, ticks


def main():
    a = np.asarray(Image.open(FIG).convert("RGB")).astype(int)
    for g in COLORS:
        pl, tk = analyse(a, g)
        json.dump({"plateaus": pl, "ticks": tk}, open(f"{OUT}/curve_{g}.json", "w"), indent=1,
                  default=float)
        print(g, "plateaus", len(pl), "ticks", len(tk))


if __name__ == "__main__":
    main()
