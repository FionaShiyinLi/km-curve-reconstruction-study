"""Reload committed CSV, recompute right-continuous KM, compare with measurements.

Usage: python checks.py [--outdir DIR] [--csv ipd.csv] [--sens sensitivity.csv]
"""
import argparse, hashlib, json, os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 689, 475, 336, 222, 71, 0], "B": [1000, 676, 544, 438, 358, 165, 0]}
N = {"A": 1000, "B": 1000}
TOL_S = 0.005  # ~ curve line thickness (4 px = 0.0053) ; set before comparing
CHECK_T = [0.25, 0.5, 1, 2, 3, 4.5, 6, 7.5, 9, 10.5, 12, 15, 18, 21, 24, 26, 28, 30, 32, 34, 35, 35.8]


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1])
    S, s = [], 1.0
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; S.append(s)
    return ut, np.array(S)


def km_at(ut, S, x):  # right-continuous step evaluation
    i = np.searchsorted(ut, x, side="right") - 1
    return 1.0 if i < 0 else float(S[i])


def rmst(ut, S, tau):
    pts = np.concatenate([[0], ut[ut < tau], [tau]])
    vals = np.concatenate([[1.0], S[ut < tau]])
    return float(np.sum(np.diff(pts) * vals))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default=os.path.join(HERE, ".."))
    p.add_argument("--csv", default="ipd.csv")
    p.add_argument("--sens", default="sensitivity.csv")
    a = p.parse_args()
    path = os.path.join(a.outdir, a.csv)
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    df = pd.read_csv(path)
    res = dict(csv=a.csv, sha256=sha, columns=list(df.columns),
               tolerance_S=TOL_S,
               tolerance_note="4-px line thickness = 0.0053 in S; centroid/timing error ~1 px/column",
               supplied_event_totals="unavailable (not in manifest)", arms={})
    km_by = {}
    for g in ("A", "B"):
        d = df[df.group == g]
        ut, S = km(d); km_by[g] = (ut, S)
        meas = pd.read_csv(os.path.join(a.outdir, "extraction", f"curve_{g}.csv"))
        ok = meas.S_raw.notna() & (meas.occluded.fillna(1) == 0)
        mt, ms = meas.t[ok].values, meas.S_raw[ok].values
        comps = []
        for x in CHECK_T:
            near = np.abs(mt - x) <= 0.05
            if not near.any():
                comps.append(dict(t=x, status="unavailable (occluded/no pixels)")); continue
            m = float(np.median(ms[near])); r = km_at(ut, S, x)
            comps.append(dict(t=x, measured=round(m, 4), reconstructed=round(r, 4),
                              residual=round(r - m, 4), status="pass" if abs(r - m) <= TOL_S else "fail"))
        # overlap zones: primary measurement excluded these columns; compare with
        # the lower-confidence core-intrusion remeasurement (not used in fitting)
        mc = pd.read_csv(os.path.join(a.outdir, "extraction", f"curve_{g}_core.csv"))
        okc = mc.S_raw.notna() & (mc.occluded.fillna(1) == 0)
        sup = []
        for x in [0.25, 0.5, 0.75, 1.0, 1.25, 6.0, 6.5, 7.0, 7.5]:
            near = (np.abs(mc.t - x) <= 0.05) & okc
            if not near.any():
                sup.append(dict(t=x, status="unavailable")); continue
            m = float(np.median(mc.S_raw[near])); r = km_at(ut, S, x)
            sup.append(dict(t=x, measured_core_rule=round(m, 4), reconstructed=round(r, 4), residual=round(r - m, 4),
                            status="consistent (lower-confidence measurement)" if abs(r - m) <= TOL_S else "unresolved"))
        allres = np.array([km_at(ut, S, x) for x in mt]) - ms
        risk = []
        for tt, nn in zip(RISK_T, RISK[g]):
            c = int((d.observed_time >= tt).sum())
            risk.append(dict(t=tt, table=nn, reconstructed=c, residual=c - nn, status="pass" if c == nn else "fail"))
        res["arms"][g] = dict(
            n=int(len(d)), n_expected=N[g], n_status="pass" if len(d) == N[g] else "fail",
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            max_time=float(d.observed_time.max()), survival_checks=comps,
            overlap_zone_supplementary=sup,
            all_columns=dict(n=int(len(mt)), max_abs_resid=round(float(np.abs(allres).max()), 4),
                             mean_abs_resid=round(float(np.abs(allres).mean()), 5),
                             frac_within_tol=round(float((np.abs(allres) <= TOL_S).mean()), 4)),
            risk_table=risk)
    sp = os.path.join(a.outdir, a.sens)
    if os.path.exists(sp):
        sd = pd.read_csv(sp)
        tau = float(min(df.groupby("group").observed_time.max().min(), sd.groupby("group").observed_time.max().min()))
        tau = np.floor(tau * 10) / 10
        cmp = dict(common_horizon=tau)
        for g in ("A", "B"):
            u2, S2 = km(sd[sd.group == g]); u1, S1 = km_by[g]
            cmp[g] = dict(S_primary=round(km_at(u1, S1, tau), 4), S_sensitivity=round(km_at(u2, S2, tau), 4),
                          RMST_primary=round(rmst(u1, S1, tau), 3), RMST_sensitivity=round(rmst(u2, S2, tau), 3),
                          S_at_12_primary=round(km_at(u1, S1, 12), 4), S_at_12_sens=round(km_at(u2, S2, 12), 4),
                          S_at_24_primary=round(km_at(u1, S1, 24), 4), S_at_24_sens=round(km_at(u2, S2, 24), 4))
        res["sensitivity_comparison"] = cmp
    else:
        res["sensitivity_comparison"] = "not run"
    json.dump(res, open(os.path.join(a.outdir, "checks.json"), "w"), indent=1)
    for g in ("A", "B"):
        r = res["arms"][g]
        print(g, r["n"], r["events"], r["all_columns"], [c["status"] for c in r["risk_table"]])
        for c in r["survival_checks"]:
            print("  ", c)
    print(res["sensitivity_comparison"])


if __name__ == "__main__":
    main()
