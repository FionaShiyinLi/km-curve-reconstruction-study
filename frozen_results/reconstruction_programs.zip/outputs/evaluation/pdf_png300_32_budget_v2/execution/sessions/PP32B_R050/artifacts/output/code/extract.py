"""Measure the two KM curves and censor ticks from the raster figure.

Usage: python extract.py [--input DIR] [--outdir DIR]
Defaults resolve relative to this file: input = ../../../input, outdir = ..
Writes curve_A.csv, curve_B.csv, ticks_A.csv, ticks_B.csv, calibration.json.
"""
import argparse, json, os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))


def calibrate(im):
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    dark = (r < 100) & (g < 100) & (b < 100)
    # y ticks: short dark horizontal marks left of the y axis
    ys = np.where(dark[150:940, 258:267].sum(1) > 5)[0] + 150
    xs = np.where(dark[932:945, 250:1720].sum(0) > 5)[0] + 250

    def centers(v):
        groups, cur = [], [v[0]]
        for a in v[1:]:
            if a - cur[-1] <= 1:
                cur.append(a)
            else:
                groups.append(cur); cur = [a]
        groups.append(cur)
        # continuous coordinate of mark centre (pixel i spans [i, i+1))
        return [float(np.mean(gp)) + 0.5 for gp in groups]

    yc, xc = centers(ys), centers(xs)
    ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
    xlab = [0, 6, 12, 18, 24, 30, 36]
    assert len(yc) == 6 and len(xc) == 7, (yc, xc)
    ay = np.polyfit(yc, ylab, 1)   # S = ay0*y + ay1
    ax = np.polyfit(xc, xlab, 1)   # t = ax0*x + ax1
    res_y = np.array(ylab) - np.polyval(ay, yc)
    res_x = np.array(xlab) - np.polyval(ax, xc)
    return dict(y_tick_centres=yc, x_tick_centres=xc, S_fit=list(ay), t_fit=list(ax),
                max_abs_resid_S=float(np.abs(res_y).max()),
                max_abs_resid_t=float(np.abs(res_x).max()))


def colour_weights(im):
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    # tab:blue (31,119,180), tab:orange (255,127,14); antialiased blends with white
    wb = np.clip((b - r) / (180 - 31), 0, 1) * ((b > g) & (b - r > 25))
    wo = np.clip((r - b) / (255 - 14), 0, 1) * ((r > g) & (r - b > 35))
    return wb, wo


def measure(w, w_other, cal, x0, x1, row0=170, row1=936):
    """Per-column line centre (subpixel) + tick flags for one arm."""
    ay, ax = cal["S_fit"], cal["t_fit"]
    out = []
    for x in range(x0, x1 + 1):
        col = w[row0:row1, x]
        rows = np.where(col > 0.35)[0]
        if len(rows) == 0:
            out.append((x, np.nan, np.nan, 0, 0, 0)); continue
        med = np.median(rows)
        lo, hi = int(med) - 3, int(med) + 4
        seg = col[lo:hi]
        idx = np.arange(lo, hi)
        yc = (seg * idx).sum() / seg.sum() + row0 + 0.5
        # occlusion: other colour anywhere within the tick half-height (8.5 px)
        # of the line; a partially covered tick biases the median (seen at B px 288)
        oth_wide = w_other[row0 + int(med) - 10: row0 + int(med) + 11, x].max() > 0.35
        # other colour inside this arm's own 4-px core => this arm is under it here
        ic0 = int(round(yc - 0.5))
        oth_core = w_other[ic0 - 1: ic0 + 3, x].max() > 0.35
        oth = (oth_wide, oth_core)
        # tick flag: strong colour both well above and well below the line core
        ic = int(round(yc - 0.5))
        up = (w[ic - 8:ic - 3, x] > 0.35).sum()
        dn = (w[ic + 4:ic + 9, x] > 0.35).sum()
        tick = int(up >= 3 and dn >= 3)
        span = int(rows.max() - rows.min() + 1)
        out.append((x, yc, oth, tick, span, 1))
    return out


def finish(out, cal, lower_layer):
    """Occlusion flag: wide rule for the arm drawn underneath, core rule otherwise."""
    ay, ax = cal["S_fit"], cal["t_fit"]
    rows = []
    for (x, yc, oth, tick, span, pres) in out:
        if pres == 0:
            rows.append((x, np.nan, np.nan, 0, 0, 0)); continue
        rows.append((x, yc, float(oth[0] if lower_layer else oth[1]), tick, span, 1))
    out = rows
    arr = np.array(out, dtype=float)
    t = np.polyval(ax, arr[:, 0] + 0.5)
    S = np.polyval(ay, arr[:, 1])
    return arr, t, S


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", default=os.path.join(HERE, "..", "..", "..", "input"))
    p.add_argument("--outdir", default=os.path.join(HERE, ".."))
    a = p.parse_args()
    im = np.asarray(Image.open(os.path.join(a.input, "figure.png")).convert("RGB")).astype(float)
    cal = calibrate(im)
    wb, wo = colour_weights(im)
    x_axis = int(round(cal["x_tick_centres"][0]))
    x_end = int(round(cal["x_tick_centres"][-1]))
    wdir = os.path.join(a.outdir, "extraction"); os.makedirs(wdir, exist_ok=True)
    json.dump(cal, open(os.path.join(wdir, "calibration.json"), "w"), indent=1)
    raw = {}
    for g, w, wother in (("A", wb, wo), ("B", wo, wb)):
        raw[g] = measure(w, wother, cal, x_axis + 1, x_end + 5)
    # z-order from data: count columns where the other colour intrudes on each core
    intr = {g: sum(1 for o in raw[g] if o[5] and o[2][1]) for g in raw}
    lower = max(intr, key=intr.get)
    cal["core_intrusion_columns"] = intr; cal["lower_layer_arm"] = lower
    json.dump(cal, open(os.path.join(wdir, "calibration.json"), "w"), indent=1)
    for g in ("A", "B"):
        arr, t, S = finish(raw[g], cal, g == lower)
        with open(os.path.join(wdir, f"curve_{g}.csv"), "w") as f:
            f.write("px,t,S_raw,occluded,tick,span,present\n")
            for row, tt, ss in zip(arr, t, S):
                f.write(f"{int(row[0])},{tt:.4f},{ss:.5f},{int(row[2]) if row[2]==row[2] else ''},{int(row[3])},{int(row[4])},{int(row[5])}\n")
        # supplementary (checks only): core-intrusion rule for both arms
        arr2, t2, S2 = finish(raw[g], cal, False)
        with open(os.path.join(wdir, f"curve_{g}_core.csv"), "w") as f:
            f.write("px,t,S_raw,occluded\n")
            for row, tt, ss in zip(arr2, t2, S2):
                f.write(f"{int(row[0])},{tt:.4f},{ss:.5f},{int(row[2]) if row[2]==row[2] else ''}\n")
    print(json.dumps(cal, indent=1))


if __name__ == "__main__":
    main()
