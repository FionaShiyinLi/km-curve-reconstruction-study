"""Reconstruct IPD from measured KM curves (output of extract.py) + risk table.

Usage: python reconstruct.py [--outdir DIR] [--censor-mode ticks|uniform] [--out FILE]
No stochastic step is used; the supplied seed is set and recorded anyway.
"""
import argparse, json, os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 1643789789
TICK_W = 3  # modal width (px) of an isolated censor tick, measured by extract.py
PX_PER_MONTH = 40.0
X0 = 270.0

# Risk table read from the figure (times in months)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 689, 475, 336, 222, 71, 0],
        "B": [1000, 676, 544, 438, 358, 165, 0]}
N = {"A": 1000, "B": 1000}


def pava_decreasing(y, w):
    """Weighted isotonic (non-increasing) regression by pool-adjacent-violators."""
    v, ww, cnt = [], [], []
    for yi, wi in zip(-np.asarray(y), w):
        v.append(yi); ww.append(wi); cnt.append(1)
        while len(v) > 1 and v[-2] > v[-1]:
            tw = ww[-2] + ww[-1]
            v[-2] = (v[-2] * ww[-2] + v[-1] * ww[-1]) / tw
            ww[-2] = tw; cnt[-2] += cnt[-1]
            v.pop(); ww.pop(); cnt.pop()
    return -np.repeat(v, cnt)


def load_curve(wdir, g):
    d = pd.read_csv(os.path.join(wdir, f"curve_{g}.csv"))
    ok = d.S_raw.notna() & (d.occluded.fillna(1) == 0)
    # tick columns carry the vertical tick; centre estimate is still symmetric
    tv = np.concatenate([[0.0], d.t[ok].values])
    sv = np.concatenate([[1.0], d.S_raw[ok].values])
    wv = np.concatenate([[1e3], np.ones(ok.sum())])  # S(0)=1 by definition
    fit = pava_decreasing(sv, wv)
    fit = np.minimum(fit, 1.0)
    last_px = int(d.px[d.present == 1].max())
    grid_px = np.arange(int(X0) + 1, last_px + 1)
    grid_t = (grid_px - X0) / PX_PER_MONTH  # left edge of column = step location
    t_ctr = (grid_px + 0.5 - X0) / PX_PER_MONTH
    S = np.interp(t_ctr, tv, fit)
    # tick runs -> censor mark positions (a run wider than one tick = several marks)
    tk = d.set_index("px").tick.reindex(grid_px).fillna(0).values.astype(int)
    marks = []
    i = 0
    while i < len(tk):
        if tk[i]:
            j = i
            while j + 1 < len(tk) and tk[j + 1]:
                j += 1
            w = j - i + 1
            k = max(1, int(round(w / TICK_W)))
            ctr = np.linspace(grid_px[i] + (w / k) / 2, grid_px[j] + 1 - (w / k) / 2, k)
            marks += list((ctr - X0) / PX_PER_MONTH)
            i = j + 1
        else:
            i += 1
    return grid_t, S, np.array(marks), dict(tv=tv, raw=sv, fit=fit, t_end=float(grid_t[-1] + 1 / PX_PER_MONTH))


def allocate(n, times, weights=None):
    """Integer allocation of n items to candidate times by cumulative rounding,
    so that surplus/deficit is spread evenly across the interval."""
    if n <= 0 or len(times) == 0:
        return np.array([])
    w = np.ones(len(times)) if weights is None else np.asarray(weights, float)
    cq = np.round(np.cumsum(n * w / w.sum()) - 1e-9).astype(int)
    base = np.diff(np.concatenate([[0], cq]))
    return np.repeat(times, base)


def simulate(grid_t, S, n0, cens_times, S_hat0):
    """Walk columns; events from KM ratio, then censorings (events first at ties)."""
    nr, S_hat = n0, S_hat0
    ev, ce = [], []
    ct = np.sort(cens_times)
    ci = 0
    for k, (t, s) in enumerate(zip(grid_t, S)):
        t_next = grid_t[k + 1] if k + 1 < len(grid_t) else np.inf
        if nr > 0 and s < S_hat:
            d = int(round(nr * (1 - s / S_hat)))
            d = min(max(d, 0), nr)
            if d:
                ev += [t] * d
                S_hat *= 1 - d / nr
                nr -= d
        while ci < len(ct) and ct[ci] < t_next:
            if nr > 0:
                ce.append(ct[ci]); nr -= 1
            ci += 1
    return ev, ce, nr, S_hat


def reconstruct_arm(g, wdir, mode):
    grid_t, S, marks, info = load_curve(wdir, g)
    n_risk = RISK[g]
    events, cens, log = [], [], []
    S_hat = 1.0
    for k in range(len(RISK_T) - 1):
        a, b = RISK_T[k], RISK_T[k + 1]
        m = (grid_t >= a) & (grid_t < b)
        gt, gs = grid_t[m], S[m]
        n0, n1 = (n_risk[k] if k == 0 else n_cur), n_risk[k + 1]
        mk = marks[(marks >= a) & (marks < b)]
        uni = mode == "uniform" or len(mk) == 0
        hi = min(b, info["t_end"])
        ev0, _, _, _ = simulate(gt, gs, n0, [], S_hat)
        c = max(0, n0 - n1 - len(ev0))
        best = None
        for it in range(100):
            ct = a + (np.arange(c) + 0.5) / max(c, 1) * (hi - a) if uni else allocate(c, mk)
            ev, ce, nr, Sh = simulate(gt, gs, n0, ct, S_hat)
            diff = nr - n1
            if best is None or abs(diff) < abs(best[0]):
                best = (diff, ev, ce, nr, Sh, c)
            if diff == 0:
                break
            c = max(0, c + diff)
        diff, ev, ce, nr, Sh, c = best
        log.append(dict(interval=[a, b], n_start=n0, n_end_target=n1, n_end=nr,
                        events=len(ev), censored=len(ce), tick_marks=int(len(mk)),
                        censor_source="uniform" if uni else "ticks"))
        events += ev; cens += ce
        n_cur, S_hat = nr, Sh
    if n_cur > 0:  # should not happen when the final risk count is 0
        cens += [info["t_end"] - 1e-3] * n_cur
    df = pd.concat([pd.DataFrame({"observed_time": events, "event": 1}),
                    pd.DataFrame({"observed_time": cens, "event": 0})])
    df.insert(0, "group", g)
    assert len(df) == N[g]
    return df.sort_values(["observed_time", "event"], ascending=[True, False]), log, info


def main():
    np.random.seed(SEED)
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default=os.path.join(HERE, ".."))
    p.add_argument("--censor-mode", default="ticks", choices=["ticks", "uniform"])
    p.add_argument("--out", default="ipd.csv")
    a = p.parse_args()
    wdir = os.path.join(a.outdir, "extraction")
    parts, logs = [], {}
    for g in ("A", "B"):
        df, log, info = reconstruct_arm(g, wdir, a.censor_mode)
        parts.append(df); logs[g] = log
        pd.DataFrame({"t": info["tv"], "S_raw": info["raw"], "S_isotonic": info["fit"]}).to_csv(
            os.path.join(wdir, f"measured_{g}.csv"), index=False, float_format="%.5f")
    out = pd.concat(parts)
    out["observed_time"] = out.observed_time.round(4)
    final = os.path.join(a.outdir, a.out)
    tmp = final + ".tmp"
    out.to_csv(tmp, index=False)
    os.replace(tmp, final)  # atomic commit of complete file
    json.dump(dict(seed=SEED, censor_mode=a.censor_mode, intervals=logs),
              open(os.path.join(wdir, f"recon_log_{a.censor_mode}.json"), "w"), indent=1)
    print(json.dumps(logs, indent=1))


if __name__ == "__main__":
    main()
