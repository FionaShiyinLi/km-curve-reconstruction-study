# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster) and `../input/manifest.json`: n = 1000 per arm, time in months, code seed 1643789789.
- Number-at-risk table, read visually from the figure at 0, 6, 12, 18, 24, 30, 36 months:
  A = 1000, 689, 475, 336, 222, 71, 0; B = 1000, 676, 544, 438, 358, 165, 0. All digits were clearly legible.
- The manifest gives no arm-specific event totals, so none were used and no event-total check exists (`checks.json` marks it unavailable). The reconstructed totals (A 775 events and 225 censored; B 613 events and 387 censored) come from the curve and the risk table only.

## Measurement (`code/extract.py`)
- **Calibration.** Linear, from labelled tick marks: 7 x ticks and 6 y ticks, located at pixel centers. t = (x − 270)/40 months and S = (930 − y)/750. The residuals at the ticks are 0. No global rescaling or other post hoc transform was applied. S(0) = 1 is imposed only at t = 0.
- **Curve and tick detection.** Arms are separated by hue (tab:blue = A, tab:orange = B), with antialiasing handled by per-pixel color weights. For each pixel column, the curve level is the weighted centroid within ±3 px of the median colored row. Censor ticks are 17 px tall and centered on the line, so the median is unbiased at tick columns. A column is flagged as a tick when colored pixels lie on both sides of the 4-px line core. A tick run w px wide is treated as round(w/3) marks, since 3 px is the modal isolated-tick width. This measures tick *visibility*. It does not measure multiplicity: overlapping ticks cannot be counted from the raster.
- **Occlusion.** The curves overlap over roughly 0–1.5 and 5.8–7.9 months. The drawing order could not be determined from the data (the other color intrudes on 9 A columns and 8 B columns). The arm with more intrusions (A) was treated as the lower layer. For A, any column with orange within ±10 px was excluded, which leaves only 7 of 59 A columns in 0–1.5 months. For B, only columns where blue covers B's own line core were excluded. Excluded columns are filled by interpolating the monotone fit, so the early A curve is constrained mainly by those 7 columns and S(0) = 1.
- **Monotone fit.** Weighted isotonic (pool-adjacent-violators) regression on the unoccluded columns. There is no running minimum, so a single misread point cannot propagate. Early drops are kept: B falls to about 0.974 by 0.25 months.

## Reconstruction (`code/reconstruct.py`, deterministic; the seed is set and recorded)
- **Events.** Each risk-table interval is processed column by column (0.025-month resolution). At each column, d = round(n_risk · (1 − S_meas/Ŝ)), where Ŝ is the running reconstructed KM. A 1-px change (0.0013) is about one event at n = 1000, so d is set by the size of the drop rather than fixed at 1. Tied events within a column get the same time: the column's left edge.
- **Censoring.** The number censored in each interval, c_k, is found iteratively so that the reconstructed risk set at the next risk-table time equals the table count exactly. Those c_k censorings are placed at the detected tick positions by cumulative rounding, with events counted before censorings at tied times. Detected marks and fitted censor counts agree fairly closely before 24 months (for example A 0–6: 18 marks vs 23 censored). From 24 months onward the table needs about twice as many censorings as there are visible marks (A 24–30: 56 vs 100; B 30–36: 67 vs 154). This is consistent with overlapping ticks, but it is an assumption: the extra censorings are spread in proportion to the visible marks.
- **Tail.** The table shows 0 at risk at 36. All records end before 36 (A max 35.95, B max 35.84, the last tick positions). No follow-up was invented beyond the drawn curve. The flat tails do not identify the censoring distribution or an accrual period.

## Checks (`code/checks.py` → `checks.json`)
The checks reload `ipd.csv` and recompute the right-continuous KM.
- **Survival.** The recomputed KM is compared with the raw measured curve at 22 prespecified times, including 34, 35 and 35.8 months, and at every unoccluded column. The tolerance is 0.005, about the 4-px line thickness, and was fixed before comparison. Every available time passes. Maximum column residuals: A 0.0033, B 0.0021. Times that fall inside the overlap zones are marked *unavailable*. For those, a supplementary lower-confidence remeasurement (narrow occlusion rule, not used in fitting) agrees within 0.004.
- **Risk table.** All 14 counts (#observed_time ≥ t) match exactly, including 0 at 36. Arm sizes, 0/1 event indicators and finite nonnegative times are verified.

## Revision history
There were two primary correction cycles after the first complete file.
1. A partly occluded orange tick at 0.46 months (B) biased one column. The occlusion window was widened to the tick height.
2. (a) Allocation ties were resolved toward interval starts, which pushed censorings early. This was replaced by cumulative rounding. (b) The layer-dependent occlusion rule described above was added.

## Sensitivity (`sensitivity.csv`)
One alternative was run: within each interval, censorings were spaced uniformly instead of at tick positions, with the same event rule and risk-table constraints. Common supported horizon: 35.8 months.

| Arm | S(35.8), primary | S(35.8), alternative | RMST to 35.8, primary | RMST to 35.8, alternative |
|---|---|---|---|---|
| A | 0.1307 | 0.1322 | 15.292 | 15.298 |
| B | 0.3237 | 0.3259 | 18.724 | 18.734 |

This single alternative is not an uncertainty bound.

## Unresolved limitations
- The event/censor split within a column, tick multiplicity in dense regions, and exact censoring times are not identified. The records are one feasible reconstruction, not unique recovery.
- Early A (0–1.5 months) and both arms around 6–8 months depend on interpolation across occluded columns. Timing is resolved only to about 0.025 months.
