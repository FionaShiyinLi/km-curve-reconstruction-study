"""Reconstruct participant-level records from the vector KM figure.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: ../input and ./output relative to the current working directory.

Deterministic algorithm (no randomness is used; the manifest seed is recorded
and set anyway for reproducibility).
"""
import json, os, sys, hashlib
import numpy as np
import pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
man = json.load(open(os.path.join(IN, "manifest.json")))
SEED = man["code_seed"]
np.random.seed(SEED)

page = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]
words = page.extract_words()
lines = page.lines

# ---------- axis calibration from labelled tick marks ----------
def close(a, b, tol=1.5):
    return abs(a - b) < tol

xt = [l for l in lines if l["stroking_color"] == (0.0, 0.0, 0.0)
      and close(l["pts"][0][0], l["pts"][1][0], 0.01) and close(l["pts"][0][1], 223.2, 0.5)
      and abs(l["pts"][0][1] - l["pts"][1][1]) < 4]
yt = [l for l in lines if l["stroking_color"] == (0.0, 0.0, 0.0)
      and close(l["pts"][0][1], l["pts"][1][1], 0.01) and abs(l["pts"][0][0] - l["pts"][1][0]) < 4]
# match tick marks to numeric labels by position
def label_near(x=None, y=None, row=None):
    best = None
    for w in words:
        try:
            v = float(w["text"])
        except ValueError:
            continue
        if x is not None and 229 < w["top"] < 231:
            d = abs((w["x0"] + w["x1"]) / 2 - x)
        elif y is not None and w["x1"] < 60:
            d = abs((w["top"] + w["bottom"]) / 2 - y)
        else:
            continue
        if best is None or d < best[0]:
            best = (d, v)
    return best[1]

xa = np.array([[l["pts"][0][0], label_near(x=l["pts"][0][0])] for l in xt])
ya = np.array([[l["pts"][0][1], label_near(y=l["pts"][0][1])] for l in yt])
# page y from pdfplumber 'pts' is in top-down coordinates
bx = np.polyfit(xa[:, 0], xa[:, 1], 1)
by = np.polyfit(ya[:, 0], ya[:, 1], 1)
T = lambda x: np.polyval(bx, x)
S = lambda y: np.polyval(by, y)
calib = {"x_anchors": xa.tolist(), "y_anchors": ya.tolist(),
         "time_fit": bx.tolist(), "surv_fit": by.tolist(),
         "x_resid_max": float(np.max(np.abs(T(xa[:, 0]) - xa[:, 1]))),
         "y_resid_max": float(np.max(np.abs(S(ya[:, 0]) - ya[:, 1])))}

# ---------- legend: colour -> group ----------
COL = {}
for l in lines:
    if abs(l["pts"][0][1] - 20.0) < 0.1 and abs(l["pts"][0][0] - l["pts"][1][0]) > 10:
        xr = l["pts"][1][0]
        lab = min((w for w in words if w["text"] in ("A", "B") and w["top"] < 30),
                  key=lambda w: abs(w["x0"] - xr))
        COL[tuple(l["stroking_color"])] = lab["text"]

# ---------- risk table ----------
risk = {"A": {}, "B": {}}
xtimes = sorted(xa[:, 1])
for g, top in (("A", 283.9), ("B", 297.9)):
    for w in words:
        if abs(w["top"] - top) < 1 and w["x0"] > 55:
            xc = (w["x0"] + w["x1"]) / 2
            t = float(round(T(xc) / 6) * 6)
            risk[g][t] = int(w["text"])

# ---------- curves and censor ticks ----------
curves, ticks = {}, {"A": [], "B": []}
for c in page.curves:
    g = COL[tuple(c["stroking_color"])]
    curves[g] = [(float(T(x)), float(S(y))) for x, y in c["pts"]]
for l in lines:
    col = tuple(l["stroking_color"])
    if col in COL and abs(l["pts"][0][1] - l["pts"][1][1]) > 3:
        x = l["pts"][0][0]
        ymid = (l["pts"][0][1] + l["pts"][1][1]) / 2
        ticks[COL[col]].append((float(T(x)), float(S(ymid))))

def steps(pts):
    """Return list of (time, S_before, S_after) for every vertical drop."""
    out = []
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-6 and y1 < y0 - 1e-6:
            out.append((x0, y0, y1))
    return out

def km_step(pts, t):
    """Right-continuous value of the digitised step curve at time t."""
    s = pts[0][1]
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-6 and x0 <= t + 1e-9:
            s = y1
    return s

def simulate(N, drops, cens):
    """Forward pass: events before censorings at tied times."""
    evs = [(t, 0, i) for i, t in enumerate(drops)] + [(t, 1, None) for t in cens]
    evs.sort(key=lambda e: (e[0], e[1]))
    n, recs, dinfo = N, [], []
    for t, kind, i in evs:
        if kind == 0:
            _, sb, sa = drops_full[i]
            raw = n * (1 - sa / sb)
            d = max(1, int(round(raw)))
            dinfo.append({"time": t, "S_before": sb, "S_after": sa, "n_risk": n,
                          "d_raw": raw, "d": d})
            recs += [(t, 1)] * d
            n -= d
        else:
            recs.append((t, 0))
            n -= 1
    return recs, dinfo, n

results, diag = {}, {}
for g in ("A", "B"):
    N = man["groups"][g]
    pts = curves[g]
    drops_full = steps(pts)
    drops = [d[0] for d in drops_full]
    vis = sorted(t for t, _ in ticks[g])
    t_end = pts[-1][0]
    # Visible ticks are taken as one censoring each (tick visibility != multiplicity:
    # ticks at identical x would overlap; this is handled via the risk table below).
    # Risk-table constraint: add hidden censorings in an interval if the forward
    # pass leaves more participants at risk than printed.
    rt = sorted(risk[g].items())
    hidden = []
    notes = []
    for k in range(1, len(rt)):
        t0, t1 = rt[k - 1][0], rt[k][0]
        target = rt[k][1]
        for h in range(0, N):
            extra = [t0 + (t1 - t0) * (j + 0.5) / h for j in range(h)] if h else []
            # hidden censorings must not fall at/after curve end for the final interval
            extra = [min(e, t_end) for e in extra]
            recs, dinfo, _ = simulate(N, drops, vis + hidden + extra)
            atrisk = sum(1 for t, e in recs if t >= t1 - 1e-9)
            if atrisk <= target:
                break
        if h:
            hidden += extra
            notes.append(f"interval [{t0},{t1}): {h} hidden censorings added evenly")
        if atrisk < target:
            notes.append(f"at t={t1}: reconstructed at risk {atrisk} < printed {target}")
    recs, dinfo, n_left = simulate(N, drops, vis + hidden)
    # remaining participants: censored at end of drawn curve (last tick)
    if n_left > 0:
        recs += [(t_end, 0)] * n_left
        notes.append(f"{n_left} participants remaining after all ticks censored at curve end t={t_end:.3f}")
    elif n_left < 0:
        notes.append(f"over-allocation by {-n_left}")
    results[g] = recs
    diag[g] = {"N": N, "n_drops": len(drops), "n_visible_ticks": len(vis),
               "n_hidden_censor": len(hidden), "hidden_times": hidden,
               "curve_end": t_end, "notes": notes, "drops": dinfo,
               "ticks": ticks[g], "risk_table": risk[g]}

# ---------- atomic write ----------
os.makedirs(OUT, exist_ok=True)
tmp = os.path.join(OUT, "ipd.csv.tmp")
with open(tmp, "w") as f:
    f.write("group,observed_time,event\n")
    for g in ("A", "B"):
        assert len(results[g]) == man["groups"][g]
        for t, e in sorted(results[g]):
            f.write(f"{g},{t:.4f},{e}\n")
os.replace(tmp, os.path.join(OUT, "ipd.csv"))

json.dump({"seed": SEED, "calibration": calib, "legend": {str(k): v for k, v in COL.items()},
           "groups": diag, "curves": curves},
          open(os.path.join(OUT, "extraction.json"), "w"), indent=1)
for g in ("A", "B"):
    d = diag[g]
    print(g, {k: d[k] for k in ("N", "n_drops", "n_visible_ticks", "n_hidden_censor", "curve_end", "notes")})
    dev = max(abs(x["d_raw"] - x["d"]) for x in d["drops"])
    print("  events", sum(x["d"] for x in d["drops"]), "max |d_raw-d|", round(dev, 4),
          "multi-event drops", [(round(x["time"], 2), x["d"]) for x in d["drops"] if x["d"] > 1])
print(json.dumps(calib))
