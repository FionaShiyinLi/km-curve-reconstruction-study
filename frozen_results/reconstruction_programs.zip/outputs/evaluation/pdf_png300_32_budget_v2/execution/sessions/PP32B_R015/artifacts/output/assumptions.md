# Reconstruction assumptions

## Inputs used
- `../input/figure.pdf` (vector PDF, one page) and `../input/manifest.json` (N_A = N_B = 100, months, seed 1210913098).
- The manifest has no arm-specific event totals. That constraint is marked unavailable. Its absence was not read as zero events.
- No other information was used.

## Measurement
- The PDF contains the KM curves as vector paths: one stroked path per arm, colour-coded, with the colour-to-group mapping taken from the legend. Censor marks are short vertical line segments in the arm colour. Coordinates were read from the PDF objects directly (pdfplumber), not from pixels.
- Calibration: linear fits to the labelled axis ticks (x: 0–36 months at 7 ticks; y: 0.0–1.0 at 6 ticks). The maximum anchor residual is about 1e-14, so the fit is exact. No global rescaling or origin correction was needed or applied. Both curves start exactly at S = 1.0 (page y = 43.2). The earliest drops (A at 0.023 months; B shortly after 0) are kept as genuine events.
- Risk-table numbers were read from the PDF text layer and assigned to times by their x position.
- Extracted observations (calibration, curve vertices, ticks, per-drop n_risk and d, risk table) are saved in `output/extraction.json`.

## Algorithm (`output/code/reconstruct.py`, deterministic)
1. Identify each vertical drop (time, S_before, S_after) in the step path.
2. Treat each visible censor tick as one censoring at its x time.
3. Take a forward pass in time order, with events before censorings at tied times. At each drop, d = n_risk · (1 − S_after/S_before), rounded. For **every** drop in both arms, the unrounded value equalled an integer to floating-point precision. That value was d = 1 in all cases, so no drop encodes tied events. This was checked, not assumed: a drop of 2 or more would have given a clearly different ratio.
4. Risk-table step: if the reconstructed number at risk exceeds the printed count, hidden censorings are added evenly within that interval. No hidden censorings were needed in either arm.
5. Anyone still at risk after the last drop or tick would be censored at the curve end. None were left: A has 74 events + 26 ticks and B has 69 events + 31 ticks, 100 each.

## Censoring and risk tables
- Tick visibility vs multiplicity: two censorings at exactly the same time would draw as one tick. Here the visible ticks plus the inferred events account for exactly N in each arm, and all six risk-table counts per arm match. That leaves no room for hidden or overlapping censorings under the tick-equals-one-censoring reading.
- Risk counts are computed as #{observed_time ≥ t}. At t = 36 both arms show 0, and all records are < 36: the last A record is at 35.67 and the last B record at 35.98, which are the final censor ticks where the curves end.

## Verification (`output/code/checks.py` → `output/checks.json`)
- The script reloads the committed CSV, recomputes the right-continuous KM step function, and compares it with the vector curve on a grid from 0 to the curve end, just after every drop, and at every tick height. The maximum absolute residual is about 3e-7 (tolerance 1e-3; the only error source is 4-decimal time rounding in the CSV).
- All risk-table counts match exactly, the arm sizes are 100 each, and event indicators are 0/1. Overall status: pass.

## Limitations
- The reconstruction matches the published figure, not necessarily the original data. Times are exact only to the plotted precision, which is float coordinates in the PDF, and are rounded to 1e-4 months in the CSV.
- The reading that each tick is exactly one censoring is an assumption. It is supported by the exact balance with N and the risk table, but it cannot be proven from the figure.
- Sensitivity analysis was **not run**. The allocation of events and censorings is fully determined by the inputs, as set out under Algorithm and Censoring above. No materially different feasible allocation is consistent with them, so an alternative would not be informative. This is not a claim of an error bound.
