"""Reload committed output/ipd.csv and compare to the extracted figure data.

Usage: python checks.py [OUTPUT_DIR]   (default ./output; needs extraction.json from reconstruct.py)
"""
import json, os, sys, hashlib
import numpy as np
import pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
csv = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(csv, "rb").read()).hexdigest()
df = pd.read_csv(csv)
ext = json.load(open(os.path.join(OUT, "extraction.json")))
TOL = 1e-3  # vector-extracted coordinates: residual limited by 4-decimal CSV rounding

def km(times, events):
    """Right-continuous KM step function; returns callable."""
    ut = np.unique(times[events == 1])
    s, surv = 1.0, []
    for t in ut:
        n = np.sum(times >= t)
        d = np.sum((times == t) & (events == 1))
        s *= 1 - d / n
        surv.append(s)
    ut, surv = np.array(ut), np.array(surv)
    return lambda t: 1.0 if not np.any(ut <= t) else float(surv[ut <= t][-1])

def curve_val(pts, t):
    s = pts[0][1]
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-6 and x0 <= t + 1e-4:
            s = y1
    return s

out = {"csv_sha256": sha, "columns_ok": list(df.columns) == ["group", "observed_time", "event"],
       "tolerance_survival": TOL,
       "tolerance_note": "curve read from PDF vector paths (exact to float precision); "
                         "times rounded to 1e-4 months in CSV", "groups": {}}
allpass = True
for g in ("A", "B"):
    d = df[df.group == g]
    t, e = d.observed_time.to_numpy(), d.event.to_numpy()
    f = km(t, e)
    pts = ext["curves"][g]
    gi = ext["groups"][g]
    res = {"n": int(len(d)), "n_expected": gi["N"], "n_ok": len(d) == gi["N"],
           "event_int_ok": bool(set(np.unique(e)) <= {0, 1}),
           "finite_nonneg_ok": bool(np.all(np.isfinite(t)) and np.all(t >= 0)),
           "events": int(e.sum()), "censored": int((e == 0).sum()),
           "supplied_event_total": "unavailable (not in manifest)"}
    # survival comparisons: fixed grid incl. start and tail, plus just after each drop
    grid = [0, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, gi["curve_end"]]
    sc = []
    for tt in grid:
        m, r = curve_val(pts, tt), f(tt)
        ok = abs(m - r) <= TOL
        allpass &= ok
        sc.append({"t": round(tt, 4), "measured": round(m, 5), "reconstructed": round(r, 5),
                   "residual": round(r - m, 6), "status": "pass" if ok else "fail"})
    res["survival_grid"] = sc
    drops = [x["time"] for x in gi["drops"]]
    dres = [abs(f(x + 1e-4) - curve_val(pts, x + 1e-4)) for x in drops]
    res["all_drops_max_abs_residual"] = float(max(dres))
    res["all_drops_status"] = "pass" if max(dres) <= TOL else "fail"
    allpass &= max(dres) <= TOL
    # censor ticks: height of reconstructed KM at each tick time vs tick midpoint
    tk = [abs(f(tt) - sy) for tt, sy in gi["ticks"]]
    res["tick_height_max_abs_residual"] = float(max(tk))
    res["tick_height_status"] = "pass" if max(tk) <= TOL else "fail"
    # risk table: count observed_time >= t
    rc = []
    for tt, n in sorted(gi["risk_table"].items(), key=lambda kv: float(kv[0])):
        r = int(np.sum(t >= float(tt) - 1e-9))
        ok = r == n
        allpass &= ok
        rc.append({"t": float(tt), "printed": n, "reconstructed": r, "residual": r - n,
                   "status": "pass" if ok else "fail"})
    res["risk_table"] = rc
    res["max_time"] = float(t.max())
    out["groups"][g] = res
out["overall"] = "pass" if allpass else "fail"
tmp = os.path.join(OUT, "checks.json.tmp")
json.dump(out, open(tmp, "w"), indent=1)
os.replace(tmp, os.path.join(OUT, "checks.json"))
print(out["overall"], sha)
for g in ("A", "B"):
    r = out["groups"][g]
    print(g, r["n"], r["events"], r["censored"], r["all_drops_max_abs_residual"],
          r["tick_height_max_abs_residual"], [(x["t"], x["printed"], x["reconstructed"]) for x in r["risk_table"]])
