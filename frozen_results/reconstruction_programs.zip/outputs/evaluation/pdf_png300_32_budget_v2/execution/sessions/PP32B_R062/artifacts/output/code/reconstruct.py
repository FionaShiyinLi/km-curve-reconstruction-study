"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input ../input] [--out output] [--censor ticks|uniform]
Paths default relative to the work directory (run from work/).
Steps: (1) calibrate axes from labelled tick marks; (2) per-column pixel
measurement of each coloured curve (bottom edge, censor-tick detection);
(3) Guyot-style interval-wise reconstruction constrained by the number-at-risk
table, with censor times placed at detected tick marks.
"""
import argparse, json, os, tempfile
import numpy as np
import pandas as pd
from PIL import Image

SEED = 345233437
ap = argparse.ArgumentParser()
ap.add_argument('--input', default='../input')
ap.add_argument('--out', default='output')
ap.add_argument('--censor', default='ticks', choices=['ticks', 'uniform'])
ap.add_argument('--csv', default='ipd.csv')
args = ap.parse_args()
rng = np.random.default_rng(SEED)  # recorded; algorithm itself is deterministic
man = json.load(open(os.path.join(args.input, 'manifest.json')))
im = np.asarray(Image.open(os.path.join(args.input, 'figure.png')).convert('RGB')).astype(float)
H, W, _ = im.shape

# ---------- 1. axis calibration (from pixel positions of labelled ticks) ----------
dark = im.sum(2) < 300
xt = np.where(dark[936, 250:1750])[0] + 250          # x tick marks (2 px each)
xt = xt.reshape(-1, 2).mean(1)                          # centres for 0,6,...,36
yt = np.where(dark[150:950, 264])[0] + 150
yt = yt.reshape(-1, 2).mean(1)                          # centres for 1.0,...,0.0
xlab = np.arange(0, 37, 6.0); ylab = np.array([1.0, .8, .6, .4, .2, 0.0])
ax_, bx_ = np.polyfit(xlab, xt, 1); ay_, by_ = np.polyfit(ylab, yt, 1)
px2t = lambda x: (x - bx_) / ax_
py2s = lambda y: (y - by_) / ay_
calib = dict(x_ticks_px=xt.tolist(), y_ticks_px=yt.tolist(), px_per_month=ax_,
             px_per_unit_S=-ay_, x_resid=(xt - (ax_*xlab+bx_)).tolist(),
             y_resid=(yt - (ay_*ylab+by_)).tolist())

def alpha(col):
    c = np.array(col, float); d = 255 - c
    a = ((255 - im) * d).sum(2) / (d * d).sum()
    res = np.abs(255 - im - a[..., None] * d).sum(2)
    return np.where(res < 40, a, 0) > 0.5

COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
masks = {g: alpha(c) for g, c in COL.items()}
R0, R1 = int(yt.min()) - 10, int(yt.max()) + 5         # plot rows (excludes legend)
X0, X1 = int(xt[0]) - 2, int(xt[-1]) + 2
HALF = 2.5    # half line thickness (6 px line, measured in flat regions)
TICK_HALF = 8  # censor tick half-height (17 px ticks)

def measure(g):
    m = masks[g][R0:R1]; other = masks['B' if g == 'A' else 'A'][R0:R1]
    rows = []
    for x in range(X0, X1 + 1):
        r = np.where(m[:, x])[0]
        if len(r) == 0:
            rows.append((x, np.nan, np.nan, 0)); continue
        rows.append((x, r.min() + R0, r.max() + R0, len(r)))
    d = pd.DataFrame(rows, columns=['x', 'top', 'bot', 'n'])
    d = d[d.x >= d.x[d.n > 0].min()].reset_index(drop=True)
    d = d[d.x <= d.x[d.n > 0].max()].reset_index(drop=True)
    # occlusion: other colour within +-12 px of own pixels -> unreliable column
    occ = []
    for i, x in enumerate(d.x):
        if np.isnan(d.top[i]):
            occ.append(True); continue
        lo, hi = int(d.top[i]) - 12 - R0, int(d.bot[i]) + 12 - R0
        occ.append(bool(other[max(lo, 0):hi, x].any()))
    d['occluded'] = occ
    # tick detection: true top/bottom edges are monotone non-decreasing (rows);
    # a tick produces a local upward excursion of top and downward of bottom.
    top, bot = d.top.values, d.bot.values
    K = 8; tick = np.zeros(len(d), bool)
    for i in range(len(d)):
        if np.isnan(top[i]):
            continue
        prev = top[max(0, i-K):i]; nxt = bot[i+1:i+1+K]
        c1 = len(prev) and np.nanmax(prev) - top[i] >= 4
        c2 = len(nxt) and bot[i] - np.nanmin(nxt) >= 4
        span = bot[i] - top[i] >= 2*TICK_HALF - 1   # full-height mark
        tick[i] = bool(c1 or c2 or (span and (c1 or c2 or i >= len(d) - K)))
    d['tick'] = tick
    good = (~d.tick) & (~d.occluded) & d.bot.notna()
    lev = np.where(good, d.bot - HALF, np.nan)
    # occluded columns: use whichever edge of the own line does not touch the
    # other colour (bottom edge preferred; top edge = own level - HALF)
    d['edge_used'] = np.where(good, 'bottom', '')
    for i in np.where(d.occluded & ~d.tick & d.bot.notna())[0]:
        x = d.x[i]; b = int(d.bot[i]); tp = int(d.top[i])
        if not other[b + 1 - R0:b + 3 - R0, x].any() and not m[b + 1 - R0:b + 3 - R0, x].any():
            lev[i] = b - HALF; d.loc[i, 'edge_used'] = 'bottom_occl'
        elif not other[tp - 2 - R0:tp - R0, x].any() and b - tp <= 2*HALF + 1:
            lev[i] = tp + HALF; d.loc[i, 'edge_used'] = 'top_occl'
    d['level_row'] = lev
    # measured S at column x represents S at time of x+HALF (right edge of drops)
    d['t'] = np.round(px2t(d.x + HALF), 4)  # round before interval assignment
    d['S_raw'] = py2s(d.level_row)
    # tick clusters -> censor mark positions (centre column); each ~2 px wide
    marks = []
    idx = np.where(tick)[0]
    if len(idx):
        groups = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
        for gidx in groups:
            w = len(gidx); nm = max(1, int(round(w / 2.5)))   # wide clusters = adjacent marks
            xs = np.linspace(d.x[gidx[0]], d.x[gidx[-1]], nm + 2)[1:-1] if nm > 1 else [d.x[gidx].mean()]
            for xc in xs:
                marks.append(dict(x=float(xc), t=round(float(px2t(xc)), 4), width=int(w)))
    return d, pd.DataFrame(marks)

def pava_dec(y):
    """isotonic non-increasing fit (pool adjacent violators)."""
    y = list(-np.asarray(y)); vals, wts, cnt = [], [], []
    for v in y:
        vals.append(v); wts.append(1.0); cnt.append(1)
        while len(vals) > 1 and vals[-2] > vals[-1]:
            v2, w2, c2 = vals.pop(), wts.pop(), cnt.pop()
            vals[-1] = (vals[-1]*wts[-1] + v2*w2) / (wts[-1] + w2); wts[-1] += w2; cnt[-1] += c2
    return -np.repeat(vals, cnt)

# risk table read visually from the figure (text rendered in raster; values
# transcribed by inspection of the image)
RISK_T = np.arange(0, 37, 6.0)
RISK = {'A': [1000, 710, 469, 321, 212, 68, 0], 'B': [1000, 662, 535, 437, 364, 160, 0]}

def reconstruct(g, d, marks, mode):
    # remaining unmeasurable columns (ticks / unresolved overlap): linear
    # interpolation of the *measured* curve in time (measurement step only)
    ok = d.S_raw.notna().values
    t = d.t.values
    # hidden origin region: anchor S(0)=1 (labelled axis value, both curves
    # start there) and interpolate to the first measurable column
    S = np.minimum(np.interp(t, np.r_[0.0, t[ok]], np.r_[1.0, d.S_raw.values[ok]]), 1.0)
    viol = int((np.diff(S) > 1e-9).sum())
    S = np.clip(pava_dec(S), 0, 1)
    t_end = px2t(d.x.max())                           # last drawn column
    N = man['groups'][g]; nr = RISK[g]
    ct_all = np.sort(marks.t.values) if len(marks) else np.array([])
    ev_times, cen_times, log = [], [], []
    Shat = 1.0; n_start = N
    for i in range(len(RISK_T) - 1):
        a, b = RISK_T[i], RISK_T[i + 1]
        sel = (t >= a) & (t < b) if i < len(RISK_T) - 2 else (t >= a)
        ti, Si = t[sel], S[sel]
        ticks_i = ct_all[(ct_all >= a) & (ct_all < b)]
        target = nr[i + 1]
        def run(c, cts=None):
            if cts is not None:
                pass
            elif c <= 0:
                cts = np.array([])
            elif mode == 'ticks' and len(ticks_i):
                # c censorings allocated over visible marks; tick multiplicity
                # is not observable, so extra censorings are spread evenly
                k = np.arange(c); cts = np.sort(ticks_i[(k * len(ticks_i)) // c]) if c <= len(ticks_i) \
                    else np.sort(ticks_i[np.floor(np.arange(c) * len(ticks_i) / c).astype(int)])
            else:
                hi = min(b, t_end); cts = a + (np.arange(c) + 0.5) * (hi - a) / c
            n = n_start; sh = Shat; evs = []; ci = 0
            for tk, sk in zip(ti, Si):
                while ci < len(cts) and cts[ci] < tk:
                    n -= 1; ci += 1
                if n <= 0:
                    break
                dk = int(round(n * (1 - sk / sh))) if sh > 0 else 0
                dk = max(0, min(dk, n - (len(cts) - ci)))
                if dk:
                    evs += [tk] * dk; sh *= (1 - dk / n); n -= dk
            n_end = n_start - len(evs) - len(cts)
            return evs, cts, sh, n_end
        def sse(evs, cts):
            # squared error of reconstructed KM vs measured curve in interval
            n = n_start; ev = np.array(evs); cs = np.asarray(cts)
            out = 0.0; j = 0; cur = Shat
            order = np.sort(np.r_[ev, cs]); isev = np.r_[np.ones(len(ev)), np.zeros(len(cs))][np.argsort(np.r_[ev, cs], kind='stable')]
            for tk, sk in zip(ti, Si):
                while j < len(order) and order[j] <= tk:
                    if isev[j]:
                        cur *= 1 - 1 / n
                    n -= 1; j += 1
                out += (cur - sk) ** 2
            return out
        c = max(0, int(round(n_start * (S[sel][-1] / Shat if len(Si) else 1) - target)))
        best = None
        for it in range(60):
            evs, cts, sh, n_end = run(c)
            err = n_end - target
            if best is None or abs(err) < abs(best[4]):
                best = (evs, cts, sh, c, err)
            if err == 0:
                break
            c = max(0, c + err)
        evs, cts, sh, c, err = best
        if mode == 'ticks' and len(ticks_i) > 1 and c > 0 and err == 0:
            # local search over tick multiplicities (unobservable): move one
            # censoring to a neighbouring mark if it lowers curve SSE while
            # keeping the risk-table count exact
            u = list(ticks_i); cnt = np.bincount(np.searchsorted(u, cts), minlength=len(u))
            cur = sse(evs, cts)
            for sweep in range(30):
                improved = False
                for a_ in range(len(u)):
                    for b_ in (a_ - 1, a_ + 1, a_ - 3, a_ + 3):
                        if b_ < 0 or b_ >= len(u) or cnt[a_] == 0:
                            continue
                        c2 = cnt.copy(); c2[a_] -= 1; c2[b_] += 1
                        cts2 = np.repeat(u, c2)
                        e2, _, sh2, ne2 = run(c, cts2)
                        if ne2 != target:
                            continue
                        v = sse(e2, cts2)
                        if v < cur - 1e-12:
                            cnt, cur, evs, cts, sh = c2, v, e2, cts2, sh2; improved = True
                if not improved:
                    break
        ev_times += list(evs); cen_times += list(cts)
        log.append(dict(interval=[a, b], n_start=int(n_start), n_end_target=int(target),
                        events=len(evs), censored=int(c), visible_marks=int(len(ticks_i)),
                        risk_residual=int(err)))
        Shat = sh; n_start = n_start - len(evs) - c
    cen = np.minimum(np.array(cen_times), t_end)
    rec = pd.DataFrame({'group': g, 'observed_time': np.r_[ev_times, cen],
                        'event': np.r_[np.ones(len(ev_times), int), np.zeros(len(cen), int)]})
    return rec.sort_values(['observed_time', 'event'], ascending=[True, False]), log, viol

if __name__ == '__main__':
    os.makedirs(args.out, exist_ok=True)
    allrec, meta = [], dict(seed=SEED, calibration=calib, censor_mode=args.censor, groups={})
    for g in ['A', 'B']:
        d, marks = measure(g)
        if args.censor == 'ticks':
            d.to_csv(os.path.join(args.out, f'digitized_{g}.csv'), index=False)
            marks.to_csv(os.path.join(args.out, f'censor_marks_{g}.csv'), index=False)
        rec, log, viol = reconstruct(g, d, marks, args.censor)
        assert len(rec) == man['groups'][g]
        allrec.append(rec)
        meta['groups'][g] = dict(intervals=log, monotonicity_violations_before_pava=viol,
                                 n_columns=len(d), n_tick_cols=int(d.tick.sum()),
                                 n_occluded=int(d.occluded.sum()), n_marks=len(marks))
    out = pd.concat(allrec)
    out['observed_time'] = out.observed_time.round(4)
    fd, tmp = tempfile.mkstemp(dir=args.out, suffix='.tmp'); os.close(fd)
    out.to_csv(tmp, index=False); os.replace(tmp, os.path.join(args.out, args.csv))
    json.dump(meta, open(os.path.join(args.out, f'recon_log_{args.censor}.json'), 'w'), indent=1, default=float)
    print(json.dumps(meta['groups'], indent=1, default=float))
