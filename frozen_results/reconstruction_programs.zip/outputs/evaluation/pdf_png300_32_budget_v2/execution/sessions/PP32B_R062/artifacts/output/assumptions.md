# Reconstruction assumptions and limitations

This file describes the approximate individual participant data (IPD) in `ipd.csv`, reconstructed from a Kaplan–Meier (KM) figure. The records are **not** a unique recovery of the original data.

## Inputs used
- `../input/figure.png` (1800×1350 raster) and `../input/manifest.json`. The manifest supplies N = 1000 per arm, time in months and code seed 345233437.
- Number-at-risk table, transcribed by eye from the figure. The printing is clear and I consider the reading reliable.
  - Times: 0, 6, …, 36 months.
  - A: 1000, 710, 469, 321, 212, 68, 0.
  - B: 1000, 662, 535, 437, 364, 160, 0.
- Arm-specific event totals are **not supplied**. They are marked unavailable in `checks.json`; the reconstructed totals are A 791 and B 613.

## Algorithm
The reconstruction is my own code: `code/reconstruct.py`. It is deterministic; the seed is recorded but no random draws are used.

**1. Calibration.** Axes were calibrated from the pixel centres of the labelled tick marks.
- Time: 0–36 mo maps to x = 269.5–1709.5 (40 px/mo).
- Survival: 1.0–0.0 maps to y = 179.5–929.5 (750 px per unit of S).
- Both fits are exactly linear (residuals < 1e-12 px). No global rescaling was applied to either arm; any start below 1 was not "corrected" by a multiplier.

**2. Measurement.** Each arm was isolated by colour.
- For each column, the bottom edge of the 6-px line minus 2.5 px gives the level. This level is assigned to time (x + 2.5 px), the right edge of any vertical drop segment.
- Censor ticks are 2 px wide and 17 px tall. They were detected as local excursions of the top/bottom edges against the monotone line edges. Tick columns are excluded from level measurement.
- Where the other arm's colour lies within 12 px (the curves overlap at 0–1.5 and 7.8–9.5 mo), the unobstructed edge was used if available. Otherwise the column was left unmeasured and linearly interpolated in time; this interpolation is a measurement step only.
- The hidden origin of A (under B) is anchored at the labelled S(0) = 1 and interpolated to its first visible column. B's genuine early drops (from about 0.05 mo) are preserved.
- A pool-adjacent-violators (non-increasing) fit replaced a running minimum. It had to correct 39 (A) and 89 (B) small monotonicity violations (≤ 1–2 px).
- Outputs: `digitized_{A,B}.csv` and `censor_marks_{A,B}.csv`.

**3. Reconstruction.** This is interval-wise and Guyot-style, applied to each risk-table interval.
- Events at each column: d = round(n_risk · (1 − S_meas/Ŝ_prev)), where Ŝ is the reconstructed KM. The estimate is self-correcting, and d is not assumed to be 1.
- The number censored per interval is iterated until the count at risk at the next table time matches exactly.
- Censor times are placed at detected tick positions. Tick multiplicity is not observable, so it is an **assumption**:
  - Start from an even allocation over the visible marks (more censorings than marks produces multiple censorings per mark).
  - Refine by a local search that moves single censorings between nearby marks when this lowers the squared error to the measured curve. A move is accepted only if the risk-table count stays exact.
  - The only constraint on multiplicity is therefore the drop magnitudes (KM relation S_after/S_before = 1 − d/n).
- Censorings outnumber visible marks in several intervals, e.g. A 24–30: 89 censorings vs 60 marks; B 30–36: 148 vs 61. Dense or overlapping ticks are not resolvable individually.
- Ties: events are counted before censorings.
- Displayed risk 0 at 36 mo: all records lie strictly before 36 mo (maximum A 35.946, B 35.975, the last drawn tick or column). None were placed at 36.

## Verification (`checks.json`, `code/checks.py`)
The checks reload the committed CSV and recompute the right-continuous KM step function.
- Arm sizes and 0/1 event indicators: pass.
- Risk counts (records with time ≥ t) match at all 7 table times for both arms: pass.
- Curve comparison: 21 times per arm, from 0.25 to 35.8 mo, with tolerance 0.01 (≈7.5 px, covering ≤ 1.5 px measurement error plus ≤ 3 px timing offsets on steep segments). All pass.
  - The times at 1 and 8 mo fall in overlap regions. Their measured values there come from edge-based or interpolated measurements, so they are less certain.
- All measurable columns: mean |residual| is 0.0004 (A) and 0.0006 (B); max is 0.004 (A) and 0.006 (B), both near 30 mo in the dense-tick region.
- Visual overlays: `overlay.png` and `overlay_zoom.png`.

## Correction cycles (2 used after the first complete file)
1. Overlap columns had been dropped, which collapsed their events into single drops at the end of each gap. Fixed by edge-based measurement plus interpolation.
2. An artificial drop at t ≈ 0.1 for A came from the hidden origin; fixed with the S(0) = 1 anchor. Even tick allocation also failed the B tail (35.8 mo, residual −0.0105), because the at-risk counts it implied were inconsistent with the measured drop sizes; fixed with the multiplicity local search.

A float-rounding bug in interval assignment was also fixed before correction 1.

## Sensitivity (one alternative)
`sensitivity.csv` uses the same measurement and risk-table constraints, but spreads censorings uniformly within each interval and ignores tick positions. Results are in `sensitivity_comparison.json`, with a common supported horizon of 35.9 mo.
- Survival agrees to within about 0.001 up to 30 mo.
- At 35.9 mo, S differs: A 0.093 vs 0.089; B 0.285 vs 0.293. The tail depends on the censoring allocation.
- RMST to 35.9 mo: A 15.02 vs 15.02; B 18.69 vs 18.69.

This single alternative is not a confidence interval or a bound on reconstruction error.

## Unresolved limitations
- Censoring times are known only up to tick position and interval. Multiplicity is inferred rather than observed, and within-column event timing is resolved to 0.025 mo.
- In A 12–18 mo, 9 marks were detected but the risk table and curve support only 8 censorings, so one mark receives none. Either the detector found a false mark (e.g. an edge artefact where the curves overlap) or the displayed counts are rounded; this is unresolved. The risk table was kept as the binding constraint.
- The last months (≈ 34–36 mo) rest on few participants at risk, so they are the most allocation-dependent part of the reconstruction.
