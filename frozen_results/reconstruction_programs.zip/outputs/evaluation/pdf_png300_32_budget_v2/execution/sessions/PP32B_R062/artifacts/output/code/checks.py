"""Reload committed CSV, recompute right-continuous KM, compare to measurements/risk table."""
import argparse, hashlib, json, os
import numpy as np, pandas as pd
from PIL import Image, ImageDraw
ap = argparse.ArgumentParser(); ap.add_argument('--input', default='../input'); ap.add_argument('--out', default='output')
args = ap.parse_args()
csv = os.path.join(args.out, 'ipd.csv')
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
ipd = pd.read_csv(csv); man = json.load(open(os.path.join(args.input, 'manifest.json')))
RISK_T = np.arange(0, 37, 6.0)
RISK = {'A': [1000, 710, 469, 321, 212, 68, 0], 'B': [1000, 662, 535, 437, 364, 160, 0]}

def km(df):
    ts = np.sort(df.observed_time[df.event == 1].unique()); S = 1.0; out = []
    for t in ts:
        n = (df.observed_time >= t).sum(); d = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - d / n; out.append((t, S))
    return np.array(out)
def Sat(k, t):  # right-continuous step
    i = np.searchsorted(k[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else k[i, 1]
TOL = 0.01  # ~7.5 px; measurement noise ~<=1 px (0.0013) + drop timing within 3 px
res = dict(csv_sha256=sha, tolerance_S=TOL, tolerance_note='Pixel measurement error <=~1.5 px (0.002) '
           'plus curve-drop timing offsets up to ~3 px (0.075 mo); 0.01 allows for steep-segment timing shifts.',
           event_totals='unavailable (not supplied in manifest)', groups={})
im = Image.open(os.path.join(args.input, 'figure.png')).convert('RGB'); dr = ImageDraw.Draw(im)
allok = True
for g in ['A', 'B']:
    df = ipd[ipd.group == g]; k = km(df)
    dig = pd.read_csv(os.path.join(args.out, f'digitized_{g}.csv')); dig = dig[dig.S_raw.notna()]
    r = dict(n=int(len(df)), n_expected=man['groups'][g], events=int(df.event.sum()),
             censored=int((df.event == 0).sum()), event_is_int01=bool(df.event.isin([0, 1]).all()),
             time_min=float(df.observed_time.min()), time_max=float(df.observed_time.max()))
    r['size_check'] = 'pass' if r['n'] == r['n_expected'] else 'fail'
    rk = []
    for t, nr in zip(RISK_T, RISK[g]):
        m = int((df.observed_time >= t).sum()); rk.append(dict(t=t, displayed=nr, reconstructed=m, residual=m - nr,
                                                            status='pass' if m == nr else 'fail'))
    r['risk_table'] = rk
    cmp = []
    for t in [0.25, 0.5, 1, 2, 3, 4.5, 6, 8, 10, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.8]:
        # measured value: nearest reliable non-tick column at or before t
        sub = dig[dig.t <= t]
        if len(sub) == 0 or t - sub.t.iloc[-1] > 0.3:
            cmp.append(dict(t=t, status='unavailable')); continue
        mS = float(sub.S_raw.iloc[-1]); rS = float(Sat(k, t))
        cmp.append(dict(t=t, measured=round(mS, 4), measured_at=round(float(sub.t.iloc[-1]), 3), reconstructed=round(rS, 4),
                        residual=round(rS - mS, 4), status='pass' if abs(rS - mS) <= TOL else 'fail'))
    r['curve'] = cmp
    # all measurable (non-tick, non-occluded) columns
    allres = np.array([Sat(k, tt) - ss for tt, ss in zip(dig.t, dig.S_raw)])
    r['all_columns'] = dict(n_columns=int(len(allres)), mean_abs=float(np.abs(allres).mean()),
                            p95_abs=float(np.quantile(np.abs(allres), .95)), max_abs=float(np.abs(allres).max()),
                            t_at_max=float(dig.t.values[np.abs(allres).argmax()]))
    allok &= all(c['status'] != 'fail' for c in cmp + rk)
    col = (0, 0, 0) if g == 'A' else (120, 0, 120)
    pts = [(269.5 + 40 * t, 929.5 - 750 * s) for t, s in np.r_[[[0, 1]], k]]
    step = [pts[0]]
    for p in pts[1:]:
        step += [(p[0], step[-1][1]), p]
    step.append((269.5 + 40 * r['time_max'], step[-1][1]))
    dr.line(step, fill=col, width=1)
    res['groups'][g] = r
res['all_pass'] = bool(allok)
im.save(os.path.join(args.out, 'overlay.png'))
json.dump(res, open(os.path.join(args.out, 'checks.json'), 'w'), indent=1, default=float)
for g in res['groups']:
    print(g, {k2: v for k2, v in res['groups'][g].items() if k2 not in ('curve', 'risk_table')})
    print(' risk', [(x['t'], x['residual']) for x in res['groups'][g]['risk_table']])
    print(' curve', [(x['t'], x.get('residual'), x['status']) for x in res['groups'][g]['curve']])
print('sha', sha, 'all_pass', allok)
