"""Compare primary (tick-placed censoring) vs sensitivity (uniform within interval) IPD."""
import json, os, sys
import numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
def km(df):
    ts = np.sort(df.observed_time[df.event == 1].unique()); S = 1.0; r = [(0.0, 1.0)]
    for t in ts:
        n = (df.observed_time >= t).sum(); d = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - d / n; r.append((t, S))
    return np.array(r)
def Sat(k, t): return k[np.searchsorted(k[:, 0], t, side='right') - 1, 1]
def rmst(k, h):
    tt = np.r_[k[:, 0][k[:, 0] < h], h]; return float(np.sum(np.diff(tt) * k[:len(tt) - 1, 1]))
P = pd.read_csv(os.path.join(out, 'ipd.csv')); Q = pd.read_csv(os.path.join(out, 'sensitivity.csv'))
H = float(min(P.groupby('group').observed_time.max().min(), Q.groupby('group').observed_time.max().min()))
H = np.floor(H * 10) / 10
res = dict(common_horizon_months=H, alternative='censorings spread uniformly within each risk-table interval '
           '(tick positions ignored); same curve measurement and risk-table constraints', groups={})
for g in ['A', 'B']:
    kp, kq = km(P[P.group == g]), km(Q[Q.group == g])
    res['groups'][g] = dict(
        S=[dict(t=t, primary=round(float(Sat(kp, t)), 4), sensitivity=round(float(Sat(kq, t)), 4)) for t in [6, 12, 18, 24, 30, H]],
        rmst_primary=round(rmst(kp, H), 3), rmst_sensitivity=round(rmst(kq, H), 3),
        events_primary=int(P[P.group == g].event.sum()), events_sensitivity=int(Q[Q.group == g].event.sum()))
json.dump(res, open(os.path.join(out, 'sensitivity_comparison.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
