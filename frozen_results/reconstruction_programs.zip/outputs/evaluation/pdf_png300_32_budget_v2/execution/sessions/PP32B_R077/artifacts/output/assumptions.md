# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 1180577179). The manifest has no arm-specific event totals, so no event-total constraint was applied. That does not mean zero events.

**Code** (`output/code/`, run from the work directory):
`python output/code/reconstruct.py ../input output` → `ipd.csv`, `measured_curve.csv`, `censor_ticks.csv`, `reconstruction_log.json`.
Then `python output/code/check.py output` → `checks.json` and `diag/overlay.png`.
Then `reconstruct.py ../input output --uniform-censoring output/sensitivity.csv` and `sensitivity.py output` → `sensitivity_comparison.json`.
`extract.py` is an earlier diagnostic pass over the pixel columns. The algorithm is deterministic, but the seed is set anyway. No KM-to-IPD package was used.

## Measurement
- **Calibration.** Axis lines and labelled tick marks were located from dark pixels. x: 0–36 months at px 269.5 to 1709.5, so 40 px per month. y: 1.0 to 0.0 at px 179.5 to 929.5, so 750 px per unit. The linear fit reproduces all 7 x-ticks and 6 y-ticks exactly. No global rescaling was applied.
- **Curve extraction.** Each arm is segmented by RGB distance to its line colour. The line is about 4 px thick.
  - Columns with a span of 5 px or less give the line centre directly.
  - Columns containing a censor tick (±8 px about the line) or a vertical drop are resolved from neighbouring clean columns. A flat stretch takes the neighbour level. A transition column takes its bottom edge minus 1.5 px, clipped between the neighbouring levels.
  - A least-squares isotonic fit (pool-adjacent-violators) then enforces monotonicity. No running minimum was used.
- **Origin.** Near t = 0 the blue (A) line lies under the orange (B) line. For those columns A's level comes from its visible lower edge (bottom minus 1.5 px), not from a rescaling. A's genuine steep early decline was kept.
- **Precision.** Survival is capped at 1. The line-centre ambiguity is about 1 px (0.0013 in survival).
- **Censor ticks.** A column counts as a tick if colour extends at least 5 px both above and below the local line. Adjacent tick columns are grouped (69 groups in A, 78 in B).
  - A group's width divided by 3 px is used only as a relative weight for multiplicity.
  - Visibility is not multiplicity: overlapping ticks, especially in the dense 24–30 month region, hide how many censorings each group holds.
  - Ticks drawn on vertical drop segments can be missed.

## Reconstruction algorithm (own implementation)
1. The risk table (0/6/…/36 months) was read visually; OCR was not available. A: 1000, 667, 444, 290, 197, 65, 0. B: 1000, 775, 568, 440, 339, 143, 0. The digits are clearly rendered, so I regard these readings as reliable.
2. Each risk-table interval [T_j, T_{j+1}) is processed in turn.
   - The interval censoring count c_j is found by search, so that the number with observed_time ≥ T_{j+1} equals the table count.
   - Given the censoring times, events per pixel column are d = round(n·(1 − S_meas/Ŝ_prev)), where Ŝ is the reconstructed KM. This follows d/n from the measured relative drop and does not assume d = 1 per drop.
   - At tied times, events precede censorings.
   - Event times are pixel-column centres, a 0.025-month resolution.
3. Censoring times are placed at detected tick-group times.
   - Allocation starts proportional to tick weight (largest remainder).
   - **Correction cycle 1 (the only one used)** then refines it. It moves single censorings between tick groups within an interval, holding c_j fixed and keeping at least one censoring at every visible tick. A move is kept only if it lowers the squared difference between reconstructed KM and measured curve and leaves the end-of-interval count unchanged.
   - This cycle was triggered by a tail check: before refinement, A's final KM was 0.071 against a measured 0.081. The pixels show a single drop of about 25% at 35.35 months with ticks on both sides, which implies about 4 at risk. Allocation had left only 3.
4. The last interval must end with 0 at risk at 36. All remaining participants are censored at visible tick times before 36 (A at most 35.85, B at most 35.96). No follow-up beyond the drawn curve is invented.

## Result (final `ipd.csv`; SHA-256 in `checks.json`)
- **Arm sizes and events.** A: 1000 records, 812 events. B: 1000 records, 650 events.
- **Risk table.** Counts match the table at all 7 times in both arms, using observed_time ≥ t.
- **Curve fit.** The reconstructed right-continuous KM was compared with the measured curve at 52 times per arm, tail included. Maximum absolute residual: 0.0010 (A) and 0.0041 (B).
- **Tolerance.** The tolerance is 0.004 (3 px) plus S/n_risk (one event step). All checks pass.
- **Final level.** A: 0.0808 against 0.0813 measured. B: 0.1738 against 0.172 measured.
- **Unavailable checks.** Times beyond an arm's last drawn pixel (A after 35.8 months) are marked unavailable.

## Sensitivity (one alternative, `sensitivity.csv`)
- **Assumption.** Censorings are spaced uniformly within each risk interval, ignoring tick positions and skipping refinement.
- **Comparison.** Risk-table counts are identical to the primary. Over a common horizon of 35.8 months:
  - Survival differs by at most 0.001 through 33 months.
  - At 35.8 months, A is 0.0808 (primary) vs 0.0774, and B is 0.1738 vs 0.1612.
  - Restricted mean survival time (area under the curve) to 35.8 months: A 14.117 vs 14.116, B 19.203 vs 19.206.
  - Events: A 812 vs 812, B 650 vs 647.
- **Why tick-based is primary.** It uses the displayed censor marks and fits the measured tail better. It was not chosen for any treatment contrast. This single alternative is not a confidence interval or a bound on reconstruction error.

## Unresolved limitations
- Exact censoring times and multiplicities within intervals are not identified. Hidden or merged ticks were allocated by the fitting rule above, which is an assumption. They are constrained only by interval counts and curve shape.
- Event times are quantised to pixel columns (±0.0125 months). Tied events within a column are grouped at one time.
- Inside a steep, dense drop the split between adjacent columns is approximate.
- The tail rests on very few participants (n at risk ≤ 17 after 35.5 months), so individual tail records are weakly identified.
- The flat tails do not identify any accrual or administrative-censoring process, and none was assumed beyond the displayed curve.
