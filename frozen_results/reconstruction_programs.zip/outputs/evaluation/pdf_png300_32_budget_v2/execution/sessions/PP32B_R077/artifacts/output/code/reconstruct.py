"""KM figure -> approximate IPD. Own implementation (pixel measurement + risk-table-constrained
Guyot-style inversion written from scratch). Usage:
  python reconstruct.py [input_dir] [output_dir] [--uniform-censoring out.csv]
Seed 1180577179 is set for reproducibility although the algorithm is deterministic."""
import sys, os, json, numpy as np, pandas as pd
from PIL import Image
SEED = 1180577179
np.random.seed(SEED)
args = [a for a in sys.argv[1:] if not a.startswith('--')]
IN = args[0] if len(args) > 0 else '../input'
OUT = args[1] if len(args) > 1 else 'output'
UNIFORM = '--uniform-censoring' in sys.argv
manifest = json.load(open(os.path.join(IN, 'manifest.json')))
im = np.asarray(Image.open(os.path.join(IN, 'figure.png')).convert('RGB')).astype(int)

# ---------------- calibration from labelled axis ticks ----------------
dark = im.sum(2) < 150
xrow = int(np.argmax(dark.sum(1))); ycol = int(np.argmax(dark.sum(0)))
def groups(idx):
    return [g for g in np.split(idx, np.where(np.diff(idx) > 1)[0] + 1) if len(g)]
xt = [g.mean() for g in groups(np.where(dark[xrow+3:xrow+8].all(0))[0]) if g.mean() >= ycol - 2]
yt = [g.mean() for g in groups(np.where(dark[:, ycol-8:ycol-3].all(1))[0])]
assert len(xt) == 7 and len(yt) == 6
bx = np.polyfit(xt, [0, 6, 12, 18, 24, 30, 36], 1)
by = np.polyfit(yt, [1.0, .8, .6, .4, .2, 0.0], 1)
px2t = lambda x: np.polyval(bx, x); py2s = lambda y: np.polyval(by, y)

# ---------------- risk table (read visually from the figure; OCR not available) -------------
T = np.array([0, 6, 12, 18, 24, 30, 36.])
RISK = {'A': [1000, 667, 444, 290, 197, 65, 0], 'B': [1000, 775, 568, 440, 339, 143, 0]}
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
top_lim = int(min(yt)) - 40

def pav_increasing(y):
    """Least-squares isotonic (nondecreasing) fit, pool-adjacent-violators."""
    blocks = []
    for v in y:
        blocks.append([v, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            v2, w2 = blocks.pop(); v1, w1 = blocks.pop()
            blocks.append([(v1*w1 + v2*w2)/(w1+w2), w1+w2])
    return np.concatenate([[v]*w for v, w in blocks])

def measure(g):
    other = [k for k in COL if k != g][0]
    m = np.sqrt(((im - np.array(COL[g]))**2).sum(2)) < 60
    mo = np.sqrt(((im - np.array(COL[other]))**2).sum(2)) < 60
    for mm in (m, mo):
        mm[:top_lim] = False; mm[xrow+1:] = False
    xs = np.where(m.any(0))[0]
    X = np.arange(xs.min(), xs.max()+1)
    top = np.full(len(X), np.nan); bot = top.copy(); lev = top.copy(); occl = np.zeros(len(X), bool)
    for i, x in enumerate(X):
        ys = np.where(m[:, x])[0]
        if not len(ys): continue
        top[i], bot[i] = ys.min(), ys.max()
        occl[i] = ys.min() > 0 and mo[ys.min()-1, x]     # upper edge hidden under other curve
        span = ys.max() - ys.min() + 1
        if span <= 5 and not occl[i]: lev[i] = (ys.min()+ys.max())/2
        elif occl[i] and span <= 5:   lev[i] = ys.max() - 1.5   # 4-px line: centre = bottom-1.5
    valid = ~np.isnan(lev)
    raw = lev.copy()
    # unresolved columns (ticks, drops, occlusion with ticks): use neighbours
    vi = np.where(valid)[0]
    for i in np.where(~valid)[0]:
        l = vi[vi < i]; r = vi[vi > i]
        L = lev[l[-1]] if len(l) else 179.5; R = lev[r[0]] if len(r) else L
        if np.isnan(bot[i]): lev[i] = L; continue
        if abs(R - L) <= 2: lev[i] = (L + R)/2      # flat stretch with a censor tick
        else: lev[i] = np.clip(bot[i] - 1.5, L, R)  # transition column
    y_iso = pav_increasing(np.maximum(lev, yt[0]))   # S<=1 by definition, then monotone
    S = np.minimum(py2s(y_iso), 1.0)
    # censor ticks: column extends >=5 px both above and below the local line level
    lo = np.minimum(y_iso, np.r_[y_iso[0], y_iso[:-1]]); hi = np.maximum(y_iso, np.r_[y_iso[1:], y_iso[-1]])
    tick = (top <= lo - 5) & (bot >= hi + 5)
    tg = groups(np.where(tick)[0])
    ticks = pd.DataFrame({'x_px': [X[g].mean() for g in tg], 'width_px': [len(g) for g in tg]})
    ticks['time'] = px2t(ticks.x_px)
    ticks['visible_marks'] = np.maximum(1, np.round(ticks.width_px / 3)).astype(int)  # rough; overlap hides multiplicity
    curve = pd.DataFrame({'group': g, 'x_px': X, 'time': px2t(X), 'top_px': top, 'bottom_px': bot,
                          'raw_level_px': raw, 'level_px': lev, 'iso_level_px': y_iso, 'S': S,
                          'occluded_top': occl, 'tick_col': tick})
    ticks.insert(0, 'group', g)
    return curve, ticks

def allocate(c, ticks, t0, t1, colt):
    """Censor times for c censorings in [t0,t1)."""
    if c == 0: return np.array([])
    tk = ticks[(ticks.time >= t0) & (ticks.time < t1)]
    if UNIFORM or len(tk) == 0:
        lo_, hi_ = t0, min(t1, colt.max())
        return lo_ + (np.arange(c) + 0.5) * (hi_ - lo_) / c
    w = tk.visible_marks.values.astype(float); q = c * w / w.sum()
    n = np.floor(q).astype(int); rem = c - n.sum()
    n[np.argsort(-(q - n), kind='stable')[:rem]] += 1
    return np.repeat(tk.time.values, n)

def walk(times, S, n0, Shat0, cens, t0, t1):
    """Invert KM drops in [t0,t1) given censor times; events rounded against reconstructed KM."""
    sel = (times >= t0) & (times < t1)
    n, Sh = n0, Shat0; ev = []; ce = []
    cens = np.sort(cens); ci = 0
    for t, s in zip(times[sel], S[sel]):
        # censorings strictly before this column time leave first
        while ci < len(cens) and cens[ci] < t - 1e-9:
            if n > 0: ce.append(cens[ci]); n -= 1
            ci += 1
        if n > 0 and Sh > 0:
            d = int(np.clip(np.round(n * (1 - s / Sh)), 0, n))
            if d: ev += [t]*d; Sh *= 1 - d/n; n -= d
        while ci < len(cens) and cens[ci] <= t + 1e-9:     # ties: events before censoring
            if n > 0: ce.append(cens[ci]); n -= 1
            ci += 1
    while ci < len(cens):
        if n > 0: ce.append(cens[ci]); n -= 1
        ci += 1
    return n, Sh, ev, ce

def sse(times, S, n0, Sh0, cens, t0, t1):
    r = walk(times, S, n0, Sh0, cens, t0, t1)
    sel = (times >= t0) & (times < t1); ev = np.array(r[2])
    # reconstructed KM at each column in the interval (piecewise constant after events)
    Sh = Sh0; n = n0; out = []; cs = np.sort(cens); ci = 0
    for t, s in zip(times[sel], S[sel]):
        while ci < len(cs) and cs[ci] < t - 1e-9: n -= 1; ci += 1
        d = int((np.abs(ev - t) < 1e-9).sum())
        if d: Sh *= 1 - d/n; n -= d
        while ci < len(cs) and cs[ci] <= t + 1e-9: n -= 1; ci += 1
        out.append(Sh - s)
    return float(np.sum(np.square(out))), r

def refine(times, S, n0, Sh0, c, ticks, t0, t1, max_sweeps=6):
    """Primary correction cycle 1: keep interval censor count c (fixed by risk table) but move
    censorings between detected tick groups to minimise squared KM-vs-measured residual.
    Every visible tick keeps >=1 censoring when c >= number of tick groups."""
    tk = ticks[(ticks.time >= t0) & (ticks.time < t1)].time.values
    if len(tk) < 2: r = walk(times, S, n0, Sh0, allocate(c, ticks, t0, t1, times), t0, t1); return (*r, 0)
    cens = allocate(c, ticks, t0, t1, times)
    cnt = np.array([(np.abs(cens - t) < 1e-9).sum() for t in tk])
    floor_ = 1 if c >= len(tk) else 0
    best, r = sse(times, S, n0, Sh0, np.repeat(tk, cnt), t0, t1); moves = 0
    for _ in range(max_sweeps):
        improved = False
        for i in range(len(tk)):
            if cnt[i] <= floor_: continue
            for k in range(len(tk)):
                if k == i or cnt[i] <= floor_: continue
                cnt[i] -= 1; cnt[k] += 1
                v, rr = sse(times, S, n0, Sh0, np.repeat(tk, cnt), t0, t1)
                if v < best - 1e-12 and rr[0] == r[0]: best, r = v, rr; moves += 1; improved = True
                else: cnt[i] += 1; cnt[k] -= 1
        if not improved: break
    return (*r, moves)

def reconstruct(g, curve, ticks):
    times = curve.time.values; S = curve.S.values
    N = manifest['groups'][g]; risk = RISK[g]; assert risk[0] == N
    n, Sh = N, 1.0; E, C, log = [], [], []
    for j in range(len(T) - 1):
        target = risk[j+1]; best = None
        for c in range(0, n + 1):
            cens = allocate(c, ticks, T[j], T[j+1], times)
            r = walk(times, S, n, Sh, cens, T[j], T[j+1])
            err = abs(r[0] - target)
            if best is None or err < best[0]: best = (err, c, r)
            if r[0] < target: break
        err, c, (n1, Sh1, ev, ce) = best
        if not UNIFORM and c > 0:
            n1b, Sh1b, evb, ceb, moves = refine(times, S, n, Sh, c, ticks, T[j], T[j+1])
            if n1b == n1: n1, Sh1, ev, ce = n1b, Sh1b, evb, ceb
            else: moves = 'rejected (changed end count)'
        else: moves = 0
        log.append(dict(interval=[T[j], T[j+1]], n_start=n, n_end=n1, table_end=target,
                        events=len(ev), censored=len(ce), mismatch=int(n1 - target), refine_moves=moves))
        E += ev; C += ce; n, Sh = n1, Sh1
    assert n == 0, f'{g}: {n} participants still at risk at 36'
    df = pd.DataFrame({'group': g, 'observed_time': np.r_[E, C], 'event': np.r_[np.ones(len(E)), np.zeros(len(C))].astype(int)})
    assert len(df) == N
    return df.sort_values(['observed_time', 'event'], ascending=[True, False]), log

def atomic_csv(df, path):
    tmp = path + '.tmp'; df.to_csv(tmp, index=False, float_format='%.4f'); os.replace(tmp, path)

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    curves, tks, ipd, logs = [], [], [], {}
    for g in ['A', 'B']:
        cv, tk = measure(g); df, lg = reconstruct(g, cv, tk)
        curves.append(cv); tks.append(tk); ipd.append(df); logs[g] = lg
    target = sys.argv[sys.argv.index('--uniform-censoring')+1] if UNIFORM else os.path.join(OUT, 'ipd.csv')
    if not UNIFORM:
        pd.concat(curves).to_csv(os.path.join(OUT, 'measured_curve.csv'), index=False, float_format='%.5f')
        pd.concat(tks).to_csv(os.path.join(OUT, 'censor_ticks.csv'), index=False, float_format='%.4f')
        json.dump(dict(calibration=dict(xticks_px=xt, yticks_px=yt, months_per_px=bx[0], S_per_px=by[0],
                       x_axis_row=xrow, y_axis_col=ycol), intervals=logs),
                  open(os.path.join(OUT, 'reconstruction_log.json'), 'w'), indent=1, default=float)
    atomic_csv(pd.concat(ipd), target)
    for g in logs:
        print(g, [(l['events'], l['censored'], l['mismatch']) for l in logs[g]])
