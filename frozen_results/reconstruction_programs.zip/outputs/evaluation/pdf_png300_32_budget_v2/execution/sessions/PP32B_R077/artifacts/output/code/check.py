"""Reload committed ipd.csv, recompute right-continuous KM, compare with measurements -> checks.json.
Usage: python check.py [output_dir] [ipd_csv]"""
import sys, os, json, hashlib, numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
CSV = sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, 'ipd.csv')
sys.path.insert(0, os.path.dirname(__file__)); 
RISK = {'A': [1000, 667, 444, 290, 197, 65, 0], 'B': [1000, 775, 568, 440, 339, 143, 0]}
T = [0, 6, 12, 18, 24, 30, 36]; N = {'A': 1000, 'B': 1000}
ipd = pd.read_csv(CSV); meas = pd.read_csv(os.path.join(OUT, 'measured_curve.csv'))
def km(d):
    ut = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = []
    for t in ut:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e/n; out.append((t, S, n))
    return np.array(out)
def km_at(k, t):
    i = np.searchsorted(k[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else k[i, 1]
res = dict(csv_sha256=hashlib.sha256(open(CSV, 'rb').read()).hexdigest(), csv=CSV,
           structure=dict(columns=list(ipd.columns), n=ipd.groupby('group').size().to_dict(),
                          event_values=sorted(ipd.event.unique().tolist()),
                          finite_nonneg=bool(np.isfinite(ipd.observed_time).all() and (ipd.observed_time >= 0).all()),
                          pass_=bool(list(ipd.columns) == ['group','observed_time','event'] and
                                     ipd.groupby('group').size().to_dict() == N)),
           supplied_event_totals='unavailable (manifest has no event totals)',
           tolerance_note='survival tol = 0.004 (3 px of the 750 px/unit axis: line-centre and antialiasing '
                          'uncertainty) + one-event KM step S/n_risk at the check time (integer-event quantization)',
           arms={})
for g in ['A', 'B']:
    d = ipd[ipd.group == g]; k = km(d); m = meas[meas.group == g]
    tt = list(np.arange(0.25, 35.8, 0.75)) + [35.6, 35.8, 35.9, 35.95]
    rows = []
    for t in tt:
        mm = m[m.time <= t]
        if not len(mm) or t > m.time.max(): rows.append(dict(t=t, status='unavailable')); continue
        ms = float(mm.S.iloc[-1]); rs = float(km_at(k, t)); n = int((d.observed_time >= t).sum())
        tol = 0.004 + (rs / n if n else 0)
        rows.append(dict(t=round(float(t), 3), measured=round(ms, 4), reconstructed=round(rs, 4),
                         residual=round(rs - ms, 4), tol=round(tol, 4), n_risk=n,
                         status='pass' if abs(rs - ms) <= tol else 'fail'))
    risk = [dict(t=t, table=RISK[g][i], reconstructed=int((d.observed_time >= t).sum()),
                 status='pass' if int((d.observed_time >= t).sum()) == RISK[g][i] else 'fail')
            for i, t in enumerate(T)]
    ok = [r for r in rows if r['status'] != 'unavailable']
    res['arms'][g] = dict(n=len(d), events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                          max_time=float(d.observed_time.max()), last_event=float(d.observed_time[d.event == 1].max()),
                          final_KM=float(k[-1, 1]), risk_table=risk, curve=rows,
                          curve_max_abs_resid=max(abs(r['residual']) for r in ok),
                          curve_fail=sum(r['status'] == 'fail' for r in ok))
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g, a in res['arms'].items():
    print(g, a['n'], a['events'], a['max_time'], a['final_KM'], 'maxres', a['curve_max_abs_resid'],
          'fails', a['curve_fail'], [r['status'] for r in a['risk_table']])
    print('  fails:', [(r['t'], r['measured'], r['reconstructed']) for r in a['curve'] if r['status'] == 'fail'])
# overlay figure
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
fig, ax = plt.subplots(figsize=(12, 6))
for g, c in zip('AB', ['tab:blue', 'tab:orange']):
    k = km(ipd[ipd.group == g]); m = meas[meas.group == g]
    ax.plot(m.time, m.S, color='k', lw=0.6)
    ax.step(np.r_[0, k[:, 0]], np.r_[1, k[:, 1]], where='post', color=c, lw=0.8, alpha=.8)
ax.set_xlabel('months'); ax.set_ylabel('S'); fig.savefig(os.path.join(OUT, 'diag', 'overlay.png'), dpi=110)
