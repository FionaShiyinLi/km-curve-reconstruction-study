"""Compare primary ipd.csv with sensitivity.csv (uniform within-interval censoring, no tick refinement).
Usage: python sensitivity.py [output_dir]"""
import sys, os, json, numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
def km(d):
    ut = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = [(0.0, 1.0)]
    for t in ut:
        S *= 1 - ((d.observed_time == t) & (d.event == 1)).sum() / (d.observed_time >= t).sum(); out.append((t, S))
    return np.array(out)
def S_at(k, t): return k[np.searchsorted(k[:, 0], t, side='right') - 1, 1]
def rmst(k, h):
    t = np.r_[k[k[:, 0] < h, 0], h]; return float(np.sum(np.diff(t) * k[k[:, 0] < h, 1]))
P = pd.read_csv(os.path.join(OUT, 'ipd.csv')); Q = pd.read_csv(os.path.join(OUT, 'sensitivity.csv'))
H = float(min(P.groupby('group').observed_time.max().min(), Q.groupby('group').observed_time.max().min()))
H = np.floor(H * 10) / 10
res = dict(common_horizon_months=H, assumption='censorings in each risk-table interval spaced uniformly '
           'over the interval (tick positions ignored, no refinement); event inversion and risk-table counts as primary',
           arms={})
for g in 'AB':
    kp, kq = km(P[P.group == g]), km(Q[Q.group == g])
    rows = [dict(t=t, S_primary=round(float(S_at(kp, t)), 4), S_sens=round(float(S_at(kq, t)), 4))
            for t in [6, 12, 18, 24, 30, 33, 35, H]]
    res['arms'][g] = dict(events_primary=int(P[P.group == g].event.sum()), events_sens=int(Q[Q.group == g].event.sum()),
                          risk_check_sens=[int((Q[Q.group == g].observed_time >= t).sum()) for t in range(0, 37, 6)],
                          survival=rows, rmst_primary=round(rmst(kp, H), 3), rmst_sens=round(rmst(kq, H), 3))
json.dump(res, open(os.path.join(OUT, 'sensitivity_comparison.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
