"""Step 1: axis calibration and curve/censor-mark measurement from figure.png pixels.
Usage: python extract.py [input_png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
inp = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(inp).convert('RGB')).astype(int)
H, W, _ = im.shape
dark = (im.sum(2) < 150)
# --- axis lines: longest dark row / column runs
rowsum = dark.sum(1); colsum = dark.sum(0)
yax_row = int(np.argmax(rowsum))            # x-axis line row
xax_col = int(np.argmax(colsum))            # y-axis line column
# x ticks: dark pixels just below the x-axis line
below = dark[yax_row+3:yax_row+8, :].all(0)
xt = np.where(below)[0]
groups = np.split(xt, np.where(np.diff(xt) > 1)[0]+1)
xticks = [float(g.mean()) for g in groups if len(g) and g.mean() >= xax_col - 2]
# y ticks: dark pixels just left of y-axis
left = dark[:, xax_col-8:xax_col-3].all(1)
yt = np.where(left)[0]
groups = np.split(yt, np.where(np.diff(yt) > 1)[0]+1)
yticks = [float(g.mean()) for g in groups if len(g)]
print('x-axis row', yax_row, 'y-axis col', xax_col)
print('xticks', xticks); print('yticks', yticks)
tvals = [0, 6, 12, 18, 24, 30, 36]; svals = [0, .2, .4, .6, .8, 1.0][::-1]
assert len(xticks) == 7 and len(yticks) == 6, 'tick detection failed'
ax_ = np.polyfit(xticks, tvals, 1); ay_ = np.polyfit(yticks, svals, 1)
xres = np.polyval(ax_, xticks) - tvals; yres = np.polyval(ay_, yticks) - svals
print('x calib residual (months)', xres.round(4), 'y calib residual', yres.round(5))
cal = dict(x_axis_row=yax_row, y_axis_col=xax_col, xticks_px=xticks, yticks_px=yticks,
           t_per_px=ax_[0], t0=ax_[1], s_per_px=ay_[0], s0=ay_[1],
           max_abs_x_resid=float(abs(xres).max()), max_abs_y_resid=float(abs(yres).max()))
cols = {'A': (31, 119, 180), 'B': (255, 127, 14)}
res = {'calibration': cal}
plot_top = int(min(yticks)) - 40
for g, c in cols.items():
    d = np.sqrt(((im - np.array(c))**2).sum(2))
    m = d < 60
    m[:plot_top, :] = False; m[yax_row+1:, :] = False   # plot area only (exclude legend)
    # horizontal-continuity mask: line pixels have coloured neighbours at x-2 and x+2
    hz = m & np.roll(m, 2, 1) & np.roll(m, -2, 1)
    xs = np.where(m.any(0))[0]
    curve = []; ticks = []
    for x in range(xs.min(), xs.max()+1):
        ys = np.where(m[:, x])[0]
        if len(ys) == 0: continue
        hy = np.where(hz[:, x])[0]
        curve.append([x, int(ys.min()), int(ys.max()),
                      int(hy.min()) if len(hy) else -1, int(hy.max()) if len(hy) else -1])
    curve = np.array(curve)
    res[g] = dict(x_range=[int(xs.min()), int(xs.max())], columns=curve.tolist())
    np.save(f'{out}/code/_mask_{g}.npy', m)
json.dump(res, open(f'{out}/pixel_columns.json', 'w'))
