# Reconstruction assumptions and limitations

## Inputs
- `../input/figure.png` (1800x1350 raster KM plot, two arms, number-at-risk table).
- `../input/manifest.json`: n = 100 per arm, time in months, code seed 1424912571. The seed is set in `reconstruct.py`, but the algorithm is deterministic.
- The manifest gives no arm-specific event totals, so the event-total check is marked unavailable. The reconstruction implies 78 events in A and 63 in B, but these are outputs of the reconstruction, not inputs.
- Number at risk, transcribed by eye from the printed table (no OCR available). The digits are large and unambiguous:
  A: 100, 64, 40, 25, 17, 8, 0; B: 100, 73, 62, 46, 42, 16, 0 at 0, 6, ..., 36 months.

## Measurement (`code/extract.py` -> `measured_curves.json`)
- Calibration uses the labelled axis ticks, which are detected and asserted in code. On x, pixel 269.5 is 0 months and 1709.5 is 36 months (40 px/month). On y, pixel 179.5 is S = 1 and 929.5 is S = 0 (750 px per unit).
- No global rescaling was applied. The first horizontal segment of each arm is centred at exactly S = 1.000, so no origin correction was needed. B's genuine early drop at 0.17 months is kept.
- The curve colours are pure (no antialiasing), and the lines are about 4 px thick. In each column, a line run no thicker than 6 px gives the level (its centre). Plateaus are maximal runs of equal level, and steps are transitions between plateaus. The event time is the centre of the riser gap.
- Orange is drawn over blue. Where a blue column has no visible line but an orange line lies between blue's previous and next measured levels, blue is assumed to be hidden under orange. This occurs only in the 0–4 month overlap.
- Censor ticks were detected as own-colour pixels more than 3 px above the local line top. A candidate is accepted if its top is 6–11.5 px above an adjacent plateau centre (true ticks rise about 8 px). Each tick gets a confidence grade. Grade 2 means the tick sits on a plateau. Grade 1 means it sits at a riser, where it could instead be the riser of an unresolved intermediate level. Grade 0 means the candidate was rejected. One tick (A, 5.66 months) was upgraded to grade 2 after a 5x visual zoom (`overlay_zoom.png`), because it overlaps a riser.
- Tick visibility is not multiplicity. Overlapping ticks cannot be counted from the image.

## Reconstruction (`code/reconstruct.py`)
- The method is my own interval-wise implementation of the Guyot-style logic; no KM-to-IPD package was used. The intervals are the risk-table intervals. For each candidate number of censorings c = 0..n_start:
  - Censor times are taken from the tick candidates in confidence order, then by time.
  - Any extra (unmarked) censorings are spread uniformly over the interval. In the last interval they are capped at the drawn curve end.
  - At each measured step, d is the integer ≥1 that brings the cumulative reconstructed KM closest to the measured post-step level, using S_after = S_before(1 − d/n). d = 1 is not assumed; several steps need d = 2.
  - At tied times, events come before censorings.
  - The chosen c minimises 10·|n_next(model) − n_next(table)| + 1000·SSE(curve), with a tiny penalty for departing from the number of visible ticks.
- Several events inside one wide riser gap (more than 8 columns) are spread evenly across that gap. Otherwise tied events share the riser time.
- Handling of the risk table:
  - Every interval reconciles exactly.
  - The table sometimes demanded fewer censorings than there were tick candidates. The unused candidates are listed in `ipd_log.json` under `ticks_not_used`. Examples: A at 18.44 and 19.06, which are riser artefacts of two-event gaps, and A at 7.51–10.35.
  - Sometimes the table demanded more censorings than there were visible ticks. These unmarked censorings were placed uniformly: A 24–30 (1) and 30–36 (1); B 24–30 (2) and 30–36 (3).
- Nobody is left at risk at 36 months. The last records are at the drawn curve ends (A 33.76, B 35.63). No follow-up beyond the drawn curve was invented.

## Verification (`code/checks.py` -> `checks.json`)
- The committed CSV is reloaded, and the right-continuous KM is recomputed from it.
- Plateau check:
  - It compares the reconstructed KM with every measured plateau at least 4 px wide: 43 in A and 45 in B, including the tails.
  - The tolerance is ±1.5 px (0.002) plus half of a one-event drop at the current risk set, because integer counts can't match finer than that.
  - Result: all pass, with a largest absolute residual of 0.0014.
  - Tail at the last plateau: A 0.1659 reconstructed vs 0.1673 measured; B 0.2629 vs 0.2627.
- Every risk-table count, taken as the number with observed_time ≥ t, matches exactly for both arms. Arm sizes are 100/100, and the event indicators are integers 0/1.
- These checks confirm consistency with the curve and table I measured. They do not show that the reconstruction is unique.
- The SHA-256 of the final CSV is recorded in `checks.json`.

## Sensitivity (`sensitivity.csv`, one alternative)
- In the alternative, extra unmarked censorings are placed at visible tick times (tick multiplicity) instead of uniformly. It also reconciles all risk counts and passes all curve checks.
- Comparison at the common supported horizon of 33.76 months:

| Arm | S(H) primary | S(H) alternative | Area 0–H primary | Area 0–H alternative |
|---|---|---|---|---|
| A | 0.166 | 0.165 | 13.78 | 13.77 |
| B | 0.263 | 0.248 | 19.31 | 19.26 |

- This single alternative is not a confidence interval or a bound on reconstruction error. The primary allocation was chosen in advance (uniform placement of unmarked censorings), not by its effect on the between-arm contrast.

## Unresolved limitations
- The location of the third censoring in A before 6 months is uncertain. The table requires 3 censorings; only 4.84 and 5.66 are visually clear. The 3.52 candidate, used as the third, lies in the blue/orange overlap region and may be an artefact.
- Blue steps hidden under orange (0–4 months) are inferred from the occlusion rule. Their exact times carry about ±0.1 month of uncertainty.
- Exact censoring times within an interval are identified only where ticks are visible. Censoring after the last event in each arm is anchored to visible ticks plus the unmarked extras; a flat tail does not identify the censoring distribution.
- Event times have a resolution of about ±0.05 month (2 px).

## Reproduction
From the work directory:
`python3 output/code/extract.py ../input/figure.png output && python3 output/code/reconstruct.py output/measured_curves.json ../input/manifest.json output && python3 output/code/reconstruct.py output/measured_curves.json ../input/manifest.json output --alt && python3 output/code/checks.py output`.
A clean rerun reproduced SHA-256 e098f30f…4ce87b for `ipd.csv`.
Environment: Python 3.12.14, numpy 2.5.3, pandas 3.0.6, Pillow 12.3.0 (R was not used; the runtime provided Python only).
