"""Reload committed CSV(s), recompute right-continuous KM, compare to measurements & risk table.
Usage: python checks.py [outdir]"""
import sys, json, hashlib, os, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
M = json.load(open(os.path.join(out, 'measured_curves.json')))
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 64, 40, 25, 17, 8, 0], 'B': [100, 73, 62, 46, 42, 16, 0]}
N = {'A': 100, 'B': 100}
PX = 1 / 750  # one pixel in survival units

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; T, S, NR = [0.0], [1.0], []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n
        T.append(u); S.append(s)
    return np.array(T), np.array(S)

def S_at(T, S, x):  # right-continuous step evaluation
    return float(S[np.searchsorted(T, x, side='right') - 1])

def nrisk(df, x): return int((df.observed_time >= x).sum())

def check(fn):
    df = pd.read_csv(os.path.join(out, fn))
    res = {'file': fn, 'sha256': hashlib.sha256(open(os.path.join(out, fn), 'rb').read()).hexdigest(),
           'columns_ok': list(df.columns) == ['group', 'observed_time', 'event'], 'arms': {}}
    for g in 'AB':
        d = df[df.group == g]; T, S = km(d); R = M[g]
        a = {'n': len(d), 'n_expected': N[g], 'n_pass': len(d) == N[g],
             'event_integer_01': bool(d.event.isin([0, 1]).all()),
             'times_finite_nonneg': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
             'events': int(d.event.sum()), 'censored': int((d.event == 0).sum()),
             'supplied_event_total': 'unavailable (not in manifest)', 'max_time': float(d.observed_time.max())}
        rk = []
        for x, nt in zip(RISK_T, RISK[g]):
            nr = nrisk(d, x); rk.append({'t': x, 'table': nt, 'reconstructed': nr, 'residual': nr - nt,
                                          'status': 'pass' if nr == nt else 'fail'})
        a['risk_table'] = rk
        cmp = []
        for p in R['plateaus']:
            if p['x1'] - p['x0'] < 3: continue
            x = (p['t0'] + p['t1']) / 2; rec = S_at(T, S, x)
            n = max(nrisk(d, x), 1)
            # tolerance: +-1.5 px line-centre reading plus half a one-event step at that risk set
            tol = 1.5 * PX + 0.5 * rec / n
            cmp.append({'t': round(x, 3), 'measured': round(p['s'], 4), 'reconstructed': round(rec, 4),
                        'residual': round(rec - p['s'], 4), 'tol': round(tol, 4),
                        'status': 'pass' if abs(rec - p['s']) <= tol else 'fail'})
        a['curve_checks'] = cmp
        a['curve_pass'] = sum(c['status'] == 'pass' for c in cmp); a['curve_n'] = len(cmp)
        a['max_abs_residual'] = max(abs(c['residual']) for c in cmp)
        last = R['plateaus'][-1]
        a['tail_check'] = {'t': round(last['t1'], 3), 'measured': round(last['s'], 4),
                           'reconstructed': round(S_at(T, S, last['t1']), 4),
                           'curve_end_measured': round(max([R['t_end']] + [k['t'] for k in R['ticks']]), 3),
                           'last_record_time': float(d.observed_time.max())}
        res['arms'][g] = a
    return res, df

res, df = check('ipd.csv')
out_j = {'primary': res}
if os.path.exists(os.path.join(out, 'sensitivity.csv')):
    rs, ds = check('sensitivity.csv')
    H = min(df.groupby('group').observed_time.max().min(), ds.groupby('group').observed_time.max().min())
    comp = {'common_horizon_months': float(H)}
    for g in 'AB':
        row = {}
        for nm, d in (('primary', df), ('sensitivity', ds)):
            T, S = km(d[d.group == g]); grid = np.r_[T[T < H], H]
            area = float(np.sum(np.diff(grid) * S[:len(grid) - 1]))
            row[nm] = {'S_at_H': round(S_at(T, S, H), 4), 'area_0_H': round(area, 3)}
        comp[g] = row
    out_j['sensitivity'] = {'file_checks': {g: {'risk_table_all_pass': all(r['status'] == 'pass' for r in rs['arms'][g]['risk_table']),
                                                  'curve_pass': f"{rs['arms'][g]['curve_pass']}/{rs['arms'][g]['curve_n']}"} for g in 'AB'},
                            'sha256': rs['sha256'], 'same_horizon_comparison': comp}
json.dump(out_j, open(os.path.join(out, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    a = res['arms'][g]
    print(g, a['n'], a['events'], a['censored'], 'risk', [r['status'] for r in a['risk_table']],
          'curve %d/%d maxres %.4f' % (a['curve_pass'], a['curve_n'], a['max_abs_residual']), a['tail_check'])
    print('  fails:', [c for c in a['curve_checks'] if c['status'] == 'fail'])
if 'sensitivity' in out_j: print(json.dumps(out_j['sensitivity']))
print(res['sha256'])
