"""Reconstruct IPD from measured KM steps/ticks + transcribed number-at-risk table.
Usage: python reconstruct.py [measured_curves.json] [manifest.json] [outdir] [--alt]
Own implementation (interval-wise, Guyot-style logic); no KM-to-IPD package used.
"""
import sys, json, os, hashlib, numpy as np, pandas as pd
args = [a for a in sys.argv[1:] if not a.startswith('--')]
ALT = '--alt' in sys.argv
meas_p = args[0] if len(args) > 0 else 'output/measured_curves.json'
man_p = args[1] if len(args) > 1 else '../input/manifest.json'
out = args[2] if len(args) > 2 else 'output'
man = json.load(open(man_p)); SEED = man['code_seed']
np.random.seed(SEED)  # recorded; the algorithm itself is deterministic
M = json.load(open(meas_p))
# Number at risk, transcribed by eye from the table printed under the figure
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 64, 40, 25, 17, 8, 0], 'B': [100, 73, 62, 46, 42, 16, 0]}

# Ticks confirmed by visual inspection of a 5x zoom (work_tmp/viz.png): the 5.66-month
# blue tick overlaps a riser, so the automatic width test under-rates it.
VISUAL_CONFIRMED = {'A': [5.66]}

def tick_conf(k, plats, g=None):
    if any(abs(k['t'] - v) < 0.03 for v in VISUAL_CONFIRMED.get(g, [])): return 2
    # 2 = tick lies on a plateau and rises 6.5-10.5 px above that plateau's line centre;
    # 1 = accepted candidate at/near a riser (could be an unresolved intermediate riser);
    # 0 = rejected candidate (used only if the risk table demands more censorings)
    if k.get('rejected'): return 0
    on = [p for p in plats if p['x0'] <= k['xc'] <= p['x1']]
    return 2 if (k['width'] >= 2 and any(6.5 <= p['cy'] - k['top'] <= 10.5 for p in on)) else 1

def simulate(n0, T0, T1, steps, cens, km0):
    """Return events [(t,d)], n_next, sse, km_end. Events precede censorings at ties."""
    evs, n, km, sse = [], n0, km0, 0.0
    cens = sorted(cens); ci = 0
    for s in steps:
        while ci < len(cens) and cens[ci] < s['t']: n -= 1; ci += 1
        if n <= 0: sse += 1.0; continue
        ds = np.arange(1, n + 1); kms = km * (1 - ds / n)
        d = int(ds[np.argmin(np.abs(kms - s['s_after']))])
        km = km * (1 - d / n); sse += (km - s['s_after']) ** 2
        evs.append((s, d)); n -= d
    n -= len(cens) - ci
    return evs, n, sse, km

def arm(g):
    R = M[g]; n_tot = man['groups'][g]; assert RISK[g][0] == n_tot
    ticks = [dict(k, conf=tick_conf(k, R['plateaus'], g)) for k in R['ticks']] + \
            [dict(k, rejected=True, conf=0) for k in R['rejected_tick_candidates']]
    # curve end = last drawn pixel or last accepted tick, whichever is later
    t_end = max([R['t_end']] + [k['t'] for k in R['ticks']])
    recs, km, log = [], 1.0, []
    for i in range(len(RISK_T) - 1):
        T0, T1 = RISK_T[i], RISK_T[i + 1]
        n0, n1 = RISK[g][i], RISK[g][i + 1]
        hi = min(T1, t_end + 1e-9)
        st = [s for s in R['steps'] if T0 <= s['t'] < T1]
        tk = sorted([k for k in ticks if T0 <= k['t'] < T1 and k['t'] <= t_end + 1e-9],
                    key=lambda k: (-k['conf'], k['t']))
        best = None
        for c in range(0, n0 + 1):
            use = tk[:min(c, len(tk))]; m = c - len(use)
            ct = [k['t'] for k in use]
            if m > 0:
                if not ALT:   # primary: extra censorings spread uniformly over interval
                    ct += list(T0 + (np.arange(m) + 0.5) * (hi - T0) / m)
                else:         # alternative: extras = multiplicity at visible ticks (else interval end)
                    base = [k['t'] for k in tk if k['conf'] > 0] or [hi - 1e-3]
                    ct += [base[j % len(base)] for j in range(m)]
            if i == len(RISK_T) - 2 and m >= 0:
                # final interval: nobody may remain beyond the drawn curve end
                ct = [min(x, t_end) for x in ct]
            evs, nn, sse, kme = simulate(n0, T0, T1, st, ct, km)
            score = (abs(nn - n1) * 10.0 + sse * 1e3 + 1e-3 * abs(c - sum(k['conf'] > 0 for k in tk)))
            if best is None or score < best[0]: best = (score, c, ct, evs, nn, kme, len(use), m)
        score, c, ct, evs, nn, kme, nvis, m = best
        km = kme
        for s, d in evs:
            if d > 1 and s['gap_cols'] > 8:
                ts = np.linspace(s['t_lo'], s['t_hi'], d)
            else: ts = [s['t']] * d
            recs += [(g, float(t), 1) for t in ts]
        recs += [(g, float(t), 0) for t in ct]
        log.append({'ticks_used': [round(k['t'], 3) for k in tk[:min(c, len(tk))]],
                    'ticks_not_used': [round(k['t'], 3) for k in tk[min(c, len(tk)):]],'interval': [T0, T1], 'n_start': n0, 'n_next_table': n1, 'n_next_model': int(nn),
                    'events': int(sum(d for _, d in evs)), 'censored': c, 'from_ticks': nvis,
                    'extra_unmarked': m, 'visible_tick_candidates': len(tk),
                    'high_conf_ticks': sum(k['conf'] == 2 for k in tk)})
    assert len(recs) == n_tot, (g, len(recs))
    return recs, log

allrecs, logs = [], {}
for g in 'AB':
    r, l = arm(g); allrecs += r; logs[g] = l
    for row in l: print(g, row)
df = pd.DataFrame(allrecs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
fn = 'sensitivity.csv' if ALT else 'ipd.csv'
tmp = os.path.join(out, fn + '.tmp')
df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(out, fn))
json.dump({'seed': SEED, 'alt': ALT, 'intervals': logs}, open(os.path.join(out, fn.replace('.csv', '_log.json')), 'w'), indent=1)
print('wrote', fn, len(df), hashlib.sha256(open(os.path.join(out, fn), 'rb').read()).hexdigest())
