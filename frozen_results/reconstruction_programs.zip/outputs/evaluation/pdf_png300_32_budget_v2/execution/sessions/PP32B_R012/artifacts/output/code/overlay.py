import numpy as np, pandas as pd
from PIL import Image, ImageDraw
im=Image.open('../input/figure.png').convert('RGB')
z=im.crop((395,280,510,440)).resize((575,800),Image.NEAREST)
d=pd.read_csv('output/ipd.csv'); ov=im.copy(); dr=ImageDraw.Draw(ov)
for g in 'AB':
  x=d[d.group==g].sort_values('observed_time'); n=len(x); s=1; pts=[(269.5,179.5)]
  for t,grp in x.groupby('observed_time'):
    e=grp.event.sum(); px=269.5+40*t
    if e: pts.append((px,929.5-750*s)); s*=1-e/n; pts.append((px,929.5-750*s))
    n-=len(grp)
  pts.append((px,929.5-750*s)); dr.line(pts,fill=(0,0,0),width=1)
ov=ov.crop((260,160,1720,940))
W=Image.new('RGB',(575+ov.width, max(800,ov.height)),'white'); W.paste(z,(0,0)); W.paste(ov,(575,0)); W.save('output/overlay_zoom.png')
