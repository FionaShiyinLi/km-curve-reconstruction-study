"""Measure KM step curves and censor ticks from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]
Calibration (from labelled axis ticks, detected in probe step and re-checked here):
  x: pixel 269.5 -> 0 months, 1709.5 -> 36 months (tick pairs 269/270 ... 1709/1710)
  y: pixel 179.5 -> S=1.0, 929.5 -> S=0.0 (tick pairs 179/180 ... 929/930)
"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(fig).convert('RGB')).astype(int)
r, g, b = im[..., 0], im[..., 1], im[..., 2]
dark = (r < 80) & (g < 80) & (b < 80)
# verify axis anchors
xt = [x for x in range(im.shape[1]) if dark[936:940, x].all()]
yt = [y for y in range(im.shape[0]) if dark[y, 261:265].all()]
assert {269, 270, 1709, 1710} <= set(xt) and {179, 180, 929, 930} <= set(yt), (xt, yt)
X0, X36, Y1, Y0 = 269.5, 1709.5, 179.5, 929.5
t_of = lambda x: (x - X0) * 36 / (X36 - X0)
s_of = lambda y: (Y0 - y) / (Y0 - Y1)
BLUE = (r == 31) & (g == 119) & (b == 180)
ORNG = (r == 255) & (g == 127) & (b == 14)
Y_TOP, Y_BOT = 170, 925   # plot area rows (exclude legend)

def runs(colmask):
    idx = np.nonzero(colmask)[0]
    if len(idx) == 0: return []
    br = np.nonzero(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br + 1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st + Y_TOP, en + Y_TOP))

def measure(mask, occluder, name):
    m = mask[Y_TOP:Y_BOT]; oc = occluder[Y_TOP:Y_BOT]
    xs = np.nonzero(m.any(0))[0]; xmin, xmax = xs.min() + 0, xs.max()
    thin = {}; occl = {}; top_px = {}
    for x in range(xmin, xmax + 1):
        th = [(a, c) for a, c in runs(m[:, x]) if c - a + 1 <= 6]
        if th: thin[x] = min(th)
        occl[x] = [(a, c) for a, c in runs(oc[:, x]) if c - a + 1 <= 6]
        col = np.nonzero(m[:, x])[0]
        if len(col): top_px[x] = int(col.min()) + Y_TOP
    cy = {x: (a + c) / 2 for x, (a, c) in thin.items()}
    # occlusion fill: a column without own thin line but with an occluder line lying
    # between own previous and next measured levels is taken to be hidden under it
    filled = {}
    known = sorted(cy)
    for x in range(xmin, xmax + 1):
        if x in cy or not occl[x]: continue
        prev = [cy[k] for k in known if k < x]; nxt = [cy[k] for k in known if k > x]
        if not prev or not nxt: continue
        for a, c in occl[x]:
            yo = (a + c) / 2
            if prev[-1] - 1 <= yo <= nxt[0] + 1: filled[x] = yo; break
    lev = dict(cy); lev.update(filled)
    # plateaus = maximal runs of equal level (+-1 px); gaps are risers or tick columns
    plats = []
    for x in sorted(lev):
        y = lev[x]
        if plats and abs(plats[-1]['cy'] - y) <= 1.0:
            p = plats[-1]; p['x1'] = x; p['ys'].append(y); p['cy'] = float(np.median(p['ys']))
            p['occ'] += x in filled
        else:
            plats.append({'x0': x, 'x1': x, 'ys': [y], 'cy': y, 'occ': int(x in filled)})
    clean = []   # enforce monotone non-increasing survival (drop upward artefacts)
    for p in plats:
        if clean and p['cy'] < clean[-1]['cy'] - 1: continue
        if clean and abs(p['cy'] - clean[-1]['cy']) <= 1:
            clean[-1]['x1'] = p['x1']; clean[-1]['occ'] += p['occ']; continue
        clean.append(p)
    # tick candidates: own-colour pixels > 3 px above the local line top
    above = {}
    for x in range(xmin, xmax + 1):
        nb = [thin[k][0] for k in range(x - 6, x + 7) if k in thin]
        if nb and x in top_px and top_px[x] < min(nb) - 3: above[x] = top_px[x]
    cand = []
    for x in sorted(above):
        if cand and x == cand[-1]['x1'] + 1: cand[-1]['x1'] = x; cand[-1]['top'] = min(cand[-1]['top'], above[x])
        else: cand.append({'x0': x, 'x1': x, 'top': above[x]})
    ticks, rejected = [], []
    for k in cand:
        xc = (k['x0'] + k['x1']) / 2
        near = [p for p in clean if p['x0'] - 4 <= xc <= p['x1'] + 4]
        hs = [p['cy'] - k['top'] for p in near]
        rec = {'x0': k['x0'], 'x1': k['x1'], 'xc': xc, 't': t_of(xc), 'width': k['x1'] - k['x0'] + 1,
               'top': k['top'], 'h_rel_adjacent_levels': hs}
        (ticks if any(6 <= h <= 11.5 for h in hs) else rejected).append(rec)
    steps = []
    for a, bb in zip(clean[:-1], clean[1:]):
        steps.append({'x_a1': a['x1'], 'x_b0': bb['x0'], 't_lo': t_of(a['x1'] + 2.5), 't_hi': t_of(bb['x0'] - 2.5),
                      't': t_of((a['x1'] + bb['x0']) / 2), 's_before': s_of(a['cy']), 's_after': s_of(bb['cy']),
                      'gap_cols': int(bb['x0'] - a['x1'])})
    return {'name': name, 'x_first': int(xmin), 'x_last': int(xmax), 't_end': t_of(xmax - 1.5),
            'n_occlusion_filled_cols': len(filled),
            'plateaus': [{'x0': int(p['x0']), 'x1': int(p['x1']), 't0': t_of(p['x0']), 't1': t_of(p['x1']),
                          'cy': p['cy'], 's': s_of(p['cy']), 'occluded_cols': p['occ']} for p in clean],
            'steps': steps, 'ticks': ticks, 'rejected_tick_candidates': rejected}

A = measure(BLUE, ORNG, 'A'); B = measure(ORNG, BLUE, 'B')
json.dump({'calibration': {'X0': X0, 'X36': X36, 'Y1': Y1, 'Y0': Y0}, 'A': A, 'B': B},
          open(f'{out}/measured_curves.json', 'w'), indent=1)
for R in (A, B):
    print(R['name'], 'x', R['x_first'], R['x_last'], 'nplat', len(R['plateaus']), 'nticks', len(R['ticks']))
    print('  steps:', ' '.join('%.2f:%.3f>%.3f(g%d)' % (s['t'], s['s_before'], s['s_after'], s['gap_cols']) for s in R['steps']))
    print('  ticks:', ' '.join('%.2f' % k['t'] for k in R['ticks']))
    print('  rejected:', ' '.join('%.2f' % k['t'] for k in R['rejected_tick_candidates']))
