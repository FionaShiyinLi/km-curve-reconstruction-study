"""Reconstruct approximate participant-level records from the measured KM
curves (extracted_{A,B}.json from extract.py) plus the risk table read from
the figure. Own implementation of an interval-wise, Guyot-style algorithm.

Usage: python reconstruct.py [workdir_output]   (default: parent of this file)
Writes ipd.csv (primary, atomic), sensitivity.csv, checks.json.
"""
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np

SEED = 91158228  # manifest code seed; the algorithm is deterministic
np.random.seed(SEED)

HERE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / ".."

N = {"A": 100, "B": 100}  # manifest group sizes
RISK_T = [0, 6, 12, 18, 24, 30, 36]  # risk-table times (months), read by eye
RISK = {"A": [100, 66, 42, 28, 23, 5, 0],
        "B": [100, 67, 44, 33, 25, 6, 0]}
# Manual pixel observation: in arm A the 1.0 line is hidden under arm B's
# 0.99 line; its top row (row 178) is visible in blue only to x=274, so arm A
# leaves 1.0 at about x=273 (t~0.09), then 0.99->0.98 at t=0.55.
HIDDEN_LEVELS = {"A": [(0.0875, 0.99)]}
SKIPPED = []  # drops rejected as sub-event-step artefacts (logged)
MIN_T = 0.025  # one pixel; strokes at the y-axis are clamped to this time


def load(g):
    d = json.load(open(OUT / f"extracted_{g}.json"))
    segs = sorted(d["segments"], key=lambda s: (s["t_start"], -(s["t_end"] - s["t_start"])))
    # drop short tick/stroke blobs sharing a start with a longer segment
    clean = []
    for s in segs:
        if clean and abs(s["t_start"] - clean[-1]["t_start"]) < 0.03:
            continue
        if s["thick"] > 6 and (s["x1"] - s["x0"]) <= 10:
            continue
        clean.append(s)
    for t, S in HIDDEN_LEVELS.get(g, []):
        clean.append({"t_start": t, "t_end": t, "S": S, "manual": True})
    clean.sort(key=lambda s: s["t_start"])
    # step curve: (time, level) with drops only where level falls >= 2 px
    steps = [(0.0, 1.0)]
    for s in clean:
        if s["S"] < steps[-1][1] - 2 / 750:
            steps.append((max(s["t_start"], MIN_T), s["S"]))
        # small rises (<2 px) are measurement noise; larger ones are flagged
        elif s["S"] > steps[-1][1] + 2 / 750:
            print(f"warning {g}: level rise at t={s['t_start']:.3f}")
    ticks = []
    for k in d["ticks"]:
        m = 2 if (k["n_marks"] == 2 and all(k["isolated_arms"])) else 1
        ticks += [k["t"]] * m
    t_end = max(s["t_end"] for s in clean)
    return steps, sorted(ticks), t_end


def simulate(n0, S0, drops, cens):
    """March through one interval. drops: [(t, S_before_meas, S_after_meas)];
    cens: censor times. Events precede censorings at tied times."""
    n, S = n0, S0
    ev, ce = [], []
    skipped = SKIPPED
    ci = 0
    cens = sorted(cens)
    for t, Sb, Sa in drops:
        while ci < len(cens) and cens[ci] < t:
            ce.append(cens[ci]); n -= 1; ci += 1
        if n <= 0:
            break
        # d from measured relative drop applied to reconstructed KM value
        x = n * (1 - Sa / S)
        if x < 0.5:
            # drop smaller than half of one event step at this risk set:
            # treated as a measurement artefact (e.g. tick+stroke blob)
            skipped.append((round(t, 3), round(x, 2)))
            continue
        d = min(max(int(round(x)), 1), n)  # a drawn drop implies >= 1 event
        ev += [t] * d
        S *= 1 - d / n
        n -= d
    while ci < len(cens):
        ce.append(cens[ci]); n -= 1; ci += 1
    return n, S, ev, ce


def reconstruct(g, mode="uniform"):
    steps, ticks, t_end = load(g)
    drops = [(steps[i][0], steps[i - 1][1], steps[i][1]) for i in range(1, len(steps))]
    recs, log = [], []
    n, S = N[g], 1.0
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        n_obs_end = RISK[g][k + 1]
        dk = [x for x in drops if lo <= x[0] < hi]
        tk = [t for t in ticks if lo <= t < hi]
        c_hi = min(hi, t_end) if n_obs_end == 0 else hi
        extra, dropped_ticks = 0, 0
        for _ in range(300):
            if mode == "uniform":
                ex = [lo + (j + 0.5) * (c_hi - lo) / extra for j in range(extra)]
            else:  # sensitivity: extra censoring immediately after lo
                ex = [lo + 0.01 * (j + 1) for j in range(extra)]
            use_t = tk[:len(tk) - dropped_ticks] if dropped_ticks else tk
            n_end, S_end, ev, ce = simulate(n, S, dk, use_t + ex)
            diff = n_end - n_obs_end
            if diff == 0:
                break
            if diff > 0:
                extra += diff
            elif extra > 0:
                extra = max(0, extra + diff)
            elif dropped_ticks < len(tk):
                dropped_ticks += 1  # more removals than the risk table allows
            else:
                break
        log.append(dict(interval=[lo, hi], n_start=n, n_end_table=n_obs_end,
                        n_end_recon=n_end, events=len(ev), tick_censor=len(tk) - dropped_ticks,
                        ticks_dropped=dropped_ticks, extra_censor=extra,
                        resolved=bool(n_end == n_obs_end)))
        recs += [(t, 1) for t in ev] + [(t, 0) for t in ce]
        n, S = n_end, S_end
    if n > 0:  # anyone left (not expected: table shows 0 at 36)
        recs += [(t_end, 0)] * n
        log.append(dict(note=f"{n} left at end, censored at line end {t_end:.3f}"))
    log.append(dict(sub_step_drops_ignored=sorted(set(SKIPPED))))
    SKIPPED.clear()
    return recs, log, steps, t_end


def km(times, events):
    times, events = np.asarray(times, float), np.asarray(events, int)
    ut = np.unique(times[events == 1])
    S, out = 1.0, []
    for t in ut:
        nr = (times >= t).sum()
        d = ((times == t) & (events == 1)).sum()
        S *= 1 - d / nr
        out.append((t, S))
    return out


def step_eval(curve, t):
    """Right-continuous step function value at t for [(time, S)] drops."""
    S = 1.0
    for tt, s in curve:
        if tt <= t:
            S = s
        else:
            break
    return S


def rmst(curve, tau):
    pts = [(0.0, 1.0)] + [(t, s) for t, s in curve if t < tau]
    area = 0.0
    for i, (t, s) in enumerate(pts):
        t2 = pts[i + 1][0] if i + 1 < len(pts) else tau
        area += s * (t2 - t)
    return area


def write_atomic(path, rows):
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in rows:
            f.write(f"{g},{t:.4f},{e}\n")
    os.replace(tmp, path)


def main():
    rows, logs, meas = [], {}, {}
    for g in "AB":
        recs, log, steps, t_end = reconstruct(g)
        assert len(recs) == N[g], (g, len(recs))
        rows += [(g, max(t, 0.0), e) for t, e in sorted(recs)]
        logs[g], meas[g] = log, (steps, t_end)
    write_atomic(OUT / "ipd.csv", rows)
    alt = []
    alt_logs = {}
    for g in "AB":
        recs, log, _, _ = reconstruct(g, mode="early")
        assert len(recs) == N[g]
        alt += [(g, max(t, 0.0), e) for t, e in sorted(recs)]
        alt_logs[g] = log
    write_atomic(OUT / "sensitivity.csv", alt)

    # ---- checks from the committed file ----
    import pandas as pd
    df = pd.read_csv(OUT / "ipd.csv")
    sha = hashlib.sha256(open(OUT / "ipd.csv", "rb").read()).hexdigest()
    sdf = pd.read_csv(OUT / "sensitivity.csv")
    checks = {"csv_sha256": sha, "seed": SEED, "arms": {}}
    tau = 34.9  # common supported horizon: end of arm B's drawn curve (34.925)
    for g in "AB":
        d = df[df.group == g]
        steps, t_end = meas[g]
        cur = km(d.observed_time, d.event)
        drop_t = [t for t, _ in steps[1:]]
        grid = sorted(set([0.5 * i for i in range(1, 70)] + [t_end - 0.05]))
        grid = [t for t in grid if t < t_end and min(abs(t - x) for x in drop_t) > 0.1]
        comp = []
        for t in grid:
            sm, sr = step_eval(steps, t), step_eval(cur, t)
            nr = int((d.observed_time >= t).sum())
            tol = 0.5 * sm / max(nr, 1) + 0.0015
            comp.append(dict(t=t, measured=round(sm, 4), recon=round(sr, 4),
                             resid=round(sr - sm, 4), tol=round(tol, 4),
                             status="pass" if abs(sr - sm) <= tol else "fail"))
        risk = []
        for t, nt in zip(RISK_T, RISK[g]):
            nr = int((d.observed_time >= t).sum())
            risk.append(dict(t=t, table=nt, recon=nr, resid=nr - nt,
                             status="pass" if nr == nt else "fail"))
        da = sdf[sdf.group == g]
        cur_alt = km(da.observed_time, da.event)
        checks["arms"][g] = dict(
            n=int(len(d)), n_expected=N[g], events=int(d.event.sum()),
            event_indicator_integer=bool(d.event.isin([0, 1]).all()),
            max_time=float(d.observed_time.max()), drawn_curve_end=round(t_end, 3),
            supplied_event_total="unavailable (not in manifest)",
            curve_checks=comp,
            curve_fail=sum(c["status"] == "fail" for c in comp),
            tail_checks=[c for c in comp if c["t"] >= 28],
            risk_table=risk, interval_log=logs[g],
            sensitivity=dict(
                assumption="extra (unticked) censorings placed at the start of each risk interval instead of uniformly",
                horizon=tau, events=int(da.event.sum()),
                S_primary={str(t): round(step_eval(cur, t), 4) for t in (6, 12, 18, 24, 30, tau)},
                S_alt={str(t): round(step_eval(cur_alt, t), 4) for t in (6, 12, 18, 24, 30, tau)},
                RMST_primary=round(rmst(cur, tau), 3), RMST_alt=round(rmst(cur_alt, tau), 3),
                interval_log=alt_logs[g]))
    checks["curve_tolerance"] = ("0.5*S_measured/n_at_risk + 0.0015: half of one event step "
                                 "(integer-event rounding) plus ~1 px level reading error; "
                                 "times within 0.1 month of a measured drop are skipped")
    json.dump(checks, open(OUT / "checks.json", "w"), indent=1)
    for g in "AB":
        a = checks["arms"][g]
        print(g, "n", a["n"], "events", a["events"], "curve fails", a["curve_fail"],
              "/", len(a["curve_checks"]), "risk", [r["recon"] for r in a["risk_table"]])
        for L in a["interval_log"]:
            print("  ", L)
        s = a["sensitivity"]
        print("  sens RMST", s["RMST_primary"], s["RMST_alt"], "S", s["S_primary"], s["S_alt"])
    print("sha256", sha)


if __name__ == "__main__":
    main()
