"""Measure KM step curves and censor ticks from the raster figure.

Usage: python extract.py [path/to/figure.png] [outdir]
Writes <outdir>/extracted_A.json, extracted_B.json (segments, drops, ticks).
Calibration from axis tick marks found in the image (see calibrate()).
"""
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
FIG = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "../../../input/figure.png"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / ".."
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
PLOT_ROWS = (150, 945)  # rows containing the plotting panel (excludes legend)


def calibrate(a):
    dark = a.sum(2) < 200
    # x-axis ticks: short dark marks just below the axis line (row ~936)
    xaxis_rows = np.where(dark[:, 300:1700].sum(1) > 1000)[0]
    yaxis_cols = np.where(dark[200:900].sum(0) > 500)[0]
    ax_row = xaxis_rows.mean()
    ax_col = yaxis_cols.mean()
    trow = int(xaxis_rows.max()) + 6
    xt = np.where(dark[trow])[0]
    xt = xt[xt >= yaxis_cols.min()]
    groups = np.split(xt, np.where(np.diff(xt) > 1)[0] + 1)
    xcent = np.array([g.mean() for g in groups])  # labelled 0,6,...,36
    tcol = int(yaxis_cols.min()) - 6
    yt = np.where(dark[:int(ax_row) + 2, tcol])[0]
    groups = np.split(yt, np.where(np.diff(yt) > 1)[0] + 1)
    ycent = np.array([g.mean() for g in groups])  # labelled 1.0,0.8,...,0.0
    xlab = np.arange(0, 37, 6.0)
    ylab = np.linspace(1.0, 0.0, 6)
    assert len(xcent) == 7 and len(ycent) == 6, (xcent, ycent)
    px, bx = np.polyfit(xlab, xcent, 1)
    py, by = np.polyfit(ylab, ycent, 1)
    cal = dict(x_px_per_month=px, x0=bx, y_px_per_unit=py, y0=by,
               x_ticks_px=xcent.tolist(), y_ticks_px=ycent.tolist(),
               x_resid=(xcent - (px * xlab + bx)).tolist(),
               y_resid=(ycent - (py * ylab + by)).tolist())
    return cal


def bands(mask, minrun=6):
    """Horizontal line segments: row-runs of length>=minrun grouped over
    vertically adjacent rows with overlapping x-extent."""
    runs = []
    for y in range(mask.shape[0]):
        xs = np.where(mask[y])[0]
        if xs.size == 0:
            continue
        for g in np.split(xs, np.where(np.diff(xs) > 1)[0] + 1):
            if g.size >= minrun:
                runs.append([y, g[0], g[-1]])
    segs = []  # each: dict rows list, x0, x1
    for y, x0, x1 in runs:
        placed = False
        for s in segs:
            # attach to a band whose previous-row run overlaps this run by at
            # least half of the shorter run
            lx0, lx1 = s["lx0"], s["lx1"]
            ov = min(x1, lx1) - max(x0, lx0) + 1
            l0, l1 = x1 - x0 + 1, lx1 - lx0 + 1
            if s["ylast"] == y - 1 and ov >= 0.5 * min(l0, l1) and \
                    max(l0, l1) <= 1.6 * min(l0, l1):
                s["rows"].append((y, x0, x1))
                s["ylast"], s["lx0"], s["lx1"] = y, x0, x1
                placed = True
                break
        if not placed:
            segs.append({"rows": [(y, x0, x1)], "ylast": y, "lx0": x0, "lx1": x1})
    out = []
    for s in segs:
        r = np.array(s["rows"])
        # line body = rows where run is long; the extent common to the band
        ys = r[:, 0]
        out.append(dict(ytop=int(ys.min()), ybot=int(ys.max()),
                        yc=float((ys.min() + ys.max()) / 2),
                        x0=int(np.median(r[:, 1])), x1=int(np.median(r[:, 2])),
                        thick=int(ys.max() - ys.min() + 1)))
    return sorted(out, key=lambda d: d["x0"])


def refine_levels(own, other, segs):
    """Re-measure each band's centre from per-column 4-px line runs; where the
    run is truncated by the other arm's colour (occlusion), anchor on the
    visible edge. Returns segments with 'yc' refined and 'occluded' flag."""
    out = []
    for s in segs:
        cs = []
        occl = 0
        for x in range(s["x0"] + 1, s["x1"]):
            ys = np.where(own[s["ytop"] - 6:s["ybot"] + 7, x])[0] + s["ytop"] - 6
            if ys.size == 0:
                continue
            for g in np.split(ys, np.where(np.diff(ys) > 1)[0] + 1):
                if g[-1] < s["ytop"] or g[0] > s["ybot"]:
                    continue
                if g.size == 4:
                    cs.append((g[0] + g[-1]) / 2)
                elif g.size < 4:
                    if other[g[0] - 1, x]:
                        cs.append(g[-1] - 1.5); occl += 1
                    elif other[g[-1] + 1, x]:
                        cs.append(g[0] + 1.5); occl += 1
        s = dict(s)
        # 4-5 px bands are measured directly; only thin (occluded) or thick
        # (merged with ticks/strokes) bands are re-measured per column
        if s["thick"] not in (4, 5) and cs:
            s["yc"] = float(np.median(cs))
        elif (s["thick"] < 3 or s["thick"] > 6) and not cs:
            continue  # sliver/blob (tick+stroke union) without line pixels
        s["n_cols"] = len(cs)
        s["occluded_cols"] = occl
        out.append(s)
    # merge neighbouring bands at the same level (split by occlusion/ticks)
    out.sort(key=lambda d: d["x0"])
    merged = []
    for s in out:
        if merged and abs(s["yc"] - merged[-1]["yc"]) < 2 and s["x0"] <= merged[-1]["x1"] + 12:
            m = merged[-1]
            m["x1"] = max(m["x1"], s["x1"]); m["n_cols"] += s["n_cols"]
            m["ytop"] = min(m["ytop"], s["ytop"]); m["ybot"] = max(m["ybot"], s["ybot"])
        else:
            merged.append(s)
    return merged


def ticks(own, other, segs):
    """Censor ticks: 16-px vertical marks centred on the line. A column is a
    tick column if, relative to the band covering it, both the 6-px arm above
    and the 6-px arm below are coloured (own colour, or the other arm's
    colour where occluded, with at least one arm mostly own colour). A drop
    stroke fills only one side of its band, so it is not flagged."""
    either = own | other
    cols = []
    for x in range(own.shape[1]):
        for s in segs:
            if not (s["x0"] <= x <= s["x1"]):
                continue
            c = s["yc"]
            up = slice(int(round(c - 1.5)) - 6, int(round(c - 1.5)))
            dn = slice(int(round(c + 1.5)) + 1, int(round(c + 1.5)) + 7)
            if either[up, x].all() and either[dn, x].all() and \
                    max(own[up, x].sum(), own[dn, x].sum()) >= 4:
                cols.append((x, c))
    merged = []
    for x, c in cols:
        if merged and x - merged[-1]["xs"][-1] <= 1 and abs(c - merged[-1]["yc"]) < 2:
            merged[-1]["xs"].append(x)
        else:
            merged.append({"xs": [x], "yc": c})
    keep = []
    for m in merged:
        m["xc"] = float(np.mean(m["xs"]))
        m["width"] = len(m["xs"])
        # isolation: a tick arm is a ~2-px-wide mark, a drop stroke is 4 px
        # wide. Require at least one arm whose horizontal run (mid-arm row)
        # through the group is no wider than the group + 1 and <= 3 px, else
        # the "arms" are neighbouring drop strokes of a steep staircase.
        c = m["yc"]
        iso = []
        for yy in (int(round(c - 5.5)), int(round(c + 5.5))):
            row = either[yy]
            x = int(round(m["xc"]))
            if not row[x]:
                iso.append(False); continue
            l = x
            while row[l - 1]:
                l -= 1
            r = x
            while row[r + 1]:
                r += 1
            # the isolated arm must be drawn mainly in this arm's colour
            # (rejects crossings where the other curve fills an arm)
            arm = slice(yy - 2, yy + 3)
            own_frac = own[arm, x].mean()
            iso.append((r - l + 1) <= max(3, m["width"]) and own_frac >= 0.6)
        m["isolated_arms"] = iso
        del m["xs"]
        if any(iso):
            # two overlapping marks are indistinguishable from one; a group
            # >= 5 px wide is read as two adjacent marks (assumption)
            m["n_marks"] = 2 if m["width"] >= 5 else 1
            keep.append(m)
    return keep


def main():
    a = np.asarray(Image.open(FIG).convert("RGB")).astype(int)
    cal = calibrate(a)
    t = lambda x: (x - cal["x0"]) / cal["x_px_per_month"]
    s = lambda y: (y - cal["y0"]) / cal["y_px_per_unit"]
    r0, r1 = PLOT_ROWS
    for g, col in COLORS.items():
        m = np.zeros(a.shape[:2], bool)
        m[r0:r1] = (a[r0:r1] == col).all(2)
        other = np.zeros_like(m)
        oc = COLORS["B" if g == "A" else "A"]
        other[r0:r1] = (a[r0:r1] == oc).all(2)
        segs = refine_levels(m, other, bands(m))
        tk = ticks(m, other, segs)
        for sg in segs:
            sg["S"] = s(sg["yc"])
            # a drop's vertical stroke is 4 px wide and centred on the event
            # time; the lower segment starts at its left edge -> +1.5 px
            sg["t_start"] = t(sg["x0"] + 1.5)
            sg["t_end"] = t(sg["x1"] - 1.5)
        for k in tk:
            k["t"] = t(k["xc"])
            k["S_center"] = s(k["yc"])
        json.dump(dict(calibration=cal, segments=segs, ticks=tk),
                  open(OUT / f"extracted_{g}.json", "w"), indent=1, default=float)
        print(g, "segments", len(segs), "ticks", len(tk))
    print(json.dumps({k: v for k, v in cal.items()}, default=float))


if __name__ == "__main__":
    main()
