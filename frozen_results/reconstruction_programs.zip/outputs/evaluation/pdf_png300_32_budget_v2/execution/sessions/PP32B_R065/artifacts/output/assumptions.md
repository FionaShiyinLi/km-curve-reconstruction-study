# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster; flat colors: arm A = RGB(31,119,180), arm B = RGB(255,127,14), no antialiasing).
- `../input/manifest.json`: n = 100 per arm, time unit months, code seed 91158228. The manifest gives no arm-specific event totals, so event totals are unavailable as a constraint (they are not assumed to be zero).
- Number-at-risk table, read by eye from the figure at 0, 6, ..., 36 months: A 100/66/42/28/23/5/0; B 100/67/44/33/25/6/0. The table digits are crisp and I treat them as certain.

## Calibration (`code/extract.py`)
The axis tick marks are located in the image and fitted linearly (residuals < 1e-12 px). The labelled anchors 0 to 36 months map to x = 269.5 to 1709.5 (40 px/month), and survival 1.0 to 0.0 maps to y = 179.5 to 929.5 (750 px per unit). No global rescaling was applied. Both arms start at the 1.0 gridline.

## Curve measurement
- Horizontal line segments are row runs at least 6 px long, grouped across rows. Each level is the center of the 4 px line band.
- Bands partly hidden under the other arm are anchored on their visible edge (flagged `occluded_cols` in `extracted_*.json`). Blobs formed by a tick plus a drop stroke are discarded.
- An event time is the center of the vertical drop stroke.
- Manual observation: arm A's 1.0 line is hidden under arm B's 0.99 line. Its top row is visible in blue only up to x = 274, so arm A's first drop (1.0 to 0.99) is placed at t = 0.0875. This is the only hand-entered measurement.
- Arm B drops at the y-axis (event at about t = 0). That time is clamped to one pixel (0.025 months).
- Drops smaller than half an event step at the current risk set are treated as artifacts rather than events. The only one found is arm B at 28.2 months, a tick-plus-stroke blob (logged in checks.json).
- The extracted segments and ticks are saved in `extracted_A.json` and `extracted_B.json`. `crop_check.png` is the zoom used to confirm ticks visually.

## Censor marks
- A tick is a 16 px vertical mark with coloured arms above and below the line. At least one arm must be isolated (at most 3 px wide) and mostly the arm's own colour. This rejects adjacent drop strokes and places where the two curves cross.
- Each visible tick counts as one censoring. The exception is a tick group at least 5 px wide with both arms isolated, which is read as two overlapping marks. Only arm B's final mark at 34.91 qualifies.
- Tick visibility does not establish multiplicity. Any further censorings come only from the risk table (next section).
- Detected ticks: A 19, B 23 (counting the double mark).

## Algorithm (`code/reconstruct.py`, my own Guyot-style implementation)
The algorithm works through the risk-table intervals [t_k, t_k+1) in order:
1. Walk the measured drops in time order. At each drop, d = round(n_risk x (1 - S_after,measured / S_before,reconstructed)), with d at least 1. Anchoring on the reconstructed survival value prevents rounding drift.
2. Ticks are censorings at their measured times. Events precede censorings at tied times.
3. If the interval ends with more people at risk than the table shows, extra censorings with no visible tick are added. They are spread uniformly over the interval (**assumption**). The count is iterated until the reconstructed number at risk at t_k+1 (records with observed_time >= t_k+1) equals the table.
4. Tick censorings would be removed only if they exceeded the table. This never happened.
5. In the last interval the table shows 0 at 36. Extra censorings would be capped at the end of the drawn line, but none were needed. Arm A's five remaining participants are censored at its five visible tail ticks, the last at 35.525. Arm B has two events and four censorings, the last two at 34.91.

Censoring without a visible tick was needed in arm A (1 in 0–6 and 2 in 24–30 months) and arm B (3 in 24–30 months). Their exact times are not identified by the figure. The algorithm is deterministic; the seed is recorded but not used.

## Result and checks (`checks.json`, regenerated from the final CSV)
- Arm A has 78 events and 22 censorings; arm B has 73 events and 27 censorings.
- All 7 risk-table counts match exactly in both arms.
- The right-continuous KM curve from the saved CSV was compared with the measured step curve every 0.5 month and just before the end of each line. Times within 0.1 month of a measured drop were skipped. All 45 A and 47 B comparisons are within tolerance.
- The tolerance is half an event step (0.5·S/n_risk), from integer rounding, plus 0.0015 for about 1 px reading error.
- The largest tail residuals are about +0.005 (arm A after 27.8 months: reconstructed 0.178 vs measured 0.173) and +0.0014 (arm B after 30.5 months).
- There are no supplied event totals to check against.

## Sensitivity (`sensitivity.csv`, one alternative)
The alternative places the unticked censorings at the start of each interval instead of uniformly. The common supported horizon is τ = 34.9 months, where arm B's drawn curve ends.

| Arm | RMST(τ), primary | RMST(τ), alternative | S(30), primary | S(30), alternative |
|---|---|---|---|---|
| A | 14.395 | 14.315 | 0.178 | 0.171 |
| B | 15.249 | 15.201 | 0.204 | 0.198 |

Survival at 6, 18 and 24 months is essentially unchanged. This is one alternative, not an uncertainty bound.

## Limitations
- The individual times of unticked censorings, and of ticks hidden under the other curve, are not identified.
- Drops at tied or nearly tied times (within 1–2 px, about 0.05 month) cannot be separated. Event times carry roughly ±0.05 month of pixel uncertainty.
- The first events near t = 0 (A at 0.0875, B at 0.025) are within one or two pixels of the axis.
- The primary uniform-spread rule was chosen before any comparison of the arms.
- Correction cycles used after the first complete file: 1. A sub-step blob at B 28.2 months had been counted as an event; after the fix both arms were re-checked.
