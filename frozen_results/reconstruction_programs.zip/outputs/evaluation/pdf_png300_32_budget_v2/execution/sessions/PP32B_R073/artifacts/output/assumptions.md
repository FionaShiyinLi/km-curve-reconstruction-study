# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`: a vector PDF. I read the step curves, censor ticks, axis ticks, tick labels and number-at-risk text directly from the PDF objects with `pdfplumber`. No rasterization or OCR was needed.
- `../input/manifest.json`: n = 100 per arm, time in months, code seed 1834025855. The code records the seed but uses no randomness.
- The manifest has no arm-specific event totals, so that check is marked unavailable.

## Measurement
- **Calibration.** I fitted a linear map to the labelled axis ticks: x ticks for 0–36 months at 57.6 pt per 6 months, and y ticks for survival 0–1.0 at 180 pt per unit. The maximum residual at the anchors is about 1e-14. No global rescaling or origin correction was applied. Both curves start exactly at (0, 1.0).
- **Arm identity.** I identified the arms by stroke color, using the legend line segments next to the "Group A" (blue) and "Group B" (orange) labels.
- **Extracted data.** The curve vertices and censor-tick coordinates are saved in `extracted_observations.json`.
- **Censor ticks.** Each tick is a separate vertical line object (4 pt long, centered on the curve), and I counted each object as one censoring. Ticks that nearly coincide are distinct objects at distinct x positions (for example, arm B at 323.26, 323.45 and 323.54 pt), so each was counted.
- **Hidden ticks.** Exactly duplicated, fully hidden tick objects would not be detectable. However, the event count plus the tick count equals n = 100 exactly in both arms, and the risk table is reproduced exactly. Both facts are consistent with there being no hidden ticks.

## Algorithm (own code, `code/reconstruct.py`)
1. **Sequential KM inversion.** I walked through the vertical drops in time order. Before each drop, the number at risk n is reduced by the ticks strictly before the drop time. The number of events at the drop is d = n(1 − S_after/S_before).
2. **Evidence for d = 1.** Every drop gave a raw d within 5e-5 of 1, which is why d = 1 was assigned. This value is not a default: it follows from the exact vector ratio combined with the independently tracked n at risk. A tied pair of events at the same n would have produced a raw d near 2.
3. **Censoring times.** Censored records are placed at the tick x positions. After all drops and ticks, no participants remained unaccounted for in either arm (0 extra), so no censoring times were invented. The last record in each arm is the final tick: A at 35.52 and B at 34.93 months. Both are before 36, which is consistent with the displayed 0 at risk at 36.
4. **Rounding and ties.** Times are rounded to 4 decimal places. No censor tick coincides with an event time.

## Results and checks (`code/checks.py` → `checks.json`)
- **Records.** A has 100 records (78 events, 22 censored). B has 100 records (73 events, 27 censored).
- **Curve agreement.** I reloaded `ipd.csv` and recomputed the right-continuous KM step function, then evaluated it at the midpoint of every horizontal segment and at the curve end (79 points in A, 74 in B). The maximum absolute residual is 5e-6, against a tolerance of 0.0015; the tolerance is set well below one 1/100 step, and the residual reflects 4-decimal time rounding.
- **Risk table.** At 0, 6, 12, 18, 24, 30 and 36 months, the counts of records with observed_time ≥ t match the displayed values exactly in both arms (A: 100, 66, 42, 28, 23, 5, 0; B: 100, 67, 44, 33, 25, 6, 0).
- **Supplied event totals.** Unavailable (not in the manifest).

## Limitations
- Event and censoring times are known only to the precision of the plotted coordinates, not the original data values.
- The reconstruction assumes the plotted curve is the KM estimator and that each tick object represents one censoring. The exact agreement with n and the risk table supports this, but it cannot rule out compensating errors that I did not detect.
- **No sensitivity analysis.** No alternative allocation was run, and `sensitivity.csv` was not produced. Once the event counts and tick positions are fixed, the vector geometry leaves no materially different feasible allocation: n, the risk table and the curve are all matched with zero leftover participants.
