"""KM reconstruction from vector PDF objects (own code; no KM-to-IPD package).
Usage: python reconstruct.py [input_dir] [output_dir]
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), '..')
man = json.load(open(os.path.join(IN, 'manifest.json')))
SEED = man['code_seed']; np.random.seed(SEED)  # no randomness used; seed recorded
pg = pdfplumber.open(os.path.join(IN, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks (PDF top-coordinates)
xt = sorted({round(l['x0'], 3) for l in pg.lines if abs(l['x0']-l['x1']) < 1e-6 and l['stroking_color'] == (0.0, 0.0, 0.0) and abs(l['bottom']-l['top']-3) < .01})
yt = sorted({round(l['top'], 3) for l in pg.lines if abs(l['top']-l['bottom']) < 1e-6 and l['stroking_color'] == (0.0, 0.0, 0.0) and abs(l['x1']-l['x0']-3) < .01})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, .8, .6, .4, .2, 0.0]   # tick labels read from PDF text (top->bottom)
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
cal = dict(x_ticks_pt=xt, x_labels=xlab, y_ticks_pt=yt, y_labels=ylab, months_per_pt=ax, x0=bx, surv_per_pt=ay, y0=by,
           x_resid=float(np.max(np.abs(np.polyval([ax, bx], xt)-xlab))), y_resid=float(np.max(np.abs(np.polyval([ay, by], yt)-ylab))))
T = lambda x: ax*x+bx; S = lambda y: ay*y+by

COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}  # legend: blue line next to "Group A"
risk_times = [0, 6, 12, 18, 24, 30, 36]
risk = {'A': [100, 66, 42, 28, 23, 5, 0], 'B': [100, 67, 44, 33, 25, 6, 0]}  # read from PDF text; x positions align to ticks

res, ipd, obs = {}, [], {}
for g, col in COL.items():
    N = man['groups'][g]
    cv = [c for c in pg.curves if c['stroking_color'] == col][0]
    pts = [(T(x), S(y)) for x, y in cv['pts']]
    # step function vertices: horizontal then vertical segments; collect drops
    steps = []  # (time, S_before, S_after)
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1-t0) < 1e-9 and s1 < s0-1e-9:
            steps.append((t1, s0, s1))
    t_end = pts[-1][0]; s_end = pts[-1][1]
    ticks = sorted(T(l['x0']) for l in pg.lines if l['stroking_color'] == col and abs(l['bottom']-l['top']-4) < .01)
    tick_S = {round(T(l['x0']), 6): S((l['top']+l['bottom'])/2) for l in pg.lines if l['stroking_color'] == col and abs(l['bottom']-l['top']-4) < .01}
    obs[g] = dict(curve_vertices=[[round(a, 5), round(b, 5)] for a, b in pts], censor_ticks=[[round(t, 5), round(tick_S[round(t, 6)], 5)] for t in ticks], curve_end=[t_end, s_end])
    # sequential KM inversion: n at risk decremented by events and censor ticks strictly before each event time
    n = N; ci = 0; rec = []; dlog = []
    for (t, sb, sa) in steps:
        while ci < len(ticks) and ticks[ci] < t:
            rec.append((ticks[ci], 0)); n -= 1; ci += 1
        dr = n*(1-sa/sb); d = int(round(dr))
        dlog.append(dict(t=t, S_before=sb, S_after=sa, n_risk=n, d_raw=dr, d=d))
        rec += [(t, 1)]*d; n -= d
    while ci < len(ticks):
        rec.append((ticks[ci], 0)); n -= 1; ci += 1
    extra = n
    # remaining participants not accounted by visible ticks: censored at curve end (last plotted time) -- assumption
    rec += [(t_end, 0)]*extra
    for t, e in rec: ipd.append((g, t, e))
    res[g] = dict(n=N, n_steps=len(steps), n_ticks=len(ticks), events=sum(e for _, e in rec), extra_censored_at_end=extra,
                  t_end=t_end, S_end=s_end, max_abs_d_rounding=max(abs(x['d_raw']-x['d']) for x in dlog), drops=dlog)

df = pd.DataFrame(ipd, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(4)
tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
json.dump(dict(calibration=cal, groups=obs), open(os.path.join(OUT, 'extracted_observations.json'), 'w'), indent=1)
json.dump(dict(seed=SEED, summary={g: {k: v for k, v in r.items() if k != 'drops'} for g, r in res.items()},
               drops={g: r['drops'] for g, r in res.items()}), open(os.path.join(OUT, 'reconstruction_log.json'), 'w'), indent=1)
for g, r in res.items(): print(g, {k: v for k, v in r.items() if k != 'drops'})
print(cal)
