"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..')
csv = os.path.join(OUT, 'ipd.csv'); sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); ex = json.load(open(os.path.join(OUT, 'extracted_observations.json')))
risk = {'A': [100, 66, 42, 28, 23, 5, 0], 'B': [100, 67, 44, 33, 25, 6, 0]}; rt = [0, 6, 12, 18, 24, 30, 36]
TOL = 0.0015  # vector coordinates exact to ~1e-5; tolerance < one 1/100 step (vertical step 0.0055 per pt -> ~0.3pt)
def km(d):
    t = np.sort(d.observed_time.unique()); s = 1.; out = []
    for u in t:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1-e/n; out.append((u, s))
    return out
def S_at(k, t):  # right-continuous
    s = 1.
    for u, v in k:
        if u <= t + 1e-9: s = v
        else: break
    return s
chk = dict(csv_sha256=sha, tolerance_curve=TOL, tolerance_note='PDF vector geometry; residual limited by 4-dp time rounding and float output', groups={})
allpass = True
for g in ['A', 'B']:
    d = df[df.group == g]; k = km(d); v = ex['groups'][g]['curve_vertices']
    # measured value on each horizontal segment: at midpoint of segment (support), plus tail
    cmp = []
    for (t0, s0), (t1, s1) in zip(v[:-1], v[1:]):
        if t1 - t0 > 1e-6 and abs(s1 - s0) < 1e-9:
            tm = (t0+t1)/2; r = S_at(k, tm); cmp.append(dict(t=round(tm, 4), measured=s0, reconstructed=round(r, 6), resid=round(r-s0, 6)))
    tail = dict(t=v[-1][0], measured=v[-1][1], reconstructed=round(S_at(k, v[-1][0]), 6))
    tail['resid'] = round(tail['reconstructed']-tail['measured'], 6)
    sel = [cmp[i] for i in np.linspace(0, len(cmp)-1, 12).astype(int)]
    maxr = max(abs(c['resid']) for c in cmp + [tail])
    rk = []
    for t, n in zip(rt, risk[g]):
        c = int((d.observed_time >= t).sum()); rk.append(dict(t=t, displayed=n, reconstructed=c, resid=c-n, status='pass' if c == n else 'fail'))
    ints = bool(d.event.isin([0, 1]).all())
    st = dict(n_records=len(d), n_expected=100, n_status='pass' if len(d) == 100 else 'fail', event_indicator_integer=ints,
              events=int(d.event.sum()), supplied_event_total='unavailable (not in manifest)',
              curve_all_segments=dict(n_segments=len(cmp), max_abs_resid=maxr, status='pass' if maxr <= TOL else 'fail'),
              curve_selected=sel, tail_check=tail, risk_table=rk)
    allpass &= st['n_status'] == 'pass' and maxr <= TOL and all(r['status'] == 'pass' for r in rk) and ints
    chk['groups'][g] = st
chk['overall'] = 'pass' if allpass else 'fail'
json.dump(chk, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    s = chk['groups'][g]; print(g, s['n_records'], s['events'], s['curve_all_segments'], s['tail_check'], [(r['t'], r['displayed'], r['reconstructed']) for r in s['risk_table']])
print(chk['overall'], sha)
