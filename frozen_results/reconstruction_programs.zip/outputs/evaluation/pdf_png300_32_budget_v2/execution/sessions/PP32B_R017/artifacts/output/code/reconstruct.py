#!/usr/bin/env python3
"""KM-to-IPD reconstruction from the vector PDF figure (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]
Defaults: ../input and ./output relative to the current working directory (work/)."""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

SEED = 1114203069
np.random.seed(SEED)  # no stochastic step is used; recorded for reproducibility
IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
os.makedirs(OUT, exist_ok=True)
man = json.load(open(os.path.join(IN, "manifest.json")))
pg = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]

# ---- axis calibration from labelled anchors (tick marks + labels) ----
words = pg.extract_words()
blk = [l for l in pg.lines if l["stroking_color"] == (0.0, 0.0, 0.0)]
xt = sorted(l["x0"] for l in blk if abs(l["x0"] - l["x1"]) < 1e-6 and l["bottom"] - l["top"] < 5)
xlab = sorted([(w["x0"] + w["x1"]) / 2, float(w["text"])] for w in words
              if w["text"].isdigit() and abs(w["top"] - 229.7) < 1)
# match each x label to nearest tick
xa = np.array([[min(xt, key=lambda t: abs(t - c)), v] for c, v in xlab])
bx = np.polyfit(xa[:, 1], xa[:, 0], 1)   # x_pt = bx0*t + bx1
ylab = [((w["top"] + w["bottom"]) / 2, float(w["text"])) for w in words
        if w["text"] in ("0.0", "0.2", "0.4", "0.6", "0.8", "1.0")]
# y tick lines: horizontal short black lines; label centres align with them
yt = sorted(l["top"] for l in blk if abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 5)
ya = np.array([[min(yt, key=lambda t: abs(t - c)), v] for c, v in ylab]) if yt else \
     np.array([[c, v] for c, v in ylab])
by = np.polyfit(ya[:, 1], ya[:, 0], 1)
t_of = lambda x: (x - bx[1]) / bx[0]
s_of = lambda y: (y - by[1]) / by[0]
calib = dict(x_anchors=xa.tolist(), y_anchors=ya.tolist(), x_fit=bx.tolist(), y_fit=by.tolist(),
             x_resid_max=float(np.max(np.abs(np.polyval(bx, xa[:, 1]) - xa[:, 0]))),
             y_resid_max=float(np.max(np.abs(np.polyval(by, ya[:, 1]) - ya[:, 0]))))

# ---- legend: colour -> group ----
leg = [l for l in pg.lines if l["linewidth"] == 1.0]
labs = [w for w in words if w["text"] in ("A", "B") and w["top"] < 30]
col2grp = {}
for l in leg:
    w = min((w for w in labs if w["x0"] > l["x1"]), key=lambda w: w["x0"] - l["x1"])
    col2grp[l["stroking_color"]] = w["text"]

# ---- risk table ----
rt_times = [float(w["text"]) for w in sorted([w for w in words if abs(w["top"] - 229.7) < 1 and w["text"].isdigit()], key=lambda w: w["x0"])]
risk = {}
for g in ("A", "B"):
    row = [w for w in words if w["text"] == g and w["x0"] < 50 and w["top"] > 270][0]
    nums = sorted([w for w in words if abs(w["top"] - row["top"]) < 1 and w["text"].isdigit()], key=lambda w: w["x0"])
    risk[g] = [int(w["text"]) for w in nums]
    assert len(risk[g]) == len(rt_times)

# ---- curves and censor ticks ----
meas = {}
for cv in pg.curves:
    g = col2grp[cv["stroking_color"]]
    p = np.array(cv["pts"])
    T, S = t_of(p[:, 0]), s_of(p[:, 1])
    # step path alternates horizontal/vertical; drops = vertical segments
    drops = []
    for i in range(1, len(p)):
        if abs(p[i, 0] - p[i-1, 0]) < 1e-9 and p[i, 1] > p[i-1, 1] + 1e-9:
            drops.append((T[i], S[i-1], S[i]))
    ticks = sorted(t_of(l["x0"]) for l in pg.lines
                   if l["stroking_color"] == cv["stroking_color"] and l["linewidth"] < 1)
    meas[g] = dict(path_t=T.tolist(), path_s=S.tolist(), drops=drops, ticks=ticks,
                   t_end=float(T[-1]), s_end=float(S[-1]))

def meas_S(g, t):
    """right-continuous step value of the measured (vector) curve"""
    s = 1.0
    for td, sb, sa in meas[g]["drops"]:
        if td <= t + 1e-9: s = sa
    return s

def simulate(g, n0, drops, cens):
    """walk in time: events before censoring at ties. cens: list of times (with multiplicity)."""
    ev = sorted(drops); cs = sorted(cens)
    n = n0; recs = []; j = 0
    for td, sb, sa in ev:
        while j < len(cs) and cs[j] < td - 1e-9:
            recs.append((cs[j], 0)); n -= 1; j += 1
        d = int(round(n * (1 - sa / sb))) if n > 0 else 0
        d = max(d, 1) if n > 0 else 0
        recs += [(td, 1)] * d; n -= d
    recs += [(c, 0) for c in cs[j:]]
    return recs

def allocate(g, mode):
    """Interval-by-interval: choose censoring count C_k so the simulated
    number at risk at the next risk-table time matches the table."""
    m = meas[g]; n0 = man["groups"][g]
    edges = rt_times + [np.inf]
    cens_all = []; log = []
    for k in range(len(rt_times)):
        lo, hi = edges[k], edges[k+1]
        if k + 1 < len(rt_times):
            target = risk[g][k+1]
        else:
            target = None
        tk = [t for t in m["ticks"] if lo <= t < hi]
        dk = [d for d in m["drops"] if lo <= d[0] < hi]
        # number at risk at lo from current reconstruction
        def run(C):
            cz = place(tk, C, lo, min(hi, m["t_end"]), mode)
            recs = simulate(g, n0, m["drops"], cens_all + cz)
            n_hi = n0 - sum(1 for t, e in recs if t < hi - 1e-9) if np.isfinite(hi) else 0  # survivors are not yet records
            nev = sum(e for t, e in recs if lo <= t < hi)
            return cz, n_hi, nev
        n_lo = n0 - sum(1 for t, e in simulate(g, n0, m["drops"], cens_all) if t < lo - 1e-9)
        if target is None:
            # final interval: the risk table shows 0 at 36, so everyone leaves before it.
            # Censor all survivors: at ticks (>=1 each), remainder at ticks (mode rule).
            best = None
            for C in range(0, n_lo + 1):
                cz, _, nev = run(C)
                if C + nev == n_lo: best = (C, cz, nev); break
                if C + nev > n_lo: best = (C, cz, nev); break
            C, cz, nev = best
            status = "exact" if C + nev == n_lo else "unreconciled"
        else:
            best = None
            for C in range(0, n_lo + 1):
                cz, n_hi, nev = run(C)
                if best is None or abs(n_hi - target) < abs(best[2] - target): best = (C, cz, n_hi, nev)
                if n_hi <= target: break
            C, cz, n_hi, nev = best
            status = "exact" if n_hi == target else f"off by {n_hi - target}"
        cens_all += cz
        log.append(dict(interval=[lo, None if not np.isfinite(hi) else hi], n_start=n_lo,
                        ticks_visible=len(tk), censored_assigned=C, events=nev,
                        target_next=target, status=status))
    recs = simulate(g, n0, m["drops"], cens_all)
    return recs, log

def place(tk, C, lo, hi, mode):
    """Place C censorings in an interval. 'ticks': each visible tick >=1 censoring
    (if C >= #ticks), extra multiplicity spread round-robin over ticks in time order
    (equal multiplicity); if C < #ticks, use C ticks evenly spaced among them.
    'uniform': one per visible tick, the excess spread uniformly in time over [lo,hi)."""
    tk = sorted(tk)
    if C == 0: return []
    if not tk:
        return list(lo + (np.arange(C) + 0.5) / C * (hi - lo))
    if C <= len(tk):
        idx = np.round(np.linspace(0, len(tk) - 1, C)).astype(int)
        return [tk[i] for i in idx]
    extra = C - len(tk)
    if mode == "ticks":
        q, r = divmod(extra, len(tk))
        idx = np.round(np.linspace(0, len(tk) - 1, r)).astype(int) if r else []
        out = []
        for i, t in enumerate(tk):
            out += [t] * (1 + q + int(i in set(idx)))
        return out
    return tk + list(lo + (np.arange(extra) + 0.5) / extra * (hi - lo))

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d / n; out.append((u, S))
    return out
def km_at(steps, t):
    s = 1.0
    for u, v in steps:
        if u <= t + 1e-9: s = v
    return s

def write_atomic(df, path):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", suffix=".tmp")
    os.close(fd); df.to_csv(tmp, index=False); os.replace(tmp, path)

def build(mode):
    rows = []; logs = {}
    for g in ("A", "B"):
        recs, log = allocate(g, mode)
        assert len(recs) == man["groups"][g]
        rows += [(g, round(float(t), 5), int(e)) for t, e in recs]; logs[g] = log
    return pd.DataFrame(rows, columns=["group", "observed_time", "event"]), logs

prim, logs = build("ticks")
write_atomic(prim, os.path.join(OUT, "ipd.csv"))
sens, slogs = build("uniform")
_key = lambda d: d.sort_values(["group", "observed_time", "event"]).reset_index(drop=True)
SENS_IDENTICAL = _key(sens).equals(_key(prim))
if SENS_IDENTICAL:
    # visible ticks account for every required censoring, so no alternative allocation exists
    if os.path.exists(os.path.join(OUT, "sensitivity.csv")): os.remove(os.path.join(OUT, "sensitivity.csv"))
else:
    write_atomic(sens, os.path.join(OUT, "sensitivity.csv"))

# save extracted observations
json.dump(dict(calibration=calib, colour_to_group={str(k): v for k, v in col2grp.items()},
               risk_times=rt_times, risk=risk,
               curves={g: dict(drops=m["drops"], ticks=m["ticks"], t_end=m["t_end"], s_end=m["s_end"])
                       for g, m in meas.items()}, allocation_log=logs, sensitivity_log=slogs),
          open(os.path.join(OUT, "extracted.json"), "w"), indent=1)

# ---- checks on reloaded CSV ----
df = pd.read_csv(os.path.join(OUT, "ipd.csv"))
sha = hashlib.sha256(open(os.path.join(OUT, "ipd.csv"), "rb").read()).hexdigest()
TOL_S = 0.005  # vector coordinates are exact; residual reflects integer d rounding only
chk = dict(csv_sha256=sha, survival_tolerance=TOL_S,
           tolerance_note="curve read from exact PDF vector coordinates; tolerance allows integer-event rounding",
           arms={})
for g in ("A", "B"):
    d = df[df.group == g]; st = km(d)
    times = [0, 1, 3, 6, 9, 12, 18, 24, 27, 30, 33, 35, meas[g]["t_end"]]
    sv = [dict(t=round(t, 4), measured=round(meas_S(g, t), 5), reconstructed=round(km_at(st, t), 5),
               residual=round(km_at(st, t) - meas_S(g, t), 5),
               status="pass" if abs(km_at(st, t) - meas_S(g, t)) <= TOL_S else "fail") for t in times]
    rk = [dict(t=t, table=r, reconstructed=int((d.observed_time >= t - 1e-9).sum()),
               residual=int((d.observed_time >= t - 1e-9).sum()) - r,
               status="pass" if int((d.observed_time >= t - 1e-9).sum()) == r else "fail")
          for t, r in zip(rt_times, risk[g])]
    chk["arms"][g] = dict(n=int(len(d)), n_expected=man["groups"][g],
                          n_status="pass" if len(d) == man["groups"][g] else "fail",
                          events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                          event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
                          supplied_event_total="unavailable (not in manifest)",
                          visible_censor_ticks=len(meas[g]["ticks"]),
                          max_time=float(d.observed_time.max()), curve_end=meas[g]["t_end"],
                          survival=sv, risk_table=rk)
# sensitivity comparison at common supported horizon
H = min(meas["A"]["t_end"], meas["B"]["t_end"])
def rmst(steps, H):
    a = 0; prev_t = 0; s = 1.0
    for u, v in steps:
        if u > H: break
        a += s * (u - prev_t); prev_t = u; s = v
    return a + s * (H - prev_t)
sc = dict(horizon=round(H, 4), identical_to_primary=bool(SENS_IDENTICAL), status="not materially different; sensitivity.csv not saved" if SENS_IDENTICAL else "run", assumption="excess censorings (beyond one per visible tick) spread uniformly in time within each risk-table interval instead of stacked on ticks")
for g in ("A", "B"):
    p1 = km(df[df.group == g]); p2 = km(sens[sens.group == g])
    sc[g] = dict(S_primary=round(km_at(p1, H), 5), S_sensitivity=round(km_at(p2, H), 5),
                 area_primary=round(rmst(p1, H), 4), area_sensitivity=round(rmst(p2, H), 4))
chk["sensitivity_comparison"] = sc
json.dump(chk, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
print(json.dumps(dict(calib=calib, map={str(k): v for k, v in col2grp.items()}, logs=logs), indent=0))
print(json.dumps(sc))
for g in ("A","B"):
    a = chk["arms"][g]; print(g, a["n"], a["events"], a["censored"], a["visible_censor_ticks"],
        [s["status"] for s in a["survival"]], [(r["table"], r["reconstructed"]) for r in a["risk_table"]])
