# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (a vector PDF) and `../input/manifest.json` (n = 1000 per arm, time in months, seed 1114203069). The manifest gives no arm-specific event totals, so I had no supplied totals to check against. That absence is not read as zero events. No other information was used.
**Code:** `output/code/reconstruct.py [input_dir] [output_dir]`. The defaults are `../input` and `output`, and the script is run from `work/`. It is deterministic: the seed is set and recorded, but no step uses randomness.

## Measurement
- The figure is vector graphics, so I read the curves from the PDF path coordinates rather than from pixels. There is no antialiasing and no obscured origin.
- **Calibration.** Time comes from a linear fit of the seven labelled x-ticks (0–36). Survival comes from the six labelled y-ticks (0.0–1.0). Maximum anchor residual is under 1e-12 pt. No global rescaling or running-minimum correction was applied. Both paths start exactly at (t = 0, S = 1).
- **Arm identity.** I matched each colour to its legend label: blue is Group A and orange is Group B.
- **Events and censorings.** Each step path alternates horizontal and vertical segments. Vertical segments are drops, giving 798 for A and 630 for B. Censor marks are separate 4-pt vertical tick objects: 202 for A and 370 for B. Every tick object was counted, including two B ticks drawn at identical coordinates. Those are counted as two censorings at one time: tick multiplicity is taken from the object count, not from how visible the tick is.
- **Risk table.** Read from PDF text: A = 1000, 692, 485, 334, 221, 69, 0; B = 1000, 635, 521, 422, 342, 148, 0, at 0, 6, …, 36 months.
- All extracted values are saved in `output/extracted.json`: calibration, drops with S before and after, tick times, and risk rows.

## Algorithm
For each interval between risk-table times, I walked forward in time. At a tie, events are processed before censorings.
- At each drop, the event count is d = round(n_risk × (1 − S_after/S_before)).
- I chose the interval's censoring count so that the number at risk at the next table time matches the table.
- Censorings are placed at the tick times. The code also has a rule for putting any extra multiplicity on ticks, but it was never needed.

**Result:** in every interval of both arms, the required censoring count equals the number of tick objects, so each tick is exactly one censoring.

The event multiplicities were not assumed to be 1. They were computed from the drop ratios, and every drop gave d = 1. Given the reconstructed n_risk, the implied d departs from an integer by at most 0.0005.

Totals: A has 798 events and 202 censorings; B has 630 events and 370 censorings. The last record in each arm is the censoring tick at the end of the curve (A: 35.93 months, B: 35.94 months). All of these are before 36, which agrees with the zero risk counts at 36.

## Checks
Results are in `output/checks.json`, which records the SHA-256 of the final CSV. I reloaded the CSV and recomputed the right-continuous KM estimate for each arm. At 13 times, including 0, early times, the tail and the curve end, it matches the vector curve with residual 0 (tolerance 0.005, justified by exact coordinates and integer rounding). All seven risk-table counts match exactly, using observed_time ≥ t. Arm sizes are 1000 each, and event indicators are 0/1 integers.

## Limitations and sensitivity
- **Time precision.** Times are the plotted x-coordinates, stored to 1e-5 months. If the original data had tied times that the plotting software separated, or rounded times, those details cannot be recovered.
- **What the reconstruction rests on.** It assumes that the plotted ticks show every censoring and that the steps are the product-limit estimate. The exact agreement with the risk table in every interval supports both assumptions, but it does not prove them.
- **Sensitivity analysis.** The planned alternative moved censorings in excess of the ticks to uniform times within each interval. Because there are no excess censorings, it gave records identical to the primary result, so no `sensitivity.csv` was saved. Survival at the common horizon of 35.93 months is S_A = 0.1287 and S_B = 0.2558. The areas under the curves to that horizon are 14.98 months for A and 18.09 months for B. These are identical under both allocations.
- No unresolved discrepancies remain. This one alternative allocation is not an error bound.
