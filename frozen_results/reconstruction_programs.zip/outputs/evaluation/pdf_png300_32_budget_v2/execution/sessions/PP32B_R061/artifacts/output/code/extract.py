"""Extract KM step curves and censor ticks from the vector PDF.

Usage: python extract.py [path/to/figure.pdf] [outdir]
Writes curve_steps_<G>.csv and ticks_<G>.csv to outdir (default work/).
Calibration from the drawn axis ticks: x=64.8 -> t=0, x=410.4 -> t=36
(labels 0..36 centred on tick lines); y=223.2 -> S=0, y=43.2 -> S=1
(labels 0.0..1.0 centred on tick lines).  pdfplumber 'top' coordinates.
"""
import sys, os, json
import pdfplumber
import pandas as pd

PDF = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.pdf"
OUT = sys.argv[2] if len(sys.argv) > 2 else "work"
os.makedirs(OUT, exist_ok=True)

X0, X36, Y0, Y1 = 64.8, 410.4, 223.2, 43.2
tx = lambda x: (x - X0) / (X36 - X0) * 36.0
sy = lambda y: (Y0 - y) / (Y0 - Y1)

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}

pg = pdfplumber.open(PDF).pages[0]
summary = {}
for g, col in COL.items():
    cv = [c for c in pg.curves if tuple(c["stroking_color"]) == col]
    assert len(cv) == 1
    pts = cv[0]["pts"]
    # step path: horizontal then vertical segments; record every vertical drop
    rows = []
    for (xa, ya), (xb, yb) in zip(pts[:-1], pts[1:]):
        if abs(xa - xb) < 1e-9 and yb > ya + 1e-9:
            rows.append(dict(x=xa, y_before=ya, y_after=yb, t=tx(xa),
                             S_before=sy(ya), S_after=sy(yb)))
        elif abs(xa - xb) > 1e-9 and abs(ya - yb) > 1e-9:
            raise RuntimeError("non-step segment")
    steps = pd.DataFrame(rows)
    steps.to_csv(f"{OUT}/curve_steps_{g}.csv", index=False)
    ticks = [l for l in pg.lines if l["linewidth"] == 0.65
             and tuple(l["stroking_color"]) == col]
    tk = pd.DataFrame([dict(x=l["pts"][0][0], ymid=(l["pts"][0][1] + l["pts"][1][1]) / 2)
                       for l in ticks])
    tk["t"] = tk.x.map(tx)
    tk["S"] = tk.ymid.map(sy)
    tk = tk.sort_values("t").reset_index(drop=True)
    tk.to_csv(f"{OUT}/ticks_{g}.csv", index=False)
    summary[g] = dict(n_drops=len(steps), n_ticks=len(tk),
                      start=(pts[0][0], pts[0][1]), end=(pts[-1][0], pts[-1][1]),
                      t_end=tx(pts[-1][0]), S_end=sy(pts[-1][1]))
print(json.dumps(summary, indent=1))
