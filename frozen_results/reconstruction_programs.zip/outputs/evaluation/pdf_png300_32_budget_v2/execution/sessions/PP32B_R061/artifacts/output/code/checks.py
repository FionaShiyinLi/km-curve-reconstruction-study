"""Verify committed output/ipd.csv against the extracted curve and risk table.

Usage: python checks.py [workdir] [outdir]
"""
import sys, json, hashlib
import numpy as np
import pandas as pd

W = sys.argv[1] if len(sys.argv) > 1 else "work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
path = f"{OUT}/ipd.csv"
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path)
# Risk table as printed under the figure (read from PDF text objects)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 667, 444, 290, 197, 65, 0], "B": [1000, 775, 568, 440, 339, 143, 0]}
N = {"A": 1000, "B": 1000}
# KM tolerance: extracted S values are exact to ~3e-7 (4-decimal pt rounding)
KM_TOL = 2e-6


def km(t, e):
    ut = np.unique(t[e == 1])
    S, s = [], 1.0
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; S.append(s)
    return ut, np.array(S)


def step_eval(ut, S, x):  # right-continuous
    k = np.searchsorted(ut, x, side="right")
    return 1.0 if k == 0 else S[k - 1]


out = dict(csv_sha256=sha, columns=list(df.columns), groups={})
for g in "AB":
    d = df[df.group == g]
    t, e = d.observed_time.to_numpy(float), d.event.to_numpy(int)
    st = pd.read_csv(f"{W}/curve_steps_{g}.csv")
    ut, S = km(t, e)
    # measured right-continuous curve from the vector path
    mt, mS = st.t.to_numpy(), st.S_after.to_numpy()
    grid = sorted(set([0.0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5,
                       float(t.max())]))
    kmc = []
    for x in grid:
        m, r = step_eval(mt, mS, x), step_eval(ut, S, x)
        kmc.append(dict(t=round(x, 4), measured=round(m, 7), reconstructed=round(r, 7),
                        residual=round(r - m, 9), status="pass" if abs(r - m) <= KM_TOL else "fail"))
    # full-path check: every measured drop
    # evaluated midway between consecutive drops (avoids 1e-6 time-rounding at the jump)
    mid = np.append((mt[:-1] + mt[1:]) / 2, mt[-1] + 1e-4)
    allres = np.array([step_eval(ut, S, x) - s for x, s in zip(mid, mS)])
    rk = []
    for tt, obs in zip(RISK_T, RISK[g]):
        rec = int((t >= tt).sum())
        rk.append(dict(t=tt, displayed=obs, reconstructed=rec, residual=rec - obs,
                       status="pass" if rec == obs else "fail"))
    out["groups"][g] = dict(
        n_records=len(d), n_expected=N[g], n_ok=len(d) == N[g],
        event_integer_01=bool(set(np.unique(e)) <= {0, 1}),
        events=int(e.sum()), censored=int((e == 0).sum()),
        supplied_event_total="unavailable (manifest gives none)",
        max_time=float(t.max()), all_finite_nonneg=bool(np.all(np.isfinite(t)) and np.all(t >= 0)),
        km_tolerance=KM_TOL, km_tolerance_basis="PDF coords rounded to 1e-4 pt = 2.8e-7 in S; allow accumulation",
        km_checks=kmc,
        km_all_drops=dict(n=len(mt), max_abs_residual=float(np.abs(allres).max()),
                          status="pass" if np.abs(allres).max() <= KM_TOL else "fail"),
        km_n_event_times_reconstructed=len(ut), km_n_drops_measured=len(mt),
        risk_table_convention="count observed_time >= t",
        risk_checks=rk)
json.dump(out, open(f"{OUT}/checks.json", "w"), indent=1)
for g in "AB":
    o = out["groups"][g]
    print(g, o["n_records"], o["events"], o["km_all_drops"], [r["status"] for r in o["risk_checks"]],
          [c["status"] for c in o["km_checks"]].count("fail"))
print(sha)
