# Reconstruction assumptions and method

## Inputs
- `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 1553089965).
- The manifest gives no arm-specific event totals. Event totals were therefore not constrained. They are marked unavailable in `checks.json`.
- Risk table (from PDF text objects), at t = 0, 6, …, 36: A 1000, 667, 444, 290, 197, 65, 0; B 1000, 775, 568, 440, 339, 143, 0. The risk table was **not** used to build the records. It was held out for validation.

## Measurement
- The figure is vector graphics. Each arm is one stroked step path: blue = Group A and orange = Group B, identified from the legend line segments next to the "Group A"/"Group B" labels. Censor marks are separate vertical segments, 4 pt long and 0.65 pt wide, in the arm colour.
- Calibration comes from the drawn axis tick lines, whose labels are centred on the ticks: x = 64.8 pt → 0 months and x = 410.4 pt → 36 months (linear; the intermediate ticks at 57.6 pt spacing agree), and y = 223.2 pt → S = 0 and y = 43.2 pt → S = 1. Both paths start exactly at (64.8, 43.2), which is S = 1 at t = 0, so no origin correction or global rescaling was applied.
- Coordinates are stored to 1e-4 pt, which is about 2.8e-7 in S. I read the path vertices directly rather than raster pixels, so antialiasing and overplotting of the lines are not an issue. Measured drops are in `extracted/curve_steps_{A,B}.csv` and ticks in `extracted/ticks_{A,B}.csv`.

## Algorithm (`code/reconstruct.py`, deterministic)
1. Walk through each arm's drops in time order. The number at risk before drop i is N_max = (at risk after the previous event) − (visible ticks strictly between the two drops).
2. Test the KM relation S_after = S_before·(1 − d/n). The first candidate is n = N_max with d = 1…8. If no d fits within the rounding tolerance (8e-7), try additional unmarked censorings c = 0…60 and keep the candidate with the smallest residual. d = 1 was not assumed: it was chosen because it gave the fit.
3. Result: every drop in both arms was fitted with **d = 1 and no extra censorings**, with maximum residuals of 5.3e-7 (A) and 5.4e-7 (B). So each visible tick is consistent with exactly one censoring and each drop with exactly one event. There was no evidence of tied events, overplotted ticks or unmarked censorings. Ticks after the last drop account exactly for the remaining at-risk count: 3 in each arm.
4. Censored records are placed at their tick times and events at their drop times, with times rounded to 1e-6 months. A: 806 events and 194 censored. B: 640 events and 360 censored.

## Verification (`code/checks.py` → `checks.json`)
- I reloaded the committed CSV, recomputed the right-continuous KM curve, and compared it with the measured curve. This was done at 19 fixed times from 0 to the last observation, covering the start and the tail, and midway after every one of the 806/640 measured drops. The maximum absolute residual is 2.8e-7, and all points pass at a tolerance of 2e-6 (justified by the coordinate rounding).
- Risk table, counting observed_time ≥ t: all 7 times match exactly in both arms, including 0 at 36 months (the last times are 35.85 for A and 35.96 for B).
- Each arm has 1000 records, event is an integer in {0, 1}, and all times are finite and nonnegative.

## Limitations
- The d/n identifiability argument depends on each tick being a single censoring. One tick hiding k censorings (with k−1 unmarked) would change n at later drops and break the KM fit. The fit holds everywhere at rounding precision, so this cannot have occurred except in combinations that exactly offset each other, which I consider implausible.
- Censoring times are exact only to the plotted tick positions, and event times to the plotted drop positions (both about 1e-6 months after rounding).
- A censoring and an event at the same plotted x could not be told apart from the ordering convention. None occurred.
- No sensitivity alternative was run. The inputs did not leave materially different feasible event/censoring allocations, because the risk table and the curve are both reproduced exactly.
- Seed 1553089965 is recorded in the code, but the algorithm uses no randomness.

## Reproduce
`bash output/code/run_all.sh ../input/figure.pdf` run from the work directory (extract → reconstruct → checks). The CSV is written to a temporary file and atomically renamed.
