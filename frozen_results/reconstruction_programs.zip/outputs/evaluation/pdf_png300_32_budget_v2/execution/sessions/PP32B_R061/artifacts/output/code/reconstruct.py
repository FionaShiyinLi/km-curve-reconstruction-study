"""Reconstruct IPD from the extracted vector step curves and censor ticks.

Usage: python reconstruct.py [workdir_with_extracted_csvs] [outdir]
Deterministic (no randomness); seed 1553089965 recorded for completeness.

For each drop i (time t_i, observed S_before, S_after), the number at risk just
before the drop is N_max = (n at risk after previous event) - (visible ticks in
(t_{i-1}, t_i)).  Candidates (d, n) with n = N_max - c_extra, c_extra >= 0
(unmarked or overplotted censorings) are scored by the KM relation
S_after = S_before * (1 - d/n).  The ticks-only candidate (c_extra = 0) with
the best d is accepted when its residual is within the coordinate-rounding
tolerance; otherwise the candidate with the smallest residual is taken.
Extra censorings are placed at the visible ticks in that interval (multiplicity)
if any exist, otherwise spread evenly inside the open interval.
"""
import sys, os, json
import numpy as np
import pandas as pd

SEED = 1553089965
np.random.seed(SEED)
W = sys.argv[1] if len(sys.argv) > 1 else "work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
N = {"A": 1000, "B": 1000}
# PDF coordinates carry 4 decimals: |dy| <= 5e-5 pt per value -> 2.8e-7 in S;
# a residual combines two such roundings in S_before and S_after.
TOL = 8e-7
DMAX, CMAX = 8, 60

records, log = [], {}
for g in "AB":
    st = pd.read_csv(f"{W}/curve_steps_{g}.csv").sort_values("t").reset_index(drop=True)
    tk = pd.read_csv(f"{W}/ticks_{g}.csv").sort_values("t").reset_index(drop=True)
    n_after = N[g]
    t_prev = -np.inf
    rows, recs = [], []
    for i, s in st.iterrows():
        inint = tk[(tk.t > t_prev) & (tk.t < s.t)].t.tolist()
        for tt in inint:
            recs.append((tt, 0))
        nmax = n_after - len(inint)
        best0 = min(((abs(s.S_before * (1 - d / nmax) - s.S_after), d) for d in range(1, DMAX + 1)))
        if best0[0] < TOL:
            d, c_extra, res = best0[1], 0, best0[0]
        else:
            cands = [(abs(s.S_before * (1 - d / (nmax - c)) - s.S_after), c, d)
                     for c in range(0, CMAX + 1) for d in range(1, DMAX + 1) if nmax - c > d - 1]
            res, c_extra, d = min(cands)
        if c_extra:
            if inint:
                extra = [inint[k % len(inint)] for k in range(c_extra)]
            else:
                lo = max(t_prev, 0.0)
                extra = list(lo + (s.t - lo) * (np.arange(c_extra) + 1) / (c_extra + 1))
            recs += [(tt, 0) for tt in extra]
        n = nmax - c_extra
        recs += [(s.t, 1)] * d
        rows.append(dict(t=s.t, n_risk=n, d=d, ticks=len(inint), c_extra=c_extra,
                         resid=res, ratio_n=d / (1 - s.S_after / s.S_before)))
        n_after = n - d
        t_prev = s.t
    tail = tk[tk.t > t_prev].t.tolist()
    recs += [(tt, 0) for tt in tail]
    left = n_after - len(tail)
    rows_df = pd.DataFrame(rows)
    rows_df.to_csv(f"{W}/allocation_{g}.csv", index=False)
    log[g] = dict(events=int(rows_df.d.sum()), drops=len(rows_df), multi_d=int((rows_df.d > 1).sum()),
                  steps_with_extra_censor=int((rows_df.c_extra > 0).sum()),
                  extra_censors=int(rows_df.c_extra.sum()), ticks=len(tk),
                  tail_ticks=len(tail), unallocated_after_tail=int(left),
                  max_resid=float(rows_df.resid.max()))
    if left != 0:
        raise RuntimeError(f"group {g}: {left} participants unaccounted after tail ticks")
    records += [(g, t, e) for t, e in recs]
    assert sum(1 for r in records if r[0] == g) == N[g]

df = pd.DataFrame(records, columns=["group", "observed_time", "event"])
df["observed_time"] = df.observed_time.round(6)
df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
os.makedirs(OUT, exist_ok=True)
tmp = f"{OUT}/.ipd.csv.tmp"
df.to_csv(tmp, index=False)
os.replace(tmp, f"{OUT}/ipd.csv")
json.dump(log, open(f"{W}/reconstruct_log.json", "w"), indent=1)
print(json.dumps(log, indent=1))
