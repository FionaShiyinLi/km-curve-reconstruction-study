#!/bin/bash
# Run from the work directory: bash output/code/run_all.sh [../input/figure.pdf]
set -e
PDF=${1:-../input/figure.pdf}
D=$(dirname "$0")
python3 "$D/extract.py" "$PDF" output/extracted
python3 "$D/reconstruct.py" output/extracted output
python3 "$D/checks.py" output/extracted output
