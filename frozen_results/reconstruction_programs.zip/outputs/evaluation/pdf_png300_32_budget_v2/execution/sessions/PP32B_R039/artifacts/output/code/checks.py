#!/usr/bin/env python3
"""Reload output/ipd.csv and compare it with the measured (vector) curves and the risk table.
Usage: python checks.py [OUTPUT_DIR] [MANIFEST]   (run reconstruct.py first)"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
MAN = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
ipd = pd.read_csv(os.path.join(OUT, 'ipd.csv'))
meta = json.load(open(os.path.join(OUT, 'extraction_meta.json')))
man_n = json.load(open(MAN))['groups']
sha = hashlib.sha256(open(os.path.join(OUT, 'ipd.csv'), 'rb').read()).hexdigest()


def km(x):
    ts = np.sort(x.observed_time[x.event == 1].unique()); S = 1.0; out = []
    for t in ts:
        n = (x.observed_time >= t).sum(); d = ((x.observed_time == t) & (x.event == 1)).sum()
        S *= 1 - d / n; out.append((t, S))
    return np.array(out)


def step(tab, t):            # right-continuous KM step value at t
    i = np.searchsorted(tab[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else tab[i, 1]


def measured(cv, t):         # vector curve value at t (post-drop value at a vertical segment)
    idx = np.where(cv.t.values <= t + 1e-9)[0][-1]
    return cv.S.values[idx]


TOL = 1e-4
res = dict(csv_sha256=sha, tolerance_S=TOL,
           tolerance_note='Curve is read from PDF vector paths (coordinates to ~1e-5 pt, ~6e-8 survival '
                          'units); observed_time is rounded to 1e-6 months. 1e-4 is a generous bound for '
                          'accumulated rounding, not a pixel-reading tolerance.', arms={})
for g in man_n:
    x = ipd[ipd.group == g]; tab = km(x)
    cv = pd.read_csv(os.path.join(OUT, f'curve_vertices_{g}.csv'))
    tend = float(cv.t.max())
    times = [0.0, 0.25, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, tend]
    comp = []
    for t in times:
        m = measured(cv, t); r = step(tab, t)
        comp.append(dict(t=round(t, 4), measured=round(m, 6), reconstructed=round(r, 6),
                         residual=float(f'{r - m:.3g}'), status='pass' if abs(r - m) < TOL else 'fail'))
    # dense check: midpoint of every horizontal segment of the measured curve. Exact jump
    # instants are avoided because observed_time is rounded to 1e-6 months, which can put a
    # reconstructed jump a fraction of 1e-6 after the vector jump (an evaluation artefact).
    ut = np.unique(cv.t.values); mids = (ut[:-1] + ut[1:]) / 2
    allres = np.array([step(tab, t) - measured(cv, t) for t in mids])
    rk = []
    for t, n in meta['risk_table'][g]:
        n_rec = int((x.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=n_rec, residual=n_rec - n,
                       status='pass' if n_rec == n else 'fail'))
    ticks = pd.read_csv(os.path.join(OUT, f'censor_ticks_{g}.csv'))
    res['arms'][g] = dict(
        n_records=int(len(x)), n_expected=int(man_n[g]),
        size_status='pass' if len(x) == man_n[g] else 'fail',
        event_indicators_integer_01=bool(x.event.isin([0, 1]).all()),
        events=int(x.event.sum()), censored=int((x.event == 0).sum()),
        supplied_event_total='unavailable (manifest has no event totals)',
        visible_censor_ticks=int(len(ticks)),
        max_observed_time=float(x.observed_time.max()), curve_end_time=tend,
        last_tick_time=float(ticks.t.max()),
        survival_checks=comp,
        dense_check=dict(where='midpoint of every horizontal segment', n_points=int(len(allres)), max_abs_residual=float(np.abs(allres).max()),
                         status='pass' if np.abs(allres).max() < TOL else 'fail'),
        tail_check=dict(t=tend, measured=float(cv.S.iloc[-1]), reconstructed=float(step(tab, tend)),
                        n_at_risk_at_curve_end=int((x.observed_time >= tend - 1e-6).sum()),
                        status='pass' if abs(step(tab, tend) - cv.S.iloc[-1]) < TOL else 'fail'),
        risk_table=rk)
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g, a in res['arms'].items():
    print(g, a['size_status'], 'events', a['events'], 'cens', a['censored'], 'ticks', a['visible_censor_ticks'],
          'dense', a['dense_check'], 'fails', sum(c['status'] == 'fail' for c in a['survival_checks']),
          [r['status'] for r in a['risk_table']], 'tail', a['tail_check'],
          'last tick', a['last_tick_time'], 'maxT', a['max_observed_time'])
print(sha)
