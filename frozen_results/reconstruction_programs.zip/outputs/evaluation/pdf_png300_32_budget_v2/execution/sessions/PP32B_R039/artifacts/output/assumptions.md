# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf` (a vector PDF) and `../input/manifest.json` (N = 1000 per arm, months, seed 1167498436).
- The manifest has no arm-level event totals, so no totals constraint was available. The reconstructed totals (A 764, B 643) are derived from the curve and are not supplied values.
- The risk table (times 0, 6, ..., 36) was read from the PDF text layer:
  A 1000/689/472/327/235/91/0; B 1000/628/530/444/361/145/0.

## Measurement
- No pixels were processed. The KM step paths (A is blue and B is orange, identified from the legend line colours) and the censor tick marks (short vertical 4-pt segments in the arm colour: 236 for A, 357 for B) were read directly from the PDF drawing objects with `pdfplumber`.
- Calibration uses linear fits of the labelled axis tick marks: x 64.8 pt = 0 months and 410.4 pt = 36 months; y 223.2 pt = 0 and 43.2 pt = 1.0. Both curves start at exactly S = 1 at t = 0, so no origin correction or global rescaling was applied. Early drops, the first at t = 0.003 months, are kept.
- Extracted observations are saved in `curve_vertices_{A,B}.csv`, `censor_ticks_{A,B}.csv`, `drops_{A,B}.csv` (per-drop d, n at risk, censorings in the preceding gap, visible ticks) and `extraction_meta.json` (calibration, risk table).

## Algorithm (`code/reconstruct.py`, deterministic; the seed is set but unused)
The method is a sequential KM inversion anchored to the running reconstructed KM:
1. For each vertical drop, we know S_after and the number m still at risk after the previous drop. For each candidate d (1 to 29), we solve S_rec·(1 − d/n) = S_after for a real-valued n. That gives the implied censorings in the gap, c* = m − n.
2. We choose the d whose c* is closest to (and not below) the number k of visible ticks in that gap. Then c = max(k, round(c*)).
   - Anchoring to the reconstructed S_rec rather than the drawn S_before stops coordinate rounding (worth about ±0.4 in n near n ≈ 1000 when solved drop by drop) from accumulating into phantom censorings. An earlier drop-by-drop version produced exactly such artefacts and was discarded before any commit.
3. Censorings are placed at the visible tick times in the gap. A tick at an event time counts as at risk at that event (the event is ordered before the censoring). If c had exceeded k, the extra censorings would have been placed as added multiplicity on the ticks. If there had been no ticks in a gap, they would have been spread uniformly over it. **Neither case arose:** in every gap of both arms c = k.
4. Everyone still at risk after the last drop is censored at the ticks after it. The last tick coincides with the curve's end (A 35.932, B 35.952 months), so no follow-up was added beyond the drawn curve.

## Result and how well it is identified
- Every drop resolved to d = 1 (A 764 events, B 643). In every inter-drop gap, the censoring count implied by the curve equals the visible tick count, so each tick is one censoring (A 236, B 357).
- The d = 1 reading is not assumed from the drop size. A drop with d = 2 at risk set n looks the same as d = 1 at n/2, but n/2 would require about n/2 censorings in a single gap that shows only k ticks. That is incompatible with the ticks and with the risk table.
- Separately from the fit, the risk table is reproduced exactly at all 7 times in both arms, counting observed_time ≥ t. The risk table was not used in the fit, so this is an independent check.
- The reconstructed KM matches the drawn curve to within 3e-7 at the midpoint of every horizontal segment and at 21 named times per arm, including 35, 35.5 and the curve end (see `checks.json`; tolerance 1e-4, justified there).

## Limitations
- Censor times are the tick x-positions, which are exact only to the plotting precision of the PDF. Event times are the drop x-positions, rounded to 1e-6 months.
- If the original data had tied censorings plotted as one tick together with an equal hidden excess of events, the curve and ticks would not reveal it. There is no evidence of this: the tick counts reconcile exactly with the drop sizes and the risk table.
- No sensitivity allocation was run. The curve, ticks and risk table together leave no materially different feasible censor/event allocation: every gap is fixed at c = k with d = 1. A `--alt` option (uniform within-gap censor placement) exists in the code but was not executed, and `sensitivity.csv` was not produced.
- No covariates or information beyond the figure were used or created.
