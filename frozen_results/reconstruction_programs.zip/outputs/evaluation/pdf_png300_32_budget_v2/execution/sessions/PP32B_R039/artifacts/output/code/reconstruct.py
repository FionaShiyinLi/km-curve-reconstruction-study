#!/usr/bin/env python3
"""KM-to-IPD reconstruction from the vector paths of figure.pdf.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: INPUT_DIR=../input, OUTPUT_DIR=./output (relative to the cwd).
Set --alt to write the sensitivity allocation instead of the primary one.
"""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

SEED = 1167498436           # code seed from manifest; algorithm is deterministic
np.random.seed(SEED)
args = [a for a in sys.argv[1:] if not a.startswith('--')]
ALT = '--alt' in sys.argv
IN = args[0] if len(args) > 0 else '../input'
OUT = args[1] if len(args) > 1 else 'output'
os.makedirs(OUT, exist_ok=True)
man = json.load(open(os.path.join(IN, 'manifest.json')))
pg = pdfplumber.open(os.path.join(IN, 'figure.pdf')).pages[0]

# ---- axis calibration from the black tick marks and their labels -----------
blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted({round(l['pts'][0][0], 4) for l in blk if abs(l['pts'][0][0]-l['pts'][1][0]) < 1e-6
             and abs(l['pts'][0][1]-l['pts'][1][1]) < 4})
yt = sorted({round(l['pts'][0][1], 4) for l in blk if abs(l['pts'][0][1]-l['pts'][1][1]) < 1e-6
             and abs(l['pts'][0][0]-l['pts'][1][0]) < 4})
words = pg.extract_words()
xlab = sorted((float(w['text']), (w['x0']+w['x1'])/2) for w in words
              if w['text'].isdigit() and 225 < w['top'] < 240)
ylab = sorted((float(w['text']), (w['top']+w['bottom'])/2) for w in words
              if w['x1'] < 60 and w['text'].replace('.', '').isdigit())
# match each label to nearest tick, then fit linear maps
xa = np.polyfit([min(xt, key=lambda v: abs(v-c)) for _, c in xlab], [v for v, _ in xlab], 1)
ya = np.polyfit([min(yt, key=lambda v: abs(v-c)) for _, c in ylab], [v for v, _ in ylab], 1)
T = lambda x: np.polyval(xa, x)
Sv = lambda y: np.polyval(ya, y)
calib = dict(x_ticks_pt=xt, x_labels=[v for v, _ in xlab], y_ticks_pt=yt,
             y_labels=[v for v, _ in ylab], time_per_pt=xa[0], surv_per_pt=ya[0])

# ---- risk table (text) ------------------------------------------------------
rows = {}
for w in words:
    if w['text'].isdigit() and w['top'] > 280:
        g = 'A' if w['top'] < 295 else 'B'
        rows.setdefault(g, []).append(((w['x0']+w['x1'])/2, int(w['text'])))
risk = {g: [(float(round(T(x))), n) for x, n in sorted(v)] for g, v in rows.items()}

# ---- arm colours from legend (1.0-width lines left of 'Group A'/'Group B') --
leg = [l for l in pg.lines if l['linewidth'] >= 1.0 and l['stroking_color'] != (0.0, 0.0, 0.0)]
leg.sort(key=lambda l: l['pts'][0][0])
col = {'A': leg[0]['stroking_color'], 'B': leg[1]['stroking_color']}

def arm_data(g):
    c = [c for c in pg.curves if c['stroking_color'] == col[g]][0]
    P = np.array(c['pts'])
    t, S = T(P[:, 0]), Sv(P[:, 1])
    v = np.where(np.abs(np.diff(P[:, 1])) > 1e-9)[0]
    drops = np.c_[t[v], S[v], S[v+1]]
    ticks = [l for l in pg.lines if l['stroking_color'] == col[g] and l['linewidth'] < 1]
    tk = np.sort([T(l['pts'][0][0]) for l in ticks])
    tky = np.array([Sv((l['pts'][0][1]+l['pts'][1][1])/2) for l in sorted(ticks, key=lambda l: l['pts'][0][0])])
    return dict(t=t, S=S, drops=drops, ticks=tk, tick_S=tky, t_end=t[-1], S0=S[0])

def reconstruct(g, N, alt=False):
    a = arm_data(g)
    dr, tk = a['drops'], a['ticks']
    recs, log = [], []
    m = N                       # number at risk just after the previous drop
    tprev = 0.0
    def place(c, lo, hi, closed_hi):
        """place c censorings in (lo, hi) using the arm's tick marks there."""
        sel = tk[(tk >= lo) & ((tk <= hi) if closed_hi else (tk < hi))]
        if c <= 0: return [], len(sel)
        if alt or len(sel) == 0:            # uniform spread over the gap
            return list(lo + (hi-lo)*(np.arange(c)+0.5)/c), len(sel)
        if c >= len(sel):                   # every tick >=1, extras round-robin
            k = np.full(len(sel), c // len(sel)); k[:c % len(sel)] += 1
            # put extra multiplicity on ticks spread evenly across the gap
            idx = np.argsort(np.argsort(-((np.arange(len(sel))*0.618) % 1)))
            k = np.full(len(sel), c // len(sel)); k[idx < c % len(sel)] += 1
            return list(np.repeat(sel, k)), len(sel)
        pick = np.round(np.linspace(0, len(sel)-1, c)).astype(int)
        return list(sel[pick]), len(sel)
    Srec = 1.0                  # running KM of the records built so far
    for (tt, sb, sa) in dr:
        k = int(np.sum((tk >= tprev) & (tk < tt)))   # visible ticks in the gap
        # for each candidate d, solve Srec*(1-d/n) = S_after for real n, then the
        # implied censorings c* = m - n; choose d whose c* is closest to (and not
        # below) the visible tick count. Uses Srec, not S_before, so small vector
        # rounding errors do not accumulate into phantom censorings.
        cands = []
        for d in range(1, 30):
            nstar = d / (1 - sa/Srec)
            cst = m - nstar
            if cst < k - 0.5 or nstar < d: continue
            cands.append((abs(cst - k), d, cst))
        if cands:
            _, d, cst = min(cands)
            c = max(k, int(round(cst)))
            err = cst - c
        else:                            # drop larger than any feasible fit
            d, c, err = 1, k, np.nan
        n = m - c
        Srec *= 1 - d/n
        c = m - n
        ct, nt = place(c, tprev, tt, False)
        recs += [(g, x, 0) for x in ct] + [(g, tt, 1)]*d
        log.append(dict(t=tt, S_before=sb, S_after=sa, S_rec=Srec, d=d, n_risk=n, c_resid=err,
                        cens_gap=c, ticks_gap=nt))
        m = n - d; tprev = tt
    # after last drop: remaining m censored at ticks in (tprev, t_end]; curve end supports t_end
    sel = tk[tk >= tprev]
    if m > 0:
        if alt or len(sel) == 0:
            ct = list(tprev + (a['t_end']-tprev)*(np.arange(m)+0.5)/m)
            ct[-1] = a['t_end']
        else:
            ct, _ = place(m, tprev, a['t_end'], True)
            if max(ct) < a['t_end'] - 1e-9: ct[-1] = a['t_end']
        recs += [(g, x, 0) for x in ct]
    log.append(dict(t=a['t_end'], tail_censored=m, ticks_tail=int(len(sel))))
    return pd.DataFrame(recs, columns=['group', 'observed_time', 'event']), log, a

if __name__ == '__main__':
    dfs, logs = [], {}
    for g, N in man['groups'].items():
        df, log, a = reconstruct(g, N, ALT)
        assert len(df) == N, (g, len(df))
        dfs.append(df); logs[g] = log
        pd.DataFrame(log).to_csv(os.path.join(OUT, f'drops_{g}{"_alt" if ALT else ""}.csv'), index=False)
        if not ALT:
            pd.DataFrame(np.c_[a['t'], a['S']], columns=['t', 'S']).to_csv(
                os.path.join(OUT, f'curve_vertices_{g}.csv'), index=False)
            pd.DataFrame(np.c_[a['ticks'], a['tick_S']], columns=['t', 'S']).to_csv(
                os.path.join(OUT, f'censor_ticks_{g}.csv'), index=False)
    out = pd.concat(dfs).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    out['observed_time'] = out['observed_time'].round(6).clip(lower=0)
    name = 'sensitivity.csv' if ALT else 'ipd.csv'
    fd, tmp = tempfile.mkstemp(dir=OUT, suffix='.tmp'); os.close(fd)
    out.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, name))
    json.dump(dict(calibration=calib, risk_table=risk, colours=col),
              open(os.path.join(OUT, 'extraction_meta.json'), 'w'), indent=1, default=float)
    print(name, 'written', out.groupby('group').event.agg(['size', 'sum']).to_dict())
