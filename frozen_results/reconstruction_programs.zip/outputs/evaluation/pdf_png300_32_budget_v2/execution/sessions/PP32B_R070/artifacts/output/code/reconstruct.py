"""KM-to-IPD reconstruction from vector PDF paths (own implementation).
Usage: python reconstruct.py [path/to/figure.pdf] [path/to/manifest.json] [outdir]
"""
import sys, json, os, hashlib
import numpy as np, pandas as pd, pdfplumber

here = os.path.dirname(os.path.abspath(__file__))
pdf = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '../../../input/figure.pdf')
man = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, '../../../input/manifest.json')
out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(here, '..')
manifest = json.load(open(man))
np.random.seed(manifest['code_seed'])  # no randomness used; seed recorded

pg = pdfplumber.open(pdf).pages[0]
# --- axis calibration from labelled tick marks
xt = sorted({round(l['x0'], 3) for l in pg.lines if l['x0'] == l['x1'] and l['top'] == 223.2 and l['bottom'] > 224})
yt = sorted({round(l['top'], 3) for l in pg.lines if l['top'] == l['bottom'] and l['x0'] < 62 and l['x1'] <= 64.8})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
T = lambda x: ax * np.asarray(x) + bx
S = lambda y: ay * np.asarray(y) + by
calib = dict(x_ticks_pt=xt, y_ticks_pt=yt, months_per_pt=ax, surv_per_pt=ay,
             x_resid=float(np.max(np.abs(T(xt) - xlab))), y_resid=float(np.max(np.abs(S(yt) - ylab))))

colors = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
def same(c, d): return c is not None and len(c) == 3 and np.allclose(c, d, atol=1e-3)

risk_times = [0, 6, 12, 18, 24, 30, 36]
risk = {'A': [100, 74, 47, 30, 21, 7, 0], 'B': [100, 68, 55, 42, 32, 14, 0]}

records, obs = [], {}
for g, col in colors.items():
    curve = [c for c in pg.curves if same(c.get('stroking_color'), col)][0]
    pts = np.array(curve['pts'])
    t, s = T(pts[:, 0]), S(pts[:, 1])
    # step vertices: horizontal segment then vertical drop at same x
    steps = []  # (time, S_before, S_after)
    for i in range(1, len(pts)):
        if abs(pts[i, 0] - pts[i-1, 0]) < 1e-9 and pts[i, 1] > pts[i-1, 1] + 1e-9:
            steps.append((float(t[i]), float(s[i-1]), float(s[i])))
    t_end = float(t[-1]); s_end = float(s[-1])
    ticks = sorted(float(T(l['x0'])) for l in pg.lines
                   if same(l.get('stroking_color'), col) and l['x0'] == l['x1'] and 30 < l['top'] < 223)
    n0 = manifest['groups'][g]
    n = n0; ev = []; cens = []; ti = 0; drops = []
    for (tt, sb, sa) in steps:
        while ti < len(ticks) and ticks[ti] < tt - 1e-9:
            cens.append(ticks[ti]); n -= 1; ti += 1
        dreal = n * (1 - sa / sb)
        d = int(round(dreal))
        drops.append(dict(time=tt, S_before=sb, S_after=sa, n_risk=n, d_real=dreal, d=d))
        ev += [tt] * d; n -= d
    while ti < len(ticks):
        cens.append(ticks[ti]); n -= 1; ti += 1
    leftover = n
    # participants unaccounted for by events/ticks: censored at last drawn curve time (assumption)
    cens += [t_end] * leftover
    for x in ev: records.append((g, x, 1))
    for x in cens: records.append((g, x, 0))
    obs[g] = dict(steps=drops, ticks=ticks, curve_end_time=t_end, curve_end_S=s_end,
                  n_events=len(ev), n_ticks=len(ticks), leftover_censored_at_end=leftover,
                  max_abs_d_rounding=float(max(abs(r['d_real'] - r['d']) for r in drops)),
                  vertices=[[float(a), float(b)] for a, b in zip(t, s)])

df = pd.DataFrame(records, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False]).reset_index(drop=True)
assert all((df.group == g).sum() == manifest['groups'][g] for g in manifest['groups'])
tmp = os.path.join(out, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(out, 'ipd.csv'))
json.dump(dict(calibration=calib, risk_table=dict(times=risk_times, **risk), arms=obs),
          open(os.path.join(out, 'extracted_observations.json'), 'w'), indent=1)
for g in obs:
    o = obs[g]; print(g, {k: v for k, v in o.items() if k not in ('steps', 'ticks', 'vertices')})
print(calib)
