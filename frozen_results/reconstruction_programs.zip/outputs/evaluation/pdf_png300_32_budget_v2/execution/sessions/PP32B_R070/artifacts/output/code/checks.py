"""Reload committed ipd.csv, recompute right-continuous KM, compare to vector-extracted curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
here = os.path.dirname(os.path.abspath(__file__))
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..')
csv = os.path.join(out, 'ipd.csv')
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); ob = json.load(open(os.path.join(out, 'extracted_observations.json')))
man = json.load(open(os.path.join(here, '../../../input/manifest.json'))) if len(sys.argv) < 3 else json.load(open(sys.argv[2]))

def km(d):
    ts = np.sort(d.loc[d.event == 1, 'observed_time'].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return out
def S_at(curve, t):  # right-continuous step
    s = 1.0
    for tt, ss in curve:
        if tt <= t + 1e-9: s = ss
    return s
def meas_at(verts, t):  # measured step curve: last vertex with time<=t (vertical drops ordered)
    s = 1.0
    for tt, ss in verts:
        if tt <= t + 1e-9: s = ss
    return s

TOL_S = 0.003  # ~0.5 pt of vector path; coordinates rounded to 0.01 pt in PDF, rounding of stored times 1e-4 mo
res = dict(csv_sha256=sha, tolerance_survival=TOL_S,
           tolerance_justification='vector PDF coordinates (0.01 pt precision = 5.6e-5 survival); tolerance kept at 0.003 to allow for time rounding at 1e-4 months near steps',
           arms={})
allpass = True
for g in ['A', 'B']:
    d = df[df.group == g]; c = km(d); o = ob['arms'][g]; v = o['vertices']
    r = dict(n_records=int(len(d)), n_expected=man['groups'][g], events=int(d.event.sum()),
             event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
             supplied_event_total='unavailable (not in manifest)')
    # curve comparison at many times incl. just after each measured drop and tail
    times = sorted(set([0, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, o['curve_end_time'] - 1e-3, o['curve_end_time']]
                       + [s['time'] + 1e-3 for s in o['steps']]))
    cmp = []
    for t in times:
        m = meas_at(v, t); k = S_at(c, t)
        cmp.append(dict(t=round(t, 4), measured=round(m, 5), reconstructed=round(k, 5), resid=round(k - m, 6),
                        status='pass' if abs(k - m) <= TOL_S else 'fail'))
    r['curve_checks'] = cmp
    r['max_abs_curve_resid'] = max(abs(x['resid']) for x in cmp)
    rk = []
    for t, nr in zip(ob['risk_table']['times'], ob['risk_table'][g]):
        cnt = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=nr, reconstructed=cnt, resid=cnt - nr, status='pass' if cnt == nr else 'fail'))
    r['risk_checks'] = rk
    r['max_followup'] = float(d.observed_time.max())
    ok = all(x['status'] == 'pass' for x in cmp + rk) and r['n_records'] == r['n_expected'] and r['event_indicator_integer_01']
    r['overall'] = 'pass' if ok else 'fail'; allpass &= ok
    res['arms'][g] = r
    print(g, r['overall'], 'n', r['n_records'], 'events', r['events'], 'maxres', r['max_abs_curve_resid'],
          [(x['t'], x['displayed'], x['reconstructed']) for x in rk])
json.dump(res, open(os.path.join(out, 'checks.json'), 'w'), indent=1)
print('sha', sha, 'ALL', allpass)
