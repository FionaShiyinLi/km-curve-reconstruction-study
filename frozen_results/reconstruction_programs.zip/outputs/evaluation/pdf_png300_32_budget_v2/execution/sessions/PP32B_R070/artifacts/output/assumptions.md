# Reconstruction assumptions and method

## Inputs
- `../input/figure.pdf`: a vector PDF. The KM step paths, censor ticks, axis ticks and all text (including the number-at-risk table) are PDF objects, so no rasterization or OCR was needed.
- `../input/manifest.json`: n = 100 per arm, time in months, code seed 1296616075. The seed is set, but the algorithm is deterministic. The manifest gives no arm-specific event totals, so that check is marked unavailable.
- Group identity comes from the legend: the blue line/path is Group A and the orange one is Group B.
- Risk table as read from the PDF text at 0, 6, ..., 36 months: A 100, 74, 47, 30, 21, 7, 0; B 100, 68, 55, 42, 32, 14, 0.

## Algorithm (`code/reconstruct.py`, own implementation)
1. **Calibration.** I fitted a linear map from the labelled axis tick-mark coordinates: x 64.8–410.4 pt maps to 0–36 months (9.6 pt/month), and y 223.2–43.2 pt maps to 0–1. Residuals were at floating-point level. I applied no global rescaling or correction. Both paths start exactly at S = 1 (y = 43.2), so origin handling was not an issue.
2. **Curve measurement.** For each arm I took the step path vertices and identified each vertical segment as a drop, with time t, S_before and S_after.
3. **Censoring.** Each vertical censor tick in the arm's colour counts as one censoring at its x position. Every tick is a separate PDF object, including near-coincident ones about 0.02 months apart, so tick multiplicity comes from object count, not from how visible the ticks are. Ticks strictly before a drop time reduce the risk set before that drop.
4. **Events.** For each drop, d = n_risk × (1 − S_after/S_before), with n_risk carried forward from n = 100. Every computed d was within 5×10⁻⁵ of an integer, and every one equals 1. That value comes from the measured ratio and the tracked risk set; it was not assumed.
5. **Reconciliation.** Events plus ticks came to exactly 100 in each arm (A: 78 events, 22 censored; B: 66 events, 34 censored). No participants were left over, so I added no censorings. The last censor tick in each arm falls at the curve end (A 34.47 months, B 35.35 months). Nothing was placed beyond the drawn follow-up.
6. Times are rounded to 1e-4 months. The CSV is written to a temporary file and then atomically renamed.

## Verification (`code/checks.py` produces `checks.json`)
- I reloaded the CSV and recomputed the right-continuous KM. I compared it with the measured step curve at fixed times (0 to 33 months), just after every drop, and at the tail. The maximum absolute residual is 0 in both arms, against a tolerance of 0.003.
- For the risk table I counted records with observed_time ≥ t at each displayed time. All 14 counts match exactly, including 0 at 36 months.
- Arm sizes are 100/100, and all event indicators are 0/1 integers. The SHA-256 of the CSV is recorded in `checks.json`.
- `extracted_observations.json` holds all measured vertices, drops, ticks and calibration.

## Limitations
- The exact times depend on the figure's plotting precision: PDF coordinates are stored to 0.01 pt, which is about 0.001 months.
- If two censorings at an identical time had been drawn as one tick object, or if a tick sat exactly on an event time, the figure could not show it. However, the exact agreement between counts and the risk table at all seven times gives no sign of this.
- There were no supplied event totals to check against.
- Covariates and anything beyond the observed (time, status) records are not reconstructed.
- **Sensitivity analysis: not run.** The inputs gave no materially different feasible allocation of events and censorings (all multiplicities were integer, tick objects were individually countable, and the risk table matched exactly), so `sensitivity.csv` was not produced.
