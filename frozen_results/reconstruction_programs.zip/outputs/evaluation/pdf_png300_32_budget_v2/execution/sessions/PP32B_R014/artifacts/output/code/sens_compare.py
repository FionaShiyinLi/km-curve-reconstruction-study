"""Compare primary and sensitivity CSVs at common horizon: S(t) and restricted mean (area under KM)."""
import sys, json, numpy as np, pandas as pd
H = 35.9
def km(tt, ee):
    ut = np.unique(tt[ee == 1]); S = 1.0; st = []
    for u in ut:
        S *= 1 - ((tt == u) & (ee == 1)).sum() / (tt >= u).sum(); st.append((u, S))
    return st
def S_at(st, x):
    v = 1.0
    for u, s in st:
        if u <= x: v = s
        else: break
    return v
def area(st, h):
    a, prev_t, prev_s = 0.0, 0.0, 1.0
    for u, s in st:
        if u > h: break
        a += prev_s * (u - prev_t); prev_t, prev_s = u, s
    return a + prev_s * (h - prev_t)
out = {'horizon_months': H, 'groups': {}}
P = pd.read_csv('output/ipd.csv'); Q = pd.read_csv('output/sensitivity.csv')
for g in 'AB':
    r = {}
    for nm, d in (('primary', P), ('sensitivity', Q)):
        e = d[d.group == g]; st = km(e.observed_time.values, e.event.values)
        r[nm] = dict(events=int(e.event.sum()), S_12=round(S_at(st, 12), 4), S_24=round(S_at(st, 24), 4),
                     S_H=round(S_at(st, H), 4), area_0_H=round(area(st, H), 3))
    out['groups'][g] = r
json.dump(out, open('output/sensitivity_comparison.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
