# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster). This is the only source of the curves, censor marks and number-at-risk table.
- `../input/manifest.json`: n = 1000 per arm, time unit months, code seed 168200680. The manifest contains **no arm-specific event totals**, so reconstructed totals (A 774, B 678) are outputs, not checked constraints. `checks.json` records the event-total check as unavailable.
- Risk table read visually at 0, 6, ..., 36 months. A: 1000, 675, 446, 320, 222, 81, 0. B: 1000, 753, 568, 434, 323, 111, 0. The digits are clearly rendered, and I consider the readings certain.

## Measurement (`code/extract.py`, output `measured_columns_raw.csv`)
- Calibration comes from the labelled axis tick marks: x = 0 and x = 36 at pixel columns 269.5 and 1709.5 (40 px/month); S = 1.0 and S = 0.0 at rows 179.5 and 929.5 (750 px/unit). No global rescaling or other transform was applied.
- Each pixel is unmixed by least squares into white plus blue (A) and orange (B) coverage. Pixels with a large residual (black text or axes) are discarded.
- Per column, the level is the coverage-weighted centroid of that arm's largest connected pixel cluster. The "+" censor marks are vertically symmetric about the line, so tick columns leave the centroid essentially unbiased.
- Up to about 1.5 months the arms overlap, and one colour occludes the other in places. Columns where the other arm's cluster lies within 3 px are flagged unreliable and filled by linear interpolation of neighbouring measured levels. This fill is a measurement step only; the estimator is never interpolated.
- The origin is anchored at S(0) = 1 by the KM definition. The early decline in both arms (about 2% by 0.3 months) is visible in reliable columns and is kept as measured; no reciprocal rescaling was used.
- Monotonicity is imposed by a weighted isotonic (pool-adjacent-violators) fit, with unreliable columns down-weighted to 0.2, rather than by a running minimum. A single misread point therefore cannot propagate through the rest of the curve. Raw and isotonic values are both saved in `measured_curve_{A,B}.csv`.
- Censor ticks are columns whose cluster extends 13 to 20 px and whose centroid lies within 3 px of the rolling median level. The second condition rejects risers of large drops. An isolated tick spans about 3 columns. Dense tick blocks (for example after 24 months, and 30 to 36 months) merge into continuous runs, so tick *visibility* is detected but tick *multiplicity* is not identified.

## Reconstruction algorithm (`code/reconstruct.py`)
This is my own Guyot-type interval algorithm. For each risk-table interval [t_k, t_k+1):
1. The number censored, c_k, is solved iteratively so that n(t_k) - d_k - c_k = n(t_k+1). The risk counts are treated as exact.
2. Censorings are placed at quantiles of the detected tick-column positions within the interval (uniform placement if an interval had no ticks; none did).
3. Walking column by column, events are d_j = round(n_j (1 - S_j / S_km,prev)), using the reconstructed KM so far, which self-corrects rounding. d is not fixed at 1; a column may carry several tied events. At a tied column, events precede censorings.
4. Correction cycle 1, the only primary revision: a seeded (168200680) greedy local search moves single censorings between tick columns. A move is accepted only if the interval-end risk count still matches and the squared deviation between the KM and the isotonic curve decreases. The reason: the first version failed the B tail check (S(35.9) = 0.199 vs measured 0.206) because width-based tick weighting underweights stacked ticks in dense blocks.
- All times are strictly below 36 (maximum 35.975), because n(36) = 0 is displayed. Remaining participants in the last interval are censored at detected tick positions up to the last column, not at 36.

## Censoring and follow-up
The within-interval censoring times are an assumption. Their totals are constrained by the risk table and their locations by visible ticks and curve fit. Tick multiplicity inside dense blocks is not recoverable. No accrual or administrative-censoring model was assumed beyond what the ticks show, and no follow-up beyond the last plotted column was invented.

## Verification (`code/check.py` -> `checks.json`)
- The committed CSV is reloaded and a right-continuous KM step function recomputed from it.
- The KM is compared with the measured curve at 19 times from 0.25 to 35.9 months, including the tail. The tolerance of 0.006 was set in advance: drawn line thickness 3 to 4 px plus about 1 px centroid error, where 1 px = 0.00133.
- All points pass. The maximum absolute residual against the isotonic curve is 0.0005 in A and 0.0009 in B (at 35.9 months). At early times in the overlap region, the isotonic curve and the raw centroid differ by up to 0.008 (A, 0.25 months), because the raw column there is partly occluded.
- Risk counts are computed as #(observed_time >= t) and match the displayed values exactly at all 7 times, including 0 at 36.
- Arm sizes, integer 0/1 events, and finite non-negative times all pass.
- The maximum absolute deviation over all reliable columns against the raw centroids is 0.0033 (A) and 0.0093 (B). B's maximum is at 35.3 to 35.4 months, on the vertical riser of a single-event tail step, where a column centroid lies between the two levels. It is not a level misfit.

## Sensitivity (`sensitivity.csv`, `sensitivity_comparison.json`)
I ran one alternative: censorings uniform within each risk interval (tick positions ignored), with the same event rule and no refinement. At the common supported horizon of 35.9 months:
- A: S(35.9) 0.1577 vs 0.1599; area 15.010 vs 15.018 months.
- B: S(35.9) 0.2067 vs 0.2017; area 18.433 vs 18.431 months.
- Events: A 774 vs 774; B 678 vs 680.

This single alternative is neither a confidence interval nor a bound on reconstruction error.

## Unresolved limitations
- Individual censoring times inside dense tick blocks, and the split between tied events within a column, are not identified by the figure. The 0.025-month column resolution limits time precision.
- Early (< 1.5 months) levels depend partly on interpolation across occluded columns.
- The reconstructed tail uses few participants at risk (about 10 to 25 in B after 34.5 months), so tail estimates are sensitive to single-record choices.
- No event totals were supplied, so they could not be cross-checked.
