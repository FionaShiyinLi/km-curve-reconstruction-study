"""Stage 1: pixel measurement of the KM figure (no correction applied here).
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(fig).convert('RGB')).astype(float)
# axis calibration from labelled tick marks (tick pixel pairs, centres):
# x: '0' tick cols 269-270, '36' tick cols 1709-1710 -> 40 px / month
# y: '1.0' tick rows 179-180, '0.0' tick rows 929-930 -> 750 px / unit
X0, X36, Y1, Y0 = 269.5, 1709.5, 179.5, 929.5
t_of = lambda x: (x - X0) / (X36 - X0) * 36.0
s_of = lambda y: (Y0 - y) / (Y0 - Y1)
COL = {'A': np.array([31, 119, 180.]), 'B': np.array([255, 127, 14.])}
# unmix each pixel as white + a_A*(cA-white) + a_B*(cB-white), least squares
M = np.stack([COL['A'] - 255, COL['B'] - 255], 1)          # 3x2
P = (im - 255).reshape(-1, 3)
coef = np.linalg.lstsq(M, P.T, rcond=None)[0].T
resid = np.linalg.norm(P - coef @ M.T, axis=1)
coef = np.clip(coef, 0, 1).reshape(im.shape[0], im.shape[1], 2)
bad = (resid > 60).reshape(im.shape[:2])                    # black/grey text, axes
coef[bad] = 0
ytop, ybot = 170, 928
res = {}
for gi, g in enumerate('AB'):
    a = coef[:, :, gi].copy(); a[:ytop] = 0; a[ybot:] = 0
    cen = np.full(im.shape[1], np.nan); lo = cen.copy(); hi = cen.copy(); mass = cen.copy()
    for x in range(271, 1712):
        col = a[:, x]
        ys = np.where(col > 0.25)[0]
        if len(ys) == 0: continue
        # keep the largest-mass connected cluster of this arm's colour
        runs = np.split(ys, np.where(np.diff(ys) > 2)[0] + 1)
        r = max(runs, key=lambda r: col[r].sum())
        w = col[r[0]-1:r[-1]+2]; yy = np.arange(r[0]-1, r[-1]+2)
        cen[x] = (w * yy).sum() / w.sum(); lo[x] = r[0]; hi[x] = r[-1]; mass[x] = w.sum()
    res[g] = dict(cen=cen, lo=lo, hi=hi, mass=mass, a=a)
# save per-column measurements
import pandas as pd
rows = []
for g in 'AB':
    r = res[g]
    for x in range(271, 1712):
        if np.isnan(r['cen'][x]): continue
        rows.append(dict(group=g, px=x, t=t_of(x + 0.5), y_centroid=r['cen'][x],
                         s_raw=s_of(r['cen'][x]), top=r['lo'][x], bottom=r['hi'][x],
                         alpha_mass=r['mass'][x]))
pd.DataFrame(rows).to_csv(f'{out}/measured_columns_raw.csv', index=False)
print('saved', len(rows))
