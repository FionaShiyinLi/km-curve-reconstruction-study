"""Stage 2: KM -> approximate IPD reconstruction (own implementation).
Usage: python reconstruct.py [measured_columns_raw.csv] [out.csv] [--censor ticks|uniform]
Inputs: per-column pixel measurements from extract.py, risk table read from the figure,
group sizes from ../input/manifest.json. Deterministic; seed recorded anyway."""
import sys, os, json, numpy as np, pandas as pd
SEED = 168200680
np.random.seed(SEED)                      # no stochastic step is used; recorded for provenance
args = [a for a in sys.argv[1:] if not a.startswith('--')]
meas = args[0] if len(args) > 0 else 'output/measured_columns_raw.csv'
outcsv = args[1] if len(args) > 1 else 'output/ipd.csv'
mode = 'uniform' if '--censor=uniform' in sys.argv else 'ticks'
N = {'A': 1000, 'B': 1000}                 # manifest group sizes
RT_T = [0, 6, 12, 18, 24, 30, 36]          # risk-table times (months), read from figure
RT = {'A': [1000, 675, 446, 320, 222, 81, 0], 'B': [1000, 753, 568, 434, 323, 111, 0]}
X0, X36 = 269.5, 1709.5
t_of = lambda x: (x - X0) / (X36 - X0) * 36.0
TMAX = t_of(1708.5)                        # last column centre strictly before 36 (risk 0 at 36)

def pav_decreasing(y, w):
    """Weighted isotonic (non-increasing) regression by pool-adjacent-violators."""
    blocks = []
    for yi, wi in zip(y, w):
        blocks.append([yi * wi, wi, 1])
        while len(blocks) > 1 and blocks[-2][0] / blocks[-2][1] < blocks[-1][0] / blocks[-1][1]:
            s, ww, n = blocks.pop(); blocks[-1][0] += s; blocks[-1][1] += ww; blocks[-1][2] += n
    out = []
    for s, ww, n in blocks: out += [s / ww] * n
    return np.array(out)

def measure(d):
    """Return per-column table with reliability flags, filled + isotonic curve and ticks."""
    A = d[d.group == 'A'].set_index('px'); B = d[d.group == 'B'].set_index('px')
    px = np.arange(271, 1710)
    res = {}
    for g, me, ot in (('A', A, B), ('B', B, A)):
        df = pd.DataFrame(index=px)
        df['t'] = t_of(px + 0.5)
        df = df.join(me[['s_raw', 'top', 'bottom', 'y_centroid']]).join(
            ot[['top', 'bottom']].rename(columns={'top': 'otop', 'bottom': 'obot'}))
        h = df.bottom - df.top
        # occlusion: other arm's pixel cluster within 3 rows of this arm's cluster
        occl = (df.otop <= df.bottom + 3) & (df.obot >= df.top - 3)
        df['reliable'] = df.s_raw.notna() & ~occl
        # tick = tall symmetric vertical mark: extent >=13 px and centroid consistent with
        # neighbouring level (rejects risers of large drops)
        med = df.y_centroid.rolling(13, center=True, min_periods=3).median()
        df['tick'] = (h >= 13) & (h <= 20) & ((df.y_centroid - med).abs() <= 3)
        tr = df.loc[df.reliable, 't'].values; sr = df.loc[df.reliable, 's_raw'].values
        # measurement fill for unreliable columns (interpolation of measured levels only);
        # S(0)=1 anchor from KM definition at the labelled origin
        df['s_fill'] = np.interp(df.t, np.r_[0.0, tr], np.r_[1.0, sr])
        w = np.where(df.reliable, 1.0, 0.2)
        df['s_iso'] = np.minimum(pav_decreasing(df.s_fill.values, w), 1.0)
        res[g] = df
    return res

def simulate(t, S, cols, ct, n0, S_start):
    """Walk one risk-table interval: events from KM drop relation d = round(n(1 - S/S_km)),
    events before censorings at tied columns. Returns events, censor times, S_km, n_end, SSE."""
    cidx = np.clip(np.searchsorted(t[cols], ct, side='right') - 1, 0, len(cols) - 1)
    ccount = np.bincount(cidx, minlength=len(cols)) if len(ct) else np.zeros(len(cols), int)
    cts = np.sort(ct); cis = np.sort(cidx)
    Skm = S_start; nr = n0; ev = []; cens = []; sse = 0.0
    for j, ci in enumerate(cols):
        if nr > 0 and Skm > 0:
            dj = max(0, min(int(round(nr * (1 - S[ci] / Skm))), nr))
            if dj:
                Skm *= 1 - dj / nr; nr -= dj; ev += [t[ci]] * dj
        cj = min(ccount[j], nr); nr -= cj
        cens += list(cts[cis == j][:cj])
        sse += (Skm - S[ci]) ** 2
    return ev, cens, Skm, nr, sse

def reconstruct(df, n_rt, mode, refine=True):
    rng = np.random.default_rng(SEED)
    t = df.t.values; S = df.s_iso.values
    tick_t = t[df.tick.values]
    recs = []; S_start = 1.0; log = []
    for k in range(len(RT_T) - 1):
        a, b = RT_T[k], RT_T[k + 1]
        cols = np.where((t >= a) & (t < b))[0]
        n0, n1 = n_rt[k], n_rt[k + 1]
        tk = tick_t[(tick_t >= a) & (tick_t < b)]
        use_ticks = mode == 'ticks' and len(tk) > 0
        def place(c):
            if c <= 0: return np.array([])
            if use_ticks:
                return tk[np.minimum(((np.arange(c) + 0.5) * len(tk) / c).astype(int), len(tk) - 1)]
            return np.minimum(a + (np.arange(c) + 0.5) * (min(b, TMAX) - a) / c, TMAX)
        c = 0; best = None
        for it in range(200):
            ct = place(c)
            ev, cens, Skm, nr, sse = simulate(t, S, cols, ct, n0, S_start)
            if best is None or abs(nr - n1) < best[4] or (abs(nr - n1) == best[4] and nr == n1):
                best = (ct, ev, cens, Skm, abs(nr - n1), sse)
            if nr == n1 and len(cens) == c: break
            cnew = max(0, c + (nr - n1))
            if cnew == c: break
            c = cnew
        ct, ev, cens, Skm, miss, sse = best
        sse0 = sse; nmoves = 0
        if refine and use_ticks and len(ct) > 0 and miss == 0:
            # seeded greedy local search: move one censoring to another tick column;
            # accept only if risk count at interval end still matches and SSE decreases
            ct = ct.copy()
            for it in range(1500):
                i = rng.integers(len(ct)); new = ct.copy(); new[i] = tk[rng.integers(len(tk))]
                ev2, cens2, Skm2, nr2, sse2 = simulate(t, S, cols, new, n0, S_start)
                if nr2 == n1 and len(cens2) == len(new) and sse2 < sse - 1e-12:
                    ct, ev, cens, Skm, sse = new, ev2, cens2, Skm2, sse2; nmoves += 1
        log.append(dict(interval=[a, b], n_start=n0, n_end_target=n1, events=len(ev), censored=len(cens),
                        risk_mismatch=int(miss), ticks_cols=int(len(tk)), sse_before=sse0, sse_after=sse, accepted_moves=nmoves))
        recs += [(x, 1) for x in ev] + [(x, 0) for x in cens]
        S_start = Skm
    return recs, log

if __name__ == '__main__':
    d = pd.read_csv(meas)
    M = measure(d)
    out = []; summ = {}
    for g in 'AB':
        recs, log = reconstruct(M[g], RT[g], mode, refine=mode == 'ticks')
        summ[g + '_intervals'] = log
        if len(recs) != N[g]:
            print(f'group {g}: {len(recs)} records != {N[g]}; not saved'); continue
        out += [(g, round(x, 4), e) for x, e in recs]
        summ[g] = dict(n=len(recs), events=int(sum(e for _, e in recs)))
        json.dump(summ, open(outcsv.replace('.csv', '_reconstruction_log.json'), 'w'), indent=1, default=float)
        M[g].to_csv(os.path.join(os.path.dirname(outcsv), f'measured_curve_{g}.csv'))
    df = pd.DataFrame(out, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = outcsv + '.tmp'
    df.to_csv(tmp, index=False); os.replace(tmp, outcsv)
    print(mode, {g: summ[g] for g in 'AB' if g in summ})
    for g in 'AB':
        for r in summ.get(g + '_intervals', []): print(g, r)
