#!/bin/sh
# Run from the work directory (parent of output/); figure path may be given as $1.
set -e
FIG=${1:-../input/figure.png}
python3 output/code/extract.py "$FIG" output
python3 output/code/reconstruct.py output/measured_columns_raw.csv output/ipd.csv
python3 output/code/check.py output/ipd.csv output
python3 output/code/reconstruct.py output/measured_columns_raw.csv output/sensitivity.csv --censor=uniform
python3 output/code/sens_compare.py
