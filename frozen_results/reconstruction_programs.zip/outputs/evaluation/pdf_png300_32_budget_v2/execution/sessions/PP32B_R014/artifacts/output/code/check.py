"""Stage 3: reload committed CSV, recompute right-continuous KM, compare to measurements
and risk table; write checks.json. Usage: python check.py [ipd.csv] [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
ipd = sys.argv[1] if len(sys.argv) > 1 else 'output/ipd.csv'
od = sys.argv[2] if len(sys.argv) > 2 else 'output'
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [1000, 675, 446, 320, 222, 81, 0], 'B': [1000, 753, 568, 434, 323, 111, 0]}
TOL = 0.006   # prespecified: ~4.5 px = drawn line thickness (3-4 px) + 1 px centroid error
TIMES = [0.25, 0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.9]
def km(tt, ee):
    ut = np.unique(tt[ee == 1]); S = 1.0; st = []
    for u in ut:
        n = (tt >= u).sum(); d = ((tt == u) & (ee == 1)).sum(); S *= 1 - d / n; st.append((u, S))
    return st
def S_at(st, x):   # right-continuous step
    v = 1.0
    for u, s in st:
        if u <= x: v = s
        else: break
    return v
d = pd.read_csv(ipd)
sha = hashlib.sha256(open(ipd, 'rb').read()).hexdigest()
out = {'csv': ipd, 'sha256': sha, 'survival_tolerance': TOL,
       'tolerance_justification': 'line thickness 3-4 px (0.004-0.005) plus ~1 px centroid error; 1 px = 0.00133 survival, 0.025 months',
       'groups': {}}
for g in 'AB':
    e = d[d.group == g]; tt = e.observed_time.values; ee = e.event.values
    m = pd.read_csv(f'{od}/measured_curve_{g}.csv')
    st = km(tt, ee); G = {}
    G['n'] = {'expected': 1000, 'observed': int(len(e)), 'status': 'pass' if len(e) == 1000 else 'fail'}
    G['event_indicator_integer_01'] = bool(set(np.unique(ee)) <= {0, 1})
    G['finite_nonneg_times'] = bool(np.isfinite(tt).all() and (tt >= 0).all())
    G['events_total'] = {'reconstructed': int(ee.sum()), 'supplied': None, 'status': 'unavailable (no event totals in manifest)'}
    G['max_time'] = float(tt.max())
    sc = []
    for x in TIMES:
        # measured value at x: column whose time span contains x
        row = m.iloc[(np.abs(m.t - x)).argmin()]
        rec = S_at(st, x)
        r = rec - row.s_iso
        sc.append(dict(t=x, measured_raw=None if np.isnan(row.s_raw) else round(float(row.s_raw), 4),
                       measured_isotonic=round(float(row.s_iso), 4), column_reliable=bool(row.reliable),
                       reconstructed=round(rec, 4), residual=round(r, 4),
                       status='pass' if abs(r) <= TOL else 'fail'))
    G['survival'] = sc
    # max abs deviation over all reliable columns
    dev = [abs(S_at(st, tx) - s) for tx, s, rl in zip(m.t, m.s_raw, m.reliable) if rl]
    G['max_abs_dev_reliable_columns_vs_raw'] = round(float(np.max(dev)), 4)
    G['mean_abs_dev_reliable_columns_vs_raw'] = round(float(np.mean(dev)), 4)
    rk = []
    for x, n in zip(RT_T, RT[g]):
        c = int((tt >= x).sum())
        rk.append(dict(t=x, displayed=n, reconstructed=c, residual=c - n, status='pass' if c == n else 'fail'))
    G['risk_table'] = rk
    out['groups'][g] = G
json.dump(out, open(f'{od}/checks.json', 'w'), indent=1)
for g in 'AB':
    G = out['groups'][g]
    print(g, G['n'], G['events_total']['reconstructed'], G['max_time'], G['max_abs_dev_reliable_columns_vs_raw'], G['mean_abs_dev_reliable_columns_vs_raw'])
    print(' risk', [(r['t'], r['displayed'], r['reconstructed']) for r in G['risk_table']])
    print(' surv', [(r['t'], r['measured_raw'], r['measured_isotonic'], r['reconstructed'], r['status']) for r in G['survival']])
