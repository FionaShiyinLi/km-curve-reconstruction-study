"""Reconstruct IPD from vector KM vertices + censor ticks (run extract.py first).
Usage: python reconstruct.py [outdir]   (default: output)"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
SEED = 581577519; np.random.seed(SEED)  # recorded; algorithm is deterministic
N = {'A': 1000, 'B': 1000}
RISK = {'A': [1000, 657, 459, 322, 209, 69, 0], 'B': [1000, 659, 544, 434, 366, 162, 0]}
RT = [0, 6, 12, 18, 24, 30, 36]

def drops(v):
    r = []
    for i in range(1, len(v)):
        if abs(v.x[i]-v.x[i-1]) < 1e-9 and v.S[i] < v.S[i-1]-1e-9:
            r.append((v.t[i], v.S[i-1], v.S[i]))
    return pd.DataFrame(r, columns=['t', 'Sb', 'Sa'])

def build(g):
    v = pd.read_csv(f'{out}/vertices_{g}.csv'); k = pd.read_csv(f'{out}/censor_ticks_{g}.csv')
    ct = np.sort(k.t.values); dr = drops(v); D = 0; ev = []; diag = []
    for r in dr.itertuples():
        nr = N[g] - D - (ct < r.t - 1e-9).sum()
        draw = nr*(1 - r.Sa/r.Sb); d = int(round(draw))
        diag.append(dict(t=r.t, n_risk=int(nr), d_raw=draw, d=d)); D += d
        ev += [r.t]*d
    rec = pd.DataFrame({'group': g, 'observed_time': np.r_[ev, ct], 'event': np.r_[np.ones(len(ev), int), np.zeros(len(ct), int)]})
    assert len(rec) == N[g], (g, len(rec))
    return rec.sort_values(['observed_time', 'event'], ascending=[True, False]), pd.DataFrame(diag), v

def km(rec):
    t = np.sort(rec.observed_time.unique()); S = 1.0; ts = [0.0]; ss = [1.0]
    for u in t:
        n = (rec.observed_time >= u).sum(); d = ((rec.observed_time == u) & (rec.event == 1)).sum()
        if d: S *= 1 - d/n; ts.append(u); ss.append(S)
    return np.array(ts), np.array(ss)

def step_eval(ts, ss, q):  # right-continuous
    return ss[np.searchsorted(ts, q, side='right')-1]

if __name__ == '__main__':
    recs, diags, verts = {}, {}, {}
    for g in 'AB':
        recs[g], diags[g], verts[g] = build(g)
        diags[g].to_csv(f'{out}/event_allocation_{g}.csv', index=False)
    ipd = pd.concat([recs['A'], recs['B']])
    tmp = f'{out}/ipd.csv.tmp'; ipd.to_csv(tmp, index=False, float_format='%.6f'); os.replace(tmp, f'{out}/ipd.csv')
    # ---- checks from the reloaded committed CSV ----
    raw = open(f'{out}/ipd.csv', 'rb').read(); sha = hashlib.sha256(raw).hexdigest()
    ipd = pd.read_csv(f'{out}/ipd.csv'); chk = {'ipd_sha256': sha, 'seed': SEED, 'arms': {}}
    for g in 'AB':
        r = ipd[ipd.group == g]; ts, ss = km(r); v = verts[g]
        # measured curve: value at vertex level holding at time q (right-continuous from vertices)
        mt = v.t.values; ms = v.S.values
        qs = [0, 0.5, 1, 3, 6, 9, 12, 18, 24, 27, 30, 33, 35, 35.5, float(r.observed_time.max())]
        def meas(q):  # lowest vertex level reached by time q
            idx = np.where(mt <= q + 1e-9)[0][-1]; return float(ms[idx:][mt[idx:] <= q+1e-9].min())
        km_rows = []
        for q in qs:
            m = meas(q); s = float(step_eval(ts, ss, q)); res = s - m
            km_rows.append(dict(t=q, measured=round(m, 6), reconstructed=round(s, 6), residual=res,
                                status='pass' if abs(res) <= 0.001 else 'fail'))
        rt_rows = []
        for t, n in zip(RT, RISK[g]):
            c = int((r.observed_time >= t).sum())
            rt_rows.append(dict(t=t, displayed=n, reconstructed=c, residual=c-n, status='pass' if c == n else 'fail'))
        # max vertical discrepancy over all drop times
        dr = drops(v); mx = float(np.max(np.abs(step_eval(ts, ss, dr.t.values + 2e-6) - dr.Sa.values)))
        chk['arms'][g] = dict(n=int(len(r)), n_expected=N[g], events=int(r.event.sum()), censored=int((r.event == 0).sum()),
                              event_indicator_integer_01=bool(set(r.event.unique()) <= {0, 1}),
                              supplied_event_total='unavailable (not in manifest)',
                              max_abs_KM_minus_vertex_at_all_drops=mx,
                              max_abs_frac_d_raw=float((diags[g].d_raw-diags[g].d).abs().max()),
                              km_tolerance='0.001 = 0.18 pt; exact vector coordinates, tolerance covers rounding of times to 1e-6',
                              km_checks=km_rows, risk_table_checks=rt_rows,
                              risk_count_convention='count observed_time >= t')
    json.dump(chk, open(f'{out}/checks.json', 'w'), indent=1, default=float)
    for g in 'AB':
        a = chk['arms'][g]; print(g, a['n'], a['events'], a['censored'], a['max_abs_KM_minus_vertex_at_all_drops'])
        print(pd.DataFrame(a['risk_table_checks']).to_string()); print(pd.DataFrame(a['km_checks']).to_string())
    print(sha)
