import pandas as pd, numpy as np
for g in 'AB':
    v = pd.read_csv(f'output/vertices_{g}.csv'); k = pd.read_csv(f'output/censor_ticks_{g}.csv')
    dr = []
    for i in range(1, len(v)):
        if abs(v.x[i]-v.x[i-1]) < 1e-9 and v.S[i] < v.S[i-1]-1e-9:
            dr.append((v.t[i], v.S[i-1], v.S[i]))
    dr = pd.DataFrame(dr, columns=['t', 'Sb', 'Sa'])
    n = 1000; D = 0; res = []; ct = np.sort(k.t.values)
    for r in dr.itertuples():
        nr = 1000 - D - (ct < r.t - 1e-9).sum()
        draw = nr*(1-r.Sa/r.Sb); d = int(round(draw)); D += d
        res.append((r.t, nr, draw, d))
    res = pd.DataFrame(res, columns=['t', 'n', 'draw', 'd'])
    res['frac'] = res.draw-res.d
    print(g, 'drops', len(dr), 'events', D, 'cens ticks', len(ct), 'left at end', 1000-D-len(ct))
    print(' max|frac|', res.frac.abs().max(), 'd dist', res.d.value_counts().to_dict())
    print(res[res.frac.abs() > 0.1].head(10))
    # tick S vs curve
