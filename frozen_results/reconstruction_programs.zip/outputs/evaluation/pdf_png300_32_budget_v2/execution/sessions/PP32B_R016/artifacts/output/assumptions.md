# Reconstruction assumptions (groups A and B, 1000 each; time in months)

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (group sizes, time unit, seed 581577519). The manifest gives no arm-specific event totals, so that check is marked unavailable.

**Measurement.** The figure is vector graphics, so I read coordinates directly from the PDF objects rather than from pixels (`code/extract.py`).
- Calibration is a linear fit to the labelled tick marks. The x ticks at 0, 6, …, 36 months sit at 64.8–410.4 pt, and the y ticks at 1.0, …, 0.0 sit at 43.2–223.2 pt. The fit residuals are below 1e-13. No global rescaling or origin correction was applied, and none was needed: both curves start exactly at S = 1 at t = 0.
- Arm identity comes from the legend swatch next to each "Group" label: blue is A and orange is B.
- Each arm is one step path. Group A has 783 horizontal and 782 vertical segments; group B has 616 and 615.
- Censor marks are 4-pt vertical ticks. There are 218 for A and 385 for B. No two ticks share an x coordinate, so no mark is visibly overlapped. Tick visibility does not in itself prove multiplicity.
- Saved observations: `vertices_[AB].csv`, `censor_ticks_[AB].csv`, `calibration.json`.

**Algorithm** (`code/reconstruct.py`, deterministic; the seed is recorded but no randomness is used):
1. Walk forward through the drops.
2. Set n_risk = N − (prior events) − (ticks at times strictly before the drop).
3. Compute d_raw = n_risk·(1 − S_after/S_before) and take d = round(d_raw).
4. Each tick becomes one censored record at its time.

**Why d = 1 is supported.** The risk sets come from the independently drawn ticks, not from assuming d = 1. On that basis every drop gives d_raw within 0.00054 of 1 (782 drops in A, 615 in B). Events plus ticks come to exactly 1000 in each arm, with no participants left over. If any tick stood for several censorings, or a drop for several tied events, both the fractional residuals and the totals would drift. They do not, so I adopt one tick = one censoring and one drop = one event. This is still an inference, not a proof. For example, a compensating pair of hidden errors cannot be excluded.

**Ties.** There are no tied event times and no tied censor times. One censor tick per arm lies within 1e-4 months of an event. It was kept at its own measured time. Had it been treated as tied, the checks would count the event before the censoring.

**Risk table.** The displayed counts at 0, 6, 12, 18, 24, 30 and 36 months were read from the PDF text and were not used as inputs. Counting records with observed_time ≥ t reproduces all 14 counts exactly, including 0 at 36 months. The last record is at 35.92 months in A and 35.97 months in B, both before 36.

**Checks** (`checks.json`, computed from the reloaded committed CSV):
- The right-continuous KM estimate matches the measured curve at 15 times per arm, including the start and the tail, with |residual| < 3e-7.
- The maximum error just after all drops is 2.8e-7. The tolerance is 0.001, equivalent to 0.18 pt.
- Times are stored to 6 decimals, below the smallest gap between distinct times (9e-6 months).
- The CSV SHA-256 is recorded in `checks.json`.

**Limitations.**
- Times are recovered only to the plotting precision of the PDF, about 1e-4 pt, or roughly 1e-5 months.
- Censorings that are not marked, or ticks hidden exactly on top of one another, cannot be seen directly. The evidence against them is indirect: the integer consistency and the exact risk-table agreement.
- The tail after the last event (last event: A at 35.10 months, B at 34.91 months) is determined only by the tick positions. There was no extrapolation.

**Sensitivity analysis.** None was run. The supplied observations leave no materially different allocation: any alternative would break either the drop integrality or the risk-table counts. No primary correction cycles were used.
