"""Extract KM step vertices and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, os
import pdfplumber, numpy as np, pandas as pd
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
blk = [l for l in pg.lines if tuple(np.atleast_1d(l['stroking_color'])) == (0.0, 0.0, 0.0)]
# axis anchors from labelled tick marks: x ticks at labels 0..36, y ticks at 0.0..1.0
xt = sorted({round(l['pts'][0][0], 4) for l in blk if abs(l['pts'][0][0]-l['pts'][1][0]) < 1e-6 and l['pts'][1][1] > 224})
yt = sorted({round(l['pts'][0][1], 4) for l in blk if abs(l['pts'][0][1]-l['pts'][1][1]) < 1e-6 and l['pts'][0][0] < 64})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
cal = dict(x_ticks_pt=xt, y_ticks_pt=yt, t_per_pt=ax, t0=bx, s_per_pt=ay, s0=by,
           x_resid=list(np.polyval([ax, bx], xt)-xlab), y_resid=list(np.polyval([ay, by], yt)-ylab))
# legend: line segment just left of "Group A"/"Group B" text
cols = {}
legend = [l for l in pg.lines if l['linewidth'] == 1.0]
words = pg.extract_words()
for g in 'AB':
    wx = [w for w in words if w['text'] == g and w['top'] < 30][0]['x0']
    seg = min(legend, key=lambda l: abs(wx - 30 - l['pts'][1][0]) if l['pts'][1][0] < wx else 1e9)
    cols[g] = tuple(seg['stroking_color'])
cal['colors'] = {g: list(c) for g, c in cols.items()}
os.makedirs(out, exist_ok=True)
for g, c in cols.items():
    cv = [cv for cv in pg.curves if tuple(cv['stroking_color']) == c][0]['pts']
    v = pd.DataFrame(cv, columns=['x', 'y'])
    v['t'] = ax*v.x + bx; v['S'] = ay*v.y + by
    v.to_csv(f'{out}/vertices_{g}.csv', index=False)
    tk = [l for l in pg.lines if l['linewidth'] == 0.65 and tuple(l['stroking_color']) == c]
    k = pd.DataFrame({'x': [l['pts'][0][0] for l in tk],
                      'ymid': [(l['pts'][0][1]+l['pts'][1][1])/2 for l in tk]})
    k['t'] = ax*k.x + bx; k['S'] = ay*k.ymid + by
    k.sort_values('t').to_csv(f'{out}/censor_ticks_{g}.csv', index=False)
json.dump(cal, open(f'{out}/calibration.json', 'w'), indent=1)
print(json.dumps(cal, indent=1))
