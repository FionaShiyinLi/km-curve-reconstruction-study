# Reconstruction assumptions and method

**Inputs used.** `../input/figure.pdf` (vector PDF) and `../input/manifest.json`: N = 100 per arm, time unit is months, seed 1576566624. The seed is recorded and set, but the algorithm is deterministic and uses no randomness. The manifest has no arm-specific event totals, so that check is marked unavailable. It is not treated as zero.

**Measurement.** The PDF contains the KM curves as vector step paths, one per arm, identified by colour through the legend. Censor marks are drawn as separate short vertical line objects in the same colour. I did not rasterise or OCR anything. Coordinates were read directly with pdfplumber.
- Calibration uses the labelled axis ticks: x ticks 0–36 months and y ticks 0–1.0. A linear fit gives residuals below 1e-13. No global rescaling or correction was applied. Both curves start exactly at S = 1.0 at time 0, so no origin repair was needed.
- Vertical path segments give the time of each drop and the survival values before and after it, at a precision of about 1e-5 pt. Censor times are the x positions of the tick objects. Two tick objects in arm B are nearly coincident (31.01425 and 31.01442 months) and would look like a single mark in a raster image. They are kept as two censorings. The data support this: after the last B drop, 13 participants remain at risk, and that count needs both marks.
- Raw extractions are saved in `drops_*.csv`, `ticks_*.csv` and `extraction_meta.json`.

**Algorithm** (`code/reconstruct.py`). The script walks the drops in time order. At each drop it searches for integers (c = censorings since the previous drop, d = events) such that S_prev·(1 − d/(n − c)) reproduces the measured post-drop level to within 0.02 pt. If several pairs fit, it prefers the c closest to the number of ticks in that interval. In practice this tie-break was never needed: every drop fitted to within 5e-5 pt, with d = 1 and c equal to the tick count in every interval. The value of d comes from drop height together with n_risk. It was not assumed to be 1.
- The running S is propagated from the integer KM rather than from the measured points, so reading errors cannot accumulate.
- Censorings take the tick times. A tick at exactly an event time would be treated as censored after the event, but none occurred.
- After the last drop, the remaining at-risk count (A: 9, B: 13) equals the number of remaining ticks. Those participants are censored at the tick times, the last of which coincides with the end of the drawn curve (A 35.13, B 35.43 months).
- No unmarked censorings were needed. Code exists to spread them evenly between drops, but it was never triggered.
- Result: A has 82 events and 18 censorings; B has 60 events and 40 censorings. Times are rounded to 4 decimals, which leaves distinct drops distinct.

**Risk table.** Read from the PDF text: A = 100/72/47/31/20/7/0 and B = 100/65/56/46/41/16/0 at 0, 6, …, 36 months. The table was not used as a fitting input. It serves as an independent check, using the count #{observed_time ≥ t}. All 14 counts match exactly. No record lies at or beyond 36 months.

**Verification** (`code/checks.py` → `checks.json`). The script reloads the committed CSV and recomputes the right-continuous KM step function. It compares that with the vector curve at 17 times per arm, including 0.25 months and the curve end, and on a dense grid of 2001 points. The maximum absolute difference is 2.8e-7, against a tolerance of 0.0005 in S (0.09 pt, far below the line width). All curve, risk-table, size, event-indicator and tail checks pass. The SHA-256 of the CSV is recorded in `checks.json`.

**Limitations.**
- Exact event times inside a drop are recovered only to the precision of the vector coordinates.
- Censoring times are taken from mark positions. If the figure's software displaced or merged marks, that would not be detectable, although here the marks and the drop-implied n_risk agree everywhere.
- Follow-up beyond each arm's last mark is not identified and was not invented.
- Sensitivity analysis was not run. The drop heights determine n_risk exactly at every event, and these values agree with the mark counts and with every risk-table entry, so no materially different allocation of censorings and events is consistent with the inputs. The only remaining freedom is where each censoring falls within its inter-event interval, and the tick positions fix that.

Run from the work directory with `python3 output/code/reconstruct.py [input_dir] [output_dir]`, then `python3 output/code/checks.py [input_dir] [output_dir]`.
