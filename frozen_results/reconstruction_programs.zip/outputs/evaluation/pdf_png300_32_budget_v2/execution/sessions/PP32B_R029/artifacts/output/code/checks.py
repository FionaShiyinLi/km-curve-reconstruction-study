#!/usr/bin/env python3
"""Reload committed output/ipd.csv, recompute right-continuous KM, compare with vector-measured curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reconstruct as R   # reuses extraction/calibration only (reads the PDF)
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
path = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
res = dict(ipd_sha256=sha, calibration=R.calib, groups={})
TOL_S = 0.0005   # vector path coordinates precise to ~1e-5 pt; 0.0005 in S = 0.09 pt, far below line width
def km(d, t):
    s = 1.0
    for u in np.sort(d.loc[d.event == 1, 'observed_time'].unique()):
        if u > t: break
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1 - e / n
    return s
def measured(pts, t):  # right-continuous step read from vector path: last vertex with time <= t
    tt = R.T(pts[:, 0]); ss = R.S(pts[:, 1])
    idx = np.where(tt <= t + 1e-9)[0]
    return float(ss[idx].min())   # at a vertical segment the lower end is the post-drop value
for g in ('A', 'B'):
    d = df[df.group == g]; e = R.extract(g); pts = e['pts']
    ok_basic = dict(n=int(len(d)), n_expected=R.man['groups'][g], events=int(d.event.sum()),
                    event_int=bool(d.event.isin([0, 1]).all()), time_ok=bool((d.observed_time >= 0).all() and np.isfinite(d.observed_time).all()),
                    supplied_event_total='unavailable (not in manifest)')
    tend = float(R.T(e['x_end']))
    times = [0.25, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, round(tend, 4)]
    curve = []
    for t in times:
        m = measured(pts, t); r = km(d, t)
        curve.append(dict(t=t, measured=round(m, 6), reconstructed=round(r, 6), resid=round(r - m, 6),
                          status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # dense check at every drop +- epsilon
    dense = [abs(km(d, t) - measured(pts, t)) for t in np.linspace(0, tend, 2001)]
    risk = []
    for t, nr in zip(R.risk_times, R.rows[g]):
        c = int((d.observed_time >= t).sum())
        risk.append(dict(t=t, table=nr, reconstructed=c, resid=c - nr, status='pass' if c == nr else 'fail'))
    res['groups'][g] = dict(basic=ok_basic, curve_checks=curve, dense_grid_max_abs_resid=float(max(dense)),
                            dense_grid_status='pass' if max(dense) <= TOL_S else 'fail',
                            risk_table=risk, tail=dict(curve_end=tend, max_observed_time=float(d.observed_time.max()),
                            n_at_or_after_curve_end=int((d.observed_time >= tend - 1e-4).sum()),
                            status='pass' if d.observed_time.max() <= tend + 1e-4 else 'fail'))
res['tolerance_note'] = 'S tolerance 0.0005 (0.09 pt): PDF vector coordinates carry ~5 decimals; risk counts require exact equality; counting convention n(t)=#{observed_time>=t}.'
res['sensitivity'] = 'not run: drop heights identify n_risk exactly at every event and match censor-mark counts in every interval; see assumptions.md'
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in res['groups']:
    G = res['groups'][g]; print(g, G['basic'], 'dense', G['dense_grid_max_abs_resid'], G['tail'])
    for r in G['risk_table']: print('  risk', r)
    print('  curve fails:', [c for c in G['curve_checks'] if c['status'] != 'pass'])
print(sha)
