#!/usr/bin/env python3
"""KM -> IPD reconstruction from vector PDF paths (own implementation).
Usage: python reconstruct.py [path/to/input_dir] [path/to/output_dir]
Defaults: ../input relative to cwd, and output/ relative to cwd.
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 1576566624
np.random.seed(SEED)  # no randomness is actually used; recorded for completeness
IN = sys.argv[1] if len(sys.argv) > 1 else os.path.join('..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
man = json.load(open(os.path.join(IN, 'manifest.json')))
pg = pdfplumber.open(os.path.join(IN, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks (words + tick lines)
words = pg.extract_words()
blk = [l for l in pg.lines if l.get('stroking_color') == (0.0, 0.0, 0.0)]
xt = sorted({round(l['x0'], 3) for l in blk if abs(l['x0'] - l['x1']) < 1e-6 and l['bottom'] - l['top'] < 5})
yt = sorted({round(l['top'], 3) for l in blk if abs(l['top'] - l['bottom']) < 1e-6 and l['x1'] - l['x0'] < 5})
xlab = sorted([(w['x0'] + w['x1']) / 2, float(w['text'])] for w in words if w['top'] > 225 and w['top'] < 235)
ylab = sorted([(w['top'] + w['bottom']) / 2, float(w['text'])] for w in words if w['x0'] < 50 and w['text'].replace('.', '').isdigit())
# pair each label with nearest tick
xp = np.array([[min(xt, key=lambda t: abs(t - c)), v] for c, v in xlab])
yp = np.array([[min(yt, key=lambda t: abs(t - c)), v] for c, v in ylab])
ax_, bx_ = np.polyfit(xp[:, 0], xp[:, 1], 1); ay_, by_ = np.polyfit(yp[:, 0], yp[:, 1], 1)
calib = dict(x_pairs=xp.tolist(), y_pairs=yp.tolist(),
             x_resid_max=float(np.abs(ax_ * xp[:, 0] + bx_ - xp[:, 1]).max()),
             y_resid_max=float(np.abs(ay_ * yp[:, 0] + by_ - yp[:, 1]).max()))
T = lambda x: ax_ * np.asarray(x) + bx_
S = lambda y: ay_ * np.asarray(y) + by_

# risk table from text rows
risk_times = [v for _, v in xlab]
def risk_row(label_top):
    ws = sorted([w for w in words if abs(w['top'] - label_top) < 1 and w['text'].isdigit()], key=lambda w: w['x0'])
    return [int(w['text']) for w in ws]
rows = {}
for w in words:
    if w['text'] in ('A', 'B') and w['top'] > 270:
        rows[w['text']] = risk_row(w['top'])

colors = {}
for w in words:  # legend: colour line next to "Group X" legend label
    pass
leg = [l for l in pg.lines if l['linewidth'] > 0.9 and l.get('stroking_color') != (0.0, 0.0, 0.0)]
legwords = [w for w in words if w['top'] < 30 and w['text'] in ('A', 'B')]
for l in leg:
    g = min(legwords, key=lambda w: abs(w['x0'] - l['x1']) if w['x0'] > l['x1'] else 1e9)['text']
    colors[g] = l['stroking_color']

def extract(g):
    col = colors[g]
    cv = [c for c in pg.curves if c.get('stroking_color') == col][0]
    pts = np.array(cv['pts'])
    # drops: vertical segments (same x, y increasing downward in top coords)
    drops = []
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-9 and y1 > y0 + 1e-9:
            if drops and abs(drops[-1][0] - x0) < 1e-9 and abs(drops[-1][2] - y0) < 1e-9:
                drops[-1][2] = y1
            else:
                drops.append([x0, y0, y1])
    ticks = [l for l in pg.lines if l.get('stroking_color') == col and l['linewidth'] < 0.9]
    tk = sorted([(l['x0'], (l['top'] + l['bottom']) / 2) for l in ticks])
    return dict(pts=pts, drops=drops, ticks=tk, x_end=pts[-1, 0])

def reconstruct(g, N, verbose=True):
    e = extract(g)
    drops = [(float(T(x)), float(S(y0)), float(S(y1))) for x, y0, y1 in e['drops']]
    ticks = [(float(T(x)), float(S(y))) for x, y in e['ticks']]
    tend = float(T(e['x_end']))
    n = N; s = 1.0; recs = []; log = []; ti = 0
    for k, (t, sb, sa) in enumerate(drops):
        # ticks strictly before this drop time (KM: censor at tie counted at risk -> tick at t goes after)
        tk_here = []
        while ti < len(ticks) and ticks[ti][0] < t - 1e-9:
            tk_here.append(ticks[ti][0]); ti += 1
        best = None
        for c in range(0, n):
            nn = n - c
            for d in range(1, nn + 1):
                pred = s * (1 - d / nn)
                err = abs(pred - sa) * 180  # in points
                if err < 0.02:
                    key = (abs(c - len(tk_here)), c, d)
                    if best is None or key < best[0]:
                        best = (key, c, d, nn, err)
        if best is None:
            raise RuntimeError(f'{g}: no integer (c,d) fits drop at t={t:.3f}')
        _, c, d, nn, err = best
        # censor times: tick times; if more censors than ticks -> unmarked censors
        ctimes = list(tk_here)
        extra = c - len(ctimes)
        if extra > 0:  # unmarked: spread evenly between previous drop and this one
            tprev = drops[k - 1][0] if k else 0.0
            ctimes += list(np.linspace(tprev, t, extra + 2)[1:-1])
        elif extra < 0:  # more ticks than inferred censors: keep the latest-by-fit subset
            ctimes = ctimes[-c:] if c else []
        recs += [(g, ct, 0) for ct in ctimes] + [(g, t, 1)] * d
        log.append(dict(t=t, S_before_meas=sb, S_after_meas=sa, ticks_before=len(tk_here), c=c, n_risk=nn, d=d, fit_err_pt=err))
        n = nn - d; s = s * (1 - d / nn)
        if abs(s - sb * (1 - d / nn)) * 180 > 0.05 and verbose:
            print('warn drift', g, t, s, sa)
    rest = [tt for tt, _ in ticks[ti:]]
    if verbose:
        print(g, 'remaining at risk after last drop', n, 'ticks after', len(rest), 'curve end', tend)
    tail_note = dict(n_remaining=n, ticks_after_last_drop=len(rest), curve_end=tend)
    if n >= len(rest):
        ct = rest + [tend] * (n - len(rest))
    else:
        ct = rest[-n:] if n else []
    recs += [(g, x, 0) for x in ct]
    return recs, log, tail_note, drops, ticks

if __name__ == '__main__':
    print('calib', calib); print('risk rows', rows, 'times', risk_times); print('colors', colors)
    allrec = []; logs = {}; tails = {}
    for g in ('A', 'B'):
        recs, log, tail, drops, ticks = reconstruct(g, man['groups'][g])
        assert len(recs) == man['groups'][g], (g, len(recs))
        allrec += recs; logs[g] = log; tails[g] = tail
        pd.DataFrame(log).to_csv(os.path.join(OUT, f'drops_{g}.csv'), index=False)
        pd.DataFrame(ticks, columns=['time', 'S_at_tick']).to_csv(os.path.join(OUT, f'ticks_{g}.csv'), index=False)
    df = pd.DataFrame(allrec, columns=['group', 'observed_time', 'event'])
    df['observed_time'] = df['observed_time'].round(4)
    df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
    json.dump(dict(calibration=calib, risk_rows=rows, risk_times=risk_times, tails=tails),
              open(os.path.join(OUT, 'extraction_meta.json'), 'w'), indent=1)
    for g in logs:
        print(pd.DataFrame(logs[g]).to_string())
