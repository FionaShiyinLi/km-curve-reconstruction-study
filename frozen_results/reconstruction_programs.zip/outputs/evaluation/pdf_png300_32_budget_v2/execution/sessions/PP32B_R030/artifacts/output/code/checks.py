"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table."""
import os, json, hashlib
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, '..')
ipd = pd.read_csv(os.path.join(OUT, 'ipd.csv'))
ext = json.load(open(os.path.join(OUT, 'extracted.json')))
sha = hashlib.sha256(open(os.path.join(OUT, 'ipd.csv'), 'rb').read()).hexdigest()
# risk table as printed in the PDF text layer (times 0,6,...,36)
RISK = {'A': [1000, 667, 463, 312, 198, 78, 0], 'B': [1000, 758, 564, 419, 323, 129, 0]}
RT = [0, 6, 12, 18, 24, 30, 36]
TOL_S = 0.001   # vector coordinates are given to 1e-4 pt (~6e-7 in S); 0.001 = one event at n=1000

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S))
    return np.array(out)

def S_at(step, x):   # right-continuous
    i = np.searchsorted(step[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else step[i, 1]

def measured_at(g, x):   # extracted curve level at x (right-continuous)
    st = np.array(ext[g]['steps']); i = np.searchsorted(st[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else st[i, 2]

chk = {'csv_sha256': sha, 'tolerance_S': TOL_S,
       'tolerance_note': 'vector PDF coordinates, precision ~6e-7 in S; tolerance = 1/1000', 'groups': {}}
allpass = True
for g in ['A', 'B']:
    d = ipd[ipd.group == g]; k = km(d)
    st = np.array(ext[g]['steps'])
    times = sorted(set([0, 0.25, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 34.5, 35, 35.5, 35.8, float(st[-1, 0]) + 1e-4, float(ext[g]['end'][0])]))
    # plateau points: midpoints between consecutive step times (avoid evaluating exactly on a jump)
    plate = np.append((st[:-1, 0] + st[1:, 0]) / 2, st[-1, 0] + 1e-4)
    sc = []
    for x in times:
        m, r = measured_at(g, x), S_at(k, x)
        sc.append(dict(t=round(x, 4), measured=round(m, 6), reconstructed=round(r, 6), resid=round(r - m, 7),
                       status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # all step levels
    allres = np.array([S_at(k, x) for x in plate]) - st[:, 2]
    rk = []
    for t, n in zip(RT, RISK[g]):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=c, diff=c - n, status='pass' if c == n else 'fail'))
    gp = dict(n_records=len(d), N_manifest=1000, n_events=int(d.event.sum()), n_censored=int((d.event == 0).sum()),
              event_total_supplied='unavailable (manifest has no event totals)',
              event_indicator_integer=bool(d.event.isin([0, 1]).all()),
              max_time=float(d.observed_time.max()), curve_end_time=ext[g]['end'][0],
              survival_checks=sc, max_abs_resid_all_step_levels=float(np.abs(allres).max()),
              n_step_levels_checked=len(st), step_level_note='each plateau checked at midpoint between consecutive step times', risk_table=rk)
    ok = all(s['status'] == 'pass' for s in sc) and all(r['status'] == 'pass' for r in rk) and len(d) == 1000
    gp['overall'] = 'pass' if ok else 'fail'; allpass &= ok
    chk['groups'][g] = gp
    print(g, gp['overall'], 'max step resid', gp['max_abs_resid_all_step_levels'], [(r['t'], r['displayed'], r['reconstructed']) for r in rk])
chk['overall'] = 'pass' if allpass else 'fail'
json.dump(chk, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
