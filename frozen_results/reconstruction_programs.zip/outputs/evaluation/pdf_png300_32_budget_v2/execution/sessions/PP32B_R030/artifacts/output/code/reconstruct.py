"""Reconstruct IPD from extracted vector KM steps and censor ticks.
Usage: python reconstruct.py [path/to/figure.pdf] [path/to/manifest.json]
Runs extract.py first, then writes ../ipd.csv atomically (relative to this file)."""
import sys, os, json, subprocess, hashlib
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..')
PDF = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input', 'figure.pdf')
MAN = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..', '..', '..', 'input', 'manifest.json')
man = json.load(open(MAN))
SEED = man['code_seed']            # recorded; the algorithm below is deterministic
np.random.seed(SEED)
subprocess.run([sys.executable, os.path.join(HERE, 'extract.py'), PDF, OUT], check=True)
ext = json.load(open(os.path.join(OUT, 'extracted.json')))

def reconstruct(g, N):
    steps = np.array(ext[g]['steps']); ticks = np.array(ext[g]['ticks'])
    ev_t = steps[:, 0]; Sb = steps[:, 1]; Sa = steps[:, 2]
    r = 1 - Sa / Sb                                  # = d / n_risk
    cen_t = np.sort(ticks[:, 0])
    recs, diag = [], []
    n = N; ci = 0
    for j in range(len(ev_t)):
        # censorings strictly before this event time leave the risk set first
        while ci < len(cen_t) and cen_t[ci] < ev_t[j] - 1e-9:
            recs.append((cen_t[ci], 0)); n -= 1; ci += 1
        d_float = n * r[j]
        d = max(1, int(round(d_float)))
        diag.append(dict(t=ev_t[j], n_forward=n, d_float=d_float, d=d, n_implied_d=d / r[j]))
        recs += [(ev_t[j], 1)] * d; n -= d
    while ci < len(cen_t):
        recs.append((cen_t[ci], 0)); n -= 1; ci += 1
    # participants not accounted for (n>0) or over-allocation (n<0)
    return recs, pd.DataFrame(diag), n

frames, diags, info = [], {}, {}
for g in ['A', 'B']:
    N = man['groups'][g]
    recs, dg, left = reconstruct(g, N)
    diags[g] = dg
    info[g] = dict(N=N, events=int(dg.d.sum()), ticks=len(ext[g]['ticks']), leftover=left,
                   max_abs_d_resid=float((dg.d_float - dg.d).abs().max()),
                   max_abs_n_diff=float((dg.n_implied_d - dg.n_forward).abs().max()))
    print(g, info[g])
    if left != 0:
        raise SystemExit(f'group {g}: {left} participants unallocated; not writing CSV')
    df = pd.DataFrame(recs, columns=['observed_time', 'event']); df.insert(0, 'group', g)
    frames.append(df)
    dg.to_csv(os.path.join(OUT, f'step_diagnostics_{g}.csv'), index=False)

ipd = pd.concat(frames, ignore_index=True)
ipd['observed_time'] = ipd.observed_time.clip(lower=0)
tmp = os.path.join(OUT, 'ipd.csv.tmp')
ipd.to_csv(tmp, index=False, float_format='%.10f'); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
print('wrote ipd.csv sha256', hashlib.sha256(open(os.path.join(OUT, 'ipd.csv'), 'rb').read()).hexdigest())
