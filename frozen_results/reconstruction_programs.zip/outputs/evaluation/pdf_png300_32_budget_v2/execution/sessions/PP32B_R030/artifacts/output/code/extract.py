"""Extract KM step curves and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, os
import pdfplumber
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PDF = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input', 'figure.pdf')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..')
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}

def calib(pg):
    """Axis calibration from labelled tick marks (black lines) and tick labels."""
    xt, yt = [], []
    for l in pg.lines:
        if tuple(l['stroking_color']) != (0.0, 0.0, 0.0):
            continue
        (x0, y0), (x1, y1) = l['pts']
        if x0 == x1 and abs(y1 - y0) == 3: xt.append(x0)
        if y0 == y1 and abs(x1 - x0) == 3: yt.append(y0)
    xt, yt = sorted(set(xt)), sorted(set(yt))
    tvals = [0, 6, 12, 18, 24, 30, 36]          # x tick labels read from PDF text
    svals = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]       # y ticks top->bottom (pdfplumber y increases downward)
    ax, bx = np.polyfit(xt, tvals, 1)
    ay, by = np.polyfit(yt, svals, 1)
    res = dict(x_ticks=xt, y_ticks=yt, t_per_pt=ax, t_int=bx, s_per_pt=ay, s_int=by,
               x_resid=float(np.max(np.abs(np.polyval([ax, bx], xt) - tvals))),
               y_resid=float(np.max(np.abs(np.polyval([ay, by], yt) - svals))))
    return res

def main():
    pg = pdfplumber.open(PDF).pages[0]
    cal = calib(pg)
    T = lambda x: cal['t_per_pt'] * x + cal['t_int']
    S = lambda y: cal['s_per_pt'] * y + cal['s_int']
    out = {'calibration': cal}
    for g, col in COL.items():
        cv = [c for c in pg.curves if tuple(c['stroking_color']) == col]
        assert len(cv) == 1
        pts = cv[0]['pts']
        steps = []   # (t, S_before, S_after) for each vertical segment
        for (xa, ya), (xb, yb) in zip(pts[:-1], pts[1:]):
            if xa == xb and yb != ya:
                steps.append((T(xa), S(ya), S(yb)))
            elif ya != yb:
                raise ValueError('non-axis-aligned segment')
        ticks = []
        for l in pg.lines:
            if tuple(l['stroking_color']) == col and l['linewidth'] == 0.65:
                (x0, y0), (x1, y1) = l['pts']
                ticks.append((T(x0), S((y0 + y1) / 2)))
        out[g] = dict(start=(T(pts[0][0]), S(pts[0][1])), end=(T(pts[-1][0]), S(pts[-1][1])),
                      steps=steps, ticks=sorted(ticks))
    json.dump(out, open(os.path.join(OUT, 'extracted.json'), 'w'), indent=1)
    print(json.dumps(cal))
    for g in COL:
        o = out[g]
        print(g, 'start', o['start'], 'end', o['end'], 'nsteps', len(o['steps']), 'nticks', len(o['ticks']))

if __name__ == '__main__':
    main()
