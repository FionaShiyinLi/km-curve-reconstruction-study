# Reconstruction assumptions and method

**Inputs used.** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (N = 1000 per arm, months, code seed 1257166152). No other information was used. The manifest has no event totals, so those are marked unavailable in `checks.json`.

**Measurement.** The PDF is vector-based, so I read coordinates from the PDF objects with pdfplumber rather than from pixels (`code/extract.py`).
- Calibration comes from the black axis tick marks and their text labels. x ticks at 0, 6, …, 36 months map linearly to x = 64.8…410.4 pt (0.104167 months/pt). y ticks at 1.0, …, 0.0 map to y = 43.2…223.2 pt. The linear fit residual is about 1e-14.
- Group A is the blue path and Group B the orange path, identified from the legend line colors.
- Each arm is one axis-aligned step path starting at exactly (0, 1.0). No origin correction, global rescaling or running-minimum step was applied or needed.
- Censor marks are separate 0.65-pt vertical line objects: 207 for A and 334 for B. They are centered on the curve level, and none are duplicated at the same x.
- The extracted steps, marks and calibration are saved in `extracted.json`.

**Algorithm** (`code/reconstruct.py`, deterministic; the seed is recorded but no randomness is used).
- For each vertical drop at time t, r = 1 − S_after/S_before = d/n_risk.
- n_risk is tracked forward from N by subtracting earlier events and the censorings at mark times strictly before t. The event count is then d = round(n_risk · r).
- d was not assumed to be 1. It was estimated at every drop, and the non-integer part of n_risk · r was at most 0.0005 (A) and 0.0015 (B). Every drop resolved to d = 1.
- This gives 793 events + 207 censorings = 1000 for A, and 666 + 334 = 1000 for B. No participants were left over or over-allocated.
- The step sizes independently imply n_risk to within 0.8 of the forward count, which is consistent with the coordinate precision (1e-4 pt). This supports counting each mark as exactly one censoring.
- Censored records are placed at the mark times. Event records are placed at the step times. Times are stored at full precision.

**Censoring / ties / risk table.**
- One B censor mark shares its x coordinate with an event step. Following the usual KM convention, the event is counted first and the censored participant stays at risk at that time.
- The last record in each arm is a censoring at the curve end: A at 35.885 months, B at 35.974 months. Both are before 36, so the displayed zero at risk at 36 is respected without placing anyone at t = 36.
- The risk table (read from the PDF text layer) matches exactly at 0, 6, 12, 18, 24, 30 and 36 months in both arms, counting observed_time ≥ t. It was not used as a fitting constraint, so it serves as an independent check.

**Verification** (`code/checks.py` → `checks.json`).
- The committed CSV is reloaded and a right-continuous KM curve recomputed.
- Each plateau of the extracted curve is compared at the midpoint between consecutive step times. Maximum |residual| is 2.8e-7 (A) and 2.3e-6 (B), against a tolerance of 0.001 (one event at n = 1000; the coordinate precision is about 6e-7 in S).
- A grid of times from 0 to the tail (including 34–35.9 months) also passes.
- An earlier check evaluated exactly on jump times. It failed because of float representation and 5-decimal rounding of the times, so I removed the rounding from the CSV (correction cycle 1) and moved the check to plateau points. The tolerance was not changed.

**Limitations.**
- Exact times are recovered only up to the drawing precision of the PDF (about 1e-5 months).
- The figure cannot rule out coincident censorings drawn as a single overlapping mark, or coincident events drawn as one drop. However, the step-ratio arithmetic at every drop and the exact agreement with all risk counts give no evidence of either.
- Censoring times beyond what the marks show (for example, administrative follow-up) are not identified, and none were invented.

**Sensitivity analysis.** Not run. The event/censor allocation is fully pinned down by the per-drop ratios, the mark count and the risk table. The only remaining choice is the tie order at the one coincident B time, and flipping it changes n_risk by 1 at a single event, which is immaterial. That is not a materially different plausible allocation, so no `sensitivity.csv` was produced. This is not an uncertainty bound.

**Reproduce:** `python code/reconstruct.py [figure.pdf] [manifest.json] && python code/checks.py` (the default paths are relative to `output/code/`).
