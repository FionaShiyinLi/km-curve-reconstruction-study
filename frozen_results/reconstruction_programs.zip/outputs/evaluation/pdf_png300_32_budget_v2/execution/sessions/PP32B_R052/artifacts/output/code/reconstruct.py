"""KM-to-IPD reconstruction from the vector PDF (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]
Defaults: ../input and ./output relative to the working directory."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

INP = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
SEED = 1148555630
np.random.seed(SEED)  # recorded; algorithm is deterministic
man = json.load(open(os.path.join(INP, "manifest.json")))
pg = pdfplumber.open(os.path.join(INP, "figure.pdf")).pages[0]

# ---- calibration from labelled axis ticks (black 0.6pt tick marks + text labels)
words = pg.extract_words()
blk = [l for l in pg.lines if l.get("stroking_color") == (0.0, 0.0, 0.0)]
xt = sorted({round(l["x0"], 3) for l in blk if abs(l["top"] - 223.2) < 0.01 and abs(l["bottom"] - 226.2) < 0.01})
yt = sorted({round(l["top"], 3) for l in blk if abs(l["x0"] - 61.8) < 0.01 and abs(l["x1"] - 64.8) < 0.01})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # top->bottom
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
T = lambda x: ax * x + bx
S = lambda y: ay * y + by
calib = dict(x_ticks_pt=xt, y_ticks_pt=yt, t_per_pt=ax, t0=bx, s_per_pt=ay, s0=by,
             x_resid=float(np.max(np.abs(T(np.array(xt)) - xlab))), y_resid=float(np.max(np.abs(S(np.array(yt)) - ylab))))

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}  # legend order
# risk table (text rows)
rt = {}
for g in "AB":
    row = [w for w in words if w["text"] == g and w["x0"] < 55 and w["top"] > 280]
    top = row[0]["top"]
    nums = sorted([w for w in words if abs(w["top"] - top) < 0.5 and w["x0"] > 55], key=lambda w: w["x0"])
    rt[g] = {int(round(T((w["x0"] + w["x1"]) / 2))): int(w["text"]) for w in nums}

def extract(g):
    cv = [c for c in pg.curves if c.get("stroking_color") == COL[g] and c["linewidth"] == 1.0][0]
    pts = [(T(x), S(y)) for x, y in cv["pts"]]
    steps = []  # (time, S_before, S_after)
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-9 and s1 < s0 - 1e-9:
            steps.append((t1, s0, s1))
    ticks = [l for l in pg.lines if l.get("stroking_color") == COL[g] and abs(l["linewidth"] - 0.65) < 0.01]
    cens = sorted((T(l["x0"]), S((l["top"] + l["bottom"]) / 2)) for l in ticks)
    return pts, steps, cens, pts[-1][0]

def reconstruct(g, n0):
    pts, steps, cens, tend = extract(g)
    # merge steps at identical time (should not occur but be safe)
    ev = []
    for t, a, b in steps:
        if ev and abs(ev[-1][0] - t) < 1e-6: ev[-1][2] = b
        else: ev.append([t, a, b])
    recs, log = [], []
    n = n0; ci = 0
    for t, sb, sa in ev:
        # displayed censor ticks strictly before this drop (ties: events first)
        while ci < len(cens) and cens[ci][0] < t - 1e-6:
            recs.append((cens[ci][0], 0)); n -= 1; ci += 1
        q = 1 - sa / sb
        # choose d with implied n_risk = d/q closest to current n (n_risk may not exceed n)
        best = None
        for d in range(1, n + 1):
            nr = d / q
            if nr > n + 0.5: break
            err = abs(nr - n)
            if best is None or err < best[1]: best = (d, err, nr)
        d, err, nr = best
        hidden = n - int(round(nr))
        if hidden > 0:  # undisplayed censorings needed: place just before drop at previous event/tick time midpoint
            prev = recs[-1][0] if recs else 0.0
            for k in range(hidden): recs.append(((prev + t) / 2, 0))
            n -= hidden
        for k in range(d): recs.append((t, 1))
        log.append(dict(t=t, S_before=sb, S_after=sa, n_risk=n, d=d, implied_n=nr, hidden_cens=hidden))
        n -= d
    while ci < len(cens):
        recs.append((cens[ci][0], 0)); n -= 1; ci += 1
    rem = n
    if rem > 0:  # survivors not shown by distinct ticks: censor at last tick / curve end (overlapping ticks)
        for k in range(rem): recs.append((tend, 0))
    return recs, log, cens, ev, tend, rem

allrecs, info = [], {}
for g in "AB":
    recs, log, cens, ev, tend, rem = reconstruct(g, man["groups"][g])
    assert len(recs) == man["groups"][g]
    allrecs += [(g, t, e) for t, e in recs]
    info[g] = dict(n_steps=len(ev), n_ticks=len(cens), curve_end=tend, extra_end_censors=rem,
                   events=int(sum(e for _, e in recs)), hidden_censors=int(sum(l["hidden_cens"] for l in log)),
                   max_implied_n_err=float(max(abs(l["implied_n"] - l["n_risk"] - l["hidden_cens"]) for l in log)),
                   multi_event_steps=[round(l["t"], 3) for l in log if l["d"] > 1], step_log=log,
                   ticks=[[round(t, 4), round(s, 4)] for t, s in cens],
                   curve_pts=[[round(t, 4), round(s, 5)] for t, s in extract(g)[0]])
df = pd.DataFrame(allrecs, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].round(4).clip(lower=0)
os.makedirs(OUT, exist_ok=True)
tmp = os.path.join(OUT, ".ipd.csv.tmp"); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, "ipd.csv"))
json.dump(dict(calibration=calib, risk_table=rt, groups=info), open(os.path.join(OUT, "extraction.json"), "w"), indent=1)
for g in "AB":
    i = info[g]; print(g, {k: v for k, v in i.items() if k not in ("step_log", "ticks", "curve_pts")})
print(calib); print(rt)
