"""Verify committed output/ipd.csv against extracted curve and risk table. Usage: python checks.py [output_dir]"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path); ext = json.load(open(os.path.join(OUT, "extraction.json")))
def km(d):
    ts = np.sort(d.loc[d.event == 1, "observed_time"].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for u, v in steps:
        if u <= t: s = v
    return s
def curve_at(pts, t):  # measured vector step curve, right-continuous (take last vertex with time<=t)
    s = pts[0][1]
    for u, v in pts:
        if u <= t + 1e-9: s = v
    return s
TOL = 0.002  # vector coordinates: rounding of 4-5 decimals in PDF + 4-dp time rounding in CSV
res = dict(csv_sha256=sha, tolerance_survival=TOL, tolerance_note="PDF vector coordinates are exact to ~1e-4 pt; 0.002 in S covers coordinate rounding only",
           groups={})
for g in "AB":
    d = df[df.group == g]; st = km(d); pts = ext["groups"][g]["curve_pts"]
    tend = ext["groups"][g]["curve_end"]
    times = sorted(set([0, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, round(tend - 0.01, 2), round(tend, 4)]))
    cc = []
    for t in times:
        m = curve_at(pts, t); r = S_at(st, t)
        cc.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), resid=round(r - m, 5), status="pass" if abs(r - m) <= TOL else "fail"))
    # also every step
    stepres = max(abs(S_at(st, l["t"] + 1e-3) - l["S_after"]) for l in ext["groups"][g]["step_log"])
    rk = []
    for t, n in ext["risk_table"][g].items():
        t = float(t); c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=c, resid=c - n, status="pass" if c == n else "fail"))
    res["groups"][g] = dict(n=len(d), n_expected=100, n_status="pass" if len(d) == 100 else "fail",
        events=int(d.event.sum()), censored=int((d.event == 0).sum()),
        event_indicator_integer=bool(set(d.event.unique()) <= {0, 1}),
        supplied_event_total="unavailable (not in manifest)",
        max_abs_resid_at_all_steps=round(stepres, 6), survival_checks=cc, risk_table_checks=rk,
        max_time=float(d.observed_time.max()))
json.dump(res, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
for g in "AB":
    r = res["groups"][g]; print(g, r["n"], r["events"], r["max_abs_resid_at_all_steps"], r["max_time"])
    print(" surv fails:", [c for c in r["survival_checks"] if c["status"] != "pass"])
    print(" risk:", [(c["t"], c["displayed"], c["reconstructed"]) for c in r["risk_table_checks"]])
print(sha)
