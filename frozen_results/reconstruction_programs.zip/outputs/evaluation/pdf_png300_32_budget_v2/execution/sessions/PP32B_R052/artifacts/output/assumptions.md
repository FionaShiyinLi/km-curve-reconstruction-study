# Reconstruction assumptions and methods

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 1148555630). The manifest gives no arm-specific event totals, so that check is marked unavailable. No other information was used.

**Measurement.** The figure is vector graphics, so I read coordinates straight from the PDF objects (pdfplumber) and did not process pixels.
- **Time calibration:** a linear fit to the 7 labelled x-ticks (0–36 months at x = 64.8–410.4 pt; 9.6 pt/month). Maximum residual is about 1e-14.
- **Survival calibration:** a linear fit to the 6 labelled y-ticks (S = 1.0 at y = 43.2 pt, S = 0 at y = 223.2 pt). Maximum residual is about 1e-16.
- **Transforms and origin:** no global rescaling or running-minimum correction was applied. Both curves start exactly at S = 1.0 at t = 0.
- **Arm identity:** taken from the legend order and stroke colours (blue = Group A, orange = Group B).
- **Curves:** each arm is a single step polyline. Vertical segments are event drops (A: 78 drops, B: 66).
- **Censor marks:** 4-pt vertical segments, 0.65 pt wide, centred on the curve (A: 22, B: 34). No tick positions are duplicated.

**Algorithm (own code, `code/reconstruct.py`).** A forward pass through the drops and ticks in time order:
1. Remove the censorings shown by ticks strictly before each drop. At tied times, events come first.
2. Compute the relative drop q = 1 − S_after/S_before.
3. Choose the integer d whose implied risk set d/q is closest to the bookkept n_risk, subject to d/q ≤ n_risk. Any shortfall would have been allocated to hidden censorings; none were needed.

**Why d = 1 is supported, not assumed:**
- At every drop, 1/q equals the risk set computed independently from 100 − (earlier events + earlier ticks), to within 0.0034. A drop of d ≥ 2 would need an implied risk set of at least 2·n_risk, which is infeasible.
- Events plus ticks add up to exactly 100 in each arm (A: 78 + 22; B: 66 + 34). So each tick is one censoring, with no hidden or stacked ticks and no survivors beyond the last tick. Each arm's curve ends at its final tick (A at 34.47 months, B at 35.35).

**Censoring times** are the tick x-positions. **Event times** are the drop x-positions. Times are rounded to 4 decimal places (the pixel-to-time resolution is far coarser).

**Risk table.** I read it from the PDF text and assigned each count to its time column by the label centre. It was used only for verification, not fitting. Counts of records with observed_time ≥ t match every displayed count, including 0 at 36 months:
- A: 100/74/47/30/21/7/0
- B: 100/68/55/42/32/14/0

**Verification (`code/checks.py` → `checks.json`).**
- The committed CSV is reloaded and its right-continuous KM curve recomputed.
- The KM curve matches the measured vector curve at 0, 1, 3, …, 33 months and at each arm's tail. The residual is 0 just after every drop (tolerance 0.002, which covers coordinate rounding only).
- Arm sizes, 0/1 event indicators and all risk-table counts pass.

**Limitations.**
- The records reproduce the displayed KM curves, censor marks and risk table exactly. Unobservable features cannot be recovered: exact times within the precision of the plot coordinates, and the order of events within a tied time.
- Time precision is limited by the PDF coordinates (about 1e-4 pt ≈ 1e-5 months) and by rounding to 4 decimal places.
- Correct reconstruction depends on the figure being a faithful rendering of the underlying data, one tick per censoring. The exact closure of the counts supports this but does not prove it.
- **Sensitivity analysis: not run.** The vector data and risk table leave no materially different event/censoring allocation feasible, so no alternative was fitted.
- The seed is set and recorded, but the algorithm is deterministic.
