# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.pdf`: a vector PDF. KM curves, censor ticks, axis ticks, legend and risk-table text were read directly from PDF objects with pdfplumber. No rasterization or OCR was needed.
- `../input/manifest.json`: arm sizes (A = 1000, B = 1000), unit (months) and seed 827134516. The seed is set in the code but not used, because the algorithm is deterministic. The manifest gives **no arm-specific event totals**, so that check is marked unavailable.

## Measurement
- **Calibration:** a linear fit to the labeled axis tick marks. Time: 0–36 months maps to x = 64.8–410.4 pt (9.6 pt per month). Survival: 0–1 maps to y = 223.2–43.2 pt. Fit residuals are 0, and no global rescaling was applied.
- **Arm identification:** legend colors. Blue is Group A and orange is Group B.
- **Origin:** both curves start exactly at S = 1 (y = 43.2), so no origin correction was needed.
- **Curve steps:** each curve is one step path. A vertical segment with increasing y is a drop, at time T(x) with S_before and S_after. A has 787 drops and B has 634.
- **Censor ticks:** 0.65-pt vertical strokes in the arm color. A has 212 and B has 366, all at distinct x positions, so no overlapping ticks were detected. Overplotting that is exactly coincident cannot be excluded from the vector data alone.
- **Saved observations:** `extracted_curve_*.csv`, `extracted_drops_*.csv`, `extracted_ticks_*.csv`.

## Algorithm (own code: `code/reconstruct.py`; run from `work/` with `python output/code/reconstruct.py [--input ../input --out output]`)
1. The algorithm works through each risk-table interval [t_k, t_{k+1}) starting from the displayed n_k.
2. For each candidate number of censorings c, the censorings are placed at the tick times in that interval (equal multiplicity per tick when c exceeds the number of ticks). A forward KM recursion is then run, with d_j = round(n_j (1 − S_after/S_before)). Censorings at a time strictly before a drop are removed from the risk set first.
3. The algorithm picks the c that reproduces n_{k+1}. **Result:** in every interval, for both arms, the chosen c equals the number of drawn ticks. Each tick therefore corresponds to one censored participant. This is an outcome of the fit, not an assumption imposed on it.
4. **Event multiplicities:** these were not assumed to be 1. The implied n_j·h_j was within 0.0006 of an integer at every drop, which strongly supports the adopted counts. Arm A has one drop with d = 2.
5. **Totals:** A has 788 events and 212 censored; B has 634 events and 366 censored.
6. **End of follow-up:** the displayed number at risk at 36 months is 0. All records have observed_time < 36; the last are censorings at the final ticks (A 35.997, B 35.978). No follow-up beyond the figure was invented.
7. **Tie convention:** at tied times, events precede censorings.

## Checks (`checks.json`, computed from the reloaded committed CSV)
- **Survival:** a right-continuous KM from the CSV was compared with the measured step curve at 16 times from 0.5 to 35.9 months, including the tail, and at every measured drop. The maximum absolute residual is about 3e-7, far below the stated tolerance of 0.005.
- **Risk table:** counts of observed_time ≥ t match exactly at 0, 6, 12, 18, 24, 30 and 36 months for both arms.
- **Records:** arm sizes and 0/1 event indicators pass.
- **Hash:** checks.json records the CSV SHA-256.

## Limitations
- **Censoring times:** these are exact only up to the drawing precision of the tick x positions (about 1e-5 pt). Times are rounded to 5 decimals in months.
- **Coincident marks:** a tick drawn at exactly the same x as another, or as an event drop, could hide extra censorings or events. The exact risk-table agreement argues against this, but the table only constrains totals within each 6-month interval, not their placement inside it.
- **Unavailable checks:** no supplied event totals.
- **Sensitivity analysis (one alternative, `sensitivity.csv`):** censorings were spread uniformly in time within each risk interval instead of at the tick times. This alternative ignores the tick evidence, so it tests only how much the within-interval placement of censorings matters. At the common horizon of 35.9 months:

| Arm | S(35.9), primary | S(35.9), alternative | RMST, primary | RMST, alternative |
|-----|------------------|----------------------|---------------|-------------------|
| A   | 0.1221           | 0.1259               | 15.087        | 15.116            |
| B   | 0.2842           | 0.2780               | 18.172        | 18.171            |

  Event counts are unchanged; details are in `sensitivity_comparison.json`. This single alternative is not a confidence interval or error bound.
- **Primary corrections:** no corrections were made to the primary records after the first complete file. One check-computation bug (a time-rounding mismatch) was fixed; the CSV was unchanged and its hash is identical.
