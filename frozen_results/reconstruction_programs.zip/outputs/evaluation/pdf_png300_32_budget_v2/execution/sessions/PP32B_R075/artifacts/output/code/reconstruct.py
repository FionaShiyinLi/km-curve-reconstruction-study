#!/usr/bin/env python3
"""Reconstruct approximate participant-level records from a vector KM figure.

Usage: python reconstruct.py [--input ../input] [--out output]
(paths relative to the working directory; defaults assume run from work/)

Own implementation (no KM-to-IPD package). Steps:
 1. Parse PDF vector paths: KM step curves (stroke width 1.0), censor ticks
    (short vertical strokes, width 0.65), axis ticks; legend colours -> arm.
 2. Calibrate time/survival from labelled axis tick marks.
 3. Per risk-table interval, choose the integer number of censorings so that the
    forward KM recursion (d_j = round(n_j * (1 - S_j/S_{j-1}))) reproduces the
    next displayed number at risk; censorings are placed at censor-tick times
    (equal multiplicity per tick; assumption).
 4. Write output/ipd.csv atomically, then checks.json, then one sensitivity run.
"""
import argparse, json, os, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

SEED = 827134516
np.random.seed(SEED)  # recorded; the algorithm itself is deterministic

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
args = ap.parse_args()
IN, OUT = args.input, args.out
os.makedirs(OUT, exist_ok=True)
manifest = json.load(open(os.path.join(IN, "manifest.json")))
N = manifest["groups"]

pg = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]
words = pg.extract_words()

# ---- axis calibration from labelled tick marks --------------------------------
blk = [l for l in pg.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted({round(l["pts"][0][0], 4) for l in blk
             if abs(l["pts"][0][0] - l["pts"][1][0]) < 1e-6 and l["pts"][1][1] > 223.3})
yt = sorted({round(l["pts"][0][1], 4) for l in blk
             if abs(l["pts"][0][1] - l["pts"][1][1]) < 1e-6 and l["pts"][0][0] < 64})
xlab = sorted(float(w["text"]) for w in words if w["top"] > 228 and w["top"] < 240)
ylab = sorted((float(w["text"]) for w in words if w["x1"] < 60 and w["x0"] > 40 and w["top"] < 230), reverse=True)
assert len(xt) == len(xlab) and len(yt) == len(ylab), (xt, xlab, yt, ylab)
ax_x = np.polyfit(xt, xlab, 1)          # time = a*x + b
ax_y = np.polyfit(yt, ylab, 1)          # surv = a*y + b  (y in top coords)
T = lambda x: np.polyval(ax_x, x)
S = lambda y: np.polyval(ax_y, y)
calib = dict(x_ticks_pt=xt, x_labels=xlab, y_ticks_pt=yt, y_labels=ylab,
             time_fit=list(ax_x), surv_fit=list(ax_y),
             x_resid_max=float(np.max(np.abs(T(np.array(xt)) - xlab))),
             y_resid_max=float(np.max(np.abs(S(np.array(yt)) - ylab))))

# ---- arm colours from legend --------------------------------------------------
legend = [l for l in pg.lines if l["linewidth"] == 1.0 and l["pts"][0][1] < 30]
col = {}
for g in ("A", "B"):
    wx = [w for w in words if w["text"] == g and w["top"] < 30][0]["x0"]
    best = min(legend, key=lambda l: abs(wx - l["pts"][1][0]) if l["pts"][1][0] < wx else 1e9)
    col[g] = tuple(best["stroking_color"])

# ---- risk table ---------------------------------------------------------------
risk = {}
for g in ("A", "B"):
    row = [w for w in words if w["text"] == g and w["x0"] < 50 and w["top"] > 280][0]
    cells = sorted((w for w in words if abs(w["top"] - row["top"]) < 1 and w["x0"] > 52),
                   key=lambda w: w["x0"])
    times = [float(T((w["x0"] + w["x1"]) / 2)) for w in cells]
    risk[g] = [(round(t), int(w["text"])) for t, w in zip(times, cells)]

# ---- curves and censor ticks --------------------------------------------------
def curve_steps(g):
    cv = [c for c in pg.curves if tuple(c["stroking_color"]) == col[g]][0]
    p = np.array(cv["pts"])
    t, s = T(p[:, 0]), S(p[:, 1])
    drops = []  # (time, S_before, S_after)
    for i in range(1, len(p)):
        if abs(p[i, 0] - p[i - 1, 0]) < 1e-9 and p[i, 1] > p[i - 1, 1] + 1e-9:
            drops.append([t[i], s[i - 1], s[i]])
    d = pd.DataFrame(drops, columns=["time", "s_before", "s_after"])
    # merge drops at identical x (should not occur, guard anyway)
    d = d.groupby("time", as_index=False).agg(s_before=("s_before", "max"), s_after=("s_after", "min"))
    return pd.DataFrame({"x_pt": p[:, 0], "y_pt": p[:, 1], "time": t, "surv": s}), d

def ticks(g):
    tk = [l for l in pg.lines if l["linewidth"] == 0.65 and tuple(l["stroking_color"]) == col[g]]
    out = []
    for l in tk:
        (x0, y0), (x1, y1) = l["pts"]
        out.append((T(x0), S((y0 + y1) / 2)))
    return pd.DataFrame(sorted(out), columns=["time", "surv_at_tick"])

# ---- reconstruction -----------------------------------------------------------
def simulate(n0, drops, cens_times, t_lo, t_hi):
    """Forward KM recursion within [t_lo, t_hi). Returns events list, n_end, residual info."""
    n = n0; ev = []; ci = 0; cens_times = sorted(cens_times); fracs = []
    for _, r in drops.iterrows():
        while ci < len(cens_times) and cens_times[ci] < r.time:   # censor strictly before
            n -= 1; ci += 1
        h = 1 - r.s_after / r.s_before
        draw = n * h
        dj = int(round(draw)); dj = max(dj, 1) if draw > 0.5 else max(dj, 0)
        fracs.append(draw - round(draw))
        dj = min(dj, n)
        ev.append((r.time, dj, n, draw)); n -= dj
    n -= len(cens_times) - ci
    return ev, n, fracs

def place_censor(c, tk_times, t_lo, t_hi, mode):
    """Place c censoring times in [t_lo, t_hi)."""
    if c <= 0:
        return []
    if mode == "ticks" and len(tk_times) > 0:
        m = len(tk_times)
        if c >= m:  # equal multiplicity; remainder to evenly spaced ticks
            base, rem = divmod(c, m)
            extra = set(np.round(np.linspace(0, m - 1, rem)).astype(int)) if rem else set()
            k = 0; out = []
            for i, tt in enumerate(tk_times):
                out += [tt] * (base + (1 if i in extra else 0))
            # linspace can give duplicate indices for rem close to m; top up
            while len(out) < c:
                out.append(tk_times[k % m]); k += 1
            return sorted(out)
        idx = np.round(np.linspace(0, m - 1, c)).astype(int)
        return sorted(tk_times[i] for i in idx)
    # uniform in time over the interval (sensitivity / no ticks)
    return list(t_lo + (np.arange(c) + 0.5) / c * (t_hi - t_lo))

def reconstruct(g, mode="ticks"):
    _, drops = curve_steps(g)
    tk = ticks(g)
    rt = risk[g]
    assert rt[0][1] == N[g], "risk table start differs from manifest"
    recs, log = [], []
    n = N[g]
    for k in range(len(rt) - 1):
        t_lo, t_hi, n_next = rt[k][0], rt[k + 1][0], rt[k + 1][1]
        dk = drops[(drops.time >= t_lo) & (drops.time < t_hi)]
        tt = [float(x) for x in tk.time[(tk.time >= t_lo) & (tk.time < t_hi)]]
        best = None
        for c in range(0, n + 1):
            ct = place_censor(c, tt, t_lo, t_hi, mode)
            ev, n_end, fr = simulate(n, dk, ct, t_lo, t_hi)
            err = abs(n_end - n_next)
            if best is None or err < best[0]:
                best = (err, c, ct, ev, n_end, fr)
            if n_end < n_next:
                break
        err, c, ct, ev, n_end, fr = best
        # any residual (count mismatch) handled as censoring at interval end - 1e-6 (flagged)
        for (t, dj, _, _) in ev:
            recs += [(g, t, 1)] * dj
        recs += [(g, t, 0) for t in ct]
        log.append(dict(interval=[t_lo, t_hi], n_start=n, n_next_table=n_next, n_end_recon=n_end,
                        events=int(sum(e[1] for e in ev)), censored=c, ticks=len(tt), drops=len(dk),
                        max_abs_rounding_frac=float(np.max(np.abs(fr))) if fr else None))
        n = n_end
    # participants still at risk after the last risk-table time (none here, last n=0)
    if n > 0:
        last = drops.time.max() if len(drops) else rt[-1][0]
        recs += [(g, float(tk.time.max()), 0)] * n
        log.append(dict(note=f"{n} residual participants censored at last tick"))
    return pd.DataFrame(recs, columns=["group", "observed_time", "event"]), log

def km(df):
    """Right-continuous KM; returns event times and survival after each."""
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        nr = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); s *= 1 - d / nr; out.append((u, s))
    return np.array(out)

def km_at(kmtab, x):
    idx = np.searchsorted(kmtab[:, 0], x, side="right") - 1
    return np.where(idx >= 0, kmtab[np.clip(idx, 0, None), 1], 1.0)

def measured_at(g, x):
    _, d = curve_steps(g)
    idx = np.searchsorted(d.time.values, x, side="right") - 1
    return np.where(idx >= 0, d.s_after.values[np.clip(idx, 0, None)], 1.0)

def atomic_csv(df, path):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", suffix=".tmp")
    os.close(fd); df.to_csv(tmp, index=False); os.replace(tmp, path)

def rmst(kmtab, tau):
    xs = np.concatenate([[0], kmtab[kmtab[:, 0] < tau, 0], [tau]])
    ss = np.concatenate([[1], kmtab[kmtab[:, 0] < tau, 1]])
    return float(np.sum(np.diff(xs) * ss))

if __name__ == "__main__":
    # save extracted observations
    for g in ("A", "B"):
        pts, d = curve_steps(g)
        pts.to_csv(os.path.join(OUT, f"extracted_curve_{g}.csv"), index=False)
        d.to_csv(os.path.join(OUT, f"extracted_drops_{g}.csv"), index=False)
        ticks(g).to_csv(os.path.join(OUT, f"extracted_ticks_{g}.csv"), index=False)
    res, logs = {}, {}
    for g in ("A", "B"):
        res[g], logs[g] = reconstruct(g, "ticks")
        assert len(res[g]) == N[g], (g, len(res[g]))
    ipd = pd.concat([res["A"], res["B"]], ignore_index=True)
    ipd["observed_time"] = ipd.observed_time.round(5)
    ipd["event"] = ipd.event.astype(int)
    atomic_csv(ipd, os.path.join(OUT, "ipd.csv"))

    # ---- checks from the committed file --------------------------------------
    f = pd.read_csv(os.path.join(OUT, "ipd.csv"))
    sha = hashlib.sha256(open(os.path.join(OUT, "ipd.csv"), "rb").read()).hexdigest()
    TOL = 0.005
    chk = dict(csv_sha256=sha, calibration=calib, legend_colours={g: list(c) for g, c in col.items()},
               survival_tolerance=TOL,
               tolerance_justification="Vector coordinates are exact to ~1e-5 in S; residual reflects integer "
                                       "event rounding and censor-placement assumptions (~1/n_risk per step).",
               arms={})
    grid = [0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.9]
    for g in ("A", "B"):
        fg = f[f.group == g]
        kt = km(fg)
        meas = measured_at(g, np.array(grid)); rec = km_at(kt, np.array(grid))
        _, d = curve_steps(g)
        # also compare at every measured drop (max residual)
        allres = km_at(kt, np.round(d.time.values, 5)) - d.s_after.values  # CSV times rounded to 5 dp
        rtc = []
        for t, nr in risk[g]:
            cnt = int((fg.observed_time >= t).sum())
            rtc.append(dict(time=t, table=nr, reconstructed=cnt, residual=cnt - nr,
                            status="pass" if cnt == nr else "fail"))
        chk["arms"][g] = dict(
            n_records=int(len(fg)), n_manifest=N[g], n_status="pass" if len(fg) == N[g] else "fail",
            event_indicator_integer_01=bool(fg.event.isin([0, 1]).all()),
            events_total=int(fg.event.sum()), censored_total=int((fg.event == 0).sum()),
            supplied_event_total="unavailable (not in manifest)",
            censor_ticks_drawn=int(len(ticks(g))),
            survival_checks=[dict(time=t, measured=round(float(m), 5), reconstructed=round(float(r), 5),
                                  residual=round(float(r - m), 5), status="pass" if abs(r - m) <= TOL else "fail")
                             for t, m, r in zip(grid, meas, rec)],
            max_abs_residual_all_drops=round(float(np.max(np.abs(allres))), 5),
            tail=dict(last_measured_drop_time=round(float(d.time.max()), 4),
                      measured_final_S=round(float(d.s_after.iloc[-1]), 5),
                      reconstructed_final_S=round(float(kt[-1, 1]), 5),
                      max_observed_time=float(fg.observed_time.max())),
            risk_table=rtc, interval_log=logs[g])
    json.dump(chk, open(os.path.join(OUT, "checks.json"), "w"), indent=1, default=float)

    # ---- one sensitivity allocation: censoring uniform in time within intervals
    sres = {g: reconstruct(g, "uniform")[0] for g in ("A", "B")}
    sens = pd.concat([sres["A"], sres["B"]], ignore_index=True)
    sens["observed_time"] = sens.observed_time.round(5)
    atomic_csv(sens, os.path.join(OUT, "sensitivity.csv"))
    tau = 35.9
    comp = {}
    for g in ("A", "B"):
        kp, ks = km(f[f.group == g]), km(sens[sens.group == g])
        comp[g] = dict(horizon=tau, S_primary={t: round(float(km_at(kp, t)), 4) for t in (12, 24, 30, tau)},
                       S_sensitivity={t: round(float(km_at(ks, t)), 4) for t in (12, 24, 30, tau)},
                       RMST_primary=round(rmst(kp, tau), 3), RMST_sensitivity=round(rmst(ks, tau), 3),
                       events_primary=int(f[f.group == g].event.sum()),
                       events_sensitivity=int(sens[sens.group == g].event.sum()))
    json.dump(comp, open(os.path.join(OUT, "sensitivity_comparison.json"), "w"), indent=1)
    print(json.dumps({g: {k: v for k, v in chk["arms"][g].items() if k in
                          ("events_total", "censored_total", "censor_ticks_drawn", "max_abs_residual_all_drops",
                           "tail")} for g in "AB"}, indent=1))
    print(json.dumps({g: [(r["time"], r["table"], r["reconstructed"]) for r in chk["arms"][g]["risk_table"]]
                      for g in "AB"}))
    print(json.dumps({g: [(l.get("censored"), l.get("ticks"), l.get("max_abs_rounding_frac")) for l in logs[g]]
                      for g in "AB"}))
    print(json.dumps(comp, indent=1)); print(sha)
