# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (A = 100, B = 100, months, seed 657880310). No other information was used. The manifest has no arm-specific event totals, so that check is marked unavailable.

**Measurement.** The figure is a vector PDF, so I read coordinates directly from its drawing objects with pdfplumber; I did not threshold pixels.
- Time was calibrated by a linear fit of the seven labelled x-axis ticks (0–36 months), and survival by a fit of the six labelled y-axis ticks (0.0–1.0). Maximum calibration residuals are about 1e-14, so no global correction was applied.
- Each arm is one stroked step path, identified by its legend color. Both paths start at exactly (t = 0, S = 1.000), so no correction was made at the origin. Early drops are kept as drawn, for example A at 0.20 and 0.39 months.
- Censor marks are 4-pt vertical tick segments in the arm color: 29 in A and 37 in B. Each tick is a separate PDF object, so tick multiplicity is counted directly and does not depend on visual overlap. Near-coincident ticks (for example, B at 24.9 months) are kept as separate records.
- All extracted drops, ticks, calibration and risk-table readings are in `extracted_observations.json`.

**Algorithm** (`code/reconstruct.py`, own implementation):
1. Drops and ticks are processed in time order. The number at risk equals N minus prior events minus censorings strictly before the drop. Censorings at a tied time count as at risk.
2. At each drop, d = round(n·(1 − S_after/Ŝ_current)), where Ŝ_current is the reconstructed KM value. Matching the absolute level in this way prevents drift. d is not fixed at 1 in advance. Every drop gave a raw d within 0.01 of an integer, and that integer was 1 in all cases.
3. Censorings in each risk-table interval were compared with the displayed counts. The code can add undrawn censorings, spread uniformly or at the interval end, if the table requires them. Here none were needed: 71 events + 29 ticks = 100 in A, and 63 + 37 = 100 in B, and all 7 risk-table counts per arm match exactly (counting observed_time ≥ t). No participants were left over to place at the curve end.
4. The program uses no randomness. The seed is still set with `np.random.seed(657880310)` and recorded.

**Tail and follow-up.** The last record in A is a censoring at 35.58 months, where the curve ends at S = 0.175. The last record in B is a censoring at 35.93 months, where the curve ends at S = 0.356. Both are before 36 months, which agrees with the displayed risk count of 0 at 36. No follow-up beyond the drawn marks was invented. Censor times are the tick positions, not a modeled censoring distribution.

**Verification** (`checks.json`). I reloaded the saved CSV, recomputed the right-continuous KM estimate, and compared it with the drawn step function at 18 times from 0 to 35.5 months, including the tail. All residuals are below 1e-4 in absolute value. The tolerance is half of one event step at that time, with a floor of 0.002. The 36-month check is unavailable because it lies beyond the drawn curves. Arm sizes, 0/1 event coding and all risk-table counts pass. The file includes the CSV's SHA-256 hash.

**Limitations.**
- Exact event and censoring times are recoverable only to the precision of the vector coordinates. The CSV stores them to 4 decimals.
- If ticks were drawn exactly on top of each other as a single object, or if the plotting software thinned them, some censorings would not appear. The exact closure with N and the risk table argues against this, but it cannot rule it out.
- Censorings could coincide with event times. That cannot be seen in the figure.
- Two pairs of arm-A drops are less than 0.001 months apart. They are recorded as separate times; merging them would give the same KM curve.

**Sensitivity analysis:** not run. The drawn ticks, the drop sizes, N and the risk table close exactly with no free allocation, so I found no materially different plausible censoring/event allocation that fits the supplied inputs. Accordingly, `sensitivity.csv` was not produced. This does not bound reconstruction error.

**Reproduce:** `python output/code/reconstruct.py --input ../input --out output` (run from the work directory).
