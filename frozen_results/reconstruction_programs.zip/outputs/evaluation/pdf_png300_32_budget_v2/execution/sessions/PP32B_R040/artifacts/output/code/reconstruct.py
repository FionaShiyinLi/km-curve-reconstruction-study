#!/usr/bin/env python3
"""KM figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input ../input] [--out output] [--hidden uniform|end]
Reads the vector PDF (figure.pdf) and manifest.json. No randomness is used; the
manifest seed is recorded and numpy is seeded with it for reproducibility.
"""
import argparse, json, os, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(here, ".."))
ap.add_argument("--hidden", default="uniform", choices=["uniform", "end"],
                help="placement of censorings implied by risk table but not drawn")
ap.add_argument("--csvname", default="ipd.csv")
ap.add_argument("--nochecks", action="store_true")
args = ap.parse_args()
man = json.load(open(os.path.join(args.input, "manifest.json")))
SEED = man["code_seed"]; np.random.seed(SEED)
N = man["groups"]
COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}

pg = pdfplumber.open(os.path.join(args.input, "figure.pdf")).pages[0]
words = pg.extract_words()

# ---- axis calibration from labelled tick marks (black axis ticks + labels)
blk = [l for l in pg.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted({round(l["x0"], 3) for l in blk if abs(l["x0"] - l["x1"]) < 1e-6 and l["bottom"] - l["top"] < 5})
yt = sorted({round(l["top"], 3) for l in blk if abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 5})
xlab = sorted([w for w in words if 225 < w["top"] < 240], key=lambda w: w["x0"])
ylab = sorted([w for w in words if w["x0"] < 60 and w["top"] < 230 and "." in w["text"]], key=lambda w: w["top"])
xv = [float(w["text"]) for w in xlab]; yv = [float(w["text"]) for w in ylab]
assert len(xt) == len(xv) and len(yt) == len(yv)
xa, xb = np.polyfit(xt, xv, 1); ya, yb = np.polyfit(yt, yv, 1)
calib = dict(x_ticks_pt=xt, x_labels=xv, y_ticks_pt=yt, y_labels=yv,
             x_resid_max=float(np.max(np.abs(np.polyval([xa, xb], xt) - xv))),
             y_resid_max=float(np.max(np.abs(np.polyval([ya, yb], yt) - yv))))
T = lambda x: xa * x + xb
S = lambda y: ya * y + yb

# ---- risk table
risk_times = xv
risk = {}
for g in "AB":
    row = [w for w in words if w["text"] == g and w["x0"] > 40 and w["top"] > 280][0]
    vals = sorted([w for w in words if abs(w["top"] - row["top"]) < 1 and w["x0"] > 55], key=lambda w: w["x0"])
    risk[g] = [int(w["text"]) for w in vals]

# ---- curves (step path) and censor ticks per arm
def close(c1, c2): return all(abs(a - b) < 1e-4 for a, b in zip(c1, c2))
extracted = {}
for g in "AB":
    cur = [c for c in pg.curves if close(c["stroking_color"], COL[g])][0]
    pts = [(T(x), S(y)) for x, y in cur["pts"]]
    drops = []  # (time, S_before, S_after)
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-6 and s1 < s0 - 1e-6:
            drops.append((t1, s0, s1))
    ticks = sorted(T(l["x0"]) for l in pg.lines if close(l["stroking_color"], COL[g])
                   and abs(l["linewidth"] - 0.65) < 0.01 and abs(l["x0"] - l["x1"]) < 1e-6)
    extracted[g] = dict(start=pts[0], end=pts[-1], drops=drops, ticks=ticks, path=pts)

def curve_S(g, t):
    """right-continuous step value of the drawn curve at t"""
    s = extracted[g]["start"][1]
    for td, sb, sa in extracted[g]["drops"]:
        if td <= t + 1e-9: s = sa
    return s

# ---- reconstruction
def reconstruct(g, hidden_mode):
    e = extracted[g]; n0 = N[g]
    ticks = list(e["ticks"]); rt = risk[g]
    # Pass 1: events from drops with at-risk from drawn ticks only, per interval;
    # add undrawn censorings where the risk table requires them.
    extra = []
    for it in range(20):
        cens = sorted(ticks + extra)
        recs = []; s_rec = 1.0; n = n0
        ev_times = []
        ci = 0
        for td, sb, sa in e["drops"]:
            while ci < len(cens) and cens[ci] < td - 1e-9:
                n -= 1; ci += 1
            # choose d to match the absolute level after the drop (avoids drift)
            d = int(round(n * (1 - sa / s_rec))) if s_rec > 0 else 0
            d = max(d, 1); d = min(d, n)
            s_rec *= 1 - d / n; n -= d
            ev_times += [td] * d
        # risk-table consistency: required censorings per interval
        new_extra = []
        for k in range(len(rt) - 1):
            a, b = risk_times[k], risk_times[k + 1]
            n_b_rec = sum(1 for t in ev_times if t >= b) + sum(1 for t in cens if t >= b)
            n_b_rec -= sum(1 for t in extra if t >= b)  # exclude previous extras
            # extras already placed in this interval or later are recomputed from scratch
            need = n_b_rec - rt[k + 1] - sum(1 for t in new_extra if t >= b)
            # need >0: more records survive to b than table allows -> add censorings in [a,b)
            if need > 0:
                if hidden_mode == "uniform":
                    pos = [a + (b - a) * (j + 0.5) / need for j in range(need)]
                else:
                    pos = [b - 1e-3 * (b - a) * (j + 1) for j in range(need)]
                new_extra += pos
        new_extra = sorted(new_extra)
        if len(new_extra) == len(extra) and np.allclose(new_extra, extra):
            break
        extra = new_extra
    cens = sorted(ticks + extra)
    # remaining participants after last recorded time: censor at last drawn tick/curve end
    n_left = n0 - len(ev_times) - len(cens)
    tail = []
    if n_left > 0:
        tail = [e["end"][0]] * n_left
    elif n_left < 0:
        raise RuntimeError(f"{g}: {-n_left} too many records")
    df = pd.DataFrame({"group": g,
                       "observed_time": ev_times + cens + tail,
                       "event": [1] * len(ev_times) + [0] * (len(cens) + len(tail))})
    info = dict(n_events=len(ev_times), n_drawn_ticks=len(ticks), n_hidden_censor=len(extra),
                hidden_censor_times=[round(x, 3) for x in extra], n_tail_censor=len(tail),
                iterations=it + 1)
    return df, info

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); s *= 1 - d / n; out.append((u, s))
    return out

def km_at(steps, t):
    s = 1.0
    for u, v in steps:
        if u <= t + 1e-9: s = v
    return s

def atomic_csv(df, path):
    d = os.path.dirname(path); fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    os.close(fd); df.to_csv(tmp, index=False, float_format="%.4f"); os.replace(tmp, path)

os.makedirs(args.out, exist_ok=True)
parts, infos = [], {}
for g in "AB":
    df, info = reconstruct(g, args.hidden)
    assert len(df) == N[g]
    parts.append(df); infos[g] = info
ipd = pd.concat(parts, ignore_index=True)
csv_path = os.path.join(args.out, args.csvname)
atomic_csv(ipd, csv_path)

# ---- save extracted observations
obs = {"calibration": calib, "risk_table": {"times": risk_times, **risk}}
for g in "AB":
    e = extracted[g]
    obs[g] = dict(start=e["start"], end=e["end"],
                  drops=[dict(t=round(a, 4), S_before=round(b, 5), S_after=round(c, 5)) for a, b, c in e["drops"]],
                  censor_ticks=[round(x, 4) for x in e["ticks"]])
if args.csvname == "ipd.csv":
    json.dump(obs, open(os.path.join(args.out, "extracted_observations.json"), "w"), indent=1)
print(json.dumps(infos, indent=1))

if args.nochecks:
    raise SystemExit
# ---- checks from reloaded CSV
re = pd.read_csv(csv_path)
sha = hashlib.sha256(open(csv_path, "rb").read()).hexdigest()
checks = {"csv": args.csvname, "sha256": sha, "seed": SEED, "hidden_censor_mode": args.hidden,
          "arm_sizes": {}, "event_indicator_integer_01": bool(re.event.isin([0, 1]).all()),
          "supplied_event_totals": "unavailable (not in manifest)", "km_vs_curve": {}, "risk_table": {}}
check_t = sorted(set([0, 0.5, 1, 2, 3] + list(np.arange(6, 36.01, 3)) + [33, 34, 35, 35.5]))
for g in "AB":
    r = re[re.group == g]
    checks["arm_sizes"][g] = {"expected": N[g], "found": int(len(r)), "status": "pass" if len(r) == N[g] else "fail"}
    steps = km(r); rows = []
    for t in check_t:
        if t > extracted[g]["end"][0] + 1e-9:
            rows.append(dict(t=float(t), status="unavailable (beyond drawn curve)")); continue
        m = curve_S(g, t); k = km_at(steps, t)
        nr = int((r.observed_time >= t).sum())
        tol = max(0.002, 0.5 * m / max(nr, 1))  # half of one event step at that time
        rows.append(dict(t=float(t), measured=round(m, 5), reconstructed=round(k, 5),
                         residual=round(k - m, 5), tol=round(tol, 5), status="pass" if abs(k - m) <= tol else "fail"))
    checks["km_vs_curve"][g] = rows
    rrows = []
    for t, v in zip(risk_times, risk[g]):
        c = int((r.observed_time >= t - 1e-9).sum())
        rrows.append(dict(t=t, table=v, reconstructed=c, residual=c - v, status="pass" if c == v else "fail"))
    checks["risk_table"][g] = rrows
    checks[f"summary_{g}"] = dict(events=int(r.event.sum()), censored=int((r.event == 0).sum()),
                                  max_time=float(r.observed_time.max()), **infos[g])
name = "checks.json" if args.csvname == "ipd.csv" else "checks_" + args.csvname.replace(".csv", ".json")
json.dump(checks, open(os.path.join(args.out, name), "w"), indent=1)
for g in "AB":
    print(g, [ (x["t"], x["residual"], x["status"]) for x in checks["risk_table"][g]])
    print(g, [ (x["t"], x.get("residual"), x["status"]) for x in checks["km_vs_curve"][g]])
