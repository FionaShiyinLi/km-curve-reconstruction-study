#!/usr/bin/env python3
"""Reload committed output/ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table."""
import json, hashlib, os, sys
import numpy as np, pandas as pd

out = sys.argv[1] if len(sys.argv) > 1 else "output"
csvp = os.path.join(out, "ipd.csv")
sha = hashlib.sha256(open(csvp, "rb").read()).hexdigest()
df = pd.read_csv(csvp)
ex = json.load(open(os.path.join(out, "extracted.json")))
TOL = 1e-3  # vector coordinates: exact up to PDF float rounding (~1e-5 in S)

def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for tt, v in steps:
        if tt <= t: s = v
    return s

res = dict(csv_sha256=sha, tolerance_S=TOL, arms={})
for g in "AB":
    d = df[df.group == g]; st = km(d); a = ex["arms"][g]; r = {}
    r["n"] = int(len(d)); r["n_expected"] = 100; r["event_values_ok"] = bool(set(d.event) <= {0, 1})
    r["events"] = int(d.event.sum()); r["supplied_event_total"] = "unavailable (not in manifest)"
    # curve check: at each step time (post-drop), and midway between steps, plus tail
    steps = a["steps"]; comps = []
    probe = [(s["t"] + 1e-5, s["S_after"]) for s in steps]  # just after drop (CSV times rounded to 5 dp)
    probe += [(s["t"] - 1e-5, s["S_before"]) for s in steps]  # just before drop
    probe += [((s0["t"] + s1["t"]) / 2, s0["S_after"]) for s0, s1 in zip(steps[:-1], steps[1:])]
    probe += [(steps[0]["t"] - 1e-3 if steps[0]["t"] > 1e-3 else 0.0, 1.0), (a["curve_end"], steps[-1]["S_after"])]
    for t, m in sorted(probe):
        k = S_at(st, t); comps.append([round(t, 5), round(m, 6), round(k, 6), round(k - m, 7)])
    mx = max(abs(c[3]) for c in comps)
    r["curve"] = dict(columns=["t", "measured", "km", "resid"], max_abs_resid=mx,
                      status="pass" if mx < TOL else "fail", n_points=len(comps),
                      sample=comps[:5] + comps[-5:])
    r["tail"] = dict(curve_end=a["curve_end"], max_observed_time=float(d.observed_time.max()),
                     S_end_measured=steps[-1]["S_after"], S_end_km=S_at(st, a["curve_end"]))
    rt = []
    for t, v in ex["risk_table"][g].items():
        c = int((d.observed_time >= float(t)).sum())
        rt.append(dict(t=float(t), displayed=v, reconstructed=c, resid=c - v, status="pass" if c == v else "fail"))
    r["risk_table"] = rt
    # censor ticks sitting exactly on a drop time (tie convention check)
    stt = {round(s["t"], 6) for s in steps}
    r["ticks_at_event_times"] = sum(round(x["t"], 6) in stt for x in a["ticks"])
    res["arms"][g] = r
json.dump(res, open(os.path.join(out, "checks.json"), "w"), indent=1)
for g in "AB":
    r = res["arms"][g]
    print(g, r["n"], r["events"], r["curve"]["status"], r["curve"]["max_abs_resid"], [(x["t"], x["displayed"], x["reconstructed"]) for x in r["risk_table"]], r["tail"], r["ticks_at_event_times"])
print(sha)
