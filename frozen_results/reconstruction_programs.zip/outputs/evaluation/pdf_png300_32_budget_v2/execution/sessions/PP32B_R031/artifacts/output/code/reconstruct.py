#!/usr/bin/env python3
"""Reconstruct IPD from the vector KM figure (no KM-to-IPD package used).

Usage: python3 reconstruct.py [--input ../input] [--out output]
Steps:
 1. Parse PDF vector objects (pdfplumber): step path per arm, censor tick lines.
 2. Calibrate axes from labelled tick positions (text labels + tick marks).
 3. Sequential KM inversion: at each vertical drop, d = n_risk * (1 - S_after/S_before),
    n_risk = N - prior events - prior censorings (ticks), censorings at a drop time
    placed after events (tick drawn at post-drop level).
 4. Censorings not visible as ticks (if needed to reconcile) allocated per risk table.
No randomness is used; the manifest seed is recorded only.
"""
import argparse, json, os, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
a = ap.parse_args()
man = json.load(open(os.path.join(a.input, "manifest.json")))
SEED = man["code_seed"]; np.random.seed(SEED)
os.makedirs(a.out, exist_ok=True)

pg = pdfplumber.open(os.path.join(a.input, "figure.pdf")).pages[0]
words = pg.extract_words()
# --- axis calibration from labelled anchors ---
xt = sorted({round(l["x0"], 3) for l in pg.lines if l["stroking_color"] == (0.0, 0.0, 0.0)
             and abs(l["x0"] - l["x1"]) < 1e-6 and l["bottom"] - l["top"] < 4})
yt = sorted({round(l["top"], 3) for l in pg.lines if l["stroking_color"] == (0.0, 0.0, 0.0)
             and abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 4})
xlab = [float(w["text"]) for w in words if w["top"] > 228 and w["top"] < 240 and w["text"].isdigit()]
ylab = sorted([float(w["text"]) for w in words if w["x1"] < 60 and w["text"].replace(".", "").isdigit()], reverse=True)
assert len(xt) == len(xlab) and len(yt) == len(ylab)
px = np.polyfit(xt, xlab, 1); py = np.polyfit(yt, ylab, 1)
X = lambda x: float(np.polyval(px, x)); Y = lambda y: float(np.polyval(py, y))
calib = dict(x_ticks=xt, x_labels=xlab, y_ticks=yt, y_labels=ylab,
             x_fit=list(px), y_fit=list(py),
             x_resid=float(np.max(np.abs(np.polyval(px, xt) - xlab))),
             y_resid=float(np.max(np.abs(np.polyval(py, yt) - ylab))))

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}
# risk table
risk = {}
for g in "AB":
    row = [w for w in words if w["text"] == g and w["x0"] < 55 and w["top"] > 280]
    top = row[0]["top"]
    vals = sorted([(w["x0"], int(w["text"])) for w in words if abs(w["top"] - top) < 1 and w["x0"] > 55])
    risk[g] = dict(zip(xlab, [v for _, v in vals]))

obs, recs, summ = {}, [], {}
for g in "AB":
    N = man["groups"][g]
    cv = [c for c in pg.curves if c["stroking_color"] == COL[g] and len(c["pts"]) > 10][0]
    pts = [(X(x), Y(y)) for x, y in cv["pts"]]
    drops = []  # (t, S_before, S_after)
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x0 - x1) < 1e-9 and y1 < y0 - 1e-9:
            drops.append((x0, y0, y1))
    t_end = pts[-1][0]
    ticks = sorted((X(l["x0"]), Y((l["top"] + l["bottom"]) / 2)) for l in pg.lines
                   if l["stroking_color"] == COL[g] and abs(l["x0"] - l["x1"]) < 1e-6 and abs(l["bottom"] - l["top"] - 4) < 0.01)
    obs[g] = dict(steps=[dict(t=t, S_before=s0, S_after=s1) for t, s0, s1 in drops],
                  curve_end=t_end, ticks=[dict(t=t, S=s) for t, s in ticks])
    # sequential inversion
    n = N; ev = []; cen = []; ti = 0; resid = []
    for t, s0, s1 in drops:
        while ti < len(ticks) and ticks[ti][0] < t - 1e-9:
            cen.append(ticks[ti][0]); n -= 1; ti += 1
        dr = n * (1 - s1 / s0); d = int(round(dr)); resid.append(dr - d)
        ev += [t] * d; n -= d
    rest = ticks[ti:]
    cen += [t for t, _ in rest]; n -= len(rest)
    hidden = n  # participants not accounted for by events+visible ticks
    # hidden censorings (if any) placed at curve end (last follow-up shown); flagged
    cen += [t_end] * max(hidden, 0)
    summ[g] = dict(N=N, events=len(ev), visible_ticks=len(ticks), hidden_censor_at_end=hidden,
                   max_abs_d_residual=float(np.max(np.abs(resid))), n_drops=len(drops))
    recs += [(g, t, 1) for t in ev] + [(g, t, 0) for t in cen]

df = pd.DataFrame(recs, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0).round(5)
df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
for g in "AB":
    assert (df.group == g).sum() == man["groups"][g], (g, (df.group == g).sum())
fd, tmp = tempfile.mkstemp(dir=a.out, suffix=".tmp")
with os.fdopen(fd, "w") as f: df.to_csv(f, index=False)
os.replace(tmp, os.path.join(a.out, "ipd.csv"))
json.dump(dict(calibration=calib, risk_table=risk, arms=obs, summary=summ, seed=SEED),
          open(os.path.join(a.out, "extracted.json"), "w"), indent=1)
print(json.dumps(summ, indent=1)); print(calib)
