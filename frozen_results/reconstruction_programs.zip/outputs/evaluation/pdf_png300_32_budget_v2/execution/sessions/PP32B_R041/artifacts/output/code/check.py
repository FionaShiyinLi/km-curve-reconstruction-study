"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve & risk table."""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
csv = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); obs = json.load(open(os.path.join(OUT, 'extracted_observations.json')))
meta = json.load(open(os.path.join(OUT, 'recon_meta.json')))
TOL_S = 0.0015  # vector coords exact to ~1e-5; tolerance covers 4-dp time rounding only
def km(d):
    ts = np.sort(d.loc[d.event == 1, 'observed_time'].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for tt, ss in steps:
        if tt <= t: s = ss
    return s
def meas_at(pts, t):  # measured step polyline: last y at x<=t (post-drop value at drop x)
    s = 1.0
    for x, y in pts:
        if x <= t + 1e-9: s = y
    return s
res = {'csv_sha256': sha, 'survival_tolerance': TOL_S, 'arms': {}}
for g in 'AB':
    d = df[df.group == g]; st = km(d); pts = obs[g]['steps']
    tt = sorted(set([0, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35,
                     round(obs[g]['t_end'] - 0.01, 3), round(obs[g]['t_end'], 3)]))
    cmp = []
    for t in tt:
        if t > obs[g]['t_end'] + 1e-9: continue
        m, r = meas_at(pts, t), S_at(st, t)
        cmp.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), resid=round(r - m, 5),
                        status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # every drop location
    drop_fail = sum(abs(S_at(st, round(e['t'], 4) + 1e-4) - e['S_after']) > TOL_S for e in obs[g]['drops'])
    rk = []
    for t, n in zip([0, 6, 12, 18, 24, 30, 36], meta[g]['risk_row']):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=c, resid=c - n, status='pass' if c == n else 'fail'))
    res['arms'][g] = dict(n=int(len(d)), n_expected=100, events=int(d.event.sum()),
                          event_indicator_integer=bool(d.event.isin([0, 1]).all()),
                          supplied_event_total='unavailable (not in manifest)',
                          censored=int((d.event == 0).sum()), censor_ticks_visible=len(obs[g]['censor_ticks']),
                          max_time=float(d.observed_time.max()), curve_end_time=obs[g]['t_end'],
                          curve_end_S=obs[g]['S_end'], km_final=st[-1][1],
                          survival_checks=cmp, drops_checked=len(obs[g]['drops']), drops_failed=int(drop_fail),
                          risk_table=rk)
fd, tmp = tempfile.mkstemp(dir=OUT, suffix='.tmp'); os.close(fd)
json.dump(res, open(tmp, 'w'), indent=1); os.replace(tmp, os.path.join(OUT, 'checks.json'))
for g in 'AB':
    a = res['arms'][g]
    print(g, a['n'], a['events'], a['censored'], a['censor_ticks_visible'], 'max', a['max_time'],
          'Send', round(a['curve_end_S'], 4), 'KMend', round(a['km_final'], 4), 'dropfail', a['drops_failed'],
          'survfail', sum(c['status'] != 'pass' for c in a['survival_checks']),
          'risk', [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table']])
print(sha)
