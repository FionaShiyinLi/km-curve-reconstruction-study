"""KM -> IPD reconstruction from vector PDF objects (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]   (defaults ../input, output)
"""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

INP = sys.argv[1] if len(sys.argv) > 1 else '../input'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
SEED = 391922031
rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic
man = json.load(open(os.path.join(INP, 'manifest.json')))
pg = pdfplumber.open(os.path.join(INP, 'figure.pdf')).pages[0]
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}

# ---- axis calibration from labelled tick marks (words + tick lines) ----
words = pg.extract_words()
xt = sorted([(l['x0'], l['bottom']) for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)
             and abs(l['x0'] - l['x1']) < 1e-6 and l['bottom'] - l['top'] < 4])
xticks = sorted(set(round(x, 3) for x, _ in xt))
xlab = [0, 6, 12, 18, 24, 30, 36]
yticks = sorted(set(round(l['top'], 3) for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)
                    and abs(l['top'] - l['bottom']) < 1e-6 and l['x1'] - l['x0'] < 4))
ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax, bx = np.polyfit(xticks, xlab, 1); ay, by = np.polyfit(yticks, ylab, 1)
cal_resid = dict(x=float(np.max(np.abs(np.polyval([ax, bx], xticks) - xlab))),
                 y=float(np.max(np.abs(np.polyval([ay, by], yticks) - ylab))))
T = lambda x: ax * x + bx
S = lambda y: ay * y + by

# ---- risk table (OCR-free: PDF text) ----
rows = {}
for g in 'AB':
    lab = [w for w in words if w['text'] == g and w['x0'] < 60 and w['top'] > 280]
    top = lab[0]['top']
    nums = sorted([w for w in words if abs(w['top'] - top) < 1 and w['x0'] > 55], key=lambda w: w['x0'])
    rows[g] = [int(w['text']) for w in nums]
risk_times = xlab

recs, obs, checks = {}, {}, {'calibration': {'x_ticks_pt': xticks, 'y_ticks_pt': yticks,
                                            'max_abs_resid': cal_resid}, 'arms': {}}
for g in 'AB':
    n0 = man['groups'][g]
    cv = [c for c in pg.curves if c['stroking_color'] == COL[g] and len(c['pts']) > 10][0]
    pts = [(T(x), S(y)) for x, y in cv['pts']]
    # vertical segments = drops
    drops = [(pts[i][0], pts[i][1], pts[i + 1][1]) for i in range(len(pts) - 1)
             if abs(pts[i][0] - pts[i + 1][0]) < 1e-9 and pts[i + 1][1] < pts[i][1] - 1e-9]
    t_end = pts[-1][0]
    ticks = sorted(T(l['x0']) for l in pg.lines if l['stroking_color'] == COL[g]
                   and abs(l['x0'] - l['x1']) < 1e-6 and abs(l['bottom'] - l['top'] - 4) < 0.1)
    # merge drops at identical time (none expected)
    ev = []
    cens = list(ticks)
    n = n0; ci = 0; Sprev = 1.0
    for (t, sb, sa) in drops:
        while ci < len(cens) and cens[ci] < t:  # censor strictly before event time
            n -= 1; ci += 1
        dfrac = n * (1 - sa / sb)
        d = int(round(dfrac))
        ev.append(dict(t=t, S_before=sb, S_after=sa, n_risk=n, d_raw=dfrac, d=d))
        n -= d
    remaining_after_ticks = n - (len(cens) - ci)
    obs[g] = dict(steps=[list(p) for p in pts], drops=ev, censor_ticks=ticks, t_end=t_end,
                  S_end=pts[-1][1])
    rec = [(e['t'], 1) for e in ev for _ in range(e['d'])] + [(c, 0) for c in cens]
    # any participants not accounted for: censor at curve end (documented assumption)
    extra = n0 - len(rec)
    if extra > 0:
        rec += [(t_end, 0)] * extra
    recs[g] = dict(rec=rec, extra=extra, remaining_after_ticks=remaining_after_ticks)

os.makedirs(OUT, exist_ok=True)
df = pd.concat([pd.DataFrame(recs[g]['rec'], columns=['observed_time', 'event']).assign(group=g)
                for g in 'AB'])[['group', 'observed_time', 'event']]
df['observed_time'] = df['observed_time'].round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
json.dump(obs, open(os.path.join(OUT, 'extracted_observations.json'), 'w'), indent=1)
fd, tmp = tempfile.mkstemp(dir=OUT, suffix='.tmp'); os.close(fd)
df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
json.dump({g: dict(extra_censored_at_end=recs[g]['extra'],
                   unaccounted_after_ticks=recs[g]['remaining_after_ticks'],
                   risk_row=rows[g]) for g in 'AB'},
          open(os.path.join(OUT, 'recon_meta.json'), 'w'), indent=1)
print(df.groupby('group').agg(n=('event', 'size'), ev=('event', 'sum')))
for g in 'AB':
    print(g, 'extra', recs[g]['extra'], 'unacc', recs[g]['remaining_after_ticks'],
          'max|d_raw-d|', max(abs(e['d_raw'] - e['d']) for e in obs[g]['drops']),
          'd>1:', [(round(e['t'], 3), e['d']) for e in obs[g]['drops'] if e['d'] != 1])
print(cal_resid)
