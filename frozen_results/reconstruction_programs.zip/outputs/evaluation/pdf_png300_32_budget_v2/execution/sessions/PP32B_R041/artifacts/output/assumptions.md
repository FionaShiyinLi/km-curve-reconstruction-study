# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 391922031). No other information was used. The manifest gives no event totals, so that check is marked unavailable.

**Measurement.** The figure is a vector PDF, so I read the coordinates straight from the PDF objects with pdfplumber. I did not rasterize or OCR it.
- Time and survival were calibrated by a linear fit to the labeled axis tick marks: x ticks at 0–36 by 6 months (9.6 pt per month) and y ticks at 0–1 by 0.2 (180 pt per unit). The maximum calibration residual was below 1e-13. No global rescaling was applied.
- Each arm's curve is a single polyline, identified by stroke color and the legend. Both curves start exactly at S = 1 at t = 0. The early drops were kept exactly as drawn.
- Censor marks are 4-pt vertical line objects in the arm's color. Each object was counted as one censoring at its x position. Near-coincident marks (for example A at 30.00 and 30.02 months) are separate objects and were counted separately.
- All measurements are saved in `extracted_observations.json`: step vertices, drops, and tick times.

**Algorithm (own code, `code/reconstruct.py`, deterministic).**
- Moving forward in time, the number at risk is n minus prior events minus ticks strictly before the drop time.
- At each vertical drop, d = n_risk × (1 − S_after/S_before). No d = 1 assumption was imposed.
- Every raw d was within 5e-5 of an integer (all equal to 1), which is consistent with exact vector coordinates.
- Events plus visible ticks account for all participants in each arm: A has 79 events and 21 censorings, and B has 58 and 42. No imputed or padded censorings were needed.
- No tick coincides with a drop time; the minimum separation is 0.011 months. The event-before-censoring tie convention was therefore never invoked.
- The seed was set but not used, because nothing in the algorithm is random.
- Times are rounded to 4 decimal places (at most 5e-5 months), well below the minimum drop spacing of 0.005 months.

**Tails.**
- Arm A drops to 0 at 35.75 months, when the last participant has an event.
- Arm B ends flat at S = 0.3037, with a final censoring at 33.85 months. This is the last tick, and the curve ends there.
- No follow-up was extended beyond the drawn curve.

**Risk table.** The risk table was read from the PDF text layer. For each time t, the check counts records with observed_time ≥ t. All 14 counts match exactly, including the zeros at 36 months. The risk table was used only for verification, not fitting, and required no adjustment.

**Verification (`code/check.py` → `checks.json`).**
- The committed CSV was reloaded and a right-continuous KM curve was recomputed from it.
- It matches the measured step curve at 18–20 grid times per arm, including tail points, and just after every drop (38 in A, 31 in B).
- Tolerance was 0.0015. It is only needed to absorb the 4-decimal rounding of times; the actual residuals are about 1e-5.

**Limitations.**
- Participants censored at exactly the same time would be drawn as overlapping marks, possibly as a single object. Because the arithmetic closes exactly (integer d at every drop, all 100 per arm accounted for, all risk counts matched), there is no evidence of hidden marks. A hidden coincident mark cannot be strictly excluded, but it would have to be offset by a compensating error somewhere else.
- Event and censoring times are the plotted positions. The true times could differ by less than the drawing precision, or by any rounding the original plotting software applied.
- **Sensitivity analysis:** not run. The inputs leave no materially different event/censoring allocation that is consistent with them, so `sensitivity.csv` was not produced.
