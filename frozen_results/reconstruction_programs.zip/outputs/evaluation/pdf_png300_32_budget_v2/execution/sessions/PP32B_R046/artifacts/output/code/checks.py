"""Reload committed ipd.csv, recompute right-continuous KM, compare with vector-measured curve and risk table."""
import sys, json, hashlib
import numpy as np, pandas as pd
work = sys.argv[1] if len(sys.argv) > 1 else 'output/work'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
csv = f'{out}/ipd.csv'
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); ex = json.load(open(f'{work}/vector_extraction.json'))
arms = {'A': '(0.122, 0.467, 0.706)', 'B': '(1.0, 0.498, 0.055)'}
risk = {'A': [1000, 699, 488, 336, 233, 85, 0], 'B': [1000, 746, 559, 422, 308, 114, 0]}  # OCR/text layer of PDF
rt = [0, 6, 12, 18, 24, 30, 36]
TOL_S = 0.002  # vector coordinates: 1e-5 pt precision; allow 0.002 (~0.36 pt) for rounding of saved times
def km(d, t):
    s = 1.0
    for u in np.unique(d.observed_time[d.event == 1]):
        if u > t: break
        n = (d.observed_time >= u).sum(); k = ((d.observed_time == u) & (d.event == 1)).sum(); s *= 1 - k / n
    return s
def measured(e, t):  # right-continuous step value of the plotted vector path
    s = 1.0
    for x, sb, sa in sorted(e['drops']):
        if x <= t: s = sa
    return s
res = {'csv_sha256': sha, 'survival_tolerance': TOL_S,
       'tolerance_justification': 'curve read from PDF vector path (sub-1e-4 survival precision); 0.002 covers time rounding to 1e-5 months',
       'arms': {}}
for g, key in arms.items():
    d = df[df.group == g]; e = ex[key]
    times = [0.25, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.9, float(d.observed_time.max())]
    sc = []
    for t in times:
        m, r = measured(e, t), km(d, t)
        sc.append({'t': round(t, 5), 'measured': round(m, 6), 'reconstructed': round(r, 6), 'residual': round(r - m, 6),
                   'status': 'pass' if abs(r - m) <= TOL_S else 'fail'})
    rc = []
    for t, n in zip(rt, risk[g]):
        c = int((d.observed_time >= t).sum())
        rc.append({'t': t, 'displayed': n, 'reconstructed': c, 'residual': c - n, 'status': 'pass' if c == n else 'fail'})
    res['arms'][g] = {
        'n_records': len(d), 'n_expected': 1000, 'n_status': 'pass' if len(d) == 1000 else 'fail',
        'event_indicator_integer_01': bool(d.event.isin([0, 1]).all()),
        'events': int(d.event.sum()), 'supplied_event_total': 'unavailable (not in manifest)',
        'censor_records': int((d.event == 0).sum()), 'censor_ticks_in_pdf': len(e['ticks']),
        'max_time': float(d.observed_time.max()), 'plot_curve_end_time': e['end'][0],
        'survival_checks': sc, 'risk_table_checks': rc}
    print(g, [x['status'] for x in sc], [(x['t'], x['displayed'], x['reconstructed']) for x in rc])
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
print(sha)
