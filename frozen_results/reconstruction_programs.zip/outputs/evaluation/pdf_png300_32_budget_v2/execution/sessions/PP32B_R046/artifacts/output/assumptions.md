# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 468766617). The manifest gives no event totals, so that check is marked unavailable.

**Measurement.** The figure is vector graphics, so I read coordinates from the PDF path objects with pdfplumber and did not process pixels (`code/extract.py`). I calibrated both axes by linear fit to the labelled tick marks: x ticks 0–36 months at 64.8–410.4 pt, and y ticks 0–1 at 223.2–43.2 pt. Both fits are exact, so no global correction was applied. Both curves start at exactly (0, 1.0), so the origin needed no correction. I assigned arms by legend line colour: blue = Group A, orange = Group B. Each arm is one step path. Each vertical segment gives an event time with S_before and S_after. The censor marks are 4-pt vertical ticks in the arm's colour. Raw extraction is in `work/vector_extraction.json`.

**Algorithm (`code/reconstruct.py`).** I walked forward in time with n = 1000. Before each event time I removed any censor ticks that fall strictly earlier. At each drop I estimated d = n(1 − S_after/S_before), rounded to an integer. Ticks at the same time as a drop are removed after the events. d was not assumed to be 1. It was estimated from the measured ratio and the exact current risk set. Every drop gave d = 1 with |residual| < 0.0006 (A: 769 events; B: 683 events). Ticks: 231 for A and 317 for B. Events plus ticks equal 1000 in each arm, so no participants were left over and no censorings had to be imputed. Arm B has one pair of ticks at the same x-coordinate. I counted them as two tied censorings, and the risk table supports that. No random draws are used; the seed is recorded in the code anyway.

**Risk table.** The risk table was read from the PDF text layer. It was **not** used to fit the reconstruction, so it serves as an independent check. Counting records with observed_time ≥ t reproduces every displayed count exactly at 0, 6, 12, 18, 24, 30 and 36 months in both arms, including 0 at 36 months.

**Verification (`code/checks.py`, `checks.json`).** The script reloads the committed CSV and recomputes the right-continuous Kaplan–Meier (KM) curve. It compares that curve with the plotted step function at 16 times, from 0.25 months to the last record (about 35.99 months), with tolerance 0.002. All residuals are below 1e-6. The CSV SHA-256 is recorded in `checks.json`.

**Limitations.**
- Times are stored to 5 decimals, which is about 1e-4 pt of resolution.
- If two censorings were drawn at identical coordinates, a single visible tick could hide more than one. The exact agreement of the event and tick totals with n, and of the risk-table counts, suggests this did not happen except for the one coincident pair noted above. I cannot prove it.
- No follow-up was assumed beyond the plotted curves.

**Sensitivity analysis:** not run. No materially different allocation is consistent with the data, because the drops, ticks, arm sizes and risk table jointly fix it. This does not bound the error from any undrawn information.
