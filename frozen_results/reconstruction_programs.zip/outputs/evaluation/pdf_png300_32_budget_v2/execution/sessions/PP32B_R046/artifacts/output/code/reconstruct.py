"""Reconstruct IPD from vector_extraction.json. Deterministic; seed recorded for completeness.
Usage: python reconstruct.py [workdir] [outdir]"""
import sys, json, os, hashlib
import numpy as np, pandas as pd
SEED = 468766617; rng = np.random.default_rng(SEED)  # no random draws are used
work = sys.argv[1] if len(sys.argv) > 1 else 'output/work'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
ex = json.load(open(f'{work}/vector_extraction.json'))
N = json.load(open('../input/manifest.json'))['groups'] if len(sys.argv) < 4 else json.load(open(sys.argv[3]))['groups']
arms = {'A': '(0.122, 0.467, 0.706)', 'B': '(1.0, 0.498, 0.055)'}  # legend line colours
recs, diag = [], {}
for g, key in arms.items():
    e = ex[key]; n = N[g]
    drops = sorted(e['drops']); ticks = sorted(t[0] for t in e['ticks'])
    # merge drops at identical x (tied events drawn as consecutive segments)
    ev = []  # (time, S_before, S_after)
    for t, sb, sa in drops:
        if ev and abs(ev[-1][0] - t) < 1e-6: ev[-1][2] = sa
        else: ev.append([t, sb, sa])
    atrisk = n; ci = 0; S = 1.0; dlist = []; resid = []
    for t, sb, sa in ev:
        # censorings strictly before this event time leave the risk set first
        while ci < len(ticks) and ticks[ci] < t - 1e-6:
            recs.append((g, ticks[ci], 0)); atrisk -= 1; ci += 1
        dreal = atrisk * (1 - sa / sb); d = int(round(dreal))
        resid.append(dreal - d); dlist.append(d)
        recs += [(g, t, 1)] * d; atrisk -= d; S *= 1 - d / (atrisk + d)
    while ci < len(ticks):
        recs.append((g, ticks[ci], 0)); atrisk -= 1; ci += 1
    diag[g] = {'n_event_times': len(ev), 'events': int(sum(dlist)), 'censor_ticks': len(ticks),
               'max_abs_d_residual': float(np.max(np.abs(resid))), 'd_values': sorted(set(dlist)),
               'remaining_unassigned': atrisk, 'final_S_recon': S, 'final_S_plot': e['end'][1]}
    assert atrisk == 0, (g, atrisk)
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(5)
assert df.groupby('group').size().to_dict() == N
tmp = f'{out}/ipd.csv.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(diag, open(f'{work}/reconstruction_diagnostics.json', 'w'), indent=1)
print(json.dumps(diag, indent=1))
