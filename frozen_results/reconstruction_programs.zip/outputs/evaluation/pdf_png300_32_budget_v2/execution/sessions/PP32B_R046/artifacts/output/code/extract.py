"""Extract KM step paths and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, collections
import pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output/work'
pg = pdfplumber.open(pdf).pages[0]
# axis calibration from labelled tick marks (black 0.6 lines)
ax = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted({round(l['x0'], 3) for l in ax if abs(l['bottom'] - l['top']) > 1 and l['top'] >= 223.1})
yt = sorted({round(l['top'], 3) for l in ax if abs(l['x1'] - l['x0']) > 1 and l['x0'] < 62})
words = pg.extract_words()
xlab = {round(w['x0'] + (w['x1'] - w['x0']) / 2, 1): float(w['text']) for w in words if abs(w['top'] - 229.7) < 1}
ylab = {round((w['top'] + w['bottom']) / 2, 1): float(w['text']) for w in words if abs(w['x0'] - 43.5) < 1 and w['top'] < 225}
print('x ticks', xt, 'labels', xlab); print('y ticks', yt, 'labels', ylab)
# linear fit: time = a + b*x ; S = c + d*top
import numpy as np
xl = sorted(xlab.items()); yl = sorted(ylab.items())
bx = np.polyfit(xt, [v for _, v in xl], 1); by = np.polyfit(yt, [v for _, v in yl], 1)
print('calib time', bx, 'surv', by)
T = lambda x: float(np.polyval(bx, x)); S = lambda y: float(np.polyval(by, y))
res = {'calibration': {'time_per_pt': bx.tolist(), 'surv_per_pt': by.tolist(), 'x_ticks': xt, 'y_ticks': yt}}
# legend: 1.0-width short lines near legend text
for l in pg.lines:
    if l['linewidth'] == 1.0: print('legend line', l['stroking_color'], l['x0'], l['x1'], l['top'])
for cv in pg.curves:
    col = tuple(round(c, 3) for c in cv['stroking_color'])
    pts = cv['pts']
    steps = []  # vertical segments = drops
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-9 and y1 > y0 + 1e-9:
            steps.append([T(x0), S(y0), S(y1)])
    ticks = [l for l in pg.lines if tuple(round(c, 3) for c in l['stroking_color']) == col and l['linewidth'] < 1]
    tk = sorted([T(l['x0']), S((l['top'] + l['bottom']) / 2)] for l in ticks)
    res[str(col)] = {'start': [T(pts[0][0]), S(pts[0][1])], 'end': [T(pts[-1][0]), S(pts[-1][1])],
                     'drops': steps, 'ticks': tk}
    print(col, 'drops', len(steps), 'ticks', len(tk), 'start', res[str(col)]['start'], 'end', res[str(col)]['end'])
    dup = collections.Counter(round(t[0], 4) for t in tk); print(' duplicate tick x:', sum(v - 1 for v in dup.values()))
json.dump(res, open(f'{out}/vector_extraction.json', 'w'), indent=1)
