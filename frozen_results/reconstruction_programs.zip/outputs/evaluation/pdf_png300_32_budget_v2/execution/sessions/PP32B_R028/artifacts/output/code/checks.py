"""Reload committed CSVs, recompute right-continuous KM, compare with measured curve and risk table."""
import sys, json, hashlib, numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else '..'
TOL = 0.006   # survival tolerance: ~4.5 px; line half-width ~2.3 px + centre-estimation error ~1 px,
              # still below a one-event step (>=0.0075 at n<=100 after early censoring)
RT = {'A': [100, 76, 48, 34, 24, 10, 0], 'B': [100, 75, 58, 43, 33, 8, 0]}
RT_T = [0, 6, 12, 18, 24, 30, 36]
obs = json.load(open(f'{OUT}/extracted_observations.json'))['obs']

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d/n; out.append((u, S))
    return out
def S_at(steps, x):   # right-continuous: S(x) includes events at x
    s = 1.0
    for u, v in steps:
        if u <= x: s = v
        else: break
    return s
def rmst(steps, tau):
    a, prev_t, s = 0.0, 0.0, 1.0
    for u, v in steps:
        if u > tau: break
        a += s*(u - prev_t); prev_t, s = u, v
    return a + s*(tau - prev_t)

def check(path):
    raw = open(path, 'rb').read()
    df = pd.read_csv(path)
    res = dict(file=path.split('/')[-1], sha256=hashlib.sha256(raw).hexdigest(), arms={})
    for g in ('A', 'B'):
        d = df[df.group == g]; steps = km(d)
        lv = [l for l in obs[g]['levels'] if (l['t1'] - l['t0']) >= 0.2]
        idx = np.unique(np.linspace(0, len(lv)-1, 18).round().astype(int))
        pts = []
        for i in idx:
            l = lv[i]; tm = (l['t0'] + l['t1'])/2; r = S_at(steps, tm)
            pts.append(dict(t=round(tm, 3), measured=round(l['S'], 4), reconstructed=round(r, 4),
                            residual=round(r - l['S'], 4), status='pass' if abs(r - l['S']) <= TOL else 'fail'))
        risk = []
        for t, n in zip(RT_T, RT[g]):
            c = int((d.observed_time >= t).sum())
            risk.append(dict(t=t, displayed=n, reconstructed=c, residual=c - n, status='pass' if c == n else 'fail'))
        res['arms'][g] = dict(
            n=len(d), n_expected=100, n_status='pass' if len(d) == 100 else 'fail',
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            supplied_event_total='unavailable (not in manifest)',
            max_time=float(d.observed_time.max()),
            curve_checks=pts, risk_checks=risk, _steps=steps)
    return res

prim = check(f'{OUT}/ipd.csv')
out = dict(tolerance_survival=TOL, tolerance_note='abs survival; ~4.5 px vs 750 px/unit; risk counts exact integer match',
           primary=prim)
try:
    sens = check(f'{OUT}/sensitivity.csv')
    tau = round(min(prim['arms'][g]['max_time'] for g in 'AB'), 2)
    tau = min(tau, round(min(sens['arms'][g]['max_time'] for g in 'AB'), 2))
    comp = {}
    for g in 'AB':
        p, s = prim['arms'][g]['_steps'], sens['arms'][g]['_steps']
        comp[g] = dict(S_primary={t: round(S_at(p, t), 4) for t in (6, 12, 18, 24, 30, tau)},
                       S_sensitivity={t: round(S_at(s, t), 4) for t in (6, 12, 18, 24, 30, tau)},
                       RMST_primary=round(rmst(p, tau), 3), RMST_sensitivity=round(rmst(s, tau), 3))
    out['sensitivity'] = dict(file='sensitivity.csv', sha256=sens['sha256'], common_horizon_months=tau,
                              risk_checks={g: [r['status'] for r in sens['arms'][g]['risk_checks']] for g in 'AB'},
                              comparison=comp)
except FileNotFoundError:
    out['sensitivity'] = 'not run'
for r in [prim] + ([sens] if isinstance(out['sensitivity'], dict) else []):
    for g in 'AB': r['arms'][g].pop('_steps')
json.dump(out, open(f'{OUT}/checks.json', 'w'), indent=1)
for g in 'AB':
    a = prim['arms'][g]
    print(g, a['n'], a['events'], a['censored'], a['max_time'],
          [r['status'] for r in a['risk_checks']],
          'curve fails:', [(c['t'], c['residual']) for c in a['curve_checks'] if c['status'] != 'pass'],
          'max|res|', max(abs(c['residual']) for c in a['curve_checks']))
print(json.dumps(out['sensitivity'], indent=0)[:1500])
