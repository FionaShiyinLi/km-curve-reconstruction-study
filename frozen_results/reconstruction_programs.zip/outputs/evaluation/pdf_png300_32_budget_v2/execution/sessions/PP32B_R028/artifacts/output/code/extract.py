"""Pixel extraction of KM step curves and censor ticks from ../input/figure.png.
Usage: python extract.py [path/to/figure.png]  -> writes ../extracted_*.csv"""
import sys, json, numpy as np, pandas as pd
from PIL import Image
FIG = sys.argv[1] if len(sys.argv) > 1 else '../../../input/figure.png'
OUT = sys.argv[2] if len(sys.argv) > 2 else '..'
im = np.asarray(Image.open(FIG).convert('RGB')).astype(int)
# calibration from labelled axis ticks (black tick marks found by probe.py):
# x tick centres 269.5 + 240k for t = 0,6,...,36 ; y tick centres 179.5 (1.0) ... 929.5 (0.0)
X0, PXM = 269.5, 240/6.0
Y1, Y0 = 179.5, 929.5
t_of = lambda x: (x - X0)/PXM
s_of = lambda y: (Y0 - y)/(Y0 - Y1)
COL = {'A': (31,119,180), 'B': (255,127,14)}
def mask(rgb, tol=60):
    return (np.abs(im - np.array(rgb)).sum(2) < tol)
res = {}
for g, rgb in COL.items():
    m = mask(rgb)
    m[:, :268] = False; m[:150] = False; m[935:] = False
    H, W = m.shape
    # horizontal pixels: coloured over a 5-px window horizontally
    hz = m.copy()
    for k in (-2,-1,1,2):
        hz &= np.roll(m, k, axis=1)
    lev = np.full(W, np.nan); ext = []
    for c in range(W):
        rs = np.where(hz[:, c])[0]
        if len(rs):
            # take lowest horizontal run (at a corner column two runs may exist)
            runs = np.split(rs, np.where(np.diff(rs) > 1)[0]+1)
            lev[c] = np.mean(runs[-1]) if len(runs) == 1 else np.nan
        rr = np.where(m[:, c])[0]
        ext.append((rr.min(), rr.max()) if len(rr) else (np.nan, np.nan))
    ext = np.array(ext, float)
    cols = np.where(~np.isnan(ext[:,0]))[0]
    xmin, xmax = cols.min(), cols.max()
    res[g] = dict(lev=lev, ext=ext, xmin=xmin, xmax=xmax, hz=hz, m=m)
    print(g, 'x-range', xmin, xmax, t_of(xmin), t_of(xmax), 'line thickness sample',
          np.bincount(hz[:, xmin+5:xmax-5].sum(0))[:8])
np.save(f'{OUT}/_tmp.npy', {g:{k:v for k,v in d.items() if k in('lev','ext','xmin','xmax')} for g,d in res.items()}, allow_pickle=True)
