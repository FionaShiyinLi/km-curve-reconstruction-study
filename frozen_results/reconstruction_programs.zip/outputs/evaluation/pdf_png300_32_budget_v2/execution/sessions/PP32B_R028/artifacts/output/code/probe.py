import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
H,W,_=im.shape
blk=(im.sum(2)<150)
# axis lines
cols=blk[150:935].sum(0); print('vert axis cols',[(c,cols[c]) for c in np.argsort(cols)[-4:]])
rows=blk[:,200:1750].sum(1); print('horiz axis rows',[(r,rows[r]) for r in np.argsort(rows)[-4:]])
# x ticks below axis
for r in range(928,950):
    xs=np.where(blk[r,200:1760])[0]+200
    if 0<len(xs)<60: print('row',r,xs[:40]); 
# y ticks left of axis
for c in range(255,272):
    ys=np.where(blk[150:940,c])[0]+150
    if 0<len(ys)<80: print('col',c,ys)
# colors
from collections import Counter
cnt=Counter(map(tuple,im[150:930,272:1720].reshape(-1,3)))
print(cnt.most_common(12))
