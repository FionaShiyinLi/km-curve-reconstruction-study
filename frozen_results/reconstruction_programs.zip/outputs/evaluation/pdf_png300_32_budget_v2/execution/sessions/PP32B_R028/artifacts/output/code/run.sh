#!/bin/sh
# Run from output/code. Optional arg: path to figure.png
FIG=${1:-../../../input/figure.png}
set -e
python3 extract.py "$FIG" ..
python3 segs.py .. > ../segments_log.txt
python3 reconstruct.py "$FIG" ..
KM_MODE=sensitivity python3 reconstruct.py "$FIG" ..
python3 checks.py ..
