"""KM -> approximate IPD reconstruction (own implementation).
Usage (from output/code):  python reconstruct.py [figure.png] [outdir]
Requires ../_segs_raw.json produced by extract.py + segs.py (see run.sh)."""
import sys, os, json, hashlib, numpy as np, pandas as pd
from PIL import Image
FIG = sys.argv[1] if len(sys.argv) > 1 else '../../../input/figure.png'
OUT = sys.argv[2] if len(sys.argv) > 2 else '..'
MODE = os.environ.get('KM_MODE', 'primary')      # 'primary' or 'sensitivity'
SEED = 1458408313
rng = np.random.default_rng(SEED)                # recorded; algorithm is deterministic
X0, PXM, Y1, Y0 = 269.5, 40.0, 179.5, 929.5
t_of = lambda x: (x - X0)/PXM
s_of = lambda y: (Y0 - y)/(Y0 - Y1)
N = {'A': 100, 'B': 100}
RT = {'A': [100, 76, 48, 34, 24, 10, 0], 'B': [100, 75, 58, 43, 33, 8, 0]}   # read from figure
RT_T = [0, 6, 12, 18, 24, 30, 36]
COL = {'A': (31,119,180), 'B': (255,127,14)}
im = np.asarray(Image.open(FIG).convert('RGB')).astype(int)
raw = json.load(open(f'{OUT}/_segs_raw.json'))

def drops_for(g):
    segs = raw[g]['segs']
    m = np.abs(im - np.array(COL[g])).sum(2) < 60
    acc = [s for i, s in enumerate(segs) if s['x1'] - s['x0'] >= 2 or i == len(segs)-1]
    prev = dict(x0=int(X0), x1=int(X0), y=Y1)          # implicit start S=1 at t=0
    out = []
    for s in acc:
        lo, hi = prev['x1'], s['x0'] - 1
        if hi - lo <= 4:
            x = (lo + hi)/2 + 0.5; how = 'visible'   # riser centre = segment end + 0.5 px (verified)
        else:  # hidden gap: locate own-colour riser pixels strictly between the levels
            cs = [c for c in range(lo+1, hi+1)
                  if m[int(prev['y'])+3:int(s['y'])-2, c].any()]
            x = np.median(cs) if cs else (lo + hi)/2
            how = f'gap {lo}-{hi}, riser cols {cs[:1]}..{cs[-1:]}' if cs else f'gap {lo}-{hi}, midpoint'
        out.append(dict(x=float(x), t=t_of(x), s_before=s_of(prev['y']), s_after=s_of(s['y']), how=how))
        prev = s
    if g == 'A':
        # override (visual check of zoomed origin crop): A leaves 1.0 at x~274.5; the 0.99
        # level is hidden under B's 0.99 line until the visible riser at x~286.
        d0 = out[0]
        out[0:1] = [dict(x=274.5, t=t_of(274.5), s_before=1.0, s_after=0.99, how='override origin'),
                    dict(x=286.0, t=t_of(286.0), s_before=0.99, s_after=d0['s_after'], how='override origin')]
    return out, acc

def ticks_for(g):
    tk = []
    for x0, x1 in raw[g]['ticks']:
        w = x1 - x0 + 1
        k = 2 if w >= 5 else 1            # >=5 px wide cluster = two overlapping 3-px ticks
        tk += [t_of((x0 + x1)/2)]*k
    return sorted(tk)

def simulate(n0, events, cens, S0=1.0):
    """events: list of (t, ratio[, S_measured_after]); cens: list of times.
    Returns (records, n_end, sse of reconstructed KM vs measured levels after each drop)."""
    rec = []; n = n0; S = S0; sse = 0.0
    ci = sorted(cens); j = 0
    for t, ratio, sm in events:
        while j < len(ci) and ci[j] < t:
            rec.append((ci[j], 0)); n -= 1; j += 1
        d = int(round(n*(1 - ratio))); d = max(0, min(d, n))
        if n > 0: S *= 1 - d/n
        sse += (S - sm)**2
        rec += [(t, 1)]*d; n -= d
    while j < len(ci):
        rec.append((ci[j], 0)); n -= 1; j += 1
    return rec, n, sse

def km_end(n, ev, cens, S):
    ci = sorted(cens); j = 0
    for t, ratio, sm in ev:
        while j < len(ci) and ci[j] < t: n -= 1; j += 1
        d = max(0, min(int(round(n*(1 - ratio))), n))
        if n > 0: S *= 1 - d/n
        n -= d
    return S

def reconstruct(g):
    drops, acc = drops_for(g)
    lev = [dict(t0=t_of(s['x0']), t1=t_of(s['x1'])) for s in acc]
    ticks = ticks_for(g)
    t_last = t_of(max(raw[g]['ticks'][-1][1], acc[-1]['x1']))
    recs = []; log = []; n = RT[g][0]; Srec = 1.0
    for k in range(len(RT_T)-1):
        a, b = RT_T[k], RT_T[k+1]
        ev = [(d['t'], d['s_after']/d['s_before'], d['s_after']) for d in drops if a <= d['t'] < b]
        vt = [t for t in ticks if a <= t < b]
        target = RT[g][k+1]
        extra = 0; hist = set()
        while True:
            hi = min(b, t_last)
            if MODE == 'sensitivity':  # unseen censorings spread uniformly over the interval
                ex = [a + (j+0.5)*(hi - a)/extra for j in range(extra)]
            else:                      # primary: greedy least-squares placement against measured levels
                cand = sorted(set(vt + [(l['t0'] + l['t1'])/2 for l in lev if a <= (l['t0'] + l['t1'])/2 < hi]))
                ex = []
                for _ in range(extra):
                    best = min(cand, key=lambda c: (simulate(n, ev, vt + ex + [c], Srec)[2], c))
                    ex.append(best)
            r, nend, sse = simulate(n, ev, vt + ex, Srec)
            if nend == target or extra in hist: break
            hist.add(extra)
            if nend > target: extra += 1
            elif extra > 0: extra -= 1
            else: break
        Srec = km_end(n, ev, vt + ex, Srec)   # carry reconstructed KM to next interval
        log.append(dict(interval=[a, b], n_start=n, target=target, n_end=nend, visible_ticks=len(vt),
                        extra_censor=extra, extra_censor_times=[round(x, 3) for x in ex], sse=sse, events=sum(e for _, e in r), status='ok' if nend == target else 'UNRESOLVED'))
        recs += r; n = nend
    if n > 0:   # should not happen (last risk count 0); censor at last observed time
        recs += [(t_last, 0)]*n
    return recs, log, drops, ticks, acc

allrec = []; logs = {}; obs = {}
for g in ('A', 'B'):
    recs, log, drops, ticks, acc = reconstruct(g)
    assert len(recs) == N[g], (g, len(recs))
    allrec += [(g, round(t, 4), e) for t, e in recs]
    logs[g] = log
    obs[g] = dict(drops=drops, ticks=ticks, levels=[dict(t0=t_of(s['x0']), t1=t_of(s['x1']), S=s_of(s['y'])) for s in acc])
    for l in log: print(g, l)
df = pd.DataFrame(allrec, columns=['group', 'observed_time', 'event'])
fname = 'ipd.csv' if MODE == 'primary' else 'sensitivity.csv'
tmp = f'{OUT}/.{fname}.tmp'
df.to_csv(tmp, index=False); os.replace(tmp, f'{OUT}/{fname}')
if MODE == 'primary':
    json.dump(dict(logs=logs, obs=obs), open(f'{OUT}/extracted_observations.json', 'w'), indent=1, default=float)
print('wrote', fname, len(df))
