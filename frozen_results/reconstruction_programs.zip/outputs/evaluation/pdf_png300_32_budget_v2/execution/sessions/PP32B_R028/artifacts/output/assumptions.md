# Reconstruction assumptions (figure.png, groups A and B, n = 100 each)

**Inputs.** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (n = 100/100, months, seed 1458408313).
The manifest has no event totals, so that check is marked *unavailable* (this does not mean zero events).
Risk table read by eye from the figure: A 100/76/48/34/24/10/0, B 100/75/58/43/33/8/0 at 0,6,...,36 months.
The glyphs are clean and unambiguous. I used Python (the specified runtime) rather than R. The seed is set in
`reconstruct.py`, but the algorithm is deterministic and draws no random numbers.

**Calibration.** Black tick marks on the axes: t = 0,...,36 at x = 269.5 + 40 t px; S = 1.0 at y = 179.5 and 0.0 at y = 929.5
(750 px per unit). Only this linear map is used. There is no global rescaling or running-minimum correction.
Both curves start at the y = 1.0 pixel row.

**Measurement** (`extract.py`, `segs.py`). The lines are exact RGB colours (A #1f77b4, B #ff7f0e), about 4.5 px thick.
Each level is the centre of a horizontal run (5-px window) in that colour. Levels at least 3 px long are kept.
Shorter pieces are riser corners and are merged, so a merged drop can contain several events.
A drop's time is the riser centre, which I checked to be the segment end + 0.5 px.
Where A is hidden under B (0.4-1.7, 5.1-5.4, 8.4-8.6 months), the drop time is the median of A's own visible riser columns.
At the origin, A's level 0.99 is hidden under B's 0.99 line. From a zoomed crop, I entered two manual drops:
1.0 -> 0.99 at 0.125 months and 0.99 -> 0.97 at 0.41 months.
Censor ticks are columns whose colour extends more than 6 px above and below the adjacent levels.
A cluster at least 5 px wide counts as 2 ticks (a single tick is 2-3 px wide).
B has a partly hidden tick at the 0.99 level at t = 0.04, next to the y-axis spine. I accepted it as one censoring.
Extracted levels, drops and ticks are saved in `extracted_observations.json` and `segments_log.txt`.

**Algorithm** (`reconstruct.py`, my own implementation). Each interval between risk-table times is processed in order.
Visible ticks are censorings. Each drop gets d = round(n_risk * (1 - S_after/S_before)), with n_risk updated
for censorings before the drop; events precede censorings at tied times.
If the implied count at the next risk time is too high, unseen censorings are added one at a time until it equals
the displayed count. **Primary allocation (assumption):** each added censoring is placed greedily at the
candidate time that minimizes squared error between the reconstructed KM and the measured levels in that
interval. Candidates are visible tick times and midpoints of flat segments.
This uses only the curve levels and the risk table; it is not a unique recovery.
Unseen censorings added: A 2 (6-12), 1 (24-30); B 1 (0-6), 1 (12-18), 6 (24-30).
Of B's 6, three sit at 24.06 months. That point is weakly identified: the dense tick cluster at 24.8-25.5 months
could also hide multiple ticks.
The last displayed count is 0 at 36, so everyone left after the last event is censored at the visible tail ticks
(A last 35.01, B last 34.24). No follow-up beyond the last drawn curve point is invented.

**Result.** A: 74 events, 26 censored; B: 70 events, 30 censored. `ipd.csv` SHA-256 = `b17547e2491dcb7ba46864e074ac526256b6be8eed6c23fef785b5af9a9610ac`.

**Checks** (`checks.py`, results in `checks.json`). The committed CSV is reloaded and the right-continuous KM recomputed.
It is compared with measured levels at 18 segment midpoints per arm, including both tails.
Tolerance is 0.006 (about 4.5 px: line half-width plus centre error; smaller than a one-event step).
All points pass: max |residual| is 0.0012 for A and 0.0007 for B.
Risk counts (number with observed_time >= t) match exactly at all 7 times in both arms.
A has an event measured at exactly 6.00 months (riser at x = 509.5), so it is in the 6-month risk set.
That agreement depends on the half-pixel riser offset; a 1-px error would put it before 6 and break the 76.

**Revision history.** First complete file: the unseen censorings were spread uniformly within each interval.
In B the 24-30 interval then put the tail plateau at 0.2462 against a measured 0.2400, failing at 0.0062.
I did one correction cycle, the least-squares placement above; the tolerance was not changed.

**Sensitivity** (`sensitivity.csv`, one alternative). Same drops and ticks, with the unseen censorings spread uniformly
over each interval (Guyot-style). It meets all risk counts.
Common horizon tau = 34.24 months (last observed time in B).
Restricted mean survival time (RMST) to tau, primary vs alternative: A 16.29 vs 16.31, B 17.71 vs 17.76.
S(30): A 0.227 vs 0.229, B 0.240 vs 0.246.
This one alternative is not a confidence interval or a bound on reconstruction error.

**Limitations.** Tick multiplicity can't be recovered where ticks overlap or are hidden under the other curve.
Event times inside merged risers are placed at a single time (error under 0.1 month).
Censoring times between ticks are modelled, not observed. There are no event totals to confirm the event counts.
