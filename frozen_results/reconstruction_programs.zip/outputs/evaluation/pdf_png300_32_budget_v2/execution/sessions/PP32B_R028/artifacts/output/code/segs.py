"""Segment curves into horizontal levels, drops and censor ticks. Writes extracted observations."""
import sys, json, numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else '..'
X0, PXM, Y1, Y0 = 269.5, 40.0, 179.5, 929.5
t_of = lambda x: (x - X0)/PXM
s_of = lambda y: (Y0 - y)/(Y0 - Y1)
D = np.load(f'{OUT}/_tmp.npy', allow_pickle=True).item()
allobs = {}
for g, d in D.items():
    lev, ext, xmin, xmax = d['lev'], d['ext'], d['xmin'], d['xmax']
    # constant-level segments
    segs = []; cur = None
    for c in range(xmin, xmax+1):
        v = lev[c]
        if np.isnan(v): continue
        if cur and abs(v - cur['y']) <= 1.0 and c - cur['x1'] <= 60:
            cur['x1'] = c; cur['ys'].append(v)
        else:
            if cur: segs.append(cur)
            cur = dict(x0=c, x1=c, y=v, ys=[v])
        cur['y'] = np.median(cur['ys'])
    segs.append(cur)
    segs = [s for s in segs if s['x1'] - s['x0'] >= 0]
    # ticks: columns whose coloured extent reaches > 6 px beyond both neighbouring levels
    tickcols = []
    for c in range(xmin, xmax+1):
        if np.isnan(ext[c,0]): continue
        # levels just left/right
        L = [s['y'] for s in segs if s['x0'] <= c+3 and s['x1'] >= c-3]
        if not L: continue
        top, bot = min(L), max(L)
        if ext[c,0] < top - 6 and ext[c,1] > bot + 6:
            tickcols.append(c)
    ticks = []
    for c in tickcols:
        if ticks and c - ticks[-1][-1] <= 1: ticks[-1].append(c)
        else: ticks.append([c])
    print(f'== {g}: {len(segs)} segments, {len(ticks)} tick clusters')
    for s in segs:
        print(f"  seg x {s['x0']}-{s['x1']} t {t_of(s['x0']):.3f}-{t_of(s['x1']):.3f} y {s['y']:.1f} S {s_of(s['y']):.4f}")
    print('  ticks (x0,x1,width,t):', [(k[0], k[-1], len(k), round(t_of(np.mean(k)),3)) for k in ticks])
    allobs[g] = dict(segs=[dict(x0=int(s['x0']), x1=int(s['x1']), y=float(s['y'])) for s in segs],
                     ticks=[[int(k[0]), int(k[-1])] for k in ticks])
json.dump(allobs, open(f'{OUT}/_segs_raw.json','w'))
