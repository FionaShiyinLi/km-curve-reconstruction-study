import numpy as np
from PIL import Image
im=Image.open('../../../input/figure.png').convert('RGB')
boxes=[(262,170,352,260),(460,300,520,360),(590,380,640,430),(1220,640,1300,730),(1370,740,1400,770),(1620,800,1680,840)]
tiles=[im.crop(b).resize(((b[2]-b[0])*6,(b[3]-b[1])*6),Image.NEAREST) for b in boxes]
W=max(t.size[0] for t in tiles[:3])+max(t.size[0] for t in tiles[3:])+10
H=max(sum(t.size[1] for t in tiles[:3]),sum(t.size[1] for t in tiles[3:]))+20
out=Image.new('RGB',(W,H),'gray')
y=0
for t in tiles[:3]: out.paste(t,(0,y)); y+=t.size[1]+5
y=0; x0=max(t.size[0] for t in tiles[:3])+10
for t in tiles[3:]: out.paste(t,(x0,y)); y+=t.size[1]+5
out.save('../_crops.png'); print(out.size)
