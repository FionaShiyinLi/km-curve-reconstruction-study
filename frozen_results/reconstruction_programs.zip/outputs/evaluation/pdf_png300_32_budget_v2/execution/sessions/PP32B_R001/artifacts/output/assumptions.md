# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`, a vector PDF, read with pdfplumber. It contains one polyline per arm, one short vertical line object per drawn censor tick, axis tick lines, text labels and the number-at-risk table.
- `../input/manifest.json`: n = 1000 per arm, time unit months, code seed 254961424. The seed is recorded in the code. The primary algorithm is deterministic, so the seed is never used to draw random numbers. The manifest gives no arm-specific event totals, so that check is marked unavailable.
- Arms were identified by legend color: Group A is blue (0.1216, 0.4667, 0.7059) and Group B is orange (1.0, 0.498, 0.0549).

## Calibration
Time comes from the seven labelled x-axis tick lines (0–36 months; 9.6 pt per month, origin at x = 64.8 pt). Survival comes from the six labelled y-axis tick lines (0–1; 180 pt per unit). Linear-fit residuals are below 1e-13. No global rescaling or origin correction was applied. Both curves start exactly at S = 1 at t = 0, and the first drop in each arm is kept as measured.

## Algorithm (primary, `output/ipd.csv`)
1. Every vertical segment of an arm's path is an event drop. The drops are 772 in A and 602 in B.
2. Every drawn tick is a censoring at the tick's x position. There are 228 ticks in A and 398 in B. No two ticks share an x coordinate, and no tick sits at an event time.
3. Each drop is recorded as a single event (d = 1). This was checked, not assumed. First, drops plus ticks equals exactly 1000 in each arm. If any tick stands for at least one participant, a drop with d ≥ 2 would push the total above n. Second, with the risk sets these records imply, every drop satisfies (1 − S_after/S_before) × n_risk = 1 to within 5.3e-4. A drop with d = 2 would give a value near 2. The small deviations are consistent with the PDF's roughly 1e-4 pt coordinate precision.
4. Participants still at risk after the last event are exactly the ticks that come after it (23 in A, 19 in B). The last tick coincides with the curve's end, at 35.977 months in A and 35.966 months in B. No follow-up is extended beyond the drawn curve.

The identification rests on one assumption: each drawn tick object is one censored participant and no tick is hidden. The exact count and the q × n_risk = 1 check both support this assumption, but they do not prove it.

## Risk table and verification (`output/checks.json`)
I reloaded the committed CSV and recomputed the right-continuous KM curve. It matches the measured vector curve after every one of the 1374 drops, with a maximum absolute difference of 2.8e-7. It also matches at 16 spot times per arm, from 0.5 months through the curve end. The survival tolerance is 1e-4, well below one event (about 1e-3). The number at risk, counted as records with observed_time ≥ t, equals the printed table at every one of t = 0, 6, …, 36 in both arms, including 0 at 36 months. The risk table was not used to fit the records, so this is an independent check. The file has 1000 records per arm, and event is always 0 or 1.

## Sensitivity (`output/sensitivity.csv`)
The alternative ignores tick count and position. It infers d and n_risk from drop heights alone by sequential inversion, taking the largest integer d consistent with the number still at risk. Censorings are spaced evenly within each inter-event interval. The common horizon is 35.966 months, the earliest last observed time.
- Survival at the horizon and the area under the curve up to it are the same in both allocations: A 0.1486 and 15.686 months; B 0.3099 and 19.037 months.
- In B, the inversion splits one drop as d = 2 with one fewer censoring. Its risk counts then miss the printed table by 1 at 24 and 30 months (384 and 165 instead of 385 and 166). This is one reason the tick-based allocation is kept as primary.

This single alternative is not an uncertainty bound.

## Limitations
- Censor times inside an interval are only as precise as the tick x coordinates (about 1e-5 months).
- Event times are stored to 6 decimal places.
- If the plotting software thinned or merged coincident ticks, or collapsed tied events, the reconstruction could differ. No evidence for this was found. The totals and drop ratios are exactly consistent with one participant per object.
- `fig-1.png` is a 150-dpi rendering kept for visual inspection. `drops_*.csv` and `censor_ticks_*.csv` hold the extracted numerical observations.
