"""Reconstruct participant-level records from the vector KM figure.

Usage: python reconstruct.py [--input ../input] [--out output]
(paths relative to the work directory). No KM-to-IPD package is used.

Primary algorithm (reconstruct_direct): events at every vertical drop of the
arm's vector KM path (d=1 each), censorings at every drawn censor tick.
Sensitivity algorithm (reconstruct(mode="even")) described below.
1. Parse the PDF vector paths with pdfplumber. Calibrate time and survival
   from the labelled axis tick lines (x ticks 0..36 months, y ticks 0..1).
2. Each arm's KM curve is a polyline; every vertical segment is an event drop
   with ratio r = S_after/S_before. With q = 1 - r, d/n_risk = q.
3. Sequential inversion: carrying n_avail (the number still under follow-up),
   choose integer d as the largest d with d/q <= n_avail + tol and record
   n_risk = round(d/q) (integer residual kept for inspection). Censorings
   between successive event times are n_avail - n_risk.
4. Censor times inside each inter-event interval are taken from the drawn
   censor-tick x positions in that interval (cycled if more censorings than
   ticks); if the interval has no tick, times are spread evenly within it.
   Participants remaining after the last drop are censored at tick positions
   after the last event, ending at the curve end.
"""
import argparse, hashlib, json, os, sys
import numpy as np
import pandas as pd
import pdfplumber

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
args = ap.parse_args()
SEED = 254961424
rng = np.random.default_rng(SEED)  # recorded; the primary algorithm is deterministic

man = json.load(open(os.path.join(args.input, "manifest.json")))
N = man["groups"]
page = pdfplumber.open(os.path.join(args.input, "figure.pdf")).pages[0]

# ---- calibration from axis ticks -------------------------------------------
blk = [l for l in page.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted({round(l["pts"][0][0], 4) for l in blk
             if abs(l["pts"][0][0] - l["pts"][1][0]) < 1e-6 and max(p[1] for p in l["pts"]) > 225})
yt = sorted({round(l["pts"][0][1], 4) for l in blk
             if abs(l["pts"][0][1] - l["pts"][1][1]) < 1e-6 and min(p[0] for p in l["pts"]) < 63})
xlab = [0, 6, 12, 18, 24, 30, 36]
ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # top-down in pdfplumber coordinates
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
ax_, bx_ = np.polyfit(xt, xlab, 1)
ay_, by_ = np.polyfit(yt, ylab, 1)
cal = dict(x_ticks_pt=xt, y_ticks_pt=yt, months_per_pt=ax_, x0=bx_, surv_per_pt=ay_, y0=by_,
           x_fit_resid=list(np.polyval([ax_, bx_], xt) - xlab),
           y_fit_resid=list(np.polyval([ay_, by_], yt) - ylab))
T = lambda x: ax_ * np.asarray(x) + bx_
S = lambda y: ay_ * np.asarray(y) + by_

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}  # from legend


def arm_geometry(g):
    col = COL[g]
    cur = [c for c in page.curves if tuple(c["stroking_color"]) == col]
    assert len(cur) == 1
    pts = np.array(cur[0]["pts"])
    ticks = [l for l in page.lines if tuple(l["stroking_color"]) == col and abs(l["linewidth"] - 0.65) < 1e-3]
    tick_x = np.array(sorted(l["pts"][0][0] for l in ticks))
    tick_y = np.array([np.mean([p[1] for p in l["pts"]]) for l in sorted(ticks, key=lambda l: l["pts"][0][0])])
    return pts, tick_x, tick_y


def drops_from_path(pts):
    ev = []  # (x, S_before, S_after)
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-9 and y1 > y0 + 1e-9:
            if ev and abs(ev[-1][0] - x0) < 1e-9:
                ev[-1] = (x0, ev[-1][1], float(S(y1)))
            else:
                ev.append((x0, float(S(y0)), float(S(y1))))
    return ev


def reconstruct_direct(g):
    """Primary: one event per vector drop, one censoring per drawn tick.
    Justified (not assumed) because drops + ticks = N exactly and, with the
    risk sets implied by these records, every drop satisfies q * n_risk = 1."""
    pts, tick_x, tick_y = arm_geometry(g)
    ev = drops_from_path(pts)
    et = T([e[0] for e in ev]); ct = T(tick_x)
    df = pd.DataFrame(dict(group=g, observed_time=np.r_[et, ct],
                           event=np.r_[np.ones(len(et), int), np.zeros(len(ct), int)]))
    df = df.sort_values(["observed_time", "event"], ascending=[True, False]).reset_index(drop=True)
    t = df.observed_time.values
    nr = np.array([(t >= u).sum() for u in et])
    q = np.array([1 - e[2] / e[1] for e in ev])
    dg = pd.DataFrame(dict(t=et, S_before=[e[1] for e in ev], S_after=[e[2] for e in ev], q=q,
                           d=1, n_risk=nr, q_times_n=q * nr))
    return df, dg, dict(n_ticks=len(tick_x), t_end=float(T(pts[-1, 0])), n_drops=len(ev),
                        max_abs_q_times_n_minus_1=float(np.abs(q * nr - 1).max()),
                        drops_plus_ticks=len(ev) + len(tick_x))


def reconstruct(g, mode="ticks"):
    pts, tick_x, tick_y = arm_geometry(g)
    ev = drops_from_path(pts)
    t_end = float(T(pts[-1, 0]))
    t_tick = T(tick_x)
    n_avail = N[g]
    rows, diag = [], []
    ev_t = [float(T(e[0])) for e in ev]

    def censor_block(k, lo, hi):
        if k <= 0:
            return []
        if mode == "ticks":
            tk = t_tick[(t_tick >= lo - 1e-9) & (t_tick < hi - 1e-9)] if hi > lo else np.array([])
            if len(tk):
                return list(np.resize(np.sort(tk), k))
        # no tick (or sensitivity mode): evenly spaced within the open interval
        return list(lo + (hi - lo) * (np.arange(k) + 0.5) / k)

    prev_t = 0.0
    for i, (x, sb, sa) in enumerate(ev):
        t = ev_t[i]
        q = 1.0 - sa / sb
        dmax = int(np.floor(q * (n_avail + 0.5)))
        d = max(dmax, 1)
        n_hat = d / q
        n_risk = int(round(n_hat))
        n_risk = min(n_risk, n_avail)
        c = n_avail - n_risk  # censored in [prev_t, t)
        rows += [(g, ct, 0) for ct in censor_block(c, prev_t, t)]
        rows += [(g, t, 1)] * d
        diag.append(dict(t=t, S_before=sb, S_after=sa, q=q, d=d, n_hat=n_hat, n_risk=n_risk,
                         int_resid=n_hat - round(n_hat), censored_before=c))
        n_avail = n_risk - d
        prev_t = t
    # remaining participants after last event: censored in [last event, curve end]
    rem = n_avail
    if mode == "ticks":
        tk = np.sort(t_tick[t_tick >= prev_t - 1e-9])
        if len(tk) == 0 or tk[-1] < t_end - 1e-6:
            tk = np.append(tk, t_end)
        ct = list(np.resize(tk, rem)) if rem else []
        # make sure one record reaches the curve end
        if rem:
            ct[-1] = t_end
    else:
        ct = list(prev_t + (t_end - prev_t) * (np.arange(1, rem + 1)) / rem) if rem else []
    rows += [(g, c, 0) for c in ct]
    df = pd.DataFrame(rows, columns=["group", "observed_time", "event"])
    return df, pd.DataFrame(diag), dict(n_ticks=len(tick_x), t_end=t_end, n_drops=len(ev),
                                        remaining_after_last_event=int(rem))


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1])
    s, out = 1.0, []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; out.append((u, s))
    return np.array(out)


def km_at(curve, tq):
    idx = np.searchsorted(curve[:, 0], tq, side="right") - 1
    return np.where(idx >= 0, curve[np.maximum(idx, 0), 1], 1.0)


def measured_at(pts, tq):
    # right-continuous step read from the vector path: last vertex with x <= t
    xs, ys = T(pts[:, 0]), S(pts[:, 1])
    out = []
    for t in np.atleast_1d(tq):
        m = xs <= t + 1e-12
        out.append(float(ys[m][-1]))  # path is ordered; last vertex at/left of t = post-drop value
    return np.array(out)


def rmst(curve, tau):
    ts = np.concatenate([[0], curve[:, 0][curve[:, 0] < tau], [tau]])
    ss = np.concatenate([[1], curve[:, 1][curve[:, 0] < tau]])
    return float(np.sum(np.diff(ts) * ss))


def atomic_csv(df, path):
    tmp = path + ".tmp"
    df.to_csv(tmp, index=False, float_format="%.6f")
    os.replace(tmp, path)


if __name__ == "__main__":
    os.makedirs(args.out, exist_ok=True)
    res, diags, info = {}, {}, {}
    for g in ["A", "B"]:
        df, dg, inf = reconstruct_direct(g)
        assert len(df) == N[g], (g, len(df))
        res[g], diags[g], info[g] = df, dg, inf
        dg.to_csv(os.path.join(args.out, f"drops_{g}.csv"), index=False)
        pts, tx, ty = arm_geometry(g)
        pd.DataFrame(dict(x_pt=tx, t_months=T(tx), y_pt=ty, S=S(ty))).to_csv(
            os.path.join(args.out, f"censor_ticks_{g}.csv"), index=False)
    ipd = pd.concat([res["A"], res["B"]], ignore_index=True)
    ipd["observed_time"] = ipd.observed_time.clip(lower=0).round(6)
    ipd["event"] = ipd.event.astype(int)
    path = os.path.join(args.out, "ipd.csv")
    atomic_csv(ipd, path)

    # ---- checks from the committed file ------------------------------------
    ipd = pd.read_csv(path)
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    risk_tab = {"A": [1000, 698, 487, 356, 249, 81, 0], "B": [1000, 659, 552, 454, 385, 166, 0]}
    rt = [0, 6, 12, 18, 24, 30, 36]
    chk = dict(csv_sha256=sha, calibration=cal, seed=SEED, arms={})
    for g in ["A", "B"]:
        d = ipd[ipd.group == g]
        cur = km(d)
        pts, _, _ = arm_geometry(g)
        tq = [0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.9, info[g]["t_end"]]
        meas = measured_at(pts, tq); rec = km_at(cur, np.array(tq))
        tol = 1e-4  # path coordinates carry ~1e-4 pt precision (<1e-6 in S); 1e-4 leaves margin, far below one event (~1e-3)
        surv = [dict(t=float(t), measured=float(m), reconstructed=float(r), resid=float(r - m),
                     status="pass" if abs(r - m) <= tol else "fail") for t, m, r in zip(tq, meas, rec)]
        # all-drop comparison
        evt = np.round(diags[g].t.values, 6) + 1e-9  # CSV stores 6 dp
        all_res = km_at(cur, evt) - diags[g].S_after.values
        risk = []
        for t, n in zip(rt, risk_tab[g]):
            nr = int((d.observed_time >= t).sum())
            risk.append(dict(t=t, table=n, reconstructed=nr, resid=nr - n,
                             status="pass" if nr == n else "fail"))
        chk["arms"][g] = dict(
            n=int(len(d)), n_expected=N[g], events=int(d.event.sum()), censored=int((d.event == 0).sum()),
            event_indicator_integer=bool(set(d.event.unique()) <= {0, 1}),
            supplied_event_total="unavailable (not in manifest)",
            n_drops=info[g]["n_drops"], n_censor_ticks=info[g]["n_ticks"], curve_end_months=info[g]["t_end"],
            max_abs_resid_all_drops=float(np.max(np.abs(all_res))),
            drops_plus_ticks=info[g]["drops_plus_ticks"],
            max_abs_q_times_n_minus_1=info[g]["max_abs_q_times_n_minus_1"],
            drops_with_d_gt_1=int((diags[g].d > 1).sum()),
            survival_checks=surv, survival_tolerance=tol, risk_table_checks=risk)

    # ---- sensitivity: censor times spread evenly within intervals (ignore tick positions)
    sens = []
    for g in ["A", "B"]:
        df, _, _ = reconstruct(g, "even")
        sens.append(df)
    sens = pd.concat(sens, ignore_index=True)
    sens["observed_time"] = sens.observed_time.round(6)
    atomic_csv(sens, os.path.join(args.out, "sensitivity.csv"))
    tau = float(min(ipd.groupby("group").observed_time.max().min(), sens.groupby("group").observed_time.max().min()))
    sc = dict(assumption="ignore tick positions/count: infer n_risk and d from drop heights alone (sequential inversion), censorings evenly spaced within each inter-event interval",
              horizon=tau, arms={})
    for g in ["A", "B"]:
        c1 = km(ipd[ipd.group == g]); c2 = km(sens[sens.group == g])
        sc["arms"][g] = dict(S_primary=float(km_at(c1, np.array([tau]))[0]), S_sens=float(km_at(c2, np.array([tau]))[0]),
                             RMST_primary=rmst(c1, tau), RMST_sens=rmst(c2, tau),
                             risk_primary=[int((ipd[ipd.group == g].observed_time >= t).sum()) for t in rt],
                             risk_sens=[int((sens[sens.group == g].observed_time >= t).sum()) for t in rt])
    chk["sensitivity"] = sc
    json.dump(chk, open(os.path.join(args.out, "checks.json"), "w"), indent=1, default=float)
    for g in ["A", "B"]:
        a = chk["arms"][g]
        print(g, {k: a[k] for k in ["n", "events", "censored", "n_drops", "n_censor_ticks", "curve_end_months",
                                    "max_abs_resid_all_drops", "drops_plus_ticks", "max_abs_q_times_n_minus_1", "drops_with_d_gt_1"]})
        print("  risk", [(r["t"], r["table"], r["reconstructed"]) for r in a["risk_table_checks"]])
        print("  surv fails", [s for s in a["survival_checks"] if s["status"] != "pass"])
    print(json.dumps(sc, indent=0))
    print("sha", sha)
