"""Reconstruct approximate participant-level records from the KM figure.

Usage (from the work directory):
    python3 output/code/reconstruct.py [../input/figure.png] [../input/manifest.json] [outdir]

Algorithm (own implementation; no KM-to-IPD package):
 1. extract.py measures the step curves (levels between drops) and censor ticks.
 2. Documented manual overrides replace the automated reading where arm A is
    occluded by arm B near the origin (pixel columns inspected by hand).
 3. Per risk-table interval [T_k, T_k+1), the number censored c_k is chosen so
    that the reconstructed number at risk at T_k+1 matches the table. Given c_k,
    censor times are the visible tick positions (one per tick, two for clusters
    >=4 px wide; any surplus is assigned to visible ticks as multiplicity, widest
    ticks first; if the interval has no visible tick, censors are spread evenly).
    Sensitivity mode ("alt" 4th argument): every tick cluster counts once and any
    surplus censors are spread evenly over the interval (Guyot-type convention);
    written to sensitivity.csv instead of ipd.csv.
    Events at each measured drop: d = round(n_risk * (1 - S_meas_after / S_rec_before)),
    using the reconstructed KM before the drop (Guyot-type cumulative correction).
    Multi-event drops whose vertical segment spans >5 px columns are spread evenly
    over that span (the individual sub-steps are not resolvable).
 4. The last interval (to the table's zero at 36) ends with all remaining
    participants censored at visible tick positions (no follow-up beyond the last
    visible curve point is invented).
The program is deterministic; the manifest seed is set and recorded anyway.
"""
import json
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract import extract  # noqa: E402

FIG = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
MAN = sys.argv[2] if len(sys.argv) > 2 else "../input/manifest.json"
OUT = sys.argv[3] if len(sys.argv) > 3 else "output"
ALT = len(sys.argv) > 4 and sys.argv[4] == "alt"

manifest = json.load(open(MAN))
SEED = manifest["code_seed"]
np.random.seed(SEED)  # not used by the deterministic algorithm; recorded

# Risk table read from the figure (OCR by visual inspection of the rendered image)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 66, 42, 28, 23, 5, 0], "B": [100, 67, 44, 33, 25, 6, 0]}

# Manual overrides from hand-inspected pixel columns (see assumptions.md):
#  A: its 1.0 line is visible at columns 272-274 only and is gone from 275, where
#     it lies under B's 0.99 line -> drop 1.0->0.99 at col ~273 (t=0.09). Then
#     visible verticals at cols ~291 (0.99->0.98), ~295 (0.98->0.97), ~301.5 (0.97->0.96).
#  B: vertical 1.0->0.99 at cols 268-271 (centre 269.5-270, t~0.0); recorded at t=0.01.
OVERRIDE_EARLY = {
    "A": {"t_max": 0.85, "steps": [(0.09, 1.00, 0.99), (0.54, 0.99, 0.98),
                                   (0.64, 0.98, 0.97), (0.80, 0.97, 0.96)]},
    "B": {"t_max": 0.05, "steps": [(0.01, 1.00, 0.99)]},
}
JITTER = 3.0 / 750  # level changes < 3 px are line-thickness jitter, not drops


def clean_steps(g, ex):
    st = []
    for s in ex[g]["steps"]:
        st.append([s["t"], s["S_before"], s["S_after"], s["gap_cols"]])
    ov = OVERRIDE_EARLY[g]
    st = [s for s in st if s[0] > ov["t_max"]]
    st = [[t, a, b, 0] for t, a, b in ov["steps"]] + st
    # merge jitter: consecutive level changes smaller than JITTER
    out = []
    for s in st:
        if abs(s[1] - s[2]) < JITTER:
            if out:
                out[-1][2] = s[2] if s[2] < out[-1][2] else out[-1][2]
            continue
        out.append(s)
    # enforce level continuity (S_before of step j = S_after of step j-1)
    for j in range(1, len(out)):
        out[j][1] = out[j - 1][2]
    return out


def km(times, events):
    df = pd.DataFrame({"t": times, "e": events}).sort_values("t")
    ut = np.unique(df.t)
    n = len(df)
    s, S, T = 1.0, [], []
    for u in ut:
        at = (df.t >= u).sum()
        d = ((df.t == u) & (df.e == 1)).sum()
        if d:
            s *= 1 - d / at
            T.append(u)
            S.append(s)
    return np.array(T), np.array(S)


def km_at(T, S, t):
    i = np.searchsorted(T, t, side="right") - 1
    return 1.0 if i < 0 else S[i]


def simulate_interval(n0, t0, t1, steps, ticks, c, s_rec0, last):
    """Return (event_times, censor_times, n_end, s_rec_end)."""
    # censor times
    tk = [k for k in ticks if t0 <= k["t"] < t1] if not last else \
         [k for k in ticks if t0 <= k["t"] <= t1]
    cens = []
    if ALT:
        tk = [dict(k, mult=1) for k in tk]
        base = [k["t"] for k in tk][:c]
        extra = c - len(base)
        cens = base + list(t0 + (t1 - t0) * (np.arange(extra) + 0.5) / max(extra, 1))[:extra]
    elif c > 0:
        if tk:
            base = [k["t"] for k in tk for _ in range(k["mult"])][:c]
            cens = list(base)
            order = sorted(tk, key=lambda k: -k["width"])
            i = 0
            while len(cens) < c:
                cens.append(order[i % len(order)]["t"])
                i += 1
        else:
            cens = list(t0 + (t1 - t0) * (np.arange(c) + 0.5) / c)
    cens = sorted(cens)
    evs = []
    n = n0
    s_rec = s_rec0
    ci = 0
    for (t, sb, sa, gap) in steps:
        while ci < len(cens) and cens[ci] < t:
            n -= 1
            ci += 1
        if n <= 0:
            break
        d = int(round(n * (1 - sa / s_rec)))
        d = max(0, min(d, n))
        if d == 0:
            continue
        if d > 1 and gap > 5:
            w = gap / 40.0
            tt = list(t - w / 2 + w * (np.arange(d) + 0.5) / d)
        else:
            tt = [t] * d
        for x in tt:
            evs.append(x)
            s_rec *= 1 - 1 / n
            n -= 1
    n -= len(cens) - ci
    return evs, cens, n, s_rec, sum(k["mult"] for k in tk)


def reconstruct(g, ex):
    steps = clean_steps(g, ex)
    ticks = ex[g]["ticks"]
    t_end = ex[g]["t_last"]
    ev_all, ce_all, diag = [], [], []
    n0, s_rec = RISK[g][0], 1.0
    for k in range(len(RISK_T) - 1):
        t0, t1 = RISK_T[k], RISK_T[k + 1]
        last = RISK[g][k + 1] == 0 or k == len(RISK_T) - 2
        st = [s for s in steps if t0 <= s[0] < t1]
        target = RISK[g][k + 1]
        best = None
        for c in range(0, n0 + 1):
            evs, cens, n_end, s_end, ntk = simulate_interval(
                n0, t0, min(t1, t_end + 1e-9) if last else t1, st, ticks, c, s_rec, last)
            if n_end < 0:
                break
            # objective: match table; tie-break toward the tick count and the curve
            s_err = abs(s_end - (st[-1][2] if st else s_rec))
            score = (abs(n_end - target), abs(c - ntk), s_err)
            if best is None or score < best[0]:
                best = (score, c, evs, cens, n_end, s_end, ntk)
        score, c, evs, cens, n_end, s_end, ntk = best
        diag.append({"interval": [t0, t1], "n_start": n0, "n_end_table": target,
                     "n_end_recon": n_end, "events": len(evs), "censored": c,
                     "visible_ticks": ntk, "S_end_measured": st[-1][2] if st else s_rec,
                     "S_end_recon": s_end})
        ev_all += evs
        ce_all += cens
        n0, s_rec = n_end, s_end
    if n0 > 0:  # should not happen when the table ends at 0
        ce_all += [t_end] * n0
    rec = pd.DataFrame({"group": g,
                        "observed_time": np.r_[ev_all, ce_all],
                        "event": np.r_[np.ones(len(ev_all), int), np.zeros(len(ce_all), int)]})
    return rec, diag, steps


def main():
    os.makedirs(OUT, exist_ok=True)
    ex = extract(FIG)
    json.dump(ex, open(os.path.join(OUT, "extracted.json"), "w"), indent=1)
    recs, diags, used = [], {}, {}
    for g in ("A", "B"):
        rec, diag, steps = reconstruct(g, ex)
        assert len(rec) == manifest["groups"][g], (g, len(rec))
        recs.append(rec)
        diags[g] = diag
        used[g] = steps
    ipd = pd.concat(recs, ignore_index=True)
    ipd["observed_time"] = ipd["observed_time"].clip(lower=0).round(4)
    ipd = ipd.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    name = "sensitivity.csv" if ALT else "ipd.csv"
    tmp = os.path.join(OUT, name + ".tmp")
    ipd.to_csv(tmp, index=False)
    os.replace(tmp, os.path.join(OUT, name))
    if ALT:
        json.dump({"seed": SEED, "intervals": diags},
                  open(os.path.join(OUT, "sensitivity_diagnostics.json"), "w"), indent=1, default=float)
        return
    json.dump({"seed": SEED, "intervals": diags,
               "steps_used": {g: [dict(zip(["t", "S_before", "S_after", "gap_cols"], s))
                                  for s in used[g]] for g in used}},
              open(os.path.join(OUT, "reconstruction_diagnostics.json"), "w"), indent=1, default=float)
    for g in diags:
        print(g)
        for d in diags[g]:
            print("  ", d)


if __name__ == "__main__":
    main()
