# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster; no vector objects were available).
- `../input/manifest.json`: n = 100 per arm, time in months, seed 1523353319. The program sets the seed, but the algorithm is deterministic and does not use it. The manifest gives no arm-specific event totals, so there was nothing to check event counts against. Event counts come from the curve.
- The number-at-risk table was read from the figure by eye. A: 100, 66, 42, 28, 23, 5, 0; B: 100, 67, 44, 33, 25, 6, 0 at 0, 6, ..., 36 months. All values were clearly legible.

## Measurement (`code/extract.py`)
- Calibration comes from the labelled axis ticks: t = 0 at column 269.5 and t = 36 at column 1709.5 (40 px/month); S = 1 at row 179.5 and S = 0 at row 929.5 (750 px/unit). No global rescaling was applied. Both arms start at the S = 1 row, so no origin correction was needed.
- The curves are drawn as solid lines 4–5 px thick with no antialiasing. For each arm's exact colour, a column counts as "clean" when it contains a single 4–5 px run. The level is the centre row of that run. A level change of less than 3 px is treated as line-thickness jitter. A drop is placed at the midpoint of the non-clean columns between two levels.
- Occlusion: B is drawn over A. Where A is partly hidden, its level is inferred from the visible rows. Near the origin I inspected the columns by hand and hard-coded the result in `reconstruct.py` (`OVERRIDE_EARLY`):
  - A: 1.00→0.99 at t≈0.09 (hidden under B), then drops at about 0.54, 0.64 and 0.80.
  - B: a genuine drop 1.00→0.99 at t≈0.00, recorded at 0.01. This early drop is kept, not flattened.
- Censor ticks are 2 px wide and 16 px tall. A column is a tick candidate if the arm's colour extends at least 5 px beyond the line envelope on either side. One side is enough, because ticks that coincide with a vertical drop only stick out one way. Clusters 4 px wide or more are counted as 2 overlapping ticks. This is a lower bound on tick multiplicity: identical-time censorings produce identical marks.
- Measured values are saved in `extracted.json`: segments, steps and ticks with widths.

## Reconstruction (`code/reconstruct.py`, own implementation)
- The algorithm works interval by interval between risk-table times. It chooses the number censored, c_k, so that the reconstructed count at risk at the next table time matches the table exactly.
- Censorings go at the visible tick times.
- Events at each measured drop are d = round(n_risk · (1 − S_meas_after / S_rec_before)). Using the reconstructed KM value before the drop stops rounding errors from accumulating. Each drop's d is derived from n_risk; I did not assume d = 1.
- A drop spanning more than 5 px of columns with d > 1 is spread evenly over that span, because its sub-steps cannot be resolved. Other multi-event drops are recorded as tied times.
- Interval results (events / censored / visible tick count):

  | Interval (months) | A | B |
  |---|---|---|
  | 0–6 | 33/1/1 | 31/2/2 |
  | 6–12 | 22/2/2 | 17/6/6 |
  | 12–18 | 13/1/1 | 11/0/0 |
  | 18–24 | 5/0/0 | 7/1/1 |
  | 24–30 | 5/13/12 | 5/14/12 |
  | 30–36 | 0/5/5 | 2/4/4 |

  Totals: A has 78 events and 22 censored; B has 73 events and 27 censored.
- **Assumption (surplus censoring).** The risk table requires more censorings at 24–30 months than there are detected ticks: 1 extra in A and 2 in B. I assigned them as extra multiplicity at the widest visible ticks: A at 26.32, and B at 25.39 and 28.21. These are also tick clusters that sit on drops. No other allocation mechanism is identified by the figure.
- A's single censoring at 0–6 months is at a tick detected at 4.86, in a region where the curves overlap. That tick is less certain than the others.
- Follow-up ends at the last visible tick in each arm (A 35.52, B 34.91). No follow-up beyond the drawn curve was invented. The table's zero at 36 is met without putting anyone at t = 36.

## Checks (`code/checks.py` → `checks.json`)
- The checks reload `ipd.csv` and recompute the right-continuous KM step function; there is no interpolation.
- Survival comparisons use the midpoint of every clean segment of at least 0.1 month: 35 in A and 38 in B, covering the start and the tail. The largest absolute residual is 0.0017 in A and 0.0009 in B, and all pass at a tolerance of 0.01. That tolerance is ±1 px of reading error plus one-event discretisation.
- Fixed-time checks fall on overlapping or vertical regions at several early times; those are marked unavailable.
- Risk-table counts (observed_time ≥ t) match exactly at all 7 times in both arms.
- Arm sizes are 100/100, and event indicators are integers 0/1.
- Tail at 34.9 months: A reconstructed 0.1746 vs measured 0.1733. B ends at 34.95, so 34.9 lies inside its final tick cluster and is unavailable; at 34.5, B is 0.1356 vs 0.1347.
- `overlay.png` shows the reconstructed curves drawn over the figure.

## Sensitivity (`sensitivity.csv`, one alternative run)
- Alternative assumption: every tick cluster counts once, and any surplus censorings are spread evenly across the interval (Guyot convention) instead of being added at visible ticks.
- At the common supported horizon of 34.9 months:
  - A: S = 0.1746 (primary) vs 0.1782 (alternative); area under the curve 14.367 vs 14.394 months.
  - B: S = 0.1356 vs 0.1361; area 15.247 vs 15.249 months.
  - S at 12 and 24 months is identical under both allocations.
- This is one alternative, not a bound on reconstruction error. The primary was chosen on figure evidence (no ticks are drawn where the surplus would go under the even-spread rule), not on its effect estimates.

## Unresolved limitations
- Records are an approximation. Exact event times within merged multi-event drops (spans up to about 0.35 months) and censoring times within tick clusters cannot be recovered.
- Tick multiplicity is only partly identifiable. The three surplus censorings in the 24–30 month intervals are allocated by assumption.
- Where A is hidden under B (early months and overlapping stretches), A's drop times rely on partial pixels and hand inspection. Hidden A ticks cannot be ruled out, but the risk table constrains their number per interval.
- There were no event totals to reconcile against.

## Reproduction
Run from the work directory, which must contain `../input/`:
```
python3 output/code/reconstruct.py ../input/figure.png ../input/manifest.json output
python3 output/code/reconstruct.py ../input/figure.png ../input/manifest.json output alt
python3 output/code/checks.py output ../input/manifest.json ../input/figure.png
```
Final `ipd.csv` SHA-256: b75ae0596e14c3a261af58912fd2cab08011e2584f688e8c0fce5c06336c854e
