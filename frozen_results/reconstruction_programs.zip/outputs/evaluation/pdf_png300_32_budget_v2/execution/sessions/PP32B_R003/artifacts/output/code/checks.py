"""Verify the committed output/ipd.csv against the measured curve and risk table.

Usage: python3 output/code/checks.py [outdir] [manifest]
Reads outdir/ipd.csv, outdir/extracted.json (written by reconstruct.py) and,
if present, outdir/sensitivity.csv; writes outdir/checks.json.
"""
import hashlib
import json
import os
import sys
import numpy as np
import pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
MAN = sys.argv[2] if len(sys.argv) > 2 else "../input/manifest.json"
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 66, 42, 28, 23, 5, 0], "B": [100, 67, 44, 33, 25, 6, 0]}
CHECK_T = [0.3, 1.0, 2.0, 3.5, 5.0, 6.5, 8.0, 9.0, 10.8, 12.0, 14.0, 16.0,
           18.0, 20.0, 22.0, 24.0, 26.0, 28.0, 29.0, 31.0, 33.0, 34.5, 35.4]
# Tolerance: pixel reading +/-1 px (0.0013) and line-thickness jitter (0.0007)
# plus the integer-event discretisation of a KM estimator at n_risk>=5 when the
# reconstructed and drawn curves differ by at most one event near a drop.
# 0.01 = ~7.5 px; larger residuals are flagged fail.
TOL = 0.01


def km_step(df):
    """Right-continuous KM: returns function S(t)."""
    t = df.observed_time.values
    e = df.event.values
    ut = np.unique(t[e == 1])
    S, s = [], 1.0
    for u in ut:
        n = (t >= u).sum()
        d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n
        S.append(s)
    ut, S = np.array(ut), np.array(S)

    def f(x):
        i = np.searchsorted(ut, x, side="right") - 1
        return 1.0 if i < 0 else float(S[i])
    return f, ut, S


def measured_at(segs, t):
    for s in segs:
        if s["t0"] + 0.03 <= t <= s["t1"] - 0.03:
            return s["S"]
    return None


def rmst(f, ut, tau):
    grid = np.r_[0, ut[ut < tau], tau]
    return float(sum(f(a) * (b - a) for a, b in zip(grid[:-1], grid[1:])))


def main():
    path = os.path.join(OUT, "ipd.csv")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    ipd = pd.read_csv(path)
    ex = json.load(open(os.path.join(OUT, "extracted.json")))
    man = json.load(open(MAN))
    res = {"csv": "ipd.csv", "sha256": sha, "tolerance_S": TOL,
           "tolerance_note": "pixel +/-1 px (0.0013) plus integer-event discretisation; "
                             "measured values taken only inside clean horizontal segments "
                             ">=0.03 mo from a vertical; occluded/drop locations marked unavailable",
           "structure": {}, "groups": {}}
    res["structure"] = {
        "columns_ok": list(ipd.columns) == ["group", "observed_time", "event"],
        "event_integer_01": bool(ipd.event.isin([0, 1]).all()),
        "times_finite_nonneg": bool(np.isfinite(ipd.observed_time).all() and (ipd.observed_time >= 0).all()),
        "event_totals_supplied": "unavailable (manifest has no event totals)",
    }
    for g in ("A", "B"):
        d = ipd[ipd.group == g]
        f, ut, S = km_step(d)
        gr = {"n": int(len(d)), "n_manifest": man["groups"][g],
              "n_status": "pass" if len(d) == man["groups"][g] else "fail",
              "events": int(d.event.sum()), "censored": int((d.event == 0).sum()),
              "max_time": float(d.observed_time.max()),
              "measured_curve_end": ex[g]["t_last"]}
        rows = []
        for t in CHECK_T:
            m = measured_at(ex[g]["segments"], t)
            r = f(t)
            if m is None:
                rows.append({"t": t, "measured": None, "recon": round(r, 4), "status": "unavailable"})
            else:
                rows.append({"t": t, "measured": round(m, 4), "recon": round(r, 4),
                             "residual": round(r - m, 4),
                             "status": "pass" if abs(r - m) <= TOL else "fail"})
        gr["survival_checks"] = rows
        # all clean segments: max abs residual at segment midpoints
        mids = [(0.5 * (s["t0"] + s["t1"]), s["S"]) for s in ex[g]["segments"]
                if s["t1"] - s["t0"] >= 0.1]
        resid = [f(t) - m for t, m in mids]
        gr["segment_midpoint_checks"] = [
            [round(t, 3), round(m, 4), round(f(t), 4), round(f(t) - m, 4),
             "pass" if abs(f(t) - m) <= TOL else "fail"] for t, m in mids]
        gr["segment_midpoint_checks_columns"] = ["t", "measured", "recon", "residual", "status"]
        gr["segment_midpoint_residuals"] = {"n_segments": len(mids),
                                            "max_abs": round(float(np.max(np.abs(resid))), 4),
                                            "mean_abs": round(float(np.mean(np.abs(resid))), 4)}
        rk = []
        for t, nt in zip(RISK_T, RISK[g]):
            c = int((d.observed_time >= t).sum())
            rk.append({"t": t, "table": nt, "recon": c, "residual": c - nt,
                       "status": "pass" if c == nt else "fail"})
        gr["risk_table_checks"] = rk
        tail_t = min(ex["A"]["t_last"], ex["B"]["t_last"]) - 0.05
        gr["tail"] = {"t": round(tail_t, 3), "measured": round(measured_at(ex[g]["segments"], tail_t) or float("nan"), 4),
                      "recon": round(f(tail_t), 4)}
        res["groups"][g] = gr
    sp = os.path.join(OUT, "sensitivity.csv")
    if os.path.exists(sp):
        sen = pd.read_csv(sp)
        tau = round(min(ex["A"]["t_last"], ex["B"]["t_last"]) - 0.05, 2)
        cmp = {"horizon_months": tau, "assumption": "tick clusters counted once; surplus censorings "
               "spread evenly over each risk interval instead of as multiplicity at visible ticks"}
        for g in ("A", "B"):
            fp, up, _ = km_step(ipd[ipd.group == g])
            fs, us, _ = km_step(sen[sen.group == g])
            cmp[g] = {"S_primary": round(fp(tau), 4), "S_sensitivity": round(fs(tau), 4),
                      "S_at_12_primary": round(fp(12), 4), "S_at_12_sensitivity": round(fs(12), 4),
                      "S_at_24_primary": round(fp(24), 4), "S_at_24_sensitivity": round(fs(24), 4),
                      "area_primary": round(rmst(fp, up, tau), 3),
                      "area_sensitivity": round(rmst(fs, us, tau), 3)}
        res["sensitivity_comparison"] = cmp
    else:
        res["sensitivity_comparison"] = "not run"
    try:  # visual overlay of the reconstructed KM on the figure
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from PIL import Image
        fig_path = sys.argv[3] if len(sys.argv) > 3 else "../input/figure.png"
        im = np.array(Image.open(fig_path).convert("RGB"))
        fig, ax = plt.subplots(figsize=(18, 13.5), dpi=100)
        ax.imshow(im)
        for g, col in (("A", "k"), ("B", "m")):
            f, ut, S = km_step(ipd[ipd.group == g])
            xs = np.r_[0, np.repeat(ut, 2), ipd[ipd.group == g].observed_time.max()]
            ys = np.r_[1, 1, np.repeat(S, 2)[:-1], S[-1]]
            ax.plot(269.5 + 40 * xs, 929.5 - 750 * ys, col, lw=0.8)
        ax.axis("off")
        fig.savefig(os.path.join(OUT, "overlay.png"), bbox_inches="tight")
    except Exception as exc:  # overlay is optional
        res["overlay"] = "failed: %s" % exc
    tmp = os.path.join(OUT, "checks.json.tmp")
    json.dump(res, open(tmp, "w"), indent=1)
    os.replace(tmp, os.path.join(OUT, "checks.json"))
    for g in ("A", "B"):
        gr = res["groups"][g]
        print(g, gr["n"], gr["events"], gr["censored"], gr["segment_midpoint_residuals"])
        print("  ", [(r["t"], r.get("residual"), r["status"]) for r in gr["survival_checks"]])
        print("  ", [(r["t"], r["recon"], r["table"]) for r in gr["risk_table_checks"]], gr["tail"])
    print(res["structure"], res["sensitivity_comparison"])


if __name__ == "__main__":
    main()
