"""Pixel extraction of KM step curves and censor ticks from the raster figure.

Calibration (from labelled axis anchors, measured in this image):
  x tick marks: t=0 at column 269.5, t=36 at column 1709.5  -> 40 px / month
  y tick marks: S=1.0 at row 179.5, S=0.0 at row 929.5      -> 750 px / unit
Curve lines are drawn 4 px thick without antialiasing; censor ticks are
2 px wide, 16 px tall vertical marks centred on the line. Group B (orange)
is drawn on top of Group A (blue).
"""
import json
import sys
import numpy as np
from PIL import Image

X0, X36 = 269.5, 1709.5
Y1, Y0 = 179.5, 929.5
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
ROW_LO, ROW_HI = 150, 935


def t_of(x):
    return (x - X0) / (X36 - X0) * 36.0


def s_of(yc):
    # yc is a line-centre row in crop coordinates
    return (Y0 - (yc + ROW_LO)) / (Y0 - Y1)


def runs(col):
    idx = np.where(col)[0]
    if len(idx) == 0:
        return []
    out, st = [], idx[0]
    for a, b in zip(idx[:-1], idx[1:]):
        if b != a + 1:
            out.append((st, a))
            st = b
    out.append((st, idx[-1]))
    return out


def extract(path):
    im = np.array(Image.open(path).convert("RGB")).astype(int)
    masks = {g: (np.abs(im - c).sum(2) < 150) for g, c in COL.items()}
    res = {}
    for g in ("A", "B"):
        m = masks[g][ROW_LO:ROW_HI]
        occ = masks["B"][ROW_LO:ROW_HI] if g == "A" else np.zeros_like(m)
        xs = np.where(m.any(0))[0]
        xmin, xmax = int(xs.min()), int(xs.max())
        level = {}  # column -> line top row (clean columns only)
        for x in range(xmin, xmax + 1):
            rr = runs(m[:, x])
            if len(rr) != 1:
                continue
            a, b = rr[0]
            L = b - a + 1
            if L in (4, 5):
                level[x] = 0.5 * (a + b)  # line centre (crop rows)
            elif L < 4 and g == "A":
                # partially hidden under orange: extend into occluder
                if a > 0 and occ[a - 1, x]:
                    level[x] = b - 1.5
                elif b + 1 < m.shape[0] and occ[b + 1, x]:
                    level[x] = a + 1.5
        cx = sorted(level)
        # horizontal segments and drops
        segs = []  # (x_start, x_end, top)
        for x in cx:
            if segs and level[x] == segs[-1][2]:
                segs[-1][1] = x
            else:
                segs.append([x, x, level[x]])
        # merge tiny segments (<=1 col) that are artefacts only if same level
        steps = []
        for i in range(1, len(segs)):
            p, q = segs[i - 1], segs[i]
            xe = 0.5 * (p[1] + q[0])  # event column: middle of the gap
            steps.append({
                "x": xe, "t": t_of(xe),
                "gap_cols": int(q[0] - p[1] - 1),
                "y_before": float(p[2] + ROW_LO), "y_after": float(q[2] + ROW_LO),
                "S_before": s_of(p[2]), "S_after": s_of(q[2]),
            })
        # censor ticks: mask extends >=5 px above and below the local line
        tickcols = []
        for x in range(xmin, xmax + 1):
            left = [c for c in cx if c <= x]
            right = [c for c in cx if c >= x]
            if not left and not right:
                continue
            tops = [level[left[-1]]] if left else []
            tops += [level[right[0]]] if right else []
            hi, lo = int(min(tops) - 1.5), int(max(tops) + 1.5)
            if not left:  # before the first clean column the curve starts at S=1
                hi = min(hi, int(Y1 - ROW_LO - 1.5))
            col = m[:, x]
            # envelope = line rows between the flanking clean levels; a tick
            # (16 px tall) extends >=5 px beyond it on at least one side (only one
            # side when the tick coincides with a vertical drop segment)
            if col[max(hi - 7, 0):hi - 4].any() or col[lo + 5:lo + 8].any():
                tickcols.append(x)
        ticks = []
        for x in tickcols:
            if ticks and x == ticks[-1][1] + 1:
                ticks[-1][1] = x
            else:
                ticks.append([x, x])
        tk = []
        ticks = [tb for tb in ticks if tb[1] - tb[0] + 1 >= 2]  # ticks are 2 px wide
        for a, b in ticks:
            xc = 0.5 * (a + b)
            left = [c for c in cx if c <= xc]
            top = level[left[-1]] if left else level[cx[0]]
            w = int(b - a + 1)
            # a single 2-px tick covers 2-3 columns; wider clusters are taken as
            # overlapping ticks (visible multiplicity lower bound)
            tk.append({"x": xc, "t": t_of(xc), "width": w,
                       "mult": max(1, int(round((w - 1) / 2 + 1e-9))), "S": s_of(top)})
        res[g] = {
            "xmin": xmin, "xmax": xmax, "t_last": t_of(xmax - 0.5),
            "S_start": s_of(segs[0][2]), "x_first_seg": int(segs[0][0]),
            "segments": [{"t0": t_of(a), "t1": t_of(b), "S": s_of(c)}
                         for a, b, c in segs],
            "steps": steps, "ticks": tk,
        }
    return res


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
    r = extract(path)
    json.dump(r, open(sys.argv[2] if len(sys.argv) > 2 else "output/extracted.json", "w"), indent=1)
    for g in r:
        print(g, "start S", round(r[g]["S_start"], 4), "first seg col", r[g]["x_first_seg"],
              "t_last", round(r[g]["t_last"], 3))
        for s in r[g]["steps"]:
            print("  step t=%.3f gap=%d S %.4f -> %.4f" % (s["t"], s["gap_cols"], s["S_before"], s["S_after"]))
        for k in r[g]["ticks"]:
            print("  tick t=%.3f w=%d m=%d S=%.4f" % (k["t"], k["width"], k["mult"], k["S"]))
