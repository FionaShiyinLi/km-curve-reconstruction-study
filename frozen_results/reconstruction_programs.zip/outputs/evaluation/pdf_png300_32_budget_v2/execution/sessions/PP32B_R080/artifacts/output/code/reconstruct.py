"""KM -> IPD reconstruction from vector PDF geometry (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]
Defaults: ../input and ./output relative to the work directory."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else '../input'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'output'
man = json.load(open(os.path.join(IN, 'manifest.json')))
SEED = man['code_seed']; rng = np.random.default_rng(SEED)  # no randomness used; seed recorded
pg = pdfplumber.open(os.path.join(IN, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks ----
words = pg.extract_words()
xt = {float(w['text']): None for w in words if w['top'] > 229 and w['top'] < 231}
axl = [l for l in pg.lines if l.get('stroking_color') == (0.0, 0.0, 0.0)]
xticks = sorted(round(l['x0'], 3) for l in axl if abs(l['x0']-l['x1']) < 1e-6 and l['bottom'] > 224)
yticks = sorted(round(l['top'], 3) for l in axl if abs(l['top']-l['bottom']) < 1e-6 and l['x0'] < 62)
tlab = [0, 6, 12, 18, 24, 30, 36]; slab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax_, bx_ = np.polyfit(xticks, tlab, 1); ay_, by_ = np.polyfit(yticks, slab, 1)
resx = np.max(np.abs(np.polyval([ax_, bx_], xticks) - tlab)); resy = np.max(np.abs(np.polyval([ay_, by_], yticks) - slab))
T = lambda x: ax_*x + bx_
S = lambda top: ay_*top + by_
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
# legend check: colour sample line located left of "Group A"/"Group B" text
risk = {}
for g in 'AB':
    row = [w for w in words if w['top'] > (283 if g == 'A' else 297) and w['top'] < (285 if g == 'A' else 299)]
    risk[g] = [int(w['text']) for w in sorted(row, key=lambda w: w['x0']) if w['text'].isdigit()]
risk_t = tlab

obs = {'calibration': {'t_per_pt': ax_, 't0_pt': -bx_/ax_, 'S_per_pt': ay_, 'max_resid_t': resx, 'max_resid_S': resy},
       'risk_table': {'times': risk_t, **risk}}
recs = []; extracted = []
for g in 'AB':
    N = man['groups'][g]
    cur = [c for c in pg.curves if c.get('stroking_color') == COL[g]][0]
    pts = [(T(x), S(y)) for x, y in cur['pts']]
    # vertices of a step path: horizontal then vertical segments; collect drops
    drops = []  # (time, S_before, S_after)
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1-t0) < 1e-6 and s1 < s0 - 1e-9:
            drops.append((t0, s0, s1))
    t_end = pts[-1][0]; s_start = pts[0][1]
    ticks = sorted(T(l['x0']) for l in pg.lines if l.get('stroking_color') == COL[g]
                   and abs(l['x0']-l['x1']) < 1e-6 and abs(l['bottom']-l['top']-4) < 0.1)
    for d in drops: extracted.append({'group': g, 'kind': 'drop', 'time': d[0], 'S_before': d[1], 'S_after': d[2]})
    for c in ticks: extracted.append({'group': g, 'kind': 'censor_tick', 'time': c})
    extracted.append({'group': g, 'kind': 'curve_end', 'time': t_end, 'S_before': pts[-1][1]})
    # ---- sequential KM inversion ----
    n = N; ci = 0; rows = []; dlog = []
    for (t, sb, sa) in drops:
        while ci < len(ticks) and ticks[ci] < t - 1e-9:   # censored strictly before event time
            rows.append((ticks[ci], 0)); n -= 1; ci += 1
        draw = n * (1 - sa/sb); d = int(round(draw))
        dlog.append({'time': t, 'n_risk': n, 'd_raw': draw, 'd': d})
        rows += [(t, 1)] * d; n -= d
    while ci < len(ticks):
        rows.append((ticks[ci], 0)); n -= 1; ci += 1
    extra = n  # participants not accounted for by visible ticks -> censored at curve end (assumption)
    rows += [(t_end, 0)] * max(extra, 0)
    obs[g] = {'n_drops': len(drops), 'n_ticks': len(ticks), 'events': sum(r[1] for r in rows),
              'unticked_remaining_at_end': extra, 'curve_end_time': t_end, 'S_start': s_start,
              'max_abs_d_rounding': max(abs(x['d_raw']-x['d']) for x in dlog), 'drop_log': dlog}
    assert len(rows) == N, (g, len(rows))
    recs += [(g, t, e) for t, e in rows]

df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].round(4).clip(lower=0)
os.makedirs(OUT, exist_ok=True)
pd.DataFrame(extracted).to_csv(os.path.join(OUT, 'extracted_geometry.csv'), index=False)
json.dump(obs, open(os.path.join(OUT, 'extraction_summary.json'), 'w'), indent=1, default=float)
tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
print(json.dumps({k: (v if k in 'AB' and False else v) for k, v in obs.items() if k != 'A' and k != 'B'}, default=float))
for g in 'AB': print(g, {k: v for k, v in obs[g].items() if k != 'drop_log'})
