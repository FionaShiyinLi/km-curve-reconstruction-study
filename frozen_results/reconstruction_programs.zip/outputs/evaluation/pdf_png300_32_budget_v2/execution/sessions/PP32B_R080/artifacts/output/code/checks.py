"""Reload committed output/ipd.csv, recompute right-continuous KM, compare with PDF geometry and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
p = os.path.join(OUT, 'ipd.csv'); sha = hashlib.sha256(open(p, 'rb').read()).hexdigest()
df = pd.read_csv(p); geo = pd.read_csv(os.path.join(OUT, 'extracted_geometry.csv'))
summ = json.load(open(os.path.join(OUT, 'extraction_summary.json')))
def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum(); s *= 1 - e/n; out.append((t, s))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for tt, v in steps:
        if tt <= t: s = v
        else: break
    return s
def meas_at(g, t):  # measured step curve from PDF vertices (right-continuous)
    dr = geo[(geo.group == g) & (geo.kind == 'drop')].sort_values('time'); s = 1.0
    for _, r in dr.iterrows():
        if r.time <= t + 1e-9: s = r.S_after
    return s
TOL = 0.0005  # vector coordinates are exact to ~1e-5 in S; tolerance covers 4-dp time rounding in CSV
chk = {'csv_sha256': sha, 'tolerance_S': TOL, 'tolerance_note': 'PDF vector path coordinates; calibration residual <1e-13; tolerance allows 4-decimal time rounding', 'groups': {}}
allpass = True
for g in 'AB':
    d = df[df.group == g]; st = km(d); G = {}
    G['n'] = {'expected': 100, 'reconstructed': int(len(d)), 'status': 'pass' if len(d) == 100 else 'fail'}
    G['event_indicator_integer_01'] = bool(d.event.isin([0, 1]).all())
    G['events_total'] = {'supplied': 'unavailable (manifest has no event totals)', 'reconstructed': int(d.event.sum())}
    tend = float(geo[(geo.group == g) & (geo.kind == 'curve_end')].time.iloc[0])
    times = [0, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, tend]
    rows = []
    for t in times:
        m = meas_at(g, t); r = S_at(st, t); ok = abs(m - r) <= TOL; allpass &= ok
        rows.append({'t': round(t, 4), 'measured': round(m, 6), 'reconstructed': round(r, 6), 'resid': round(r - m, 6), 'status': 'pass' if ok else 'fail'})
    # also at every drop time just before and after
    dr = geo[(geo.group == g) & (geo.kind == 'drop')]
    maxres = max(max(abs(S_at(st, t + 1e-4) - a), abs(S_at(st, t - 1e-3) - b)) for t, b, a in zip(dr.time, dr.S_before, dr.S_after))
    G['survival_checks'] = rows; G['max_abs_resid_all_drop_neighbourhoods'] = maxres
    rt = summ['risk_table']; rr = []
    for t, n in zip(rt['times'], rt[g]):
        c = int((d.observed_time >= t).sum()); ok = c == n; allpass &= ok
        rr.append({'t': t, 'displayed': n, 'reconstructed': c, 'resid': c - n, 'status': 'pass' if ok else 'fail'})
    G['risk_table'] = rr
    G['tail'] = {'last_obs_time': float(d.observed_time.max()), 'curve_end_time': tend, 'S_tail_reconstructed': st[-1][1]}
    # RMST to common horizon for reference
    chk['groups'][g] = G
chk['overall'] = 'pass' if allpass else 'fail'
json.dump(chk, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1, default=float)
print(chk['overall'], sha)
for g in 'AB': print(g, chk['groups'][g]['risk_table'], chk['groups'][g]['max_abs_resid_all_drop_neighbourhoods'], chk['groups'][g]['tail'])
