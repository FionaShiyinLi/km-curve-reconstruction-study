# Reconstruction assumptions and method

**Inputs:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (A = 100, B = 100, months, seed 281773966). No other information was used. The code is deterministic. The seed is read and recorded but not used.

**Measurement.** The PDF contains the KM curves as vector step paths (blue = Group A, orange = Group B; colors matched to the legend sample lines) and the censor marks as separate 4-pt vertical tick segments in the same colors. There was no raster digitization. Calibration comes from the labeled axis tick segments: t = (x − 64.8)/9.6 months and S = (223.2 − y)/180. The linear-fit residual is below 1e-13 at all 7 x-ticks and all 6 y-ticks. No global or origin correction was applied. Both curves start at exactly S = 1. The genuine early drops (A at 0.023 mo, B at 0.002 mo) are kept. The extracted vertices, drops and tick times are in `extracted_geometry.csv` and `extraction_summary.json`.

**Algorithm** (`code/reconstruct.py`). The script walks each path in time order. Ticks strictly before a drop time are removed from the risk set as censorings. At a drop, it computes d = n_risk·(1 − S_after/S_before) and rounds to the nearest integer. Ticks at or after a drop time are treated as censored after the events at that time. Anyone still at risk after the last tick would have been censored at the curve end. That count was 0 in both arms, so no records were created this way.

**Event multiplicity.** d = 1 was not assumed. It is the value computed at every drop: raw d is between 0.99995 and 1.00005 for all 74 (A) and 69 (B) drops. The resulting counts are 74 events and 26 censorings in A, and 69 events and 31 censorings in B.

**Censoring.** Censor times are the x-positions of the tick segments. Each tick is a separate PDF object, so coincident ticks would still appear as separate objects. The tick counts plus event counts equal N exactly in both arms, with no residual. This is evidence that no censor marks are hidden or missing.

**Risk table.** The printed numbers at risk (0–36 months) were **not** used in the reconstruction. They serve only as a validation check. The reconstructed counts of observed_time ≥ t match every displayed value in both arms, including 0 at 36 months.

**Event totals.** The manifest contains no arm-specific event totals, so that check is marked unavailable.

**Verification** (`code/checks.py`, `checks.json`). The script reloads the committed CSV and recomputes the right-continuous KM. It then compares that curve with the PDF step curve at 17 times per arm, including the tail and the curve end, and at every drop neighborhood (max |residual| ≈ 3e-7). It also checks the risk table, the arm sizes and whether event indicators are integer 0/1. All checks pass.

**Limitations.**
- Times are recovered to the precision of the PDF coordinates, rounded to 4 decimals in the CSV.
- Ties at identical plotted times cannot be distinguished from very close times beyond that precision.
- If an event and a censoring share the same plotted time, the censoring is ordered after the event, which is the usual KM convention.
- Follow-up beyond each arm's last tick (A: 35.67 mo, B: 35.98 mo) is not represented, and none is invented.

**Sensitivity analysis: not run.** The geometry, tick counts and risk table together leave no materially different event/censor allocation, so `sensitivity.csv` was not produced. This does not claim zero reconstruction error. Precision is limited to the figure's coordinate resolution.
