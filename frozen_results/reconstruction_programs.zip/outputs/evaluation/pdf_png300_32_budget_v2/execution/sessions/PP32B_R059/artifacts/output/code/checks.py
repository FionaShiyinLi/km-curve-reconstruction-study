"""Reload committed ipd.csv, recompute right-continuous KM, compare with vector-measured curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
csv = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); meas = json.load(open(os.path.join(OUT, 'measurements.json')))
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 64, 40, 28, 21, 6, 0], 'B': [100, 73, 53, 40, 29, 16, 0]}
TOL = 1e-3  # vector coordinates are exact to ~1e-5 pt; 1e-3 in S (0.18 pt) allows rounding of times to 1e-4

def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for tt, v in steps:
        if tt <= t + 1e-9: s = v
        else: break
    return s
def meas_at(verts, t):  # measured step curve: level of the horizontal segment covering t (right-continuous)
    s = verts[0][1]
    for (t0, s0), (t1, s1) in zip(verts[:-1], verts[1:]):
        if t0 <= t + 1e-9 and t1 == t0: s = min(s0, s1) if t0 <= t + 1e-9 else s
        elif t0 <= t + 1e-9: s = s0
    return s
res = {'csv_sha256': sha, 'tolerance_S': TOL, 'arms': {}}
for g in 'AB':
    d = df[df.group == g]; st = km(d); m = meas[g]; verts = m['vertices']
    drop_t = [x[0] for x in m['drops']]
    grid = sorted(set([0.0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, m['end']]
                      + [t + 1e-3 for t in drop_t[::8]] + [drop_t[-1] + 1e-3]))
    grid = [t for t in grid if t <= m['end'] + 1e-9]
    cmp = []
    for t in grid:
        mv, rv = meas_at(verts, t), S_at(st, t)
        cmp.append(dict(t=round(t, 4), measured=round(mv, 5), reconstructed=round(rv, 5),
                        residual=round(rv - mv, 6), status='pass' if abs(rv - mv) <= TOL else 'fail'))
    # all drop levels
    maxres = max(abs(S_at(st, t + 1e-4) - s1) for t, s0, s1 in m['drops'])
    rk = []
    for t, r in zip(RISK_T, RISK[g]):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=r, reconstructed=c, residual=c - r, status='pass' if c == r else 'fail'))
    res['arms'][g] = dict(n=int(len(d)), n_expected=100, events=int(d.event.sum()),
                          event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
                          supplied_event_total='unavailable (not in manifest)',
                          n_drops=len(m['drops']), max_abs_residual_all_drop_levels=round(maxres, 7),
                          curve_comparisons=cmp, risk_table=rk,
                          tail=dict(last_event=max(d.observed_time[d.event == 1]), max_time=float(d.observed_time.max()),
                                    curve_end=m['end'], S_tail_meas=round(verts[-1][1], 5), S_tail_recon=round(st[-1][1], 5)))
    print(g, len(d), d.event.sum(), 'maxres', maxres, 'fails', sum(c['status'] == 'fail' for c in cmp), [ (r['t'], r['displayed'], r['reconstructed']) for r in rk])
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
