"""KM -> IPD reconstruction from the vector objects of the assigned PDF figure.
Usage: python reconstruct.py [path/to/figure.pdf] [output_dir]
Deterministic; seed recorded for completeness (no randomness is used)."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 1653156847
np.random.seed(SEED)
HERE = os.path.dirname(os.path.abspath(__file__))
PDF = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '../../../input/figure.pdf')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..')
N = {'A': 100, 'B': 100}
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 64, 40, 28, 21, 6, 0], 'B': [100, 73, 53, 40, 29, 16, 0]}

pg = pdfplumber.open(PDF).pages[0]
# ---- axis calibration from labelled tick marks (x ticks 0..36, y ticks 0..1)
xt = sorted({round(l['x0'], 3) for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)
             and abs(l['x0'] - l['x1']) < 1e-6 and l['bottom'] - l['top'] < 3.5})
yt = sorted({round(l['top'], 3) for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)
             and abs(l['top'] - l['bottom']) < 1e-6 and l['x1'] - l['x0'] < 3.5})
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
ax_x = np.polyfit(xt, [0, 6, 12, 18, 24, 30, 36], 1)
ax_y = np.polyfit(yt, [1.0, 0.8, 0.6, 0.4, 0.2, 0.0], 1)   # top-based coords
tx = lambda x: np.polyval(ax_x, x)
sy = lambda y: np.polyval(ax_y, y)

def same(c, ref): return c is not None and len(c) == 3 and max(abs(a - b) for a, b in zip(c, ref)) < 1e-4

meas, recs, diag = {}, [], {}
for g in 'AB':
    cv = [c for c in pg.curves if same(c['stroking_color'], COL[g])]
    assert len(cv) == 1
    pts = [(tx(x), sy(y)) for x, y in cv[0]['pts']]
    # drops: vertical segments going down
    drops = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-9 and s1 < s0 - 1e-9:
            drops.append([t0, s0, s1])
    # merge consecutive vertical segments at same time
    md = []
    for d in drops:
        if md and abs(md[-1][0] - d[0]) < 1e-9 and abs(md[-1][2] - d[1]) < 1e-9: md[-1][2] = d[2]
        else: md.append(d)
    t_end = pts[-1][0]
    ticks = sorted(tx((l['x0'] + l['x1']) / 2) for l in pg.lines
                   if same(l['stroking_color'], COL[g]) and abs(l['linewidth'] - 0.65) < 0.01
                   and abs(l['bottom'] - l['top'] - 4) < 0.1)
    meas[g] = {'vertices': pts, 'drops': md, 'ticks': ticks, 'end': t_end}
    # ---- forward walk.  At each drop, infer (n_risk, d) from the exact ratio.
    n = N[g]; events = []; cens = []; hidden = []; rows = []
    tick_i = 0; prev_t = 0.0
    for t, s0, s1 in md:
        # visible censor ticks strictly before this drop (ties at same time: events first)
        while tick_i < len(ticks) and ticks[tick_i] < t - 1e-6:
            cens.append(ticks[tick_i]); n -= 1; tick_i += 1
        q = 1 - s1 / s0
        # accept d = q*n when it is (near-)integer under the walked risk set;
        # otherwise search the smallest d whose implied n_hat=d/q is near-integer and <= n
        dn = q * n
        if abs(dn - round(dn)) < 0.05 and round(dn) >= 1:
            d, nh = int(round(dn)), n
        else:
            cand = [(abs(d_ / q - round(d_ / q)), d_, int(round(d_ / q))) for d_ in range(1, 15) if d_ / q <= n + 0.5]
            _, d, nh = min(cand)
        if nh < n:   # hidden censorings needed between previous event and this drop
            k = n - nh
            lo = max(prev_t, cens[-1] if cens else 0.0)
            ht = list(np.linspace(prev_t, t, k + 2)[1:-1])
            hidden += ht; cens += ht; n = nh
        rows.append(dict(t=t, S_before=s0, S_after=s1, n_risk=n, d=d, d_exact=q * n,
                         n_hat=d / q))
        events += [t] * d; n -= d; prev_t = t
    rest = ticks[tick_i:]
    cens += rest; n -= len(rest)
    extra_tail = n
    if n > 0: cens += [t_end] * n; n = 0   # unticked remainder placed at curve end
    diag[g] = dict(steps=rows, hidden=hidden, extra_tail=extra_tail, n_ticks=len(ticks),
                   n_events=len(events))
    recs += [(g, t, 1) for t in events] + [(g, t, 0) for t in cens]

df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df.observed_time.clip(lower=0).round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
assert (df.groupby('group').size() == pd.Series(N)).all()
os.makedirs(OUT, exist_ok=True)
tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
# save measurements
json.dump({g: {k: v for k, v in m.items()} for g, m in meas.items()} | {'axis': {'x_ticks_pt': xt, 'y_ticks_pt': yt}},
          open(os.path.join(OUT, 'measurements.json'), 'w'), indent=1)
json.dump(diag, open(os.path.join(OUT, 'walk_diagnostics.json'), 'w'), indent=1)
for g in 'AB':
    r = pd.DataFrame(diag[g]['steps'])
    print(g, 'events', diag[g]['n_events'], 'ticks', diag[g]['n_ticks'], 'hidden', len(diag[g]['hidden']),
          'extra_tail', diag[g]['extra_tail'], 'max|d_exact-d|', (r.d_exact - r.d).abs().max().round(4),
          'multi-d', r[r.d > 1][['t', 'd', 'n_risk']].round(3).values.tolist())
