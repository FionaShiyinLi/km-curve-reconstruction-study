# Reconstruction assumptions and method

**Inputs used.** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, months, seed 1653156847). The manifest has no arm-specific event totals, so there is no supplied-total check (marked unavailable in `checks.json`). The number-at-risk table (0, 6, …, 36 months) was read from the PDF text layer: A 100/64/40/28/21/6/0; B 100/73/53/40/29/16/0.

**Measurement.** The PDF holds each arm as one vector step path (identified by stroke colour) and each censor mark as a 4-pt vertical line segment. I calibrated time and survival by linear fits to the labelled axis ticks: x ticks at 0–36 months (9.6 pt/month) and y ticks at 0–1 (180 pt per unit). The fit is exact. I applied no rescaling, no origin correction and no running minimum. Both paths start exactly at S = 1 at t = 0. The early drops are real and are kept. Vertices, drops, censor-tick times and axis anchors are saved in `measurements.json`.

**Algorithm** (`code/reconstruct.py`, deterministic, so the seed is set but not used):
1. Walk forward from n = 100 through the drops in time order.
2. Before each drop, remove the censor ticks that fall strictly before it. A tick at the same time as an event is kept in the risk set.
3. At each drop, compute q = 1 − S_after/S_before and set d = q·n.
4. If d was not an integer, the code would search for hidden censorings (n̂ = d/q < n).

- **Every step gave an integer d.** Across all 79 (A) and 72 (B) drops, q·n was an integer within about 1e-6, and in every case d = 1.
- **d = 1 is determined, not assumed.** Any d > 1 would need a risk set larger than the one walked from the known n and the visible ticks, and that is infeasible.
- **The tick count balances.** Each visible tick is one censoring: 21 in A, 28 in B. Events plus ticks equal 100 in each arm, so no hidden or unticked censorings were needed.
- **Censoring times come straight from the ticks.** Each censoring time is its tick's x-position. No censoring distribution was modelled.
- **Follow-up ends at the last tick.** Each arm's last record is the censor tick at the end of its curve (A 35.67 months, B 34.71). No follow-up was added beyond that.

**Checks** (`code/checks.py` → `checks.json`). The script reloads the committed CSV and recomputes the right-continuous Kaplan–Meier (KM) curve.
- **Curve.** It matches every measured drop level to within 3e-7 and passes at the grid and tail times, with a tolerance of 1e-3 in S. That tolerance covers rounding the times to 1e-4 months; the vector precision itself is much finer.
- **Risk table.** Counting records with observed_time ≥ t reproduces all 14 displayed counts exactly, including 0 at 36 months.
- **Arms.** Each arm has 100 records, and every event indicator is an integer 0 or 1.

**Limitations and unresolved issues.**
- **Overlapping ticks.** Two ticks at exactly the same position would be stacked vector objects. They would still be counted, because objects are counted, not pixels.
- **Tick–event ties.** If a tick lay exactly at an event time, its order relative to the event could not be seen. The events-first convention was used.
- **What the data support.** The exact KM ratios and the risk table are consistent with the recovered records, but only the displayed curves and marks constrain them. Times are known only to plotting precision (about 1e-4 months after rounding).
- **No sensitivity analysis.** The alternative allocation was not run: no material ambiguity remained, since every drop and risk count was reproduced without free choices, so no `sensitivity.csv` was produced.
