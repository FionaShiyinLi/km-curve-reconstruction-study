"""Reconstruct participant-level records from the vector KM figure.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: ../input and ./output relative to the current working directory.
Only pdfplumber / numpy / pandas are used; no KM-to-IPD package.
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 1230746963  # supplied code seed; the algorithm below is deterministic
np.random.seed(SEED)

inp = sys.argv[1] if len(sys.argv) > 1 else "../input"
out = sys.argv[2] if len(sys.argv) > 2 else "output"
os.makedirs(out, exist_ok=True)
man = json.load(open(os.path.join(inp, "manifest.json")))
pg = pdfplumber.open(os.path.join(inp, "figure.pdf")).pages[0]

# ---------- calibration from labelled axis ticks ----------
# x ticks: labels 0..36 at the vertical tick marks below the x-axis; y ticks: labels 0.0..1.0
lines = pg.lines
xt = sorted({round(l["x0"], 3) for l in lines if l["stroking_color"] == (0.0, 0.0, 0.0)
             and abs(l["x0"] - l["x1"]) < 1e-6 and l["top"] > 222 and l["bottom"] - l["top"] < 4})
yt = sorted({round(l["top"], 3) for l in lines if l["stroking_color"] == (0.0, 0.0, 0.0)
             and abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 4})
xlab = [0, 6, 12, 18, 24, 30, 36]
ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # top (small 'top') to bottom
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
ax, bx = np.polyfit(xt, xlab, 1)
ay, by = np.polyfit(yt, ylab, 1)
cal = dict(x_ticks_pt=xt, y_ticks_pt=yt, months_per_pt=ax, x0_pt=-bx / ax,
           surv_per_pt=ay, y_of_S1_pt=(1 - by) / ay,
           x_resid=float(np.max(np.abs(np.polyval([ax, bx], xt) - xlab))),
           y_resid=float(np.max(np.abs(np.polyval([ay, by], yt) - ylab))))
T = lambda x: ax * x + bx
S = lambda y: ay * y + by

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}  # legend order

# ---------- risk table ----------
words = pg.extract_words()
risk = {}
for g in "AB":
    row_top = [w["top"] for w in words if w["text"] == g and w["x0"] < 60 and w["top"] > 270][0]
    vals = sorted([(w["x0"], int(w["text"])) for w in words
                   if abs(w["top"] - row_top) < 1 and w["x0"] > 55 and w["text"].isdigit()])
    # map each number to nearest x tick by centre
    rt = {}
    for (x0, v), w in zip(vals, sorted([w for w in words if abs(w["top"] - row_top) < 1
                                        and w["x0"] > 55 and w["text"].isdigit()], key=lambda w: w["x0"])):
        c = (w["x0"] + w["x1"]) / 2
        rt[int(round(T(c) / 6) * 6)] = v
    risk[g] = dict(sorted(rt.items()))

# ---------- curve and censor extraction ----------
measured = {}
records = []
diag = {}
for g in "AB":
    n0 = man["groups"][g]
    curve = [c for c in pg.curves if tuple(round(v, 6) for v in c["stroking_color"]) == COL[g]][0]
    pts = [(T(x), S(y)) for x, y in curve["pts"]]
    # step curve: collect vertical segments (drops) as (time, S_before, S_after)
    drops = []
    for (t1, s1), (t2, s2) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t2) < 1e-9 and s2 < s1 - 1e-9:
            drops.append((t1, s1, s2))
    t_end = pts[-1][0]
    s_start = pts[0][1]
    ticks = sorted(T((l["x0"] + l["x1"]) / 2) for l in lines
                   if tuple(round(v, 6) for v in l["stroking_color"]) == COL[g]
                   and abs(l["x0"] - l["x1"]) < 1e-6 and 3.5 < l["bottom"] - l["top"] < 4.5)
    tick_S = sorted(((T(l["x0"]), S((l["top"] + l["bottom"]) / 2)) for l in lines
                     if tuple(round(v, 6) for v in l["stroking_color"]) == COL[g]
                     and abs(l["x0"] - l["x1"]) < 1e-6 and 3.5 < l["bottom"] - l["top"] < 4.5))
    measured[g] = dict(start_S=s_start, end_time=t_end,
                       drops=[dict(t=t, S_before=a, S_after=b) for t, a, b in drops],
                       censor_ticks=[dict(t=t, S_at_tick=s) for t, s in tick_S])

    # Sequential KM inversion. extra[k] = unmarked censorings added in risk interval k
    rtimes = sorted(risk[g])
    extra = {k: 0 for k in range(len(rtimes) - 1)}
    for it in range(20):
        cens = list(ticks)
        for k, m in extra.items():
            lo, hi = rtimes[k], rtimes[k + 1]
            # unmarked censorings spread uniformly inside the interval (assumption)
            cens += list(lo + (hi - lo) * (np.arange(m) + 0.5) / max(m, 1)) if m else []
        cens = sorted(cens)
        n = n0; ev = []; ci = 0; dres = []
        for t, a, b in drops:
            while ci < len(cens) and cens[ci] < t:
                n -= 1; ci += 1
            dexact = n * (1 - b / a)
            d = int(round(dexact))
            dres.append(dict(t=t, n_risk=n, d_exact=dexact, d=d))
            ev += [t] * d; n -= d
        # remaining at end: censor survivors at their censor times; any excess at curve end
        c_left = cens[ci:]
        n_after = n - len(c_left)
        obs = np.array(ev + cens, float)
        rec_ev = np.array([1] * len(ev) + [0] * len(cens))
        # compare risk table
        new = dict(extra)
        for k in range(1, len(rtimes)):
            t = rtimes[k]
            nr = int(np.sum(obs >= t)) + (n_after if t_end >= t else 0)
            disc = nr - risk[g][t]
            if disc > 0 and k - 1 in new:
                new[k - 1] += disc
                break
        if new == extra:
            break
        extra = new
    diag[g] = dict(drops=dres, unmarked_censor_added=extra, survivors_beyond_last_marked=n_after,
                   iterations=it + 1)
    if n_after > 0:  # survivors not accounted for by marks: censor at curve end (must be < 36)
        obs = np.append(obs, [t_end] * n_after); rec_ev = np.append(rec_ev, [0] * n_after)
    elif n_after < 0:
        raise RuntimeError(f"{g}: more marked censorings than remaining participants")
    assert len(obs) == n0, (g, len(obs))
    for t, e in zip(obs, rec_ev):
        records.append((g, round(float(t), 4), int(e)))

df = pd.DataFrame(records, columns=["group", "observed_time", "event"]).sort_values(
    ["group", "observed_time", "event"], ascending=[True, True, False])
tmp = os.path.join(out, "ipd.csv.tmp")
df.to_csv(tmp, index=False)
os.replace(tmp, os.path.join(out, "ipd.csv"))
json.dump(dict(calibration=cal, risk_table=risk, measured=measured, inversion=diag),
          open(os.path.join(out, "extracted.json"), "w"), indent=1, default=float)
print(json.dumps({g: dict(unmarked=diag[g]["unmarked_censor_added"], n_after=diag[g]["survivors_beyond_last_marked"],
                          events=int(df[(df.group == g)].event.sum()),
                          max_dres=max(abs(r["d_exact"] - r["d"]) for r in diag[g]["drops"]),
                          dist=np.unique([r["d"] for r in diag[g]["drops"]], return_counts=True)[1].tolist())
                  for g in "AB"}, default=int))
print(cal)
