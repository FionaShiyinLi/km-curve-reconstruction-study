# Reconstruction assumptions

## Inputs used
- `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (A = 100, B = 100, months, seed 1230746963). The manifest has no arm-specific event totals, so that check is marked unavailable.
- Arm identity: the legend lists blue as "Group A" and orange as "Group B". Censor ticks and step paths are separated by stroke color.
- Number-at-risk table (read from the PDF text layer, with columns matched to x-axis ticks by position): A 100/68/44/30/22/13/0, B 100/76/55/44/31/9/0 at 0/6/.../36 months.

## Measurement
- No raster measurement was needed. Each arm's KM curve is a single vector path, and each censor mark is a separate 4-pt vertical line. Coordinates were read directly from the PDF with pdfplumber.
- Calibration uses a linear fit to the 7 labelled x-ticks (0–36) and 6 labelled y-ticks (0.0–1.0). The maximum fit residual is below 1e-13, so no global correction was applied. Both paths start exactly at (0, 1.0), so there was no origin problem.
- Extracted values (drops with S before and after, censor tick times and heights, risk table, calibration) are saved in `output/extracted.json`. `output/overlay.png` plots the measured curve against the KM curve recomputed from the CSV.

## Algorithm (`output/code/reconstruct.py`)
- The program is a sequential KM inversion. Censor ticks give censoring times directly. At each vertical drop, d = n_risk × (1 − S_after/S_before), where n_risk = N − previous events − censorings strictly before the drop.
- The unrounded d was within 5e-5 of an integer at every drop (d = 1 at all 76 drops in A and all 65 in B). No tied drops were found. So d = 1 is supported by the exact vector ratios under the tick-based risk sets, not assumed from drop size.
- The program can add unmarked censorings when the marked risk sets exceed the table. None were needed: 24 ticks in A and 35 in B reproduce every risk-table count exactly. The number of ticks equals N − events in each arm, so no participants remain beyond the last mark. Both curves end at their last censor tick (A 35.96, B 35.53 months), before the displayed 0 at 36.
- Two A ticks lie within 0.001 month of an event (7.158 and 25.837). The PDF x-positions put them just before the event. That order is preserved at 4-decimal precision, and at these arm sizes it does not affect the KM ratios.
- The algorithm is deterministic. The seed is set and recorded but not used.

## Checks (`output/code/checks.py` → `output/checks.json`)
- The checker reloads the committed CSV, recomputes the right-continuous KM curve, and compares it with the measured step function at a time grid (including 0, 33–35 months and the curve end) and at every drop. The maximum absolute residual is 0 at the stated tolerance of 0.002.
- Risk-table counts are computed as #{observed_time ≥ t}. All 14 match exactly, including the 0 at 36 months.
- Each arm has 100 records, and every event indicator is 0 or 1.
- A first run of the checker reported one mismatch at B's last drop. That came from evaluating the exact-time measured step at a time rounded to 4 decimals, just below the jump. The checker now compares jump times at the CSV's 1e-4-month precision. The CSV was not changed, so no primary correction cycle was used.

## Limitations
- The CSV times are the plotted vector coordinates rounded to 1e-4 month. The true times may have been rounded or jittered before plotting.
- If a displayed censor tick hid several tied censorings at identical coordinates, the reconstruction would not show it. The exact agreement with the risk table and the integer drop ratios argues against this, but cannot rule out offsetting errors between table intervals.
- Sensitivity analysis was not run. No materially different allocation is consistent with the vector drops, the ticks and the risk table, so `sensitivity.csv` is not provided.
