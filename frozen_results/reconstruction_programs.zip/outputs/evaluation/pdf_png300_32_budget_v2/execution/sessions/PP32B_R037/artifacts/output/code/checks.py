"""Reload committed ipd.csv, recompute right-continuous KM, compare with vector measurements.
Usage: python checks.py [OUTPUT_DIR]   (needs OUTPUT_DIR/extracted.json from reconstruct.py)"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

out = sys.argv[1] if len(sys.argv) > 1 else "output"
path = os.path.join(out, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path)
ex = json.load(open(os.path.join(out, "extracted.json")))
TOL_S = 0.002  # vector coordinates: 1 pt = 0.0056 survival; tolerance well below one-point rendering error
EPS = 1e-4  # CSV times carry 4 decimals; jump times compared at that precision (min event-time gap 0.0019 mo)

def km(t, e):
    ut = np.unique(t[e == 1]); s = 1.0; st = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); s *= 1 - d / n; st.append((u, s))
    return st

def S_at(st, x):  # right-continuous step function
    s = 1.0
    for u, v in st:
        if u <= x: s = v
        else: break
    return s

def S_meas(m, x):  # measured step function from vector drops
    s = m["start_S"]
    for d in m["drops"]:
        if d["t"] <= x + EPS: s = d["S_after"]
    return s

res = dict(csv_sha256=sha, tolerance_survival=TOL_S,
           tolerance_note="Curve read from exact PDF vector coordinates (axis fit residual <1e-13); "
                          "0.002 allows for 4-5 decimal coordinate rounding only.", groups={})
fig, axs = plt.subplots(1, 2, figsize=(11, 4))
for i, g in enumerate("AB"):
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    st = km(t, e); m = ex["measured"][g]
    tend = m["end_time"]
    grid = sorted(set([0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 34, 35, round(tend - 0.01, 3), round(tend, 3)]
                      + [round(x["t"] + 1e-3, 4) for x in m["drops"][:: max(1, len(m["drops"]) // 12)]]
                      + [round(m["drops"][-1]["t"] + EPS, 4)]))
    grid = [x for x in grid if x <= tend]
    comp = []
    for x in grid:
        sm, sr = S_meas(m, x), S_at(st, x)
        comp.append(dict(t=x, measured=round(sm, 5), reconstructed=round(sr, 5), resid=round(sr - sm, 5),
                         status="pass" if abs(sr - sm) <= TOL_S else "fail"))
    # all drops individually
    maxd = max(abs(S_at(st, x["t"] + EPS) - x["S_after"]) for x in m["drops"])
    rk = []
    for tt, v in ex["risk_table"][g].items():
        tt = float(tt); nr = int(np.sum(t >= tt))
        rk.append(dict(t=tt, displayed=v, reconstructed=nr, resid=nr - v, status="pass" if nr == v else "fail"))
    res["groups"][g] = dict(
        n_records=len(d), n_expected=100, n_status="pass" if len(d) == 100 else "fail",
        event_indicator_integer_01=bool(set(e) <= {0, 1}),
        events=int(e.sum()), censored=int((e == 0).sum()),
        supplied_event_total="unavailable (not in manifest)",
        marked_censor_ticks=len(m["censor_ticks"]),
        max_abs_resid_at_all_drops=round(maxd, 6),
        n_drops_measured=len(m["drops"]), n_distinct_event_times=len(st),
        max_observed_time=float(t.max()), curve_end_time=round(tend, 4),
        tail_S_measured=round(m["drops"][-1]["S_after"], 5), tail_S_reconstructed=round(st[-1][1], 5),
        km_comparison=comp, risk_table=rk)
    xs = np.linspace(0, 36, 2000)
    axs[i].step([0] + [x["t"] for x in m["drops"]] + [tend], [m["start_S"]] + [x["S_after"] for x in m["drops"]] + [m["drops"][-1]["S_after"]], where="post", label="measured (vector)", lw=3, alpha=.4)
    axs[i].plot(xs, [S_at(st, x) for x in xs], drawstyle="steps-post", lw=1, label="KM from ipd.csv")
    axs[i].set_title(g); axs[i].legend()
fig.savefig(os.path.join(out, "overlay.png"), dpi=100)
json.dump(res, open(os.path.join(out, "checks.json"), "w"), indent=1)
for g in "AB":
    r = res["groups"][g]
    print(g, r["n_records"], r["events"], r["max_abs_resid_at_all_drops"],
          [c["status"] for c in r["km_comparison"]].count("fail"), [(x["displayed"], x["reconstructed"]) for x in r["risk_table"]],
          r["max_observed_time"], r["tail_S_measured"], r["tail_S_reconstructed"])
print(sha)
