import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
H,W,_=im.shape
dark=(im.sum(2)<200)
# axis lines
cols=dark.sum(0); rows=dark.sum(1)
print('dark cols',[ (i,cols[i]) for i in np.argsort(cols)[-5:]])
print('dark rows',[ (i,rows[i]) for i in np.argsort(rows)[-5:]])
# tick marks below x axis
for r in range(925,945):
    xs=np.where(dark[r,200:1750])[0]+200
    if 0<len(xs)<60: print('row',r,xs)
for c in range(250,270):
    ys=np.where(dark[100:960,c])[0]+100
    if 0<len(ys)<60: print('col',c,ys)
