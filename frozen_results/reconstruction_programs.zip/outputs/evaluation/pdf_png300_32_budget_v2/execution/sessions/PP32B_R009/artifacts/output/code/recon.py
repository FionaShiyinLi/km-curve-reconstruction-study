"""KM-to-IPD reconstruction (own implementation). Usage: python recon.py [input_png] [manifest] [outdir]
Run from output/code/ ; defaults point to ../../../input/.  Writes <outdir>/ipd.csv (atomic), extracted_*.csv."""
import sys, os, json, hashlib, numpy as np, pandas as pd
from PIL import Image
_a = sys.argv if __name__=='__main__' else []   # CLI args only when run directly (module is imported by checks.py)
PNG = _a[1] if len(_a)>1 else '../../../input/figure.png'
MAN = _a[2] if len(_a)>2 else '../../../input/manifest.json'
OUT = _a[3] if len(_a)>3 else '..'
MODE = os.environ.get('EXTRA_CENSOR','uniform')   # 'uniform' (primary) or 'ticks' (sensitivity)
man=json.load(open(MAN)); SEED=man['code_seed']; rng=np.random.default_rng(SEED)  # seed recorded; algorithm is deterministic
NG=man['groups']
# --- calibration from labelled axis ticks (see probe.py): x=0..36 ticks at px 269.5+40/month; y 1.0@179.5, 0.0@929.5
X0,PXM=269.5,40.0; Y0,PXS=929.5,750.0
t_of=lambda x:(x-X0)/PXM; s_of=lambda y:(Y0-y)/PXS
# --- risk table read visually from the figure (text rows below plot)
RT_T=[0,6,12,18,24,30,36]
RT={'A':[100,71,46,33,24,8,0],'B':[100,61,45,35,26,10,0]}
COL={'A':(31,119,180),'B':(255,127,14)}
im=np.asarray(Image.open(PNG).convert('RGB')).astype(float)

def clusters(idx,gap=1):
    if len(idx)==0: return []
    out=[[idx[0]]]
    for i in idx[1:]:
        if i-out[-1][-1]<=gap: out[-1].append(i)
        else: out.append([i])
    return out

def measure(g):
    d=np.sqrt(((im-np.array(COL[g]))**2).sum(2)); m=d<60
    m[:,:268]=False; m[936:,:]=False; m[:150,:]=False
    hz=np.ones_like(m)
    for s in range(-3,4): hz&=np.roll(m,s,axis=1)
    rec=[]
    for x in range(268,1712):
        ys=np.where(m[:,x])[0]; cl=clusters(list(np.where(hz[:,x])[0]))
        lv=np.mean(cl[-1]) if cl else (ys.mean() if len(ys) and ys.max()-ys.min()<=5 else np.nan)  # raw fallback (axis/corners)         # lowest horizontal cluster = level after any drop in this column
        rec.append(dict(x=x,t=t_of(x),level_px=lv,S=s_of(lv),
                        ymin=ys.min() if len(ys) else np.nan,ymax=ys.max() if len(ys) else np.nan))
    df=pd.DataFrame(rec)
    # tick = colored pixels extending >=5 px below the (lowest) line level; drops never extend below the new level
    lvl=df.level_px.ffill().rolling(9,center=True,min_periods=1).max()   # lowest level within +-4 px (covers drop corners)
    up=df.level_px.ffill().bfill().rolling(9,center=True,min_periods=1).min()  # highest level within +-4 px
    # tick = extends >=5 px below the lower local level OR >=5 px above the upper local level (drops do neither)
    hzcol=df.level_px.notna()
    # below-test only where a horizontal level exists in the column; in columns without one (descending staircase)
    # only the above-test is used, since a staircase never extends above its previous level
    # reference for the below-test: the lower of the local level and the next horizontal level to the right
    # (a descending staircase never extends below the level it ends at; a censor tick does)
    lowref=np.fmax(lvl,df.level_px.bfill().rolling(9,center=True,min_periods=1).max())
    df['tickcol']=((df.ymax-(lowref+1.5))>=5) | (((up-1.5)-df.ymin)>=5)
    # level refinement: lower envelope (ymax - 1.5 px half line width) resolves narrow staircase steps that the
    # 7-px horizontal window merges; tick columns keep the horizontal-cluster level
    env=df.ymax-1.5
    use=~df.tickcol & env.notna() & df.level_px.isna()   # only where no horizontal-window level exists
    df.loc[use,'level_px']=env[use]; df['S']=s_of(df.level_px)
    df['hidden']=df.level_px.isna()
    return df

def fill_hidden(df,other):
    """columns where this arm's pixels are absent (drawn underneath the other arm) take the other arm's level,
    when that level lies between this arm's neighbouring visible levels"""
    df=df.copy(); o=other.set_index('x').level_px
    prev=df.level_px.ffill(); nxt=df.level_px.bfill()
    for i in df.index[df.hidden & (df.x>=275)]:
        ol=o.get(df.x[i],np.nan)
        if np.isfinite(ol) and prev[i]-1.5<=ol<=nxt[i]+1.5:
            df.loc[i,['level_px','S','hidden','filled']]=[ol,s_of(ol),False,True]
    return df

def km_steps(df):
    """segment level series into flat runs; return list of (t_drop, S_before, S_after) and the curve end"""
    v=df[~df.hidden & (df.x>=272)]
    xs=v.x.values; L=v.level_px.values
    runs=[]; start=0
    for i in range(1,len(L)+1):
        if i==len(L) or abs(L[i]-np.median(L[start:i]))>1.5:
            runs.append((xs[start],xs[i-1],np.median(L[start:i]))); start=i
    drops=[]
    prevS=1.0   # origin: S(0)=1 by definition; first run's level checked below (not rescaled)
    for (a,b,lv) in runs:
        S=s_of(lv)
        if prevS-S>0.002: drops.append((t_of(a),prevS,S))
        prevS=S if (prevS-S>0.002 or S>prevS) else prevS
    return runs,drops

def ticks(df):
    cl=clusters(list(df.x[df.tickcol].values))
    return [(t_of(np.mean(c)),len(c)) for c in cl]

def build(g):
    df=measure(g); tk=ticks(df)
    df=fill_hidden(df,measure('B' if g=='A' else 'A')); runs,drops=km_steps(df)
    tend=t_of(df.x[~df.hidden].max())
    n0=NG[g]; rt=RT[g]
    times=[];events=[]
    S_cur=1.0; n=n0; di=0
    log=[]
    for k in range(len(RT_T)-1):
        a,b=RT_T[k],RT_T[k+1]
        dk=[dr for dr in drops if a<=dr[0]<b]
        # ticks within 0.1 month of the origin are axis/start-drop artifacts (inspected) and are ignored
        tkw=[(t,w) for t,w in tk if a<=t<b and t>=0.1]; tkk=[t for t,w in tkw]
        # if fewer censorings than detected ticks: primary keeps the widest (strongest) ticks; sensitivity keeps evenly spaced
        rank=sorted(range(len(tkw)),key=lambda i:(-tkw[i][1],i))
        best=None
        for c in range(0,n+1):
            # censor times: visible ticks first; extras beyond ticks spread uniformly over [a, min(b,tend)) (assumption)
            if c<=len(tkk):
                if MODE=='uniform': ct=[tkk[i] for i in rank[:c]]
                else: ct=list(np.array(tkk)[np.round(np.linspace(0,len(tkk)-1,c)).astype(int)]) if c>0 else []
            else:
                hi=min(b,tend)
                extra = list(a+(np.arange(c-len(tkk))+0.5)*(hi-a)/(c-len(tkk))) if MODE=='uniform' else \
                        [tkk[i%len(tkk)] if tkk else (a+hi)/2 for i in range(c-len(tkk))]
                ct=tkk+extra
            ct=sorted(ct); Sc=S_cur; nr=n; ev=[]; ci=0; ok=True
            for (td,Sb,Sa) in dk:
                while ci<len(ct) and ct[ci]<td: nr-=1; ci+=1
                if nr<=0: ok=False; break
                d=int(np.clip(round(nr*(1-Sa/Sc)),0,nr))  # d=0 allowed: sub-event level jitter (e.g. overlap with other arm) is not an event
                ev.append((td,d)); Sc*=1-d/nr; nr-=d
            nr-=len(ct)-ci
            if not ok or nr<0: continue
            err=abs(nr-rt[k+1]) + 0.001*abs(c-len(tkk))
            if best is None or err<best[0]: best=(err,c,ct,ev,Sc,nr)
        err,c,ct,ev,Sc,nr=best
        for td,d in ev: times+= [td]*d; events+=[1]*d
        # at 36 the displayed risk is 0: keep censor times strictly below 36
        times+= [min(t,35.99) for t in ct]; events+=[0]*len(ct)
        log.append(dict(interval=[a,b],n_start=n,n_end_table=rt[k+1],n_end_recon=nr,visible_ticks=len(tkk),
                        censored=c,events=int(sum(d for _,d in ev)),drops=len(dk)))
        S_cur=Sc; n=nr
    # anyone still at risk after the last interval (should be 0) censored at curve end
    times+=[min(tend,35.99)]*n; events+=[0]*n
    return df,runs,drops,tk,pd.DataFrame(dict(group=g,observed_time=np.round(times,4),event=events)),log,tend

if __name__=='__main__':
    allrec=[]; meta={}
    for g in ['A','B']:
        df,runs,drops,tk,ipd,log,tend=build(g)
        assert len(ipd)==NG[g]
        df.to_csv(f'{OUT}/extracted_columns_{g}.csv',index=False)
        pd.DataFrame(drops,columns=['t','S_before','S_after']).to_csv(f'{OUT}/extracted_drops_{g}.csv',index=False)
        pd.DataFrame(tk,columns=['t','width_px']).to_csv(f'{OUT}/extracted_ticks_{g}.csv',index=False)
        allrec.append(ipd); meta[g]=dict(log=log,curve_end=tend,n_drops=len(drops),n_ticks=len(tk),
              tick_widths=[w for _,w in tk],first_run=[t_of(runs[0][0]),t_of(runs[0][1]),s_of(runs[0][2])])
        print(g,json.dumps(meta[g],default=float))
    fn='ipd.csv' if MODE=='uniform' else 'sensitivity.csv'
    tmp=f'{OUT}/.{fn}.tmp'; pd.concat(allrec).to_csv(tmp,index=False); os.replace(tmp,f'{OUT}/{fn}')
    json.dump(meta,open(f'{OUT}/recon_log_{MODE}.json','w'),indent=1,default=float)
