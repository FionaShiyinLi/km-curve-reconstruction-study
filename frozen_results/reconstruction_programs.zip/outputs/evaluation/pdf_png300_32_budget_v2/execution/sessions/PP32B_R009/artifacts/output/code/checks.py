"""Reload committed CSV, recompute right-continuous KM, compare with measured curve and risk table.
Usage (from output/code/): python checks.py [csv] [outjson]"""
import sys, json, hashlib, numpy as np, pandas as pd
from recon import RT_T, RT, NG, measure, X0, PXM

def km(d):
    tt=np.sort(d.observed_time[d.event==1].unique()); S=1.0; out=[]
    for t in tt:
        n=(d.observed_time>=t).sum(); e=((d.observed_time==t)&(d.event==1)).sum(); S*=1-e/n; out.append((float(t),float(S)))
    return out

def S_at(steps,t):  # right-continuous step function
    S=1.0
    for tt,s in steps:
        if tt<=t: S=s
        else: break
    return S

TOL=0.01  # 7.5 px

def main(CSV,OUTJ):
    ipd=pd.read_csv(CSV); sha=hashlib.sha256(open(CSV,'rb').read()).hexdigest()
    res={'csv':CSV,'sha256':sha,'tolerance_S':TOL,
         'tolerance_justification':'measured level +-1.5 px (0.002); check times moved >=0.075 mo (3 px) away from detected drops; '
            '0.01 is below one event step at every risk set (1/n_risk * S >= 0.0074 at n=100,S=0.74; larger later), so an event-count error fails',
         'groups':{}}
    for g in ['A','B']:
        d=ipd[ipd.group==g]; st=km(d); df=measure(g)
        gr={'n_records':int(len(d)),'n_expected':NG[g],'n_ok':bool(len(d)==NG[g]),
            'event_integer_0_1':bool(d.event.isin([0,1]).all()),'events':int(d.event.sum()),'censored':int((d.event==0).sum()),
            'supplied_event_total':'unavailable (not in manifest)','max_time':float(d.observed_time.max()),
            'finite_nonneg':bool(np.isfinite(d.observed_time).all() and (d.observed_time>=0).all())}
        drops=pd.read_csv(f'../extracted_drops_{g}.csv').t.values
        cmp=[]
        for t in np.concatenate([np.arange(0.25,36,1.0),[35.5]]):
            if len(drops):   # nearest time (searching both directions) at least 3 px from every detected drop
                for off in [0]+[o*k for k in range(1,41) for o in (0.025,-0.025)]:
                    if np.min(np.abs(drops-(t+off)))>=0.075: t=t+off; break
            x=X0+t*PXM
            col=df[(df.x>=x-1)&(df.x<=x+1)&~df.hidden]
            r=S_at(st,t)
            if len(col)==0:
                cmp.append(dict(t=round(float(t),3),measured=None,recon=round(r,4),resid=None,status='unavailable (curve pixels hidden by other arm/drop)')); continue
            m=float(col.S.median())
            cmp.append(dict(t=round(float(t),3),measured=round(m,4),recon=round(r,4),resid=round(r-m,4),status='pass' if abs(r-m)<=TOL else 'fail'))
        gr['curve']=cmp
        gr['risk_table']=[]
        for t,n in zip(RT_T,RT[g]):
            c=int((d.observed_time>=t).sum()); gr['risk_table'].append(dict(t=t,table=n,recon=c,resid=c-n,status='pass' if c==n else 'fail'))
        res['groups'][g]=gr
        print(g,{k:v for k,v in gr.items() if k not in('curve','risk_table')})
        print(' curve non-pass:',[(c['t'],c['status']) for c in cmp if c['status']!='pass'],
              ' max|resid|:',max(abs(c['resid']) for c in cmp if c['resid'] is not None))
        print(' risk:',[(r['t'],r['table'],r['recon']) for r in gr['risk_table']])
    json.dump(res,open(OUTJ,'w'),indent=1)

if __name__=='__main__':
    main(sys.argv[1] if len(sys.argv)>1 else '../ipd.csv', sys.argv[2] if len(sys.argv)>2 else '../checks.json')
