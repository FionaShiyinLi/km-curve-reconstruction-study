# Reconstruction of participant-level records from the Kaplan–Meier figure

## Inputs used
- `../input/figure.png` (1800×1350 raster). Curves, censor ticks and the number-at-risk table were read from this image.
- `../input/manifest.json`: n = 100 per arm, time unit months, code seed 1291055773. The seed is loaded and recorded in `recon.py`, but the algorithm is deterministic and draws no random numbers.
- The manifest has no arm-specific event totals, so that check is marked unavailable. No other auxiliary information was used.
- Risk table (read visually; all digits legible, no ambiguity noted) at 0, 6, 12, 18, 24, 30, 36 months:
  - A: 100, 71, 46, 33, 24, 8, 0
  - B: 100, 61, 45, 35, 26, 10, 0

## Calibration and measurement
- **Axes.** Calibration uses the pixel centers of the labelled axis ticks (`code/probe.py`). Time: 0 months at x = 269.5 px, 40 px per month (ticks every 6 months up to 36). Survival: 1.0 at y = 179.5 px and 0.0 at y = 929.5 px (ticks every 0.2). No global rescaling was applied. Both arms' initial horizontal lines sit at S ≈ 0.998, within half a line width of 1.0.
- **Origin.** Both arms have genuine early drops, and these were kept. A falls to 0.99 at about 0.14 months; B falls to 0.98 at about 0.06 months. Near the y-axis, the level was measured from raw column pixels because the black axis line covers the first 2 px.
- **Line tracing.** Each arm is traced by color (the matplotlib defaults, #1f77b4 for A and #ff7f0e for B). The level in each column is the center of the lowest pixel cluster that is colored over a 7-px horizontal window.
  - Where that window fails (steep staircases such as B at 2.3–3.1 months, and drop corners), the level is the lower pixel envelope minus half the line width.
  - Where A is drawn underneath B (about 15.4–16.2 months), A's hidden columns take B's level. This is done only when B's level lies between A's neighboring visible levels.
- **Drops.** The level series is segmented into flat runs (tolerance 1.5 px). Every drop between runs is recorded with its before and after levels. Measurements are saved in `extracted_columns_*.csv`, `extracted_drops_*.csv` and `extracted_ticks_*.csv`.
- **Censor ticks.** A tick is a column whose pixels extend at least 5 px above the local upper level, or at least 5 px below the lower of the local level and the next horizontal level. A drop never does either. Adjacent tick columns are grouped. Candidates within 0.1 months of the origin are axis or start-drop artifacts and were excluded after inspection.
  - Tick *visibility* does not establish *multiplicity*. Overlapping ticks cannot be separated, so the number of censorings per interval comes from the risk table (below), not from the tick count.

## Reconstruction algorithm (own implementation, `code/recon.py`)
The method is a Guyot-style interval algorithm written from scratch. Risk-table intervals are processed in order. For each candidate number of censorings c in the interval (0 to n at the interval start):

1. **Censor placement.** The c censorings go at visible tick times. If c exceeds the visible ticks, the extras are spread uniformly over the interval (*assumption*). If c is smaller, the widest ticks are kept.
2. **Events at each drop.** Walking through the drops in time order, n_risk is updated after preceding censorings. The event count is d = round(n_risk·(1 − S_after/S_current)), where S_current is the reconstructed KM value, so rounding errors do not accumulate. d = 0 is allowed for sub-event level jitter. A single visible drop can therefore carry several tied events (for example, 3 events at 9.39 months in A).
3. **Selection.** The chosen c reproduces the next risk-table count, with ties broken toward the visible tick count.

**Final interval.** The displayed count at 36 months is 0, so every remaining participant is censored at a detected tick before 36 months (B's last tick at 35.99; A's curve ends at 35.66). Nobody is placed at 36.

**Visible ticks vs. censorings required** (intervals 0–6, 6–12, 12–18, 18–24, 24–30, 30–36):

| Arm | Visible ticks | Censorings required | Events |
|---|---|---|---|
| A | 4, 1, 2, 0, 11, 8 | identical | 74 |
| B | 3, 1, 2, 1, 13, 9 | 3, 1, 2, 2, 14, 9 | 69 |

- In A, the risk table and the tick evidence agree independently in every interval.
- In B, two censorings (one in 18–24, one in 24–30) have no separately visible tick. They are placed uniformly within their intervals as an assumption. The likely cause is ticks hidden by overlap with A or merged with other ticks.

## Verification (`code/checks.py` → `checks.json`)
- The committed CSV is reloaded and a right-continuous KM step function is recomputed. It is compared with the measured level at 38 times per arm, from 0.2 to 35.5 months, including the start and the tail.
- Each check time is moved to the nearest point at least 3 px from every detected drop, so the ±1 px measurement window does not straddle a step. This rule was corrected once, after it placed a check point on an adjacent drop.
- Tolerance is 0.01 in S. This is below one event step for every risk set in the figure, so an event-count error fails. The measurement precision is about ±0.002.
- Results: all points pass. The maximum |residual| is 0.0028 for A and 0.0008 for B. Tail values at 35.5 months are A 0.1947 (measured 0.1947) and B 0.2514 (measured 0.2507).
- The measured values come from the same pixel extraction that drives the reconstruction, so this is an internal consistency check, not independent validation. The overlay in `overlay.png` was also inspected visually.
- Risk counts are the number with observed_time ≥ t. All 14 match exactly, including the 0 at 36 months.
- n = 100 per arm, event indicators are integer 0/1, and times are finite and nonnegative. The event-total check is unavailable.

## Sensitivity (one alternative, `sensitivity.csv`)
- **Alternative assumption.** Censorings in excess of the visible ticks are duplicated at visible tick positions (tick multiplicity), not spread uniformly. Where fewer censorings than ticks are needed, evenly spaced ticks are kept. This affects only B in the intervals noted above.
- **Common supported horizon: 35.6 months** (A's follow-up ends at 35.66).

| Arm | Allocation | S(12) | S(24) | S(35.6) | Area under S to 35.6 (RMST) |
|---|---|---|---|---|---|
| A | primary / alternative | 0.4877 / 0.4877 | 0.2671 / 0.2671 | 0.1947 / 0.1947 | 15.889 / 15.889 |
| B | primary / alternative | 0.4753 / 0.4753 | 0.3106 / 0.3117 | 0.2514 / 0.2511 | 15.479 / 15.481 |

- One alternative allocation is not a bound on reconstruction error.

## Limitations and unresolved points
- **Timing precision.** Event times are resolved to about 1 px (0.025 months), and drop times sit at the detected column (possibly about 1 px early). Censoring times within an interval are known only as far as the ticks resolve them. Where ticks overlap, individual times are not identifiable.
- **Occluded region.** Where A runs underneath B, A's level is inferred from B's line. Some ticks may be hidden as well.
- **Beyond the risk table.** Events are allocated so that the curve is reproduced. The records are one feasible data set consistent with the figure, not a unique recovery of the original data. No covariates or follow-up beyond what the figure shows were created.

## Correction history
1. First complete file.
2. Correction cycle 1: allowed d = 0 for sub-event level jitter, which removed a spurious extra event in B near 20.4 months.
3. Correction cycle 2: added the occlusion fill (A, 15.4 months) and the staircase envelope with a tick rule consistent with it (B, 2.3–3.1 months). This took several sub-iterations within the cycle, and intermediate runs overwrote the CSV atomically.
- `checks.json` and `sensitivity.csv` were regenerated from the final files. `checks.json` records the SHA-256 of `ipd.csv`.

## Reproduce
```
cd output/code
python recon.py [../../../input/figure.png ../../../input/manifest.json ..]
EXTRA_CENSOR=ticks python recon.py      # sensitivity
python checks.py                        # checks.json
python checks.py ../sensitivity.csv ../checks_sensitivity.json
python compare.py                       # sensitivity_comparison.json, overlay.png
```
