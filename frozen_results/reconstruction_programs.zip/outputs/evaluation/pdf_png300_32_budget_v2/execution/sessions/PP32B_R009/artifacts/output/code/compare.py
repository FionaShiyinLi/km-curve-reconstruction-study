"""Same-horizon comparison of primary vs sensitivity reconstructions and overlay plot."""
import json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
from checks import km, S_at
from recon import X0,PXM,Y0,PXS
H=35.6  # common supported horizon: A's curve ends at 35.66 mo, B's at 35.99 mo
def rmst(st,h):
    ts=[0]+[t for t,_ in st if t<h]+[h]; a=0
    for i in range(len(ts)-1): a+=S_at(st,ts[i])*(ts[i+1]-ts[i])
    return a
out={'horizon_months':H}
for lab,f in [('primary','../ipd.csv'),('sensitivity','../sensitivity.csv')]:
    d=pd.read_csv(f)
    for g in 'AB':
        st=km(d[d.group==g]); out[f'{lab}_{g}']={'S_at_H':round(S_at(st,H),4),'S_at_12':round(S_at(st,12),4),'S_at_24':round(S_at(st,24),4),'RMST_H':round(rmst(st,H),3)}
print(json.dumps(out,indent=1)); json.dump(out,open('../sensitivity_comparison.json','w'),indent=1)
im=Image.open('../../../input/figure.png'); fig,ax=plt.subplots(figsize=(18,13.5),dpi=100); ax.imshow(im)
d=pd.read_csv('../ipd.csv')
for g,c in [('A','k'),('B','m')]:
    st=km(d[d.group==g]); tt=np.linspace(0,36,3000); ax.plot(X0+tt*PXM,[Y0-S_at(st,t)*PXS for t in tt],c,lw=0.8)
    cz=d[(d.group==g)&(d.event==0)].observed_time; ax.plot(X0+cz*PXM,[Y0-S_at(st,t)*PXS-12 for t in cz],c+'v',ms=3)
ax.set_xlim(250,1730); ax.set_ylim(950,150); fig.savefig('../overlay.png',bbox_inches='tight')
