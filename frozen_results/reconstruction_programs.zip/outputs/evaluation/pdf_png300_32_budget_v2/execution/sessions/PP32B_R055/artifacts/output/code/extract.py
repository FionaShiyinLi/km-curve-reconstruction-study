"""Measure KM step curves and censor ticks from the raster figure.

Usage: python extract.py [path/to/figure.png] [outdir]
Writes <outdir>/extracted_<group>.json with plateaus (time interval, survival) and tick times.
Calibration is from the labelled axis ticks (found by pixel search, see find_axes()).
"""
import sys, json, os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input', 'figure.png')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..', 'extracted')
os.makedirs(OUT, exist_ok=True)

COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}
im = np.array(Image.open(FIG).convert('RGB')).astype(int)
Hh, Ww, _ = im.shape
dark = im.sum(2) < 200


def find_axes():
    # x tick marks hang below the x-axis line (row ~930); y tick marks left of the y axis
    xr = np.where(dark[934:942].all(0))[0]
    yr = np.where(dark[:, 258:266].all(1))[0]
    def centers(v):
        groups, cur = [], [v[0]]
        for a in v[1:]:
            if a - cur[-1] <= 1: cur.append(a)
            else: groups.append(np.mean(cur)); cur = [a]
        groups.append(np.mean(cur)); return np.array(groups)
    xc, yc = centers(xr), centers(yr)
    xlab = np.array([0, 6, 12, 18, 24, 30, 36.])      # labelled x ticks
    ylab = np.array([1.0, 0.8, 0.6, 0.4, 0.2, 0.0])   # labelled y ticks, top to bottom
    assert len(xc) == 7 and len(yc) == 6, (xc, yc)
    ax_, bx = np.polyfit(xc, xlab, 1); ay, by = np.polyfit(yc, ylab, 1)
    resx = xlab - (ax_ * xc + bx); resy = ylab - (ay * yc + by)
    return dict(xpix=xc.tolist(), ypix=yc.tolist(), ax=ax_, bx=bx, ay=ay, by=by,
                max_res_x=float(abs(resx).max()), max_res_y=float(abs(resy).max()))


cal = find_axes()
tx = lambda x: cal['ax'] * x + cal['bx']
sy = lambda y: cal['ay'] * y + cal['by']
x0 = int(round(cal['xpix'][0])) + 1          # first column right of y axis line
ybot = int(round(cal['ypix'][-1]))           # x axis row

masks = {g: (np.abs(im - np.array(c)).sum(2) < 30) for g, c in COLORS.items()}
for g in masks:
    masks[g][ybot - 1:, :] = masks[g][ybot - 1:, :]  # keep
    masks[g][:150, :] = False; masks[g][ybot + 2:, :] = False


def clusters(rows):
    if len(rows) == 0: return []
    out, cur = [], [rows[0]]
    for r in rows[1:]:
        if r - cur[-1] <= 1: cur.append(r)
        else: out.append(cur); cur = [r]
    out.append(cur); return out


def horiz(m, k=3):
    h = m.copy()
    for s in range(1, k + 1):
        h &= np.roll(m, s, 1) & np.roll(m, -s, 1)
    return h


def trace(g, other=None):
    m = masks[g]
    hm = horiz(m)
    # occlusion: where this curve has no horizontal pixels in a column but the curve drawn on top
    # ('other') does, and this curve is visible on both sides at the same level as 'other'
    ho = horiz(masks[other]) if other else None
    level = np.full(Ww, np.nan); thick = np.zeros(Ww); occl = np.zeros(Ww, bool)
    xs = np.where(m.any(0))[0]; xmax = xs.max()
    for x in range(x0, xmax + 1):
        cl = clusters(np.where(hm[:, x])[0])
        if len(cl) == 1 and 3 <= len(cl[0]) <= 7:
            level[x] = np.mean(cl[0]); thick[x] = len(cl[0])
        elif len(cl) == 0 and ho is not None:
            clo = clusters(np.where(ho[:, x])[0])
            # whole column of this curve hidden (no pixels at all) -> take the top curve's level
            if len(clo) == 1 and not m[:, x].any():
                level[x] = np.mean(clo[0]); occl[x] = True
    return level, occl, xmax


def plateaus(level, xmax):
    pl = []  # [xstart, xend, ycenter]
    x = x0
    while x <= xmax:
        if np.isnan(level[x]): x += 1; continue
        s = x; ys = [level[x]]
        while x + 1 <= xmax and not np.isnan(level[x + 1]) and abs(level[x + 1] - level[s]) <= 1.0:
            x += 1; ys.append(level[x])
        pl.append([s, x, float(np.median(ys))]); x += 1
    # merge plateaus with (nearly) the same level separated by small gaps (ticks, occlusion)
    merged = []
    for p in pl:
        if merged and abs(p[2] - merged[-1][2]) <= 1.0:
            merged[-1][1] = p[1]
        else:
            merged.append(p)
    # monotonicity: a KM curve cannot rise; a plateau higher than its predecessor is an occlusion
    # artefact (this curve hidden while the other curve's line was taken). Drop such plateaus.
    mono = []
    for p in merged:
        if mono and p[2] < mono[-1][2] - 1.0:
            continue
        if mono and abs(p[2] - mono[-1][2]) <= 1.0:
            mono[-1][1] = p[1]; continue
        mono.append(p)
    return mono


def ticks(g, pls, xmax):
    """Censor ticks: pixels of this colour clearly above the top of the current line.
    In the first columns of a plateau (where the vertical drop line arrives from above) the
    reference level is the preceding (upper) plateau; beyond the last plateau up to the last
    coloured column the last plateau's level is used (catches a tick at the curve end)."""
    m = masks[g]
    cols = []
    for i, (a, b, y) in enumerate(pls):
        b2 = xmax if i == len(pls) - 1 else b
        for x in range(a, b2 + 1):
            yref = pls[i - 1][2] if (i > 0 and x < a + 4) else y
            top = yref - 2.0   # line is 4 px thick: rows y-1.5..y+1.5; ticks rise 6 px above top row
            above = np.where(m[:int(np.floor(top)) + 1, x])[0]
            above = above[above > top - 14]
            if len(above) >= 5:
                cols.append((x, int(above.min())))
    out = []
    for x, t in cols:
        if out and x - out[-1][-1][0] <= 1: out[-1].append((x, t))
        else: out.append([(x, t)])
    # a single tick is 2 px wide (spans 2-3 columns); wider groups = overlapping ticks
    return [dict(x=float(np.mean([c[0] for c in grp])), width=len(grp),
                 mult=max(1, int(round(len(grp) / 3.0)))) for grp in out]


res = {'calibration': cal}
for g, other in [('A', 'B'), ('B', None)]:
    level, occl, xmax = trace(g, other)
    pls = plateaus(level, xmax)
    pls = [p for p in pls if not (p[1] - p[0] + 1 <= 2 and occl[p[0]:p[1] + 1].all())]
    tk = ticks(g, pls, xmax)
    # final vertical drop to zero? (colour reaching the x axis at the right end)
    m = masks[g]
    tail_cols = [x for x in range(int(pls[-1][0]), xmax + 1) if m[ybot - 3:ybot, x].any()]
    to_zero = float(np.mean(tail_cols)) if tail_cols else None
    rec = dict(
        plateaus=[dict(t0=tx(a - 0.5), t1=tx(b + 0.5), S=sy(y), ypix=y, xpix=[a, b],
                       occluded_cols=int(occl[a:b + 1].sum())) for a, b, y in pls],
        ticks=[dict(t=tx(t['x']), width_px=t['width'], mult=t['mult']) for t in tk],
        drop_to_zero_t=(tx(to_zero) if to_zero else None),
        last_col_t=tx(xmax + 0.5))
    res[g] = rec
    with open(os.path.join(OUT, f'extracted_{g}.json'), 'w') as f:
        json.dump(dict(calibration=cal, **rec), f, indent=1)

if __name__ == '__main__':
    print(json.dumps(cal))
    for g in 'AB':
        r = res[g]
        print(g, 'n plateaus', len(r['plateaus']), 'ticks', len(r['ticks']), 'zero', r['drop_to_zero_t'], 'last', r['last_col_t'])
        for p in r['plateaus']:
            print(f"  {p['t0']:6.2f}-{p['t1']:6.2f} S={p['S']:.4f} occl={p['occluded_cols']} w={p['xpix'][1]-p['xpix'][0]+1}")
        print('  ticks', [(round(t['t'], 2), t['width_px'], t['mult']) for t in r['ticks']])
