"""Reconstruct participant-level (time, event) records from measured KM plateaus, censor ticks
and the number-at-risk table. Own implementation (sequential KM inversion, risk-table
constrained, in the spirit of interval-wise inversion); no KM-to-IPD package is used.

Usage: python reconstruct.py [extracted_dir] [out_csv] [--sensitivity]
Inputs: extracted_<g>.json (from extract.py), risk_table.json, ../../../input/manifest.json
"""
import sys, os, json, hashlib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith('--')]
SENS = '--sensitivity' in sys.argv
EXT = args[0] if len(args) > 0 else os.path.join(HERE, '..', 'extracted')
OUTCSV = args[1] if len(args) > 1 else os.path.join(HERE, '..', ('sensitivity.csv' if SENS else 'ipd.csv'))
MANIFEST = os.path.join(HERE, '..', '..', '..', 'input', 'manifest.json')

manifest = json.load(open(MANIFEST))
SEED = manifest['code_seed']
rng = np.random.default_rng(SEED)   # recorded; the algorithm below is deterministic
risk = json.load(open(os.path.join(HERE, 'risk_table.json')))


def load(g):
    e = json.load(open(os.path.join(EXT, f'extracted_{g}.json')))
    pl = e['plateaus']
    # KM starts at S=1 at t=0; the first visible plateau is the first post-drop level
    levels = [1.0]; times = []
    prev_t1 = 0.0
    if pl and abs(pl[0]['S'] - 1.0) < 0.004:
        prev_t1 = pl[0]['t1']; pl = pl[1:]
    for p in pl:
        times.append(0.5 * (prev_t1 + p['t0']))   # drop at the vertical segment between plateaus
        levels.append(p['S']); prev_t1 = p['t1']
    if e['drop_to_zero_t'] is not None:
        times.append(e['drop_to_zero_t']); levels.append(0.0)
    ticks = []
    for t in e['ticks']:
        if t['width_px'] >= 2:                      # 1-column hits are line-join artefacts
            ticks += [t['t']] * t['mult']
    return np.array(times), np.array(levels), sorted(ticks), e['last_col_t']


def simulate(n0, ev_t, ev_S, S_prev_hat, cens, tend):
    """Walk through drops in time order. cens: sorted censor times in the interval.
    Events at a tied time precede censorings (censored at t are at risk at t)."""
    n = n0; Shat = S_prev_hat; recs = []; ci = 0
    for t, S in zip(ev_t, ev_S):
        while ci < len(cens) and cens[ci] < t:
            recs.append((cens[ci], 0)); n -= 1; ci += 1
        if n <= 0: break
        if S <= 0: d = n
        else: d = int(round(n * (1 - S / Shat)))
        d = min(max(d, 0), n)
        recs += [(t, 1)] * d
        Shat *= (1 - d / n); n -= d
    while ci < len(cens):
        recs.append((cens[ci], 0)); n -= 1; ci += 1
    return recs, n, Shat


def allocate(ticks, c, a, b, tmax_obs):
    """Choose c censoring times in [a,b). Visible ticks are used first. If more censorings are
    required than ticks are visible (hidden/overlapping ticks), extras are spread uniformly over
    the interval (restricted to the drawn follow-up). If fewer are required, ticks are thinned
    evenly (a visible tick may represent a mis-detection; reported in diagnostics)."""
    ticks = sorted(ticks)
    if c <= len(ticks):
        if c == len(ticks): return ticks
        idx = np.round(np.linspace(0, len(ticks) - 1, c)).astype(int) if c > 0 else []
        return sorted(ticks[i] for i in idx)
    extra = c - len(ticks)
    hi = min(b, tmax_obs)
    if SENS:
        # sensitivity: hidden censorings sit at the visible tick positions (overlap multiplicity)
        # or, without ticks, at the end of the interval
        if ticks:
            ex = [ticks[k % len(ticks)] for k in range(extra)]
        else:
            ex = [hi - 0.01 * (k + 1) for k in range(extra)]
    else:
        ex = list(a + (np.arange(extra) + 0.5) * (hi - a) / extra)
    return sorted(ticks + ex)


def reconstruct(g):
    ev_times, ev_levels, ticks, tlast = load(g)
    ev_S = ev_levels[1:]
    T = risk['times']; N = risk[g]
    n0 = manifest['groups'][g]
    assert N[0] == n0
    recs = []; Shat = 1.0; diag = []
    for j in range(len(T) - 1):
        a, b = T[j], T[j + 1]
        last = (j == len(T) - 2)
        sel = (ev_times >= a) & (ev_times < b)
        et, eS = ev_times[sel], ev_S[sel]
        tk = [t for t in ticks if a <= t < b]
        c = len(tk); best = None
        for it in range(200):
            cens = allocate(tk, c, a, b, tlast)
            r, n_end, Sh = simulate(N[j], et, eS, Shat, cens, b)
            target = N[j + 1]
            diff = n_end - target
            if best is None or abs(diff) < abs(best[2]): best = (r, Sh, diff, c, cens)
            if diff == 0: break
            nc = max(0, c + diff)
            if nc == c: break
            c = nc
        r, Sh, diff, c, cens = best
        recs += r; Shat = Sh
        diag.append(dict(interval=[a, b], n_start=N[j], n_end_table=N[j + 1],
                         n_end_recon=N[j + 1] + diff, events=sum(e for _, e in r),
                         censored=c, visible_ticks=len(tk),
                         hidden_censorings_added=max(0, c - len(tk)),
                         ticks_dropped=max(0, len(tk) - c)))
    # anyone still at risk after the last risk-table interval would be unsupported follow-up
    assert len(recs) == n0, (g, len(recs))
    return recs, diag


if __name__ == '__main__':
    allrec = []; diags = {}
    for g in ['A', 'B']:
        r, d = reconstruct(g)
        diags[g] = d
        allrec += [(g, round(float(t), 4), int(e)) for t, e in sorted(r)]
    tmp = OUTCSV + '.tmp'
    with open(tmp, 'w') as f:
        f.write('group,observed_time,event\n')
        for g, t, e in allrec: f.write(f'{g},{t},{e}\n')
    os.replace(tmp, OUTCSV)   # atomic commit after both arms are complete
    dpath = os.path.join(HERE, '..', 'extracted', 'recon_diagnostics' + ('_sens' if SENS else '') + '.json')
    json.dump(dict(seed=SEED, sensitivity=SENS, intervals=diags), open(dpath, 'w'), indent=1)
    print(json.dumps(diags, indent=0))
    print('sha256', hashlib.sha256(open(OUTCSV, 'rb').read()).hexdigest())
