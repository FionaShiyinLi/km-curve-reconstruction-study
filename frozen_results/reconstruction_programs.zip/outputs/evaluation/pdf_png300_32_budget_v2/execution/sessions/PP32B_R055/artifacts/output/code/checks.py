"""Reload the committed CSV, recompute right-continuous KM per arm, compare with measured
plateaus, risk table and arm sizes; optionally compare the sensitivity file.
Usage: python checks.py   (paths relative to this file)"""
import os, json, hashlib
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..')
manifest = json.load(open(os.path.join(HERE, '..', '..', '..', 'input', 'manifest.json')))
risk = json.load(open(os.path.join(HERE, 'risk_table.json')))


def km(df):
    t = np.sort(df.observed_time.unique()); S = 1.0; out = []
    for u in t:
        n = (df.observed_time >= u).sum(); d = ((df.observed_time == u) & (df.event == 1)).sum()
        if d: S *= 1 - d / n
        out.append((u, S))
    return np.array(out)


def S_at(curve, t):  # right-continuous step function
    i = np.searchsorted(curve[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else float(curve[i, 1])


def rmst(curve, tau):
    ts = np.concatenate([[0], curve[:, 0][curve[:, 0] < tau], [tau]])
    return float(sum(S_at(curve, ts[k]) * (ts[k + 1] - ts[k]) for k in range(len(ts) - 1)))


def run(csv):
    df = pd.read_csv(csv)
    res = dict(file=os.path.basename(csv), sha256=hashlib.sha256(open(csv, 'rb').read()).hexdigest(), arms={})
    assert list(df.columns) == ['group', 'observed_time', 'event']
    for g in ['A', 'B']:
        d = df[df.group == g]
        cur = km(d)
        ext = json.load(open(os.path.join(OUT, 'extracted', f'extracted_{g}.json')))
        arm = dict(n=int(len(d)), n_expected=manifest['groups'][g],
                   n_pass=bool(len(d) == manifest['groups'][g]),
                   event_integer_01=bool(d.event.isin([0, 1]).all()),
                   times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                   events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                   supplied_event_total='unavailable (not in manifest)')
        # survival checks at the midpoint of every measured plateau (covers start and tail)
        sc = []
        for p in ext['plateaus']:
            tm = 0.5 * (p['t0'] + p['t1'])
            nr = int((d.observed_time >= tm).sum())
            r = S_at(cur, tm)
            # tolerance: 1.5 px line-centre measurement (0.002) + half a one-event KM step at this risk set
            tol = 0.002 + (0.5 * p['S'] / max(nr, 1))
            sc.append(dict(t=round(tm, 3), measured=round(p['S'], 4), recon=round(r, 4),
                           resid=round(r - p['S'], 4), tol=round(tol, 4),
                           status='pass' if abs(r - p['S']) <= tol else 'fail'))
        arm['survival_checks'] = sc
        arm['survival_max_abs_resid'] = max(abs(x['resid']) for x in sc)
        arm['survival_fail_count'] = sum(x['status'] == 'fail' for x in sc)
        # risk table: count observed_time >= t
        rt = []
        for t, n in zip(risk['times'], risk[g]):
            c = int((d.observed_time >= t).sum())
            rt.append(dict(t=t, table=n, recon=c, resid=c - n, status='pass' if c == n else 'fail'))
        arm['risk_table_checks'] = rt
        arm['max_followup'] = float(d.observed_time.max())
        arm['last_drawn_t'] = ext['last_col_t']
        res['arms'][g] = arm
    return res, df


if __name__ == '__main__':
    main, dfm = run(os.path.join(OUT, 'ipd.csv'))
    out = dict(primary=main,
               tolerance_note='survival tol = 0.002 (1.5 px of 750 px/unit, line-centre reading) + 0.5*S/n_risk (half a single-event KM step); risk counts must match exactly',
               risk_table_reading='visual reading of printed integers; all clearly legible')
    sp = os.path.join(OUT, 'sensitivity.csv')
    if os.path.exists(sp):
        sens, dfs = run(sp)
        tau = min(main['arms']['A']['max_followup'], main['arms']['B']['max_followup'],
                  sens['arms']['A']['max_followup'], sens['arms']['B']['max_followup'])
        cmp = dict(horizon=tau)
        for g in 'AB':
            cp, cs = km(dfm[dfm.group == g]), km(dfs[dfs.group == g])
            cmp[g] = dict(S_primary={t: round(S_at(cp, t), 4) for t in [6, 12, 18, 24, 30, round(tau, 3)]},
                          S_sens={t: round(S_at(cs, t), 4) for t in [6, 12, 18, 24, 30, round(tau, 3)]},
                          RMST_primary=round(rmst(cp, tau), 3), RMST_sens=round(rmst(cs, tau), 3))
        out['sensitivity'] = dict(file_sha256=sens['sha256'],
                                  risk_all_pass={g: all(x['status'] == 'pass' for x in sens['arms'][g]['risk_table_checks']) for g in 'AB'},
                                  comparison=cmp)
    else:
        out['sensitivity'] = 'not run'
    json.dump(out, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
    for g in 'AB':
        a = main['arms'][g]
        print(g, a['n'], a['events'], a['censored'], 'maxres', a['survival_max_abs_resid'], 'fails', a['survival_fail_count'],
              [x['status'] for x in a['risk_table_checks']])
        print('  fails:', [x for x in a['survival_checks'] if x['status'] == 'fail'])
    print(main['sha256']); print(json.dumps(out['sensitivity'])[:1500])
