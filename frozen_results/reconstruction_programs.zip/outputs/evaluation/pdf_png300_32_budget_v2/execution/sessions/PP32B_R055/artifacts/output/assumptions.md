# Reconstruction assumptions and method

## Inputs used
- `../input/figure.png` (1800x1350 raster KM plot, two arms, censor ticks, number-at-risk table).
- `../input/manifest.json`: n = 100 per arm, time in months, code seed 1167394772 (recorded in the code; the algorithm is deterministic, so the seed does not affect the output).
- The number-at-risk table was read visually, and all entries were clearly legible: A 100/62/44/27/19/6/0 and B 100/80/54/46/34/14/0 at 0/6/12/18/24/30/36 months (`code/risk_table.json`).
- No arm-specific event totals are supplied. The event totals in the output come from the reconstruction and are not constrained by any supplied total.

## Measurement (`code/extract.py`)
- **Calibration** uses linear fits to the labelled tick marks, found by pixel search. The x ticks at 0–36 give 40 px/month, and the y ticks at 0–1 give 750 px per unit; the fit residuals are 0. No global rescaling or origin correction is applied. Both arms have level 1.0 at the origin, and their first measured plateaus are 0.98 for A and 0.99 for B.
- **Curves** are isolated by their exact RGB colors; the figure has no antialiasing. A pixel counts as part of a horizontal line only if it is colored at ±3 columns. The level of each column is the center of the 4-px line, and adjacent columns within 1 px are grouped into plateaus. The drop time is placed at the midpoint of the gap between two plateaus, which is where the vertical segment is drawn.
- **Occlusion:** B is drawn over A before about 1.5 months. Where an A column is completely hidden, it takes B's level. Plateaus that break monotonicity, or that are entirely borrowed from B and at most 2 px wide, are discarded. As a result, the early timing of A's drops is uncertain to about ±0.15 months, and one short A plateau (0.96) is not seen. Its two drops are merged into a single tied drop of d = 2, which leaves the survival levels unchanged.
- **Censor ticks** are 2-px-wide vertical marks rising 6 px above the line. A group of marks 5 px wide or more is counted as 2 overlapping ticks. Ticks that exactly coincide with each other, or that fall inside a vertical drop, cannot be seen. Visible ticks are counted as a lower bound, not an exact count.
- Measured plateaus and ticks are saved in `extracted/extracted_A.json` and `extracted/extracted_B.json`.

## Reconstruction (`code/reconstruct.py`, own implementation)
- The risk-table intervals [0,6), [6,12), …, [30,36) are processed in order. At each measured drop, d = round(n_risk × (1 − S_after / Ŝ_before)), where Ŝ is the reconstructed KM up to that point, so rounding errors do not accumulate. Events are processed before censorings at tied times. The number of drops of each size is therefore not assumed to be 1; d is derived from the size of the drop and the current risk set.
- Within each interval, the number of censorings is adjusted until the count at the end of the interval equals the risk-table value. Visible ticks are used first. Any additional censorings that are needed are an **assumption**: they are placed uniformly across the interval, in the same way as Guyot et al.'s method. This happened in three intervals: A [6,12) +1, B [12,18) +1 and B [24,30) +2. No visible tick had to be removed.
- **Tail:** A's line ends with a censor tick at 35.8 months, and the 6 participants still at risk at 30 months are all censored at visible ticks. B's line drops vertically to 0 at 35.2 months, which is read as an event for the last participant at risk. Some or all of the B participants censored at 30–35 months could in principle have had censorings that are not displayed, but the risk count of 0 at 36 means nobody is placed at or beyond 36. The reconstruction does not extend follow-up beyond the drawn curves.
- Reconstructed totals are A: 78 events and 22 censored; B: 71 events and 29 censored.

## Verification (`code/checks.py` → `checks.json`)
- The script reloads the committed CSV and recomputes the right-continuous KM curve, then compares it with the measured level at the midpoint of every plateau, from the first to the last (59 per arm). The tolerance is 0.002 for the line-center reading plus half of a single-event KM step. Every check passes, with a maximum absolute residual of 0.0011 for A and 0.0030 for B.
- The number at risk (observed_time ≥ t) matches the table exactly at all 7 time points for both arms.
- Both arms have n = 100, all event indicators are integers 0 or 1, and all times are finite and nonnegative.

## Limitations
- The records are one feasible reconstruction, not a unique recovery. The exact times of censorings added to meet the risk table are unknown; within the interval they could lie anywhere without changing the plotted curve by more than one tick. Hidden coincident ticks and early A drop times hidden under B are also unidentified.
- No censoring distribution, accrual pattern or event-free follow-up is inferred from the flat tails. Reported uncertainty from analyses of these records does not include reconstruction error.

## Sensitivity analysis (one alternative allocation, `sensitivity.csv`)
- **Assumption:** censorings added to meet the risk table are placed at the visible tick positions in the same interval, as if they were overlapping ticks. Where an interval has no tick (B [12,18)), they go at the end of the interval. The primary instead places them uniformly. Everything else is unchanged, and all risk counts still match exactly.
- **Comparison** at the common supported horizon τ = 35.225 months, B's last observation (from `checks.json`). Restricted mean survival time (RMST) to τ is 13.921 (primary) vs 13.911 (sensitivity) for A and 18.319 vs 18.294 for B. S(30) is 0.1513 vs 0.1511 for A and 0.302 vs 0.298 for B.
- Only 4 censorings are allocated differently, so the two versions differ by very little. This is one alternative, not a bound on reconstruction error. In particular, it does not vary the hidden early drop times in A or allow for coincident ticks within intervals that already reconcile.
- `work_img/overlay.png` shows the reconstructed KM curve plotted over the source figure for visual inspection.
