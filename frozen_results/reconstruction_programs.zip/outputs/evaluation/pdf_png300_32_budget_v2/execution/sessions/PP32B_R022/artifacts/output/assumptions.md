# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (a vector PDF) and `../input/manifest.json`, which gives N = 1000 per arm, time in months and seed 1153859518. The manifest has no event totals, so the check against supplied event totals is marked unavailable.

**Run order (from `work/`):**
1. `python output/code/extract.py ../input/figure.pdf output`
2. `python output/code/reconstruct.py ../input/manifest.json output`
3. `python output/code/checks.py output ../input/manifest.json`

## Measurement
- **Source objects:** the KM curves are PDF path objects, and each censor mark is a separate 4-pt vertical line object. I read them with pdfplumber; no pixels were used. Group identity comes from the legend-line colors: A is blue and B is orange.
- **Calibration:** time and survival were calibrated by linear fit to the labelled axis tick marks (7 time ticks at 0–36, 6 survival ticks at 0–1). Residuals were below 1e-13, so no global correction was applied.
- **Origin:** each curve starts exactly at (0, 1.000). The first drops (to 0.999, 0.998, …) are genuine early events and were kept.
- **Curve shape:** each curve is a pure step function with no diagonal segments. Arm A has 788 vertical drops and arm B has 702. There are 212 censor ticks in A and 298 in B. No two ticks share the same x.
- **Extracted data:** saved in `output/extracted.json`.

## Algorithm
Both arms were processed in time order, with events placed before censorings at tied times.
- **Censoring:** each tick removes one participant from the risk set as a censoring at the tick's x-time.
- **Events:** at each drop, the event count is `d = round(n_risk·(1 − S_after/S_before))`, where n_risk comes from the records built so far. d was not fixed at 1 in advance.
- **Result:** every drop resolved to d = 1. The largest |d̂ − d| was 5e-4 in either arm, so the implied risk sets agree with the tick-based risk sets at every drop.
- **Totals:** events plus ticks equal exactly 1000 in each arm (A: 788 + 212; B: 702 + 298). No participant was left unassigned, so no end-of-follow-up censoring had to be invented.
- **Randomness:** none is used. The seed is still set and recorded.

## Censoring and risk table
- **Tick multiplicity:** I assumed each drawn tick is one censoring. Two things support this: drops plus ticks reconcile exactly to N, and all 7 risk-table counts per arm are reproduced exactly.
- **Risk-table convention:** a record counts as at risk at t if `observed_time >= t`. At t = 36 the table shows 0 at risk, and no record has observed_time ≥ 36. The largest times are A 35.955 and B 35.997.

## Verification
Results are in `output/checks.json`, which includes the CSV SHA-256.
- **Survival curve:** I reloaded the CSV, recomputed the right-continuous KM, and compared it with the extracted step curve at the midpoint of every flat segment. The maximum absolute difference was 2.8e-7 in both arms.
- **Grid checks:** 18 grid times from 0.5 to 35.9 months, including the tail, all pass at a tolerance of 1e-4. This tolerance is loose relative to the roughly 1e-6 coordinate precision.
- **Evaluation point:** I checked at segment midpoints because evaluating exactly at a jump is sensitive to 1e-15 float round-trip error in the CSV.
- **Visual check:** `output/overlay.png`.

## Limitations
- **Time precision:** times are limited by the PDF coordinate precision, about 1e-6 months.
- **Hidden multiplicity:** if the plotting software drew a single tick for several censorings at an identical time, or one drop for several tied events, this would not be visible. However, either would break the exact reconciliation with N and the risk table that was observed. The reconstruction is consistent with every supplied constraint, but I don't claim it is the unique original dataset.
- **Sensitivity analysis:** not run. No materially different censor/event allocation is consistent with the inputs, because the tick count, drop count, N and risk table are all jointly satisfied with no residual.
