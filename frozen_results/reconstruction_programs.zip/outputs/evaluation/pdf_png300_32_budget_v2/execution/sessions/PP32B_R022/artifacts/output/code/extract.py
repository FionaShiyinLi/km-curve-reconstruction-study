"""Extract KM step curves and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
p = pdfplumber.open(pdf).pages[0]
H = p.height
# axis calibration from labelled tick marks (PDF bottom-up coordinates)
xt = sorted({round(l['x0'], 3) for l in p.lines if l['stroking_color'] == (0.0, 0.0, 0.0) and l['x0'] == l['x1'] and abs(l['y1'] - l['y0']) < 4})
yt = sorted({round(l['y0'], 3) for l in p.lines if l['stroking_color'] == (0.0, 0.0, 0.0) and l['y0'] == l['y1'] and abs(l['x1'] - l['x0']) < 4})
tlab = [0, 6, 12, 18, 24, 30, 36]; slab = [0, .2, .4, .6, .8, 1.0]
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
import numpy as np
ax, bx = np.polyfit(xt, tlab, 1); ay, by = np.polyfit(yt, slab, 1)
T = lambda x: ax * x + bx
S = lambda ybu: ay * ybu + by
res = {'calib': {'x_ticks': xt, 'y_ticks': yt, 'x_resid': list(np.array(xt) * ax + bx - tlab), 'y_resid': list(np.array(yt) * ay + by - slab)}}
# legend: 1.0-width short lines near the "Group A"/"Group B" words
words = p.extract_words()
leg = [l for l in p.lines if l['linewidth'] == 1.0]
colmap = {}
for w in words:
    if w['text'] in ('A', 'B') and w['top'] < 40:
        l = min(leg, key=lambda l: abs(l['x1'] - w['x0']))
        colmap[str(l['stroking_color'])] = w['text']
res['legend'] = {c: g for c, g in colmap.items()}
for c in p.curves:
    g = colmap[str(c['stroking_color'])]
    pts = [(T(x), S(H - y)) for x, y in c['pts']]  # curve pts are top-down
    ticks = sorted([(T(l['x0']), S((l['y0'] + l['y1']) / 2), S(l['y0']), S(l['y1'])) for l in p.lines
                    if str(l['stroking_color']) == str(c['stroking_color']) and l['linewidth'] == 0.65])
    res[g] = {'vertices': pts, 'ticks': ticks}
json.dump(res, open(f'{out}/extracted.json', 'w'))
print(res['calib'], res['legend'])
for g in 'AB':
    print(g, len(res[g]['vertices']), len(res[g]['ticks']), res[g]['vertices'][:4], res[g]['vertices'][-3:])
