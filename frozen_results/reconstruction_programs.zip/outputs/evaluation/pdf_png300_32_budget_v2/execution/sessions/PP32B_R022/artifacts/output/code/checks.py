"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table.
Usage: python checks.py [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
man = json.load(open('../input/manifest.json' if len(sys.argv) < 3 else sys.argv[2]))
df = pd.read_csv(f'{out}/ipd.csv'); r = json.load(open(f'{out}/extracted.json'))
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
risk_times = [0, 6, 12, 18, 24, 30, 36]
risk_tab = {'A': [1000, 663, 469, 309, 217, 89, 0], 'B': [1000, 727, 519, 391, 294, 109, 0]}  # read from PDF text
def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; S = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; S.append(s)
    return ts, np.array(S)
def step(ts, S, t):  # right-continuous
    i = np.searchsorted(ts, t, side='right') - 1
    return 1.0 if i < 0 else S[i]
def curve(v, t):  # measured PDF step curve, right-continuous value at t
    v = np.array(v); val = v[0, 1]
    for x, y in v:
        if x <= t + 1e-12: val = y
        else: break
    return val
TOL_S = 1e-4  # vector coordinates carry ~1e-6 precision in S; 1e-4 allows for rounding accumulation
res = {'csv_sha256': sha, 'tolerance_survival': TOL_S, 'groups': {}}
for g in 'AB':
    d = df[df.group == g]; ts, S = km(d); v = r[g]['vertices']
    grid = [0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, 35.9]
    sc = []
    for t in grid:
        m, k = curve(v, t), step(ts, S, t)
        sc.append({'t': t, 'measured': round(m, 6), 'reconstructed': round(k, 6), 'resid': round(k - m, 7), 'status': 'pass' if abs(k - m) < TOL_S else 'fail'})
    # exhaustive: at every vertex x (just after), compare
    xs = np.unique([x for x, _ in v]) ; mids = (xs[:-1] + xs[1:]) / 2  # midpoints of flat segments (avoid knife-edge at jumps)
    allres = float(max(abs(step(ts, S, x) - curve(v, x)) for x in mids))
    rk = []
    for t, obs in zip(risk_times, risk_tab[g]):
        n = int((d.observed_time >= t).sum())
        rk.append({'t': t, 'observed': obs, 'reconstructed': n, 'resid': n - obs, 'status': 'pass' if n == obs else 'fail'})
    res['groups'][g] = {'n': len(d), 'n_expected': man['groups'][g], 'events': int(d.event.sum()),
        'event_indicator_integer_01': bool(d.event.isin([0, 1]).all()),
        'supplied_event_total': 'unavailable (not in manifest)',
        'n_censor_ticks_drawn': len(r[g]['ticks']), 'n_censored_records': int((d.event == 0).sum()),
        'max_time': float(d.observed_time.max()),
        'survival_checks': sc, 'max_abs_resid_all_flat_segment_midpoints': allres, 'n_segments_checked': len(mids),
        'risk_table_checks': rk}
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1, default=float)
for g in 'AB':
    x = res['groups'][g]
    print(g, x['n'], x['events'], x['max_abs_resid_all_flat_segment_midpoints'], [c['status'] for c in x['survival_checks']].count('fail'), [(c['observed'], c['reconstructed']) for c in x['risk_table_checks']])
print(sha)
