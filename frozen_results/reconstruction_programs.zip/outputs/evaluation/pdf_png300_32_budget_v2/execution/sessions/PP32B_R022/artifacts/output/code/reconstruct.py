"""Reconstruct IPD from the vector-extracted KM curves (run extract.py first).
Usage: python reconstruct.py [manifest.json] [outdir]
Algorithm: walk the step curve in time order. Censor ticks (one record per drawn tick)
remove participants from the risk set; at each vertical drop the event count is
d = round(n_risk * (1 - S_after/S_before)), with n_risk taken from the records built so far
(events before censorings at tied times). No randomness is used; seed recorded for completeness."""
import sys, os, json, numpy as np, pandas as pd
man = json.load(open(sys.argv[1] if len(sys.argv) > 1 else '../input/manifest.json'))
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
SEED = man['code_seed']; np.random.seed(SEED)
r = json.load(open(f'{out}/extracted.json'))
recs, diag = [], {}
for g in 'AB':
    N = man['groups'][g]
    v = np.array(r[g]['vertices'])
    drops = [(v[i, 0], v[i - 1, 1], v[i, 1]) for i in range(1, len(v))
             if abs(v[i, 0] - v[i - 1, 0]) < 1e-9 and v[i, 1] < v[i - 1, 1] - 1e-9]
    ticks = [t[0] for t in r[g]['ticks']]
    # merge: (time, kind) with events (kind 0) before censorings (kind 1) at ties
    evs = sorted([(t, 0, a, b) for t, a, b in drops] + [(t, 1, None, None) for t in ticks])
    n = N; rows = []; resid = []
    for t, kind, a, b in evs:
        if kind == 1:
            if n <= 0: raise RuntimeError(f'{g}: tick at {t} with empty risk set')
            rows.append((g, t, 0)); n -= 1
        else:
            dhat = n * (1 - b / a); d = int(round(dhat))
            resid.append((t, n, dhat, d))
            if d < 1 or d > n: raise RuntimeError(f'{g}: infeasible drop at {t}: n={n} dhat={dhat}')
            rows += [(g, t, 1)] * d; n -= d
    t_end = v[-1, 0]
    diag[g] = {'n_drops': len(drops), 'n_ticks': len(ticks), 'events': sum(x[3] for x in resid),
               'max_abs_d_resid': float(max(abs(x[2] - x[3]) for x in resid)),
               'd_values': sorted(set(x[3] for x in resid)), 'left_after_last_mark': n, 'curve_end_time': float(t_end)}
    if n > 0:
        # participants not accounted for by ticks: censor at end of drawn curve (assumption)
        rows += [(g, float(t_end), 0)] * n
    recs += rows
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
assert (df.groupby('group').size() == pd.Series(man['groups'])).all()
tmp = f'{out}/ipd.csv.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(diag, open(f'{out}/reconstruction_diag.json', 'w'), indent=1)
print(json.dumps(diag, indent=1))
