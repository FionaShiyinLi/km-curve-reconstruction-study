# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json`. The manifest gives n = 1000 per arm, time in months and seed 1138292175. It supplies **no arm-specific event totals**, so none were used. The number-at-risk table was read by eye from the figure:

- A: 1000, 657, 459, 322, 209, 69, 0
- B: 1000, 659, 544, 434, 366, 162, 0

These are at 0, 6, …, 36 months. The digits are crisp and I consider the reading reliable.

**Reproduce:** run these from the work directory:

- `python3 output/code/reconstruct.py` (primary)
- `python3 output/code/reconstruct.py --alt` (sensitivity)
- `python3 output/code/checks.py`

The `--input` and `--out` arguments are available. The algorithm is deterministic. The seed is set and recorded, but no random draws are used.

## Measurement

- **Calibration.** Time and survival are mapped linearly from the axis tick marks: x = 0 to 36 months at pixel columns 269.5 to 1709.5, i.e. 40 px per month; y = 1.0 at row 179.5 and y = 0.0 at row 929.5. The intermediate ticks are equally spaced at 240 px and 150 px, so they support the linear map. No global rescaling was applied to either arm.
- **Curve.** Pixels are selected by exact line colour; the plot is not antialiased. The line is about 4 px thick.
  - The line edges are estimated as monotone envelopes: the bottom edge is the minimum from the right and the top edge the maximum from the left. Ticks only protrude beyond these envelopes locally.
  - Where an edge adjoins the other arm's colour, it is treated as occluded and not used; B is drawn over A near the origin and the crossing at about 6 months.
  - Level = bottom edge − half-width where the bottom is reliable, otherwise top edge + half-width. In tick columns the level is the centre of the tick, since ticks are symmetric about the line.
  - The levels are then fitted by weighted isotonic regression (not a running minimum). Unresolved columns take the next resolved level, which puts the drop at that column.
  - Per-column output is in `curve_A.csv` and `curve_B.csv`; tick positions are in `ticks_*.csv`.
- **Origin.** S(0) = 1 by definition.
  - A: the first 0.15 months are mostly hidden under B. A symmetric tick at about 0.06 months is centred at S ≈ 0.9967, and the line is at S ≈ 0.993 by 0.18 months. These imply about 3 events before 0.06 months. They are placed at the first column (0.0125 months), which is an assumption.
  - B: B's line leaves 1.0 within the first column. That genuine early drop is preserved rather than flattened.
- **Censor ticks.** A tick is a column where the run protrudes at least 3 px beyond an envelope, or a run reaching above the S = 1 line. Clusters of w adjacent tick columns are counted as ceil(w/3) ticks, because a single tick is 3 px wide. This is a **lower bound on visibility, not multiplicity**: coincident or overlapping ticks cannot be counted, which matters especially after 24 months, where ticks are dense.

## Reconstruction algorithm (own implementation)

This is an interval-wise, Guyot-type approach.

1. **Search per interval.** For each risk interval [t_k, t_{k+1}), search over the integer number of censorings c. For each c, walk the pixel-column grid:
   - At each column, d = round(n_risk · (1 − S_measured/Ŝ)). Here Ŝ is the reconstructed KM value, so rounding does not accumulate.
   - Censorings at that column are removed after events (events first at ties).
   - The smallest c that brings the number at risk at t_{k+1} to the displayed count is chosen.
2. **Placing censorings (assumption).** Censorings go at detected tick times. If c exceeds the visible ticks, the extras are spread evenly over those ticks. If c is smaller, an evenly spaced subset of ticks is used. If an interval has no ticks, censorings are spread evenly across it.
3. **Last interval.** In 30–36 months, everyone remaining is censored by the last plotted time (A 35.91, B 35.96 months). This makes n(36) = 0 hold with every time below 36. The endpoint follows from the plotted extent and the displayed zero; follow-up beyond the plot was not assumed.
4. **Event multiplicity.** Multiple events per column are allowed. The number is set by the measured relative drop, not by assuming d = 1. One pixel is 0.0013 in S, roughly 1–2 events early on and less than 1 event late. Individual event times within a column are therefore not identifiable; events are recorded at the column time, a 0.025-month grid.

## Results and checks (`checks.json`)

- **Events:** A 786 and B 619. These are derived, not supplied.
- **Risk counts:** all 14 displayed counts are reproduced exactly using observed_time ≥ t.
- **Curve agreement:** the KM curve recomputed from the committed CSV matches the measured curve within 0.001 at 22 times per arm, including 0.25–0.5 months and 33–35.9 months. The exception is B at 0.5 months, where the difference is 0.008. That is a one-column time-registration difference on a steep segment, and it is accepted under the ±1-column rule stated in `checks.json`. The tolerance is ±3 px (0.004): half the line width plus 1 px of edge quantisation.

## Sensitivity (one alternative, run)

`sensitivity.csv` places censorings evenly within each interval and ignores the ticks. Over the common supported horizon of 35.8 months:

| | RMST, primary | RMST, alternative | Events, primary | Events, alternative |
|---|---|---|---|---|
| A | 14.679 | 14.677 | 786 | 789 |
| B | 18.508 | 18.507 | 619 | 619 |

S(t) differs by at most 0.001 at 6, 12, 18, 24, 30 and 35.8 months. This single alternative is not a bound on reconstruction error.

## Unresolved limitations

- Censoring times within intervals, and tick multiplicity in the dense regions after 24 months, are not identified; the risk table only fixes interval totals.
- Tied or subpixel event timing is unresolved.
- The early A curve under B (before about 0.15 months) and the curve crossing at about 6 months are partly occluded; the levels there come from neighbouring or tick-centre evidence.
- No event totals were supplied, so the event counts are unverified beyond agreement with the curve.
