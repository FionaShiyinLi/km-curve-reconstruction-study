#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python3 reconstruct.py [--input ../input] [--out output] [--alt]
Steps: (1) calibrate axes from labelled tick anchors, (2) extract each arm's
step curve per pixel column by colour, (3) detect censor ticks, (4) allocate
events/censorings per risk-table interval so that the reconstructed KM tracks
the measured curve and the at-risk counts are reproduced.
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
from PIL import Image

SEED = 1138292175
rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
ap.add_argument("--alt", action="store_true",
                help="sensitivity: censor uniformly within intervals, ignoring ticks")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
man = json.load(open(os.path.join(args.input, "manifest.json")))
img = np.asarray(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(int)

# ---- 1. calibration: labelled anchors (read from the figure) ----
# x ticks 0,6,...,36 at pixel columns 269/270 ... 1709/1710 -> centres 269.5+40k
# y ticks 1.0 at rows 179/180, 0.0 at rows 929/930 (0.2 steps every 150 px)
X0, PX_PER_MONTH = 269.5, 40.0
Y1, Y0 = 179.5, 929.5
def t_of(x): return (x - X0) / PX_PER_MONTH
def s_of(y): return (Y0 - y) / (Y0 - Y1)
def y_of(s): return Y0 - s * (Y0 - Y1)

# risk table read visually from the figure
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 657, 459, 322, 209, 69, 0],
        "B": [1000, 659, 544, 434, 366, 162, 0]}
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
YTOP, YBOT = 168, 936  # plot panel rows (excludes legend)
XL, XR = 270, 1712

def isotonic_increasing(y, w):
    """Pool-adjacent-violators, non-decreasing fit (pixel row increases as S falls)."""
    blocks = []  # [mean, weight, count]
    for yi, wi in zip(y, w):
        blocks.append([yi, wi, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            m2, w2, c2 = blocks.pop(); m1, w1, c1 = blocks.pop()
            blocks.append([(m1 * w1 + m2 * w2) / (w1 + w2), w1 + w2, c1 + c2])
    out = []
    for m, _, c in blocks: out += [m] * c
    return np.array(out)

def extract(g):
    mask = np.abs(img - np.array(COL[g])).sum(2) < 60
    other = np.abs(img - np.array(COL["B" if g == "A" else "A"])).sum(2) < 60
    for m_ in (mask, other):
        m_[:YTOP] = False; m_[YBOT:] = False
    xs = np.arange(XL, XR)
    top = np.full(len(xs), np.nan); bot = np.full(len(xs), np.nan)
    occ_t = np.zeros(len(xs), bool); occ_b = np.zeros(len(xs), bool)
    for i, x in enumerate(xs):
        r = np.where(mask[:, x])[0]
        if len(r):
            top[i], bot[i] = r.min(), r.max()
            # edge adjoining the other arm's colour may be occluded -> unreliable
            occ_b[i] = other[int(bot[i]) + 1:int(bot[i]) + 4, x].any()
            occ_t[i] = other[max(int(top[i]) - 3, 0):int(top[i]), x].any()
        else:
            occ_t[i] = occ_b[i] = other[YTOP:YBOT, x].any()
    xmax_i = np.where(~np.isnan(top))[0].max()
    sl = slice(0, xmax_i + 1)
    xs, top, bot, occ_t, occ_b = xs[sl], top[sl], bot[sl], occ_t[sl], occ_b[sl]
    L = bot - top + 1
    cleanL = (L <= 7) & ~occ_t & ~occ_b
    hw = float(np.median((bot - top)[cleanL]) / 2)  # half line width in px
    # monotone line-edge envelopes: line rows are non-decreasing in x; ticks only
    # push bottom down / top up locally, so min-from-right of bottom and
    # max-from-left of top recover the line edges.  Occluded edges are skipped.
    bref = np.where(occ_b | np.isnan(bot), np.inf, bot)
    tref = np.where(occ_t | np.isnan(top), -np.inf, top)
    env_b = np.minimum.accumulate(bref[::-1])[::-1]
    env_t = np.maximum.accumulate(tref)
    # ticks: local excursion >=3 px beyond an envelope (tick arms reach ~6 px
    # beyond the line edge; on steep segments the neighbouring drop eats 1-3 px;
    # colours are unantialiased so plain line edges show no such excursions)
    with np.errstate(invalid="ignore"):
        below = np.isfinite(bref) & (bref - env_b >= 3)
        above = np.isfinite(tref) & (env_t - tref >= 3)
    # a run reaching above the S=1 line's top edge cannot be the curve itself
    # (no left context exists for the envelope test at the origin)
    with np.errstate(invalid="ignore"):
        above_one = np.isfinite(top) & (top < Y1 - hw - 2)
    istick = below | above | above_one
    lev_b = env_b - hw; lev_t = env_t + hw
    # per column: bottom-edge level where this column's bottom is unoccluded,
    # else top-edge level where its top is unoccluded, else unresolved
    lev = np.full(len(xs), np.nan)
    okb = np.isfinite(bref) & ~istick; okt = np.isfinite(tref) & ~istick
    lev[okt] = lev_t[okt]; lev[okb] = lev_b[okb]
    # tick columns: tick arms are symmetric about the line -> run centre
    tk = istick & ~occ_t & ~occ_b & (L >= 12)
    lev[tk] = ((top + bot) / 2)[tk]
    known = np.isfinite(lev)
    w = np.where(okb, 1.0, 0.5)[known]
    fit = np.full(len(xs), np.nan)
    fit[known] = isotonic_increasing(lev[known], w)
    nxt = np.nan  # unresolved columns take the next resolved level (drop placed there)
    for i in range(len(xs) - 1, -1, -1):
        if known[i]: nxt = fit[i]
        elif not np.isnan(nxt): fit[i] = nxt
    lev = np.maximum(fit, Y1)  # cannot exceed S=1
    ticks = []; i = 0
    while i < len(xs):
        if istick[i]:
            j = i
            while j + 1 < len(xs) and istick[j + 1]: j += 1
            wdt = j - i + 1
            m = max(1, int(np.ceil(wdt / 3)))  # min number of 3-px ticks covering width
            cen = np.linspace(xs[i] + 1, xs[j] - 1, m) if m > 1 else [(xs[i] + xs[j]) / 2]
            ticks += [float(c) for c in cen]
            i = j + 1
        else: i += 1
    curve = pd.DataFrame({"x": xs, "time": t_of(xs), "top": top, "bottom": bot,
                          "occl_top": occ_t, "occl_bot": occ_b, "env_top": env_t, "env_bot": env_b,
                          "S_from_bottom": s_of(lev_b), "S_from_top": s_of(lev_t),
                          "tick": istick, "S": s_of(lev)})
    curve.attrs["hw"] = hw
    return curve, np.array(ticks)

def simulate(times, S, n0, cens_times, eps_end=None):
    """Walk the column grid; events tracking S, censorings at cens_times (events first at ties)."""
    ct = np.sort(np.asarray(cens_times, float))
    n = n0; Shat = 1.0; recs = []; k = 0
    for t, s in zip(times, S):
        if n > 0 and s < Shat:
            d = int(round(n * (1 - s / Shat)))
            d = min(max(d, 0), n)
            if d:
                recs += [(t, 1)] * d; Shat *= (1 - d / n); n -= d
        while k < len(ct) and ct[k] <= t + 1e-12:
            if n > 0: recs.append((ct[k], 0)); n -= 1
            k += 1
    while k < len(ct):  # censor times beyond last column
        if n > 0: recs.append((ct[k], 0)); n -= 1
        k += 1
    return recs, n, Shat

def alloc_censor(c, ticks, a, b, alt):
    """Place c censoring times in [a,b). Primary: at detected tick positions."""
    if c <= 0: return []
    if alt or len(ticks) == 0:
        return list(a + (np.arange(c) + 0.5) * (b - a) / c)
    ticks = np.sort(ticks)
    m = len(ticks)
    if c <= m:
        idx = np.round(np.linspace(0, m - 1, c)).astype(int) if c > 1 else [m // 2]
        return list(ticks[idx])
    # more censorings than visible ticks: one per tick, extras spread evenly over ticks
    extra = c - m
    rep = np.ones(m, int) + np.diff(np.round(np.linspace(0, extra, m + 1)).astype(int))
    return list(np.repeat(ticks, rep))

def reconstruct(g, curve, ticks_x, alt=False):
    times = curve.time.values; S = curve.S.values
    tick_t = t_of(ticks_x)
    n_start = RISK[g][0]; recs_all = []; report = []
    Scur = 1.0
    for k in range(len(RISK_T) - 1):
        a, b = RISK_T[k], RISK_T[k + 1]
        target = RISK[g][k + 1]
        last = (k == len(RISK_T) - 2)
        sel = (times >= a) & (times < b)
        tt = tick_t[(tick_t >= a) & (tick_t < b)]
        if last:
            tmax = times[sel].max()
            tt = tt[tt <= tmax]
            bb = tmax + 1e-9
        else:
            bb = b
        # express interval target curve relative to KM level at interval start
        Srel = S[sel] / Scur
        best = None
        for c in range(0, n_start + 1):
            ct = alloc_censor(c, tt, a, bb if not last else tmax, alt)
            recs, n_end, Sh = simulate(times[sel], Srel, n_start, ct)
            diff = n_end - target
            if best is None or abs(diff) < abs(best[1]): best = (c, diff, recs, n_end, Sh)
            if diff <= 0: break
        c, diff, recs, n_end, Sh = best
        if last and n_end > 0:  # anything left must leave before 36: censor at last column time
            recs += [(times[sel].max(), 0)] * n_end; n_end = 0
        d = sum(1 for r in recs if r[1] == 1)
        report.append({"interval": [a, b], "n_start": n_start, "n_end_target": target,
                       "n_end_recon": n_end, "events": d, "censored": len(recs) - d,
                       "visible_ticks": int(len(tt))})
        recs_all += recs; n_start = n_end
        Scur = Scur * Sh
    return recs_all, report

out_rows = []; reports = {}
for g in ["A", "B"]:
    curve, ticks = extract(g)
    if not args.alt:
        curve.to_csv(os.path.join(args.out, f"curve_{g}.csv"), index=False)
        pd.DataFrame({"x": ticks, "time": t_of(ticks)}).to_csv(os.path.join(args.out, f"ticks_{g}.csv"), index=False)
    recs, rep = reconstruct(g, curve, ticks, alt=args.alt)
    assert len(recs) == man["groups"][g], (g, len(recs))
    reports[g] = rep
    out_rows += [(g, round(float(t), 4), int(e)) for t, e in recs]

df = pd.DataFrame(out_rows, columns=["group", "observed_time", "event"])
name = "sensitivity.csv" if args.alt else "ipd.csv"
tmp = os.path.join(args.out, name + ".tmp")
df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(args.out, name))
json.dump(reports, open(os.path.join(args.out, ("alt_" if args.alt else "") + "interval_report.json"), "w"), indent=1)
print(json.dumps(reports, indent=1))
print("sha256", hashlib.sha256(open(os.path.join(args.out, name), "rb").read()).hexdigest())
