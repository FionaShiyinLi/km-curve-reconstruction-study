#!/usr/bin/env python3
"""Reload committed IPD, recompute right-continuous KM, compare with measured curve,
risk table and sizes; compare sensitivity file if present. Writes checks.json."""
import argparse, json, os, hashlib
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
args = ap.parse_args()
man = json.load(open(os.path.join(args.input, "manifest.json")))
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 657, 459, 322, 209, 69, 0], "B": [1000, 659, 544, 434, 366, 162, 0]}
CHECK_T = [0.25, 0.5, 1, 2, 3, 4, 5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, 35.9]
# tolerance: +-3 px vertical (half line width 2 px + 1 px edge quantisation) = 0.004,
# plus one-column (0.025 mo) time misregistration on steep parts, evaluated below
PX = 1 / 750

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = []; s = 1.0
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n; S.append(s)
    return ut, np.array(S)

def S_at(ut, S, x):  # right-continuous step function
    i = np.searchsorted(ut, x, side="right") - 1
    return 1.0 if i < 0 else float(S[i])

def rmst(ut, S, h):
    grid = np.concatenate([[0], ut[ut < h], [h]]); vals = [1.0] + [S_at(ut, S, g) for g in grid[1:-1]]
    return float(np.sum(np.diff(grid) * np.array(vals)))

path = os.path.join(args.out, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
ipd = pd.read_csv(path)
out = {"csv": "output/ipd.csv", "sha256": sha, "columns_ok": list(ipd.columns) == ["group", "observed_time", "event"],
       "tolerance_note": "curve: |resid| <= 3 px (0.004) or within the measured range over +-1 column (0.025 mo); risk counts: exact",
       "arms": {}}
for g in ["A", "B"]:
    d = ipd[ipd.group == g]
    cur = pd.read_csv(os.path.join(args.out, f"curve_{g}.csv"))
    ut, S = km(d)
    arm = {"n": int(len(d)), "n_expected": man["groups"][g], "n_pass": len(d) == man["groups"][g],
           "event_integer_01": bool(d.event.isin([0, 1]).all()),
           "time_finite_nonneg": bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
           "events_total": int(d.event.sum()),
           "event_total_supplied": "unavailable (not in manifest)",
           "max_time": float(d.observed_time.max()), "curve": [], "risk": []}
    for t in CHECK_T:
        i = int((cur.time - t).abs().argmin())
        meas = float(cur.S.iloc[i]); lo = float(cur.S.iloc[max(i - 1, 0):i + 2].min()); hi = float(cur.S.iloc[max(i - 1, 0):i + 2].max())
        rec = S_at(ut, S, t); res = rec - meas
        ok = abs(res) <= 3 * PX + 1e-9 or (lo - 3 * PX <= rec <= hi + 3 * PX)
        arm["curve"].append({"t": t, "measured": round(meas, 4), "reconstructed": round(rec, 4),
                             "resid": round(res, 4), "status": "pass" if ok else "fail"})
    for t, nr in zip(RISK_T, RISK[g]):
        n = int((d.observed_time >= t).sum())
        arm["risk"].append({"t": t, "displayed": nr, "reconstructed": n, "resid": n - nr,
                            "status": "pass" if n == nr else "fail"})
    out["arms"][g] = arm

sp = os.path.join(args.out, "sensitivity.csv")
if os.path.exists(sp):
    sen = pd.read_csv(sp)
    H = float(min(ipd.groupby("group").observed_time.max().min(), sen.groupby("group").observed_time.max().min()))
    H = float(np.floor(H * 10) / 10)
    out["sensitivity"] = {"assumption": "censorings placed evenly within each risk interval, ignoring detected ticks",
                          "horizon": H, "arms": {}}
    for g in ["A", "B"]:
        u1, s1 = km(ipd[ipd.group == g]); u2, s2 = km(sen[sen.group == g])
        out["sensitivity"]["arms"][g] = {
            "S_primary": {t: round(S_at(u1, s1, t), 4) for t in [6, 12, 18, 24, 30, H]},
            "S_alt": {t: round(S_at(u2, s2, t), 4) for t in [6, 12, 18, 24, 30, H]},
            "RMST_primary": round(rmst(u1, s1, H), 3), "RMST_alt": round(rmst(u2, s2, H), 3),
            "events_primary": int(ipd[ipd.group == g].event.sum()), "events_alt": int(sen[sen.group == g].event.sum())}
else:
    out["sensitivity"] = "not run"
json.dump(out, open(os.path.join(args.out, "checks.json"), "w"), indent=1)
for g, a in out["arms"].items():
    print(g, a["n"], a["events_total"], a["max_time"])
    print(" curve", [(c["t"], c["measured"], c["reconstructed"], c["status"]) for c in a["curve"]])
    print(" risk", [(r["t"], r["displayed"], r["reconstructed"]) for r in a["risk"]])
print(json.dumps(out["sensitivity"], indent=0)[:1500])
