# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster Kaplan–Meier (KM) plot) and `../input/manifest.json`. The manifest gives n = 1000 per arm, time unit months, and code seed 228262772.
- Number-at-risk table, read visually from the figure at 0, 6, 12, 18, 24, 30 and 36 months:
  A = 1000, 686, 480, 337, 232, 83, 0; B = 1000, 637, 530, 439, 371, 140, 0. The digits are clearly rendered, and I treat them as exact.
- The manifest contains no arm-specific event totals, so there was no event-total constraint (marked unavailable in `checks.json`). The reconstructed totals are A: 763 and B: 629 events. These are outputs of the reconstruction, not supplied values.
- No HR, RMST or standard error was used.

## Algorithm (`code/reconstruct.py`, own implementation)
1. **Calibration.** The axis lines and tick marks were located from dark-pixel profiles. The x ticks for 0–36 months are at px 269.5…1709.5 (0.025 months/px). The y ticks for 1.0–0.0 are at px 179.5…929.5 (0.001333 survival units/px). Linear fits have zero residual at all 7 and 6 anchors (`extraction_meta.json`). No global rescaling was applied. The origin was not renormalized: A measures 1.000 over its first columns, and B's first columns (0.998, 0.996, …) are kept as a genuine immediate early decline.
2. **Curve measurement.** Each arm was isolated by RGB distance to its line color. The legend region above the plot is masked.
   - Line-only columns (single run ≤ 6 px): the level is the antialias-weighted centroid.
   - Step columns (a single run that does not rise above the previous level): the level is the run bottom minus 1.5 px.
   - Censor-tick columns (run extending ≥ 5 px above the previous level and ≥ 5 px below the next level): the previous level is carried forward. The new level starts at the first column whose pixels no longer reach the old level.
   - Columns where the arm is absent because the other arm covers it (mainly the crossing near 7–8.5 months): linear interpolation.
   - The raw measurements are kept (`S_raw` in `extracted_curves.csv`). A non-increasing pool-adjacent-violators fit (`S_monotone`) is used for inversion, not a running minimum. The largest upward violation in the raw series is 0.009 (about 7 px, from tick/overlap artefacts).
3. **Censoring.** Censor-tick clusters were detected per column. Each 2 px of cluster width counts as one candidate tick position, which is a lower bound on the number of distinct ticks. Tick visibility does not reveal multiplicity. Within each risk-table interval [t_k, t_{k+1}), the number censored is set so that the reconstructed number at risk at t_{k+1} equals the displayed count. It is solved iteratively together with the events. These censorings are spread evenly over the detected tick positions in that interval; if there are more censorings than ticks, multiplicities are assigned evenly. **This allocation is an assumption.** Only the interval totals are constrained by the risk table; timing within an interval comes only from tick locations.
4. **Events.** Walking column by column: d = round(n_risk × (1 − S_measured / S_reconstructed_before)), computed against the running reconstructed KM so that error does not accumulate. Multiple events per column are allowed; d = 1 is not assumed. Censorings that fall before a column's time are removed first. Events come before censorings at ties.
5. **Zero at risk at 36.** Everyone still at risk after 30 months leaves before 36. The last censoring is at the final tick (A 35.975, B 35.90 months). Nobody is placed at exactly 36.
6. The algorithm is deterministic. The seed is recorded, but no random draws affect the output.

## Checks (`checks.json`, `overlay.png`; ipd.csv SHA-256 88a8c68c…25fa5d)
- 1000 records per arm; event indicators are 0/1; all times are finite and in [0, 36).
- Every displayed risk count is reproduced exactly (count of observed_time ≥ t) at all 7 times in both arms.
- The right-continuous KM step function recomputed from the CSV was compared with the raw measured curve at 24 times from 0.25 to 35.9 months. Tolerance is 0.01 (about 7.5 px, given the 4 px line, antialiasing and tick occlusion). All pass. Maximum absolute residuals: A 0.003, B 0.007.
- The largest residual is B's tail, where the reconstructed 0.258 compares with the measured 0.265 after the drop at about 34.93 months. The measured relative drop is 0.900. The reconstruction has 16 at risk there and assigns 2 events (0.875). n = 10/d = 1 or n = 20/d = 2 would fit exactly. The number at risk at 34.9 is not identified: it depends on how the censorings in [30, 36) are spread, which the risk table does not constrain. I left this unresolved rather than tuning the allocation.

## Sensitivity (one alternative, `sensitivity.csv`)
In the alternative, censorings within each risk interval are spread uniformly in time, ignoring tick positions. The risk-table totals are unchanged. Common supported horizon is 35.9 months (`sensitivity_comparison.json`):
- A: S(35.9) 0.150 (primary) vs 0.145; RMST to 35.9 months 15.49 vs 15.48; events 763 vs 766.
- B: S(35.9) 0.258 vs 0.268; RMST to 35.9 months 18.33 vs 18.34; events 629 vs 628.

These two runs do not bound the reconstruction error. The primary was chosen before seeing these results because it uses the tick evidence.

## Limitations
- Censoring times within intervals, and multiplicities at overlapping ticks, are not identified. Ticks hidden under the other arm or under steep step segments are missed.
- Event timing is resolved to about 1 px (0.025 months). Across tick or occlusion gaps, drops are assigned to the gap end or interpolated, which can shift event times by up to about 0.3 months (e.g., A near 7.5 months, B near 1.9 and 3.2 months).
- One pixel is about 0.75–1 event early on and several events in the tail, so per-column counts are rounded approximations.
- Two primary correction cycles were used after the first complete file: (1) handling of tick/step gaps; (2) step-column levels and masking the legend swatches, which had corrupted A near 10–12 months and B near 21 months. The checks were regenerated from the final CSV.

Re-run from `work/`: `python3 output/code/reconstruct.py --input ../input --out output && python3 output/code/checks.py output`. For the sensitivity file add `--censor-mode uniform --csv-name sensitivity.csv`, then run `python3 output/code/sensitivity_compare.py output`.
