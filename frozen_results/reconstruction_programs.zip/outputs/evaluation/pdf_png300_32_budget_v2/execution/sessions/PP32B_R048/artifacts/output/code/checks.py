#!/usr/bin/env python3
"""Reload committed CSV, recompute right-continuous KM, compare with measured curve and risk table."""
import json, os, hashlib, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..')
csv = os.path.join(OUT, 'ipd.csv')
df = pd.read_csv(csv); ext = pd.read_csv(os.path.join(OUT, 'extracted_curves.csv'))
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 686, 480, 337, 232, 83, 0], 'B': [1000, 637, 530, 439, 371, 140, 0]}
TOL = 0.01  # ~7.5 px; line is ~4 px thick, plus <=1 event rounding and tick-column occlusion


def km(d):
    tt = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = []
    for t in tt:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return np.array(out) if out else np.zeros((0, 2))


def S_at(k, t):  # right-continuous step
    i = np.searchsorted(k[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else k[i, 1]


res = dict(csv_sha256=sha, tolerance_S=TOL, tolerance_note='~7.5 px at 750 px/unit; line width 4 px, antialiasing, tick occlusion', groups={})
fig, axs = plt.subplots(1, 2, figsize=(14, 5))
for ax, g in zip(axs, ['A', 'B']):
    d = df[df.group == g]; k = km(d); e = ext[ext.group == g]
    chk = dict(n=int(len(d)), n_expected=1000, n_pass=bool(len(d) == 1000),
               event_indicator_integer=bool(d.event.isin([0, 1]).all()), events=int(d.event.sum()),
               supplied_event_total='unavailable (not in manifest)',
               max_time=float(d.observed_time.max()), curve=[], risk=[])
    for t in [0.25, 0.5, 1, 2, 3, 4, 5, 6, 7.5, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 34.5, 35, 35.5, 35.9]:
        row = e.iloc[(e.time - t).abs().argmin()]
        m = float(row.S_raw); r = float(S_at(k, t)); chk['curve'].append(dict(
            time=t, measured=round(m, 4), measured_monotone=round(float(row.S_monotone), 4), reconstructed=round(r, 4),
            residual=round(r - m, 4), status='pass' if abs(r - m) <= TOL else 'fail'))
    for t, n in zip(RISK_T, RISK[g]):
        r = int((d.observed_time >= t).sum())
        chk['risk'].append(dict(time=t, displayed=n, reconstructed=r, residual=r - n, status='pass' if r == n else 'fail'))
    res['groups'][g] = chk
    ax.plot(e.time, e.S_raw, 'k.', ms=1, label='measured (raw)')
    ax.step(k[:, 0], k[:, 1], where='post', lw=0.8, label='KM of reconstructed IPD')
    ax.set_title(g); ax.legend()
    ax2 = ax.inset_axes([0.55, 0.45, 0.4, 0.3])
    kk = np.array([S_at(k, t) for t in e.time]); ax2.plot(e.time, kk - e.S_raw, lw=0.5); ax2.axhline(0, c='k', lw=.5)
    ax2.set_title('residual', fontsize=7)
plt.savefig(os.path.join(OUT, 'overlay.png'), dpi=110)
tmp = os.path.join(OUT, 'checks.json.tmp'); json.dump(res, open(tmp, 'w'), indent=1); os.replace(tmp, os.path.join(OUT, 'checks.json'))
for g in res['groups']:
    c = res['groups'][g]
    print(g, c['n'], c['events'], c['max_time'], 'curve fails', [x['time'] for x in c['curve'] if x['status'] != 'pass'],
          'risk', [x['residual'] for x in c['risk']], 'max|res|', max(abs(x['residual']) for x in c['curve']))
