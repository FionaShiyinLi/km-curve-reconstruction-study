#!/usr/bin/env python3
"""Same-horizon comparison of primary (ipd.csv) and sensitivity (sensitivity.csv) reconstructions."""
import os, sys, json
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..')
H = 35.9  # common supported horizon: both plotted curves extend to >= 35.9 months


def km(d):
    tt = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = [(0.0, 1.0)]
    for t in tt:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return np.array(out)


def summ(k):
    tt = np.r_[k[k[:, 0] <= H, 0], H]; ss = k[k[:, 0] <= H, 1]
    return dict(S_at_H=round(float(ss[-1]), 4), RMST_to_H=round(float(np.sum(np.diff(tt) * ss)), 3))


res = dict(horizon_months=H, assumption='sensitivity: censoring times spread uniformly within each risk-table interval instead of at detected tick positions')
for f in ['ipd.csv', 'sensitivity.csv']:
    d = pd.read_csv(os.path.join(OUT, f))
    res[f] = {g: summ(km(d[d.group == g])) | dict(events=int(d[d.group == g].event.sum())) for g in ['A', 'B']}
json.dump(res, open(os.path.join(OUT, 'sensitivity_comparison.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
