#!/usr/bin/env python3
"""Reconstruct approximate participant-level time-to-event records from a KM figure.

Usage: python reconstruct.py [--input ../input] [--out output] [--censor-mode ticks|uniform]
Own implementation (pixel extraction + iterative KM inversion constrained by the
number-at-risk table). No KM-to-IPD package is used.
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
from PIL import Image

ap = argparse.ArgumentParser()
ap.add_argument('--input', default=os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input'))
ap.add_argument('--out', default=os.path.join(os.path.dirname(__file__), '..'))
ap.add_argument('--censor-mode', default='ticks', choices=['ticks', 'uniform'])
ap.add_argument('--csv-name', default='ipd.csv')
args = ap.parse_args()
man = json.load(open(os.path.join(args.input, 'manifest.json')))
SEED = man['code_seed']
rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic, rng used only for tie-free jitter-free ordering
os.makedirs(args.out, exist_ok=True)

im = np.asarray(Image.open(os.path.join(args.input, 'figure.png')).convert('RGB')).astype(float)
H, W, _ = im.shape
dark = im.sum(2) < 150

# ---------------- calibration from axis lines and tick marks ----------------
yax_col = int(np.argmax(dark.sum(0)))          # y axis line column (thick: 269-270)
xax_row = int(np.argmax(dark.sum(1)))          # x axis line row (929-930)
def centers(idx):
    idx = np.asarray(idx); groups = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
    return [g.mean() for g in groups if len(g)]
xt = [c for c in centers(np.where(dark[xax_row + 6, 250:1800])[0] + 250)]
yt = [c for c in centers(np.where(dark[100:935, yax_col - 7])[0] + 100)]
# labelled anchors: x ticks 0,6,...,36 ; y ticks 1.0,0.8,...,0.0 (read from figure)
xt = [c for c in xt if c >= yax_col - 2][:7]
yt = yt[:6]
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
xa, xb = np.polyfit(xt, np.arange(0, 37, 6), 1)     # months per px
ya, yb = np.polyfit(yt, [1.0, 0.8, 0.6, 0.4, 0.2, 0.0], 1)
t_of = lambda x: xa * np.asarray(x, float) + xb
s_of = lambda r: ya * r + yb
X0, X1 = int(round(xt[0])), int(round(xt[-1]))
calib = dict(x_ticks_px=xt, y_ticks_px=yt, months_per_px=xa, surv_per_px=ya,
             x_resid=list(np.polyval([xa, xb], xt) - np.arange(0, 37, 6)),
             y_resid=list(np.polyval([ya, yb], yt) - np.array([1, .8, .6, .4, .2, 0])))

COL = {'A': np.array([31, 119, 180.]), 'B': np.array([255, 127, 14.])}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 686, 480, 337, 232, 83, 0], 'B': [1000, 637, 530, 439, 371, 140, 0]}


def runs(rows):
    if len(rows) == 0: return []
    g = np.split(rows, np.where(np.diff(rows) > 1)[0] + 1)
    return [(a[0], a[-1]) for a in g]


def extract(g):
    m = np.abs(im - COL[g]).sum(2) < 90
    m[xax_row - 1:, :] = False
    m[:int(yt[0]) - 14, :] = False   # exclude legend swatches above the plot area
    # soft weight for sub-pixel centroid (channel with largest contrast to white)
    ch = 0 if g == 'A' else 2
    wsoft = np.clip((255 - im[:, :, ch]) / (255 - COL[g][ch]), 0, 1)
    xs = np.arange(X0, X1 + 2)
    level = np.full(len(xs), np.nan)     # line centre row in line-only columns
    lo = np.full(len(xs), np.nan); hi = np.full(len(xs), np.nan)
    for i, x in enumerate(xs):
        rr = runs(np.where(m[:, x])[0])
        if not rr: continue
        lo[i] = min(a for a, b in rr); hi[i] = max(b for a, b in rr)
        if len(rr) == 1 and rr[0][1] - rr[0][0] <= 5:
            a, b = rr[0]; r = np.arange(a - 1, b + 2); w = wsoft[r, x]
            level[i] = (r * w).sum() / w.sum()
    # step (drop) columns: one run that does not rise above the previous level (so not
    # a censor tick); the vertical segment ends at the new level -> centre = bottom - 1.5 px
    Lcur = np.nan
    for i, x in enumerate(xs):
        if not np.isnan(level[i]):
            Lcur = level[i]; continue
        rr = runs(np.where(m[:, x])[0])
        if len(rr) == 1 and not np.isnan(Lcur) and rr[0][0] >= Lcur - 3:
            level[i] = max(Lcur, rr[0][1] - 1.5); Lcur = level[i]
    ok = ~np.isnan(level)
    # neighbours' levels for tick detection
    idx = np.arange(len(xs))
    prev_i = np.maximum.accumulate(np.where(ok, idx, -1))
    nxt_i = np.minimum.accumulate(np.where(ok, idx, 10**9)[::-1])[::-1]
    ticks = np.zeros(len(xs), bool)
    for i in range(len(xs)):
        if ok[i] or np.isnan(lo[i]): continue
        Lp = level[prev_i[i]] if prev_i[i] >= 0 else level[nxt_i[i]]
        Ln = level[nxt_i[i]] if nxt_i[i] < len(xs) else Lp
        if lo[i] <= Lp - 5 and hi[i] >= Ln + 5:
            ticks[i] = True
    # measured S per column: line-only columns measured; gaps <=3 px carried forward
    # (drop/tick columns), longer gaps (hidden by other curve) linearly interpolated
    S = np.full(len(xs), np.nan); S[ok] = s_of(level[ok])
    gap_start = None
    for i in range(len(xs)):
        if ok[i]:
            if gap_start is not None:
                j0 = gap_start - 1
                hidden = np.isnan(lo[gap_start:i])
                if j0 >= 0 and i - gap_start > 3 and hidden.mean() > 0.5:
                    # curve occluded by the other arm: interpolate
                    S[gap_start:i] = np.interp(idx[gap_start:i], [j0, i], [S[j0], S[i]])
                elif j0 >= 0:
                    # own-colour pixels present (ticks / vertical drop): keep old level
                    # until the first column whose pixels no longer reach the old level
                    S[gap_start:i] = S[j0]
                    for jj in range(gap_start, i):
                        if not np.isnan(lo[jj]) and lo[jj] >= level[j0] + 2:
                            S[jj:i] = S[i]; break
                gap_start = None
        elif gap_start is None:
            gap_start = i
    if gap_start is not None: S[gap_start:] = S[gap_start - 1]
    if np.isnan(S[0]): S[0] = 1.0
    S = pd.Series(S).ffill().bfill().values
    raw = S.copy()
    # monotone (non-increasing) fit by pooled-adjacent-violators, not a running minimum
    S = pava_decreasing(raw)
    return xs, t_of(xs), raw, S, ticks, ok


def pava_decreasing(y):
    y = -np.asarray(y, float); vals = []; wts = []; cnt = []
    for v in y:
        vals.append(v); wts.append(1.0); cnt.append(1)
        while len(vals) > 1 and vals[-2] > vals[-1]:
            v2, w2, c2 = vals.pop(), wts.pop(), cnt.pop()
            vals[-1] = (vals[-1] * wts[-1] + v2 * w2) / (wts[-1] + w2); wts[-1] += w2; cnt[-1] += c2
    return -np.repeat(vals, cnt)


def censor_times(tick_t, a, b, c, mode):
    """Place c censoring times in [a,b). Ticks: one candidate per 2-px of tick cluster."""
    if c <= 0: return []
    if mode == 'ticks':
        cand = np.array([t for t in tick_t if a <= t < b])
    else:
        cand = np.array([])
    if len(cand) == 0:
        return list(a + (np.arange(c) + 0.5) * (b - a) / c)
    k = len(cand)
    if c >= k:
        reps = np.full(k, c // k); extra = c - reps.sum()
        if extra: reps[np.round(np.linspace(0, k - 1, extra)).astype(int)] += 1
        return list(np.repeat(cand, reps))
    return list(cand[np.round(np.linspace(0, k - 1, c)).astype(int)])


def simulate(t, S, ctimes, n0, t_lo, t_hi):
    """Walk column times in [t_lo,t_hi); events from drops relative to reconstructed KM."""
    ctimes = np.sort(np.array(ctimes)); ci = 0
    n = n0; Shat = S_state[0]; ev = []; cs = []
    sel = np.where((t >= t_lo) & (t < t_hi))[0]
    for i in sel:
        while ci < len(ctimes) and ctimes[ci] < t[i] - 1e-9:
            cs.append(ctimes[ci]); n -= 1; ci += 1
        if n <= 0: continue
        d = int(max(0, round(n * (1 - S[i] / Shat)))) if Shat > 0 else 0
        d = min(d, n)
        if d:
            ev += [t[i]] * d; Shat *= (1 - d / n); n -= d
    while ci < len(ctimes):
        cs.append(ctimes[ci]); n -= 1; ci += 1
    return ev, cs, n, Shat


results = {}; extracted = {}
for g in ['A', 'B']:
    xs, t, raw, S, ticks, ok = extract(g)
    tick_x = xs[ticks]; tick_t = []
    for grp in np.split(tick_x, np.where(np.diff(tick_x) > 1)[0] + 1):
        if len(grp) == 0: continue
        k = max(1, int(round(len(grp) / 2)))   # tick width ~2 px -> lower bound on distinct ticks
        tick_t += list(t_of(np.linspace(grp[0], grp[-1], k) if k > 1 else [grp.mean()]))
    tick_t = np.clip(np.array(tick_t), 0, None)
    extracted[g] = pd.DataFrame(dict(x_px=xs, time=t, S_raw=raw, S_monotone=S, line_col=ok, tick_col=ticks))
    events, cens = [], []
    S_state = [1.0]; n_curr = RISK[g][0]; notes = []
    for k in range(len(RISK_T) - 1):
        a, b = RISK_T[k], RISK_T[k + 1]; n_next = RISK[g][k + 1]
        ev0, _, _, _ = simulate(t, S, [], n_curr, a, b)
        c = max(0, n_curr - n_next - len(ev0)); best = None
        for it in range(40):
            ct = censor_times(tick_t, a, b, c, args.censor_mode)
            if b == 36:  # zero at risk at 36: every remaining participant leaves before 36
                ct = [min(x, t_of(X1 - 1)) for x in ct]
            ev, cs, n_end, Sh = simulate(t, S, ct, n_curr, a, b)
            err = n_end - n_next
            if best is None or abs(err) < abs(best[3]): best = (ev, cs, Sh, err, c)
            if err == 0: break
            c_new = max(0, c + err)
            if c_new == c: break
            c = c_new
        ev, cs, Sh, err, c = best
        if err != 0 and b == 36:
            # remaining participants must leave before 36: censor at last tick time
            extra = [t_of(X1 - 1)] * err; cs += extra; notes.append(f'[{a},{b}) {err} residual censored at end'); err = 0
        if err != 0: notes.append(f'[{a},{b}) residual n_at_risk mismatch {err}')
        events += ev; cens += cs; S_state[0] = Sh; n_curr = n_next if err == 0 else n_next + err
    df = pd.DataFrame({'group': g, 'observed_time': np.r_[events, cens],
                       'event': np.r_[np.ones(len(events), int), np.zeros(len(cens), int)]})
    df['observed_time'] = df['observed_time'].clip(lower=0).round(4)
    results[g] = (df, notes, len(tick_t))
    print(g, 'n', len(df), 'events', int(df.event.sum()), 'ticks', len(tick_t), notes)

out = pd.concat([results[g][0] for g in ['A', 'B']]).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
assert all((out.group == g).sum() == man['groups'][g] for g in ['A', 'B'])
tmp = os.path.join(args.out, args.csv_name + '.tmp')
out.to_csv(tmp, index=False); os.replace(tmp, os.path.join(args.out, args.csv_name))
if args.csv_name == 'ipd.csv':
    pd.concat([extracted[g].assign(group=g) for g in extracted]).to_csv(os.path.join(args.out, 'extracted_curves.csv'), index=False)
    json.dump(dict(calibration=calib, seed=SEED, notes={g: results[g][1] for g in results},
                   n_tick_candidates={g: results[g][2] for g in results}),
              open(os.path.join(args.out, 'extraction_meta.json'), 'w'), indent=1, default=float)
print('saved', args.csv_name)
