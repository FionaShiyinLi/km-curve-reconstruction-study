# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800 x 1350 raster, Kaplan–Meier (KM) curves for Groups A and B, number-at-risk table).
- `../input/manifest.json`: n = 1000 per group, time in months, code seed 754076957. The manifest has **no arm-specific event totals**, so none were used. Their absence is not read as zero events.
- Number-at-risk values read by eye from the figure at t = 0, 6, 12, 18, 24, 30, 36 months:
  A 1000/667/463/312/198/78/0; B 1000/758/564/419/323/129/0. The digits are sharp and I consider them reliable.

## Algorithm (`code/reconstruct.py`, run as `python output/code/reconstruct.py`)
1. **Calibration.** The time axis is fitted from the black x-axis tick marks (0–36 at px 269.5–1709.5, 40 px/month). The survival axis is fitted from the y-axis ticks (1.0 at row 179.5, 0.0 at row 929.5, 750 px/unit). Both linear fits have zero residuals. No global rescaling was applied.
2. **Curve measurement.** Each arm's colour-alpha map is used column by column. For line columns, the post-column level is the sub-pixel bottom edge minus the measured half line width (2 px). Columns whose colour run is ≥13 px tall are classed as censor ticks (ticks are about 17 px tall and 2 px wide). They get **no** level reading, because the tick-span centre is biased by 0.5–1 px and mixes in any drop inside a merged tick block. The previous line level is carried forward, so a drop inside a tick block is placed at the next tick-free column (a timing error of up to the block width).
3. **Draw order near the origin (t < ~1 month).** The pixels show A line < B line < censor ticks. A-columns whose bottom edge touches orange are treated as unknown and carry the previous level forward. The origin was measured directly, not forced flat. A shows a real initial drop (S ≈ 0.993 in the first column, 7 events at t = 0.0125), and B's first column reads 0.997. Neither curve was rescaled to start at 1. S(0) = 1 holds by construction of the KM estimator.
4. **Monotonicity.** Pooled-adjacent-violators isotonic fit, not a running minimum. The largest adjustment was ≤2 px.
5. **Inversion.** Each risk interval [t_k, t_k+1) is processed column by column. Events are d = round(n_risk·(1 − S_meas/S_KM,prev)). Because this compares against the current reconstructed KM, rounding errors correct themselves. Multi-event columns are allowed; d = 1 is not assumed. Events come before censorings in the same column. The interval's censoring total c_k is solved iteratively so that the count at risk at t_k+1 exactly equals the table.
6. **Censor timing (assumption).** Within an interval, c_k censorings are spread in proportion to detected tick columns. Tick visibility is not tick multiplicity: merged blocks hide how many ticks they contain, so per-column counts are assumed, not observed. Only the interval totals are constrained, by the risk table.
7. **Last interval (30–36).** The table shows 0 at risk at 36, so everyone remaining is removed before 36. Censorings follow the tick positions, and any remainder is censored at the last drawn curve column (A 35.89, B 35.99 months). No follow-up beyond the drawn curve is invented. The flat tails do not identify the true censoring distribution or the end of follow-up.
8. No stochastic step is used. The seed is recorded anyway.

## Result
- A: 795 events and 205 censorings. B: 667 events and 333 censorings. There are no reported totals to reconcile these against.

## Checks (`code/checks.py` → `checks.json`)
The checks reload the committed CSV and recompute the right-continuous KM (not interpolated).
- **Risk table:** records with observed_time ≥ t match the table exactly for all 7 times in both arms.
- **Point checks:** 18 times per arm, 0.5–35.86 months, including the tail. Tolerance is max(3 px = 0.004, one-event KM step S/n_risk). The 3 px allows for line-edge antialiasing (about ±1 px), tick/line occlusion and the integer-event granularity near a drop.
  - B passes at all 18 times.
  - A passes at 17 of 18. It **fails at t = 32.01** (measured 0.1347, reconstructed 0.1392, residual +0.0045). The 3.5 px drop there implies about 1.5 events at n ≈ 45, and the rounding put the second event later. By t = 34 the curve matches again (0.1093 vs 0.1099). I left this unresolved rather than changing the tolerance.
- **Tails:** A ends at 0.0977 vs a measured 0.0960; B at 0.2404 vs 0.2440 (≈1.3 and 2.7 px).
- **Full comparison:** across all columns the mean absolute residual against the monotone measurement is about 0.0009 in both arms. The maxima (A 0.014, B 0.011) occur at isolated columns, most likely where a drop's timing is shifted by a column or a tick block; I did not inspect each one.
- **Correction cycles:** one, which replaced tick-span levels with carried-forward line levels. Before it, a spurious split tail event put A's final S at 0.091.

## Sensitivity (`sensitivity.csv`, one alternative)
Same interval censoring totals, but censorings spread uniformly over the columns in each interval, ignoring tick positions. Common supported horizon: 35.8875 months.

| Group | S(24), primary | S(24), alternative | Area to horizon, primary | Area to horizon, alternative |
|---|---|---|---|---|
| A | 0.2256 | 0.2254 | 14.624 | 14.624 |
| B | 0.3655 | 0.3650 | 18.508 | 18.505 |

This is one alternative, not a bound on reconstruction error.

## Limitations
- Censor times within intervals and event counts in tick-dense regions (24–36 months) are not uniquely identified.
- Before about 1 month the curves overlap, so A's early levels there are partly inferred.
- Individual times are quantised to pixel columns (0.025 months), so ties are an artefact of this.
- Supporting data: `measured_curve.csv` (per-column readings), `recon_log.json` (calibration and per-interval counts).
