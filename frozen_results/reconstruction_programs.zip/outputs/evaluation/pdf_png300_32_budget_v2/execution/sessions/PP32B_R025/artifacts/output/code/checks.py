#!/usr/bin/env python3
"""Reload committed ipd.csv, recompute right-continuous KM, compare with measurements.
Usage: python checks.py [--out output]"""
import argparse, os, json, hashlib
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--out", default=os.path.join(here, ".."))
OUT = os.path.abspath(ap.parse_args().out)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 667, 463, 312, 198, 78, 0], "B": [1000, 758, 564, 419, 323, 129, 0]}
N = {"A": 1000, "B": 1000}
PX = 1 / 750.0   # one pixel in survival units (y calibration: 750 px per unit)

def km(df):
    ts = np.sort(df.observed_time[df.event == 1].unique()); S = 1.0; out = []
    for t in ts:
        n = (df.observed_time >= t).sum(); d = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - d / n; out.append((t, S))
    return np.array(out)
def S_at(k, t):  # right-continuous step function
    i = np.searchsorted(k[:, 0], t, side="right") - 1
    return 1.0 if i < 0 else k[i, 1]
def rmst(k, tau):
    tt = np.concatenate([[0], k[:, 0][k[:, 0] < tau], [tau]]); ss = [S_at(k, x) for x in tt[:-1]]
    return float(np.sum(np.diff(tt) * np.array(ss)))

path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
ipd = pd.read_csv(path)
meas = pd.read_csv(os.path.join(OUT, "measured_curve.csv"))
res = dict(ipd_sha256=sha, structure={}, risk_table={}, curve={}, event_totals="unavailable (not in manifest)")
res["structure"] = dict(columns=list(ipd.columns), event_values=sorted(ipd.event.unique().tolist()),
                        finite_nonneg=bool(np.isfinite(ipd.observed_time).all() and (ipd.observed_time >= 0).all()),
                        n={g: int((ipd.group == g).sum()) for g in "AB"},
                        n_pass=all((ipd.group == g).sum() == N[g] for g in "AB"))
check_times = [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.85]
for g in "AB":
    d = ipd[ipd.group == g]; k = km(d); m = meas[meas.group == g]
    rt = []
    for t, n in zip(RISK_T, RISK[g]):
        rec = int((d.observed_time >= t).sum())
        rt.append(dict(t=t, table=n, reconstructed=rec, residual=rec - n, status="pass" if rec == n else "fail"))
    res["risk_table"][g] = rt
    cv = []
    for t in check_times:
        j = int(np.argmin(np.abs(m.t.values - t))); tm = float(m.t.values[j])
        # measurement taken from the raw (pre-monotone) per-column reading; tick-column readings flagged
        Sm = float(m.S_raw.values[j]); Sr = float(S_at(k, tm))
        nr = int((d.observed_time >= tm).sum())
        tol = max(3 * PX, (Sr / nr) if nr > 0 else 0)   # 3 px or one-event KM step, whichever larger
        cv.append(dict(t=round(tm, 4), measured=round(Sm, 4), reconstructed=round(Sr, 4),
                       residual=round(Sr - Sm, 4), tol=round(tol, 4), tick_column=bool(m.tick.values[j]),
                       status="pass" if abs(Sr - Sm) <= tol else "fail"))
    allcols = np.array([S_at(k, t) for t in m.t.values]) - m.S.values
    res["curve"][g] = dict(points=cv, all_columns_max_abs_resid_vs_monotone_measure=round(float(np.abs(allcols).max()), 4),
                           all_columns_mean_abs_resid=round(float(np.abs(allcols).mean()), 5),
                           events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                           last_time=float(d.observed_time.max()), last_S=round(float(k[-1, 1]), 4))
res["risk_table_note"] = ("count of observed_time >= t; events precede censoring at ties; "
                          "t=36 count 0 satisfied with all records < 36 (last curve column t=35.99)")
sens = os.path.join(OUT, "sensitivity.csv")
if os.path.exists(sens):
    s = pd.read_csv(sens); tau = float(min(ipd.groupby("group").observed_time.max().min(),
                                           s.groupby("group").observed_time.max().min()))
    comp = {}
    for g in "AB":
        k1, k2 = km(ipd[ipd.group == g]), km(s[s.group == g])
        comp[g] = dict(S_primary={t: round(S_at(k1, t), 4) for t in [12, 24, tau]},
                       S_sensitivity={t: round(S_at(k2, t), 4) for t in [12, 24, tau]},
                       area_primary=round(rmst(k1, tau), 4), area_sensitivity=round(rmst(k2, tau), 4))
    res["sensitivity"] = dict(assumption="censor times spread uniformly over columns within each risk interval "
                              "(ignores tick positions); counts per interval unchanged",
                              common_horizon_months=tau, comparison=comp)
else:
    res["sensitivity"] = "not run"
json.dump(res, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
for g in "AB":
    print(g, [(p["t"], p["measured"], p["reconstructed"], p["status"]) for p in res["curve"][g]["points"]])
    print(g, [(r["t"], r["table"], r["reconstructed"]) for r in res["risk_table"][g]],
          res["curve"][g]["all_columns_max_abs_resid_vs_monotone_measure"], res["curve"][g]["all_columns_mean_abs_resid"])
print(json.dumps(res["sensitivity"], indent=0)[:1500]); print(sha)
