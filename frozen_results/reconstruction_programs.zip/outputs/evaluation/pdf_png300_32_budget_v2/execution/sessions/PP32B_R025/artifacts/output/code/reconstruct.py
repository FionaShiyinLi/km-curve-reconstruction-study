#!/usr/bin/env python3
"""Reconstruct approximate participant-level records from a raster KM figure.

Usage: python reconstruct.py [--input ../input] [--out output]
Own implementation (pixel extraction + interval-wise KM inversion constrained
by the number-at-risk table). No KM-to-IPD package is used.
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
from PIL import Image

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(here, ".."))
args = ap.parse_args()
IN, OUT = os.path.abspath(args.input), os.path.abspath(args.out)
man = json.load(open(os.path.join(IN, "manifest.json")))
SEED = man["code_seed"]; rng = np.random.default_rng(SEED)  # no stochastic step is used; seed recorded

img = np.array(Image.open(os.path.join(IN, "figure.png")).convert("RGB")).astype(float)
H, W, _ = img.shape

# ---------------- axis calibration from the black spines / tick marks -------------
dark = img.sum(2) < 200
colsum, rowsum = dark.sum(0), dark.sum(1)
xspine = np.where(colsum > 0.8 * colsum.max())[0]           # y axis columns (269,270)
yspine = np.where(rowsum > 0.8 * rowsum.max())[0]           # x axis rows (929,930)
ybase = yspine.max() + 1
# x ticks: dark runs just below the x axis
r = dark[ybase + 3]
xt = np.where(r)[0]; xt = xt[xt >= xspine.min()]
groups = np.split(xt, np.where(np.diff(xt) > 1)[0] + 1)
xticks = np.array([g.mean() for g in groups])
xlab = np.arange(0, 37, 6.0)
assert len(xticks) == len(xlab), xticks
xa, xb = np.polyfit(xlab, xticks, 1)                         # px = xa*t + xb
c = dark[:ybase, xspine.min() - 5]
yt = np.where(c)[0]
groups = np.split(yt, np.where(np.diff(yt) > 1)[0] + 1)
yticks = np.array([g.mean() for g in groups])
ylab = np.array([1.0, 0.8, 0.6, 0.4, 0.2, 0.0])
assert len(yticks) == len(ylab), yticks
ya, yb = np.polyfit(ylab, yticks, 1)                         # row = ya*S + yb
t_of = lambda px: (px - xb) / xa
S_of = lambda row: (row - yb) / ya
calib = dict(x_ticks_px=xticks.tolist(), x_labels=xlab.tolist(), y_ticks_px=yticks.tolist(),
             y_labels=ylab.tolist(), x_fit=[xa, xb], y_fit=[ya, yb],
             x_resid=(np.polyval([xa, xb], xlab) - xticks).tolist(),
             y_resid=(np.polyval([ya, yb], ylab) - yticks).tolist())

# ---------------- colour alpha maps ------------------------------------------------
COL = {"A": np.array([31, 119, 180.]), "B": np.array([255, 127, 14.])}
def alpha(c):
    # least-squares alpha of blend white*(1-a) + c*a, then colour fidelity check
    w = np.array([255., 255, 255]); d = c - w
    a = ((img - w) @ d) / (d @ d)
    resid = np.linalg.norm(img - (w + a[..., None] * d), axis=2)
    a = np.clip(a, 0, 1); a[resid > 40] = 0
    return a
AL = {g: alpha(COL[g]) for g in COL}
x0, x1 = int(np.ceil(xb)), int(np.floor(xa * 36 + xb))
top, bot = int(yticks.min()) - 12, ybase - 1

RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 667, 463, 312, 198, 78, 0], "B": [1000, 758, 564, 419, 323, 129, 0]}
N = man["groups"]
assert all(RISK[g][0] == N[g] for g in N)

def extract(g):
    other = "B" if g == "A" else "A"
    a, ao = AL[g], AL[other]
    rows = []
    for x in range(x0, x1 + 1):
        col = a[top:bot, x]; m = col > 0.25
        idx = np.where(m)[0]
        if len(idx) == 0:
            rows.append((x, np.nan, np.nan, np.nan, 0, 1)); continue
        runs = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
        occl = 0
        for rr in runs:   # other arm's colour touching this run -> possible occlusion
            lo, hi = rr.min() + top, rr.max() + top
            if ao[max(lo - 2, 0):hi + 3, x].max() > 0.25: occl = 1
        lo, hi = idx.min() + top, idx.max() + top
        cen = (np.arange(top, bot) * col).sum() / col.sum() if len(runs) == 1 else np.nan
        rows.append((x, lo, hi, cen, len(runs), occl))
    return pd.DataFrame(rows, columns=["x", "top", "bottom", "centroid", "nruns", "occluded"])

HALF_LW = 2.0      # measured line half-thickness (4 px line, e.g. rows 745-748)

def measure(g):
    d = extract(g)
    other = "B" if g == "A" else "A"
    a, ao = AL[g], AL[other]
    span = d.bottom - d.top + 1
    lv = np.full(len(d), np.nan); tick = np.zeros(len(d), bool); occ_below = np.zeros(len(d), bool)
    for i, row in d.iterrows():
        if np.isnan(row.bottom): continue
        x, b, tp = int(row.x), int(row.bottom), int(row.top)
        # Draw order seen at x=270-300: A line < B line < censor ticks (ticks overwrite lines)
        if span[i] >= 13 and row.nruns == 1:          # censor tick (possibly merged block)
            # level unreliable (tick span centre is biased 0.5-1 px and mixes in any drop inside
            # the block): carry previous line level; drop placed at next tick-free column
            tick[i] = True; continue
        below_other = ao[b + 1:b + 3, x].max() > 0.25
        if below_other and g == "A":                  # A line edge may be under B line
            occ_below[i] = True; continue
        if below_other:                               # B edge adjoins A: no white antialias fraction
            lv[i] = b + 0.5 - HALF_LW
        else:                                         # post-column level from sub-pixel bottom edge
            lv[i] = b + 0.5 + a[b + 1, x] - HALF_LW
    d["occ_below"] = occ_below; d["tick"] = tick; d["level_row"] = lv
    n = len(lv)
    lvl = pd.Series(lv).ffill().to_numpy(copy=True)   # unknown column -> previous level (drop deferred)
    lvl[np.isnan(lvl)] = ya * 1.0 + yb
    d["S_raw"] = S_of(lvl)
    # monotone (non-increasing) fit by pooled adjacent violators -- not a running min
    y = d.S_raw.values.copy(); wts = np.ones(n); blocks = []
    for k in range(n):
        blocks.append([y[k], 1.0, k, k])
        while len(blocks) > 1 and blocks[-2][0] < blocks[-1][0]:
            b2 = blocks.pop(); b1 = blocks.pop()
            wsum = b1[1] + b2[1]
            blocks.append([(b1[0] * b1[1] + b2[0] * b2[1]) / wsum, wsum, b1[2], b2[3]])
    Sm = np.empty(n)
    for v, _, s, e in blocks: Sm[s:e + 1] = v
    d["S"] = np.minimum(Sm, 1.0)
    d["t"] = t_of(d.x.values)
    return d

def reconstruct(g, d, cens_mode="ticks"):
    t = d.t.values; S = d.S.values
    tick = d.tick.values.astype(float)
    recs = []; n = RISK[g][0]; Skm = 1.0
    log = []
    for k in range(len(RISK_T) - 1):
        sel = np.where((t >= RISK_T[k]) & (t < RISK_T[k + 1]))[0]
        n0, n1 = n, RISK[g][k + 1]
        w = tick[sel] if (cens_mode == "ticks" and tick[sel].sum() > 0) else np.ones(len(sel))
        def run(ck):
            cw = np.cumsum(w) / w.sum() * ck
            cc = np.diff(np.concatenate([[0], np.round(cw)])).astype(int)
            nn, sk, ev, cs = n0, Skm, [], []
            for ii, j in enumerate(sel):
                dj = 0
                if nn > 0 and S[j] < sk:
                    dj = int(np.clip(np.round(nn * (1 - S[j] / sk)), 0, nn))
                if dj: sk *= 1 - dj / nn; nn -= dj; ev.append((t[j], dj))
                cj = min(cc[ii], nn)
                if cj: nn -= cj; cs.append((t[j], cj))
            return nn, sk, ev, cs
        ck = max(n0 - n1 - int(round(n0 * (1 - S[sel[-1]] / Skm))), 0)
        best = None
        for it in range(100):
            nn, sk, ev, cs = run(ck)
            D = sum(e for _, e in ev); C = sum(c for _, c in cs)
            err = nn - n1
            if best is None or abs(err) < abs(best[0]): best = (err, ck, nn, sk, ev, cs)
            if err == 0: break
            ck = max(ck + err, 0)
        err, ck, nn, sk, ev, cs = best
        if n1 == 0 and nn > 0:        # tail: remaining censored at last curve column (< 36)
            cs.append((t[sel[-1]], nn)); nn = 0
        for tt, e in ev: recs += [(g, tt, 1)] * e
        for tt, c in cs: recs += [(g, tt, 0)] * c
        log.append(dict(interval=[RISK_T[k], RISK_T[k + 1]], n_start=n0, n_end_table=n1,
                        n_end_recon=int(nn), events=int(sum(e for _, e in ev)),
                        censored=int(sum(c for _, c in cs)), tick_columns=int(tick[sel].sum()),
                        censor_weights="tick columns" if w is not None and cens_mode == "ticks" and tick[sel].sum() > 0 else "uniform"))
        n, Skm = nn, sk
    return recs, log

def write_atomic(df, path):
    tmp = path + ".tmp"; df.to_csv(tmp, index=False); os.replace(tmp, path)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    mode = os.environ.get("CENS_MODE", "ticks")
    target = os.environ.get("TARGET", "ipd.csv")
    allrec, logs, meas = [], {}, []
    for g in ["A", "B"]:
        d = measure(g); d["group"] = g; meas.append(d)
        recs, log = reconstruct(g, d, mode)
        assert len(recs) == N[g], (g, len(recs))
        allrec += recs; logs[g] = log
    df = pd.DataFrame(allrec, columns=["group", "observed_time", "event"])
    df["observed_time"] = df.observed_time.round(4)
    df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    write_atomic(df, os.path.join(OUT, target))
    if target == "ipd.csv":
        pd.concat(meas).to_csv(os.path.join(OUT, "measured_curve.csv"), index=False)
        json.dump(dict(calibration=calib, intervals=logs, seed=SEED, censor_mode=mode),
                  open(os.path.join(OUT, "recon_log.json"), "w"), indent=1, default=float)
    print(json.dumps(logs, indent=0, default=float)[:3000])
    print(json.dumps(calib, default=float))
