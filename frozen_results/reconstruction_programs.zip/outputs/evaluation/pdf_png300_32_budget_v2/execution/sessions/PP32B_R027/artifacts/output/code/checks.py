"""Verify committed output/ipd.csv against extracted curve and risk table. Usage: python checks.py [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
ipd = pd.read_csv(f'{out}/ipd.csv')
summ = json.load(open(f'{out}/extraction_summary.json'))
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
S_TOL = 1e-5  # vector coords to 1e-4 pt = 5.6e-7 in S; allow accumulated rounding
def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out_ = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out_.append((t, S))
    return np.array(out_)
def S_at(K, t):  # right-continuous step
    i = np.searchsorted(K[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else K[i, 1]
res = dict(csv_sha256=sha, columns_ok=list(ipd.columns) == ['group', 'observed_time', 'event'], arms={})
for g in 'AB':
    d = ipd[ipd.group == g]; K = km(d)
    v = pd.read_csv(f'{out}/curve_vertices_{g}.csv')
    # horizontal segments: compare at segment midpoints
    segs = [((v.t[i] + v.t[i+1]) / 2, v.S[i]) for i in range(len(v) - 1) if v.t[i+1] - v.t[i] > 1e-6]
    r = np.array([S_at(K, t) - s for t, s in segs])
    sel_t = [0.5, 3, 6, 9, 12, 18, 24, 30, 33, 35, float(v.t.values[-1]) - 1e-4]
    pts = []
    for t in sel_t:
        j = np.searchsorted(v.t.values, t, side='right') - 1; sm = float(v.S.values[j]); sr = float(S_at(K, t))
        pts.append(dict(t=round(t, 4), measured=round(sm, 6), reconstructed=round(sr, 6), resid=round(sr - sm, 7),
                        status='pass' if abs(sr - sm) <= S_TOL else 'fail'))
    risk = []
    for t, nr in summ['risk_table'][g].items():
        t = float(t); n = int((d.observed_time >= t).sum())
        risk.append(dict(t=t, displayed=nr, reconstructed=n, resid=n - nr, status='pass' if n == nr else 'fail'))
    res['arms'][g] = dict(n=len(d), n_expected=1000, n_ok=len(d) == 1000,
        events=int(d.event.sum()), censored=int((d.event == 0).sum()), event_values_ok=bool(d.event.isin([0, 1]).all()),
        supplied_event_total='unavailable (not in manifest)', max_time=float(d.observed_time.max()),
        all_segments=dict(n=len(segs), max_abs_resid=float(np.abs(r).max()), tol=S_TOL,
                          status='pass' if np.abs(r).max() <= S_TOL else 'fail'),
        spot_checks=pts, risk_table=risk)
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
for g in 'AB':
    a = res['arms'][g]; print(g, a['n'], a['events'], a['censored'], a['all_segments'], [x['status'] for x in a['risk_table']], [x['resid'] for x in a['spot_checks']])
