"""Reconstruct IPD from extracted vertices/ticks (run extract.py first).
Usage: python reconstruct.py [outdir]   (reads outdir/curve_vertices_*.csv, ticks_*.csv, extraction_summary.json)"""
import sys, os, json, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
SEED = 2078679311
np.random.seed(SEED)  # recorded; algorithm below is deterministic
summ = json.load(open(f'{out}/extraction_summary.json'))
N = {'A': 1000, 'B': 1000}           # manifest group sizes
S_ERR = 0.5e-4 / 180.0               # PDF coords written to 1e-4 pt; 180 pt per unit S
ETOL = 1e-6                          # time tolerance (months) for tie of tick with drop

def drops(v):
    """Steps: return list of (t, S_before, S_after)."""
    t, s = v.t.values, v.S.values
    D = []
    for i in range(1, len(t)):
        if abs(t[i] - t[i-1]) < 1e-9 and s[i] < s[i-1] - 1e-9:
            D.append((t[i], s[i-1], s[i]))
    return D

def fit_dn(q, sb, sa, ncap):
    tol = 3 * S_ERR * (1 + sa / sb) / sb + 1e-9
    cands = []
    for d in range(1, 60):
        n0 = int(round(d / q))
        for n in (n0 - 1, n0, n0 + 1):
            if d <= n <= ncap:
                cands.append((abs(q - d / n), d, n))
    ok = [c for c in cands if c[0] <= tol]
    if ok:  # largest feasible risk set = fewest additional censorings
        best = max(ok, key=lambda c: (c[2], -c[1])); return best[1], best[2], True, best[0], tol
    best = min(cands); return best[1], best[2], False, best[0], tol

log = {}
rows = []
for g in 'AB':
    v = pd.read_csv(f'{out}/curve_vertices_{g}.csv')
    tk = np.sort(pd.read_csv(f'{out}/ticks_{g}.csv').t.values)
    t_end = float(v.t.values[-1])
    D = drops(v)
    n_av = N[g]; prev_t = -1.0
    recs, evlog = [], []
    for (te, sb, sa) in D:
        q = 1 - sa / sb
        # visible ticks strictly after previous event time (ties at previous event count here) and before te
        gap = tk[(tk >= prev_t - ETOL) & (tk < te - ETOL)] if prev_t >= 0 else tk[tk < te - ETOL]
        ncap = n_av - len(gap)
        d, n, ok, err, tol = fit_dn(q, sb, sa, ncap)
        c = n_av - n
        # allocate c censorings in the gap: one per visible tick, extras spread over ticks
        # (multiplicity) or, if no tick is visible, uniformly inside the gap (assumption)
        if c > 0:
            if len(gap) > 0:
                reps = np.full(len(gap), c // len(gap)); reps[:c % len(gap)] += 1
                ct = np.repeat(gap, reps)
            else:
                lo = max(prev_t, 0.0)
                ct = lo + (te - lo) * (np.arange(c) + 0.5) / c
            recs += [(g, float(x), 0) for x in ct]
        recs += [(g, float(te), 1)] * d
        evlog.append(dict(t=te, S_before=sb, S_after=sa, n_risk=n, d=d, censored_in_gap=int(c),
                          ticks_in_gap=int(len(gap)), exact_fit=ok, abs_err=err, tol=tol))
        n_av = n - d; prev_t = te
    # after last event: remaining censored at visible ticks, extras at curve end
    gap = tk[tk >= prev_t - ETOL]
    c = n_av
    if c > 0:
        if len(gap) == 0: gap = np.array([t_end])
        k = min(len(gap), c)
        g2 = gap[:k]; reps = np.full(k, c // k); reps[:c % k] += 1
        recs += [(g, float(x), 0) for x in np.repeat(g2, reps)]
    rows += recs
    ev = pd.DataFrame(evlog); ev.to_csv(f'{out}/event_fit_{g}.csv', index=False)
    log[g] = dict(n_drops=len(D), n_events=int(ev.d.sum()), n_censored=int(N[g]-ev.d.sum()),
                  n_inexact=int((~ev.exact_fit).sum()), n_multi_event=int((ev.d > 1).sum()),
                  n_ticks=int(len(tk)), final_censored_after_last_event=int(c))
df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df.observed_time.clip(lower=0).round(6)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
tmp = f'{out}/.ipd.csv.tmp'
df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(log, open(f'{out}/reconstruct_log.json', 'w'), indent=1)
print(json.dumps(log, indent=1))
