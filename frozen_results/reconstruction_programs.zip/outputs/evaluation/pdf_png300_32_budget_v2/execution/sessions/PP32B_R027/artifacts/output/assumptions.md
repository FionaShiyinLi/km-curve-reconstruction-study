# Reconstruction assumptions and method

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 1000 per arm, months, seed 2078679311). No other information was used. The manifest gives no event totals, so that check is marked unavailable. The seed is set in the code but not used, because the algorithm is deterministic.

**Run order:** `python output/code/extract.py ../input/figure.pdf output`, then `python output/code/reconstruct.py output`, then `python output/code/checks.py output`.

## Measurement
- **Source objects.** The figure's vector objects were parsed with pdfplumber. Each arm is one staircase path: Group A is blue, with 1578 vertices; Group B is orange, with 1270 vertices. Censor marks are 4-pt vertical ticks: 212 for A and 366 for B. Arm colors were assigned from the legend swatches.
- **Calibration.** Time was calibrated from the centers of the "0" and "36" tick labels, giving 345.6 pt per 36 months. Survival was calibrated from the six y-labels (0.0–1.0), which fit a line with zero residual (180 pt per unit), with S = 0 at the x-axis spine.
- **Curve start.** Both curves start exactly at S = 1.000000, so no origin correction or global rescaling was applied.
- **Risk table.** The risk table was read from the PDF text layer:
  - A: 1000, 701, 483, 317, 217, 69, 0
  - B: 1000, 645, 529, 427, 353, 135, 0
  - These are the counts at 0, 6, 12, 18, 24, 30 and 36 months.
- **Saved observations.** The extracted values are saved in `output/curve_vertices_*.csv`, `output/ticks_*.csv` and `output/extraction_summary.json`.

## Algorithm
- **Drops.** Each vertical drop gives q = 1 − S_after/S_before. Coordinates are written to 1e-4 pt, so each S value is accurate to about 2.8e-7.
- **Fitting d and n.** For each drop, I searched integer pairs (d, n) with |q − d/n| no larger than three times the propagated rounding error. The search was constrained so that n ≤ (risk set after the previous event) − (number of distinct visible ticks since that event). Each visible tick was taken to mean at least one censoring.
- **Choosing among fits.** Among the feasible pairs, the one with the largest n was chosen, because it implies the fewest censorings the ticks do not account for.
- **Result: events.** All 788 drops in A and 634 in B fit exactly with d = 1. No drop needed a tied multiple-event solution. d = 2 with n ≈ 2k would require a risk set larger than the one available, so d = 1 was not simply assumed.
- **Result: censorings.** In every gap between events, the implied number of censorings equals the number of visible ticks in that gap. Each tick is therefore one censoring at its own x-position. A tick that coincides with a drop is treated as censored after the event at that time.
- **After the last event.** The remaining participants (15 in A, 20 in B) match exactly the ticks after the last drop. The curves end at 35.997 months (A) and 35.978 months (B). No follow-up was added beyond what the ticks and curve show.
- **Code paths not used.** The code has fallbacks for extra censorings: spreading them across ticks, or placing them uniformly in a gap with no ticks. Neither was triggered. There was also no need to reconcile against the risk table, because the risk sets inferred from the drops reproduce the table exactly.

## Result and checks (`output/checks.json`)
- **Group A:** 788 events and 212 censored. **Group B:** 634 events and 366 censored.
- **Risk table.** Counting observed_time ≥ t reproduces every displayed risk count exactly (7/7 per arm). The count at 36 months is 0 because all records are below 36.
- **KM step curve.** The committed CSV was reloaded and its right-continuous KM step curve recomputed. It matches every horizontal segment of the extracted curve (788 in A, 635 in B) with a maximum absolute error of 2.8e-7, which is the coordinate rounding. Spot checks at 0.5–35 months and at the tail all pass.
- **Tolerance.** The pass tolerance is 1e-5, about 36 times the coordinate precision.

## Limitations
- **Assumption behind the fit.** The reconstruction assumes that each distinct tick is one censoring and that no censorings are hidden behind other ticks or in gaps without ticks. The inputs cannot rule out a coincident duplicate tick exactly offset by a missing one elsewhere. However, the event-by-event risk sets inferred from the curve leave no room for that without breaking the exact drop ratios.
- **Precision.** Times carry the precision of the plotted coordinates, about 1e-4 months. The true values may have been rounded or jittered differently.
- **Sensitivity analysis not run.** No alternative allocation was run, because the curve, ticks and risk table leave no materially different allocation consistent with them. Running a sensitivity analysis would only add allocations that contradict the data.
