"""Extract KM step curves and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber, numpy as np, pandas as pd
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
# Axis calibration from labelled tick labels (centres of "0" and "36"; "0.0" and "1.0")
ch = pg.chars
def centre(txt_chars): return np.mean([(c['x0']+c['x1'])/2 for c in txt_chars])
xlab = [c for c in ch if abs(c['top']-229.7) < 1]
x0 = (xlab[0]['x0']+xlab[0]['x1'])/2                 # "0"
x36 = (xlab[-2]['x0']+xlab[-1]['x1'])/2              # "36"
ylab = [c for c in ch if c['x0'] < 56 and c['x0'] > 40 and c['text'] in '0123456789']
ys = {}
for c in ylab:
    if abs(c['x0']-52.1) < 0.5: ys[c['top']] = int(c['text'])/10 if c['text'] != '0' or True else 0
# label tops: 1.0 -> 39.4, 0.0 -> 219.4; label vertical centre offset is constant, use axis frame
tops = sorted(ys)          # 39.4 (1.0) ... 219.4 (0.0)
# y value for label "a.b": first digit at x 43.5; build mapping
vals = {}
for c in ylab:
    if abs(c['x0']-43.5) < 0.5: vals.setdefault(round(c['top'],1), [None,None])[0] = int(c['text'])
    if abs(c['x0']-52.1) < 0.5: vals.setdefault(round(c['top'],1), [None,None])[1] = int(c['text'])
yl = sorted((k, v[0]+v[1]/10) for k, v in vals.items())
ytop = np.array([k for k, _ in yl]); yval = np.array([v for _, v in yl])
slope, icpt = np.polyfit(yval, ytop, 1)   # top = icpt + slope*S (label tops; offset relative to data)
# axis spine (black horizontal line) sits at S=0; label offset = spine - top(0.0)
spine = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0) and abs(l['top']-l['bottom']) < 1e-6]
y_S0 = min(spine, key=lambda l: -l['top'])['top']
off = y_S0 - icpt
cal = dict(x_t0=x0, x_t36=x36, y_S0=y_S0, pt_per_unitS=-slope, label_fit_resid=float(np.max(np.abs(icpt+slope*yval-ytop))))
T = lambda x: (x - x0) / (x36 - x0) * 36
S = lambda y: (y_S0 - y) / (-slope)
groups = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
res = {'calibration': cal}
for g, col in groups.items():
    cv = [c for c in pg.curves if c['stroking_color'] == col][0]
    pts = np.array(cv['pts'])
    t = T(pts[:, 0]); s = S(pts[:, 1])
    pd.DataFrame({'t': t, 'S': s, 'x_pt': pts[:, 0], 'y_pt': pts[:, 1]}).to_csv(f'{out}/curve_vertices_{g}.csv', index=False)
    ticks = [l for l in pg.lines if l['stroking_color'] == col and abs(l['linewidth']-0.65) < 1e-3]
    tk = pd.DataFrame({'t': [T(l['x0']) for l in ticks], 'S_mid': [S((l['top']+l['bottom'])/2) for l in ticks]}).sort_values('t')
    tk.to_csv(f'{out}/ticks_{g}.csv', index=False)
    res[g] = dict(n_vertices=len(pts), n_ticks=len(tk), S_start=float(s[0]), t_end=float(t[-1]), S_end=float(s[-1]))
# risk table
rt = {}
for g, top in (('A', 283.9), ('B', 297.9)):
    row = sorted([c for c in ch if abs(c['top']-top) < 1 and c['x0'] > 50], key=lambda c: c['x0'])
    nums, cur, lastx = [], '', None
    for c in row:
        if lastx is not None and c['x0'] - lastx > 8: nums.append(cur); cur = ''
        cur += c['text']; lastx = c['x0']
    nums.append(cur)
    rt[g] = dict(zip([0, 6, 12, 18, 24, 30, 36], map(int, nums)))
res['risk_table'] = rt
json.dump(res, open(f'{out}/extraction_summary.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
