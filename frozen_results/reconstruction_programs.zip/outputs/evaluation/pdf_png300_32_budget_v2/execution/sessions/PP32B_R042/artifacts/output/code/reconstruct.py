"""Reconstruct participant-level records from the measured KM curves (own implementation).
Usage: python reconstruct.py [figure.png] [manifest.json] [outdir]
Requires extract.py to have been run (curve_*.csv, calibration.json in outdir)."""
import sys, os, json, hashlib, numpy as np, pandas as pd
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
man = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
out = sys.argv[3] if len(sys.argv) > 3 else 'output'
M = json.load(open(man)); SEED = M['code_seed']; rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic
cal = json.load(open(f'{out}/calibration.json'))
px, py = cal['x_fit'], cal['y_fit']
t_of = lambda c: (np.asarray(c) - px[1]) / px[0]
s_of = lambda r: (np.asarray(r) - py[1]) / py[0]
im = np.array(Image.open(fig).convert('RGB')).astype(int)
RGB = {'A': (31, 119, 180), 'B': (255, 127, 14)}
# risk table read visually from the figure (text rendered in the PNG; values transcribed)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [1000, 699, 488, 336, 233, 85, 0], 'B': [1000, 746, 559, 422, 308, 114, 0]}
TMAX = 36.0

def pava_dec(y, w=None):
    """isotonic (non-increasing) least-squares fit"""
    y = np.asarray(y, float); w = np.ones_like(y) if w is None else np.asarray(w, float)
    v, ww, n = [], [], []
    for yi, wi in zip(-y, w):
        v.append(yi); ww.append(wi); n.append(1)
        while len(v) > 1 and v[-2] > v[-1]:
            tot = ww[-2] + ww[-1]; v[-2] = (v[-2]*ww[-2] + v[-1]*ww[-1]) / tot; ww[-2] = tot; n[-2] += n[-1]
            v.pop(); ww.pop(); n.pop()
    return -np.repeat(v, n)

def measure(g):
    d = pd.read_csv(f'{out}/curve_{g}.csv')
    c = d.col.values.astype(int); r = d.row_low.values
    ok = ~np.isnan(r)
    # origin check: an isolated measured column next to the axis, followed by a hidden run of >=5 columns
    # (curve drawn under the other arm), is treated as an origin mark, not a curve level
    first = np.where(ok)[0][0]
    if first <= 2 and not ok[first+1:first+6].any():
        ok[first] = False
    # origin: both curves start at the labelled (0, 1.0) anchor; add that anchor, interpolate hidden columns
    cc = np.concatenate([[px[1]], c[ok]]); rr = np.concatenate([[py[1] + py[0]*1.0], r[ok]])
    raw = s_of(rr); tt = t_of(cc)
    # hidden columns (other arm drawn on top): fill by linear interpolation between neighbouring measurements
    hid = c[~ok & (c < c[ok].max())]
    if len(hid):
        th = t_of(hid); sh = np.interp(th, tt, raw)
        o = np.argsort(np.concatenate([tt, th])); tt = np.concatenate([tt, th])[o]; raw = np.concatenate([raw, sh])[o]
    np.savetxt(f'{out}/hidden_cols_{g}.txt', hid, fmt='%d')
    iso = pava_dec(raw); iso = np.clip(iso, 0, 1)
    # censor ticks: coloured extent >=5 px both above and below the local line centre
    m = np.abs(im - np.array(RGB[g])).sum(2) < 60
    tick = []
    for ci, ri in zip(c[ok], r[ok]):
        rows = np.where(m[int(ri)-12:int(ri)+13, ci])[0] + int(ri) - 12
        tick.append(len(rows) and rows.min() <= ri - 5 and rows.max() >= ri + 5)
    tick = np.array(tick)
    cols_t = c[ok][tick]
    clusters = np.split(cols_t, np.where(np.diff(cols_t) > 1)[0] + 1) if len(cols_t) else []
    widths = [len(k) for k in clusters]
    wmode = int(pd.Series(widths).mode().min()) if widths else 2
    ticks = [(float(t_of(k.mean())), max(1, int(round(len(k) / wmode)))) for k in clusters]
    return tt, raw, iso, ticks, wmode

def alloc(C, weights):
    """largest-remainder allocation of C censorings over tick weights"""
    w = np.asarray(weights, float)
    if C <= 0 or len(w) == 0: return np.zeros(len(w), int)
    q = C * w / w.sum(); a = np.floor(q).astype(int)
    a[np.argsort(-(q - a))[:C - a.sum()]] += 1
    return a

def reconstruct(g, tt, iso, ticks, mode='ticks'):
    n0 = RT[g]; recs = []; S_km = 1.0; n = n0[0]; log = []
    for k in range(len(RT_T) - 1):
        a, b = RT_T[k], RT_T[k+1]
        sel = (tt >= a) & (tt < b) if k < len(RT_T) - 2 else (tt >= a) & (tt <= TMAX)
        ts, ss = tt[sel], iso[sel]
        tk = [(t, w) for t, w in ticks if a <= t < b]
        if mode == 'uniform' or not tk:
            nt = 40 if not tk else len(tk)
            tk = [(a + (b - a) * (i + 0.5) / nt, 1) for i in range(nt)]
        S_end = iso[sel][-1] if sel.any() else S_km
        C = max(0, int(round(n - n0[k+1] - n * (1 - S_end / S_km))))
        for it in range(60):
            cens = alloc(C, [w for _, w in tk]); ctimes = np.repeat([t for t, _ in tk], cens)
            nn, S, ev, ci = n, S_km, [], 0; ctimes = np.sort(ctimes)
            for t, s in zip(ts, ss):
                d = int(round(nn * (1 - s / S))) if S > 0 else 0
                d = max(0, min(d, nn))
                if d: ev.append((t, d)); S *= 1 - d / nn; nn -= d
                while ci < len(ctimes) and ctimes[ci] <= t + 1e-9:
                    nn -= 1; ci += 1
            nn -= len(ctimes) - ci  # ticks later than last measured column
            D = sum(x for _, x in ev); newC = max(0, n - n0[k+1] - D)
            if newC == C: break
            C = newC
        if nn != n0[k+1]:
            log.append(f'{g} interval [{a},{b}): end count {nn} vs table {n0[k+1]}')
        for t, d in ev: recs += [(g, t, 1)] * d
        recs += [(g, t, 0) for t in ctimes]
        log.append(f'{g} [{a},{b}): n={n} events={D} censored={len(ctimes)} ticks={len(tk)} iters={it+1}')
        n, S_km = nn, S
    # anybody left (should be none because table shows 0 at 36): censor at last measured time
    if n > 0:
        recs += [(g, float(tt[-1]), 0)] * n; log.append(f'{g}: {n} leftover censored at {tt[-1]:.3f}')
    return recs, log

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        nr = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / nr; out.append((u, S))
    return np.array(out)
def km_at(step, x):
    i = np.searchsorted(step[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else float(step[i, 1])
def rmst(step, h):
    ts = np.concatenate([[0], step[:, 0][step[:, 0] < h], [h]]); ss = np.concatenate([[1], step[:, 1][step[:, 0] < h]])
    return float(np.sum(np.diff(ts) * ss))

def commit(recs, path):
    df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
    df['observed_time'] = df.observed_time.round(4); df['event'] = df.event.astype(int)
    df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = path + '.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, path)

if __name__ == '__main__':
    meas, allrec, logs, allrec_s = {}, [], [], []
    for g in ['A', 'B']:
        tt, raw, iso, ticks, wmode = measure(g)
        meas[g] = (tt, raw, iso, ticks)
        pd.DataFrame({'t': tt, 'S_raw': raw, 'S_isotonic': iso}).to_csv(f'{out}/measured_{g}.csv', index=False)
        pd.DataFrame(ticks, columns=['t', 'est_marks']).to_csv(f'{out}/ticks_{g}.csv', index=False)
        r, lg = reconstruct(g, tt, iso, ticks); assert len(r) == M['groups'][g], (g, len(r))
        allrec += r; logs += lg + [f'{g}: tick clusters={len(ticks)} modal width={wmode}px']
    commit(allrec, f'{out}/ipd.csv')
    open(f'{out}/reconstruction_log.txt', 'w').write('\n'.join(logs) + '\n'); print('\n'.join(logs))
    # ---- checks from the committed file ----
    df = pd.read_csv(f'{out}/ipd.csv'); sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
    TOL = 0.004  # ~3 px: 3-px line width plus antialias/half-pixel column quantisation
    chk = {'csv_sha256': sha, 'seed': SEED, 'survival_tolerance': TOL,
           'tolerance_note': '1 px = 0.00133 in S; drawn line ~3 px thick; tolerance ~3 px',
           'event_totals': 'unavailable (not in manifest)', 'arms': {}}
    times = [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.9]
    for g in ['A', 'B']:
        d = df[df.group == g]; st = km(d); tt, raw, iso, _ = meas[g]
        sv = []
        for x in times:
            j = np.argmin(np.abs(tt - x)); rec = km_at(st, tt[j] + 1e-6)
            sv.append(dict(t=round(float(tt[j]), 4), measured_raw=round(float(raw[j]), 4), measured_iso=round(float(iso[j]), 4),
                           reconstructed=round(rec, 4), residual=round(rec - float(raw[j]), 4),
                           status='pass' if abs(rec - raw[j]) <= TOL else 'fail'))
        allres = np.array([km_at(st, x + 1e-6) for x in tt]) - raw
        rk = []
        for x, nt in zip(RT_T, RT[g]):
            c = int((d.observed_time >= x).sum())
            rk.append(dict(t=x, table=nt, reconstructed=c, residual=c - nt, status='pass' if c == nt else 'fail'))
        chk['arms'][g] = dict(n=len(d), n_expected=M['groups'][g], n_status='pass' if len(d) == M['groups'][g] else 'fail',
                              events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                              event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
                              max_time=float(d.observed_time.max()),
                              survival=sv, all_columns_max_abs_residual=round(float(np.abs(allres).max()), 4),
                              all_columns_mean_abs_residual=round(float(np.abs(allres).mean()), 5), risk_table=rk)
    json.dump(chk, open(f'{out}/checks.json', 'w'), indent=1)
    # ---- single sensitivity alternative: censorings uniform within each risk-table interval ----
    for g in ['A', 'B']:
        tt, raw, iso, ticks = meas[g]; r, _ = reconstruct(g, tt, iso, ticks, mode='uniform'); allrec_s += r
    commit(allrec_s, f'{out}/sensitivity.csv'); ds = pd.read_csv(f'{out}/sensitivity.csv')
    H = 35.9; sens = {'horizon': H, 'assumption': 'censorings spread uniformly (equal spacing) within each risk-table interval, ignoring tick positions'}
    for g in ['A', 'B']:
        p, q = km(df[df.group == g]), km(ds[ds.group == g])
        sens[g] = {f'{lab}_{k}': round(v, 4) for lab, st in [('primary', p), ('sensitivity', q)]
                   for k, v in [('S12', km_at(st, 12)), ('S24', km_at(st, 24)), ('S_H', km_at(st, H)), ('area_0_H', rmst(st, H))]}
        sens[g]['sens_events'] = int(ds[ds.group == g].event.sum()); sens[g]['sens_risk_table'] = [int((ds[ds.group == g].observed_time >= x).sum()) for x in RT_T]
    chk['sensitivity'] = sens; json.dump(chk, open(f'{out}/checks.json', 'w'), indent=1); print(json.dumps(sens))
    for g in 'AB':
        a = chk['arms'][g]; print(g, a['n'], a['events'], a['max_time'], a['all_columns_max_abs_residual'], a['all_columns_mean_abs_residual'])
        print(' surv', [(s['t'], s['residual'], s['status']) for s in a['survival']])
        print(' risk', [(r['t'], r['reconstructed'], r['table']) for r in a['risk_table']])
