"""Measure axis calibration, KM curves and censor-tick candidates from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.array(Image.open(fig).convert('RGB')).astype(int)
H, W, _ = im.shape
blk = im.sum(2) < 200
# axis lines
xcol = int(np.argmax(blk.sum(0)[:600]))          # y-axis line column (left edge)
yrow = int(np.argmax(blk.sum(1)[:1100]))         # x-axis line row
xcols = [c for c in range(xcol-3, xcol+4) if blk[:, c].sum() > 500]
yrows = [r for r in range(yrow-3, yrow+4) if blk[r].sum() > 1000]
# x ticks: dark pixels in rows just below the axis line
below = blk[max(yrows)+2:max(yrows)+8].sum(0) >= 4
def centers(mask):
    idx = np.where(mask)[0]; groups = np.split(idx, np.where(np.diff(idx) > 1)[0]+1)
    return [float(g.mean()) for g in groups if len(g)]
xt = [x for x in centers(below) if x >= min(xcols)-3]
left = blk[:, min(xcols)-8:min(xcols)-2].sum(1) >= 4
yt = [y for y in centers(left) if 100 < y <= max(yrows)+3]
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
yt = sorted(yt, reverse=True)  # bottom (0.0) first
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
px = np.polyfit(xlab, xt, 1); py = np.polyfit(ylab, yt, 1)
resx = np.array(xt) - np.polyval(px, xlab); resy = np.array(yt) - np.polyval(py, ylab)
cal = dict(x_tick_px=xt, y_tick_px=yt, x_fit=list(px), y_fit=list(py),
           x_resid_px=list(resx), y_resid_px=list(resy), axis_col=xcols, axis_row=yrows)
t_of = lambda c: (c - px[1]) / px[0]
s_of = lambda r: (r - py[1]) / py[0]
cols = {'A': (31, 119, 180), 'B': (255, 127, 14)}
res = {}
for g, rgb in cols.items():
    d = np.abs(im - np.array(rgb)).sum(2)
    m = d < 60
    m[:, :min(xcols)] = False; m[max(yrows)-1:, :] = False; m[:140, :] = False  # drop legend
    # horizontal-run pixels: colored with colored left and right neighbours
    hr = m & np.roll(m, 1, 1) & np.roll(m, -1, 1)
    c0 = max(xcols)+1; c1 = int(round(np.polyval(px, 36)))+2
    rows = []
    for c in range(c0, c1+1):
        r = np.where(hr[:, c])[0]; allr = np.where(m[:, c])[0]
        if len(r) == 0:
            rows.append((c, np.nan, np.nan, np.nan, len(allr), np.nan, np.nan)); continue
        # the step line may contain a vertical drop in this column; take the lowest horizontal band
        bands = np.split(r, np.where(np.diff(r) > 1)[0]+1)
        top_b, bot_b = bands[0], bands[-1]
        rows.append((c, bot_b.mean(), top_b.mean(), len(bands), len(allr),
                     allr.min() if len(allr) else np.nan, allr.max() if len(allr) else np.nan))
    a = np.array(rows, float)
    # the other colour drawn on top may hide this curve: record other-colour occupancy
    res[g] = a
    np.savetxt(f'{out}/curve_{g}.csv', np.column_stack([a, t_of(a[:, 0]), s_of(a[:, 1]), s_of(a[:, 2])]),
               delimiter=',', header='col,row_low,row_high,nbands,ncolored,rmin,rmax,t,S_low,S_high', comments='', fmt='%.4f')
json.dump(cal, open(f'{out}/calibration.json', 'w'), indent=1)
print(json.dumps(cal, indent=1))
