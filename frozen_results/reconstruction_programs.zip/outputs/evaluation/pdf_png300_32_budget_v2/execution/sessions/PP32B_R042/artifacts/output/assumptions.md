# Reconstruction assumptions and limitations

Primary result: `output/ipd.csv` (A: 1000 records, 768 events; B: 1000 records, 684 events).
SHA-256 d5f6180b459b7fec915a2b2090d4989b9aa2b41b10f9257248d2a818c64f4476 (also in `checks.json`).
Rerun from the work directory: `python output/code/extract.py [figure] [outdir]`, then
`python output/code/reconstruct.py [figure] [manifest] [outdir]` (default paths `../input/...`, `output`).

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 1973180718).
- Number-at-risk table, transcribed by eye from the figure at 0, 6, ..., 36 months: A 1000/699/488/336/233/85/0; B 1000/746/559/422/308/114/0.
  All digits were clearly legible. The script hard-codes these values; there is no OCR step.
- The manifest has no arm-specific event totals, so the event-total check is marked unavailable.
- The seed is read and recorded, but the algorithm is deterministic and uses no random draws.

## Measurement
- Calibration comes from the labelled axis ticks, detected as pixels: x ticks 0–36 at columns 269.5 + 40t; y ticks 0–1 at rows 929.5 − 750S.
  The linear-fit residuals are 0 px (`calibration.json`). No global rescaling was applied to either arm.
- The curve level in each pixel column (0.025 months) is the centre of the lowest horizontal-run band of the arm's colour. Isolated vertical tick pixels are excluded.
  Raw values are saved in `curve_*.csv` and `measured_*.csv` (`S_raw`). A non-increasing isotonic (PAVA) fit, `S_isotonic`, is the event target.
  It is a least-squares projection, not a running minimum.
- Origin: both arms are anchored at the labelled point (0, 1.0).
  For A, the only measured column next to the axis (t = 0.04) is a vertical mark centred on S ≈ 1.0, and the blue curve is then hidden under B until t = 0.39.
  That column was treated as an origin mark rather than a curve level. Hidden columns were filled by linear interpolation of S between neighbouring measurements (`hidden_cols_*.txt`; A 0.06–0.36, B 0.04–0.06 and 0.59–0.79).
  This spreads A's early drop from 1.0 to 0.975 evenly over 0–0.39 months. The drop itself is real, but its exact event times inside the hidden region are not identified.

## Algorithm (own implementation, Guyot-type logic)
For each risk-table interval [t_k, t_k+1), processed column by column:
- Events per column: d = round(n_risk · (1 − S_target/S_KM)), where S_KM is the running reconstructed KM. Comparing against the running estimate stops rounding error from accumulating.
  A drop within one column may therefore represent several tied events. d = 1 is never assumed.
- Censoring count per interval: C_k = n_k − n_k+1 − D_k, iterated until stable (2–3 iterations).
- Censoring times: C_k is allocated across the censor-tick clusters detected in that interval, by largest remainder, with weights equal to cluster width divided by the modal tick width (3 px).
  Tick visibility is not tick multiplicity. The number of participants per tick is not identified, and the allocation is an assumption constrained only by the risk-table totals.
  An interval with no detected ticks would use 40 equally spaced times; this did not occur.
- At tied times, events come before censorings.
- The final risk count at 36 months is 0. All remaining participants are censored at tail tick positions before 36 months (maximum observed times 35.89 for A, 35.91 for B).
  No follow-up beyond the drawn curve was created. The flat tail does not identify the actual censoring distribution.

## Checks (`checks.json`, recomputed from the reloaded committed CSV)
- The right-continuous KM step function was evaluated at 17 times from 0.5 to 35.9 months and compared with the raw measured curve.
- Tolerance is 0.004 in S (about 3 px). The drawn line is about 3 px thick, and 1 px = 0.00133.
- All 34 comparisons pass. The largest residual at a checked time is 0.002.
- Over all columns, the mean absolute residual is 0.0004 for both arms. The maximum is 0.0067 for A and 0.0039 for B.
- Unresolved: the maximum for A is at 34.46–34.54 months. There a drop coincides with a dense cluster of censor ticks and is placed about 0.1 month earlier than the raw column reading.
  The level difference is smaller than one event, since about 20 participants are at risk.
- Risk-table counts (observed_time ≥ t) match exactly at all 7 times in both arms.
- Arm sizes are 1000/1000, and the event indicators are integers in {0, 1}.

## Sensitivity (one alternative, `sensitivity.csv`)
- Alternative assumption: censorings are spaced uniformly within each risk-table interval, ignoring tick positions. The event model is unchanged.
- Common supported horizon: 35.9 months.

| Arm | Primary S(35.9) | Alternative S(35.9) | Primary area 0–35.9 (months) | Alternative area 0–35.9 (months) |
|---|---|---|---|---|
| A | 0.152 | 0.155 | 15.600 | 15.602 |
| B | 0.207 | 0.206 | 18.242 | 18.240 |

- S(12) and S(24) differ by at most 0.0004.
- This single alternative is not a bound on reconstruction error.
  Tick multiplicity, event timing within pixel columns and within the hidden early region, and the exact tail censoring times all remain unidentified.
