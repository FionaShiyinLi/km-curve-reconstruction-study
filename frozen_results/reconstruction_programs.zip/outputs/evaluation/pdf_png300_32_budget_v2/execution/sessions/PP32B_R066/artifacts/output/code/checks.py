"""Verify committed ipd.csv against measured curve and risk table; compare sensitivity.csv.
Usage: python checks.py [output_dir]"""
import sys, os, json, hashlib
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
ext = json.load(open(os.path.join(OUT, 'extracted_curves.json')))
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [100, 74, 47, 30, 21, 7, 0], 'B': [100, 68, 55, 42, 32, 14, 0]}
N = {'A': 100, 'B': 100}

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; st = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; st.append((u, S))
    return st
def S_at(st, x):  # right-continuous step
    s = 1.0
    for u, v in st:
        if u <= x: s = v
        else: break
    return s
def rmst(st, h):
    area, prev, s = 0.0, 0.0, 1.0
    for u, v in st:
        if u > h: break
        area += s * (u - prev); prev, s = u, v
    return area + s * (h - prev)
def measured(g, x):
    prof = ext[g]['profile']; pt = np.array([p['t'] for p in prof]); ps = np.array([p['S'] for p in prof])
    sel = np.abs(pt - x) <= 0.05   # plateau value in a +-2 px window
    return float(np.median(ps[sel]))

fn = os.path.join(OUT, 'ipd.csv')
df = pd.read_csv(fn); sha = hashlib.sha256(open(fn, 'rb').read()).hexdigest()
res = dict(csv='output/ipd.csv', sha256=sha, structure={}, curve={}, risk_table={}, event_totals='unavailable: manifest supplies no arm-specific event totals')
res['structure'] = dict(columns_ok=list(df.columns) == ['group', 'observed_time', 'event'],
    sizes={g: int((df.group == g).sum()) for g in N}, sizes_ok=all((df.group == g).sum() == N[g] for g in N),
    event_integer_01=bool(df.event.isin([0, 1]).all()), times_finite_nonneg=bool(np.isfinite(df.observed_time).all() and (df.observed_time >= 0).all()),
    events={g: int(df[df.group == g].event.sum()) for g in N})
# check times chosen on plateaus (away from drop columns) incl. start and tails
CT = {'A': [0.3, 1.0, 2.0, 3.5, 5.6, 7.5, 9.8, 12.5, 15.0, 17.0, 19.0, 21.0, 23.5, 25.0, 27.0, 30.0, 33.0, 34.4],
      'B': [0.1, 0.4, 1.5, 2.5, 4.5, 6.0, 8.0, 10.0, 12.5, 15.0, 17.0, 20.5, 23.5, 26.0, 29.0, 30.6, 32.0, 33.3, 34.0, 35.2]}
for g in N:
    st = km(df[df.group == g]); rows = []
    for x in CT[g]:
        m = measured(g, x); r = S_at(st, x); n = int((df[df.group == g].observed_time >= x).sum())
        tol = 0.003 + 0.5 * max(r, 0.05) / max(n, 1)   # +-2 px reading error + half a one-event step
        rows.append(dict(t=x, measured=round(m, 4), reconstructed=round(r, 4), residual=round(r - m, 4), tol=round(tol, 4),
                         status='pass' if abs(r - m) <= tol else 'fail'))
    res['curve'][g] = rows
    rr = []
    for t, v in zip(RT_T, RT[g]):
        c = int((df[df.group == g].observed_time >= t).sum())
        rr.append(dict(t=t, displayed=v, reconstructed=c, residual=c - v, status='pass' if c == v else 'fail'))
    res['risk_table'][g] = rr
res['curve_tolerance_note'] = '0.003 (~2 px at 750 px/unit) plus half of a single-event KM step S/n at that time'
# sensitivity comparison
sp = os.path.join(OUT, 'sensitivity.csv')
if os.path.exists(sp):
    ds = pd.read_csv(sp); H = 34.4
    comp = {}
    for g in N:
        a = km(df[df.group == g]); b = km(ds[ds.group == g])
        comp[g] = dict(horizon=H, S_primary={t: round(S_at(a, t), 4) for t in [12, 24, H]}, S_alt={t: round(S_at(b, t), 4) for t in [12, 24, H]},
                       rmst_primary=round(rmst(a, H), 3), rmst_alt=round(rmst(b, H), 3),
                       alt_risk_table=[int((ds[ds.group == g].observed_time >= t).sum()) for t in RT_T])
    res['sensitivity'] = dict(assumption='censor times spaced uniformly within each risk-table interval, ignoring detected tick positions',
                              sha256=hashlib.sha256(open(sp, 'rb').read()).hexdigest(), comparison=comp)
else:
    res['sensitivity'] = 'not run'
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in N:
    print(g, [(r['t'], r['residual'], r['status']) for r in res['curve'][g]])
    print(g, [(r['t'], r['displayed'], r['reconstructed']) for r in res['risk_table'][g]])
print(res['structure']); print(json.dumps(res['sensitivity'], indent=0))
# overlay plot
try:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 6))
    for g, c in [('A', 'tab:blue'), ('B', 'tab:orange')]:
        p = ext[g]['profile']; ax.plot([q['t'] for q in p], [q['S'] for q in p], color=c, lw=4, alpha=.3, label=g + ' measured')
        st = km(df[df.group == g]); ax.step([0] + [u for u, _ in st], [1] + [v for _, v in st], where='post', color='k', lw=.8)
    ax.legend(); fig.savefig(os.path.join(OUT, 'overlay.png'), dpi=110)
except Exception as ex: print('plot failed', ex)
