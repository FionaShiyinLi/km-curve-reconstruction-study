"""Pixel extraction of KM step curves and censor ticks from figure.png.
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, os
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input', 'figure.png')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), '..')

# Axis calibration from labelled tick marks (tick pixel pairs measured in the image):
# x: 0 -> cols 269/270, 36 -> cols 1709/1710 ; y: 1.0 -> rows 179/180, 0.0 -> rows 929/930
X0, X36 = 269.5, 1709.5
Y1, Y0 = 179.5, 929.5
def t_of(col): return (col - X0) / (X36 - X0) * 36.0
def s_of(row): return (Y0 - row) / (Y0 - Y1)

im = np.array(Image.open(FIG).convert('RGB')).astype(int)
R, G, B = im[..., 0], im[..., 1], im[..., 2]
masks = {'A': (B - R > 70) & (B > 120), 'B': (R - B > 90) & (R > 180)}
TOP, BOT = 170, 935
XMIN, XMAX = 268, 1715

def runs(col):
    idx = np.where(col)[0]
    if len(idx) == 0: return []
    out = []; s = p = idx[0]
    for i in idx[1:]:
        if i != p + 1: out.append((s, p)); s = i
        p = i
    out.append((s, p)); return out

res = {}
for g, m in masks.items():
    other = masks['B' if g == 'A' else 'A']
    L = 180.0            # current level (row centre); curve starts at S=1
    cols = []
    for x in range(XMIN, XMAX):
        rr = [(a + TOP, b + TOP) for a, b in runs(m[TOP:BOT, x])]
        short = [(a + b) / 2 for a, b in rr if b - a + 1 <= 6]
        # tick: own-colour pixels 4..8 rows above current line centre
        above = m[int(L - 8):int(L - 3), x].sum()
        tick = above >= 3
        cand = [c for c in short if c >= L - 1.5]
        newL = min(cand) if cand else None
        occl = (len(rr) == 0) and other[int(L) - 2:int(L) + 3, x].any()
        if newL is not None: L = newL
        cols.append(dict(x=x, runs=[(int(a), int(b)) for a, b in rr], level=L if newL is not None else None,
                         L=L, tick=bool(tick), occluded=bool(occl), empty=len(rr) == 0))
    # drops: level changes between consecutive known levels
    known = [c for c in cols if c['level'] is not None]
    drops = []
    for c0, c1 in zip(known[:-1], known[1:]):
        if c1['level'] > c0['level'] + 0.75:
            # vertical feature columns between (exclusive) c0 and c1
            mid = [c['x'] for c in cols if c0['x'] < c['x'] < c1['x'] and not c['empty']]
            occ = [c['x'] for c in cols if c0['x'] < c['x'] < c1['x'] and c['empty']]
            if mid: xd = (min(mid) + max(mid)) / 2 - 0.0
            else: xd = (c0['x'] + c1['x']) / 2
            drops.append(dict(x_from=c0['x'], x_to=c1['x'], x=xd, row_before=c0['level'], row_after=c1['level'],
                              t=t_of(xd), S_before=s_of(c0['level']), S_after=s_of(c1['level']),
                              hidden=len(occ) > 0 and not mid))
    # tick clusters
    tx = [c['x'] for c in cols if c['tick']]
    clusters = []
    for x in tx:
        if clusters and x == clusters[-1][-1] + 1: clusters[-1].append(x)
        else: clusters.append([x])
    ticks = []
    for cl in clusters:
        xc = (cl[0] + cl[-1]) / 2
        Lr = cols[cl[0] - XMIN]['L']
        ticks.append(dict(x0=cl[0], x1=cl[-1], width=len(cl), t=t_of(xc), S=s_of(Lr)))
    last = max(c['x'] for c in cols if not c['empty'])
    occ_ranges = [c['x'] for c in cols if c['occluded']]
    res[g] = dict(drops=drops, ticks=ticks, last_col=last, t_last=t_of(last), n_occluded_cols=len(occ_ranges),
                  occluded_cols=occ_ranges,
                  profile=[dict(t=t_of(c['x']), S=s_of(c['L'])) for c in cols])
json.dump(res, open(os.path.join(OUT, 'extracted_curves.json'), 'w'), indent=1, default=float)
if __name__ == '__main__':
    for g in res:
        r = res[g]
        print(g, 'drops', len(r['drops']), 'ticks', len(r['ticks']), 't_last %.3f' % r['t_last'], 'occl cols', r['n_occluded_cols'])
        for d in r['drops']:
            print('  D t=%.3f [%d-%d] S %.4f -> %.4f%s' % (d['t'], d['x_from'], d['x_to'], d['S_before'], d['S_after'], ' HIDDEN' if d['hidden'] else ''))
        for k in r['ticks']:
            print('  T t=%.3f w=%d S=%.4f' % (k['t'], k['width'], k['S']))
        oc = r['occluded_cols']
        if oc:
            segs=[]; 
            for x in oc:
                if segs and x==segs[-1][1]+1: segs[-1][1]=x
                else: segs.append([x,x])
            print('  occluded', [(a,b) for a,b in segs])
