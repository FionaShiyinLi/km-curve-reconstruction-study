#!/bin/sh
# Usage: sh run_all.sh <input_dir> <output_dir>
set -e
D=$(cd "$(dirname "$0")" && pwd); IN=${1:-$D/../../../input}; OUT=${2:-$D/..}
python3 "$D/extract.py" "$IN/figure.png" "$OUT"
python3 "$D/reconstruct.py" "$IN" "$OUT"
python3 "$D/reconstruct.py" "$IN" "$OUT" --alt
python3 "$D/checks.py" "$OUT"
