# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json`. The manifest gives n = 100 per arm, time unit months, and code seed 669969999. No arm-specific event totals are supplied, so that check is marked unavailable. I read the number-at-risk table visually from the figure (A: 100, 74, 47, 30, 21, 7, 0; B: 100, 68, 55, 42, 32, 14, 0 at 0, 6, …, 36 months). All values are clearly legible. No method is stochastic. The seed is set and recorded anyway.

**Reproduce:** `sh output/code/run_all.sh <input_dir> <output_dir>`. This runs `extract.py`, then `reconstruct.py` (primary), then `reconstruct.py --alt` (sensitivity), then `checks.py`.

## Measurement (`extract.py`)
- **Calibration.** Labelled axis tick marks give linear calibration: x = 0 at column 269.5 and x = 36 at column 1709.5 (40 px/month); y = 1 at row 179.5 and y = 0 at row 929.5 (750 px/unit). No global rescaling or running-minimum correction is applied. Both arms start at a measured S = 1.0 (line centre at row 180).
- **Colour masks.** Each arm is segmented by colour: blue for A, orange for B. In each column, runs of ≤ 6 px are horizontal line segments; the curve level is the run centre, tracked monotonically from the previous level.
- **Drops.** A change between consecutive level readings is a drop. Changes below 0.005 are rejected as line-overlap artefacts: two 1–2 px changes, at 33.76 months (A) and 34.5 months (B), where the arms and ticks overlap. The smallest genuine one-event drop is about 0.0107.
- **Early drops.** The first drop in each arm (A 1.00 to 0.98; B 1.00 to 0.99) sits at the y-axis and is partly hidden by the other arm. It was remeasured locally: the vertical segment is centred near column 270.5, so t = 0.025 months. These early drops are kept as genuine rather than forcing a flat start.
- **Plateau levels.** The level after each drop is the median of the plateau readings that follow it.
- **Censor ticks.** A tick is own-colour pixels 4–8 rows above the current line. A single tick is 2–3 px wide. Clusters 5–7 px wide are treated as two overlapping ticks. This is an assumption: visibility is not multiplicity.
- **Saved output.** Extracted drops, ticks and the column profile are saved in `extracted_curves.json`.

## Reconstruction (`reconstruct.py`)
Each risk-table interval [t_k, t_{k+1}) is processed as follows:
1. Censorings are placed at the detected tick times. If the interval needs more censorings than there are ticks, the extras are spread uniformly across the interval.
2. Drops are processed in time order. The event count at each drop is d = round(n_risk × (1 − S_measured_after / S_reconstructed_before)), using the reconstructed KM rather than measured ratios so errors do not accumulate. The count is not assumed to be 1: several drops receive d ≥ 2, for example A at 0.025, 6.8 and 15.6 months and B at 1.0 and 1.9 months. Some of these are raster staircases, where events are spread over the feature's columns.
3. Events from a wide vertical feature (a raster staircase) are spread evenly across its columns.
4. At tied times, censorings are placed after events.
5. The interval's censoring count is iterated until the reconstructed number at risk at t_{k+1} equals the displayed count.

The displayed zeros at 36 months are matched by censoring the remaining participants at the last visible ticks (A 34.48, B 35.35 months), never at 36.

**Result:** A has 78 events and 22 censorings; B has 66 events and 34 censorings.

## Censoring and tick handling (ambiguities)
Detected tick weight versus the censorings required by the risk table:

| Arm | Interval (months) | Tick weight | Censorings required |
|---|---|---|---|
| A | 0–6 | 2 | 1 |
| A | 24–30 | 8 | 10 |
| A | 30–36 | 6 | 7 |
| B | 0–6 | 4 | 5 |
| B | 6–12 | 0 | 1 |
| B | 24–30 | 15 | 17 |
| B | 30–36 | 8 | 10 |

The remaining intervals agree exactly.
- **Surplus ticks (A, 0–6).** One tick was dropped. The A tick near 5.35 may be an overlap artefact at the point where the arms nearly coincide.
- **Missing ticks.** These are attributed to ticks hidden by overlap, drop columns or the other arm, or merged into clusters. The extra censor times are therefore an assumption (uniform within the interval), not an observation.
- **Tail.** The flat tails do not identify the censoring distribution or the follow-up endpoint. Tail censor times come only from the visible ticks and the risk table.

## Checks (`checks.json`)
`checks.json` was generated from the committed CSV and records its SHA-256.
- **Records.** Arm sizes are 100 and 100; event indicators are 0/1 integers; all times are finite and nonnegative.
- **Risk table.** All 14 risk-table counts match exactly, including the two zeros at 36 months. Counting convention: observed_time ≥ t.
- **Curve.** The right-continuous KM from the CSV was compared with the measured plateau values at 18 (A) and 20 (B) times, including the start and tail. Tolerance is 0.003 (about 2 px) plus half a one-event step. All comparisons pass, with a maximum |residual| of 0.0022 (A tail: 0.1822 reconstructed vs 0.1800 measured). That residual reflects KM step granularity with 7–8 at risk.
- **Limits of the fit.** A good fit to the curve and risk table does not show that individual event and censor times are recovered. Within-pixel times (±0.025 months) and the allocation of unticked censorings are not identified.

## Sensitivity (`sensitivity.csv`, one alternative)
- **Assumption.** Censor times are spaced uniformly within each risk interval, ignoring tick positions. It meets the same risk-table constraints.
- **Horizon.** 34.4 months, the common supported horizon (A's curve ends at 34.49).
- **Results.**
  - S(34.4): A 0.182 (primary) vs 0.181 (alternative); B 0.192 vs 0.177.
  - RMST over 0–34.4 months: A 14.93 vs 14.96; B 17.71 vs 17.65.
- **Interpretation.** The B tail is the most allocation-sensitive quantity. This single alternative is not a confidence interval or a bound on reconstruction error.
- **Primary choice.** The tick-based allocation was chosen as primary because it uses the observed ticks, not because of any treatment contrast.
