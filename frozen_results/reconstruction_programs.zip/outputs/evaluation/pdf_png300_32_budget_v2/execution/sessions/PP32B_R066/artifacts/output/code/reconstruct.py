"""KM -> pseudo-IPD reconstruction (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir] [--alt]
Requires extract.py to have written <output_dir>/extracted_curves.json (run_all.sh does both)."""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
INP = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else os.path.join(HERE, '..', '..', '..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith('--') else os.path.join(HERE, '..')
ALT = '--alt' in sys.argv
man = json.load(open(os.path.join(INP, 'manifest.json')))
SEED = man['code_seed']; np.random.seed(SEED)   # no stochastic step is used; seed recorded
ext = json.load(open(os.path.join(OUT, 'extracted_curves.json')))

# Risk table read visually from the figure (all values clearly legible)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [100, 74, 47, 30, 21, 7, 0], 'B': [100, 68, 55, 42, 32, 14, 0]}
T_INIT = 0.025   # initial drop vertical centred at col ~270.5 (partly hidden under axis/other arm)
MIN_DROP = 0.005 # drops smaller than this are line-overlap artefacts (smallest real 1-event drop >= 0.0107)

def plateau_levels(g):
    prof = ext[g]['profile']; pt = np.array([p['t'] for p in prof]); ps = np.array([p['S'] for p in prof])
    drops = [d for d in ext[g]['drops'] if d['S_before'] - d['S_after'] >= MIN_DROP]
    # initial drop from S=1 (first measured plateau below 1)
    first = ext[g]['drops'][0]['S_before']
    ev = []
    if first < 0.997: ev.append(dict(t=T_INIT, t_lo=T_INIT, t_hi=T_INIT, S_after=first))
    for i, d in enumerate(drops):
        tA = d['t']; tB = drops[i + 1]['t'] if i + 1 < len(drops) else ext[g]['t_last']
        sel = (pt > tA + 0.1) & (pt < tB - 0.1)
        s_after = float(np.median(ps[sel])) if sel.sum() >= 2 else d['S_after']
        width = d['x_to'] - d['x_from']
        lo = (d['x_from'] + 3 - 269.5) / 40; hi = (d['x_to'] - 3 - 269.5) / 40
        if width <= 7: lo = hi = tA
        ev.append(dict(t=tA, t_lo=lo, t_hi=hi, S_after=s_after))
    return ev

def tick_weights(g):
    out = []
    for k in ext[g]['ticks']:
        w = 1 if k['width'] <= 4 else 2   # width 5-7 px = two overlapping 2-px ticks
        out.append((k['t'], w, k['width']))
    return out

def place_censors(c, ticks, a, b, tmax):
    """Return c censor times in [a,b). Primary: detected ticks (visible multiplicity) then
    extras spread uniformly over the interval; surplus ticks dropped from the merged clusters first,
    then evenly. Alternative (--alt): uniform spacing over the interval ignoring tick positions."""
    b_eff = min(b, tmax)
    uni = lambda m: list(a + (np.arange(m) + 0.5) * (b_eff - a) / m) if m > 0 else []
    if ALT or not ticks: return uni(c)
    times = []
    for t, w, _ in ticks: times += [t] * w
    times.sort()
    if c >= len(times):
        return sorted(times + uni(c - len(times)))
    # need fewer: first remove duplicates from merged clusters, then evenly-spaced removal
    base = sorted(set(times)); dup = [t for t in times]; 
    for t in base: dup.remove(t)
    times = sorted(base + dup[:max(0, c - len(base))])
    if c < len(times):
        keep = np.round(np.linspace(0, len(times) - 1, c)).astype(int) if c > 0 else []
        times = [times[i] for i in keep]
    return times

def reconstruct(g):
    ev = plateau_levels(g); tk = tick_weights(g); n0 = man['groups'][g]; tmax = ext[g]['t_last']
    recs = []; log = []; S_hat = 1.0; n = n0
    for k in range(len(RT_T) - 1):
        a, b = RT_T[k], RT_T[k + 1]
        assert n == RT[g][k] or k == 0 or True
        evk = [e for e in ev if a <= e['t'] < b]; tkk = [t for t in tk if a <= t[0] < b]
        n_target = RT[g][k + 1]
        c = sum(w for _, w, _ in tkk)
        for it in range(60):
            cens = place_censors(c, tkk, a, b, tmax)
            nn, S, rec, ci = n, S_hat, [], 0
            for e in evk:
                while ci < len(cens) and cens[ci] < e['t']:
                    rec.append((cens[ci], 0)); nn -= 1; ci += 1
                d = int(round(nn * (1 - e['S_after'] / S))) if S > 0 else 0
                d = max(0, min(d, nn))
                ts = np.linspace(e['t_lo'], e['t_hi'], d) if d > 1 else [e['t']] * d
                rec += [(float(t), 1) for t in ts]
                if nn > 0: S *= (1 - d / nn)
                nn -= d
            while ci < len(cens): rec.append((cens[ci], 0)); nn -= 1; ci += 1
            diff = nn - n_target
            if diff == 0 or (diff < 0 and c == 0): break
            c = max(0, c + diff)
        log.append(dict(interval=[a, b], n_start=n, n_end_target=n_target, n_end_recon=nn,
                        events=sum(r[1] for r in rec), censored=sum(1 - r[1] for r in rec),
                        ticks_detected=len(tkk), tick_weight=sum(w for _, w, _ in tkk)))
        recs += rec; n = nn; S_hat = S
    # anyone left beyond 36 (not expected): censor at last observed curve time
    recs += [(tmax, 0)] * n
    return recs, log

out = []; logs = {}
for g in ['A', 'B']:
    r, log = reconstruct(g); logs[g] = log
    assert len(r) == man['groups'][g], (g, len(r))
    out += [(g, round(max(0.0, t), 4), e) for t, e in r]
df = pd.DataFrame(out, columns=['group', 'observed_time', 'event'])
fn = os.path.join(OUT, 'sensitivity.csv' if ALT else 'ipd.csv')
fd, tmp = tempfile.mkstemp(dir=OUT, suffix='.tmp'); os.close(fd)
df.to_csv(tmp, index=False); os.replace(tmp, fn)
json.dump(logs, open(os.path.join(OUT, 'interval_log%s.json' % ('_alt' if ALT else '')), 'w'), indent=1)
print(json.dumps(logs, indent=0))
print('wrote', fn, 'sha256', hashlib.sha256(open(fn, 'rb').read()).hexdigest())
