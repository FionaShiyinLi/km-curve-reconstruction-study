# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 508770010).
- The number-at-risk table was read visually from the figure. All values are clearly legible:
  A 1000/701/483/317/217/69/0 and B 1000/645/529/427/353/135/0 at 0, 6, ..., 36 months.
- The manifest has no arm-specific event totals, so the event-total check is marked unavailable.

## Measurement (`code/extract.py`)
- **Calibration.** Detected the x-axis tick marks (0 to 36 months) and y-axis tick marks (0.0 to 1.0), then fitted linear maps. Residuals at all anchors are 0.000. No global rescaling was applied.
- **Curve reading.**
  - Curves were isolated by their colour (antialiasing included).
  - Pixels were kept only if they belonged to a horizontal run of at least 7 px. This removes vertical risers and censor ticks.
  - In each column, the measured level is the intensity-weighted centroid of the lowest horizontal band (right-continuous value).
  - Before event allocation, a 5-column median filter was applied.
  - No running minimum or reciprocal rescaling was used.
- **Origin.** The first 3 (A) and 6 (B) columns are hidden by the y-axis or the other curve and are left unmeasured. S(0) = 1 by definition. The drops before the first measured column (A 0.997 at 0.09 mo; B 0.963 at 0.26 mo) are kept as genuine early events.
- **Crossing region.** A few columns near 2 to 2.3 months (px 338 to 360) are hidden where the curves overlap. These columns are skipped, so any drop there is assigned to the next measured column.
- **Measured values saved.** `curve_measurements.csv` (per column) and `extraction_meta.json` (calibration and tick groups).

## Reconstruction algorithm (`code/reconstruct.py`)
This is my own implementation of a Guyot-style interval iteration. It is deterministic; the seed is set but not used.

1. **Events per interval.** For each risk-table interval [t_i, t_{i+1}), the number of events in each measured column is the integer d >= 0 that minimises |S_prev(1 - d/n_risk) - S_measured|. Multi-event drops are therefore allowed, and d = 1 is not imposed.
2. **Censoring count.** The censoring count C_i is iterated until the model's number at risk at t_{i+1} equals the table value exactly.
3. **Placement of censorings.**
   - Censorings are placed at the detected censor-tick groups, weighted by group width.
   - A wide group may contain several overlapping marks. Tick visibility does not reveal multiplicity, so the width weighting is an **assumption**.
   - If an interval has no detected ticks, censorings are spread uniformly.
   - At tied times, events are processed before censorings.
4. **Last interval.** The displayed risk count at 36 is 0. All remaining participants are censored at tick positions below 36 (maximum observed time: A 35.89, B 35.73 months). Nobody is placed at exactly 36.
5. **Unsupported follow-up.** No follow-up beyond 36 months was created, and no covariates were generated.

## Results and checks (`checks.json`, computed from the committed CSV)
- **Arm sizes.** 1000 records per arm. Event totals: A 791, B 635 (not externally verifiable).
- **Risk table.** All 14 counts (records with observed_time >= t) match exactly.
- **Survival curve.** The right-continuous KM of the saved records was compared with the measurement at 19 times per arm, from 0.5 to 35.9 months.
  - All comparisons are within 0.005 (about 3.75 px; the line is about 3 px thick, plus centroid and column-quantisation error).
  - The largest residuals are in the tails: B -0.0027 at 35.5 months, and A +0.0017 in the tail. With 60 to 130 at risk, one event moves S by about 0.002, so these reflect integer granularity, not a systematic offset.
  - B at 9 months (-0.0024) lies in the crossing region, where the measurement is less reliable.
- **Overlay.** `overlay.png` shows the reconstructed KM over the original figure.

## Sensitivity (`sensitivity.csv`, one alternative)
- **Alternative assumption.** Censorings are spread uniformly within each risk-table interval instead of being placed at detected ticks.
- **Comparison at the common supported horizon of 35.5 months:**

| Arm | S(35.5), primary | S(35.5), alternative | RMST, primary | RMST, alternative | Events, primary | Events, alternative |
|---|---|---|---|---|---|---|
| A | 0.1237 | 0.1225 | 15.046 | 15.044 | 791 | 791 |
| B | 0.2813 | 0.2818 | 18.055 | 18.062 | 635 | 633 |

- **Limits of this check.** This is one alternative allocation, not a confidence interval or a bound on reconstruction error.
- **Choice of primary.** The primary was chosen because it uses the visible tick evidence, not because of its effect on the between-arm contrast.

## Unresolved limitations
- **Censoring times within intervals are not identified.** Only the interval censor counts are constrained by the risk table. Positions within an interval rely on tick detection, and overlapping ticks in dense regions (A and B after 24 months) are uncounted.
- **Event timing resolution.** Event times are resolved only to one pixel column (0.025 months). Events that fall in hidden columns (origin, crossing) are shifted to the next visible column.
- **Event totals.** No supplied event totals exist to confirm the arm totals.
- **Non-uniqueness.** Several different IPD sets are consistent with the figure. This reconstruction is one feasible approximation.
