"""Overlay KM of committed ipd.csv on the source figure. Usage: python output/code/overlay.py [input_dir] [out_dir]"""
import sys, json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
sys.path.insert(0, 'output/code'); from reconstruct import km
inp = sys.argv[1] if len(sys.argv) > 1 else '../input'; out = sys.argv[2] if len(sys.argv) > 2 else 'output'
meta = json.load(open(f'{out}/extraction_meta.json')); tx, ty = meta['time_fit'], meta['surv_fit']
im = Image.open(f'{inp}/figure.png'); ipd = pd.read_csv(f'{out}/ipd.csv')
plt.figure(figsize=(18, 13.5), dpi=100); plt.imshow(im)
for g, c in [('A', 'k'), ('B', 'm')]:
    st = km(ipd[ipd.group == g]); t = np.concatenate([[0], st[:, 0]]); s = np.concatenate([[1], st[:, 1]])
    plt.step((t - tx[1]) / tx[0], (s - ty[1]) / ty[0], where='post', color=c, lw=0.6)
plt.xlim(250, 1730); plt.ylim(950, 160); plt.axis('off'); plt.savefig(f'{out}/overlay.png', bbox_inches='tight')
