"""Reconstruct IPD from measured KM curves + risk table (own implementation, Guyot-style
interval iteration). Requires output/curve_measurements.csv and output/extraction_meta.json
produced by extract.py.  Usage: python output/code/reconstruct.py [input_dir=../input] [out_dir=output]"""
import sys, os, json, hashlib
import numpy as np
import pandas as pd
from scipy.ndimage import median_filter

inp = sys.argv[1] if len(sys.argv) > 1 else '../input'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
SEED = json.load(open(f'{inp}/manifest.json'))['code_seed']   # 508770010; algorithm is deterministic,
np.random.seed(SEED)                                          # seed set for the record only
N = json.load(open(f'{inp}/manifest.json'))['groups']
meas = pd.read_csv(f'{out}/curve_measurements.csv')
meta = json.load(open(f'{out}/extraction_meta.json'))
# risk table read visually from the figure (all values clearly legible)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [1000, 701, 483, 317, 217, 69, 0], 'B': [1000, 645, 529, 427, 353, 135, 0]}
T_END = 36.0 - 1e-6   # nobody may remain at risk at t=36 (displayed count 0)


def targets(g):
    s = meas[meas.group == g].copy()
    ok = s.S_measured.notna().values
    v = s.S_measured.values.copy()
    # 5-column median filter over measured columns only (removes 1-2 px centroid noise, keeps steps)
    v[ok] = median_filter(v[ok], size=5, mode='nearest')
    return s.time.values[ok], np.minimum(v[ok], 1.0)


def censor_times(g, a, b, C, mode):
    """Place C censorings in [a,b). mode 'ticks': at detected tick groups weighted by group width
    (wide groups may hide several overlapping marks); mode 'uniform': evenly spaced."""
    if C <= 0: return np.array([])
    tk = [(t, w) for t, w in meta['ticks'][g] if a <= t < b]
    if mode == 'uniform' or not tk:
        return a + (np.arange(C) + 0.5) * (min(b, T_END) - a) / C
    tt = np.array([t for t, _ in tk]); ww = np.array([w for _, w in tk], float)
    alloc = np.floor(C * ww / ww.sum()).astype(int)
    rem = C - alloc.sum()
    frac = C * ww / ww.sum() - alloc
    alloc[np.argsort(-frac)[:rem]] += 1
    return np.minimum(np.repeat(tt, alloc), T_END)


def walk(tt, ss, a, b, n0, S0, cens):
    """Events per measured column in [a,b) given censor times; returns event times, n at b, S at b."""
    n, S = n0, S0
    ev = []
    cens = np.sort(cens); ci = 0
    for t, target in zip(tt, ss):
        if not (a <= t < b): continue
        while ci < len(cens) and cens[ci] < t:   # censorings before this column
            n -= 1; ci += 1
        if n <= 0: break
        # integer d minimising |S*(1-d/n) - target|, d>=0 (multi-event drops allowed)
        d = int(np.clip(np.round(n * (1 - target / S)), 0, n)) if target < S else 0
        if d:
            S *= 1 - d / n; n -= d; ev += [t] * d
    n -= len(cens) - ci
    return np.array(ev), n, S


def reconstruct(g, mode):
    tt, ss = targets(g)
    recs = []; S = 1.0; log = []
    for i in range(len(RT_T) - 1):
        a, b = RT_T[i], RT_T[i + 1]
        n0, n1 = RT[g][i], RT[g][i + 1]
        Sb = ss[tt < b][-1]
        C = max(int(round(n0 - n1 - n0 * (1 - Sb / S))), 0)
        for it in range(50):
            cens = censor_times(g, a, b, C, mode)
            ev, nb, Snew = walk(tt, ss, a, b, n0, S, cens)
            if nb == n1: break
            C = max(C + (nb - n1), 0)
            if C > n0 - len(ev): C = n0 - len(ev)
        log.append(dict(interval=[a, b], censored=int(C), events=int(len(ev)), n_end_model=int(nb),
                        n_end_table=n1, iterations=it + 1))
        recs += [(g, float(t), 1) for t in ev] + [(g, float(t), 0) for t in cens]
        S = Snew
    df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
    assert len(df) == N[g], (g, len(df))
    return df, log


def write_atomic(df, path):
    tmp = path + '.tmp'
    df.to_csv(tmp, index=False); os.replace(tmp, path)


def km(df):
    """Right-continuous KM step function; events processed before censorings at ties."""
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return np.array(out)


def S_at(step, x):
    k = np.searchsorted(step[:, 0], x, side='right')
    return 1.0 if k == 0 else step[k - 1, 1]


def rmst(step, h):
    ts = np.concatenate([[0], step[:, 0][step[:, 0] < h], [h]])
    ss = np.concatenate([[1], step[:, 1][step[:, 0] < h]])
    return float((np.diff(ts) * ss).sum())


if __name__ == '__main__':
    # ---- primary ----
    res = {}; logs = {}
    for g in 'AB':
        res[g], logs[g] = reconstruct(g, 'ticks')
    ipd = pd.concat([res['A'], res['B']]).sort_values(['group', 'observed_time', 'event'],
                                                      ascending=[True, True, False])
    ipd['observed_time'] = ipd.observed_time.round(4)
    write_atomic(ipd, f'{out}/ipd.csv')
    print(json.dumps(logs, indent=0))

    # ---- checks from the committed file ----
    ipd = pd.read_csv(f'{out}/ipd.csv')
    sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
    TOL = 0.005   # ~3.75 px: rendered line ~3 px thick plus antialiasing / centroid error
    checks = {'csv_sha256': sha, 'survival_tolerance': TOL,
              'tolerance_justification': '1 survival unit = 750 px; line width ~3 px plus centroid and '
                                         'column-quantisation error (~0.5 px/0.025 mo) gives ~0.005',
              'arms': {}}
    for g in 'AB':
        d = ipd[ipd.group == g]; st = km(d)
        s = meas[meas.group == g]
        comp = []
        for t in [0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.9]:
            row = s.iloc[(s.time - t).abs().argmin()]
            m = row.S_measured
            if np.isnan(m):
                comp.append(dict(time=t, measured=None, reconstructed=S_at(st, t), status='unavailable'))
                continue
            r = S_at(st, row.time)
            comp.append(dict(time=round(float(row.time), 4), measured=round(float(m), 4),
                             reconstructed=round(float(r), 4), residual=round(float(r - m), 4),
                             status='pass' if abs(r - m) <= TOL else 'fail'))
        risk = []
        for t, n in zip(RT_T, RT[g]):
            c = int((d.observed_time >= t).sum())
            risk.append(dict(time=t, table=n, reconstructed=c, residual=c - n,
                             status='pass' if c == n else 'fail'))
        checks['arms'][g] = dict(
            n_records=int(len(d)), n_expected=N[g], n_status='pass' if len(d) == N[g] else 'fail',
            event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
            events_total=int(d.event.sum()), censored_total=int((d.event == 0).sum()),
            supplied_event_total='unavailable (manifest has no event totals)',
            max_time=float(d.observed_time.max()), survival_comparisons=comp, risk_table=risk,
            interval_log=logs[g])
        print(g, 'events', int(d.event.sum()), 'fails', sum(c['status'] == 'fail' for c in comp),
              'risk', [r['residual'] for r in risk])

    # ---- one sensitivity allocation: censorings evenly spaced within risk-table intervals ----
    alt = pd.concat([reconstruct(g, 'uniform')[0] for g in 'AB'])
    alt['observed_time'] = alt.observed_time.round(4)
    write_atomic(alt, f'{out}/sensitivity.csv')
    H = 35.5
    sens = {'assumption': 'censorings spread uniformly within each risk-table interval instead of at '
                          'detected tick positions', 'horizon_months': H, 'arms': {}}
    for g in 'AB':
        p, q = km(ipd[ipd.group == g]), km(alt[alt.group == g])
        sens['arms'][g] = dict(S_primary=S_at(p, H), S_alt=S_at(q, H), RMST_primary=rmst(p, H),
                               RMST_alt=rmst(q, H), events_primary=int(ipd[ipd.group == g].event.sum()),
                               events_alt=int(alt[alt.group == g].event.sum()))
    checks['sensitivity'] = sens
    json.dump(checks, open(f'{out}/checks.json', 'w'), indent=1)
    print(json.dumps(sens, indent=1))
