"""Measure KM curves from the figure by pixel processing.
Usage: python output/code/extract.py [input_dir=../input] [out_dir=output]"""
import sys, json
import numpy as np
import pandas as pd
from PIL import Image

inp = sys.argv[1] if len(sys.argv) > 1 else '../input'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(f'{inp}/figure.png').convert('RGB')).astype(float)
dark = im.sum(2) < 200
H, W = dark.shape

# --- axis calibration from labelled tick marks ---
xrow = int(np.argmax(dark[:, 200:1800].sum(1)))   # x-axis line
ycol = int(np.argmax(dark[100:950, :].sum(0)))     # y-axis line
band = dark[xrow + 4:xrow + 10, :].sum(0) > 0
xs = np.where(band)[0]
xt = [g.mean() for g in np.split(xs, np.where(np.diff(xs) > 1)[0] + 1) if g.mean() >= ycol - 2]
band = dark[:, ycol - 9:ycol - 4].sum(1) > 0
ys = np.where(band)[0]
yt = [g.mean() for g in np.split(ys, np.where(np.diff(ys) > 1)[0] + 1) if 100 < g.mean() < 960]
print('xrow', xrow, 'ycol', ycol, 'xticks', np.round(xt, 1), 'yticks', np.round(yt, 1))
assert len(xt) == 7 and len(yt) == 6, 'tick detection failed'
tx = np.polyfit(xt, [0, 6, 12, 18, 24, 30, 36], 1)
ty = np.polyfit(yt, [1.0, 0.8, 0.6, 0.4, 0.2, 0.0], 1)
print('calib residuals x', np.round(np.polyval(tx, xt) - np.arange(0, 37, 6), 4),
      'y', np.round(np.polyval(ty, yt) - np.array([1, .8, .6, .4, .2, 0]), 5))

colors = {'A': np.array([31, 119, 180]), 'B': np.array([255, 127, 14])}
x0, x1 = int(round(xt[0])), int(round(xt[-1]))
res = {}
for g, c in colors.items():
    d = np.sqrt(((im - c) ** 2).sum(2))
    w = np.clip(1 - d / 120, 0, 1)                 # soft colour membership (antialiasing)
    w[:100] = 0; w[int(yt[-1]) - 1:] = 0; w[:, :x0 - 2] = 0; w[:, x1 + 3:] = 0
    m = w > 0.5
    # keep pixels belonging to a horizontal run >= k px (drops vertical risers and censor ticks)
    k = 7
    cs = np.cumsum(np.pad(m, ((0, 0), (1, 0))).astype(int), axis=1)
    run = np.zeros_like(m)
    for s in range(-k + 1, 1):
        lo = np.arange(W) + s; hi = lo + k
        ok = (lo >= 0) & (hi <= W)
        full = np.zeros_like(m)
        full[:, ok] = (cs[:, hi[ok]] - cs[:, lo[ok]]) == k
        run |= full
    level = np.full(W, np.nan); ticktop = np.full(W, np.nan)
    for x in range(x0, x1 + 1):
        allr = np.where(m[:, x])[0]
        if len(allr): ticktop[x] = allr.min()
        r = np.where(run[:, x])[0]
        if len(r) == 0: continue
        grp = np.split(r, np.where(np.diff(r) > 1)[0] + 1)
        bb = grp[-1]                                # lowest band = right-continuous level
        rr = np.arange(bb[0] - 1, bb[-1] + 2)
        ww = w[rr, x]
        level[x] = (rr * ww).sum() / ww.sum()       # subpixel centroid of the line
    res[g] = dict(level=level, ticktop=ticktop)

# censor ticks: colour pixels >= 5 px above the higher neighbouring horizontal level.
# Visibility only; a wide group can hide several overlapping ticks (multiplicity unknown).
ticks = {}
for g in res:
    L, T = res[g]['level'], res[g]['ticktop']
    cand = [x for x in range(x0 + 2, x1 - 1)
            if not np.isnan(T[x]) and not np.all(np.isnan(L[max(x - 6, 0):x + 1]))
            and np.nanmin(L[max(x - 6, 0):x + 1]) - T[x] >= 5]
    tk = []
    if cand:
        cand = np.array(cand)
        for gg in np.split(cand, np.where(np.diff(cand) > 1)[0] + 1):
            tk.append((float(np.polyval(tx, gg.mean())), int(len(gg))))
    ticks[g] = tk
    print(g, 'tick groups', len(tk), 'wide groups (>5px)', sum(1 for _, n in tk if n > 5))

rows = []
for g in res:
    for x in range(x0, x1 + 1):
        lv = res[g]['level'][x]
        rows.append((g, x, float(np.polyval(tx, x)), float(np.polyval(ty, lv)) if not np.isnan(lv) else np.nan, lv))
pd.DataFrame(rows, columns=['group', 'px', 'time', 'S_measured', 'row_centroid']).to_csv(
    f'{out}/curve_measurements.csv', index=False)
json.dump({'x_ticks_px': xt, 'y_ticks_px': yt, 'time_fit': list(tx), 'surv_fit': list(ty),
           'ticks': ticks}, open(f'{out}/extraction_meta.json', 'w'), indent=1)
