"""Reconstruct IPD from vector-extracted KM steps and censor ticks.
Usage: python reconstruct.py [extracted.json] [outdir]
Deterministic; seed recorded for completeness (no randomness used)."""
import sys, json, os, tempfile
import numpy as np
SEED = 1601253955
np.random.seed(SEED)
ext = sys.argv[1] if len(sys.argv) > 1 else 'output/extracted.json'
outdir = sys.argv[2] if len(sys.argv) > 2 else 'output'
N = {'A': 100, 'B': 100}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 74, 56, 32, 26, 9, 0], 'B': [100, 83, 59, 48, 37, 11, 0]}
D = json.load(open(ext))
log = {}

def drops_of(path):
    out = []
    for (t1, s1), (t2, s2) in zip(path, path[1:]):
        if abs(t1 - t2) < 1e-9 and s2 < s1 - 1e-9:
            out.append((t1, s1, s2))
    return out

recs = []
for g in 'AB':
    path = D[g]['path_t_S']; ticks = sorted(D[g]['censor_tick_times'])
    dr = drops_of(path)
    # Infer (d, n) at each drop: n*(1 - S_after/S_before) = d, n integer, choose
    # smallest d giving integer n that is feasible (n <= previous n - previous d).
    ev = []; n_prev, d_prev = N[g], 0
    for t, a, b in dr:
        q = 1 - b / a; best = None
        for d in range(1, 6):
            n = d / q
            if abs(n - round(n)) < 0.02 and round(n) <= n_prev - d_prev:
                best = (d, int(round(n))); break
        if best is None:
            raise SystemExit(f'{g}: no feasible (d,n) at t={t:.3f}, q={q:.5f}')
        # record whether a larger multiplicity was also feasible
        alt = [d for d in range(best[0] + 1, 6) if abs(d / q - round(d / q)) < 0.02 and round(d / q) <= n_prev - d_prev]
        ev.append(dict(t=t, d=best[0], n=best[1], alt_d=alt))
        n_prev, d_prev = best[1], best[0]
    # censorings in each gap (t_{j-1}, t_j]: n_{j-1} - d_{j-1} - n_j; ticks exactly at t_j count as at risk at t_j
    gaps = []; lo, n_prev, d_prev = 0.0, N[g], 0
    for e in ev + [dict(t=np.inf, d=0, n=0)]:
        c = n_prev - d_prev - e['n']
        # a tick at time == event time is censored after the event there -> belongs to next gap; use tolerance
        tk = [x for x in ticks if lo - 1e-6 < x <= e['t'] - 1e-6] if lo > 0 else [x for x in ticks if x <= e['t'] - 1e-6]
        gaps.append(dict(lo=lo, hi=e['t'], c=c, ticks=tk))
        lo, n_prev, d_prev = e['t'], e['n'], e['d']
    used = sum(len(x['ticks']) for x in gaps); assert used == len(ticks), (g, used, len(ticks))
    ctimes = []; notes = []
    for gp in gaps:
        c, tk = gp['c'], gp['ticks']
        if c < 0: raise SystemExit(f'{g}: negative censoring count in gap {gp}')
        if c == len(tk):
            ctimes += tk
        elif c > len(tk):
            extra = c - len(tk)
            if tk:   # hidden ties: repeat visible ticks cyclically (overplotted marks)
                add = [tk[i % len(tk)] for i in range(extra)]
                notes.append(f'gap ({gp["lo"]:.3f},{gp["hi"]:.3f}]: {c} censorings, {len(tk)} visible ticks; {extra} assigned to visible tick times (overplotted)')
            else:    # no visible tick: spread evenly strictly inside gap
                hi = gp['hi'] if np.isfinite(gp['hi']) else gp['lo']
                add = list(gp['lo'] + (hi - gp['lo']) * (np.arange(1, extra + 1) / (extra + 1)))
                notes.append(f'gap ({gp["lo"]:.3f},{gp["hi"]:.3f}]: {c} censorings without visible tick; spread evenly')
            ctimes += tk + add
        else:
            notes.append(f'gap ({gp["lo"]:.3f},{gp["hi"]:.3f}]: {len(tk)} ticks but only {c} censorings implied; kept first {c}')
            ctimes += tk[:c]
    for e in ev:
        recs += [(g, e['t'], 1)] * e['d']
    recs += [(g, float(x), 0) for x in ctimes]
    nrec = sum(1 for r in recs if r[0] == g)
    log[g] = dict(n_drops=len(dr), events=sum(e['d'] for e in ev), censored=len(ctimes), ticks=len(ticks),
                  n_records=nrec, multiplicity_alternatives=[(round(e['t'], 3), e['alt_d']) for e in ev if e['alt_d']],
                  notes=notes, events_detail=[(round(e['t'], 4), e['d'], e['n']) for e in ev])
    assert nrec == N[g], (g, nrec)

os.makedirs(outdir, exist_ok=True)
fd, tmp = tempfile.mkstemp(dir=outdir, suffix='.tmp')
with os.fdopen(fd, 'w') as f:
    f.write('group,observed_time,event\n')
    for g, t, e in sorted(recs, key=lambda r: (r[0], r[1], -r[2])):
        f.write(f'{g},{t:.4f},{e}\n')
os.replace(tmp, os.path.join(outdir, 'ipd.csv'))
json.dump(log, open(os.path.join(outdir, 'reconstruction_log.json'), 'w'), indent=1)
for g in 'AB':
    print(g, {k: v for k, v in log[g].items() if k != 'events_detail'})
