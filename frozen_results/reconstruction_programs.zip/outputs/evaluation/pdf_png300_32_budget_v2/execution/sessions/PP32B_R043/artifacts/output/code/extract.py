"""Extract KM step paths and censor ticks from the vector PDF; save raw observations."""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output/extracted.json'
pg = pdfplumber.open(pdf).pages[0]
# axis calibration from labelled tick lines: x=64.8 -> 0, x=410.4 -> 36 ; y=223.2 -> 0, y=43.2 -> 1
X0, X36, Y0, Y1 = 64.8, 410.4, 223.2, 43.2
tx = lambda x: (x - X0) / (X36 - X0) * 36
sy = lambda y: (Y0 - y) / (Y0 - Y1)
cols = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
res = {}
for g, col in cols.items():
    cv = [c for c in pg.curves if tuple(c['stroking_color']) == col]
    assert len(cv) == 1
    pts = [(x, y) for x, y in cv[0]['pts']]
    # pdfplumber gives top-based y; convert back via page height
    H = pg.height
    pts = [(x, H - y) if False else (x, y) for x, y in pts]
    ticks = sorted(tx((l['x0'] + l['x1']) / 2) for l in pg.lines
                   if tuple(l['stroking_color']) == col and abs(l['linewidth'] - 0.65) < 0.01)
    res[g] = {'path_t_S': [(tx(x), sy(y)) for x, y in pts], 'censor_tick_times': ticks}
json.dump(res, open(out, 'w'), indent=1)
print({g: (len(v['path_t_S']), len(v['censor_tick_times'])) for g, v in res.items()})
