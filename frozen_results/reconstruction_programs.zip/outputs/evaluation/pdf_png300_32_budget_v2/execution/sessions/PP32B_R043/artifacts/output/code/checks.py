"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table."""
import sys, json, hashlib
import numpy as np, pandas as pd
ipd = sys.argv[1] if len(sys.argv) > 1 else 'output/ipd.csv'
ext = sys.argv[2] if len(sys.argv) > 2 else 'output/extracted.json'
out = sys.argv[3] if len(sys.argv) > 3 else 'output/checks.json'
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 74, 56, 32, 26, 9, 0], 'B': [100, 83, 59, 48, 37, 11, 0]}
N = {'A': 100, 'B': 100}
TOL_S = 0.002  # vector coordinates are given to ~1e-4 pt (~1e-6 in S); 0.002 allows for 4-dp time rounding in CSV
df = pd.read_csv(ipd); D = json.load(open(ext))
sha = hashlib.sha256(open(ipd, 'rb').read()).hexdigest()
def km(d, t):
    s = 1.0
    for u in np.unique(d.observed_time[d.event == 1]):
        if u > t: break
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1 - e / n
    return s
def measured(path, t):  # right-continuous step: last vertex with time <= t
    s = path[0][1]
    for tt, ss in path:
        if tt <= t + 1e-9: s = ss
        else: break
    return s
res = {'csv_sha256': sha, 'columns_ok': list(df.columns) == ['group', 'observed_time', 'event'],
       'survival_tolerance': TOL_S, 'arms': {}}
for g in 'AB':
    d = df[df.group == g]; path = D[g]['path_t_S']
    drops = sorted({p[0] for p in path})
    ts = sorted(set([0, 0.5, 1.5, 3, 6, 9, 12, 15, 18, 21, 24, 27, 28, 29, 30, 31, 32, 33, 34, 35, 35.3]
                    + [round(x + 0.01, 3) for x in drops[1::7]]))
    ts = [t for t in ts if t <= path[-1][0]]
    sc = [dict(t=t, measured=round(measured(path, t), 5), reconstructed=round(km(d, t), 5),
               residual=round(km(d, t) - measured(path, t), 5)) for t in ts]
    for r in sc: r['status'] = 'pass' if abs(r['residual']) <= TOL_S else 'fail'
    rk = []
    for t, n in zip(RISK_T, RISK[g]):
        m = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=m, residual=m - n, status='pass' if m == n else 'fail'))
    res['arms'][g] = dict(n_records=len(d), n_expected=N[g], size_ok=len(d) == N[g],
        events=int(d.event.sum()), events_integer_ok=bool(d.event.isin([0, 1]).all()),
        times_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
        supplied_event_total='unavailable (not in manifest)',
        max_time=float(d.observed_time.max()), curve_end_time=path[-1][0],
        survival_checks=sc, risk_table_checks=rk,
        all_survival_pass=all(r['status'] == 'pass' for r in sc), all_risk_pass=all(r['status'] == 'pass' for r in rk))
json.dump(res, open(out, 'w'), indent=1)
for g in 'AB':
    a = res['arms'][g]
    print(g, a['n_records'], a['events'], a['all_survival_pass'], a['all_risk_pass'],
          max(abs(r['residual']) for r in a['survival_checks']), [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table_checks']])
print(sha)
