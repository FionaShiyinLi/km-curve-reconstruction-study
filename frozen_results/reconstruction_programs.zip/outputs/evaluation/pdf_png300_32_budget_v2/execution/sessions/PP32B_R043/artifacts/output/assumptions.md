# Reconstruction assumptions and method

## Inputs
- `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (n = 100 per arm, time in months, seed 1601253955).
- The manifest has no arm-specific event totals, so there was no event-total constraint. Event counts come from the curve alone.
- Number-at-risk table read from the PDF text layer. A: 100, 74, 56, 32, 26, 9, 0; B: 100, 83, 59, 48, 37, 11, 0, at 0, 6, ..., 36 months.

## Measurement (`code/extract.py`)
- The figure is vector graphics, so no pixel digitization was needed. Each arm's KM curve is a single stroked path, identified by its stroke color. Censor marks are short vertical line segments in the arm's color, 0.65 pt wide.
- Calibration uses the labelled axis tick segments: x = 64.8 pt → 0 mo, x = 410.4 pt → 36 mo; y = 223.2 pt → S = 0, y = 43.2 pt → S = 1. The path starts exactly at (0, 1.0) in both arms. No global rescaling, origin correction or running-minimum correction was applied. The genuine early drops (A at 0.034 mo, B at 0.135 mo) are kept.
- Raw observations (path vertices as (t, S), tick times) are saved in `extracted.json`.

## Algorithm (`code/reconstruct.py`)
1. For each vertical drop, r = S_after/S_before. Under the KM relation d = n(1 − r), with n and d integers.
2. For each drop, test d = 1..5 and keep the smallest d for which d/(1 − r) is within 0.02 of an integer n, and that n is feasible (n ≤ n_prev − d_prev). The implied n values are integers to about ±0.005 at every drop. For every drop, d ≥ 2 was infeasible because it would make n exceed the number still at risk (logged in `reconstruction_log.json` as `multiplicity_alternatives`, which is empty). So d = 1 is implied by the risk-set sequence, not assumed. Two tied B events at 7.972 mo appear as two separate drops at the same time.
3. The number censored between consecutive events is n_prev − d_prev − n_next. In every gap, and after the last event, this equaled the number of visible censor ticks in that gap (A: 26 ticks and 26 censorings; B: 35 and 35). So no hidden or overplotted censorings had to be assigned, and each censoring time is its tick's x-position.
4. The ordering convention is that censorings at a tied time remain at risk for the event at that time. The code includes fallback rules for surplus or missing ticks (repeat visible ticks, or spread evenly within the gap), but neither was triggered.
5. No randomness was used. The seed is set and recorded anyway.

## Censoring and follow-up
- Follow-up beyond the last tick is not extrapolated. The maximum observed time equals the last tick and curve end (A 35.31, B 35.36 mo), which is consistent with a displayed risk of 0 at 36.
- One A censor tick lies at exactly x = 352.8 pt (30.000 mo). It counts as at risk at 30 under the ≥ t rule, which is needed to reproduce the displayed 9. Rounding times to 4 decimals does not change any ordering.

## Verification (`code/checks.py` → `checks.json`)
- After reloading the committed CSV, the right-continuous KM matches the measured step function at 28–30 times per arm, including 0, early drops, and the tail up to about 35.3 mo. The maximum absolute residual is 0 (tolerance 0.002).
- Risk counts (records with observed_time ≥ t) equal the displayed table at all seven times in both arms.
- Arm sizes are 100/100. Events: A 74, B 65. The event indicators are integers.

## Limitations
- The reconstruction reproduces the figure's information exactly: event times, censoring times at plotting resolution, and the risk table. The true times are known only to the precision of the plotted coordinates (about 1e-4 pt, or 1e-5 mo). Events and censorings closer together than that would not be distinguishable.
- Two censorings at an identical time with a single drawn tick would be undetectable from ticks alone. Here they are ruled out because the risk-set sizes inferred from the drop ratios account for every censoring.
- Sensitivity analysis was not run. The drop ratios and tick counts leave no materially different feasible allocation, so there was no substantive alternative to test. `sensitivity.csv` was therefore not produced.
