# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png`: 1800×1350 raster Kaplan–Meier (KM) figure. Group A is blue (RGB 31,119,180) and Group B is orange (255,127,14).
- `../input/manifest.json`: n = 1000 per arm, time in months, code seed 325137287. The seed is recorded in the code, but the algorithm is deterministic and uses no random draws. The manifest supplies no arm-specific event totals, so the event-total check is marked unavailable.
- Number-at-risk table, read visually from the figure at 0/6/12/18/24/30/36 months. A: 1000, 737, 506, 356, 236, 91, 0. B: 1000, 763, 580, 433, 314, 121, 0. The digits are crisp and I consider these readings certain.

## Calibration
Axis tick marks were located from pixels. Each is 2 px wide, with centres at x = 269.5 (0 months) through 1709.5 (36 months), giving 40 px per month. On the y axis, 929.5 is S = 0 and 179.5 is S = 1, giving 750 px per unit, so 1 px = 0.00133. These are linear maps fixed by the labelled anchors. No global rescaling or origin correction was applied.

## Curve measurement (`code/reconstruct.py`, saved to `work/curve_{A,B}.csv`)
- For each column I take the colour run nearest the previous level. The plotted line is 4 px thick.
  - Clean column: level = bottom edge − 1.5 px. This is the right-continuous (post-drop) level.
  - Censor-tick column (run extends ≥ 5.5 px above the running level): level = tick centre if the run is 16–18 px tall; otherwise the column is left unresolved.
  - Other-colour pixel abutting the bottom edge: marked as overlap.
- Isolated low readings (> 3 px below the median of the next 5 readings) are dropped before any monotone constraint is applied. There was 1 such reading in A and 4 in B. They were single columns wedged between adjacent ticks, so a running minimum does not propagate a misread point.
- Unmeasured columns are filled by linear interpolation of the *measured* curve, with S(0) = 1 as the only anchor. Arm A is hidden under or interleaved with B for roughly t < 1.2 months. There A has few direct readings, and those range from 0.937 to 0.955 near t = 1. Early drops were kept, not forced flat.
- Event times use the column time plus 1.5 px (the half-width of the 4-px riser).

## Event/censor allocation (own algorithm, Guyot-type logic)
- Each risk-table interval [T_i, T_{i+1}) is processed in turn, starting from the displayed n_i.
- At each column, events are d = round(n_risk · (1 − S_meas / Ŝ_prev)). Here Ŝ_prev is the *reconstructed* KM, so rounding errors do not accumulate. Multiple events per column are allowed; d = 1 is not assumed.
- The number censored in the interval, c_i, is solved by fixed-point iteration from c = 0 so that the number at risk at T_{i+1} equals the displayed count.
- **Primary assumption: censoring times are the detected tick times.**
  - A tick cluster of width w counts as ceil(w/4) ticks. This is the minimal visible multiplicity, not proven multiplicity.
  - c_i is spread cyclically over the ticks in the interval.
  - Detected ticks: A 200, B 207. Reconstructed censorings: A 248, B 319. So some ticks carry more than one censoring, which is consistent with the overplotting visible in the dense regions after 24 months.
- Last interval: the displayed 0 at 36 months forces everyone remaining to exit before 36. The last visible ticks are at about 35.95 months, and no record is placed at or after 36.
- Tick multiplicity, and therefore the exact timing of censorings within an interval, is not identified by the figure. The flat tails do not identify a follow-up distribution, and I do not claim unique recovery.

## Results and checks (`checks.json`, computed from the committed CSV and its SHA-256)
- Primary events: A 752 (248 censored), B 681 (319 censored). These are reconstruction outputs, not supplied totals.
- Displayed risk counts, with at risk = number of records with observed_time ≥ t: reproduced exactly at every time point in both arms. The 0 at 36 is met with maximum times below 36.
- Survival, comparing the right-continuous step KM with the measured curve, 19 check times per arm. Tolerance is 0.005 (about 3.75 px), which allows for ±0.5 px raster error, tick/overlap occlusion and integer rounding of events.
  - All available checks pass, except A at t = 1: residual −0.0084, marked **unresolved**. The measured readings within ±0.1 month span 0.937–0.955 because of the curve overlap. By t = 2 the residual is −0.0002.
  - A at t = 0.5 and B at t = 1 are **unavailable** (no direct pixel reading nearby because of the overlap).
  - Across all directly measured columns, mean |residual| is 0.0005 (A) and 0.0004 (B). The maximum is 0.009 in A (at t ≈ 1.1, overlap region) and 0.004 in B.

## Sensitivity (one alternative, run: `sensitivity.csv`, `work/sensitivity_comparison.json`)
- Alternative assumption: censorings spread uniformly within each risk-table interval instead of at the tick times.
- This also reproduces all risk counts. Events: A 757, B 688.
- At the common supported horizon of 35.9 months:

| Arm | S(35.9), primary | S(35.9), alternative | Area under KM to 35.9, primary | Area, alternative |
|---|---|---|---|---|
| A | 0.1561 | 0.1568 | 16.164 | 16.164 |
| B | 0.2205 | 0.2180 | 18.462 | 18.453 |

- This single alternative is not a confidence interval and does not bound reconstruction error.

## Limitations
- Censoring times within intervals depend on the allocation assumption.
- The early A curve (t < 1.2 months) is partly occluded.
- Event times are quantised to the 0.025-month pixel grid, so ties are artificial.
- No covariates or information beyond the figure and manifest were used.

## Reproduce
From the work directory: `python3 output/code/reconstruct.py`, then `python3 output/code/checks.py`. Optionally, for the sensitivity analysis: `reconstruct.py --censor uniform --csv sensitivity.csv`, then `sensitivity_compare.py`. Use `--input` to point at a different input directory.
