"""Reload committed CSV, recompute right-continuous KM, compare with measured curve and risk table.
Usage: python checks.py [--out output] [--csv ipd.csv]"""
import argparse, hashlib, json, os
import numpy as np, pandas as pd

here = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("--out", default=os.path.join(here, ".."))
ap.add_argument("--csv", default="ipd.csv")
ap.add_argument("--json", default="checks.json")
args = ap.parse_args()

path = os.path.join(args.out, args.csv)
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
ipd = pd.read_csv(path)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 737, 506, 356, 236, 91, 0], "B": [1000, 763, 580, 433, 314, 121, 0]}
N = {"A": 1000, "B": 1000}
TOL = 0.005  # ~3.75 px: 1 px = 0.00133; allows line-width/raster/interp error and tick occlusion


def km(t, e):
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        S *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); out.append((u, S))
    return np.array(out)


def S_at(st, x):
    m = st[:, 0] <= x
    return 1.0 if not m.any() else float(st[m, 1][-1])


res = {"csv": args.csv, "sha256": sha, "tolerance_survival": TOL,
       "tolerance_justification": "1 px = 0.00133 in S; readings are +/-0.5 px plus up to ~2 px "
       "from tick occlusion/overlap interpolation; rounding of integer events adds <~0.001",
       "groups": {}}
for g in "AB":
    d = ipd[ipd.group == g]; t = d.observed_time.values; e = d.event.values
    cur = pd.read_csv(os.path.join(args.out, "work", f"curve_{g}.csv"))
    st = km(t, e)
    gr = {"n_records": int(len(d)), "n_expected": N[g], "n_pass": bool(len(d) == N[g]),
          "event_indicator_integer_01": bool(set(np.unique(e)) <= {0, 1}),
          "times_finite_nonneg": bool(np.isfinite(t).all() and (t >= 0).all()),
          "n_events": int(e.sum()), "n_censored": int((e == 0).sum()),
          "supplied_event_total": "unavailable (not in manifest)",
          "max_time": float(t.max()), "risk": [], "survival": []}
    for tt, n in zip(RISK_T, RISK[g]):
        r = int((t >= tt).sum())
        gr["risk"].append({"t": tt, "displayed": n, "reconstructed": r, "residual": r - n,
                           "status": "pass" if r == n else "fail"})
    for tt in [0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, 35.9]:
        row = cur[(cur.t <= tt)].tail(8)
        mrow = row.dropna(subset=["s_meas"])
        if len(mrow) == 0:
            gr["survival"].append({"t": tt, "status": "unavailable (no direct pixel reading near t)"})
            continue
        m = float(mrow.s_meas.iloc[-1]); r = S_at(st, tt)
        win = cur[(cur.t >= tt - 0.1) & (cur.t <= tt + 0.1)].s_meas.dropna()
        lo, hi = float(win.min()), float(win.max())
        if abs(r - m) <= TOL:
            status = "pass"
        elif hi - lo > TOL and lo - 1e-9 <= r <= hi + 1e-9:
            status = "unresolved (local readings within +/-0.1 mo span %.4f-%.4f)" % (lo, hi)
        else:
            status = "fail"
        gr["survival"].append({"t": tt, "measured": round(m, 4), "measured_at_t": round(float(mrow.t.iloc[-1]), 3),
                               "reconstructed": round(r, 4), "residual": round(r - m, 4),
                               "local_measured_range": [round(lo, 4), round(hi, 4)], "status": status})
    # dense comparison over all directly measured columns
    mm = cur.dropna(subset=["s_meas"])
    rr = np.array([S_at(st, x) for x in mm.t.values]) - mm.s_meas.values
    gr["all_measured_columns"] = {"n": int(len(mm)), "mean_abs_resid": round(float(np.abs(rr).mean()), 5),
                                  "max_abs_resid": round(float(np.abs(rr).max()), 5),
                                  "t_of_max": round(float(mm.t.values[np.abs(rr).argmax()]), 3),
                                  "frac_within_tol": round(float((np.abs(rr) <= TOL).mean()), 4)}
    res["groups"][g] = gr
json.dump(res, open(os.path.join(args.out, args.json), "w"), indent=1)
for g in "AB":
    gr = res["groups"][g]
    print(g, gr["n_records"], gr["n_events"], [r["residual"] for r in gr["risk"]], gr["all_measured_columns"])
    print("  ", [(s["t"], s.get("residual"), s["status"][:4]) for s in gr["survival"]])
