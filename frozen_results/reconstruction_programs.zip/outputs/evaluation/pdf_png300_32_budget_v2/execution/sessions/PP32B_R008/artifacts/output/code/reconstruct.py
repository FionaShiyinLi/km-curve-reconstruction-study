"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input ../input] [--out output] [--censor ticks|uniform]
Steps: (1) pixel calibration from axis ticks, (2) per-column curve measurement,
(3) censor-tick detection, (4) interval-wise event/censor allocation constrained
by the number-at-risk table, (5) atomic CSV write.
"""
import argparse, json, os, sys, tempfile
import numpy as np, pandas as pd
from PIL import Image

SEED = 325137287  # supplied code seed; algorithm is deterministic, seed recorded only
np.random.seed(SEED)

ap = argparse.ArgumentParser()
here = os.path.dirname(os.path.abspath(__file__))
ap.add_argument("--input", default=os.path.join(here, "..", "..", "..", "input"))
ap.add_argument("--out", default=os.path.join(here, ".."))
ap.add_argument("--censor", default="ticks", choices=["ticks", "uniform"])
ap.add_argument("--csv", default="ipd.csv")
args = ap.parse_args()

man = json.load(open(os.path.join(args.input, "manifest.json")))
img = np.array(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(int)

# ---- calibration (axis tick marks are 2 px wide: x ticks at 269/270 ... 1709/1710,
# y ticks at 929/930 (0.0) ... 179/180 (1.0); see assumptions.md)
X0, X1, T1 = 269.5, 1709.5, 36.0
Y0, Y1 = 929.5, 179.5
t_of = lambda x: (x - X0) / (X1 - X0) * T1
s_of = lambda y: (Y0 - y) / (Y0 - Y1)

COL = {"A": (31, 119, 180), "B": (255, 127, 14)}
masks = {g: (np.abs(img - np.array(c)).sum(2) < 60) for g, c in COL.items()}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 737, 506, 356, 236, 91, 0], "B": [1000, 763, 580, 433, 314, 121, 0]}
HALF = 1.5  # half line width (line is 4 px thick)


def runs(idx):
    if len(idx) == 0:
        return []
    br = np.where(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br + 1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st, en))


def measure(g):
    own, oth = masks[g], masks["B" if g == "A" else "A"]
    xs = np.arange(270, 1710)
    level = np.full(len(xs), np.nan)   # curve row (right-continuous level) per column
    tick = np.zeros(len(xs), bool)
    status = []
    prev = Y1
    for i, x in enumerate(xs):
        rr = runs(np.where(own[150:940, x])[0] + 150)
        if not rr:
            status.append("missing"); continue
        top, bot = min(rr, key=lambda r: min(abs(r[0] - prev), abs(r[1] - prev)))
        h = bot - top + 1
        contaminated = oth[bot + 1:bot + 3, x].any()  # other curve abutting the bottom edge
        if top <= prev - HALF - 4:           # extends above the running level: censor tick
            tick[i] = True
            if 16 <= h <= 18 and not contaminated:
                level[i] = (top + bot) / 2; status.append("tick_flat")
            else:
                status.append("tick_unresolved")
        elif contaminated:
            status.append("overlap")
        else:
            level[i] = bot - HALF; status.append("clean")
        if not np.isnan(level[i]):
            prev = level[i]
    t = t_of(xs + HALF)   # first column showing a new level is centre-1.5 of the 4-px riser
    s = s_of(level)
    ok = ~np.isnan(s)
    # isolated low readings (single columns between adjacent ticks read at a tick's lower
    # arm) would otherwise propagate through the monotone constraint: drop a reading that
    # lies >3 px below the median of the next 5 measured readings.
    idx = np.where(ok)[0]
    for k, i in enumerate(idx[:-5]):
        nxt = np.median(s[idx[k + 1:k + 6]])
        if s[i] < nxt - 3 / (Y0 - Y1):
            status[i] = "outlier_low"
    s = np.where(np.array(status) == "outlier_low", np.nan, s)
    ok = ~np.isnan(s)
    # fill unmeasured columns by linear interpolation in time between measured ones (S(0)=1 anchor)
    s_f = np.interp(t, np.r_[0.0, t[ok]], np.r_[1.0, s[ok]])
    # tick clusters -> tick times with minimal multiplicity ceil(width/4)
    ticks = []
    for a, b in runs(np.where(tick)[0]):
        w = b - a + 1; k = max(1, int(np.ceil(w / 4.0)))
        centres = np.linspace(xs[a] + 1.5, xs[b] - 1.5, k) if k > 1 else [(xs[a] + xs[b]) / 2]
        ticks += [t_of(c) for c in centres]
    return pd.DataFrame({"x": xs, "t": t, "s_meas": s, "s": s_f, "status": status, "tick": tick}), np.array(ticks)


def km_steps(times, events):
    o = np.lexsort((1 - events, times)); times, events = times[o], events[o]
    ut = np.unique(times[events == 1]); S = 1.0; out = []
    for u in ut:
        n = (times >= u).sum(); d = ((times == u) & (events == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return np.array(out)


def km_at(steps, t):
    if len(steps) == 0 or t < steps[0, 0]:
        return 1.0
    return steps[steps[:, 0] <= t, 1][-1]


def reconstruct(g, df, ticks, mode):
    recs = []
    n_start = RISK[g][0]; Shat = 1.0; last_meas = 1.0
    for j in range(len(RISK_T) - 1):
        a, b = RISK_T[j], RISK_T[j + 1]
        n_i, n_next = RISK[g][j], RISK[g][j + 1]
        sub = df[(df.t >= a) & (df.t < b)]
        tk = ticks[(ticks >= a) & (ticks < b)]
        # start from c=0: starting at c=n_i-n_next is a spurious fixed point (the clamp that
        # reserves at-risk subjects for future censorings then suppresses all events)
        c, seen = 0, {}
        for _ in range(200):
            if mode == "ticks" and len(tk) > 0:
                # c censorings distributed over detected tick times in proportion (cyclic)
                ctimes = np.sort(tk[np.arange(c) % len(tk)]) if c > 0 else np.array([])
            else:
                ctimes = a + (np.arange(c) + 0.5) * (b - a) / c if c > 0 else np.array([])
            S_run, prev_s, D = Shat, last_meas, 0
            ev = []
            for tt, ss in zip(sub.t.values, sub.s.values):
                nr = n_i - D - (ctimes < tt).sum()
                if nr <= 0:
                    break
                target = min(ss, prev_s)   # monotone within observation noise
                d = int(round(nr * (1 - target / S_run))) if S_run > 0 else 0
                d = max(0, min(d, nr - (ctimes >= tt).sum()))
                if d > 0:
                    ev += [tt] * d; D += d; S_run *= 1 - d / nr
                prev_s = target
            c_new = max(0, n_i - n_next - D)
            seen[c] = (abs(c_new - c), ev, ctimes, S_run, prev_s)
            if c_new == c or c_new in seen:
                break
            c = c_new
        c = min(seen, key=lambda k: seen[k][0])   # exact fixed point if reached, else best
        mis, ev, ctimes, S_run, prev_s = seen[c]
        if mis:
            print(f"  {g} [{a},{b}): risk-table mismatch {mis} after iteration")
        recs += [(g, x, 1) for x in ev] + [(g, x, 0) for x in ctimes]
        Shat, last_meas = S_run, prev_s
    return recs


def main():
    allrec, meas = [], {}
    for g in ["A", "B"]:
        df, ticks = measure(g)
        df.to_csv(os.path.join(args.out, "work", f"curve_{g}.csv"), index=False)
        np.savetxt(os.path.join(args.out, "work", f"ticks_{g}.txt"), ticks, fmt="%.4f")
        recs = reconstruct(g, df, ticks, args.censor)
        if len(recs) != man["groups"][g]:
            sys.exit(f"group {g}: {len(recs)} records != {man['groups'][g]}; not writing")
        allrec += recs
        print(g, "records", len(recs), "events", sum(r[2] for r in recs), "ticks", len(ticks),
              "status", df.status.value_counts().to_dict())
    out = pd.DataFrame(allrec, columns=["group", "observed_time", "event"])
    out["observed_time"] = out.observed_time.round(4)
    fd, tmp = tempfile.mkstemp(dir=args.out, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        out.to_csv(f, index=False)
    os.replace(tmp, os.path.join(args.out, args.csv))


if __name__ == "__main__":
    main()
