"""Compare primary and sensitivity reconstructions at a common supported horizon.
Usage: python sensitivity_compare.py [--out output]"""
import argparse, json, os
import numpy as np, pandas as pd
here = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(here, "..")); args = ap.parse_args()
H = 35.9  # last curve column is t~35.95 in both arms; risk table gives 0 at 36


def km(t, e):
    ut = np.unique(t[e == 1]); S = 1.0; out = [(0.0, 1.0)]
    for u in ut:
        S *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum(); out.append((u, S))
    return np.array(out)


def summ(st, h):
    x = np.r_[st[st[:, 0] <= h, 0], h]; y = st[st[:, 0] <= h, 1]
    return float(y[-1]), float(np.sum(np.diff(x) * y))   # S(h), area under step curve to h


res = {"horizon_months": H, "primary": "ipd.csv (censorings placed at detected tick times)",
       "alternative": "sensitivity.csv (censorings spread uniformly within each risk-table interval)"}
for f in ["ipd.csv", "sensitivity.csv"]:
    d = pd.read_csv(os.path.join(args.out, f))
    for g in "AB":
        x = d[d.group == g]; st = km(x.observed_time.values, x.event.values)
        S, A = summ(st, H)
        res.setdefault(g, {})[f] = {"events": int(x.event.sum()), "S_h": round(S, 4), "area_0_h": round(A, 3)}
json.dump(res, open(os.path.join(args.out, "work", "sensitivity_comparison.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
