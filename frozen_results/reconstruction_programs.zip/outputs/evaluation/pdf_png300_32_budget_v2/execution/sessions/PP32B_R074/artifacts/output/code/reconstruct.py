#!/usr/bin/env python3
"""KM-to-IPD reconstruction from the vector objects of a Kaplan-Meier PDF.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: INPUT_DIR=../input, OUTPUT_DIR=output (relative to the work dir).
Deterministic; the seed from the manifest is set and recorded but no random
draw is used by the primary algorithm.
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
os.makedirs(OUT, exist_ok=True)
man = json.load(open(os.path.join(IN, "manifest.json")))
SEED = man["code_seed"]; np.random.seed(SEED)
N = man["groups"]

page = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]
BLUE = (0.121569, 0.466667, 0.705882); ORANGE = (1.0, 0.498039, 0.054902)
COL = {"A": BLUE, "B": ORANGE}  # legend: blue line precedes "Group A", orange precedes "Group B"

# ---- axis calibration from black tick marks + tick labels ----
blk = [l for l in page.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted({round(l["x0"], 4) for l in blk if l["x0"] == l["x1"] and l["bottom"] - l["top"] < 5})
yt = sorted({round(l["top"], 4) for l in blk if l["top"] == l["bottom"] and l["x1"] - l["x0"] < 5})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # read from text layer
assert len(xt) == 7 and len(yt) == 6
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
calib = {"x_ticks_pt": xt, "x_labels": xlab, "y_ticks_pt": yt, "y_labels": ylab,
         "t_per_pt": ax, "t_intercept": bx, "S_per_pt": ay, "S_intercept": by,
         "x_fit_maxresid": float(np.max(np.abs(np.polyval([ax, bx], xt) - xlab))),
         "y_fit_maxresid": float(np.max(np.abs(np.polyval([ay, by], yt) - ylab)))}
T = lambda x: ax * x + bx
S = lambda top: ay * top + by

def close(c1, c2): return all(abs(a - b) < 1e-4 for a, b in zip(c1, c2))

# ---- risk table from text layer ----
chars = page.chars
def row_numbers(top):
    cs = sorted([c for c in chars if abs(c["top"] - top) < 1 and c["x0"] > 50], key=lambda c: c["x0"])
    nums, cur, lastx = [], "", None
    for c in cs:
        if lastx is not None and c["x0"] - lastx > 1: nums.append((cur, cx)); cur = ""
        if cur == "": cx = c["x0"]
        cur += c["text"]; lastx = c["x1"]
    nums.append((cur, cx)); return nums
rowtop = {c2["text"]: c2["top"] for c2 in chars if c2["x0"] > 43 and c2["x0"] < 44 and c2["top"] > 280}
risk = {}
for g in "AB":
    nums = row_numbers(rowtop[g])
    risk[g] = [(xlab[i], int(v)) for i, (v, _) in enumerate(nums)]

rows, meas, drops_log = [], {}, {}
for g in "AB":
    cur = [c for c in page.curves if close(c["stroking_color"], COL[g])]
    assert len(cur) == 1
    pts = [(float(x), float(y)) for x, y in cur[0]["pts"]]
    # pdfplumber pts are in top-down coords already
    # step path: measured curve vertices
    steps = []  # (t, S_before, S_after)
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x0 - x1) < 1e-6 and y1 > y0 + 1e-6:
            steps.append((T(x0), S(y0), S(y1)))
    t_end = T(pts[-1][0]); S_end = S(pts[-1][1])
    S0 = S(pts[0][1])
    ticks = [l for l in page.lines if close(l["stroking_color"], COL[g]) and l["linewidth"] < 0.9]
    ctimes = np.array(sorted(T(l["x0"]) for l in ticks))
    ctick_S = [S((l["top"] + l["bottom"]) / 2) for l in ticks]
    meas[g] = {"start_S": S0, "end_t": t_end, "end_S": S_end, "steps": steps,
               "censor_ticks": [[T(l["x0"]), S((l["top"] + l["bottom"]) / 2)] for l in ticks]}
    # sequential KM inversion: at each drop time, n_risk = N - events so far - censors strictly before t
    n_ev = 0; Srec = 1.0; log = []
    ev_times = []
    for (t, sb, sa) in steps:
        nrisk = N[g] - n_ev - int(np.sum(ctimes < t - 1e-9))
        d_real = nrisk * (1 - sa / Srec)          # relative to reconstructed S (no drift)
        d_meas = nrisk * (1 - sa / sb)            # relative to measured S_before
        d = max(1, int(round(d_real)))
        n_ev += d; Srec *= 1 - d / nrisk
        ev_times += [t] * d
        log.append({"t": t, "S_before_meas": sb, "S_after_meas": sa, "n_risk": nrisk,
                    "d_real": d_real, "d_from_measured_ratio": d_meas, "d": d, "S_rec_after": Srec})
    drops_log[g] = log
    n_cens_needed = N[g] - n_ev
    if n_cens_needed != len(ctimes):
        print(f"WARNING {g}: events {n_ev}, ticks {len(ctimes)}, N {N[g]}")
    for t in ev_times: rows.append((g, t, 1))
    for t in ctimes: rows.append((g, t, 0))
    extra = n_cens_needed - len(ctimes)
    meas[g]["n_events"] = n_ev; meas[g]["n_ticks"] = len(ctimes); meas[g]["unallocated"] = extra

df = pd.DataFrame(rows, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0)  # full float precision (distinct steps can be <1e-4 mo apart)
df = df.sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
ok = all((df.group == g).sum() == N[g] for g in "AB")
json.dump({"calibration": calib, "risk_table_read": risk, "measured": meas, "drops": drops_log},
          open(os.path.join(OUT, "extracted_observations.json"), "w"), indent=1)
if ok:
    tmp = os.path.join(OUT, "ipd.csv.tmp")
    df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, "ipd.csv"))
    print("wrote ipd.csv", df.groupby("group").event.agg(["size", "sum"]).to_dict())
else:
    print("group sizes do not match; ipd.csv not written", df.groupby("group").size().to_dict())
for g in "AB":
    L = drops_log[g]
    print(g, "drops", len(L), "events", meas[g]["n_events"], "ticks", meas[g]["n_ticks"],
          "max|d_real-d|", max(abs(r["d_real"] - r["d"]) for r in L),
          "max d", max(r["d"] for r in L), "start S", meas[g]["start_S"], "end", t_end if g=="B" else meas[g]["end_t"], meas[g]["end_S"])
print("calib", calib["x_fit_maxresid"], calib["y_fit_maxresid"], "risk", risk)
