#!/usr/bin/env python3
"""Reload committed output/ipd.csv, recompute right-continuous KM, compare to measured vector curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
csv = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(csv, "rb").read()).hexdigest()
df = pd.read_csv(csv, float_precision="round_trip"); ex = json.load(open(os.path.join(OUT, "extracted_observations.json")))
N = {"A": 1000, "B": 1000}
TOL_S = 0.002  # vector coords are given to ~1e-5 pt (~6e-8 in S); 0.002 is a conservative display tolerance

def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return np.array(out)
def step_at(curve, t):  # right-continuous
    i = np.searchsorted(curve[:, 0], t, side="right") - 1
    return 1.0 if i < 0 else curve[i, 1]
def meas_at(steps, S0, t):
    s = S0
    for (tt, sb, sa) in steps:
        if tt <= t: s = sa
        else: break
    return s

res = {"csv_sha256": sha, "tolerance_S": TOL_S,
       "tolerance_note": "measured curve is exact PDF vector geometry; tolerance only guards float rounding", "arms": {}}
allpass = True
for g in "AB":
    d = df[df.group == g]; K = km(d); m = ex["measured"][g]
    steps = m["steps"]
    times = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, m["end_t"]]
    comp = []
    for t in times:
        o = meas_at(steps, m["start_S"], t); r = step_at(K, t)
        comp.append({"t": round(t, 4), "measured": round(o, 6), "reconstructed": round(float(r), 6),
                     "residual": round(float(r - o), 7), "status": "pass" if abs(r - o) <= TOL_S else "fail"})
    # all-step check
    EPS = 1e-9  # months; far below the minimum spacing of distinct measured steps (3e-5), guards float repr only
    allres = [abs(step_at(K, tt + EPS) - sa) for (tt, sb, sa) in steps]
    rk = []
    for t, n in ex["risk_table_read"][g]:
        c = int((d.observed_time >= t).sum())
        rk.append({"t": t, "displayed": n, "reconstructed": c, "residual": c - n, "status": "pass" if c == n else "fail"})
    # censor-tick height vs KM at tick time (tick belongs to this arm)
    tk = [abs(step_at(K, t) - s) for t, s in m["censor_ticks"]]
    arm = {"n_records": int(len(d)), "n_expected": N[g], "n_events": int(d.event.sum()),
           "n_censored": int((d.event == 0).sum()), "event_indicator_integer_01": bool(d.event.isin([0, 1]).all()),
           "supplied_event_total": "unavailable (not in manifest)",
           "max_time": float(d.observed_time.max()), "min_time": float(d.observed_time.min()),
           "survival_checks": comp, "max_abs_resid_all_measured_steps": float(max(allres)), "n_measured_steps": len(steps),
           "risk_table_checks": rk, "censor_tick_height_max_abs_diff": float(max(tk)),
           "tail": {"measured_end_t": m["end_t"], "measured_end_S": m["end_S"],
                    "reconstructed_S_at_end": float(step_at(K, m["end_t"])), "records_at_or_after_36": int((d.observed_time >= 36).sum())}}
    arm["status"] = "pass" if (len(d) == N[g] and all(c["status"] == "pass" for c in comp + rk)
                              and max(allres) <= TOL_S and max(tk) <= TOL_S) else "fail"
    allpass &= arm["status"] == "pass"
    res["arms"][g] = arm
    print(g, arm["status"], arm["n_events"], arm["max_abs_resid_all_measured_steps"], arm["censor_tick_height_max_abs_diff"],
          [(r["t"], r["displayed"], r["reconstructed"]) for r in rk])
res["overall"] = "pass" if allpass else "fail"
tmp = os.path.join(OUT, "checks.json.tmp"); json.dump(res, open(tmp, "w"), indent=1); os.replace(tmp, os.path.join(OUT, "checks.json"))

# raster overlay for visual inspection
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, subprocess
IN = sys.argv[2] if len(sys.argv) > 2 else "../input"
png = os.path.join(OUT, "figure_render")
subprocess.run(["pdftoppm", "-r", "150", "-png", "-singlefile", os.path.join(IN, "figure.pdf"), png], check=True)
img = plt.imread(png + ".png"); h, w = img.shape[:2]; sc = w / 432.0
cal = ex["calibration"]
fig, a = plt.subplots(figsize=(9, 7)); a.imshow(img)
for g, c in zip("AB", ["k", "m"]):
    K = km(df[df.group == g]); tt = np.r_[0, np.repeat(K[:, 0], 2), 36]; ss = np.r_[1, 1, np.repeat(K[:, 1], 2)][:len(tt)]
    x = (tt - cal["t_intercept"]) / cal["t_per_pt"] * sc; y = (ss - cal["S_intercept"]) / cal["S_per_pt"] * sc
    a.plot(x, y, c, lw=0.6, ls="--", label=f"reconstructed {g}")
a.legend(); fig.savefig(os.path.join(OUT, "overlay.png"), dpi=110, bbox_inches="tight")
