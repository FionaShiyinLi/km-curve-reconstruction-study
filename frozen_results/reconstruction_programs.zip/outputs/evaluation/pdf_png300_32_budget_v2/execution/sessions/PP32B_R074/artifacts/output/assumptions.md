# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf` (vector PDF, one page) and `../input/manifest.json` (N_A = N_B = 1000, months, code seed 1496593116).
- No arm-specific event totals are supplied. Event totals are therefore marked unavailable in the checks, and they were not treated as zero.
- Risk table as read from the PDF text layer. A: 1000, 667, 444, 290, 197, 65, 0 at 0, 6, ..., 36 months. B: 1000, 775, 568, 440, 339, 143, 0.

## Measurement
- The figure is fully vector. Each arm is a single stroked step path: blue (0.122, 0.467, 0.706) for Group A and orange (1.0, 0.498, 0.055) for Group B. Arms were assigned from the legend, where each colored line segment sits immediately before its "Group A"/"Group B" label.
- Censor marks are separate vertical 4-pt line objects in the arm's color: 194 for A and 360 for B. Each mark's vertical center lies on its arm's curve, with a maximum discrepancy of 3e-7 in S.
- Calibration came from the black axis tick objects and their text labels: 7 x ticks (0 to 36) and 6 y ticks (0.0 to 1.0). Both linear fits are exact (residual below 1e-13). No global rescaling or correction was applied.
- Both paths start exactly at S = 1.000 at t = 0. Genuine early drops are kept: the first events fall at 0.024 months (A) and 0.010 months (B).
- The measurement for every vertex is saved in `extracted_observations.json`: calibration, all step vertices, censor marks and the per-drop inversion log. `figure_render.png` and `overlay.png` are provided for visual inspection.

## Algorithm (`code/reconstruct.py`, deterministic)
For each measured drop at time t, taken in order:
- n_risk = N minus events so far minus censor marks strictly before t.
- d_real = n_risk × (1 − S_after/Ŝ_before), where Ŝ is the reconstructed KM, so errors cannot accumulate.
- d is d_real rounded to the nearest integer, and d events are placed at t.
- Each censor mark becomes one censored record at its x-time.

Evidence for multiplicity:
- Every one of the 1,446 drops (806 in A, 640 in B) gives d_real within 3e-4 of 1. The alternatives d = 0 or d = 2 would be off by roughly 1.
- Events plus marks equal N exactly in each arm (806 + 194, 640 + 360). This closure is only possible if each mark is one participant and each drop one event.

The seed is set, but the algorithm makes no random draws.

## Censoring, ties, risk table
- Overlapping marks: no two censor marks in an arm share a time. The closest pair is 0.0004 months apart, and PDF objects keep any duplicates. No censor time coincides with an event time, so the tie convention (events before censorings) was never needed.
- Unobserved censoring: none was imputed, since the closure above leaves none unaccounted for.
- Tail: follow-up after the last mark is not inferred. The last records are censorings at 35.85 months (A) and 35.96 months (B). Three censorings in each arm fall after that arm's last event.
- Risk table: the counts of records with observed_time ≥ t reproduce all 14 displayed numbers exactly, including 0 at 36 months (no record is ≥ 36). No record was adjusted to force agreement.

## Verification (`code/checks.py` → `checks.json`)
- The committed CSV was reloaded and the right-continuous KM recomputed.
- Comparison with the measured step function at 18 times per arm, including 0, 0.5, the tail and the final vertex: maximum absolute difference about 1e-6.
- Comparison immediately after every measured step: maximum 3e-7.
- The tolerance of 0.002 in S only guards float representation, because the measurement is exact geometry. The step checks are evaluated at t + 1e-9 months so that one-ulp CSV round-trip differences do not flip the right-continuous lookup. This value is far below the minimum 3e-5-month spacing between steps.
- Correction cycle used: one. The first CSV rounded times to 6 decimals, which could move an event just past its measured step time, so times are now written at full precision.

## Limitations
- Times are the plotted x-coordinates. If the original plot was generated from rounded times (for example, days), those values are not recoverable beyond plot precision. The coordinates are given to about 1e-5 pt, roughly 1e-6 months.
- The reconstruction is exact with respect to what is drawn. It rests on the rendered figure encoding one mark per censored participant, which the N closure supports but cannot prove.
- No covariates or other information were used or created.
- Sensitivity analysis was not run. The drawn objects left no materially different feasible allocation: multiplicities are pinned down, there are no overlapping or tied marks, and there is no residual censoring to distribute. Any alternative would be invented rather than supported by the input.
