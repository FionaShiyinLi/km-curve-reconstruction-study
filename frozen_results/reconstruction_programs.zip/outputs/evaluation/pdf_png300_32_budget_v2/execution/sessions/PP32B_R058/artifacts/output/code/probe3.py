import numpy as np
from PIL import Image
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
for name,col in [('A',(31,119,180)),('B',(255,127,14))]:
    m=(np.abs(im-np.array(col)).sum(2)<60)
    # tick shape near known ticks
    x0={'A':1602,'B':1633}[name]
    for x in range(x0-4,x0+5): print(name,x,np.where(m[:,x])[0])
    # partially colored (antialias) pixels count
    near=(np.abs(im-np.array(col)).sum(2)<250)&~m&(im.sum(2)<740)
    print('aa',near[150:940,265:1720].sum())
