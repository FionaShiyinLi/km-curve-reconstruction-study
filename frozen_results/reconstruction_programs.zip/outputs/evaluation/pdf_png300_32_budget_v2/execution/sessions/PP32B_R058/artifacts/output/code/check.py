"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve and risk table.
Writes ../checks.json (and sensitivity comparison if ../sensitivity.csv exists) and ../overlay.png."""
import json, hashlib, numpy as np, pandas as pd
from pathlib import Path
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent; OUT=HERE.parent
man=json.load(open(HERE/'../../../input/manifest.json')); ex=json.load(open(OUT/'extracted.json')); rt=json.load(open(HERE/'risk_table.json'))
TOL=0.005  # 3.75 px; measurement of line centre is +/-0.5 px (0.0007) but step timing within 1-2 px and hidden overlap regions add error; < one event at n=100 (0.0075+)
def km(d):
    t=np.sort(d.observed_time.unique()); S=1; out=[]
    for u in t:
        n=(d.observed_time>=u).sum(); e=((d.observed_time==u)&(d.event==1)).sum()
        S*=1-e/n; out.append((u,S))
    return np.array(out)
def Sat(k,t):
    i=np.searchsorted(k[:,0],t,side='right')-1
    return 1.0 if i<0 else k[i,1]
def rmst(k,h):
    ts=np.concatenate([[0],k[:,0][k[:,0]<h],[h]]); a=0
    for x0,x1 in zip(ts[:-1],ts[1:]): a+=Sat(k,x0)*(x1-x0)
    return a
def load(fn):
    return pd.read_csv(fn)
csv=OUT/'ipd.csv'; df=load(csv); sha=hashlib.sha256(open(csv,'rb').read()).hexdigest()
checks=dict(csv_sha256=sha,tolerance_survival=TOL,tolerance_note='abs(KM_recon - measured) <= 0.005 at segment midpoints >=0.1 mo from any step; risk counts must match exactly',
            columns_ok=list(df.columns)==['group','observed_time','event'],arms={})
fig,ax=plt.subplots(figsize=(9,6))
for g,c in [('A','tab:blue'),('B','tab:orange')]:
    d=df[df.group==g]; k=km(d); ar={}
    ar['n_records']=int(len(d)); ar['n_expected']=man['groups'][g]; ar['n_pass']=ar['n_records']==ar['n_expected']
    ar['event_integer_01']=bool(d.event.isin([0,1]).all()); ar['times_finite_nonneg']=bool(np.isfinite(d.observed_time).all() and (d.observed_time>=0).all())
    ar['n_events']=int(d.event.sum()); ar['n_censored']=int((d.event==0).sum())
    ar['supplied_event_total']='unavailable (manifest has no event totals)'
    steps_t=np.sort(d.observed_time[d.event==1].unique())
    comp=[]
    for s in ex[g]['segments']:
        if s.get('hidden_fill') or s['x1']-s['x0']<8: continue
        t=(s['t0']+s['t1'])/2
        if len(steps_t) and np.min(np.abs(steps_t-t))<0.1: continue
        r=Sat(k,t); comp.append(dict(t=round(t,3),measured=round(s['S'],4),recon=round(float(r),4),resid=round(float(r-s['S']),4),status='pass' if abs(r-s['S'])<=TOL else 'fail'))
    ar['curve_comparisons']=comp
    ar['curve_max_abs_resid']=max(abs(x['resid']) for x in comp); ar['curve_n_fail']=sum(x['status']=='fail' for x in comp)
    ar['tail_check']=[x for x in comp if x['t']>=30]
    rk=[]
    for t,n in zip(rt['times'],rt[g]):
        m=int((d.observed_time>=t).sum()); rk.append(dict(t=t,displayed=n,recon=m,resid=m-n,status='pass' if m==n else 'fail'))
    ar['risk_table']=rk; ar['max_time']=float(d.observed_time.max())
    checks['arms'][g]=ar
    tt=np.linspace(0,36,2000); ax.step(k[:,0],k[:,1],where='post',color=c,label=f'{g} reconstructed KM')
    for s in ex[g]['segments']: ax.plot([s['t0'],s['t1']],[s['S']]*2,color='k',lw=0.6)
    ax.plot([x['t'] for x in ex[g]['ticks']],[x['S_level'] for x in ex[g]['ticks']],'|',color='k',ms=8)
ax.set_xlim(0,36); ax.set_ylim(0,1.02); ax.legend(); ax.set_title('Reconstructed KM (colour) vs measured segments/ticks (black)')
fig.savefig(OUT/'overlay.png',dpi=120)
sens=OUT/'sensitivity.csv'
if sens.exists():
    ds=load(sens); H=min(checks['arms'][g]['max_time'] for g in 'AB')
    H=min(H,min(float(ds[ds.group==g].observed_time.max()) for g in 'AB'))
    sc=dict(assumption='censorings spread uniformly within each risk-table interval (tick positions ignored); event algorithm identical',
            common_horizon_months=round(H,3),sensitivity_sha256=hashlib.sha256(open(sens,'rb').read()).hexdigest(),arms={})
    for g in 'AB':
        kp=km(df[df.group==g]); ks=km(ds[ds.group==g])
        sc['arms'][g]=dict(S_primary={t:round(Sat(kp,t),4) for t in [6,12,18,24,30,round(H,2)]},
            S_sensitivity={t:round(Sat(ks,t),4) for t in [6,12,18,24,30,round(H,2)]},
            RMST_primary=round(rmst(kp,H),3),RMST_sensitivity=round(rmst(ks,H),3),
            risk_sens=[int((ds[ds.group==g].observed_time>=t).sum()) for t in rt['times']])
    checks['sensitivity']=sc
else: checks['sensitivity']='not run'
json.dump(checks,open(OUT/'checks.json','w'),indent=1)
for g in 'AB':
    a=checks['arms'][g]; print(g,a['n_records'],a['n_events'],a['n_censored'],'maxres',a['curve_max_abs_resid'],'nfail',a['curve_n_fail'],'of',len(a['curve_comparisons']),[r['recon'] for r in a['risk_table']])
    print('  fails',[x for x in a['curve_comparisons'] if x['status']=='fail'])
print(json.dumps(checks['sensitivity'],indent=0)[:1500])
