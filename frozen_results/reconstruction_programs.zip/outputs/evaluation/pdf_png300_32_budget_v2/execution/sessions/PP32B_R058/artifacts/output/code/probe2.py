import numpy as np
from PIL import Image
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
dark=(im.sum(2)<200)
# x ticks: dark pixels in rows 933-940
r=dark[933:942].sum(0); print('xticks cols',np.where(r>=5)[0])
c=dark[:,255:268].sum(1); print('yticks rows',np.where(c>=8)[0])
for name,col in [('A',(31,119,180)),('B',(255,127,14))]:
    m=(np.abs(im-np.array(col)).sum(2)<60)
    ys,xs=np.where(m[100:1000]); print(name,xs.min(),xs.max(),ys.min()+100,ys.max()+100)
    # line thickness at a flat column
    x=1600 if name=='B' else 1560
    print(' col',x,np.where(m[:,x])[0])
