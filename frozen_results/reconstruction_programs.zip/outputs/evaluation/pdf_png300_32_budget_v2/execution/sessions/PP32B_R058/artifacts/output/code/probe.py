import numpy as np
from PIL import Image
from collections import Counter
im=np.array(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
c=Counter(map(tuple,im.reshape(-1,3))); print(c.most_common(12))
dark=(im.sum(2)<150)
# axis lines
cols=dark[150:940].sum(0); print('vert dark cols',[(i,cols[i]) for i in np.argsort(cols)[-4:]])
rows=dark[:,200:1750].sum(1); print('horiz dark rows',[(i,rows[i]) for i in np.argsort(rows)[-4:]])
