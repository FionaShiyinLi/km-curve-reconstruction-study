# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster, flat colours, no antialiasing) and `../input/manifest.json` (n = 100 per arm, months, seed 1314633784).
- Number-at-risk table read visually from the figure (no OCR tool was installed): A 100/68/47/35/21/7/0 and B 100/73/63/55/43/15/0 at 0, 6, ..., 36 months (`code/risk_table.json`). I consider all 14 cells clearly legible.
- No arm-specific event totals were supplied. This is recorded as `unavailable` in `checks.json` and should not be read as zero events.

## Pipeline (run from `output/code/`: `python extract.py; python reconstruct.py; python reconstruct.py --mode uniform; python check.py`)
1. **Calibration** (`extract.py`). The labelled axis ticks were located at pixel centres x = 269.5 + 40·t and y = 929.5 − 750·S. The linear-fit residuals are 0 at all 7 x ticks and all 6 y ticks, so no global transform or rescaling was applied. Both arms start on the labelled 1.0 gridline (line centre at row 179.5). The origin was not renormalised.
2. **Curve measurement.** Pixels were classified by exact line colour (A = #1f77b4, B = #ff7f0e). A horizontal level is a 3–5 px thick band of horizontal runs of at least 6 px. Each step time is the centre of the 4 px vertical line. Censor ticks are columns where the colour extends at least 4 px *below* the lowest local band. A drop line never does this, but a tick drawn on a drop does. Two 1–2 px slivers no more than 6 px apart were merged into one tick that had been split by a drop line. Measurements are saved in `extracted.json`, and the derived steps and ticks in `reconstruction_log_primary.json`.
3. **Overlap.** B is drawn over A. Where A is hidden (about 0–4 months), the A levels were taken from the coincident B bands lying between the visible A levels before and after the hidden stretch (`hidden_fill`). Otherwise the drop was placed at the midpoint of the hidden gap. Any A "ticks" inside hidden stretches are unreliable. The one detected there (1.75 mo) was rejected by the risk-table constraint, since zero censorings fit in 0–6 months. B has a genuine early drop at t ≈ 0.05 (1.00 → 0.99), and it was kept.
4. **Event and censoring allocation** (`reconstruct.py`, own implementation of a Guyot-type interval scheme). For each risk-table interval [t_k, t_k+1), the censoring count c was chosen so that the next displayed number at risk is matched, with ties broken toward the visible tick count. For each measured drop, d = round(n_risk·(1 − S_measured_after/Ŝ_before)), with d ≥ 1 for a visible drop. Here Ŝ is the reconstructed KM, so rounding errors do not accumulate. d is not assumed to be 1: 10 A times and 3 B times receive tied events. At ties, events precede censorings. Censorings go at the detected tick times. When c exceeds the number of visible ticks, extras are assigned first to wide ticks (width ≥ 5 px, i.e. possibly overlapping), then spread evenly across the interval's ticks. When c is smaller, an evenly spaced subset of ticks is used. **Tick multiplicity is an assumption.** Only the per-interval censoring totals are constrained, and those come from the risk table. The algorithm has no stochastic step. The seed is set and recorded anyway.
5. **Tail and follow-up.** The table shows 0 at risk at 36 months. All remaining participants are censored at the visible tail ticks (last A 35.41, last B 35.75 months, which is where each curve ends). No follow-up beyond the drawn curve was invented.

## Censoring beyond visible ticks (unresolved ambiguity)
Censorings needed vs distinct visible ticks: A 24–30: 10 vs 8. B 6–12: 3 vs 2. B 18–24: 2 vs 1. B 24–30: 23 vs 18. B 30–36: 15 vs 13. The extra censorings are presumably overlapping or merged ticks, or ticks hidden on drop lines, but their true times are not identified. This is the main source of reconstruction ambiguity.

## Checks (`checks.json`, computed from the reloaded committed CSV)
- 100 records per arm, event ∈ {0,1}, finite nonnegative times. A has 84 events and 16 censorings; B has 54 and 46.
- The right-continuous KM was compared with the measured level at 38 (A) and 33 (B) segment midpoints, including tail points after 30 months. Max |residual| is 0.0008 (A) and 0.0022 (B). The tolerance is 0.005, about 3.7 px, which is below one event at n = 100. All pass.
- Risk-table counts (observed_time ≥ t) match every displayed value exactly, including 0 at 36.
- Supplied event totals: unavailable.

## Sensitivity (`sensitivity.csv`, one alternative)
The alternative spreads censorings uniformly within each risk interval and ignores tick positions. Event rules are unchanged. The common supported horizon is 34.86 months (the earliest last observation across both files). Survival at the horizon is A 0.111 vs 0.098 and B 0.409 vs 0.416. Restricted mean survival time (RMST) to the horizon is A 14.47 vs 14.44 and B 20.97 vs 21.05 months. The risk table is matched in both versions. This is a single alternative. It is neither a confidence interval nor a bound on reconstruction error.

## Limitations
- The exact timing of events inside the hidden A stretches (0–4 months) and the exact within-pixel event times (resolution 0.025 months) are not recoverable. Tied times reflect the raster.
- Censoring times beyond the visible ticks are an assumption (see above). The flat tails do not identify the accrual or censoring distribution.
- `code/probe*.py` are exploratory inspection scripts. They are not needed for the pipeline.
