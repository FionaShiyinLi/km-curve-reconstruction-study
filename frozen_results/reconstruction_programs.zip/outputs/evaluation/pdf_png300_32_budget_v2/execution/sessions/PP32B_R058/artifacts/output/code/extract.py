"""Measure KM step curves and censor ticks from the raster figure.
Usage: python extract.py [path/to/figure.png]   (default ../../../input/figure.png)
Writes extracted_A.json / extracted_B.json next to this script's output dir (../)."""
import sys, json, numpy as np
from PIL import Image
from pathlib import Path
HERE=Path(__file__).resolve().parent
FIG=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'../../../input/figure.png'
im=np.array(Image.open(FIG).convert('RGB')).astype(int)
dark=im.sum(2)<200
# --- calibration from labelled axis ticks (0..36 months; 0..1 survival)
xt=np.where(dark[933:942].sum(0)>=5)[0]; xt=xt[xt>250]
xc=[g.mean() for g in np.split(xt,np.where(np.diff(xt)>1)[0]+1)]
yt=np.where(dark[:,255:268].sum(1)>=8)[0]
yc=[g.mean() for g in np.split(yt,np.where(np.diff(yt)>1)[0]+1)]
assert len(xc)==7 and len(yc)==6, (xc,yc)
px=np.polyfit(xc,[0,6,12,18,24,30,36],1); py=np.polyfit(yc,[1.0,0.8,0.6,0.4,0.2,0.0],1)
xres=np.polyval(px,xc)-np.array([0,6,12,18,24,30,36]); yres=np.polyval(py,yc)-np.array([1,.8,.6,.4,.2,0])
T=lambda x: float(np.polyval(px,x)); S=lambda y: float(np.polyval(py,y))
calib=dict(x_tick_px=xc,y_tick_px=yc,x_fit=list(px),y_fit=list(py),max_abs_x_resid_months=float(abs(xres).max()),max_abs_y_resid=float(abs(yres).max()))
COL={'A':(31,119,180),'B':(255,127,14)}
masks={g:(np.abs(im-np.array(c)).sum(2)<60) for g,c in COL.items()}
def runs(v):
    idx=np.where(v)[0]
    if len(idx)==0: return []
    sp=np.split(idx,np.where(np.diff(idx)>1)[0]+1); return [(s[0],s[-1]) for s in sp]
out={}
for g in ['B','A']:
    m=masks[g]
    # horizontal-line pixels: belong to a horizontal run >=6 px
    H=np.zeros_like(m)
    for y in range(150,935):
        for a,b in runs(m[y]):
            if b-a+1>=6: H[y,a:b+1]=True
    # bands: per column, runs of H rows; collect (x, ycenter)
    pts=[]
    for x in range(265,1720):
        for a,b in runs(H[:,x]):
            if 3<=b-a+1<=5: pts.append((x,(a+b)/2))
    # group into segments by identical y center and contiguous x
    pts.sort(key=lambda p:(p[1],p[0])); segs=[]
    for x,y in pts:
        if segs and abs(segs[-1][0]-y)<0.6 and x-segs[-1][2]<=1: segs[-1][2]=x
        else: segs.append([y,x,x])
    segs=[s for s in segs if s[2]-s[1]>=3]
    segs.sort(key=lambda s:s[1])
    # ticks: columns where mask extends >=4px above band top of the highest band nearby
    ticks=[]; tcols=[]
    for x in range(265,1720):
        col=m[:,x]
        if not col.any(): continue
        cover=[s for s in segs if s[1]-1<=x<=s[2]+1]
        if not cover: continue
        bot=max(s[0] for s in cover)+1.5   # bottom pixel row of lowest band
        yb=int(round(bot))
        # a censor tick extends ~7 px below the line; a drop line never extends below the lower band
        if col[yb+1:yb+5].all(): tcols.append(x)
    for grp in runs(np.isin(np.arange(1800),tcols)):
        xcen=(grp[0]+grp[1])/2; w=grp[1]-grp[0]+1
        cover=[s for s in segs if s[1]-1<=xcen<=s[2]+1]
        ticks.append(dict(x_px=xcen,width_px=int(w),t=T(xcen),S_level=S(max(s[0] for s in cover))))
    segs=[s for s in segs]
    if g=='A':
        other=out_B_segs
        filled=[]
        for s0,s1 in zip(segs[:-1],segs[1:]):
            filled.append(s0)
            if s1[1]-s0[2]>-2:  # lower segment starts right of the upper one's end: hidden gap
                for o in other:
                    if s0[0]+2<o[0]<s1[0]-2 and o[2]>=s0[2]-3 and o[1]<=s1[1]+3:
                        filled.append([o[0],max(o[1],s0[2]-3),min(o[2],s1[1]+3),'fromB'])
        filled.append(segs[-1]); segs=filled
    else: out_B_segs=[s[:3] for s in segs]
    seglist=[dict(y_px=s[0],x0=int(s[1]),x1=int(s[2]),S=S(s[0]),t0=T(s[1]),t1=T(s[2]),hidden_fill=(len(s)>3)) for s in segs]
    out[g]=dict(segments=seglist,ticks=ticks)
json.dump(dict(calibration=calib,**out),open(HERE/'../extracted.json','w'),indent=1,default=float)
print(json.dumps(calib,default=float))
for g in ['A','B']:
    print(g,'nseg',len(out[g]['segments']),'nticks',len(out[g]['ticks']))
    for s in out[g]['segments']: print('  seg S=%.4f t=%.3f-%.3f px %d-%d %s'%(s['S'],s['t0'],s['t1'],s['x0'],s['x1'],'FILL' if s['hidden_fill'] else ''))
    print('  ticks',[(round(k['t'],2),k['width_px'],round(k['S_level'],3)) for k in out[g]['ticks']])
