"""Reconstruct IPD from measured KM steps + censor ticks + risk table (own implementation).
Usage: python reconstruct.py [--mode primary|uniform]
  primary: censorings placed at detected tick positions (extras spread over ticks)
  uniform: sensitivity; censorings spread uniformly within each risk interval, ignoring ticks
Inputs: ../extracted.json (from extract.py), risk_table.json, ../../../input/manifest.json"""
import json, sys, os, numpy as np, pandas as pd
from pathlib import Path
HERE=Path(__file__).resolve().parent; OUT=HERE.parent
MODE=sys.argv[sys.argv.index('--mode')+1] if '--mode' in sys.argv else 'primary'
SEED=json.load(open(HERE/'../../../input/manifest.json'))['code_seed']
np.random.seed(SEED)  # no stochastic step is used; seed recorded for completeness
man=json.load(open(HERE/'../../../input/manifest.json'))
ex=json.load(open(OUT/'extracted.json')); rt=json.load(open(HERE/'risk_table.json'))
px=ex['calibration']['x_fit']; T=lambda x: px[0]*x+px[1]

def steps_for(g):
    segs=sorted(ex[g]['segments'],key=lambda s:-s['S'])
    merged=[]
    for s in segs:  # merge pieces of the same level split by ticks
        if merged and abs(merged[-1]['y_px']-s['y_px'])<0.6:
            merged[-1]['x0']=min(merged[-1]['x0'],s['x0']); merged[-1]['x1']=max(merged[-1]['x1'],s['x1'])
        else: merged.append(dict(s))
    steps=[]; prevS=1.0; prev_x1=None; last_t=0.0
    for i,s in enumerate(merged):
        if abs(s['S']-1.0)<1e-3: prev_x1=s['x1']; continue
        if prev_x1 is None: xd=s['x0']+1.5          # first visible level below 1 (drop from implied 1.0)
        else: xd=((prev_x1-1.5)+(s['x0']+1.5))/2     # centre of the 4-px vertical line; midpoint if hidden gap
        t=max(T(xd),last_t); steps.append(dict(t=t,S_before=prevS,S_after=s['S'],hidden_gap=bool(prev_x1 is not None and s['x0']-prev_x1>-1)))
        prevS=s['S']; prev_x1=s['x1']; last_t=t
    end_t=T(merged[-1]['x1']-1.5)
    return steps,end_t

def ticks_for(g):
    tk=sorted(ex[g]['ticks'],key=lambda k:k['x_px']); out=[]
    for k in tk:  # a single tick split by a coincident drop line appears as two 1-2 px slivers <=6 px apart
        if out and k['x_px']-out[-1]['x_px']<=6 and k['width_px']<=2 and out[-1]['width_px']<=2:
            out[-1]=dict(x_px=(out[-1]['x_px']+k['x_px'])/2,width_px=out[-1]['width_px']+k['width_px'],merged=True)
        else: out.append(dict(x_px=k['x_px'],width_px=k['width_px']))
    for k in out: k['t']=T(k['x_px'])
    return out

def place_censors(c,ticks,a,b):
    if c==0: return []
    if MODE=='uniform' or len(ticks)==0:
        return [a+(i+0.5)*(b-a)/c for i in range(c)]
    m=len(ticks); tt=[k['t'] for k in ticks]
    if c<=m:
        idx=np.unique(np.round(np.linspace(0,m-1,c)).astype(int)) if c>1 else [m//2]
        return [tt[i] for i in idx]
    extra=c-m; res=list(tt)
    order=sorted(range(m),key=lambda i:-ticks[i]['width_px'])  # wide (possibly overlapping) ticks first
    wide=[i for i in order if ticks[i]['width_px']>=5]
    for j in range(extra):
        if j<len(wide): res.append(tt[wide[j]])
        else:
            jj=j-len(wide); ne=extra-len(wide); res.append(tt[int(round((jj+0.5)*m/ne-0.5))])
    return sorted(res)

def run_interval(n0,drops,cens,Shat):
    n=n0; ev=[]; cs=sorted(cens); ci=0
    for st in drops:
        while ci<len(cs) and cs[ci]<st['t']: n-=1; ci+=1   # censor at tie stays at risk
        d=int(round(n*(1-st['S_after']/Shat))) if Shat>0 else 0
        d=min(max(d,1),max(n,0)); ev.append((st['t'],d))
        if n>0: Shat*=1-d/n
        n-=d
    n-=len(cs)-ci
    return ev,n,Shat

def reconstruct(g):
    steps,end_t=steps_for(g); ticks=ticks_for(g); times=rt['times']; nr=rt[g]
    recs=[]; Shat=1.0; log=[]
    for k in range(len(times)-1):
        a,b=times[k],times[k+1]; n0=nr[k]; n1=nr[k+1]
        if n0<=0: break
        drops=[s for s in steps if a<=s['t']<b]; tk=[x for x in ticks if a<=x['t']<b]
        bend=min(b,end_t)
        best=None
        for c in range(0,n0+1):
            cens=place_censors(c,tk,a,bend)
            ev,nend,Sh=run_interval(n0,drops,cens,Shat)
            if nend<0: break
            score=(abs(nend-n1),abs(c-len(tk)))
            if best is None or score<best[0]: best=(score,c,cens,ev,nend,Sh)
        score,c,cens,ev,nend,Sh=best
        Shat=Sh
        recs+= [(t,1) for t,d in ev for _ in range(d)] + [(t,0) for t in cens]
        log.append(dict(interval=[a,b],n_start=n0,n_next_displayed=n1,n_next_reconstructed=nend,
            events=int(sum(d for _,d in ev)),censored=c,visible_ticks=len(tk),n_drops=len(drops)))
    # anyone still unaccounted for (only if risk table ends >0) would be censored at curve end
    left=man['groups'][g]-len(recs)
    recs+=[(end_t,0)]*max(left,0)
    return recs,log,steps,ticks,end_t

if __name__=='__main__':
    rows=[]; info={}
    for g in ['A','B']:
        recs,log,steps,ticks,end_t=reconstruct(g)
        assert len(recs)==man['groups'][g], (g,len(recs))
        rows+=[(g,round(t,4),e) for t,e in recs]
        info[g]=dict(interval_log=log,curve_end=end_t,n_steps=len(steps),n_ticks_after_merge=len(ticks),
                     steps=steps,ticks=ticks)
    df=pd.DataFrame(rows,columns=['group','observed_time','event']).sort_values(['group','observed_time','event'],ascending=[True,True,False])
    fn=OUT/('ipd.csv' if MODE=='primary' else 'sensitivity.csv'); tmp=str(fn)+'.tmp'
    df.to_csv(tmp,index=False); os.replace(tmp,fn)
    json.dump(info,open(OUT/f'reconstruction_log_{MODE}.json','w'),indent=1)
    for g in info:
        print(g,'curve end',round(info[g]['curve_end'],3))
        for l in info[g]['interval_log']: print('  ',l)
    print('wrote',fn)
