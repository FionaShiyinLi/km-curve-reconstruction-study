# Reconstruction assumptions and method

**Inputs.** `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (N = 1000 per arm, months, seed 1899309850). The manifest has no arm-specific event totals, so that check is marked unavailable. The number-at-risk table (0–36 months, every 6) was read from the PDF text layer:
A 1000/699/488/336/233/85/0; B 1000/746/559/422/308/114/0.

**Measurement.** The figure is vector-drawn, so no pixel digitization was needed. `extract.py` reads:
- each arm's KM step path (a single path object per arm);
- the censor ticks (4-pt vertical segments in the arm color);
- the axis tick marks.

Calibration is linear from the labelled axis ticks: x = 64.8 pt → 0 mo and 410.4 pt → 36 mo; y = 223.2 pt → S = 0 and 43.2 pt → S = 1. No global rescaling or running-minimum correction was applied. Both paths start exactly at (0, 1.0). The first drop in each arm is kept as a genuine early event (A at 0.0015 mo, B at 0.0077 mo). Arm colors were assigned from the legend: blue = A, orange = B. Every tick center lies exactly on its own arm's curve. No two ticks share an x-coordinate, so the tick count is taken as the censoring count within drawing precision. Extracted values are in `output/extracted.json`.

**Algorithm** (`reconstruct.py`, deterministic, no randomness). The code walks each drop in time order:
- n_risk = N − prior events − ticks at strictly earlier times. A censoring tied with an event time counts as at risk, i.e., events come before censoring.
- d = round(n_risk·(1 − S_after/S_before)). This uses the KM relation rather than assuming d = 1.

Every drop resolved to d = 1, with rounding residual |·| ≤ 0.0005 in both arms, i.e., within 0.05% of one event, so the one-event-per-drop result is supported by the data. The results:
- A: 769 events and 231 censorings.
- B: 683 events and 317 censorings.
- Ticks plus events account for all 1000 in each arm. No unticked remainder had to be allocated.

Event times are the drop x-positions and censoring times are the tick x-positions, rounded to 1e-6 months. The last observation in each arm is the tick at the curve end (A 35.991 mo, B 35.9985 mo), which is below 36, so the displayed zero at risk at 36 holds.

**Risk table.** The risk table was used only as a check, not as a fitting constraint. The reconstructed counts (observed_time ≥ t) match the table exactly at all 7 times for both arms.

**Checks** (`check.py`, reads the committed CSV). It recomputes the right-continuous KM curve and compares it with the drawn step function:
- at 17 times from 0 to 35.9 months, including the tail;
- at the midpoint of every horizontal segment of the drawn path, where the maximum absolute difference is about 3e-7 in both arms.

It also checks N, the 0/1 event indicator and the risk table; all pass (`checks.json`, which records the SHA-256). An earlier version of the check compared at vertex + 1e-7 months and reported residuals up to 0.008 there. That came from the 1e-6 time rounding in the check, not from the data, and was fixed by using segment midpoints. The CSV was not changed.

**Limitations.**
- Times are exact only to the plotting precision (about 5e-6 months) of the source PDF.
- Two censorings drawn at the same x-position would show as one tick. This cannot be ruled out from the figure, but the exact risk-table and N reconciliation leaves no room for hidden extra censorings or events between 6-month marks.
- No covariates or follow-up beyond the drawn curve were created.

**Sensitivity analysis.** Not run. No materially different allocation of events and censorings is consistent with the figure and risk table, so a single alternative would not be informative.
