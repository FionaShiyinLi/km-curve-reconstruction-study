import json, numpy as np
e = json.load(open('output/extracted.json'))
N = 1000
risk = {'A': [1000, 699, 488, 336, 233, 85, 0], 'B': [1000, 746, 559, 422, 308, 114, 0]}
for g in 'AB':
    v = np.array(e['arms'][g]['vertices']); tk = np.array(e['arms'][g]['ticks'])
    drops = [(v[i, 0], v[i - 1, 1], v[i, 1]) for i in range(1, len(v)) if v[i, 1] < v[i - 1, 1] - 1e-9 and abs(v[i, 0] - v[i - 1, 0]) < 1e-9]
    ct = tk[:, 0]
    n = N; D = 0; res = []; ds = []
    for t, sb, sa in drops:
        nr = N - D - np.sum(ct < t - 1e-9)
        dd = nr * (1 - sa / sb); d = int(round(dd)); res.append(dd - d); ds.append(d); D += d
    res = np.array(res)
    print(g, 'drops', len(drops), 'events', D, 'ticks', len(ct), 'remaining', N - D - len(ct), 'max|resid|', abs(res).max(), 'd>1:', sum(np.array(ds) > 1))
    dt = np.array([x[0] for x in drops]); ds = np.array(ds)
    for k, t in enumerate(range(0, 37, 6)):
        nrisk = N - ds[dt < t].sum() - np.sum(ct < t)
        print('  t', t, 'table', risk[g][k], 'recon(ticks only)', nrisk)
    # tick y vs curve y at tick time
    Sgrid = lambda t: v[:, 1][np.searchsorted(v[:, 0], t, side='right') - 1]
    print('  tick y mismatch max', np.max(np.abs(tk[:, 1] - np.array([Sgrid(t) for t in ct]))))
    print('  duplicate tick times', np.sum(np.diff(ct) < 1e-6))
