"""Extract KM step vertices and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
p = pdfplumber.open(pdf).pages[0]
# Axis calibration from labelled tick marks (black 0.6 lines):
# x ticks at 64.8 (0) ... 410.4 (36); y ticks at 223.2 (0.0) ... 43.2 (1.0)
xt = sorted({round(l['x0'], 3) for l in p.lines if l['stroking_color'] == (0.0, 0.0, 0.0) and l['x0'] == l['x1'] and l['bottom'] - l['top'] == 3})
yt = sorted({round(l['top'], 3) for l in p.lines if l['stroking_color'] == (0.0, 0.0, 0.0) and l['top'] == l['bottom'] and l['x1'] - l['x0'] == 3})
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
x0, x36 = xt[0], xt[-1]; y1, y0 = yt[0], yt[-1]
T = lambda x: (x - x0) / (x36 - x0) * 36.0
S = lambda y: (y0 - y) / (y0 - y1)
# Legend: colour of the line left of "Group A"/"Group B" text
words = p.extract_words()
leg = [l for l in p.lines if l['linewidth'] == 1.0]
cmap = {}
for w in words:
    if w['text'] in ('A', 'B') and w['top'] < 30:
        cand = [l for l in leg if l['x1'] < w['x0']]
        cmap[str(max(cand, key=lambda l: l['x1'])['stroking_color'])] = w['text']
res = {'calibration': {'x0_pt': x0, 'x36_pt': x36, 'y1_pt': y1, 'y0_pt': y0}, 'colour_map': cmap, 'arms': {}}
for c in p.curves:
    g = cmap[str(c['stroking_color'])]
    pts = [(T(x), S(y)) for x, y in c['pts']]
    res['arms'][g] = {'vertices': pts}
for g in 'AB':
    col = [k for k, v in cmap.items() if v == g][0]
    ticks = [l for l in p.lines if str(l['stroking_color']) == col and l['linewidth'] != 1.0]
    assert all(abs(l['x0'] - l['x1']) < 1e-6 for l in ticks)
    res['arms'][g]['ticks'] = sorted([(T(l['x0']), S((l['top'] + l['bottom']) / 2), l['bottom'] - l['top']) for l in ticks])
json.dump(res, open(f'{out}/extracted.json', 'w'), indent=0)
for g in 'AB':
    a = res['arms'][g]
    print(g, 'vertices', len(a['vertices']), 'ticks', len(a['ticks']), 'tick heights', sorted({round(t[2], 3) for t in a['ticks']}))
    print(' start', a['vertices'][:3], 'end', a['vertices'][-2:], 'last ticks', a['ticks'][-3:])
