"""KM-to-IPD reconstruction from vector PDF geometry (own implementation).
Usage (from work dir): python output/code/extract.py ../input/figure.pdf output
                       python output/code/reconstruct.py [output]
Deterministic: no randomness is used; the manifest seed 1899309850 is recorded only."""
import sys, os, json, hashlib, tempfile, numpy as np, pandas as pd
SEED = 1899309850
np.random.seed(SEED)  # recorded; not used
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
e = json.load(open(f'{out}/extracted.json'))
N = {'A': 1000, 'B': 1000}  # manifest
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 699, 488, 336, 233, 85, 0], 'B': [1000, 746, 559, 422, 308, 114, 0]}  # PDF text
TIE = 1e-9

rows, diag = [], {}
for g in 'AB':
    v = np.array(e['arms'][g]['vertices']); ct = np.array([t[0] for t in e['arms'][g]['ticks']])
    drops = [(v[i, 0], v[i - 1, 1], v[i, 1]) for i in range(1, len(v))
             if v[i, 1] < v[i - 1, 1] - 1e-9 and abs(v[i, 0] - v[i - 1, 0]) < 1e-9]
    D, resid, ev = 0, [], []
    for t, sb, sa in drops:
        nr = N[g] - D - np.sum(ct < t - TIE)          # censored at a tied time remain at risk
        dd = nr * (1 - sa / sb); d = int(round(dd))  # d estimated from n_risk, not assumed
        assert d >= 1
        resid.append(dd - d); ev += [t] * d; D += d
    nrem = N[g] - D - len(ct)
    assert nrem >= 0, f'{g}: more ticks+events than N'
    # any unticked remainder would be censored at the last drawn curve time (none here)
    cens = list(ct) + [v[-1, 0]] * nrem
    rows += [(g, t, 1) for t in ev] + [(g, t, 0) for t in cens]
    diag[g] = {'n_drops': len(drops), 'events': D, 'ticks': len(ct), 'unticked_remainder': nrem,
               'max_abs_d_rounding_residual': float(np.max(np.abs(resid)))}
df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(6)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
assert all((df.group == g).sum() == N[g] for g in 'AB')
fd, tmp = tempfile.mkstemp(dir=out, suffix='.tmp'); os.close(fd)
df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(diag, open(f'{out}/reconstruction_diag.json', 'w'), indent=1)
print(diag)
