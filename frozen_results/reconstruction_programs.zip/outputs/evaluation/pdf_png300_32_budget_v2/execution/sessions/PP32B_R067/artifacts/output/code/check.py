"""Reload committed ipd.csv, recompute right-continuous KM and compare to measured curve/risk table."""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
e = json.load(open(f'{out}/extracted.json'))
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
df = pd.read_csv(f'{out}/ipd.csv')
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 699, 488, 336, 233, 85, 0], 'B': [1000, 746, 559, 422, 308, 114, 0]}
TOL_S = 0.0005  # half of one event step at n=1000 (0.001); vector coordinates have ~1e-5 pt precision
def km(t, d):
    ut = np.unique(t[d == 1]); s = 1.0; st = []
    for u in ut:
        n = np.sum(t >= u); k = np.sum((t == u) & (d == 1)); s *= 1 - k / n; st.append(s)
    return ut, np.array(st)
chk = {'csv_sha256': sha, 'columns_ok': list(df.columns) == ['group', 'observed_time', 'event'],
       'survival_tolerance': TOL_S, 'tolerance_justification': 'half of the smallest possible KM step (1/1000); PDF vector coordinates resolve S to ~1e-7',
       'event_totals': 'unavailable (manifest has no arm event totals)', 'arms': {}}
allpass = True
for g in 'AB':
    s = df[df.group == g]; t = s.observed_time.values; d = s.event.values
    ut, st = km(t, d)
    Shat = lambda x: 1.0 if x < ut[0] else st[np.searchsorted(ut, x, side='right') - 1]
    v = np.array(e['arms'][g]['vertices'])
    Smeas = lambda x: v[:, 1][np.searchsorted(v[:, 0], x, side='right') - 1]  # right-continuous step of drawn path
    times = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.9]
    sc = [{'t': x, 'measured': round(float(Smeas(x)), 6), 'reconstructed': round(float(Shat(x)), 6),
           'residual': round(float(Shat(x) - Smeas(x)), 7)} for x in times]
    for r in sc: r['status'] = 'pass' if abs(r['residual']) <= TOL_S else 'fail'
    # all-vertex check
    mids = [(v[i, 0] + v[i + 1, 0]) / 2 for i in range(len(v) - 1) if v[i + 1, 0] - v[i, 0] > 2e-6]  # horizontal segment midpoints
    allres = max(abs(Shat(x) - Smeas(x)) for x in mids)
    rk = []
    for x, n in zip(RISK_T, RISK[g]):
        m = int(np.sum(t >= x)); rk.append({'t': x, 'table': n, 'reconstructed': m, 'residual': m - n, 'status': 'pass' if m == n else 'fail'})
    a = {'n': int(len(s)), 'n_ok': int(len(s)) == 1000, 'event_values_ok': bool(set(d) <= {0, 1}),
         'events': int(d.sum()), 'censored': int((d == 0).sum()), 'max_time': float(t.max()),
         'survival_checks': sc, 'max_abs_residual_all_vertices': float(allres), 'risk_table_checks': rk}
    allpass &= all(r['status'] == 'pass' for r in sc + rk) and a['n_ok'] and a['event_values_ok']
    chk['arms'][g] = a
chk['overall'] = 'pass' if allpass else 'fail'
json.dump(chk, open(f'{out}/checks.json', 'w'), indent=1)
print(sha, chk['overall'], {g: (chk['arms'][g]['events'], chk['arms'][g]['max_abs_residual_all_vertices']) for g in 'AB'})
