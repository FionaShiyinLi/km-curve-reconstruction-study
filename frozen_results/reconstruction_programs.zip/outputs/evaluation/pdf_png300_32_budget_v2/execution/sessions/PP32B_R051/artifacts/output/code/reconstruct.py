"""KM reconstruction from vector PDF figure. Usage: python reconstruct.py [input_dir] [output_dir]"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

here = os.path.dirname(os.path.abspath(__file__))
IN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', '..', '..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, '..')
SEED = 925054428
rng = np.random.default_rng(SEED)  # not used for allocation (deterministic), recorded per instructions
man = json.load(open(os.path.join(IN, 'manifest.json')))
pg = pdfplumber.open(os.path.join(IN, 'figure.pdf')).pages[0]

# ---- axis calibration from labelled tick marks (PDF top-origin coords) ----
words = pg.extract_words()
xt, yt = {}, {}
for l in pg.lines:
    (x0, y0), (x1, y1) = l['pts']
    if l['stroking_color'] == (0.0, 0.0, 0.0):
        if x0 == x1 and abs(y1 - y0) == 3: xt[x0] = None
        if y0 == y1 and abs(x1 - x0) == 3: yt[y0] = None
def lab_near(v, axis):
    best = None
    for w in words:
        c = (w['x0'] + w['x1']) / 2 if axis == 'x' else (w['top'] + w['bottom']) / 2
        ok = (w['top'] > 225 and w['top'] < 235) if axis == 'x' else (w['x1'] < 60)
        if ok and abs(c - v) < 8:
            try: best = float(w['text'])
            except ValueError: pass
    return best
xs = sorted(xt); ys = sorted(yt)
xl = [lab_near(v, 'x') for v in xs]; yl = [lab_near(v, 'y') for v in ys]
ax_ = np.polyfit(xs, xl, 1); ay_ = np.polyfit(ys, yl, 1)
tmap = lambda x: np.polyval(ax_, x); smap = lambda y: np.polyval(ay_, y)
calib = dict(x_ticks=list(zip(xs, xl)), y_ticks=list(zip(ys, yl)),
             x_resid=float(np.max(np.abs(tmap(np.array(xs)) - xl))), y_resid=float(np.max(np.abs(smap(np.array(ys)) - yl))))

COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
risk_times = [0, 6, 12, 18, 24, 30, 36]
risk = {'A': [100, 62, 44, 27, 19, 6, 0], 'B': [100, 80, 54, 46, 34, 14, 0]}  # read from PDF text layer

def extract(g):
    cur = [c for c in pg.curves if c['stroking_color'] == COL[g]]
    assert len(cur) == 1
    pts = [(float(tmap(x)), float(smap(y))) for x, y in cur[0]['pts']]
    ticks = []
    for l in pg.lines:
        (x0, y0), (x1, y1) = l['pts']
        if l['stroking_color'] == COL[g] and x0 == x1 and abs(y1 - y0) == 4:
            ticks.append((float(tmap(x0)), float(smap((y0 + y1) / 2))))
    return pts, sorted(ticks)

def steps_from(pts):
    # vertical segments = drops: (time, S_before, S_after)
    drops = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-9 and s1 < s0 - 1e-9: drops.append((t0, s0, s1))
    return drops, pts[-1][0]

def build(g, drops, tick_t, extra_policy='uniform'):
    n0 = man['groups'][g]
    # censoring times: ticks, plus untimed censorings needed to meet risk table in each interval
    cens = list(tick_t)
    events = []
    # iterative: determine events via KM ratio with n_risk from current censor set
    for it in range(20):
        ev = []
        allc = sorted(cens)
        for (t, sb, sa) in drops:
            nr = n0 - sum(d for _, d in ev) - sum(1 for c in allc if c < t)
            d = int(round(nr * (1 - sa / sb)))
            ev.append((t, max(d, 1)))
        # adjust censoring counts per risk interval
        new = list(tick_t); notes = []
        for k in range(len(risk_times) - 1):
            a, b = risk_times[k], risk_times[k + 1]
            leave = risk[g][k] - risk[g][k + 1]
            e_in = sum(d for t, d in ev if a <= t < b)
            c_in = sum(1 for c in tick_t if a <= c < b)
            need = leave - e_in - c_in
            if need > 0:
                # untimed censorings: spread uniformly within interval (assumption)
                add = [a + (b - a) * (j + 0.5) / need for j in range(need)]
                if b == risk_times[-1]:
                    add = [min(x, max([t for t, _ in ev] + list(tick_t) + [a]) ) for x in add]
                new += add
            notes.append(dict(interval=[a, b], leave=leave, events=e_in, ticks=c_in, untimed_added=max(need, 0), excess=min(need, 0)))
        if sorted(new) == sorted(cens) and ev == events: break
        cens, events = new, ev
    return events, sorted(cens), notes

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d / n; out.append((u, S))
    return out
def S_at(curve, t):
    s = 1.0
    for u, v in curve:
        if u <= t: s = v
    return s
def meas_at(pts, t):
    s = pts[0][1]
    for (u, v) in pts:
        if u <= t + 1e-9: s = v
    return s

res, diag = {}, {}
for g in ['A', 'B']:
    pts, ticks = extract(g)
    drops, tend = steps_from(pts)
    events, cens, notes = build(g, drops, [t for t, _ in ticks])
    rows = [(g, t, 1) for t, d in events for _ in range(d)] + [(g, c, 0) for c in cens]
    res[g] = rows
    diag[g] = dict(n_vertices=len(pts), n_drops=len(drops), curve_end=tend, n_ticks=len(ticks),
                   start=pts[0], first_pts=pts[:6], last_pts=pts[-4:], events=sum(d for _, d in events),
                   multi_event_drops=[(t, d) for t, d in events if d > 1], interval_notes=notes, n_rows=len(rows))
    pd.DataFrame(pts, columns=['time', 'S']).to_csv(os.path.join(OUT, f'measured_curve_{g}.csv'), index=False)
    pd.DataFrame(ticks, columns=['time', 'S']).to_csv(os.path.join(OUT, f'censor_ticks_{g}.csv'), index=False)

df = pd.DataFrame([r for g in 'AB' for r in res[g]], columns=['group', 'observed_time', 'event'])
df['observed_time'] = df.observed_time.round(6)
for g in 'AB': assert (df.group == g).sum() == man['groups'][g], (g, (df.group == g).sum())
tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))

# ---- checks from reloaded CSV ----
d2 = pd.read_csv(os.path.join(OUT, 'ipd.csv'))
sha = hashlib.sha256(open(os.path.join(OUT, 'ipd.csv'), 'rb').read()).hexdigest()
checks = dict(csv_sha256=sha, calibration=calib, arms={})
TOL_S = 0.006  # ~1 pt of vertical drawing precision is 1/180=0.0056; allows rounding of vertex coords
for g in 'AB':
    sub = d2[d2.group == g]; pts = pd.read_csv(os.path.join(OUT, f'measured_curve_{g}.csv')).values.tolist()
    curve = km(sub)
    tt = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, round(diag[g]['curve_end'], 6), round(diag[g]['curve_end'], 6) + 0.01]
    sc = []
    for t in tt:
        m = meas_at(pts, t); r = S_at(curve, t)
        sc.append(dict(t=round(t, 3), measured=round(m, 4), reconstructed=round(r, 4), resid=round(r - m, 4), status='pass' if abs(r - m) <= TOL_S else 'fail'))
    rc = []
    for t, n in zip(risk_times, risk[g]):
        r = int((sub.observed_time >= t).sum())
        rc.append(dict(t=t, displayed=n, reconstructed=r, resid=r - n, status='pass' if r == n else 'fail'))
    checks['arms'][g] = dict(n=int(len(sub)), n_expected=man['groups'][g], event_values_ok=bool(set(sub.event) <= {0, 1}),
                             events=int(sub.event.sum()), supplied_event_total='unavailable (not in manifest)',
                             survival_tol=TOL_S, survival=sc, risk_table=rc, diag={k: v for k, v in diag[g].items() if k in ('n_drops', 'n_ticks', 'curve_end', 'multi_event_drops', 'interval_notes', 'start')})
json.dump(checks, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1, default=float)
print(json.dumps(diag, indent=1, default=float)[:6000])
for g in 'AB':
    print(g, [ (c['t'], c['measured'], c['reconstructed'], c['status']) for c in checks['arms'][g]['survival']])
    print(g, [(c['t'], c['displayed'], c['reconstructed']) for c in checks['arms'][g]['risk_table']])
