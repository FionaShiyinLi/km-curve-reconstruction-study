# Reconstruction assumptions

**Inputs used:** `../input/figure.pdf` (vector PDF) and `../input/manifest.json`. The manifest gives n = 100 for each group, time in months, and seed 925054428. It gives no arm-specific event totals, so there was no event-total check (marked unavailable in `checks.json`).

**Measurement.** The figure is vector graphics, so I read coordinates from the PDF objects with pdfplumber instead of from pixels.
- **Calibration.** I fitted a linear map to the labelled axis ticks: x ticks at 0, 6, …, 36 months and y ticks at 0.0, 0.2, …, 1.0. The maximum calibration residual is about 0 (floating point).
- **Curves.** Each arm is one stroked path, identified by colour: blue is Group A and orange is Group B, matching the legend.
- **Starting point.** Both paths start exactly at (0, 1.0), so no origin correction or global rescaling was applied.
- **Early drops.** Both arms have genuine early drops of 0.01, first at about 0.13 months (A) and 0.08 months (B). These are kept as drawn.
- **Censor marks.** These are short vertical line objects in the arm colour: 22 for A and 30 for B. Some marks are close together (for example, A at x = 335.7 and 336.3 pt), but each is a separate object and there are no exact duplicates. I counted one censoring per object.
- **Saved measurements.** The extracted vertices and marks are in `measured_curve_{A,B}.csv` and `censor_ticks_{A,B}.csv`.

**Algorithm** (`code/reconstruct.py`, deterministic; the seed is recorded but no random draws are used):
1. Each vertical path segment is treated as an event time.
2. The number of events at each drop comes from the KM relation, d = round(n_risk · (1 − S_after/S_before)). Here n_risk is n minus earlier events and earlier censorings, where censorings are the mark times.
3. This rounding is a measurement rule, not an assumption that d = 1. Every drop came out as d = 1 because the relative drops equal 1/n_risk to within floating-point precision.
4. For each interval between risk-table times, I checked that events plus marks equal the drop in the displayed number at risk. The code would have added untimed censorings, spread uniformly, if needed. None were needed: in every interval of both arms, events plus marks equal the drop in the risk table exactly.
5. Tail handling:
   - **A:** the path ends flat at 35.81 months with a mark there, so the last participant is censored at 35.81.
   - **B:** the path drops to 0 at 35.23 months, so the last participant at risk has an event there.
   - No follow-up was added beyond these points.

**Result:**
- A: 78 events and 22 censorings.
- B: 70 events and 30 censorings.

**Checks** (`checks.json`, computed from the reloaded CSV and including its SHA-256):
- The right-continuous KM matches the measured step curve at 19 times per arm, including 0, the tail and just after the last time. All residuals are ≤ 1e-4, against a tolerance of 0.006, which is about one drawing point on the y axis (1/180).
- The number at risk (observed_time ≥ t) matches the table at every time from 0 to 36 months in both arms, including the displayed 0 at 36.
- Both arms have 100 records, and all event indicators are 0 or 1.

**Limitations.**
- Censoring times are the mark x-positions. Events tied with a censoring at the same time would not be separable, but none were seen.
- If marks sit exactly on top of each other, several censorings drawn as one mark cannot be detected from the figure. The exact agreement with the risk table argues against hidden marks within intervals, but it cannot rule out offsetting errors inside an interval.
- The reconstruction is consistent with every supplied constraint but is not a proven unique recovery of the original data.

**Sensitivity analysis:** not run. With the risk table reconciled exactly and no untimed censorings needed, there was no materially different event/censoring allocation to test.
