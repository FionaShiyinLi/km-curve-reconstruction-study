# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json` (n = 100 per arm, months, seed 1568678454). There was no auxiliary information beyond these. The manifest gives no arm-specific event totals, so the event-total check is marked unavailable. The 0 in the table at 36 months is not read as zero events.

**Run (from the work directory):** `python output/code/extract.py ../input output && python output/code/reconstruct.py output primary && python output/code/checks.py output` (and add `reconstruct.py output uniform` before the checks step for the sensitivity file). The algorithm is deterministic. The seed is set and recorded, but no random draws are used.

## Measurement (`extract.py` → `measured_curves.json`)
- **Calibration.** Black axis tick marks were located in pixels (x: 0–36 months at 6-month spacing; y: 0–1 at 0.2 spacing) and fitted linearly. Residuals are below 1e-13, giving 0.025 months and 0.00133 survival units per pixel. No global rescaling was applied.
- **Curves.** Pixels were masked by line colour (matplotlib default blue for A, orange for B). The line is 4 px thick. The right-continuous level in each column comes from the lower edge of the line minus 1.5 px. Columns containing censor ticks are masked and take the previous level. The line end, which carries a tick, is excluded the same way.
- **Origin.** B starts visibly at 1.000. The first 6 columns of A (0–0.14 months) are hidden under the orange line, so they were set to 1 (the KM origin). A's first visible column reads 0.996, which is 3 px below 1 because the drawn step to 0.989 is partly visible. This value was not used to rescale anything. Upward jitter of 2 px or less would have been treated as noise. None was found, so no running-minimum correction was applied.
- **Drop times.** Lower-edge tracing registers a drop about 1.5 px before the centre of the vertical segment, so drop times are shifted by +1.5 px (+0.0375 months).
- **Censor ticks.** A tick is a vertical run that protrudes more than 4 px beyond the line levels on either side, which a pure drop cannot do. This found 26 marks in A and 34 in B, plus a line-end tick in each arm.
  - A few visible marks sitting on drops were missed (for example, A near 5.6 and 6.8 months, B near 8.4 months).
  - Two A detections at 1.2 and 1.3 months fall where the orange line covers the blue one and may be spurious.
  - Tick *visibility* is not *multiplicity*. Wider marks (4–5 px) may be overlapping ticks, but that is not proven.

## Reconstruction (`reconstruct.py`)
- **Risk table.** The table was read by eye: A = 100, 59, 45, 37, 26, 11, 0 and B = 100, 57, 47, 38, 32, 17, 0 at 0, 6, …, 36 months. The digits are clear.
- **Events.** Within each table interval, candidate event times are the measured drops. At each drop, d = round(n_risk·(1 − S_after/Ŝ_before)), where Ŝ is the reconstructed KM, which avoids drift. d is not forced to 1: early drops at n ≈ 100 are ≈ 0.01 per event (7.5 px), so tied multi-event drops are resolved by size.
- **Censoring counts.** The number censored in each interval is iterated until the reconstructed number at risk at the next table time equals the table value. Censored subjects at a tied time stay at risk for events at that time.
- **Censor placement (primary; an assumption).** Censored subjects go at the detected tick times. If the table needs more censorings than there are ticks, wide ticks (4 px or more) get a second record first, and any remainder is spaced evenly across the interval. If it needs fewer, an evenly spaced subset of ticks is kept. This happened once, in A 0–6 months: 7 detections, 6 censored, which is consistent with one spurious or overlapping detection. Extra censorings were added in A 24–30 (+2), A 30–36 (+1) and B 24–30 (+2).
- **Last interval.** The table shows 0 at risk at 36 months, so everyone remaining is censored or has an event before the end of the drawn curve (A: 35.55 months; B: 35.925 months). Nobody is placed at 36.
- **Totals.** A has 71 events and 29 censored; B has 63 events and 37 censored. These event totals are outputs of the reconstruction, not supplied data.

## Checks (`checks.py` → `checks.json`)
The committed CSV is reloaded and a right-continuous KM is recomputed from it (no interpolation). It is compared with the measured curve at 22 times from 0.25 to 35.4 months, including the tail.
- **Tolerance.** Half of one event's KM step at that time plus 2 px of reading error. This reflects the integer-event lattice.
- **Survival checks.** 21 of 22 pass per arm. There are two fails: A at 0.25 months (measured 0.989, reconstructed 1.000) and B at 1.5 months (0.829 vs 0.840). Both check times fall within one pixel column of a drop, and the +0.0375-month edge correction puts the reconstructed event just after the check time. This is timing resolution at the scale of one pixel, not a level mismatch. The tolerance was not widened to make them pass.
- **Risk table.** All 7 table times match exactly in both arms (count of observed_time ≥ t).
- **Tail.** A: 0.1748 reconstructed vs 0.1747 measured. B: 0.3561 vs 0.3560.

## Sensitivity (`sensitivity.csv`)
- **Assumption.** Detected ticks are ignored, and every censoring in each interval is spaced evenly (Guyot-style). Events are re-derived.
- **Comparison at the common horizon of 35.5 months** (A's curve ends at 35.55):

| Arm | S(35.5), primary | S(35.5), sensitivity | RMST, primary | RMST, sensitivity |
|---|---|---|---|---|
| A | 0.175 | 0.182 | 15.80 | 15.84 |
| B | 0.356 | 0.356 | 16.63 | 16.62 |

  Event counts are unchanged. This is one alternative, not an uncertainty bound.

## Unresolved limitations
- Exact censoring times are unknown where ticks overlap, sit on drops, or are missing. Extra censorings are spread evenly by assumption.
- Event times are known only to about ±1 px (±0.025 months). Times hidden under the other arm (A before 0.15 months) are uncertain.
- The flat tails do not identify follow-up or accrual beyond the displayed ticks.
- Several different IPD sets are consistent with the figure; this reconstruction is not unique.
