"""Reload committed CSV(s), recompute right-continuous KM, compare with measurements.
Usage: python checks.py [output_dir]"""
import sys, json, hashlib, os, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
meas = json.load(open(f'{out}/measured_curves.json'))
ds_px = meas['calibration']['surv_per_px']
T_RISK = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 59, 45, 37, 26, 11, 0], 'B': [100, 57, 47, 38, 32, 17, 0]}
def km(df):
    t = np.sort(df.observed_time.unique()); S = 1.0; st = [(0.0, 1.0)]
    for u in t:
        n = (df.observed_time >= u).sum(); d = ((df.observed_time == u) & (df.event == 1)).sum()
        if d: S *= 1 - d / n; st.append((u, S))
    return np.array(st)
def S_at(st, x):  # right-continuous step evaluation
    return float(st[st[:, 0] <= x, 1][-1])
def rmst(st, h):
    ts = np.append(st[st[:, 0] < h, 0], h); ss = st[st[:, 0] < h, 1]
    return float(np.sum(np.diff(ts) * ss))
def meas_at(g, x):
    c = meas['curves'][g]; t = np.array(c['t']); s = np.array([np.nan if v is None else v for v in c['s']])
    j = int(np.argmin(np.abs(t - x))); return None if np.isnan(s[j]) else float(s[j])
CHECK_T = [0.25, 0.5, 1, 1.5, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 21, 24, 26, 28, 30, 32, 34, 35.4]
res = {}
path = f'{out}/ipd.csv'
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
res['csv'] = dict(path='ipd.csv', sha256=sha, columns=list(df.columns),
                  columns_ok=list(df.columns) == ['group', 'observed_time', 'event'])
fig, axs = plt.subplots(1, 2, figsize=(13, 5))
for i, g in enumerate(['A', 'B']):
    d = df[df.group == g]; st = km(d); c = meas['curves'][g]
    end_t = c['end_t']
    r = dict(n=int(len(d)), n_expected=100, n_ok=len(d) == 100,
             event_integer_ok=bool(d.event.isin([0, 1]).all()), events=int(d.event.sum()),
             censored=int((d.event == 0).sum()), max_time=float(d.observed_time.max()),
             supplied_event_total='unavailable (not in manifest)')
    rows = []
    for x in CHECK_T:
        if x > end_t: continue
        m = meas_at(g, x); s = S_at(st, x)
        nr = int((d.observed_time >= x).sum())
        # tolerance: half of one event's KM step at x (integer-event lattice) + 2 px reading error
        tol = 0.5 * s / max(nr, 1) + 2 * ds_px
        rows.append(dict(t=x, measured=m, reconstructed=round(s, 4), residual=None if m is None else round(s - m, 4),
                         tol=round(tol, 4), status='unavailable' if m is None else ('pass' if abs(s - m) <= tol else 'fail')))
    r['survival_checks'] = rows
    rk = []
    for t0, n0 in zip(T_RISK, RISK[g]):
        n_rec = int((d.observed_time >= t0).sum())
        rk.append(dict(t=t0, table=n0, reconstructed=n_rec, residual=n_rec - n0, status='pass' if n_rec == n0 else 'fail'))
    r['risk_checks'] = rk
    r['rmst_35.5'] = round(rmst(st, 35.5), 3)
    res[g] = r
    tt = np.array(c['t']); ss = np.array([np.nan if v is None else v for v in c['s']])
    ax = axs[i]; ax.plot(tt, ss, 'k-', lw=3, alpha=.3, label='measured (pixels)')
    ax.step(st[:, 0], st[:, 1], where='post', color='C0' if g == 'A' else 'C1', label='KM of ipd.csv')
    cz = d[d.event == 0].observed_time; ax.plot(cz, [S_at(st, x) for x in cz], '|', color='k')
    ax.set_title(f'Group {g}'); ax.set_ylim(0, 1.02); ax.legend()
plt.savefig(f'{out}/diag/overlay.png', dpi=90); plt.close()
if os.path.exists(f'{out}/sensitivity.csv'):
    sd = pd.read_csv(f'{out}/sensitivity.csv'); comp = {}
    for g in ['A', 'B']:
        p = km(df[df.group == g]); q = km(sd[sd.group == g])
        comp[g] = dict(horizon=35.5, S_primary=round(S_at(p, 35.5), 4), S_sens=round(S_at(q, 35.5), 4),
                       RMST_primary=round(rmst(p, 35.5), 3), RMST_sens=round(rmst(q, 35.5), 3),
                       S12_primary=round(S_at(p, 12), 4), S12_sens=round(S_at(q, 12), 4),
                       events_primary=int(df[df.group == g].event.sum()), events_sens=int(sd[sd.group == g].event.sum()))
    res['sensitivity'] = dict(assumption='censor times ignore detected ticks; all censors in each risk-table interval evenly spaced (drops/events re-derived)',
                              common_horizon_months=35.5, comparison=comp,
                              sha256=hashlib.sha256(open(f'{out}/sensitivity.csv', 'rb').read()).hexdigest())
else:
    res['sensitivity'] = 'not run'
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
for g in ['A', 'B']:
    r = res[g]; print(g, r['n'], r['events'], r['censored'], r['max_time'], r['rmst_35.5'])
    print('  fails', [(x['t'], x['measured'], x['reconstructed'], x['tol']) for x in r['survival_checks'] if x['status'] != 'pass'])
    print('  risk', [(x['t'], x['table'], x['reconstructed']) for x in r['risk_checks']])
print(json.dumps(res['sensitivity'], indent=0) if isinstance(res['sensitivity'], dict) else 'no sens')
