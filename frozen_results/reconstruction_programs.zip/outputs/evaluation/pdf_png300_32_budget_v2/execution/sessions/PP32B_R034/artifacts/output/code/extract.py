"""Measure KM step curves and censor ticks from the raster figure.
Usage: python extract.py [input_dir] [output_dir]"""
import sys, json, numpy as np
from PIL import Image
inp = sys.argv[1] if len(sys.argv) > 1 else '../input'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(f'{inp}/figure.png').convert('RGB')).astype(int)
H, W, _ = im.shape
dark = (im < 80).all(-1)
rows = dark.sum(1); cols = dark.sum(0)
xaxis_y = int(np.argmax(rows[:1100])); yaxis_x = int(np.argmax(cols[:600]))
def tickcentres(v, lo):
    idx = np.where(v >= 5)[0]
    gs = np.split(idx, np.where(np.diff(idx) > 2)[0] + 1)
    return [float(g.mean()) for g in gs if len(g) and g.mean() >= lo]
xticks = tickcentres(dark[xaxis_y + 3:xaxis_y + 10, :].sum(0), yaxis_x - 3)
yticks = tickcentres(dark[:, yaxis_x - 10:yaxis_x - 3].sum(1), 0)
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
assert len(xticks) == 7 and len(yticks) == 6, (xticks, yticks)
ax_ = np.polyfit(xticks, xlab, 1); ay_ = np.polyfit(yticks, ylab, 1)
t_of = lambda px: np.polyval(ax_, px); s_of = lambda py: np.polyval(ay_, py)
calib = dict(xaxis_y=xaxis_y, yaxis_x=yaxis_x, xticks_px=xticks, yticks_px=yticks,
             months_per_px=ax_[0], surv_per_px=-ay_[0],
             x_resid_max=float(np.abs(np.array(xlab) - t_of(np.array(xticks))).max()),
             y_resid_max=float(np.abs(np.array(ylab) - s_of(np.array(yticks))).max()))
cols_rgb = {'A': (31, 119, 180), 'B': (255, 127, 14)}
x0, x1 = int(round(xticks[0])), int(round(xticks[-1]))
top_lim = int(round(yticks[0])) - 12
res = {}
for g, c in cols_rgb.items():
    m = np.sqrt(((im - np.array(c)) ** 2).sum(-1)) < 90
    m[:top_lim] = False; m[xaxis_y - 1:] = False; m[:, :x0] = False
    xs = np.arange(x0, x1 + 3)
    top = np.full(W, np.nan); bot = np.full(W, np.nan); cnt = np.zeros(W, int)
    for x in xs:
        ys = np.where(m[:, x])[0]
        if len(ys): top[x], bot[x], cnt[x] = ys.min(), ys.max(), len(ys)
    lw = int(np.bincount(cnt[cnt > 0]).argmax())          # line thickness (mode)
    # censor ticks: a vertical run clearly taller than the line whose centre sits on a
    # level that is the same immediately left and right of the run (a drop changes level)
    long_ = (cnt > lw + 6)
    tick = np.zeros(W, bool)
    for x in xs[1:-1]:
        if not long_[x]: continue
        ys = np.where(m[:, x])[0]
        L = [bot[k] for k in range(x - 1, x - 12, -1) if cnt[k] > 0 and not long_[k]][:1]
        Rr = [bot[k] for k in range(x + 1, min(x + 12, W - 1)) if cnt[k] > 0 and not long_[k]][:1]
        if not L or not Rr: continue
        hi, lo = min(L[0], Rr[0]) - (lw - 1) / 2, max(L[0], Rr[0]) - (lw - 1) / 2  # pixel rows
        # a pure drop spans exactly [hi-top edge, lo-bottom edge]; a tick protrudes beyond
        if ys.min() < hi - (lw - 1) / 2 - 4 or ys.max() > lo + (lw - 1) / 2 + 4:
            tick[x] = True
    # right-continuous level from lower edge; mask tick columns and use neighbours
    bot_c = bot.copy(); bot_c[tick] = np.nan
    lastx = int(np.nanmax(np.where(~np.isnan(bot), np.arange(W), np.nan)))
    # the line end carries a censor tick: take level from lower edge 6 px before end
    lev = np.full(W, np.nan)
    prev = np.nan
    for x in range(x0, lastx + 1):
        if not np.isnan(bot_c[x]) and not (x > lastx - 3):
            prev = bot_c[x] - (lw - 1) / 2
        lev[x] = prev
    # first column: level at origin measured from local neighbourhood top edge
    s = s_of(lev)
    ticks = []
    idx = np.where(tick)[0]
    for grp in np.split(idx, np.where(np.diff(idx) > 1)[0] + 1):
        if len(grp):
            ticks.append(dict(t=float(t_of(grp.mean())), width_px=int(len(grp)),
                              s=float(s_of(np.nanmedian(lev[grp[0] - 3:grp[-1] + 4])))))
    end_t = float(t_of(lastx - (lw - 1) / 2))    # line end (tick at end of curve)
    ends_with_tick = bool(cnt[lastx - 1] > lw + 6 or cnt[lastx] > lw + 6)
    res[g] = dict(line_width=lw, t=[float(t_of(x)) for x in range(x0, lastx + 1)],
                  s=[None if np.isnan(v) else float(v) for v in s[x0:lastx + 1]],
                  ticks=ticks, end_t=end_t, end_tick=ends_with_tick,
                  origin_s=float(s_of(top[x0 + 1] + (lw - 1) / 2)) if not np.isnan(top[x0 + 1]) else None)
json.dump(dict(calibration=calib, curves=res), open(f'{out}/measured_curves.json', 'w'), indent=1)
print(json.dumps(calib))
for g, r in res.items():
    s = np.array([np.nan if v is None else v for v in r['s']])
    print(g, 'lw', r['line_width'], 'nan', np.isnan(s).sum(), 'first', np.round(s[:12], 4), 'origin', r['origin_s'],
          'end', r['end_t'], r['end_tick'], 'last s', s[-1], 'nticks', len(r['ticks']))
    print([(round(k['t'], 2), k['width_px']) for k in r['ticks']])
