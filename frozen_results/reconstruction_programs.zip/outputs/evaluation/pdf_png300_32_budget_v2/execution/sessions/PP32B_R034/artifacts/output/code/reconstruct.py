"""Reconstruct IPD from measured KM curves, censor ticks and the number-at-risk table.
Usage: python reconstruct.py [output_dir] [mode]   mode = primary | uniform (sensitivity)"""
import sys, os, json, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
mode = sys.argv[2] if len(sys.argv) > 2 else 'primary'
SEED = 1568678454
rng = np.random.default_rng(SEED)   # recorded; algorithm below is deterministic
meas = json.load(open(f'{out}/measured_curves.json'))
dt_px = meas['calibration']['months_per_px']; ds_px = meas['calibration']['surv_per_px']
# number at risk, read from the figure's table (OCR by eye; digits are unambiguous)
T_RISK = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 59, 45, 37, 26, 11, 0], 'B': [100, 57, 47, 38, 32, 17, 0]}
N = {'A': 100, 'B': 100}

def drops_from_curve(c):
    t = np.array(c['t']); s = np.array([np.nan if v is None else v for v in c['s']])
    # leading columns hidden under the other arm: KM starts at 1 by definition
    first = np.argmax(~np.isnan(s)); s[:first] = 1.0
    s = np.minimum(s, 1.0)
    # sub-2-pixel upward jitter is measurement noise; larger rises would be flagged
    rises = []
    for j in range(1, len(s)):
        if s[j] > s[j - 1]:
            if s[j] - s[j - 1] > 2 * ds_px: rises.append((t[j], s[j] - s[j - 1]))
            s[j] = s[j - 1]
    # drop times: lower-edge tracing switches ~ (lw-1)/2 px before the vertical's centre
    shift = (c['line_width'] - 1) / 2 * dt_px
    d = [(t[j] + shift, s[j - 1], s[j]) for j in range(1, len(s)) if s[j] < s[j - 1] - 0.5 * ds_px]
    return d, rises

def reconstruct(g, c):
    drops, rises = drops_from_curve(c)
    ticks = [k['t'] for k in c['ticks']]
    if c['end_tick']: ticks.append(c['end_t'])
    width = {k['t']: k['width_px'] for k in c['ticks']}
    recs = []; log = []
    n_start = RISK[g][0]; S_hat = 1.0
    for k in range(len(T_RISK) - 1):
        a, b = T_RISK[k], T_RISK[k + 1]
        n_k, n_next = RISK[g][k], RISK[g][k + 1]
        dk = [x for x in drops if a <= x[0] < b]
        tk = sorted(x for x in ticks if a <= x < b)
        b_eff = min(b, c['end_t']) if b == T_RISK[-1] else b
        def cens_times(cn):
            if mode == 'uniform':
                return list(a + (np.arange(cn) + 0.5) * (b_eff - a) / cn) if cn else []
            if cn <= len(tk):  # keep an evenly spaced subset of visible ticks
                idx = np.round(np.linspace(0, len(tk) - 1, cn)).astype(int) if cn else []
                return [tk[i] for i in idx]
            out_ = list(tk); extra = cn - len(tk)
            wide = sorted([x for x in tk if width.get(x, 0) >= 4], key=lambda x: -width[x])
            for x in wide:          # wide (possibly overlapping) ticks take a 2nd censor first
                if extra == 0: break
                out_.append(x); extra -= 1
            if extra:               # remaining unseen censors: spread evenly over interval
                out_ += list(a + (np.arange(extra) + 0.5) * (b_eff - a) / extra)
            return sorted(out_)
        def run(cn):
            ct = np.array(cens_times(cn)); S = S_hat; ev = []; D = 0
            for (td, s0, s1) in dk:
                nr = n_k - D - int((ct < td).sum())
                if nr <= 0: break
                d = int(np.clip(np.round(nr * (1 - s1 / S)), 0, nr)) if S > 0 else 0
                if d: ev.append((td, d)); D += d; S *= 1 - d / nr
            return ct, ev, D, S
        cn = max(len(tk) if mode == 'primary' else 0, 0) if n_next > 0 else None
        if n_next == 0:
            # table shows 0 at last time: everybody leaves before it; censored = remainder
            cn = 0
            for _ in range(60):
                ct, ev, D, S = run(cn)
                if cn == n_k - D: break
                cn = n_k - D
        else:
            seen = {}
            for _ in range(80):
                ct, ev, D, S = run(cn)
                gap = (n_k - D - cn) - n_next
                seen[cn] = abs(gap)
                if gap == 0: break
                new = max(0, cn + gap)
                if new in seen: cn = min(seen, key=seen.get); ct, ev, D, S = run(cn); break
                cn = new
        n_hat_next = n_k - D - len(ct)
        log.append(dict(interval=[a, b], n_start=n_k, n_next_table=n_next, n_next_recon=int(n_hat_next),
                        events=int(D), censored=int(len(ct)), visible_ticks=len(tk),
                        extra_censors=int(max(0, len(ct) - len(tk))) if mode == 'primary' else None))
        for td, d in ev: recs += [(g, round(td, 4), 1)] * d
        recs += [(g, round(float(x), 4), 0) for x in ct]
        S_hat = S
    return recs, log, rises

all_recs = []; logs = {}
for g in ['A', 'B']:
    r, lg, rises = reconstruct(g, meas['curves'][g])
    assert len(r) == N[g], (g, len(r))
    all_recs += r; logs[g] = dict(intervals=lg, rises_over_2px=rises)
df = pd.DataFrame(all_recs, columns=['group', 'observed_time', 'event'])
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False]).reset_index(drop=True)
assert np.isfinite(df.observed_time).all() and (df.observed_time >= 0).all()
fn = f'{out}/ipd.csv' if mode == 'primary' else f'{out}/sensitivity.csv'
tmp = fn + '.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, fn)
json.dump(dict(seed=SEED, mode=mode, logs=logs), open(f'{out}/recon_log_{mode}.json', 'w'), indent=1)
for g in logs:
    print(g); [print(' ', x) for x in logs[g]['intervals']]; print('  rises', logs[g]['rises_over_2px'])
print(df.groupby('group').event.agg(['size', 'sum']))
