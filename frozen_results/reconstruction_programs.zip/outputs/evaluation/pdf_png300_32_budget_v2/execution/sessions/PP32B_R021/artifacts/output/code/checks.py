"""Reload committed CSV, recompute right-continuous KM, compare to measurements and risk table.
Usage: python output/code/checks.py [workdir] [ipd_csv] [checks_json] [sens_csv]"""
import sys, json, hashlib
import numpy as np, pandas as pd
wd = sys.argv[1] if len(sys.argv) > 1 else 'work'
ipd_path = sys.argv[2] if len(sys.argv) > 2 else 'output/ipd.csv'
out_path = sys.argv[3] if len(sys.argv) > 3 else 'output/checks.json'
sens_path = sys.argv[4] if len(sys.argv) > 4 else None
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [100, 70, 44, 26, 17, 5, 0], 'B': [100, 82, 62, 46, 34, 11, 0]}
TOL = 0.01

def km(df):
    t = np.sort(df.observed_time.unique()); S = 1.0; st = []
    for u in t:
        n = (df.observed_time >= u).sum(); d = ((df.observed_time == u) & (df.event == 1)).sum()
        S *= 1 - d/n; st.append((u, S))
    return st

def S_at(st, x):          # right-continuous step value
    v = 1.0
    for u, s in st:
        if u <= x: v = s
        else: break
    return v

def rmst(st, tau):
    area, prev_t, prev_s = 0.0, 0.0, 1.0
    for u, s in st:
        if u > tau: break
        area += prev_s*(u - prev_t); prev_t, prev_s = u, s
    return area + prev_s*(tau - prev_t)

def meas_at(D, x):
    v = 1.0
    for r in D.itertuples():
        if r.t <= x: v = r.S_after
    return v

ipd = pd.read_csv(ipd_path)
sha = hashlib.sha256(open(ipd_path, 'rb').read()).hexdigest()
res = {'csv': ipd_path, 'sha256': sha, 'tolerance_survival': TOL,
       'tolerance_justification': 'Level readings are +/-1-2 px (0.0013-0.0027) after axis calibration; 0.01 (7.5 px) allows '
       'for this plus integer-event rounding, while staying below one-event step sizes in the tails (S/n about 0.013-0.03).',
       'survival_checks_exclude': 'times within 0.15 month of a measured drop (drop position uncertainty ~2-3 px)',
       'arms': {}}
grid = {'A': [0.5, 1.5, 3, 5, 6.1, 8.5, 11, 12.5, 15.2, 18.1, 21, 23, 25.5, 28, 30, 32.5, 34, 34.7],
        'B': [0.4, 1.5, 3.5, 5, 6.1, 8.5, 11, 12.5, 15.2, 18.1, 21.5, 23, 24.2, 26, 28, 30, 32.5, 33.0]}
allpass = True
for g in 'AB':
    d = ipd[ipd.group == g]; D = pd.read_csv(f'{wd}/drops_{g}.csv'); st = km(d)
    arm = {'n': int(len(d)), 'n_expected': 100, 'n_pass': bool(len(d) == 100),
           'event_values_ok': bool(set(d.event.unique()) <= {0, 1}),
           'times_ok': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
           'events': int(d.event.sum()), 'supplied_event_total': 'unavailable (not in manifest)',
           'max_time': float(d.observed_time.max()), 'survival': [], 'risk_table': []}
    for x in grid[g]:
        if (np.abs(D.t - x) < 0.15).any(): continue
        m, r = meas_at(D, x), S_at(st, x)
        ok = abs(r - m) <= TOL; allpass &= ok
        arm['survival'].append(dict(t=x, measured=round(m, 4), recon=round(r, 4), resid=round(r - m, 4),
                                    status='pass' if ok else 'fail'))
    for t, nt in zip(RT_T, RT[g]):
        c = int((d.observed_time >= t).sum())
        arm['risk_table'].append(dict(t=t, table=nt, recon=c, resid=c - nt, status='pass' if c == nt else 'fail'))
        allpass &= c == nt
    res['arms'][g] = arm
res['all_pass'] = bool(allpass)
if sens_path:
    s = pd.read_csv(sens_path); tau = 33.0
    comp = {'csv': sens_path, 'sha256': hashlib.sha256(open(sens_path, 'rb').read()).hexdigest(),
            'common_horizon_months': tau, 'arms': {}}
    for g in 'AB':
        p, q = km(ipd[ipd.group == g]), km(s[s.group == g])
        comp['arms'][g] = dict(S_primary=round(S_at(p, tau), 4), S_sens=round(S_at(q, tau), 4),
                               RMST_primary=round(rmst(p, tau), 3), RMST_sens=round(rmst(q, tau), 3),
                               events_primary=int(ipd[ipd.group == g].event.sum()), events_sens=int(s[s.group == g].event.sum()))
    res['sensitivity'] = comp
json.dump(res, open(out_path, 'w'), indent=1)
print(json.dumps({g: {'events': res['arms'][g]['events'],
                      'fails': [c for c in res['arms'][g]['survival'] + res['arms'][g]['risk_table'] if c['status'] != 'pass']}
                  for g in 'AB'}, indent=0), 'all_pass', allpass)
if sens_path: print(json.dumps(res['sensitivity']['arms']))
