"""Measure KM step curves and censor ticks from the raster figure (own code; no KM-IPD package).
Usage: python output/code/extract.py [path/to/figure.png] [workdir]
Writes <workdir>/steps_{A,B}.csv (horizontal levels) and <workdir>/ticks_{A,B}.csv."""
import sys, os
import numpy as np, pandas as pd
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else os.path.join('..','input','figure.png')
wd  = sys.argv[2] if len(sys.argv) > 2 else 'work'
os.makedirs(wd, exist_ok=True)
im = np.asarray(Image.open(fig).convert('RGB')).astype(int)
R,G,B = im[...,0],im[...,1],im[...,2]
# Calibration from labelled axis tick marks (detected as dark 2-px marks):
#   x: 0,6,...,36 months at columns 269.5 + 240k ; y: 0.0,...,1.0 at rows 929.5 - 150k
X0, XPM = 269.5, 40.0
Y0, YPU = 929.5, 750.0
t_of = lambda x: (x - X0)/XPM
s_of = lambda y: (Y0 - y)/YPU
masks = {'A': (B>120)&(R<120)&(B-R>60),       # blue  ~(31,119,180)
         'B': (R>180)&(B<120)&(R-B>100)}      # orange ~(255,127,14)

def clusters(ys):
    if len(ys)==0: return []
    br = np.where(np.diff(ys)>1)[0]
    return np.split(ys, br+1)

for g,m in masks.items():
    m = m.copy(); m[:150,:] = False; m[945:,:] = False
    h = m & np.roll(m,2,1) & np.roll(m,-2,1)          # horizontal-line pixels
    xs = np.where(m.any(0))[0]; x1, x2 = xs.min(), xs.max()
    levrows, tickcols = [], []
    for x in range(x1, x2+1):
        cl = [c for c in clusters(np.where(h[:,x])[0]) if 3 <= len(c) <= 5]
        tops = [c.min() for c in cl]
        for c in cl:
            levrows.append((x, c.mean(), len(c)))
        col = np.where(m[:,x])[0]
        if len(col) and cl:
            top = min(tops)
            above = col[col < top-2]
            below_end = col.max()
            if len(above) >= 3:
                tickcols.append((x, top, above.min(), below_end, max(c.max() for c in cl)))
    L = pd.DataFrame(levrows, columns=['x','yc','n'])
    # compress to horizontal level runs (level = row centre); keep levels seen in >=2 columns
    runs = (L.groupby('yc').x.agg(['min','max','count']).reset_index()
              .sort_values('min'))
    runs = runs[runs['count']>=2].copy()
    # Origin neighbourhood: columns left of the first detected run may be partly hidden by the y-axis
    # (dark, x=269-270) and by the other arm.  Remeasure locally from the curve's lower edge only.
    first = runs['min'].min()
    extra = []
    for x in range(x1, first):
        col = np.where(m[:,x])[0]
        if len(col): extra.append((col.max()-1.5, x))
    if extra:
        E = pd.DataFrame(extra, columns=['yc','x'])
        for yc, sub in E.groupby('yc'):
            if yc < runs['yc'].min() - 3 and s_of(yc) < 1.0:
                runs.loc[len(runs)+1000] = [yc, sub.x.min(), sub.x.max(), len(sub)]
        runs = runs.sort_values('min')
        print(g, 'origin columns (x, lower-edge centre):', extra)
    runs['t_start'] = t_of(runs['min']-1.5).clip(lower=0)
    runs['t_end'] = t_of(runs['max']+1.5)
    runs['S'] = s_of(runs['yc'])
    runs = runs.rename(columns={'min':'x_start','max':'x_end','count':'ncol'})
    runs.to_csv(f'{wd}/steps_{g}.csv', index=False)
    T = pd.DataFrame(tickcols, columns=['x','line_top','tick_top','col_bottom','line_bottom'])
    # merge adjacent tick columns into tick clusters
    grp = (T.x.diff()>1).cumsum()
    TK = T.groupby(grp).agg(x_first=('x','min'), x_last=('x','max'),
                            line_top=('line_top','min'), tick_top=('tick_top','min'),
                            col_bottom=('col_bottom','max'), line_bottom=('line_bottom','max')).reset_index(drop=True)
    TK['width'] = TK.x_last-TK.x_first+1
    # a censor tick crosses the line: it extends >=4 px below the lowest line cluster in its columns;
    # drop (vertical) segments only extend from the old level down to the new level.
    TK['below'] = TK.col_bottom - TK.line_bottom
    # guard against staircase artefacts: the pixels below must not belong to a nearby (<=3 px) lower
    # horizontal level, i.e. the next step's vertical segment.
    hb = {x: max((c.max() for c in clusters(np.where(h[:,x])[0]) if 3 <= len(c) <= 5), default=-1)
          for x in range(x1, x2+1)}
    def lower_level_near(r):
        return any(hb.get(x,-1) >= r.col_bottom-1 for x in range(r.x_first-3, r.x_last+4))
    TK['near_lower_level'] = TK.apply(lower_level_near, axis=1)
    TK['above'] = TK.line_top - TK.tick_top
    TK['is_tick'] = (TK.below >= 4) & (TK.below <= 9) & ~TK.near_lower_level
    TK['t'] = t_of((TK.x_first+TK.x_last)/2)
    TK['S_level'] = s_of(TK.line_top+1.5)
    TK.to_csv(f'{wd}/ticks_{g}.csv', index=False)
    print(g, 'levels', len(runs), 'tick clusters', len(TK), 'last x', x2, 't_last', round(t_of(x2),3))
