"""Reconstruct approximate IPD from measured KM steps, censor ticks and the number-at-risk table.
Usage: python output/code/reconstruct.py [workdir] [variant]
  variant = primary | sens   (sens: alternative censor multiplicity in Group B tail, see assumptions.md)
Reads <workdir>/steps_*.csv, ticks_*.csv produced by extract.py.  Deterministic; seed recorded anyway."""
import sys, os, json
import numpy as np, pandas as pd
SEED = 411570314
np.random.seed(SEED)            # no stochastic step is used; seed set for the record
wd = sys.argv[1] if len(sys.argv) > 1 else 'work'
variant = sys.argv[2] if len(sys.argv) > 2 else 'primary'
X0, XPM = 269.5, 40.0
t_of = lambda x: (x - X0)/XPM
N = {'A': 100, 'B': 100}                                      # manifest
RT_T = [0, 6, 12, 18, 24, 30, 36]                             # risk-table times (read from figure)
RT = {'A': [100, 70, 44, 26, 17, 5, 0], 'B': [100, 82, 62, 46, 34, 11, 0]}
END_DROP = {'A': None, 'B': 1594}   # B curve ends with a vertical drop to 0 at column ~1593-1595

def drops_for(g):
    s = pd.read_csv(f'{wd}/steps_{g}.csv').sort_values('x_start').reset_index(drop=True)
    out, prevS, prevx = [], 1.0, None
    for _, r in s.iterrows():
        if r.S >= prevS - 1e-9:
            prevx = r.x_end; continue
        x = (prevx + r.x_start)/2 if prevx is not None else r.x_start - 0.5
        out.append((max(t_of(x), 0.0), prevS, r.S)); prevS, prevx = r.S, r.x_end
    if END_DROP[g] is not None:
        out.append((t_of(END_DROP[g]), prevS, 0.0))
    return pd.DataFrame(out, columns=['t', 'S_before', 'S_after'])

def ticks_for(g):
    t = pd.read_csv(f'{wd}/ticks_{g}.csv')
    sure = t[t.is_tick].copy(); sure['cls'] = 'sure'
    # "possible": crosses the line (below>=4) and only 6-7 px above it, but rejected by the staircase guard
    poss = t[(~t.is_tick) & (t.below >= 4) & (t.below <= 9) & (t.above <= 7)].copy(); poss['cls'] = 'possible'
    return pd.concat([sure, poss])[['t', 'cls', 'width', 'above', 'below']].sort_values('t')

def simulate(n0, drops, cens, Sprev):
    """Sequential KM: censors at a time tied with an event are removed after the event."""
    recs, n, S = [], n0, Sprev
    ev = [(t, 0, sa) for t, sb, sa in drops]; ce = [(t, 1, None) for t in cens]
    for t, kind, sa in sorted(ev + ce, key=lambda z: (z[0], z[1])):
        if kind == 1:
            if n > 0: recs.append((t, 0)); n -= 1
            continue
        if n <= 0: continue
        if sa <= 1e-9: d = n
        else:
            d = int(round(n*(1 - sa/S))); d = min(max(d, 1), n)   # visible drop => >=1 event
        recs += [(t, 1)]*d; S *= (1 - d/n); n -= d
    return recs, n, S

def place_censors(C, a, b, tk, extra_dup_order=None):
    sure = tk[tk.cls == 'sure'].sort_values('t'); poss = tk[tk.cls == 'possible'].sort_values('t')
    if C <= len(sure):
        # keep ticks whose geometry is most typical (above==6), then by time
        keep = sure.assign(k=(sure.above - 6).abs()).sort_values(['k', 't']).head(C)
        return sorted(keep.t.tolist()), f'{C} of {len(sure)} sure ticks'
    times = sure.t.tolist(); note = f'{len(sure)} sure'
    need = C - len(times)
    add = poss.t.tolist()[:need]; times += add; need -= len(add)
    if add: note += f' + {len(add)} possible'
    if need > 0 and len(sure) + len(poss) > 0:
        base = sorted(sure.t.tolist() + poss.t.tolist())
        # extra censors assumed to be coincident (overlapping) ticks, spread over visible tick positions
        idx = np.linspace(0, len(base)-1, need).round().astype(int)
        times += [base[i] for i in idx]; note += f' + {need} duplicated at visible ticks'
    elif need > 0:
        times += [a + (i+0.5)*(b-a)/need for i in range(need)]; note += f' + {need} uniform (no ticks)'
    return sorted(times), note

def reconstruct(g, variant):
    D, TK = drops_for(g), ticks_for(g)
    recs, log, S, n = [], [], 1.0, N[g]
    assert RT[g][0] == N[g]
    for k in range(len(RT_T)-1):
        a, b = RT_T[k], RT_T[k+1]; n_next = RT[g][k+1]
        dk = [tuple(r) for r in D[(D.t >= a) & (D.t < b)].itertuples(index=False)]
        tk = TK[(TK.t >= a) & (TK.t < b)]
        C = int((tk.cls == 'sure').sum())
        final_zero = any(sa <= 1e-9 for _, _, sa in dk)
        if final_zero and variant == 'sens':
            C = C + 2          # alternative: two overlapping censor ticks => single final event
        seen = {}
        for it in range(60):
            cens, note = place_censors(C, a, b, tk)
            r, n_end, S_end = simulate(n, dk, cens, S)
            if final_zero:            # KM reaches 0: d = remaining at risk, C not identified by the table
                break
            if n_end == n_next: break
            Dn = sum(e for _, e in r)
            C_new = max(n - n_next - Dn, 0)
            if C_new in seen: C = min(seen.keys() | {C_new}, key=lambda c: abs(seen.get(c, 99))); 
            seen[C] = n_end - n_next
            if C_new == C: break
            C = C_new
        cens, note = place_censors(C, a, b, tk)
        r, n_end, S_end = simulate(n, dk, cens, S)
        ne = sum(e for _, e in r)
        log.append(dict(interval=[a, b], n_start=n, n_end_table=n_next, n_end_recon=n_end,
                        events=ne, censored=len(r)-ne, drops=len(dk),
                        sure_ticks=int((tk.cls == 'sure').sum()), possible_ticks=int((tk.cls == 'possible').sum()),
                        censor_note=note, S_meas_end=float(dk[-1][2]) if dk else None, S_recon_end=S_end))
        recs += r; n, S = n_end, S_end
    if n > 0:   # should not happen: table says 0 at 36
        log.append(dict(warning=f'{n} participants left after last interval'))
    return pd.DataFrame([(g, t, e) for t, e in recs], columns=['group', 'observed_time', 'event']), log, D, TK

if __name__ == '__main__':
    out, logs = [], {}
    for g in 'AB':
        df, log, D, TK = reconstruct(g, variant)
        out.append(df); logs[g] = log
        D.to_csv(f'{wd}/drops_{g}.csv', index=False)
        for L in log: print(g, L)
        print(g, 'n=', len(df), 'events=', int(df.event.sum()))
    ipd = pd.concat(out)
    ipd['observed_time'] = ipd.observed_time.round(4)
    ipd.to_csv(f'{wd}/ipd_{variant}.csv', index=False)
    json.dump(logs, open(f'{wd}/interval_log_{variant}.json', 'w'), indent=1, default=float)
