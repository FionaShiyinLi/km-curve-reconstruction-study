"""Full pipeline. Usage (from the work directory): python output/code/run_all.py [../input/figure.png]"""
import sys, os, subprocess, shutil
fig = sys.argv[1] if len(sys.argv) > 1 else os.path.join('..', 'input', 'figure.png')
here = os.path.dirname(os.path.abspath(__file__)); py = sys.executable
run = lambda *a: subprocess.run([py, *a], check=True)
os.makedirs('output', exist_ok=True)
run(os.path.join(here, 'extract.py'), fig, 'work')
run(os.path.join(here, 'reconstruct.py'), 'work', 'primary')
shutil.copy('work/ipd_primary.csv', 'output/.ipd.tmp'); os.replace('output/.ipd.tmp', 'output/ipd.csv')   # atomic commit
run(os.path.join(here, 'reconstruct.py'), 'work', 'sens')
shutil.copy('work/ipd_sens.csv', 'output/.sens.tmp'); os.replace('output/.sens.tmp', 'output/sensitivity.csv')
run(os.path.join(here, 'checks.py'), 'work', 'output/ipd.csv', 'output/checks.json', 'output/sensitivity.csv')
