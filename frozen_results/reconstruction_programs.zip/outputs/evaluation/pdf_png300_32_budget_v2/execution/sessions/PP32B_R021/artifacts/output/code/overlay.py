"""Overlay reconstructed KM (from committed CSV) on the source figure. Usage: python overlay.py [fig] [csv] [out]"""
import sys, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
fig, csv, out = (sys.argv[1:4] + ['../input/figure.png', 'output/ipd.csv', 'work/overlay.png'][len(sys.argv)-1:])[:3]
im = Image.open(fig); d = pd.read_csv(csv)
plt.figure(figsize=(18, 13.5), dpi=100); plt.imshow(im)
for g, c in [('A', 'red'), ('B', 'black')]:
    x = d[d.group == g]; t = np.sort(x.observed_time.unique()); S = [1.0]; T = [0.0]
    for u in t:
        n = (x.observed_time >= u).sum(); e = ((x.observed_time == u) & (x.event == 1)).sum(); T.append(u); S.append(S[-1]*(1-e/n))
    plt.step(269.5 + 40*np.array(T), 929.5 - 750*np.array(S), where='post', color=c, lw=0.8)
    cz = x[x.event == 0]
    for u in cz.observed_time: plt.plot(269.5+40*u, 929.5-750*S[np.searchsorted(T, u, 'right')-1] - 12, 'v', color=c, ms=3)
plt.xlim(250, 1720); plt.ylim(950, 160); plt.axis('off'); plt.savefig(out, bbox_inches='tight')
