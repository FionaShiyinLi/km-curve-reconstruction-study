# Reconstruction assumptions (groups A and B, 100 participants each; time in months)

**Inputs used:** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (n = 100 per arm, months, seed 411570314). The number-at-risk table was read from the figure: A 100/70/44/26/17/5/0 and B 100/82/62/46/34/11/0 at 0, 6, ..., 36 months. The manifest gives no arm-specific event totals, so event-total checks are marked unavailable. No other auxiliary information was used.

**Pipeline** (`python output/code/run_all.py ../input/figure.png`, run from the work directory): `extract.py`, then `reconstruct.py` (primary and sensitivity), an atomic write of the CSVs, and finally `checks.py`. `overlay.py` draws the visual check. The algorithm is deterministic. The seed is set and recorded but nothing uses it. Python 3.12.14, numpy, pandas, Pillow.

## Measurement
- **Calibration:** taken from the dark axis tick marks. The x ticks at 0, 6, ..., 36 months sit at columns 269.5 + 40k, so 1 month = 40 px. The y ticks at 0.0, ..., 1.0 sit at rows 929.5 - 150k. One linear map is used per axis, with no global rescaling of survival.
- **Curves:** the arms were separated by color (blue = A, orange = B). A horizontal level is a 3-5 px cluster of line pixels that persists over at least 2 columns, and its value is the cluster's center row. Each change of level is a drop, placed at the midpoint of the gap between the two runs.
- **Origin:** near t = 0, Group A is partly hidden by the y-axis and by the orange line. I remeasured that neighborhood locally from the curve's lower edge and found a genuine early level of about 0.99 before 0.98 at t < 0.1. Nothing was rescaled and no running minimum was applied. Group B starts at 1.00.
- **Censor ticks:** a tick is a vertical mark that crosses its line, extending 4-9 px below the line. Candidates are rejected when the lower pixels belong to a horizontal level within 3 px, since that is the next vertical segment in a tight staircase. Candidates rejected only by that rule are kept as "possible" ticks. Ticks with widths of 2-3 px are consistent with single marks (antialiasing at sub-pixel positions). Visibility does not prove multiplicity: overlapping ticks, or ticks hidden inside a vertical drop, cannot be counted from the image.
- **Group B end:** the curve ends with a vertical drop to 0 at about 33.14 months. Group A ends with a censor tick at about 34.74 months.

## Reconstruction (my own Guyot-type interval algorithm)
Within each risk-table interval, events and censorings are simulated in time order. Censorings tied with an event are processed after it.
- **Events at each drop:** d = round(n_risk × (1 − S_measured_after / S_reconstructed_before)), with d ≥ 1 because the drop is visible. This relation lets d > 1 when the relative drop requires it; d = 1 is never imposed. A drop to 0 means d equals everyone still at risk.
- **Censorings per interval:** the count C comes from the table, C = n_start − n_next − D, iterated to a fixed point. Placement follows a fixed order:
  1. visible ticks;
  2. then "possible" ticks;
  3. then extra censorings duplicated at visible tick positions (the overlapping-tick assumption);
  4. only in an interval with no ticks, uniform spacing.
- **Allocations used:** every interval reconciled exactly. The steps beyond visible ticks were:
  - Group A, [6, 12): one "possible" tick at 6.26 months.
  - Group B, [0, 6) and [12, 18): one "possible" tick each.
  - Group B, [18, 24): one duplicate at the 18.70-month tick.
  - Group B, [24, 30): one possible tick and two duplicates.

  These placements are assumptions. The table only fixes the number of censorings in each interval, not their times.
- **Group A before 6 months:** every level there is a multiple of 0.01, and the table gives 70 at risk at 6 months. Both point to 30 events and no censoring, which is what the reconstruction gives.
- **No invented follow-up:** nobody is followed beyond the last visible mark of their arm, and all times are below 36 months, consistent with the table's 0 at risk at 36.

## Results and checks (`output/checks.json`)
- **Counts:** 100 records per arm; A has 84 events and B has 66.
- **Risk table:** the counts of observed_time ≥ t match the table at every time for both arms (residual 0).
- **Survival:** the right-continuous KM recomputed from the committed CSV was compared with the measured step curve at 14 (A) and 11 (B) times from 0.4 to 34.7 months, tails included. Times within 0.15 month of a drop were skipped. The maximum absolute residual is 0.0013 for A and 0.003 for B, against a tolerance of 0.01 (justified in checks.json). The overlay is saved as `extracted/overlay.png`.

## Unresolved ambiguity and sensitivity
- **Group B tail:** 11 participants are at risk at 30 months, and 8 ticks are visible between 30 and 33.1. A drop to 0 does not identify d.
  - Primary (visible ticks counted once): 3 tied events at 33.14 months.
  - Alternative in `output/sensitivity.csv` (the only alternative run): two of those ticks are overlapping pairs, giving 10 censorings and 1 final event. B then has 64 events; Group A is unchanged.
  - Comparison at a common supported horizon of 33.0 months: the two versions give the same KM (A S = 0.129, B S = 0.283) and the same area under the survival curve (A 13.41, B 19.34 months). They differ only in B's event count, and therefore in at-risk-based variances near the end.
  - The primary was chosen because it relies only on visible marks, not because of any effect estimate. One alternative is not an error bound.
- **Other limits:**
  - Censoring times beyond visible ticks, and the split of events inside multi-event drops, cannot be identified from the figure.
  - Drop times carry roughly ±0.05 month of uncertainty.
  - These records approximate the published curve. They do not recover the original data uniquely.
