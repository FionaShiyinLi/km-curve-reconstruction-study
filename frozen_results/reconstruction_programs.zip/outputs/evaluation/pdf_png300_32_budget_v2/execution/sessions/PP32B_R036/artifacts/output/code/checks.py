"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve
and risk table; write checks.json. Usage: python checks.py [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
RT_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 689, 472, 327, 235, 91, 0], 'B': [1000, 628, 530, 444, 361, 145, 0]}
N = {'A': 1000, 'B': 1000}
TOL = 0.01  # ~7.5 px; line is ~4-5 px thick, plus column-resolution of drops
def km(d):
    ts = np.unique(d.observed_time[d.event == 1]); s = 1.0; out = []
    for x in ts:
        nr = (d.observed_time >= x).sum(); de = ((d.observed_time == x) & (d.event == 1)).sum()
        s *= 1 - de / nr; out.append((x, s))
    return np.array(out)
def S_at(k, x):
    i = np.searchsorted(k[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else float(k[i, 1])
def rmst(k, h):
    xs = np.r_[0, k[:, 0][k[:, 0] < h], h]; ss = [1.0] + [S_at(k, x) for x in xs[1:-1]]
    return float(np.sum(np.diff(xs) * np.array(ss)))
path = f'{OUT}/ipd.csv'
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
ipd = pd.read_csv(path)
chk = dict(csv_sha256=sha, km_tolerance=TOL, tolerance_note='~7.5 px vertical; rendered line 4-5 px thick; drops split over adjacent raster columns (0.025 mo)',
           supplied_event_totals='unavailable (not in manifest)', arms={})
TIMES = [0.25, 0.5, 1, 2, 3, 4.5, 6, 8, 9, 10, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5, 35.9]
fig, ax = plt.subplots(figsize=(9, 6))
for g in ['A', 'B']:
    d = ipd[ipd.group == g]; k = km(d)
    cur = pd.read_csv(f'{OUT}/measured_curve_{g}.csv')
    A = dict(n=len(d), n_expected=N[g], n_ok=len(d) == N[g],
             event_values_ok=bool(set(d.event.unique()) <= {0, 1}), events=int(d.event.sum()),
             time_finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
             max_time=float(d.observed_time.max()))
    rows = []
    for t in TIMES:
        # measured: S_meas at the column containing t (raw run-centre, before monotone fit)
        j = int(np.argmin(abs(cur.t - t))); m = float(cur.S_meas[j]); r = S_at(k, t)
        rows.append(dict(t=t, measured=round(m, 4), reconstructed=round(r, 4), residual=round(r - m, 4),
                         status='pass' if abs(r - m) <= TOL else 'fail'))
    A['km_vs_measured'] = rows
    rr = []
    for t, n in zip(RT_T, RISK[g]):
        c = int((d.observed_time >= t).sum())
        rr.append(dict(t=t, table=n, reconstructed=c, residual=c - n, status='pass' if c == n else 'fail'))
    A['risk_table'] = rr
    A['rmst_35.9'] = round(rmst(k, 35.9), 4)
    chk['arms'][g] = A
    ax.plot(cur.t, cur.S_meas, lw=3, alpha=.35, label=f'{g} measured')
    ax.step(k[:, 0], k[:, 1], where='post', lw=.8, label=f'{g} KM from ipd.csv')
try:
    s = pd.read_csv(f'{OUT}/sensitivity.csv'); H = 35.9; comp = {}
    for g in ['A', 'B']:
        k1 = km(ipd[ipd.group == g]); k2 = km(s[s.group == g])
        comp[g] = dict(horizon=H, S_primary=round(S_at(k1, H), 4), S_alt=round(S_at(k2, H), 4),
                       S12_primary=round(S_at(k1, 12), 4), S12_alt=round(S_at(k2, 12), 4),
                       rmst_primary=round(rmst(k1, H), 4), rmst_alt=round(rmst(k2, H), 4),
                       risk_alt=[int((s[s.group == g].observed_time >= t).sum()) for t in RT_T])
    chk['sensitivity'] = dict(assumption='censorings spread uniformly within each risk-table interval instead of at detected tick positions', comparison=comp)
except FileNotFoundError:
    chk['sensitivity'] = 'not run'
ax.legend(); ax.set_xlabel('months'); fig.savefig(f'{OUT}/overlay.png', dpi=110)
json.dump(chk, open(f'{OUT}/checks.json', 'w'), indent=1)
for g in chk['arms']:
    A = chk['arms'][g]; print(g, A['n'], A['events'], [ (r['t'], r['residual']) for r in A['km_vs_measured'] if r['status']!='pass'], [(r['t'], r['reconstructed'], r['table']) for r in A['risk_table']])
print(json.dumps(chk['sensitivity'], indent=0)[:900])
