"""Pixel extraction of the two KM curves from the raster figure.
Usage: python extract.py [path/to/figure.png] [outdir]
Calibration (from axis tick marks found in the image, see assumptions.md):
  x: tick t=0 occupies px cols 269-270, t=36 cols 1709-1710  -> t = (col+0.5-270)/40
  y: tick S=1 occupies px rows 179-180, S=0 rows 929-930      -> S = (930-(row+0.5))/750
"""
import sys, json, numpy as np, pandas as pd
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
a = np.asarray(Image.open(fig).convert('RGB')).astype(float)
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
X0, X1, Y0, Y1 = 270, 1710, 175, 935
t_of = lambda c: (c + 0.5 - 270) / 40.0
s_of = lambda r: (930 - (r + 0.5)) / 750.0

def mask(g):
    # colour-distance mask; antialiased edge pixels are accepted when they are
    # closer to the arm colour than to white by a margin
    d = np.sqrt(((a - np.array(COL[g])) ** 2).sum(2))
    w = np.sqrt(((a - 255) ** 2).sum(2))
    return (d < 0.5 * w) & (d < 120)

def runs(idx):
    if len(idx) == 0: return []
    br = np.where(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br + 1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st, en))

res = {}
for g in COL:
    m = mask(g)
    rows = []
    for c in range(X0, X1 + 3):
        idx = np.where(m[Y0:Y1, c])[0] + Y0
        rr = runs(idx)
        rows.append(dict(col=c, n=len(idx), runs=[(int(s), int(e)) for s, e in rr]))
    res[g] = rows
if __name__ == '__main__' and '--diag' in sys.argv:
    for g in res:
        L = [e - s + 1 for r in res[g] for s, e in r['runs']]
        print(g, 'runlen hist', np.bincount(L)[:25], 'cols empty', sum(r['n'] == 0 for r in res[g]))
        print(g, 'first cols', [(r['col'], r['runs']) for r in res[g][:6]])
        print(g, 'last cols', [(r['col'], r['runs']) for r in res[g][-10:]])
        print(g, 'multi-run cols', sum(len(r['runs']) > 1 for r in res[g]))
json.dump(res, open(f'{out}/raw_columns.json', 'w'))
