"""KM -> participant-level reconstruction (own implementation, Guyot-style logic).
Usage: python reconstruct.py [figure.png] [manifest.json] [outdir]
Steps: (1) pixel extraction (extract.py logic), (2) per-column curve level =
centre of the coloured vertical run (a censor tick is centred on the line), with
occluded columns dropped, (3) isotonic (PAVA) monotone fit, (4) tick detection,
(5) per risk-table interval, solve for the number censored so the simulated
number at risk matches the table, events from KM drops d = n*(1 - S_j/S_hat_{j-1}).
"""
import sys, os, json, hashlib, numpy as np, pandas as pd
from PIL import Image
FIG = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
MAN = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
OUT = sys.argv[3] if len(sys.argv) > 3 else 'output'
man = json.load(open(MAN)); SEED = man['code_seed']
rng = np.random.default_rng(SEED)  # recorded; algorithm is deterministic
NG = man['groups']
# risk table read visually from the figure (rows 'Group A'/'Group B')
RT_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 689, 472, 327, 235, 91, 0], 'B': [1000, 628, 530, 444, 361, 145, 0]}

a = np.asarray(Image.open(FIG).convert('RGB')).astype(float)
COL = {'A': (31, 119, 180), 'B': (255, 127, 14)}
X0, X1, Y0, Y1 = 270, 1712, 175, 935
t_of = lambda c: (np.asarray(c) + 0.5 - 270) / 40.0
s_of = lambda r: (930 - (np.asarray(r) + 0.5)) / 750.0

def mask(g):
    d = np.sqrt(((a - np.array(COL[g])) ** 2).sum(2)); w = np.sqrt(((a - 255) ** 2).sum(2))
    return (d < 0.5 * w) & (d < 120)
M = {g: mask(g) for g in COL}

def runs(idx):
    if len(idx) == 0: return []
    br = np.where(np.diff(idx) > 1)[0]
    return list(zip(np.r_[idx[0], idx[br + 1]], np.r_[idx[br], idx[-1]]))

def pava(y):
    # nondecreasing isotonic fit (rows increase as S decreases)
    v = list(map(float, y)); w = [1.0] * len(v); blocks = [[i] for i in range(len(v))]
    i = 0
    while i < len(v) - 1:
        if v[i] > v[i + 1]:
            nv = (v[i] * w[i] + v[i + 1] * w[i + 1]) / (w[i] + w[i + 1])
            v[i] = nv; w[i] += w[i + 1]; blocks[i] += blocks[i + 1]
            del v[i + 1], w[i + 1], blocks[i + 1]
            if i > 0: i -= 1
        else: i += 1
    out = np.empty(len(y))
    for val, b in zip(v, blocks): out[b] = val
    return out

def measure(g):
    other = [h for h in COL if h != g][0]
    cols, cen, top, bot, rel, occ = [], [], [], [], [], []
    for c in range(X0, X1):
        idx = np.where(M[g][Y0:Y1, c])[0] + Y0
        if len(idx) == 0: continue
        rr = runs(idx); s, e = min(r[0] for r in rr), max(r[1] for r in rr)
        # occlusion: other arm's pixels touching this run (other drawn on top)
        oth = np.where(M[other][max(Y0, s - 3):e + 4, c])[0]
        cols.append(c); cen.append((s + e) / 2); top.append(s); bot.append(e)
        rel.append(len(rr) == 1 and len(oth) == 0)
        # partially occluded column: estimate the line centre from the visible
        # edge away from the other arm (half line width ~2 px)
        if len(oth):
            omid = np.mean(oth) + max(Y0, s - 3)
            occ.append(s + 2 if omid > (s + e) / 2 else e - 2)
        else: occ.append(np.nan)
    df = pd.DataFrame(dict(col=cols, cen=cen, top=top, bot=bot, reliable=rel, occ_edge=occ))
    # 7-column running median of edge estimates suppresses censor-tick excursions
    df['occ_est'] = df.occ_edge.rolling(7, center=True, min_periods=3).median()
    use_occ = (~df.reliable) & df.occ_est.notna()
    df.loc[use_occ, 'cen'] = df.loc[use_occ, 'occ_est']
    df['used'] = df.reliable | use_occ
    last = df.col.max()
    r = df[df.used]
    # fill occluded columns by interpolation of reliable centres, then PAVA
    allc = np.arange(X0, last + 1)
    cen_i = np.interp(allc, r.col, r.cen)
    fit = pava(cen_i)
    fit = np.maximum(fit, 179.5)  # S cannot exceed 1 (row 179.5 == S=1)
    curve = pd.DataFrame(dict(col=allc, t=t_of(allc), S_meas=s_of(cen_i), S_fit=s_of(fit)))
    curve = curve.merge(df, on='col', how='left')
    # ticks: run extends >=4 px above AND below the fitted line level
    fr = dict(zip(allc, fit))
    tk = df[(df.reliable) & (df.top <= df.col.map(fr) - 4) & (df.bot >= df.col.map(fr) + 4)].col.values
    groups = []
    for c in tk:
        if groups and c - groups[-1][-1] <= 1: groups[-1].append(c)
        else: groups.append([c])
    return curve, groups, last

def reconstruct(g, curve, groups, uniform=False):
    """Returns records (time, event)."""
    tw = np.median([len(x) for x in groups]) if groups else 3
    tick_t, tick_m = [], []
    for x in groups:
        tick_t.append(t_of(np.mean(x))); tick_m.append(max(1, int(round(len(x) / tw))))
    tick_t = np.array(tick_t); tick_m = np.array(tick_m)
    t = curve.t.values; S = curve.S_fit.values
    S = np.r_[1.0, S[1:]]  # S(0)=1 by definition of KM; no rescaling of the curve
    tend = t[-1]
    recs = []
    n = NG[g]; Shat = 1.0; jstart = 0
    for k in range(len(RT_T) - 1):
        lo, hi = RT_T[k], RT_T[k + 1]
        js = np.where((t >= lo) & (t < hi))[0] if k < len(RT_T) - 2 else np.where(t >= lo)[0]
        sel = (tick_t >= lo) & (tick_t < hi)
        tt, mm = tick_t[sel], tick_m[sel]
        def censor_times(c):
            if c <= 0: return np.array([])
            if uniform or len(tt) == 0:
                return lo + (np.arange(c) + 0.5) / c * (min(hi, tend) - lo)
            w = mm.astype(float)
            # allocate c censorings across visible tick groups proportional to
            # apparent multiplicity (largest remainder); extra spread by order
            q = c * w / w.sum(); base = np.floor(q).astype(int)
            rem = c - base.sum(); base[np.argsort(-(q - base))[:rem]] += 1
            return np.repeat(tt, base)
        def sim(c, final=False):
            ct = np.sort(censor_times(c)); nn = n; sh = Shat; ev = []; ci = 0
            prevS = S[js[0] - 1] if js[0] > 0 else 1.0
            for j in js:
                # censorings strictly before this column time leave the risk set
                while ci < len(ct) and ct[ci] < t[j] - 1e-9: nn -= 1; ci += 1
                if S[j] < prevS - 1e-12 and nn > 0:
                    d = int(round(nn * (1 - S[j] / sh)))
                    d = max(0, min(d, nn))
                    if d: ev.append((t[j], d)); nn -= d; sh *= (1 - d / (nn + d))
                prevS = S[j]
            while ci < len(ct): nn -= 1; ci += 1
            return nn, ct, ev, sh
        target = RISK[g][k + 1]
        best = None
        for c in range(0, n + 1):
            nn, ct, ev, sh = sim(c)
            if nn < 0: break
            err = abs(nn - target)
            if best is None or err < best[0]: best = (err, c, nn, ct, ev, sh)
            if nn <= target: break
        err, c, nn, ct, ev, sh = best
        if k == len(RT_T) - 2 and nn > 0:
            # table shows 0 at 36: remaining subjects censored at last plotted time
            ct = np.r_[ct, np.full(nn, tend)]; nn = 0
        for x in ct: recs.append((min(x, tend), 0))
        for x, d in ev: recs += [(x, 1)] * d
        n = nn; Shat = sh
    return pd.DataFrame(recs, columns=['observed_time', 'event'])

def km(df):
    d = df.sort_values('observed_time'); ts = np.unique(d.observed_time[d.event == 1])
    out = []; s = 1.0
    for x in ts:
        nr = (d.observed_time >= x).sum(); de = ((d.observed_time == x) & (d.event == 1)).sum()
        s *= 1 - de / nr; out.append((x, s))
    return np.array(out) if out else np.zeros((0, 2))

def S_at(kmt, x):  # right-continuous step
    i = np.searchsorted(kmt[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else kmt[i, 1]

def atomic_csv(df, path):
    tmp = path + '.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, path)

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    res, alt, curves = {}, {}, {}
    for g in COL:
        curve, groups, last = measure(g)
        curves[g] = curve
        curve.to_csv(f'{OUT}/measured_curve_{g}.csv', index=False)
        pd.DataFrame([dict(t_mid=float(t_of(np.mean(x))), width_px=len(x)) for x in groups]).to_csv(
            f'{OUT}/ticks_{g}.csv', index=False)
        r = reconstruct(g, curve, groups); r.insert(0, 'group', g)
        assert len(r) == NG[g], (g, len(r))
        res[g] = r
        s = reconstruct(g, curve, groups, uniform=True); s.insert(0, 'group', g); alt[g] = s
        print(g, 'n', len(r), 'events', int(r.event.sum()), 'ticks groups', len(groups), 'last t', curve.t.iloc[-1])
    ipd = pd.concat([res['A'], res['B']]); ipd['observed_time'] = ipd.observed_time.round(4)
    atomic_csv(ipd, f'{OUT}/ipd.csv')
    sens = pd.concat([alt['A'], alt['B']]); sens['observed_time'] = sens.observed_time.round(4)
    atomic_csv(sens, f'{OUT}/sensitivity.csv')
