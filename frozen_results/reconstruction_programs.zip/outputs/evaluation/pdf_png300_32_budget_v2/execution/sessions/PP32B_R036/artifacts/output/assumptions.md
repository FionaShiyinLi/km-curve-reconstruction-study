# Reconstruction assumptions and limitations

**Inputs used.** `../input/figure.png` (1800x1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 1218589615). The manifest has no arm-specific event totals, so that check is marked unavailable (it does not mean zero events). The number-at-risk table was read by eye from the figure. A: 1000, 689, 472, 327, 235, 91, 0; B: 1000, 628, 530, 444, 361, 145, 0, at 0, 6, ..., 36 months. The digits are cleanly rendered and I treat the readings as certain.

**Calibration.** Axis tick marks were located in the pixels. x: 0 → columns 269–270, 36 → 1709–1710 (40 px/month). y: 1.0 → rows 179–180, 0.0 → rows 929–930 (750 px/unit). No global rescaling was applied, and S(0)=1 holds by the definition of KM, not by multiplying the curve.

**Curve measurement** (`code/reconstruct.py`, `measure`).
- Each arm is isolated by colour distance. In each column, the curve level is the centre of the coloured vertical run. A censor tick is centred on the line, so tick columns give the correct level too.
- Where the other arm is drawn over the line (both arms at 0–0.7 months, and near the crossing at about 9 months), the level is taken from the visible edge away from the covering arm (±2 px half line width), smoothed with a 7-column running median.
- In the first pass these covered columns were dropped and extrapolated flat, which created a spurious 4.8% drop at t=0 in arm A. I found this while checking and fixed it (correction cycle 1 of 2 allowed). A now starts at 0.996 and declines steadily. B's steep early drop is preserved as measured.
- A monotone curve was fitted by isotonic regression (PAVA), not a running minimum. Raw and fitted values are in `measured_curve_{A,B}.csv`.

**Events.** Within each risk-table interval, arms were processed column by column (0.025-month resolution). At each drop, d = round(n_risk × (1 − S_j / Ŝ_prev)), where Ŝ is the reconstructed KM, so rounding errors don't accumulate. A single column drop can therefore contain several tied events. d = 1 was not assumed. Event times are column centres, so timing is resolved only to about ±0.0125 months.

**Censoring.**
- Censor ticks are columns where the run extends at least 4 px above and below the fitted line. They were grouped into runs of adjacent columns (`ticks_{A,B}.csv`: 106 groups for A, 84 for B).
- Tick visibility is not the same as multiplicity: ticks overlap heavily in dense regions, especially after 24 months. So the number censored in each interval comes from the risk table: the smallest count c that makes the simulated number at risk at the next table time equal the table value.
- These c censorings were spread over the detected tick groups in that interval, in proportion to group width divided by the median group width (an assumed multiplicity proxy). Where an interval had no ticks, they were spaced uniformly.
- The table shows 0 at risk at 36 months, and the plotted curve ends at 35.96. Everyone still at risk after the last drop is censored at 35.9625 (the last plotted column, where overlapping ticks are visible), not at 36. This endpoint is taken from the figure. It is not an identified follow-up distribution.
- Randomness: none is used. The seed is still set and recorded.

**Result.** A: 1000 records, 763 events. B: 1000 records, 644 events.

**Checks** (`checks.json`, computed from the reloaded committed CSV using a right-continuous KM):
- All 7 risk-table counts match exactly in both arms (at-risk = observed_time ≥ t).
- KM vs measured curve at 22 times, 0.25–35.9 months: all within the 0.01 tolerance (~7.5 px, justified by the 4–5 px line width and column splitting of drops). The largest residual is +0.0048 (B, 35 months): the last B drop is placed slightly earlier than in the figure. The A tail is 0.1632 vs 0.164 measured.
- Arm sizes, 0/1 event indicators and finite nonnegative times all verified.

**Limitations.**
- The records are one feasible reconstruction, not a unique recovery. Within an interval, the exact censor times and counts at overlapping ticks are unidentified, and so are tie structures inside a raster column.
- Occluded segments (0–0.7 months for A, the crossing at about 9 months) rest on edge-based estimates.
- No uncertainty bound is claimed.

**Sensitivity** (`sensitivity.csv`, one alternative). Censorings were spaced uniformly within each interval instead of placed at tick positions. Comparison at the common supported horizon of 35.9 months:
- A: S = 0.1632 vs 0.1633; area under the curve (restricted mean survival time, RMST) 15.387 vs 15.385.
- B: S = 0.2585 vs 0.2600; RMST 17.900 vs 17.902.

Risk-table counts match in both versions. This single alternative is not a confidence interval.

**Reproduce:** `python output/code/reconstruct.py ../input/figure.png ../input/manifest.json output && python output/code/checks.py output`. (`extract.py` is an earlier diagnostic dump of raw column runs and is not needed.)
