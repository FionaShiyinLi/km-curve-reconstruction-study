# Reconstruction assumptions and limitations

## Inputs
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json`: n = 100 per arm, time in months, code seed 266141798. The manifest gives no arm-specific event totals, so that check is marked unavailable (this does not mean zero events).
- Number-at-risk table read by eye from the figure at 0, 6, ..., 36 months: A 100, 71, 46, 33, 24, 8, 0; B 100, 61, 45, 35, 26, 10, 0. The digits were legible, so these readings are not treated as uncertain.

## Measurement (`code/extract.py` writes `measurements.json` and `measured_curve_{A,B}.csv`)
- Calibration comes from the labelled axis tick marks: 0 and 36 months at columns 269.5 and 1709.5 (40 px/month); S = 1 and S = 0 at rows 179.5 and 929.5 (750 px per unit). No global rescaling was applied. The A line at t = 0 occupies rows 178-181 (S = 1.00), so its start needed no correction. B's first drop begins at the origin (t ≈ 0.03) and is kept as a genuine early drop.
- Curves were isolated by their exact plot colors. For each column the bottom edge of the 4 px line minus 1.5 px gives the line center. The level is the right-running minimum of that bottom edge. Because the level row can only increase with time and censor ticks only push the bottom edge down, ticks cannot propagate a misreading to the left. The first point was not treated as a special case.
- Group B is drawn over group A. A columns where blue is missing or adjacent to orange (122 columns, listed in `measurements.json`) are excluded. Their level is taken from the next reliable column to the right. A drop hidden under B is therefore placed at the first visible column after it, up to about 0.9 months late in the 15.4-16.3 month overlap.
- Drop time is the left edge of the riser plus 1.5 px (the riser is 4 px wide). Time error is about ±0.04 months.
- Censor ticks are columns whose extent is about 8 px above and below the line. Ticks inside a riser, or hidden under the other arm, cannot be seen. Tick width shows that a tick is visible, not how many censorings it represents. One 4 px-wide B tick near 24.05 was counted as a single tick.

## Reconstruction (`code/reconstruct.py`)
- This is my own Guyot-style iteration within each risk-table interval [t_k, t_{k+1}). At each measured drop, d = round(n_risk·(1 − S_after/Ŝ_before)), where Ŝ is the KM estimate of the records reconstructed so far. This allows d > 1 and absorbs risers split across columns. The number of censorings in an interval is n_k − n_{k+1} − events, iterated to a fixed point.
- Censorings go at the visible tick times first. **Assumption (primary):** censorings the risk table requires beyond the visible ticks are spread evenly across the interval. This added one censoring to A in [0,6) and one to B in each of [12,18), [18,24), [24,30) and [30,36). The risk-table counts constrain these placements, but their times are not identified.
- At tied times, events come before censorings. The printed risk at 36 is 0, so every time is below 36; the last B tick is at 35.99.
- The algorithm is deterministic. The seed is set and recorded but no random draws are used.
- Result: A has 74 events and 26 censorings; B has 69 events and 31 censorings. Every interval reconciled exactly with the printed risk table, with no residual conflicts (`reconstruct_log_primary.txt`).

## Verification (`code/checks.py` → `checks.json`)
- The committed `ipd.csv` was reloaded and the right-continuous KM step function recomputed per arm. It was compared with the measured curve at 21 times per arm from 0.25 to 35.5 months; check times were moved at least 0.08 months away from measured drops. The tolerance of 0.015 in S was set before the comparison.
- All curve checks pass. Most residuals are ≤ 0.0015. The B tail after 30.5 months is 0.005 high, which is less than one event step at n ≈ 9.
- All 14 risk-table counts (records with observed_time ≥ t) match exactly, including 0 at 36. Arm sizes and 0/1 event indicators pass. The CSV SHA-256 is recorded in `checks.json`.
- `overlay_check.png` shows the reconstructed KM (thin lines, offset ±3 px) over the figure.

## Sensitivity (`sensitivity.csv`)
- The one alternative that was run treats the non-visible extra censorings as additional multiplicity on visible ticks in the same interval. At the common supported horizon of 35.6 months (last A observation 35.66):
  - A: S = 0.1953 vs 0.1952; RMST 15.892 vs 15.883 months.
  - B: S = 0.2557 vs 0.2564; RMST 15.522 vs 15.531 months.
  - The largest pointwise difference in S is below 0.001.
- This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- The exact times of the five non-visible censorings, possible multiple censorings behind single ticks, and events or ticks hidden under the overlaid curve are not identified by the figure.
- Event times are pixel-quantized to about 0.025 months, so tied-looking drops may merge or split. The KM levels still match within tolerance.
- No covariates or follow-up beyond what is plotted were created.
