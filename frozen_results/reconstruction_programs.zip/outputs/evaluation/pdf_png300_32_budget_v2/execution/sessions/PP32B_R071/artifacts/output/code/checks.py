"""Reload committed CSV(s), recompute right-continuous KM, compare to measurements; write checks.json.

Usage: python checks.py [outdir]   (reads outdir/ipd.csv, outdir/measurements.json, outdir/measured_curve_*.csv,
                                    and outdir/sensitivity.csv if present)
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
TOL = 0.015   # fixed before comparison: ~1.5 px line-centre reading (0.002) + <1 event step at n>=70,
              # about half an event step at n~25-35; tail checks where n<15 flagged separately
HORIZON = 35.6  # common supported horizon: last A observation 35.66 months (B line ends at 35.99)


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return out


def S_at(curve, x):   # right-continuous step
    s = 1.0
    for u, v in curve:
        if u <= x: s = v
        else: break
    return s


def rmst(curve, h):
    area, last_t, last_s = 0.0, 0.0, 1.0
    for u, v in curve:
        if u > h: break
        area += last_s * (u - last_t); last_t, last_s = u, v
    return area + last_s * (h - last_t)


M = json.load(open(os.path.join(OUT, 'measurements.json')))
path = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
res = {'csv': 'ipd.csv', 'sha256': sha, 'tolerance_S': TOL,
       'tolerance_justification': 'fixed a priori: pixel reading error ~0.002 plus rounding of drops to integer '
                                  'events; residuals where n_risk<15 can reach one event step and are reported, not retuned',
       'structure': {}, 'risk_table': {}, 'curve': {}, 'event_totals': 'unavailable (not in manifest)'}
ok_cols = list(df.columns) == ['group', 'observed_time', 'event']
for g in 'AB':
    d = df[df.group == g]
    res['structure'][g] = {'n': int(len(d)), 'expected_n': M['risk_table'][g][0],
                           'pass': bool(len(d) == M['risk_table'][g][0] and ok_cols and set(d.event.unique()) <= {0, 1}
                                        and np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                           'events': int(d.event.sum()), 'censored': int((d.event == 0).sum())}
    # risk table: records with observed_time >= t
    rt = []
    for t, n in zip(M['risk_table']['times'], M['risk_table'][g]):
        r = int((d.observed_time >= t).sum())
        rt.append({'t': t, 'printed': n, 'reconstructed': r, 'residual': r - n, 'status': 'pass' if r == n else 'fail'})
    res['risk_table'][g] = rt
    # curve comparison at supported times away from measured drops
    cur = km(d)
    mc = pd.read_csv(os.path.join(OUT, f'measured_curve_{g}.csv'))
    step_t = np.array([s['time'] for s in M[g]['steps']])
    checks = []
    for t0 in [0.25, 1, 2, 3, 4.5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 35.5]:
        t = t0
        while len(step_t) and np.min(np.abs(step_t - t)) < 0.08: t += 0.05
        row = mc.iloc[(mc.time - t).abs().argmin()]
        rec = S_at(cur, t); nr = int((d.observed_time >= t).sum())
        r = rec - row.S
        checks.append({'t': round(t, 3), 'measured_S': round(float(row.S), 4), 'measured_col_occluded': bool(row.occluded),
                       'reconstructed_S': round(rec, 4), 'residual': round(float(r), 4), 'n_risk': nr,
                       'status': 'pass' if abs(r) <= TOL else ('unresolved' if nr < 15 else 'fail')})
    res['curve'][g] = checks
    res['structure'][g]['S_at_horizon'] = round(S_at(cur, HORIZON), 4)
    res['structure'][g]['rmst_to_horizon'] = round(rmst(cur, HORIZON), 3)

sp = os.path.join(OUT, 'sensitivity.csv')
if os.path.exists(sp):
    ds = pd.read_csv(sp); sens = {'horizon_months': HORIZON,
        'assumption': 'extra (non-visible) censorings allocated as additional multiplicity of visible ticks within the '
                      'same risk interval instead of evenly over the interval'}
    for g in 'AB':
        c1, c2 = km(df[df.group == g]), km(ds[ds.group == g])
        sens[g] = {'S_primary': round(S_at(c1, HORIZON), 4), 'S_sensitivity': round(S_at(c2, HORIZON), 4),
                   'RMST_primary': round(rmst(c1, HORIZON), 3), 'RMST_sensitivity': round(rmst(c2, HORIZON), 3),
                   'max_abs_S_diff_0_to_horizon': round(max(abs(S_at(c1, x) - S_at(c2, x)) for x in np.arange(0, HORIZON, 0.025)), 4)}
    res['sensitivity'] = sens

json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    print(g, res['structure'][g], [c['status'] for c in res['risk_table'][g]])
    print('  curve', [(c['t'], c['residual'], c['status']) for c in res['curve'][g] if c['status'] != 'pass'])
print(res.get('sensitivity'))
