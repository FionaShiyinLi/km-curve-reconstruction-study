"""Reconstruct participant-level records from measurements.json (written by extract.py).

Usage: python reconstruct.py [measurements.json] [outdir] [--mode primary|sensitivity]
Algorithm (own implementation, Guyot-style iteration within risk-table intervals):
  * Interval k = [t_k, t_{k+1}) between printed risk-table times; n_k printed at risk.
  * Censorings in interval: c_k = n_k - n_{k+1} - (events in interval), iterated to a fixed point.
  * Censor placement: detected tick times first; if c_k exceeds the visible ticks the extras are
    placed (primary) evenly over the interval, or (sensitivity) as extra multiplicity on visible
    ticks in the interval; if c_k is smaller than the visible ticks an evenly spaced subset is used.
  * Events at each measured drop: d = round(n_risk * (1 - S_after / S_hat_before)), where S_hat is
    the KM of records reconstructed so far (so split or partially rendered risers self-correct).
  * Events precede censorings at tied times. All times are < 36 because the printed risk at 36 is 0.
"""
import sys, json, os
import numpy as np

SEED = 266141798          # supplied code seed; the algorithm is deterministic, no draws are made
np.random.seed(SEED)

HERE = os.path.dirname(os.path.abspath(__file__))
argv = sys.argv[1:]
if '--mode' in argv: i = argv.index('--mode'); MODE = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
else: MODE = 'primary'
args = argv
MEAS = args[0] if len(args) > 0 else os.path.join(HERE, '..', 'measurements.json')
OUT = args[1] if len(args) > 1 else os.path.join(HERE, '..')

M = json.load(open(MEAS))
RT = M['risk_table']
TMAX_OBS = 36.0 - 1e-3


def place_censors(ticks, c, lo, hi, mode):
    ticks = sorted(ticks)
    if c <= 0: return []
    if c <= len(ticks):
        idx = np.round(np.linspace(0, len(ticks) - 1, c)).astype(int) if c > 1 else [len(ticks) // 2]
        return [ticks[i] for i in idx]
    extra = c - len(ticks)
    if mode == 'sensitivity' and ticks:
        # extras treated as multiplicity of visible ticks, spread over the ticks
        idx = [i % len(ticks) for i in np.round(np.linspace(0, len(ticks) - 1, extra)).astype(int)] if extra > 1 else [len(ticks) // 2]
        return ticks + [ticks[i] for i in idx]
    ext = list(lo + (np.arange(extra) + 0.5) * (hi - lo) / extra)
    return ticks + ext


def reconstruct(g, mode):
    steps = M[g]['steps']; ticks = [t['time'] for t in M[g]['ticks']]
    times, nrisk = RT['times'], RT[g]
    recs = []            # (time, event)
    n_alive = nrisk[0]
    S_hat = 1.0
    log = []
    for k in range(len(times) - 1):
        lo, hi = times[k], times[k + 1]
        hi_eff = min(hi, TMAX_OBS) if k == len(times) - 2 else hi
        st = [s for s in steps if lo <= s['time'] < hi]
        tk = [t for t in ticks if lo <= t < hi]
        target_removed = nrisk[k] - nrisk[k + 1]
        if nrisk[k] != n_alive:
            log.append(f'{g} interval {lo}-{hi}: carried risk {n_alive} != printed {nrisk[k]}')
        c = len(tk)
        for it in range(100):
            cens = place_censors(tk, c, lo, hi_eff, mode)
            n = n_alive; S = S_hat; ev = []
            cs = sorted(cens); ci = 0
            for s in st:
                while ci < len(cs) and cs[ci] < s['time']:
                    n -= 1; ci += 1
                if n <= 0: break
                d = int(round(n * (1 - s['S_after'] / S))) if S > 0 else 0
                d = max(0, min(d, n))
                if d:
                    ev.append((s['time'], d)); S *= (1 - d / n); n -= d
            D = sum(d for _, d in ev)
            c_new = max(0, n_alive - nrisk[k + 1] - D)
            if c_new == c: break
            c = c_new
        removed = D + len(cens)
        if removed != target_removed:
            log.append(f'{g} interval {lo}-{hi}: removed {removed} vs printed {target_removed} (events {D})')
        for t, d in ev: recs += [(t, 1)] * d
        recs += [(min(t, TMAX_OBS), 0) for t in cens]
        n_alive -= removed; S_hat = S
        log.append(f'{g} [{lo},{hi}): events {D}, censored {len(cens)} (visible ticks {len(tk)})')
    # anyone left beyond the last interval (should be none because printed risk at 36 is 0)
    if n_alive > 0:
        log.append(f'{g}: {n_alive} participants left after last interval -> censored at last tick')
        recs += [(max(ticks), 0)] * n_alive
    return recs, log


def write_atomic(path, rows):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        f.write('group,observed_time,event\n')
        for g, t, e in rows: f.write(f'{g},{t:.4f},{e}\n')
    os.replace(tmp, path)


if __name__ == '__main__':
    rows, logs = [], []
    for g in 'AB':
        recs, log = reconstruct(g, MODE)
        assert len(recs) == M['risk_table'][g][0], (g, len(recs))
        rows += [(g, t, e) for t, e in sorted(recs)]
        logs += log
    name = 'ipd.csv' if MODE == 'primary' else 'sensitivity.csv'
    write_atomic(os.path.join(OUT, name), rows)
    with open(os.path.join(OUT, f'reconstruct_log_{MODE}.txt'), 'w') as f: f.write('\n'.join(logs) + '\n')
    print('\n'.join(logs))
