"""Measure KM step curves and censor ticks from the raster figure.

Usage: python extract.py [path/to/figure.png] [outdir]
Calibration (from labelled axis tick marks, measured in pixels):
  x: 0 months -> column 269.5, 36 months -> column 1709.5 (tick pairs 269/270, 1709/1710)
  y: S=1.0 -> row 179.5, S=0.0 -> row 929.5 (tick pairs 179/180, 929/930)
Line drawn 4 px thick, censor ticks 3 px wide extending ~8 px above/below the line.
"""
import sys, json, os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input', 'figure.png')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '..')

X0, X36 = 269.5, 1709.5
Y1, Y0 = 179.5, 929.5
def t_of(col): return (col - X0) / (X36 - X0) * 36.0
def s_of(rowc): return (Y0 - rowc) / (Y0 - Y1)

COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}
a = np.asarray(Image.open(FIG).convert('RGB')).astype(int)
masks = {g: (np.abs(a - np.array(c)).sum(2) < 60) for g, c in COLORS.items()}
ROW_LO, ROW_HI = 150, 935
COL_LO, COL_HI = 266, 1714


def measure(g):
    m = masks[g]
    other = masks['B'] if g == 'A' else None   # B is drawn on top of A
    ncol = COL_HI - COL_LO
    bot = np.full(ncol, np.nan); top = np.full(ncol, np.nan); occl = np.zeros(ncol, bool)
    for i, x in enumerate(range(COL_LO, COL_HI)):
        r = np.where(m[ROW_LO:ROW_HI, x])[0] + ROW_LO
        if len(r) == 0:
            occl[i] = other is not None and other[ROW_LO:ROW_HI, x].any()
            continue
        bot[i], top[i] = r.max(), r.min()
        if other is not None:
            # bottom edge adjacent to an overlying orange pixel -> blue may continue underneath
            if other[int(r.max()) + 1:int(r.max()) + 4, x].any() or other[int(r.min()) - 3:int(r.min()), x].any():
                occl[i] = True
    # level = right-running minimum of bottom edge over reliable columns
    # (true level rows are nondecreasing in x; ticks only push the bottom edge down)
    b = np.where(np.isnan(bot) | occl, np.inf, bot)
    # a censor tick at the very end of the line has no reliable column to its right;
    # replace the trailing tick columns by the level of the column before the tick
    fin = np.where(np.isfinite(b))[0]
    j = fin.max(); k = j
    while k > 0 and np.isfinite(b[k]) and bot[k] - top[k] >= 12: k -= 1
    if k < j:
        b[k + 1:j + 1] = np.minimum(b[k + 1:j + 1], b[k])
    lev = np.minimum.accumulate(b[::-1])[::-1]
    last = np.where(np.isfinite(b))[0].max()
    lev[last + 1:] = np.nan
    # ticks: bottom edge ~8 px below level and top edge ~7 px above the line top
    tickcols = []
    for i in range(ncol):
        if np.isfinite(bot[i]) and np.isfinite(lev[i]) and bot[i] - lev[i] >= 6:
            # vertical extent above the line top (lev-3) also required
            if top[i] <= lev[i] - 3 - 5:
                tickcols.append(i)
    # cluster tick columns
    ticks = []
    for i in tickcols:
        if ticks and i - ticks[-1][-1] <= 1: ticks[-1].append(i)
        else: ticks.append([i])
    tick_list = []
    for cl in ticks:
        w = len(cl); c = COL_LO + np.mean(cl)
        tick_list.append({'col': float(c), 'width_px': w, 'time': round(float(t_of(c)), 4),
                          'S': round(float(s_of(lev[cl[0]] - 1.5)), 4),
                          'min_count_from_width': int(max(1, round(w / 3)))})
    # steps: columns where the level changes
    steps = []
    levc = lev - 1.5
    start_i = int(np.where(np.isfinite(bot))[0][0])
    # KM starts at S=1 by definition; the line top at S=1 is checked in 'start' below
    prev = Y1
    steps_raw = []
    for i in range(start_i + 1, last + 1):
        if levc[i] > prev + 0.5:
            steps_raw.append((i, prev, levc[i])); prev = levc[i]
    # merge drops in consecutive columns (a single riser rendered over >1 column is one time)
    merged = []
    for i, p, n in steps_raw:
        if merged and i - merged[-1]['i_last'] <= 1:
            merged[-1]['row_after'] = n; merged[-1]['i_last'] = i
        else:
            merged.append({'i_first': i, 'i_last': i, 'row_before': p, 'row_after': n})
    for s in merged:
        col = COL_LO + s['i_first'] + 1.5   # riser is 4 px wide; first changed column is its left edge
        steps.append({'col': float(col), 'time': round(float(t_of(col)), 4),
                      'S_before': round(float(s_of(s['row_before'])), 5),
                      'S_after': round(float(s_of(s['row_after'])), 5)})
    start = {'first_col': int(COL_LO + start_i), 'S_start': round(float(s_of(levc[start_i])), 5),
             'raw_top': float(top[start_i]), 'raw_bot': float(bot[start_i])}
    end = {'last_col': COL_LO + int(last), 't_last': round(float(t_of(COL_LO + last)), 4),
           'S_end': round(float(s_of(levc[last])), 5)}
    ocols = [int(COL_LO + i) for i in np.where(occl)[0]]
    curve = [{'col': int(COL_LO + i), 'time': round(float(t_of(COL_LO + i)), 4),
              'S': round(float(s_of(levc[i])), 5), 'occluded': bool(occl[i])}
             for i in range(start_i, last + 1)]
    return {'start': start, 'end': end, 'steps': steps, 'ticks': tick_list,
            'n_occluded_cols': len(ocols), 'occluded_cols': ocols}, curve


if __name__ == '__main__':
    res = {}
    import csv
    for g in 'AB':
        r, curve = measure(g)
        res[g] = r
        with open(os.path.join(OUT, f'measured_curve_{g}.csv'), 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=['col', 'time', 'S', 'occluded']); w.writeheader(); w.writerows(curve)
        print(g, 'start', r['start'], 'end', r['end'], 'nsteps', len(r['steps']), 'nticks', len(r['ticks']),
              'occluded', r['n_occluded_cols'])
    res['calibration'] = {'x0_col': X0, 'x36_col': X36, 'y1_row': Y1, 'y0_row': Y0}
    res['risk_table'] = {'times': [0, 6, 12, 18, 24, 30, 36],
                         'A': [100, 71, 46, 33, 24, 8, 0], 'B': [100, 61, 45, 35, 26, 10, 0],
                         'source': 'read visually from the number-at-risk table printed under the figure'}
    with open(os.path.join(OUT, 'measurements.json'), 'w') as f:
        json.dump(res, f, indent=1)
