#!/usr/bin/env python3
"""Same-horizon comparison of primary vs sensitivity: KM survival and restricted area."""
import json, os, sys, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
H = 35.0  # common supported horizon (months): both arms have >0 at risk and drawn curves beyond it

def km_steps(d):
    ut = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; S = []
    for u in ut:
        s *= 1 - ((d.observed_time == u) & (d.event == 1)).sum() / (d.observed_time >= u).sum(); S.append(s)
    return ut, np.array(S)

def summ(d):
    ut, S = km_steps(d)
    Sf = lambda t: 1.0 if np.searchsorted(ut, t, 'right') == 0 else S[np.searchsorted(ut, t, 'right') - 1]
    k = ut <= H; knots = np.r_[0, ut[k], H]; vals = np.r_[1, S[k]]
    area = float(np.sum(np.diff(knots) * vals))  # exact integral of right-continuous step function
    return dict(S={t: round(float(Sf(t)), 6) for t in [6, 12, 18, 24, 30, H]}, area_0_H=round(area, 5),
                at_risk_H=int((d.observed_time >= H).sum()))
res = {'horizon_months': H}
for f in ['ipd.csv', 'sensitivity.csv']:
    df = pd.read_csv(os.path.join(out, f))
    res[f] = {g: summ(df[df.group == g]) for g in 'AB'}
res['difference_sensitivity_minus_primary'] = {g: dict(area=round(res['sensitivity.csv'][g]['area_0_H'] - res['ipd.csv'][g]['area_0_H'], 5),
    S_H=round(res['sensitivity.csv'][g]['S'][H] - res['ipd.csv'][g]['S'][H], 6)) for g in 'AB'}
json.dump(res, open(os.path.join(out, 'sensitivity_comparison.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
