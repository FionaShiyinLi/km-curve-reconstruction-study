#!/usr/bin/env python3
"""KM-figure -> IPD reconstruction from vector PDF paths.

Usage: python reconstruct.py [--input ../input] [--out output] [--mode primary|sensitivity]

Steps
1. Parse vector step paths (curves), censor-tick segments and risk-table text.
2. Calibrate from axis tick anchors (x: t=0 at 64.8pt, t=36 at 410.4pt; y: S=1 at
   top-y 43.2pt, S=0 at 223.2pt), read from the black tick-mark lines.
3. For each arm, dynamic programming over number-at-risk n_k just before each
   vertical drop k.  d_k(n) = nearest integer to n*drop/S_prev (>=1);
   cost = ((model drop - observed drop)/sigma)^2, sigma from 4-decimal coordinate
   rounding.  Transitions allow censoring between drops; censoring in a segment with
   no censor tick is penalized heavily (primary) and risk-table counts are hard
   constraints (n(t_j) = #{observed_time >= t_j}).
4. Censored records are placed at tick times within each segment.
"""
import argparse, json, os, re
import numpy as np
import pdfplumber

SEED = 278132114
BLUE = (0.121569, 0.466667, 0.705882)
ORANGE = (1.0, 0.498039, 0.054902)


def parse(pdf_path):
    pg = pdfplumber.open(pdf_path).pages[0]
    blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
    xt = sorted({round(l['x0'], 4) for l in blk if abs(l['x1'] - l['x0']) < 1e-6 and l['bottom'] - l['top'] < 4})
    yt = sorted({round(l['top'], 4) for l in blk if abs(l['bottom'] - l['top']) < 1e-6 and l['x1'] - l['x0'] < 4})
    words = pg.extract_words()
    xlab = sorted([(float(w['text']), (w['x0'] + w['x1']) / 2) for w in words
                   if re.fullmatch(r'\d+', w['text']) and 229 < w['top'] < 232], key=lambda a: a[1])
    ylab = sorted([(float(w['text']), (w['top'] + w['bottom']) / 2) for w in words
                   if re.fullmatch(r'\d\.\d', w['text'])], key=lambda a: a[1])
    # match labels to nearest tick
    xa = [(v, min(xt, key=lambda t: abs(t - c))) for v, c in xlab]
    ya = [(v, min(yt, key=lambda t: abs(t - c))) for v, c in ylab]
    bx = np.polyfit([p for _, p in xa], [v for v, _ in xa], 1)
    by = np.polyfit([p for _, p in ya], [v for v, _ in ya], 1)
    # legend (lw 1.0 lines) -> colour to group
    leg = {}
    for l in pg.lines:
        if l['linewidth'] == 1.0:
            lx = l['x1']
            lab = min([w for w in words if w['text'] in 'AB' and w['top'] < 30], key=lambda w: abs(w['x0'] - lx))
            leg[tuple(l['stroking_color'])] = lab['text']
    curves, ticks = {}, {}
    for cv in pg.curves:
        g = leg[tuple(cv['stroking_color'])]
        curves[g] = np.array(cv['pts'])
    for g in 'AB':
        ticks[g] = []
    for l in pg.lines:
        if l['linewidth'] == 0.65:
            g = leg[tuple(l['stroking_color'])]
            ticks[g].append(((l['x0'] + l['x1']) / 2, (l['top'] + l['bottom']) / 2))
    # risk table rows
    risk = {}
    rows = {}
    for w in words:
        if w['top'] > 280:
            rows.setdefault(round(w['top']), []).append(w)
    for _, ws in rows.items():
        ws = sorted(ws, key=lambda w: w['x0'])
        g = ws[1]['text']
        vals = []
        for w in ws[2:]:
            c = (w['x0'] + w['x1']) / 2
            vals.append((float(np.polyval(bx, c)), int(w['text'])))
        risk[g] = vals
    return dict(bx=bx, by=by, xa=xa, ya=ya, curves=curves, ticks=ticks, risk=risk)


def steps(pts, bx, by):
    """Return drop times, S before, S after (observed), final time of curve."""
    d = np.diff(pts, axis=0)
    idx = np.where(np.abs(d[:, 1]) > 1e-9)[0]
    t = np.polyval(bx, pts[idx, 0])
    sb = np.polyval(by, pts[idx, 1])
    sa = np.polyval(by, pts[idx + 1, 1])
    return t, sb, sa, float(np.polyval(bx, pts[-1, 0]))


def reconstruct(g, P, n0, mode):
    bx, by = P['bx'], P['by']
    t, sb, sa, tend = steps(P['curves'][g], bx, by)
    K = len(t)
    tt = np.sort(np.polyval(bx, np.array([x for x, _ in P['ticks'][g]])))
    R = [(round(a, 6), b) for a, b in P['risk'][g]]
    R = [(round(a), b) for a, b in R]  # labels are integer months
    slope = abs(by[0])                   # S per pt
    sig = 5e-5 * slope * np.sqrt(2)      # 4-decimal rounding of both endpoints (S units)
    drop = sb - sa
    N = np.arange(n0 + 1)
    BIG, EPS = 1e3, 1e-3

    W = 2.0  # cost per unit |censorings - ticks| in a segment (primary)

    def seg_pen(lo, hi, closed_lo=True):
        """Return penalty function of censoring count c in [lo, hi)."""
        m = int(np.sum((tt >= lo) & (tt < hi)))
        if mode == 'primary':
            # ticks treated as one record each; segments w/o ticks strongly penalized
            return lambda c: np.where(np.asarray(c) < 0, INF,
                                      (W if m > 0 else BIG) * np.abs(np.asarray(c) - m))
        # sensitivity: ticks ignored; minimal censoring preference only
        return lambda c: np.where(np.asarray(c) < 0, INF, EPS * np.asarray(c))

    # boundaries after each drop k: interval [t_k, t_{k+1}) ; last: [t_K, inf)
    INF = np.inf
    cost = np.full(n0 + 1, INF)
    # anchor t=0 -> n before first drop = R(0) = n0 (no censoring before first drop)
    assert R[0][0] == 0 and R[0][1] == n0
    # censoring allowed before first drop only if ticks; primary: require n_1 = n0
    cost[n0] = 0.0
    back = []
    dsel = []
    for k in range(K):
        with np.errstate(divide='ignore', invalid='ignore'):
            dk = np.maximum(1, np.rint(N * drop[k] / sb[k])).astype(int)
        mod = sb[k] * dk / np.where(N > 0, N, 1)
        c_obs = ((mod - drop[k]) / sig) ** 2
        c_obs[dk > N] = INF
        c_obs[0] = INF
        tot = cost + c_obs
        a = N - dk  # at risk after events
        a[dk > N] = -1
        dsel.append(dk)
        lo = t[k]
        hi = t[k + 1] if k + 1 < K else INF
        anchors = [(tj, rj) for tj, rj in R if lo < tj <= hi] if k + 1 < K else [(tj, rj) for tj, rj in R if tj > lo]
        # segments between lo, anchors, hi
        bounds = [lo] + [tj for tj, _ in anchors] + [hi]
        pens = [seg_pen(bounds[i], bounds[i + 1]) for i in range(len(bounds) - 1)]
        if k + 1 == K:
            # all remaining censored in [t_K, end); anchors pin counts, last anchor is 0
            rs = [rj for _, rj in anchors]
            assert rs and rs[-1] == 0
            c = tot.copy()
            ok = a >= rs[0]
            c = np.where(ok, c + pens[0](np.where(ok, a - rs[0], 0)), INF)
            for i in range(len(rs) - 1):
                c = c + float(pens[i + 1](rs[i] - rs[i + 1]))
            arg = int(np.argmin(c))
            back.append(None)
            final = (arg, float(c[arg]))
            break
        new = np.full(n0 + 1, INF); bp = np.full(n0 + 1, -1)
        valid = np.isfinite(tot) & (a >= 0)
        nv = N[valid]
        if not anchors:
            C = a[valid][:, None] - N[None, :]             # censorings for (n, n')
            M = tot[valid][:, None] + pens[0](C)
        else:
            rs = [rj for _, rj in anchors]
            assert all(rs[i] >= rs[i + 1] for i in range(len(rs) - 1))
            left = pens[0](a[valid] - rs[0])
            mid = sum(float(pens[i + 1](rs[i] - rs[i + 1])) for i in range(len(rs) - 1))
            right = pens[-1](rs[-1] - N)
            M = (tot[valid] + left)[:, None] + mid + right[None, :]
        if len(nv):
            j = np.argmin(M, axis=0)
            new = M[j, N]
            bp = nv[j]
        back.append(bp)
        cost = new
    # backtrack
    nK, best = final
    ns = [None] * K
    ns[K - 1] = nK
    for k in range(K - 2, -1, -1):
        ns[k] = int(back[k][ns[k + 1]])
    ns = np.array(ns)
    ds = np.array([dsel[k][ns[k]] for k in range(K)])
    return dict(t=t, sb=sb, sa=sa, n=ns, d=ds, ticks=tt, R=R, tend=tend, cost=best)


def build_records(g, r, rng, mode):
    t, n, d, tt, R = r['t'], r['n'], r['d'], r['ticks'], r['R']
    K = len(t)
    recs = []
    for k in range(K):
        recs += [(g, float(t[k]), 1)] * int(d[k])
    # censorings per segment
    for k in range(K):
        lo = t[k]
        hi = t[k + 1] if k + 1 < K else np.inf
        a = n[k] - d[k]
        nxt = n[k + 1] if k + 1 < K else 0
        anchors = [(tj, rj) for tj, rj in R if lo < tj <= hi] if k + 1 < K else [(tj, rj) for tj, rj in R if tj > lo]
        bounds = [lo] + [tj for tj, _ in anchors] + [hi if np.isfinite(hi) else r['tend']]
        counts = []
        rem = a
        for _, rj in anchors:
            counts.append(rem - rj); rem = rj
        counts.append(rem - nxt)
        for i, c in enumerate(counts):
            if c <= 0:
                continue
            s0, s1 = bounds[i], bounds[i + 1]
            m = tt[(tt >= s0) & (tt < s1)]
            if mode == 'sensitivity' or len(m) == 0:
                # spread uniformly (open interval) -- assumption
                times = s0 + (s1 - s0) * (np.arange(c) + 0.5) / c
            elif c >= len(m):
                base = np.repeat(m, c // len(m))
                extra = rng.choice(m, c % len(m), replace=False) if c % len(m) else np.array([])
                times = np.concatenate([base, extra])
            else:
                idx = np.round(np.linspace(0, len(m) - 1, c)).astype(int)
                times = m[idx]
            recs += [(g, float(x), 0) for x in times]
    return recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default='../input')
    ap.add_argument('--out', default='output')
    ap.add_argument('--mode', default='primary', choices=['primary', 'sensitivity'])
    A = ap.parse_args()
    man = json.load(open(os.path.join(A.input, 'manifest.json')))
    assert man['code_seed'] == SEED
    rng = np.random.default_rng(SEED)
    P = parse(os.path.join(A.input, 'figure.pdf'))
    os.makedirs(A.out, exist_ok=True)
    allrec, diag = [], {}
    for g in ['A', 'B']:
        r = reconstruct(g, P, man['groups'][g], A.mode)
        recs = build_records(g, r, rng, A.mode)
        assert len(recs) == man['groups'][g], (g, len(recs))
        allrec += recs
        diag[g] = dict(n_drops=len(r['t']), events=int(r['d'].sum()), censored=len(recs) - int(r['d'].sum()),
                       n_ticks=len(r['ticks']), multi_event_drops=int((r['d'] > 1).sum()), dp_cost=float(r['cost']))
        # save measured observations (primary run only)
        if A.mode == 'primary':
          np.savetxt(os.path.join(A.out, f'measured_steps_{g}.csv'),
                   np.c_[r['t'], r['sb'], r['sa'], r['n'], r['d']], delimiter=',',
                   header='time_months,S_before,S_after,n_risk_fit,d_fit', comments='', fmt='%.6f')
          np.savetxt(os.path.join(A.out, f'censor_ticks_{g}.csv'), r['ticks'], header='time_months', comments='', fmt='%.6f')
    fn = 'ipd.csv' if A.mode == 'primary' else 'sensitivity.csv'
    tmp = os.path.join(A.out, fn + '.tmp')
    with open(tmp, 'w') as f:
        f.write('group,observed_time,event\n')
        for g, x, e in sorted(allrec, key=lambda z: (z[0], z[1], -z[2])):
            f.write(f'{g},{max(0.0, x):.6f},{e}\n')
    os.replace(tmp, os.path.join(A.out, fn))
    json.dump(dict(calibration=dict(x=list(P['bx']), y=list(P['by']), x_anchors=P['xa'], y_anchors=P['ya']),
                   risk=P['risk'], diag=diag), open(os.path.join(A.out, f'diag_{A.mode}.json'), 'w'), indent=1)
    print(json.dumps(diag, indent=1))


if __name__ == '__main__':
    main()
