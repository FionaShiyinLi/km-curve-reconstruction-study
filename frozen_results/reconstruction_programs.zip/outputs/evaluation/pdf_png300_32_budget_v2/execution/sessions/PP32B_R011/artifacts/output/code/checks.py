#!/usr/bin/env python3
"""Reload committed CSV, recompute right-continuous KM, compare to measured curve,
risk table and tick counts; write output/checks.json.
Usage: python checks.py [--input ../input] [--out output]"""
import argparse, hashlib, json, os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reconstruct import parse, steps

ap = argparse.ArgumentParser(); ap.add_argument('--input', default='../input'); ap.add_argument('--out', default='output')
ap.add_argument('--csv', default='ipd.csv')
A = ap.parse_args()
man = json.load(open(os.path.join(A.input, 'manifest.json')))
P = parse(os.path.join(A.input, 'figure.pdf'))
path = os.path.join(A.out, A.csv)
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
assert list(df.columns) == ['group', 'observed_time', 'event']


def km(d):
    """Right-continuous KM: returns function S(t) = prod_{t_i <= t}(1 - d_i/n_i)."""
    ut = np.sort(d.observed_time[d.event == 1].unique())
    s, S = 1.0, []
    for u in ut:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1 - e / n; S.append(s)
    ut, S = np.array(ut), np.array(S)
    return lambda t: np.where(np.searchsorted(ut, t, side='right') > 0, S[np.maximum(np.searchsorted(ut, t, side='right') - 1, 0)], 1.0)

TOL_S = 5e-5 / 180 * 3  # 3x half-unit rounding of 4-decimal y coordinate, in S units
out = dict(csv='output/' + A.csv, sha256=sha, tolerance=dict(
    survival_abs=TOL_S, justification='PDF path y-coordinates are written to 4 decimals (half-unit 5e-5 pt = 2.8e-7 in S); tolerance 3x that plus float error'),
    arms={})
allpass = True
for g in ['A', 'B']:
    d = df[df.group == g]
    S = km(d)
    t, sb, sa, tend = steps(P['curves'][g], P['bx'], P['by'])
    # measured level on each horizontal step: at times midway between drops, and just after each drop
    mids = np.r_[(t[:-1] + t[1:]) / 2, (t[-1] + tend) / 2]
    res_all = S(mids) - sa
    # selected report points: start, several interior, tail
    sel_t = [0.0, 0.5, 3, 6, 9, 12, 18, 24, 30, 33, 35.9]
    meas = []
    for x in sel_t:
        k = np.searchsorted(t, x, side='right') - 1
        m = 1.0 if k < 0 else sa[k]
        r = float(S(np.array([x]))[0])
        meas.append(dict(time=x, measured=round(float(m), 7), reconstructed=round(r, 7), residual=round(r - float(m), 8),
                         status='pass' if abs(r - m) <= TOL_S else 'fail'))
    risk = []
    for tj, rj in P['risk'][g]:
        tj = round(tj); c = int((d.observed_time >= tj).sum())
        risk.append(dict(time=tj, displayed=rj, reconstructed=c, residual=c - rj, status='pass' if c == rj else 'fail'))
    tk = np.sort(np.polyval(P['bx'], np.array([x for x, _ in P['ticks'][g]])))
    cens = np.sort(d.observed_time[d.event == 0].values)
    per_tick = pd.Series(np.round(cens, 6)).value_counts()
    tick_ok = len(cens) == len(tk) and np.allclose(cens, tk, atol=1e-5)
    ev_drop = np.sort(d.observed_time[d.event == 1].unique())
    arm = dict(
        n_records=int(len(d)), n_manifest=man['groups'][g], n_status='pass' if len(d) == man['groups'][g] else 'fail',
        event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
        events=int(d.event.sum()), censored=int((d.event == 0).sum()),
        supplied_event_total='unavailable (manifest has no event totals)',
        time_range=[float(d.observed_time.min()), float(d.observed_time.max())],
        km_vs_measured_all_steps=dict(n_steps=int(len(mids)), max_abs_residual=float(np.abs(res_all).max()),
                                      status='pass' if np.abs(res_all).max() <= TOL_S else 'fail'),
        km_vs_measured_selected=meas,
        distinct_event_times_vs_drops=dict(drops=int(len(t)), event_times=int(len(ev_drop)),
                                           max_time_diff=float(np.abs(ev_drop - t).max()) if len(ev_drop) == len(t) else None),
        risk_table=risk,
        censor_ticks=dict(n_ticks=int(len(tk)), n_censored=int(len(cens)), one_record_per_tick=bool(tick_ok),
                          max_records_at_one_time=int(per_tick.max()),
                          note='tick multiplicity is not directly observable; one-per-tick is supported by the DP fit and risk-table totals'),
    )
    fails = [arm['n_status'], arm['km_vs_measured_all_steps']['status']] + [m['status'] for m in meas] + [r['status'] for r in risk]
    arm['overall'] = 'pass' if all(f == 'pass' for f in fails) else 'fail'
    allpass &= arm['overall'] == 'pass'
    out['arms'][g] = arm
out['overall'] = 'pass' if allpass else 'fail'
name = 'checks.json' if A.csv == 'ipd.csv' else 'checks_' + A.csv.replace('.csv', '.json')
json.dump(out, open(os.path.join(A.out, name), 'w'), indent=1)
print(json.dumps({g: dict(overall=out['arms'][g]['overall'], maxres=out['arms'][g]['km_vs_measured_all_steps']['max_abs_residual'],
                          risk=[r['reconstructed'] for r in out['arms'][g]['risk_table']], ticks=out['arms'][g]['censor_ticks'])
                  for g in 'AB'}, indent=1), out['overall'], sha)
