# Reconstruction assumptions (groups A and B, n = 1000 each, time in months)

**Inputs.** I used `../input/figure.pdf` (vector PDF) and `../input/manifest.json` (group sizes, units, seed 535602793). The algorithm is deterministic, so the seed is set but has no effect. The manifest has no arm-specific event totals, so that check is marked unavailable.

**Measurement.** The figure's survival curves and censor ticks are vector paths, so I read their coordinates directly with pdfplumber instead of processing pixels. Colors were identified from the legend: blue is Group A, orange is Group B.
- **Calibration.** I fitted it by linear regression on the black axis tick segments, with x-ticks labelled 0–36 and y-ticks labelled 0.0–1.0. Maximum residuals were 1e-14 and 6e-16. No global rescaling was applied. Both curves start exactly at S = 1 (y = 43.2 pt, the 1.0 tick).
- **Drops.** Each vertical path segment was taken as one drop, 796 in A and 610 in B, and each short vertical tick-colored segment as one censor mark, 204 in A and 390 in B. All measured values are in `extracted_observations.csv`.

**Algorithm.** The code is in `code/reconstruct.py`.
- **Events per drop.** For each drop, relative drop r = 1 − S_after/S_before = d/n_risk. I chose the smallest integer d ≥ 1 for which d/r is an integer (within rounding) and does not exceed the current number at risk. Every drop gave an integer n_risk = 1/r, so d = 1 per path segment. This is measured from the curve, not assumed. Coincident drops at the same x, which occur once in A, are recorded as tied events.
- **Censoring between events.** Because n_risk is recovered at every event, the number censored between consecutive events is fixed at m = n_prev − d_prev − n_next. In every interval, m exactly equals the number of visible ticks in that interval. So I placed censorings at the tick times, and no tick multiplicity or hidden censoring was needed.
- **Tail.** After the last event, 6 (A) and 9 (B) participants remain, matching the 6 and 9 ticks there. They are censored at those tick times, all before 36 months.

**Risk table.** I read it from the PDF text: A = 1000, 710, 469, 321, 212, 68, 0 and B = 1000, 662, 535, 437, 364, 160, 0 at 0, 6, …, 36 months. It was not used as a constraint; it was reproduced as an independent check, counting observed_time ≥ t. All 14 counts match exactly, including 0 at 36 with no records placed at 36.

**Verification.** `code/checks.py` reloads the committed CSV and recomputes the right-continuous KM estimate. It compares the result with the vector curve at 17 times, from 0 to 36, and at every drop. It also checks risk counts, arm sizes and 0/1 event indicators. Results and the CSV SHA-256 are in `checks.json`.
- **Tolerance.** The tolerance is 0.002 in S. Vector coordinates have about 1e-5 pt precision, and the tolerance covers rounding of times to 1e-5 months.
- **Residuals.** The residual is 0 at all grid times. The largest per-drop residual is about 0.001. It comes from pairs of drops less than 1e-5 months apart that merge into one stored time.

**Limitations.**
- Times are only as precise as the plotted coordinates allow, about 1e-4 months.
- If a single tick stood for several censorings at identical times, or if a drop drawn as one segment were really several tied events, the drawing would not show it. The exact agreement of the risk counts supports the one-to-one reading but cannot prove it.
- No follow-up beyond the plotted curve end was assumed.

**Sensitivity analysis.** None was run. The event and censoring allocation is fully determined by the vector geometry and agrees with the risk table, so there is no materially different plausible alternative to test.
