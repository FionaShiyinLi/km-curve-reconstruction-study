"""KM-to-IPD reconstruction from the vector paths of the assigned figure.pdf.
Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: ../input and ./output relative to the work directory (script is in output/code).
Deterministic; seed recorded for completeness (no randomness used)."""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

SEED = 535602793
np.random.seed(SEED)
here = os.path.dirname(os.path.abspath(__file__))
INP = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', '..', '..', 'input')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, '..')
man = json.load(open(os.path.join(INP, 'manifest.json')))
pg = pdfplumber.open(os.path.join(INP, 'figure.pdf')).pages[0]

# ---- calibration from labelled axis ticks (black tick segments) ----
blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted({round(l['x0'], 3) for l in blk if l['x0'] == l['x1'] and l['bottom'] - l['top'] < 4})
yt = sorted({round(l['top'], 3) for l in blk if l['top'] == l['bottom'] and l['x1'] - l['x0'] < 4})
# x ticks labelled 0,6,...,36 ; y ticks labelled 1.0 (top) ... 0.0 (bottom)
xl = np.arange(0, 37, 6); yl = np.linspace(1, 0, 6)
ax, bx = np.polyfit(xt, xl, 1); ay, by = np.polyfit(yt, yl, 1)
T = lambda x: ax * x + bx
S = lambda top: ay * top + by
calib = dict(x_ticks=xt, y_ticks=yt, t_per_pt=ax, t0=bx, s_per_pt=ay, s0=by,
             x_resid=float(np.max(np.abs(T(np.array(xt)) - xl))),
             y_resid=float(np.max(np.abs(S(np.array(yt)) - yl))))

COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}  # legend lines
risk_t = [0, 6, 12, 18, 24, 30, 36]
words = pg.extract_words()
def risk_row(g):
    row = [w for w in words if abs(w['top'] - (283.9 if g == 'A' else 297.9)) < 1 and w['x0'] > 50]
    return [int(w['text']) for w in sorted(row, key=lambda w: w['x0'])]

def extract(g):
    cv = [c for c in pg.curves if c['stroking_color'] == COL[g]][0]
    pts = np.array(cv['pts'])
    drops = []  # (x, top_before, top_after)
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x0 - x1) < 1e-9 and y1 > y0 + 1e-9:
            drops.append((x0, y0, y1))
    ticks = [l for l in pg.lines if l['stroking_color'] == COL[g] and l['linewidth'] < 0.9]
    tick_x = np.array(sorted(l['x0'] for l in ticks))
    tick_mid = {round(l['x0'], 5): (l['top'] + l['bottom']) / 2 for l in ticks}
    return pts, drops, tick_x, tick_mid

def reconstruct(g, N):
    pts, drops, tick_x, _ = extract(g)
    tick_t = T(tick_x)
    n = N; Sprev = 1.0; recs = []; log = []
    tprev = 0.0
    for (x, y0, y1) in drops:
        t = T(x); sb, sa = S(y0), S(y1)
        rel = 1 - sa / sb
        # choose integer d>=1 so implied n_risk=d/rel is (near-)integer and <= current n
        best = None
        for d in range(1, 60):
            nr = d / rel
            if nr > n + 0.5: break
            err = abs(nr - round(nr))
            if best is None or err < best[2] - 1e-3:
                best = (d, int(round(nr)), err)
        d, nr, err = best
        m = n - nr  # censored in (tprev, t)
        ct = tick_t[(tick_t > tprev - 1e-9) & (tick_t < t - 1e-9)]
        k = len(ct)
        if m < 0:
            log.append(dict(t=t, issue='negative censor count', m=m)); m = 0
        if k >= m:
            cens = ct[:m] if m == k else ct[np.linspace(0, k - 1, m).round().astype(int)] if m > 0 else []
        else:  # more censorings than visible ticks: spread extras uniformly on interval
            extra = np.linspace(tprev, t, m - k + 2)[1:-1]
            cens = np.sort(np.concatenate([ct, extra]))
        if k != m: log.append(dict(t=round(t, 4), ticks=k, censored=m, d=d, n_risk=nr, fit_err=round(err, 4)))
        recs += [(g, float(c), 0) for c in cens] + [(g, float(t), 1)] * d
        n = nr - d; tprev = t; Sprev = sa
    # after last event: remaining censored at ticks, else at curve end
    tend = T(pts[-1][0])
    ct = tick_t[tick_t > tprev - 1e-9]
    k = len(ct)
    if k >= n:
        cens = ct[np.linspace(0, k - 1, n).round().astype(int)] if n > 0 else []
    else:
        cens = np.concatenate([ct, np.full(n - k, tend)])
    log.append(dict(tail_remaining=n, tail_ticks=k, curve_end=round(tend, 4)))
    recs += [(g, float(c), 0) for c in cens]
    return recs, log, drops

if __name__ == '__main__':
    allrec = []; logs = {}
    for g, N in man['groups'].items():
        r, lg, _ = reconstruct(g, N)
        assert len(r) == N, (g, len(r))
        allrec += r; logs[g] = lg
    df = pd.DataFrame(allrec, columns=['group', 'observed_time', 'event'])
    df['observed_time'] = df['observed_time'].clip(lower=0).round(5)
    df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
    json.dump(dict(calibration=calib, logs=logs), open(os.path.join(OUT, 'recon_log.json'), 'w'), indent=1, default=float)
    print(json.dumps(calib, default=float)); 
    for g in logs: print(g, len(logs[g]), logs[g][:15], logs[g][-3:])
