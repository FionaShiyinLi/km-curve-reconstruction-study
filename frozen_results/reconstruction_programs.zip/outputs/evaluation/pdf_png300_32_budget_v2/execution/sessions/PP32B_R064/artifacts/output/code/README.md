Run from the work directory: `python3 output/code/reconstruct.py ../input output` then `python3 output/code/checks.py`.
