"""Reload committed output/ipd.csv, recompute right-continuous KM, compare with the vector curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reconstruct as R

OUT = R.OUT
path = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)

def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return np.array(out)
def km_at(tab, t):
    i = np.searchsorted(tab[:, 0], t, side='right'); return 1.0 if i == 0 else tab[i - 1, 1]
def curve_at(pts, t):  # measured right-continuous value of vector path at time t
    x = (t - R.bx) / R.ax; s = 1.0
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if x0 <= x + 1e-9: s = R.S(y1) if x1 <= x + 1e-9 else R.S(y0)
    return s

res = dict(ipd_sha256=sha, calibration={k: v for k, v in R.calib.items()}, groups={})
TOL_S = 0.002   # ~0.36 pt; vector coordinates are exact to 1e-5 pt, tolerance covers rounding of times to 1e-5 mo
allpass = True
for g, N in R.man['groups'].items():
    d = df[df.group == g]; tab = km(d); pts, drops, tick_x, _ = R.extract(g)
    rows = []
    for t in [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35, 35.9, 36]:
        m = curve_at(pts, t); r = km_at(tab, t)
        rows.append(dict(t=t, measured=round(m, 6), reconstructed=round(r, 6), resid=round(r - m, 6),
                         status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # every drop location
    low = {}
    for x, y0, y1 in drops: low[round(x, 4)] = max(low.get(round(x, 4), 0), y1)  # tied drops: final level at that x
    dres = [km_at(tab, round(R.T(x), 5)) - R.S(y) for x, y in low.items()]
    rk = []
    for t, obs in zip(R.risk_t, R.risk_row(g)):
        rec = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=obs, reconstructed=rec, resid=rec - obs, status='pass' if rec == obs else 'fail'))
    ne = int(d.event.sum())
    gchk = dict(n_records=len(d), n_expected=N, size_status='pass' if len(d) == N else 'fail',
                event_values_ok=bool(set(d.event.unique()) <= {0, 1}), events=ne, censored=len(d) - ne,
                visible_censor_ticks=int(len(tick_x)),
                supplied_event_total='unavailable (not in manifest)',
                max_time=float(d.observed_time.max()),
                max_abs_resid_all_drops=float(np.max(np.abs(dres))), n_drops=len(drops),
                survival_checks=rows, risk_table_checks=rk)
    allpass &= gchk['size_status'] == 'pass' and all(r['status'] == 'pass' for r in rows + rk)
    res['groups'][g] = gchk
res['overall'] = 'pass' if allpass else 'fail'
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1, default=float)
for g in res['groups']:
    x = res['groups'][g]; print(g, {k: v for k, v in x.items() if k not in ('survival_checks', 'risk_table_checks')})
    print([ (r['t'], r['displayed'], r['reconstructed']) for r in x['risk_table_checks']])
    print([ (r['t'], r['measured'], r['resid']) for r in x['survival_checks']])
print(res['overall'], sha)
