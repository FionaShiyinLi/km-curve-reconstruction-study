# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json` (n = 1000 per arm, time in months, seed 1583930717).
- I read the number-at-risk table from the figure by eye. All entries were legible. A: 1000, 689, 476, 325, 226, 85, 0; B: 1000, 764, 569, 439, 318, 132, 0, at 0, 6, ..., 36 months.
- The manifest gives no arm-specific event totals, so that check is marked unavailable. The events in the output (A 803, B 705) are therefore estimates, not supplied values.
- The seed is recorded in the code. The algorithm is deterministic and uses no random draws.

## Measurement (`output/measured_curve.csv`, `output/censor_ticks.csv`)
- **Calibration** uses the labelled axis tick marks. The tick at 0 months is at px x=269.5 and the one at 36 months at x=1709.5 (40 px/month). S=1.0 is at px y=179.5 and S=0.0 at y=929.5 (750 px/unit). No global rescaling was applied.
- **Curve level per pixel column.** I isolated each arm by colour, then removed censor ticks (3 px wide) and risers with a 1x7 horizontal morphological opening. The level is the centre of the remaining run nearest the previous level, followed by a 5-column median filter. There is no running-minimum or reciprocal rescaling.
- **Origin and overlap region (t < about 2.4 months).** The arms overlap here and ticks are dense, so the opening lost the line. I remeasured these columns locally as the median row of the arm's own colour within ±15 px. Ticks are symmetric about the line, so the median is not pulled by them. Where the own colour was hidden by the other arm, I used the median of both colours. The first column reads S ≈ 0.998 for both arms, and the genuine early drops are preserved. Arm-specific values in this region carry ±2–3 px (about ±0.004) of uncertainty, and those columns are flagged `*_filled` in the file.
- **Censor ticks.** A column counts as a tick when the arm's colour extends at least 6 px both above and below the line centre. A cluster of w adjacent columns gets weight ceil(w/3). Visibility is not multiplicity: overlapping ticks cannot be separated, so these weights only give the *relative* timing of censoring. The risk table sets the counts.

## Reconstruction algorithm (own code, `output/code/reconstruct.py`)
- Each risk-table interval is processed in turn, starting from the reconstructed n at risk and S at its start. For a candidate number of censorings C, the C censorings are allocated to the interval's tick clusters in proportion to weight (largest remainder). The columns are then walked. At each column, d = round(n_risk · (1 − S_measured / S_reconstructed)), with d ≥ 0. This is the KM relation applied as cumulative matching, so a drop can hold several tied events and d = 1 is never forced. C is chosen so that the count at risk at the next table time matches the table. It matched exactly for every interval.
- **Final interval (30–36).** The table shows 0 at 36, so every record has time < 36. C was chosen to minimise the mean absolute difference between the reconstructed and measured S over that interval's columns, because the sizes of the tail drops constrain n at risk. Ties were broken toward the previous interval's censorings per unit of tick weight. Anyone still at risk after the last drop is censored at the drawn end of the curve (A 35.86, B 35.94 months). That puts 41 (A) and 80 (B) censorings at a single time.
- **This is an assumption.** A flat tail does not identify the censoring distribution or the maximum follow-up. The true tail censoring may be spread over the last months rather than piled up at the curve end.
- Event times are placed at the riser column minus 0.5 px, so the time resolution is 0.025 months.

## Checks (`output/checks.json`, `output/code/checks.py`)
- `checks.py` reloads the committed CSV and recomputes the right-continuous KM, with events processed before censorings at ties.
- **Survival curve.** The reconstructed KM was compared with the measured curve at 21 times per arm, including 0.24 and 0.5 months and the tail at 34–35.8, with tolerance |ΔS| ≤ 0.01 (about 7.5 px). The tolerance allows for the 4 px line width and antialiasing; one pixel is 0.0013. All points passed. The largest residual over all columns was 0.0025 (A) and 0.0011 (B).
- **Risk table.** Counts of records with observed_time ≥ t equal the displayed numbers at every time, 0 at 36 included.
- **Structure.** Arm sizes, 0/1 event indicators and finite non-negative times all checked.

## Sensitivity (`output/sensitivity.csv`)
- One alternative was run. It has the same interval censoring totals, but censorings are spaced uniformly within each interval and tick positions are ignored.
- Common horizon: 35.8 months. The area under the survival curve (restricted mean) to 35.8 is 15.167 in both versions for A, and 18.379 in both for B.
- The largest difference in S at 6, 12, 18, 24, 30 and 35.8 months is 0.0011 (A, 30 months). Event counts are A 803/803 and B 705/704.
- The timing of censoring within intervals therefore has little effect. This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- The figure does not identify individual censoring times or tick multiplicity. Censoring counts are identified only per risk interval.
- Early (t < 2.4) arm-specific levels are measured under overlap.
- The tail censoring distribution is not identified, which is why censorings pile up at the curve end.
- Event totals could not be checked because none were supplied.
