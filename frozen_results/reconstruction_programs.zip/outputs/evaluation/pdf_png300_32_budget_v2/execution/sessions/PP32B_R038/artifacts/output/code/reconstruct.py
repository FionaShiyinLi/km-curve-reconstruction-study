#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python3 output/code/reconstruct.py [--input ../input] [--out output] [--mode ticks|uniform]
  mode=ticks   (primary): censoring allocated to detected censor-tick positions
  mode=uniform (sensitivity): censoring spread uniformly within each risk-table interval
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd
from PIL import Image
from scipy import ndimage

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
ap.add_argument("--mode", default="ticks", choices=["ticks", "uniform"])
args = ap.parse_args()

man = json.load(open(os.path.join(args.input, "manifest.json")))
SEED = man["code_seed"]
rng = np.random.default_rng(SEED)  # recorded; algorithm itself is deterministic
N = man["groups"]

# ---- calibration from labelled axis ticks (pixel centres measured from tick marks) ----
# x: '0' tick at columns 269-270, '6' at 509-510, ..., '36' at 1709-1710  -> 40 px / month
# y: '1.0' tick at rows 179-180, '0.0' at 929-930                      -> 750 px / unit
X0, PX_PER_MONTH = 269.5, 40.0
Y1, Y0 = 179.5, 929.5
t_of = lambda x: (x - X0) / PX_PER_MONTH
s_of = lambda y: (Y0 - y) / (Y0 - Y1)

# risk table read visually from the figure (all entries clearly legible)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 689, 476, 325, 226, 85, 0], "B": [1000, 764, 569, 439, 318, 132, 0]}
COL = {"A": (31, 119, 180), "B": (255, 127, 14)}

img = np.array(Image.open(os.path.join(args.input, "figure.png")).convert("RGB")).astype(int)
H, W, _ = img.shape
PLOT = (slice(150, 928), slice(268, 1712))  # inside axes (exclude axis lines)


def mask(c):
    m = np.zeros((H, W), bool)
    sub = img[PLOT]
    m[PLOT] = np.abs(sub - np.array(c)).sum(2) < 150
    return m


raw = {g: mask(c) for g, c in COL.items()}
# horizontal opening removes 3-px-wide censor ticks and 4-px-wide risers, keeps the step line
line = {g: ndimage.binary_opening(raw[g], structure=np.ones((1, 7))) for g in raw}

xs = np.arange(270, 1709)
meas = {}
for g in raw:
    lev = np.full(len(xs), np.nan)
    prev = Y1
    for i, x in enumerate(xs):
        rows = np.where(line[g][:, x])[0]
        if len(rows) == 0:
            continue
        # split into runs; take run nearest previous level (guards against other stray pixels)
        runs = np.split(rows, np.where(np.diff(rows) > 1)[0] + 1)
        r = min(runs, key=lambda r: abs(r.mean() - prev))
        lev[i] = r.mean(); prev = lev[i]
    meas[g] = lev

# fill columns hidden by the other arm (overlap at early times): use other arm's level if
# close to the interpolated own level, otherwise linear interpolation; flag filled columns
filled = {}
for g, o in (("A", "B"), ("B", "A")):
    lev = meas[g].copy()
    ok = ~np.isnan(lev)
    last = xs[ok].max()
    interp = np.interp(xs, xs[ok], lev[ok])
    fl = ~ok & (xs < last)
    # Hidden/overlap columns (mainly t < 2.5 where both arms overlap and ticks are dense):
    # remeasure locally as the median row of the arm's own colour (ticks are symmetric about
    # the line, so the median is robust to them); if the own colour is occluded, use the
    # median of the union of both colours. Tracking window +-15 px from previous level.
    prev = Y1 + 1
    for i in range(len(xs)):
        x = xs[i]
        if not fl[i]:
            if not np.isnan(lev[i]):
                prev = lev[i]
            continue
        lo_, hi_ = int(prev) - 15, int(prev) + 16
        own = np.where(raw[g][lo_:hi_, x])[0] + lo_
        if len(own) < 2:
            own = np.where((raw["A"] | raw["B"])[lo_:hi_, x])[0] + lo_
        lev[i] = np.median(own) if len(own) >= 2 else interp[i]
        lev[i] = max(lev[i], Y1)  # cannot exceed S=1
        prev = lev[i]
    lev[xs > last] = np.nan
    filled[g] = fl
    meas[g] = lev

# light 5-column median filter to suppress single-column antialias misreads (not a running min)
S = {}
end_x = {}
for g in meas:
    ok = ~np.isnan(meas[g])
    end_x[g] = xs[ok].max()
    y = meas[g].copy()
    y[ok] = ndimage.median_filter(y[ok], size=5, mode="nearest")
    s = s_of(y)
    S[g] = s

# ---- censor tick detection: pixels of arm colour >=6 px both above and below the line centre ----
ticks = {}
for g in raw:
    tc = np.zeros(len(xs), bool)
    for i, x in enumerate(xs):
        if np.isnan(meas[g][i]):
            continue
        c = int(round(meas[g][i]))
        tc[i] = raw[g][c - 7:c - 5, x].any() and raw[g][c + 6:c + 8, x].any()
    lab, n = ndimage.label(tc)
    out = []
    for k in range(1, n + 1):
        idx = np.where(lab == k)[0]
        w = len(idx)
        out.append((t_of(xs[idx].mean()), max(1, int(np.ceil(w / 3))), w))  # (time, weight, width)
    ticks[g] = out


def km_walk(g, cens_times, t_lo, t_hi, n0, S_start, allow_all=False):
    """Walk columns in [t_lo,t_hi); events by cumulative matching to measured S."""
    n = n0; s_rec = S_start; ev = []; ce = []
    cens = sorted(cens_times); ci = 0
    for i, x in enumerate(xs):
        t = t_of(x - 0.5)
        if not (t_lo <= t < t_hi) or np.isnan(S[g][i]):
            continue
        while ci < len(cens) and cens[ci] < t and n > 0:
            ce.append(cens[ci]); n -= 1; ci += 1
        target = S[g][i]
        if n > 0 and target < s_rec:
            d = int(round(n * (1 - target / s_rec)))
            d = min(max(d, 0), n)
            if d > 0:
                ev += [t] * d; s_rec *= (1 - d / n); n -= d
    while ci < len(cens) and n > 0:
        ce.append(cens[ci]); n -= 1; ci += 1
    return ev, ce, n, s_rec


def alloc(C, tk, t_lo, t_hi):
    if C <= 0:
        return []
    if args.mode == "uniform" or len(tk) == 0:
        return list(t_lo + (np.arange(C) + 0.5) * (t_hi - t_lo) / C)
    w = np.array([k[1] for k in tk], float); q = C * w / w.sum()
    m = np.floor(q).astype(int); rem = C - m.sum()
    m[np.argsort(-(q - m))[:rem]] += 1
    return [tk[j][0] for j in range(len(tk)) for _ in range(m[j])]


recs = []; log = {}
for g in ("A", "B"):
    n = N[g]; s_rec = 1.0; log[g] = []
    tend = t_of(end_x[g])
    scale = None
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        tk = [tt for tt in ticks[g] if lo <= tt[0] < hi]
        last = hi == RISK_T[-1]
        if not last:
            target = RISK[g][k + 1]
            best = None
            for C in range(0, n + 1):
                ev, ce, nend, sr = km_walk(g, alloc(C, tk, lo, hi), lo, hi, n, s_rec)
                err = abs(nend - target)
                if best is None or err < best[0]:
                    best = (err, C, ev, ce, nend, sr)
                if nend < target:
                    break
            err, C, ev, ce, nend, sr = best
            wsum = sum(t[1] for t in tk)
            scale = C / wsum if wsum else scale
        else:
            # last interval: displayed risk 0 at 36 -> no one followed to 36. Censoring before the
            # curve end uses the previous interval's censored-per-tick-weight (ASSUMPTION);
            # anyone left after the final drop is censored at the drawn curve end (< 36).
            # C is chosen to minimise mean |S_rec - S_meas| over the interval's columns (the
            # drawn tail drops constrain how many can have been censored early); ties broken
            # toward the previous interval's censored-per-tick-weight rate.
            tkk = [t for t in tk if t[0] < tend - 0.05]
            wsum = sum(t[1] for t in tkk)
            C0 = int(round((scale or 1) * wsum))
            cols = [i for i, x in enumerate(xs) if lo <= t_of(x - 0.5) < tend and not np.isnan(S[g][i])]
            best = None
            for CC in range(0, n + 1):
                ev, ce, nend, sr = km_walk(g, alloc(CC, tkk, lo, tend), lo, tend + 1e-9, n, s_rec)
                evt = np.array(sorted(ev)); cet = np.array(sorted(ce))
                # rebuild S_rec at the columns
                allt = sorted([(t, 1) for t in ev] + [(t, 0) for t in ce])
                s = s_rec; nn = n; j = 0; err = 0.0
                for i in cols:
                    tt = t_of(xs[i] - 0.5)
                    while j < len(allt) and allt[j][0] <= tt:
                        tj = allt[j][0]; dd = sum(1 for a in allt[j:] if a[0] == tj and a[1] == 1)
                        cc = sum(1 for a in allt[j:] if a[0] == tj and a[1] == 0)
                        if dd: s *= 1 - dd / nn
                        nn -= dd + cc; j += dd + cc
                    err += abs(s - S[g][i])
                err = err / len(cols)
                key = (round(err, 4), abs(CC - C0))
                if best is None or key < best[0]:
                    best = (key, CC, ev, ce, nend, sr)
            _, C, ev, ce, nend, sr = best
            ce = ce + [tend] * nend; nend = 0
        recs += [(g, t, 1) for t in ev] + [(g, t, 0) for t in ce]
        log[g].append(dict(interval=[lo, hi], n_start=n, events=len(ev), censored=len(ce),
                           n_end=nend, target=RISK[g][k + 1], n_tick_clusters=len(tk)))
        n = nend; s_rec = sr

df = pd.DataFrame(recs, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0).round(4)
assert all((df.group == g).sum() == N[g] for g in N), df.group.value_counts()

os.makedirs(args.out, exist_ok=True)
fn = "ipd.csv" if args.mode == "ticks" else "sensitivity.csv"
tmp = os.path.join(args.out, fn + ".tmp")
df.sort_values(["group", "observed_time"]).to_csv(tmp, index=False)
os.replace(tmp, os.path.join(args.out, fn))

# supporting observations
if args.mode == "ticks":
    pd.DataFrame({"x_px": xs, "t": t_of(xs), "A_y_px": meas["A"], "A_S": S["A"], "A_filled": filled["A"],
                  "B_y_px": meas["B"], "B_S": S["B"], "B_filled": filled["B"]}).to_csv(
        os.path.join(args.out, "measured_curve.csv"), index=False)
    pd.DataFrame([(g, *t) for g in ticks for t in ticks[g]],
                 columns=["group", "t", "weight", "width_px"]).to_csv(
        os.path.join(args.out, "censor_ticks.csv"), index=False)
json.dump(log, open(os.path.join(args.out, f"interval_log_{args.mode}.json"), "w"), indent=1)
print(json.dumps(log, indent=1))
print({g: dict(end_t=t_of(end_x[g]), ticks=len(ticks[g])) for g in ticks})
