#!/usr/bin/env python3
"""Reload committed CSV(s), recompute right-continuous KM, compare with measured curve and risk table.
Usage: python3 output/code/checks.py [--out output]"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument("--out", default="output"); args = ap.parse_args()
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 689, 476, 325, 226, 85, 0], "B": [1000, 764, 569, 439, 318, 132, 0]}
N = {"A": 1000, "B": 1000}
TOL_S = 0.01  # ~7.5 px; line is 4 px thick, antialiasing + median filter + integer events -> 1-3 px typical


def km(d):
    """right-continuous KM step function; events before censorings at ties"""
    t = d.observed_time.values; e = d.event.values
    ut = np.unique(t[e == 1]); s = 1.0; st = []
    for u in ut:
        n = (t >= u).sum(); dd = ((t == u) & (e == 1)).sum(); s *= 1 - dd / n; st.append(s)
    st = np.array(st)
    return lambda x: np.where(np.searchsorted(ut, x, side="right") == 0, 1.0,
                              st[np.maximum(np.searchsorted(ut, x, side="right") - 1, 0)])


def rmst(f, tau):
    g = np.linspace(0, tau, 20001); return float(np.trapezoid(f(g), g))


path = os.path.join(args.out, "ipd.csv")
df = pd.read_csv(path)
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
meas = pd.read_csv(os.path.join(args.out, "measured_curve.csv"))
out = {"csv": "output/ipd.csv", "sha256": sha, "tolerance_S": TOL_S,
       "tolerance_note": "absolute S tolerance 0.01 (~7.5 px at 750 px/unit); measurement is 1-px limited "
                         "(0.0013) plus line-width/antialias ambiguity", "arms": {}}
out["structure"] = {"columns_ok": list(df.columns) == ["group", "observed_time", "event"],
                    "event_integer_01": bool(df.event.isin([0, 1]).all()),
                    "finite_nonneg_time": bool(np.isfinite(df.observed_time).all() and (df.observed_time >= 0).all()),
                    "supplied_event_totals": "unavailable (manifest has none)"}
for g in ("A", "B"):
    d = df[df.group == g]; f = km(d)
    a = {"n": int(len(d)), "n_expected": N[g], "n_pass": len(d) == N[g], "events": int(d.event.sum()),
         "censored": int((d.event == 0).sum()), "max_time": float(d.observed_time.max())}
    rows = []
    for t in [0.25, 0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, 35.8]:
        i = int(np.argmin(np.abs(meas.t.values - t)))
        m = float(meas[f"{g}_S"].iloc[i])
        if np.isnan(m):
            rows.append(dict(t=t, status="unavailable")); continue
        r = float(f(np.array([meas.t.values[i]]))[0])
        rows.append(dict(t=round(float(meas.t.values[i]), 4), measured=round(m, 4), reconstructed=round(r, 4),
                         residual=round(r - m, 4), hidden_by_other_arm=bool(meas[f"{g}_filled"].iloc[i]),
                         status="pass" if abs(r - m) <= TOL_S else "fail"))
    a["km_vs_measured"] = rows
    ok = ~np.isnan(meas[f"{g}_S"].values)
    tt = meas.t.values[ok]; resid = f(tt) - meas[f"{g}_S"].values[ok]
    a["all_columns_abs_resid"] = {"max": round(float(np.abs(resid).max()), 4), "mean": round(float(np.abs(resid).mean()), 4)}
    rk = []
    for t, n in zip(RISK_T, RISK[g]):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=c, residual=c - n, status="pass" if c == n else "fail"))
    a["risk_table"] = rk
    a["censored_at_curve_end"] = int(((d.event == 0) & (d.observed_time == d.observed_time.max())).sum())
    a["rmst_35.8_reconstructed"] = round(rmst(f, 35.8), 3)
    a["area_measured_curve_to_35.8"] = round(float(np.trapezoid(np.nan_to_num(meas[f"{g}_S"].values[meas.t <= 35.8]),
                                                                   meas.t.values[meas.t <= 35.8])), 3)
    out["arms"][g] = a

sp = os.path.join(args.out, "sensitivity.csv")
if os.path.exists(sp):
    sd = pd.read_csv(sp); H = 35.8
    sens = {"csv": "output/sensitivity.csv", "sha256": hashlib.sha256(open(sp, "rb").read()).hexdigest(),
            "assumption": "censoring spread uniformly within each risk interval (ignores tick positions)",
            "common_horizon": H, "arms": {}}
    for g in ("A", "B"):
        fp = km(df[df.group == g]); fs = km(sd[sd.group == g])
        sens["arms"][g] = {"S_primary": {t: round(float(fp(np.array([t]))[0]), 4) for t in [6, 12, 18, 24, 30, H]},
                           "S_sensitivity": {t: round(float(fs(np.array([t]))[0]), 4) for t in [6, 12, 18, 24, 30, H]},
                           "area_primary": round(rmst(fp, H), 3), "area_sensitivity": round(rmst(fs, H), 3),
                           "events_primary": int(df[df.group == g].event.sum()),
                           "events_sensitivity": int(sd[sd.group == g].event.sum())}
    out["sensitivity"] = sens
else:
    out["sensitivity"] = "not run"

tmp = os.path.join(args.out, "checks.json.tmp")
json.dump(out, open(tmp, "w"), indent=1); os.replace(tmp, os.path.join(args.out, "checks.json"))
for g in out["arms"]:
    a = out["arms"][g]
    print(g, a["n"], a["events"], a["max_time"], a["censored_at_curve_end"], a["all_columns_abs_resid"],
          [r["residual"] for r in a["risk_table"]])
    print("  ", [(r["t"], r.get("measured"), r.get("reconstructed"), r["status"]) for r in a["km_vs_measured"]])
    print("  rmst", a["rmst_35.8_reconstructed"], "meas area", a["area_measured_curve_to_35.8"])
print(json.dumps(out["sensitivity"], indent=0)[:1500])
