"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
here = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..')
csv = os.path.join(OUT, 'ipd.csv'); summ = json.load(open(os.path.join(OUT, 'extraction_summary.json')))
df = pd.read_csv(csv); sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
TOL_S = 0.0005  # half of one event step at n=1000 (0.001); vector coordinates are exact to ~1e-5
res = {'csv_sha256': sha, 'columns': list(df.columns), 'arms': {}}
def km(d):
    ts = np.sort(d.loc[d.event == 1, 'observed_time'].unique()); S = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return np.array(out)
def S_at(k, t):
    i = np.searchsorted(k[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else k[i, 1]
for g in 'AB':
    d = df[df.group == g]; k = km(d)
    v = pd.read_csv(os.path.join(OUT, f'curve_vertices_{g}.csv'))
    def meas(t):  # measured step curve: right-continuous from vertex path
        w = v[v.t <= t + 1e-9]; return float(w.S.iloc[-1])
    times = [0.0, 0.5, 1, 3, 6, 9, 12, 18, 24, 27, 30, 33, 35, 35.8]
    cmp = []
    for t in times:
        m, r = meas(t), float(S_at(k, t))
        cmp.append(dict(t=t, measured=round(m, 6), reconstructed=round(r, 6), residual=round(r - m, 6),
                        status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # full-path max deviation at every drop midpoint
    drops = pd.read_csv(os.path.join(OUT, f'drops_{g}.csv'))
    # evaluate just after each drop at stored precision (times saved to 1e-8; min drop gap ~1e-6)
    dev = max(abs(S_at(k, t + 1e-7) - sa) for t, sa in zip(drops.t, drops.S_after))
    devb = max(abs(S_at(k, t - 1e-7) - sb) for t, sb in zip(drops.t, drops.S_before))
    rt = summ['risk_table']
    rk = []
    for t, n in zip(rt['times'], rt[g]):
        c = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=n, reconstructed=c, residual=c - n, status='pass' if c == n else 'fail'))
    res['arms'][g] = dict(n=len(d), expected_n=1000, n_events=int(d.event.sum()), n_censored=int((d.event == 0).sum()),
        event_indicator_integer_01=bool(d.event.isin([0, 1]).all()), finite_nonneg=bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
        supplied_event_total='unavailable (not in manifest)', max_obs_time=float(d.observed_time.max()),
        km_vs_measured=cmp, max_abs_dev_all_drops=float(dev), max_abs_dev_before_drops=float(devb), all_drops_status='pass' if max(dev, devb) <= TOL_S else 'fail', risk_table=rk)
res['tolerance_note'] = f'survival tolerance {TOL_S} = half of one 1/1000 step; risk-table counts must match exactly (observed_time >= t, events before censoring at ties)'
json.dump(res, open(os.path.join(OUT, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    a = res['arms'][g]; print(g, a['n'], a['n_events'], a['max_abs_dev_all_drops'],
        [c['status'] for c in a['km_vs_measured']], [(r['displayed'], r['reconstructed']) for r in a['risk_table']])
