"""KM-to-IPD reconstruction from vector PDF objects (own implementation).
Usage: python reconstruct.py [path/to/figure.pdf] [path/to/manifest.json] [outdir]
"""
import sys, json, os, hashlib
import numpy as np, pandas as pd, pdfplumber

here = os.path.dirname(os.path.abspath(__file__))
PDF = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '../../../input/figure.pdf')
MAN = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, '../../../input/manifest.json')
OUT = sys.argv[3] if len(sys.argv) > 3 else os.path.join(here, '..')
man = json.load(open(MAN))
SEED = man['code_seed']; np.random.seed(SEED)  # no randomness used; recorded
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}

pg = pdfplumber.open(PDF).pages[0]
words = pg.extract_words()
# --- axis calibration from labelled tick marks (black 0.6pt lines) ---
blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted({round(l['x0'], 4) for l in blk if abs(l['x0'] - l['x1']) < 1e-6 and l['bottom'] - l['top'] < 4})
yt = sorted({round(l['top'], 4) for l in blk if abs(l['top'] - l['bottom']) < 1e-6 and l['x1'] - l['x0'] < 4})
xlab = sorted([w for w in words if w['top'] > 228 and w['bottom'] < 240], key=lambda w: w['x0'])
ylab = sorted([w for w in words if w['x0'] > 40 and w['x1'] < 60 and w['top'] < 230], key=lambda w: w['top'])
xv = [float(w['text']) for w in xlab]; yv = [float(w['text']) for w in ylab]
assert len(xt) == len(xv) and len(yt) == len(yv)
ax_, bx_ = np.polyfit(xt, xv, 1); ay_, by_ = np.polyfit(yt, yv, 1)
tx = lambda x: ax_ * np.asarray(x) + bx_
sy = lambda y: ay_ * np.asarray(y) + by_
calib = dict(x_ticks_pt=xt, x_labels=xv, y_ticks_pt=yt, y_labels=yv,
             x_resid=list(tx(xt) - xv), y_resid=list(sy(yt) - yv))

# --- risk table ---
risk = {}
for g in 'AB':
    row = [w for w in words if w['text'] == g and w['x0'] < 50 and w['top'] > 280][0]
    vals = sorted([w for w in words if abs(w['top'] - row['top']) < 1 and w['x0'] > 50], key=lambda w: w['x0'])
    risk[g] = [int(w['text']) for w in vals]
risk_times = xv

obs = {'calibration': calib, 'risk_table': {'times': risk_times, **risk}, 'arms': {}}
rows = []
for g in 'AB':
    N = man['groups'][g]
    cur = [c for c in pg.curves if c['stroking_color'] == COL[g]][0]
    pts = np.array(cur['pts'])
    t = tx(pts[:, 0]); s = sy(pts[:, 1])
    # step vertices: vertical segments = drops
    drops = []  # (time, S_before, S_after)
    for i in range(1, len(pts)):
        if abs(pts[i, 0] - pts[i-1, 0]) < 1e-9 and s[i] < s[i-1] - 1e-9:
            drops.append((t[i], s[i-1], s[i]))
    end_time = t[-1]; end_s = s[-1]
    ticks = [l for l in pg.lines if l['stroking_color'] == COL[g] and abs(l['linewidth'] - 0.65) < 0.01]
    o = np.argsort([l['x0'] for l in ticks])
    ct = tx([ticks[j]['x0'] for j in o])
    cs = sy([(ticks[j]['top'] + ticks[j]['bottom']) / 2 for j in o])
    # --- sweep: censor ticks at time c are removed from risk set after events at same time
    ev = []; n = N; ci = 0; log = []
    for (tt, sb, sa) in drops:
        while ci < len(ct) and ct[ci] < tt - 1e-9:
            n -= 1; ci += 1
        draw = n * (1 - sa / sb)
        d = int(round(draw))
        log.append(dict(t=tt, S_before=sb, S_after=sa, n_risk=n, d_raw=draw, d=d))
        ev += [tt] * d; n -= d
    rem_ticks = ct[ci:]
    n_after_ticks = n - len(rem_ticks)
    obs['arms'][g] = dict(n_vertices=len(pts), n_drops=len(drops), n_ticks=len(ct),
                          n_unique_tick_x=len(np.unique(np.round(ct, 5))),
                          end_time=float(end_time), end_S=float(end_s),
                          max_abs_d_rounding=float(max(abs(r['d_raw'] - r['d']) for r in log)),
                          n_drops_d_gt1=int(sum(r['d'] > 1 for r in log)),
                          residual_at_risk_after_last_tick=int(n_after_ticks))
    cens = list(ct)
    # participants still at risk after all ticks: censored at curve end (last drawn follow-up)
    if n_after_ticks > 0:
        cens += [end_time] * n_after_ticks
    elif n_after_ticks < 0:
        raise RuntimeError(f'{g}: more censor ticks than remaining risk set')
    pd.DataFrame(log).to_csv(os.path.join(OUT, f'drops_{g}.csv'), index=False)
    pd.DataFrame({'t': ct, 'S_at_tick': cs}).to_csv(os.path.join(OUT, f'censor_ticks_{g}.csv'), index=False)
    pd.DataFrame({'t': t, 'S': s}).to_csv(os.path.join(OUT, f'curve_vertices_{g}.csv'), index=False)
    assert len(ev) + len(cens) == N, (g, len(ev), len(cens))
    rows += [(g, float(x), 1) for x in ev] + [(g, float(x), 0) for x in cens]

df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(8)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
tmp = os.path.join(OUT, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, 'ipd.csv'))
json.dump(obs, open(os.path.join(OUT, 'extraction_summary.json'), 'w'), indent=1, default=float)
print(json.dumps(obs['arms'], indent=1)); print(calib['x_resid'], calib['y_resid'])
