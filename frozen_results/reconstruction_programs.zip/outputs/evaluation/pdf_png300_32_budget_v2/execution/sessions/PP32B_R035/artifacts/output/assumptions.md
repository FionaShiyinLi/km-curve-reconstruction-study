# Reconstruction assumptions and methods

**Inputs used:** `../input/figure.pdf` (vector PDF, one page) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 21249183). No other auxiliary information was used. The manifest has no arm-specific event totals, so that check is marked unavailable.

## Algorithm (`code/reconstruct.py`; checks in `code/checks.py`)
1. **Calibration.** Time and survival come from least-squares fits of the black axis tick segments to their text labels (x: 0–36 months, 7 ticks; y: 0–1, 6 ticks). Residuals are below 1e-13, so no global correction was needed or applied.
2. **Curve measurement.** Each arm is a single stroked step path in a distinct color (A: 1578 vertices, B: 1382 vertices). Every vertical segment is treated as a drop. Coordinates are taken directly from the PDF objects, so there is no raster or antialiasing error. Both curves start at exactly S = 1 at t = 0. The first drops are genuine early events and are kept (A at t ≈ 0.01, B at t ≈ 0.004).
3. **Censoring.** Censor marks are separate 4-pt vertical segments in the arm color: 212 for A and 310 for B. All have distinct x positions, so there are no coincident or overlapping marks. Each tick's vertical center lies on its own curve's level (maximum difference below 1e-15). Each tick becomes one censored record at its x-time. At a shared time, events are processed before censorings.
4. **Events.** The code sweeps drops in time order. The risk set n is N minus prior events minus ticks before the drop, and d = n(1 − S_after/S_before) is computed from the measured ratio, not assumed to be 1. Every one of the 788 (A) and 690 (B) drops gives d within 0.00052 of 1, so each drop is one event. This is evidence from the measurements, not an adopted d = 1 rule. Two A drops 1e-6 months apart are kept as separate events.
5. **Closure.** Events plus ticks equal exactly N in each arm: 788 + 212 and 690 + 310. No residual at-risk participants remain, so no follow-up was invented. The last tick in each arm sits at the curve end (A 35.85, B 35.91 months), which agrees with the displayed risk count of 0 at 36 months.
6. The code uses no randomness. The seed is still set with `np.random.seed(21249183)`.

## Risk table
The printed counts at 0, 6, 12, 18, 24, 30 and 36 months were read from the PDF text. They were **not** used as constraints, only as independent checks. All 14 counts match exactly using the rule observed_time ≥ t. The zero at 36 months is met because all records end before 36.

## Checks (`checks.json`)
- The committed CSV is reloaded and the right-continuous KM is recomputed from it, with no interpolation.
- The KM is compared with the measured step path at 14 times from 0 to 35.8 months, including the tail, and immediately before and after every drop.
- The tolerance is 0.0005 (half of one 1/1000 step). The maximum observed deviation is about 3e-7.
- Also checked: arm sizes, 0/1 integer event indicators, and finite nonnegative times. Event totals are unavailable.

## Limitations
- Event times are the x-positions of the drops, and censoring times are the x-positions of the ticks. Their precision is limited to the figure's coordinates (about 1e-5 months or better).
- If the plotting software rounded or jittered times, the originals cannot be recovered.
- A censoring at exactly the same time as an event, or two censorings drawn at one x position, cannot be told apart in the figure. However, the tick count closes the arm totals exactly, which argues against hidden overlapping ticks.
- No sensitivity allocation was run. The vector data, exact closure and exact risk-table agreement leave no materially different feasible allocation, so a single alternative would not add information. This is not a claim of unique recovery of the original data.

## Supporting files
`curve_vertices_{A,B}.csv`, `drops_{A,B}.csv` (includes n_risk and the raw d for each drop), `censor_ticks_{A,B}.csv`, and `extraction_summary.json`.
- `fig_render.png`, a 150-dpi render of the input, and `overlay.png`, the KM recomputed from `ipd.csv` drawn as dashed lines over the render. The two coincide along both arms, from the origin through the tail.
