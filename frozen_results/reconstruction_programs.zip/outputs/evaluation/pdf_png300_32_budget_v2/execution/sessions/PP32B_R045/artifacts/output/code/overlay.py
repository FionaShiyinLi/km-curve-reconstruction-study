"""Overlay reconstructed KM (from committed CSV) on the source figure, plus residuals over all measured steps."""
import json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
from check import km, S_at
meas = json.load(open('../measurements/measurements.json')); df = pd.read_csv('../ipd.csv')
im = Image.open('../../../input/figure.png'); fig, ax = plt.subplots(figsize=(12, 9)); ax.imshow(im)
X = lambda t: 269.5 + 40 * t; Y = lambda s: 929.5 - 750 * s
summ = {}
for arm, col in [('A', 'k'), ('B', 'm')]:
    g = df[df.group == arm]; c = km(g); ts = [0] + [u for u, _, _ in c] + [g.observed_time.max()]
    ss = [1] + [v for _, v, _ in c] + [c[-1][1]]
    ax.step([X(t) for t in ts], [Y(s) for s in ss], where='post', color=col, lw=0.7)
    r = [S_at(c, (s['t0'] + s['t1']) / 2) - s['S'] for s in meas[arm]['steps']]
    summ[arm] = dict(n_steps=len(r), max_abs=round(float(np.max(np.abs(r))), 4), mean_abs=round(float(np.mean(np.abs(r))), 4))
ax.set_xlim(250, 1730); ax.set_ylim(950, 160); fig.savefig('../measurements/overlay.png', dpi=110, bbox_inches='tight')
j = json.load(open('../checks.json')); j['all_step_residual_summary'] = summ; json.dump(j, open('../checks.json', 'w'), indent=1)
print(summ)
