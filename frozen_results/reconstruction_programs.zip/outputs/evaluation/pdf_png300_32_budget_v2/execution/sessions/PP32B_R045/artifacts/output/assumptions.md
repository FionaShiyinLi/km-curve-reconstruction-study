# Reconstruction assumptions (groups A and B, n = 100 each, time in months)

**Inputs used:** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (group sizes, time unit, seed 459003088). The manifest gives no event totals. That means no event-total constraint was available. It does not mean zero events. No other information was used.

**Calibration** (`code/measure.py`): I fitted linear maps to the black axis tick marks: x = 0,6,...,36 at px 269.5...1709.5 (40 px/month), and S = 1.0...0 at px 179.5...929.5 (750 px/unit). Residuals at the ticks are 0. The curve level is the centre of the 4-px horizontal stroke. No global rescaling or running-minimum correction was applied. The first horizontal level of each arm lies below 1 (A 0.990, B 0.960 after short early drops). I kept these as genuine early drops from S = 1. I did not normalize them away.

**Curve measurement:** I classified pixels as blue (A) or orange (B). Horizontal stroke pixels are those colored across a 7-px window. Segments are grouped at 1-px level tolerance and kept as a monotone chain. A drop is placed at the centre of the vertical stroke joining two levels. B is drawn over A, so partially covered A strokes were located from their visible edge. Two A drops (about 6.3 and 8.6 mo) are fully hidden behind B for 18 and 11 px. Where more than one event is inferred there, the events are spread evenly across the hidden gap (assumption). A's vertical line to S = 0 at 35.79 mo is read as its final event time. B's line ends at 33.86 mo with a censor mark.

**Censor marks:** A mark is a vertical run of at least 2 px extending at least 5 px both above and below the line. One-px columns are joins between drop strokes, not marks. I checked this by eye on crops (`measurements/crop_A_early.png`). A mark at A 0.39 mo coincides with a drop and was kept. Mark multiplicity is ambiguous: a run wider than about 3 px was counted as round(width/3) marks (e.g. B 24.2 and 30.2 mo). This shows that a mark is visible. It does not establish how many censorings it represents.

**Algorithm** (`code/reconstruct.py`, my own implementation of Guyot-style interval logic): the intervals are the risk-table times 0,6,...,36. The displayed at-risk counts are A 100,67,42,23,17,9,0 and B 100,66,50,43,37,13,0. I read them from the printed table and consider them unambiguous. Within each interval the steps are:
1. Place the censorings at the visible marks.
2. Walk through the drops in time order. At each drop, d = round(n_risk x (1 - S_measured_after / S_reconstructed_before)), with d >= 1 because a drawn drop implies at least one event, and d = n_risk for a drop to 0. The estimate of d is not fixed at 1. Rounding against the reconstructed cumulative S avoids drift.
3. Set censorings = n_start - n_next - events, and iterate until the counts are consistent.
4. Assign censorings beyond the visible marks and their width-based multiplicity uniformly across the interval (primary assumption). Censorings are capped at the arm's last displayed time.

Ties are handled with events before censorings. Censorings needed beyond visible marks: A 1 (in [0,6)), B 5 in [24,30) and 3 in [30,36). The code is deterministic; the seed is set anyway.

**Result:** A has 80 events and 20 censorings, and B has 58 events and 42 censorings. These totals come from the reconstruction. They are not supplied values.

**Checks** (`code/check.py`, `code/overlay.py` → `checks.json`, `measurements/overlay.png`): the checks reload the committed CSV and compute the right-continuous KM curve.
- All 7 risk-table counts match exactly in both arms (n with observed_time >= t). This is by construction, so it confirms internal consistency, not accuracy.
- The KM curve was compared with the measured level at the midpoint of every measured step, including the tails. Maximum absolute residuals are 0.0016 (A, 53 steps) and 0.0032 (B, 37 steps). All sampled checks pass at a tolerance of 0.004 (3 px) plus half of one event's KM step.
- The tail checks pass: A ends with an event at 35.79 mo, and B's last record is a censoring at 33.86 mo with S = 0.307 against 0.304 measured.

**Sensitivity** (`sensitivity.csv`, one alternative): censorings beyond the visible marks are placed on the existing marks (multiplicity) instead of uniformly. At the common supported horizon of 33.86 mo:

| Arm | S(33.86), primary | S(33.86), alternative | RMST, primary (mo) | RMST, alternative (mo) |
|---|---|---|---|---|
| A | 0.176 | 0.176 | 13.66 | 13.64 |
| B | 0.307 | 0.285 | 18.16 | 18.11 |

For B, the alternative leaves fewer at risk at the 32.6-mo drop, so it fits the measured final level (0.304) less well. This single alternative is not an uncertainty bound.

**Limitations:**
- Censoring times within an interval are identified only as far as marks are visible.
- Hidden or coincident censorings, and events hidden behind the other curve, are allocated by assumption.
- Drops closer together than about 7 px may be merged into tied events.
- The records are one feasible approximation. They are not a unique recovery of the original data.
