import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
H,W,_=im.shape
blk=(im.sum(2)<150)
# axis lines
rows=blk.sum(1); cols=blk.sum(0)
print('rows with most black',np.argsort(rows)[-5:],rows[np.argsort(rows)[-5:]])
print('cols with most black',np.argsort(cols)[-5:],cols[np.argsort(cols)[-5:]])
from collections import Counter
cnt=Counter(map(tuple,im.reshape(-1,3)))
print([c for c in cnt.most_common(12)])
