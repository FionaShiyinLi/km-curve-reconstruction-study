"""Reload committed CSV, recompute right-continuous KM, compare with measurements and risk table.
Usage: python3 check.py [ipd.csv] [measurements.json] [checks.json] [sensitivity.csv]"""
import sys, json, hashlib, os, numpy as np, pandas as pd
csv = sys.argv[1] if len(sys.argv) > 1 else '../ipd.csv'
mf = sys.argv[2] if len(sys.argv) > 2 else '../measurements/measurements.json'
outj = sys.argv[3] if len(sys.argv) > 3 else '../checks.json'
sens = sys.argv[4] if len(sys.argv) > 4 else '../sensitivity.csv'
meas = json.load(open(mf))
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [100, 67, 42, 23, 17, 9, 0], 'B': [100, 66, 50, 43, 37, 13, 0]}
def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; out.append((u, S, n))
    return out
def S_at(curve, x):  # right-continuous step
    s = 1.0
    for u, v, _ in curve:
        if u <= x: s = v
        else: break
    return s
def n_at(curve, x, df):
    return int((df.observed_time.values >= x).sum())
def rmst(curve, tau):
    grid = [0] + [u for u, _, _ in curve if u < tau] + [tau]; a = 0.0
    for i in range(len(grid) - 1): a += S_at(curve, grid[i]) * (grid[i + 1] - grid[i])
    return a
df = pd.read_csv(csv)
sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
res = dict(csv=os.path.basename(csv), sha256=sha, arms={})
res['tolerance_note'] = ('S tolerance = 0.004 (3 px line-centre reading incl. antialiasing/occlusion) + half of one-event '
                         'KM step S/(2 n_risk), because integer events cannot match an arbitrary measured level more closely. '
                         'Risk counts: exact match required (n with observed_time >= t).')
for arm in ['A', 'B']:
    g = df[df.group == arm]; c = km(g); a = {}
    a['n'] = int(len(g)); a['n_expected'] = 100; a['n_pass'] = bool(len(g) == 100)
    a['event_integer_pass'] = bool(g.event.isin([0, 1]).all()); a['events_total'] = int(g.event.sum())
    a['supplied_event_total'] = 'unavailable (not in manifest)'
    a['time_finite_nonneg'] = bool(np.isfinite(g.observed_time).all() and (g.observed_time >= 0).all())
    rk = []
    for t, n in zip(RT_T, RT[arm]):
        m = n_at(c, t, g); rk.append(dict(t=t, displayed=n, reconstructed=m, resid=m - n, status='pass' if m == n else 'fail'))
    a['risk_table'] = rk
    sc = []
    steps = meas[arm]['steps']
    idx = sorted(set(list(range(0, len(steps), max(1, len(steps) // 12))) + [len(steps) - 2, len(steps) - 1]))
    for i in idx:
        s = steps[i]; tm = (s['t0'] + s['t1']) / 2
        r = S_at(c, tm); n = n_at(c, tm, g)
        tol = 0.004 + (r / (2 * n) if n > 0 else 0)
        sc.append(dict(t=round(tm, 3), measured=round(s['S'], 4), reconstructed=round(r, 4),
                       resid=round(r - s['S'], 4), tol=round(tol, 4), status='pass' if abs(r - s['S']) <= tol else 'fail'))
    a['survival_checks'] = sc
    end = meas[arm]['end']
    a['tail'] = dict(measured_last_time=round(end['t_end'], 3), reconstructed_max_time=float(g.observed_time.max()),
                     measured_final_S=round(end['S_end'], 4), drop_to_zero=end.get('drop_to_zero', False),
                     reconstructed_S_at_max=round(S_at(c, g.observed_time.max()), 4))
    res['arms'][arm] = a
    print(arm, a['n'], a['events_total'], [r['status'] for r in rk].count('pass'), 'risk pass;',
          sum(x['status'] == 'pass' for x in sc), '/', len(sc), 'S pass; max|res|', max(abs(x['resid']) for x in sc))
    for x in sc:
        if x['status'] != 'pass': print('  FAIL', x)
# sensitivity comparison
if os.path.exists(sens):
    sd = pd.read_csv(sens); H = round(min(meas['A']['end']['t_end'], meas['B']['end']['t_end']), 2)
    comp = dict(horizon=H, note='common supported horizon = end of shorter displayed curve (B)')
    for arm in ['A', 'B']:
        c1 = km(df[df.group == arm]); c2 = km(sd[sd.group == arm])
        comp[arm] = dict(S_primary=round(S_at(c1, H), 4), S_sensitivity=round(S_at(c2, H), 4),
                         RMST_primary=round(rmst(c1, H), 3), RMST_sensitivity=round(rmst(c2, H), 3),
                         sensitivity_sha256=hashlib.sha256(open(sens, 'rb').read()).hexdigest())
    res['sensitivity'] = comp; print(comp)
json.dump(res, open(outj, 'w'), indent=1)
