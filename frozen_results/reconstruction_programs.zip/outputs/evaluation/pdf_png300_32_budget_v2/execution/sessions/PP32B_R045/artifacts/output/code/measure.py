"""Pixel measurement of the KM figure. Usage: python3 measure.py [path/to/figure.png] [outdir]
Calibration: axis ticks found in probe (x: 0->269.5 px, 36->1709.5 px; y: 1.0->179.5 px, 0->929.5 px),
re-derived here from black tick marks."""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../../../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else '../measurements'
import os; os.makedirs(out, exist_ok=True)
im = np.asarray(Image.open(fig).convert('RGB')).astype(int)
r, g, b = im[..., 0], im[..., 1], im[..., 2]
blk = im.sum(2) < 200

# --- calibration from axis tick marks ---
def runs(idx):
    idx = list(idx); res = []; s = p = None
    for i in idx:
        if s is None: s = p = i
        elif i == p + 1: p = i
        else: res.append((s, p)); s = p = i
    if s is not None: res.append((s, p))
    return res
xt = [(a + c) / 2 for a, c in runs(np.where(blk[935, 250:1750])[0] + 250)]
yt = [(a + c) / 2 for a, c in runs(np.where(blk[150:950, 262])[0] + 150)]
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
xa = np.polyfit(xt, [0, 6, 12, 18, 24, 30, 36], 1)
ya = np.polyfit(yt, [1.0, 0.8, 0.6, 0.4, 0.2, 0.0], 1)
xres = np.polyval(xa, xt) - np.array([0, 6, 12, 18, 24, 30, 36])
yres = np.polyval(ya, yt) - np.array([1, .8, .6, .4, .2, 0])
T = lambda x: float(np.polyval(xa, x)); S = lambda y: float(np.polyval(ya, y))
calib = dict(x_ticks_px=xt, y_ticks_px=yt, x_fit=list(xa), y_fit=list(ya),
             x_resid_max=float(abs(xres).max()), y_resid_max=float(abs(yres).max()))
X0, X1 = int(round(xt[0])), int(round(xt[-1])) + 3
YTOP, YBOT = 170, 932

masks = {'A': (b - r > 60) & (b > 120), 'B': (r - b > 100) & (r > 180) & (g > 60) & (g < 200)}
res = {'calibration': calib}
for arm, M in masks.items():
    other = masks['B' if arm == 'A' else 'A']
    U = M | other   # union used to recover partially occluded line edges
    # horizontal pixels: colored in 7-px window
    Hm = np.zeros_like(M)
    for x in range(X0, X1):
        Hm[:, x] = M[:, x - 3:x + 4].all(1)
    levels = {}
    for x in range(X0, X1):
        ys = np.where(Hm[YTOP:YBOT, x])[0] + YTOP
        rr = runs(ys)
        cs = []
        for a, c in rr:
            L = c - a + 1
            if L >= 4: cs.append((a + c) / 2 if L <= 5 else None)
            else:
                # partially occluded by the other arm: use the visible edge
                if U[a - 1, x] and not M[a - 1, x]: cs.append(c - 1.5)
                elif U[c + 1, x] and not M[c + 1, x]: cs.append(a + 1.5)
                elif L >= 2: cs.append(None)
        cs = [v for v in cs if v is not None]
        if cs: levels[x] = cs
    # build segments: consecutive columns sharing a level (tolerance 1 px)
    segs = []
    for x in sorted(levels):
        for y in levels[x]:
            for s in segs:
                if s['x1'] >= x - 1 and s['x1'] < x and abs(s['y'] - y) <= 1.0:
                    s['x1'] = x; s['ys'].append(y); break
            else:
                segs.append(dict(x0=x, x1=x, ys=[y], y=y))
            # running level
            for s in segs:
                if s['x1'] == x: s['y'] = float(np.median(s['ys']))
    segs = [s for s in segs if s['x1'] - s['x0'] >= 2]
    segs.sort(key=lambda s: s['x0'])
    # keep a monotone chain (y non-decreasing in pixel = S non-increasing)
    chain = []
    for s in segs:
        if chain and s['y'] < chain[-1]['y'] - 1.0:
            continue  # spurious (e.g. legend or other artefact above the curve)
        if chain and abs(s['y'] - chain[-1]['y']) <= 1.0:
            chain[-1]['x1'] = max(chain[-1]['x1'], s['x1']); chain[-1]['ys'] += s['ys']; continue
        chain.append(s)
    # horizontal line pixels span x0-3..x1+3 in the actual image; vertical drop line is 4 px wide
    steps = []
    for s in chain:
        steps.append(dict(t0=T(s['x0'] - 3), t1=T(s['x1'] + 3), x0=s['x0'] - 3, x1=s['x1'] + 3,
                          y=float(np.median(s['ys'])), S=S(float(np.median(s['ys'])))))
    drops = []
    for i in range(1, len(steps)):
        a, c = steps[i - 1], steps[i]
        gap = c['x0'] - a['x1']
        # drop location: centre of vertical stroke joining the two levels
        xs = [x for x in range(int(a['x1']) - 4, int(c['x0']) + 5)
              if M[int(a['y']) + 3:int(c['y']) - 2, x].all()] if c['y'] - a['y'] > 6 else []
        xd = (np.mean(xs) if xs else (a['x1'] + c['x0']) / 2)
        drops.append(dict(t=T(xd + 0.5 - 0.5), S_before=a['S'], S_after=c['S'], gap_px=int(gap),
                          occluded=bool(gap > 8)))
    # final drop to zero?
    last = steps[-1]
    xe = int(last['x1'])
    colbot = [x for x in range(xe - 6, xe + 6) if M[920:928, x].all()]
    end = dict(t_end=T(last['x1']), S_end=last['S'])
    if colbot:
        drops.append(dict(t=T(np.mean(colbot)), S_before=last['S'], S_after=0.0, gap_px=0, occluded=False))
        end['drop_to_zero'] = True
    # censor ticks: colored pixels 3..6 px above and below the line top/bottom within a step
    ticks = []
    for s in steps:
        yc = s['y']; top = int(round(yc - 1.5)); bot = int(round(yc + 1.5))
        cols = [x for x in range(int(s['x0']), int(s['x1']) + 1)
                if M[top - 6:top - 1, x].all() and M[bot + 2:bot + 7, x].all()]
        for a, c in runs(cols):
            w = c - a + 1
            if w < 2: continue  # 1-px columns are drop-stroke joins, not censor marks
            ticks.append(dict(t=T((a + c) / 2 + 0.5), width_px=int(w), S=s['S'],
                              est_marks=int(max(1, round(w / 3.0)))))
    res[arm] = dict(steps=steps, drops=drops, ticks=ticks, end=end)
    print(arm, 'steps', len(steps), 'drops', len(drops), 'ticks', len(ticks),
          'occluded gaps', [(round(d['t'], 2), d['gap_px']) for d in drops if d['occluded']])
    print('  first steps', [(round(s['t0'], 2), round(s['t1'], 2), round(s['S'], 4)) for s in steps[:4]])
    print('  end', end)
    print('  ticks', [(round(t['t'], 2), t['width_px']) for t in ticks])
json.dump(res, open(os.path.join(out, 'measurements.json'), 'w'), indent=1)
print(calib)
