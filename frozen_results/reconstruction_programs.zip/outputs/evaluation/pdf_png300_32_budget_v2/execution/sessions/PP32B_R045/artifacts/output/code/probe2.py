import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
blk=(im.sum(2)<200)
print('xticks below axis row 935:',np.where(blk[935,:])[0])
print('yticks left of axis col 262:',np.where(blk[:,262])[0])
r,g,b=im[...,0],im[...,1],im[...,2]
B=(b-r>60)&(b>120)
O=(r-b>100)&(r>180)&(g>60)&(g<200)
for name,M in [('A',B),('B',O)]:
  print(name,'col1500 rows',np.where(M[:,1500])[0] if name=='A' else np.where(M[:,1450])[0])
  # region near a tick: A tick ~ x=1413 at y~798
  sub=M[780:815,1405:1425] if name=='A' else M[630:660,1370:1395]
  for row in sub: print(''.join('#' if v else '.' for v in row))
