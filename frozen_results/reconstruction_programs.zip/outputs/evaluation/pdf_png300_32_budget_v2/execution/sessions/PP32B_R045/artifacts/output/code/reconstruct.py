"""KM -> approximate IPD reconstruction (own implementation, Guyot-style interval logic).
Usage: python3 reconstruct.py [measurements.json] [out.csv] [extras_mode: uniform|ticks]
Seed 459003088 is set for reproducibility although the algorithm is deterministic."""
import sys, json, os, tempfile, numpy as np
np.random.seed(459003088)
mfile = sys.argv[1] if len(sys.argv) > 1 else '../measurements/measurements.json'
outcsv = sys.argv[2] if len(sys.argv) > 2 else '../ipd.csv'
mode = sys.argv[3] if len(sys.argv) > 3 else 'uniform'
meas = json.load(open(mfile))
# Risk table read from the figure (numbers printed below the axis)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [100, 67, 42, 23, 17, 9, 0], 'B': [100, 66, 50, 43, 37, 13, 0]}
N = {'A': 100, 'B': 100}
log = {}

def build_arm(arm):
    m = meas[arm]; steps = m['steps']
    drops = [dict(d) for d in m['drops']]
    if steps[0]['S'] < 0.998:           # genuine early drop from S=1 (first horizontal level below 1)
        drops.insert(0, dict(t=max(0.0, steps[0]['t0']), S_before=1.0, S_after=steps[0]['S'],
                             gap_px=0, occluded=False))
    t_end = m['end']['t_end']
    ticks = m['ticks']
    rows = []; notes = []
    S_hat = 1.0
    n_rt = RT[arm]
    for k in range(len(RT_T) - 1):
        a, b = RT_T[k], RT_T[k + 1]
        n0, n1 = n_rt[k], n_rt[k + 1]
        dk = [d for d in drops if a <= d['t'] < b]
        tk = [t for t in ticks if a <= t['t'] < b]
        G = len(tk)
        c = sum(t['est_marks'] for t in tk)
        for it in range(50):
            # allocate c censoring times
            cens = []
            if c >= G:
                base = [t['t'] for t in tk]
                extra = c - G
                # visible multi-mark width evidence first
                for t in tk:
                    add = min(extra, t['est_marks'] - 1)
                    base += [t['t']] * add; extra -= add
                if extra > 0:
                    hi = min(b, t_end)
                    if mode == 'ticks' and tk:
                        for i in range(extra): base.append(tk[i % G]['t'])
                    else:
                        base += list(a + (hi - a) * (np.arange(extra) + 0.5) / extra)
                cens = sorted(base)
            else:
                # fewer censorings allowed than visible ticks: keep the widest/most distinct ticks
                keep = sorted(tk, key=lambda t: -t['width_px'])[:max(c, 0)]
                cens = sorted(t['t'] for t in keep)
            # simulate
            n = n0; S = S_hat; ev = []; ci = 0
            for d in dk:
                while ci < len(cens) and cens[ci] < d['t']:
                    n -= 1; ci += 1
                if n <= 0: break
                if d['S_after'] <= 1e-9:
                    dd = n
                else:
                    dd = int(round(n * (1 - d['S_after'] / S)))
                    dd = min(max(dd, 1), n)
                ev.append((d, dd)); S *= (1 - dd / n); n -= dd
            D = sum(x[1] for x in ev)
            c_new = n0 - n1 - D
            if c_new == c: break
            c = max(c_new, 0) if c_new >= 0 else c_new
            if c_new < 0:
                notes.append(f'[{a},{b}) events {D} exceed risk-table decline {n0-n1}')
                c = 0; break
        if c < G:
            notes.append(f'[{a},{b}) {G} visible ticks but only {c} censorings admissible')
        if n0 - n1 - D - len(cens) != 0:
            notes.append(f'[{a},{b}) unreconciled: n0-n1={n0-n1}, events={D}, cens={len(cens)}')
        for d, dd in ev:
            if d.get('occluded') and dd > 1:
                # drop hidden behind the other arm: spread events across occluded gap
                w = d['gap_px'] * 0.025
                for i in range(dd): rows.append((arm, d['t'] - w / 2 + w * (i + 0.5) / dd, 1))
            else:
                rows += [(arm, d['t'], 1)] * dd
        rows += [(arm, t, 0) for t in cens]
        S_hat = S
        log.setdefault(arm, []).append(dict(interval=[a, b], n_start=n0, n_next=n1, events=D,
                                            censored=len(cens), visible_tick_groups=G))
    assert len(rows) == N[arm], (arm, len(rows))
    return rows, notes

allrows = []; allnotes = {}
for arm in ['A', 'B']:
    r, nt = build_arm(arm)
    allrows += r; allnotes[arm] = nt
import pandas as pd
df = pd.DataFrame(allrows, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].clip(lower=0).round(4)
df = df.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
d = os.path.dirname(os.path.abspath(outcsv)); fd, tmp = tempfile.mkstemp(dir=d, suffix='.tmp')
os.close(fd); df.to_csv(tmp, index=False); os.replace(tmp, outcsv)
json.dump(dict(mode=mode, intervals=log, notes=allnotes),
          open(os.path.splitext(outcsv)[0] + '_reconlog.json', 'w'), indent=1)
print(json.dumps(dict(intervals=log, notes=allnotes), indent=0)[:3000])
