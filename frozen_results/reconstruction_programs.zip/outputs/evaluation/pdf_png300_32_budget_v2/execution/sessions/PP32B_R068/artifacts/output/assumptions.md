# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (1800×1350 raster) and `../input/manifest.json` (n = 1000 per arm, months, seed 1456377914). The number-at-risk table was read by eye from the figure at 0, 6, …, 36 months: A 1000/699/488/336/233/85/0, B 1000/746/559/422/308/114/0. The manifest gives no arm-specific event totals, so there was no event-total constraint (recorded as unavailable in `checks.json`). No other auxiliary information was used.

**Code:** `code/reconstruct.py` does the measurement and reconstruction. `code/checks.py` reloads the committed CSV and runs the verification. Run both from the work directory; paths can be changed with `--input` / `--out`. The algorithm is deterministic. The seed is set but no random draws are made. The sensitivity file was made with `reconstruct.py --censor-mode uniform --csv-name sensitivity.csv`.

## Measurement
- **Calibration:** taken from the labelled axis ticks, which are 2-px pairs. t = 0 is at x = 270.0 and t = 36 at x = 1710.0 (40 px/month). S = 1 is at y = 180.0 and S = 0 at y = 930.0 (750 px per unit). One pixel is 0.025 months or 0.00133 in S. There is no antialiasing, and the arms are pure RGB (31,119,180) for A and (255,127,14) for B. No global transform or rescaling was applied.
- **Curve level per column:** the curve line is 4 px thick, so the level is the bottom edge of the lowest colour run minus 2 px. Censor ticks are 17 px tall and 3 px wide. A column is classified as a tick when the run is tick-height and either sticks up above the preceding line, sits next to another tick column, or is followed by a higher plain level (a tick on a drop). For tick columns the level is the tick centre. Merged tick clusters taller than 18 px are left unmeasured and interpolated.
- **Occlusion:** each arm's pixels can be hidden by the other arm (mainly in the first ~2 months), and at t = 0 by the axis. Own-colour runs that touch the other colour are marked unreliable and filled by linear interpolation between reliable neighbours (`filled` column in `work/measured_*.csv`). Leading hidden columns are anchored at S = 1, because B's own pixels on the S = 1 row just to the right of the axis confirm the start there. The early drops (about 0.7% in the first 0.1 months) are genuine and were kept. I did not use a running minimum. The remaining upward jitter is ≤ 1.5 px.
- **Start of arm A:** A has a tick-shaped mark at t ≈ 0. It was treated as a censor tick, which gives one censoring at t = 0.0375.

## Reconstruction algorithm (own implementation, Guyot-style interval logic)
Each risk-table interval [T_k, T_k+1) is processed separately. For a trial number c of censorings in the interval:
- The c censorings are allocated to columns in proportion to detected tick coverage. Columns hidden by the other arm get the interval's visible tick density.
- The columns are then walked in order. At each column the number of events is d = round(n_risk·(1 − S_meas/Ŝ_prev)), where Ŝ is the *reconstructed* KM so far, so rounding errors correct themselves. Events are placed before censorings at the same time.
- c is chosen so that the reconstructed number at risk at T_k+1 equals the table value.

A visible drop can therefore contain several events. The value d = 1 is never assumed; d comes from the drop size relative to n_risk. Event times are column time plus 2 px, because a vertical segment starts half a line-width before the event time. Censoring times are column centres.

Tick visibility is not the same as tick multiplicity. Overlapping ticks cannot be counted, so tick positions only set *where* censorings go. The risk table sets *how many*. In the final interval, n = 0 at 36 forces everyone to have left before 36. Leftover participants are censored at the last tick column, t = 35.9875; none are placed at 36.

## Result and checks (`checks.json`, CSV SHA-256 f562dfaf…7810)
- **Records:** A has 770 events and 230 censorings. B has 685 events and 315 censorings. Every risk-table count matches exactly, counting records with observed_time ≥ t.
- **KM vs measured curve:** the right-continuous KM recomputed from the saved CSV was compared with the measured curve at 20 times from 0.5 to 35.9 months. All are within the tolerance of 0.006 (about 4.5 px: line width, 1–2 px reading error, and tail event granularity of ~0.004–0.005).
- **Every column:** mean absolute residual is 0.0014 (A) and 0.0015 (B). Maximum is 0.011 and 0.0095. Those maxima occur in single drop columns where the reconstruction's timing is 1–2 px (≤ 0.05 months) off.
- **Tail of B:** the reconstruction ends at S = 0.202 against a measured 0.207 (residual −0.005, about one event at n ≈ 40). It passes the tolerance but is the largest systematic tail difference.

## Limitations
- Censoring counts per interval are identified only through the risk table. Where they fall within an interval depends on how visible the ticks are, and some ticks are hidden under the other arm early on. The flat tails do not identify follow-up beyond the last tick.
- Event times have column resolution (0.025 months), and ties are artefacts of that resolution.
- At n ≈ 1000, one event is smaller than one pixel (0.75 px), so the exact early event counts per column are not recoverable. Only their cumulative total is constrained, to within about 1–2 events.
- This reconstruction is feasible, not unique. No uncertainty bound is claimed.

## Sensitivity (one alternative, `sensitivity.csv`)
The alternative assumption is that censorings are spread uniformly over the columns of each interval, ignoring tick positions. Same-horizon comparison at the common supported horizon of 35.9 months:
- **Arm A:** S(35.9) is 0.1529 primary vs 0.1543 alternative. RMST(35.9) is 15.599 vs 15.598 months. Events are 770 vs 771.
- **Arm B:** S(35.9) is 0.2023 vs 0.2052. RMST is 18.233 vs 18.237. Events are 685 vs 687.

This is a single alternative. It is not a confidence interval and not a bound on reconstruction error. The primary allocation was chosen because it uses the observed tick positions, not because of any treatment contrast.
