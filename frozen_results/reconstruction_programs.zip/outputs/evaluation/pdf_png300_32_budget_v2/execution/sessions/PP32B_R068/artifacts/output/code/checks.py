#!/usr/bin/env python3
"""Reload committed IPD, recompute right-continuous KM, compare with measurements
and risk table; write output/checks.json (and sensitivity comparison if present).
Usage: python checks.py [--out output]"""
import argparse, hashlib, json, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 699, 488, 336, 233, 85, 0], "B": [1000, 746, 559, 422, 308, 114, 0]}
CHECK_T = [0.5, 1, 2, 3, 4.5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.5, 35.9]
TOL = 0.006   # ~4.5 px: 4-px line + ~1 px reading error, plus integer-event granularity
HORIZON = 35.9

def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append((u, S))
    return np.array(out)

def S_at(kmt, x):   # right-continuous step function
    i = np.searchsorted(kmt[:, 0], x, side="right") - 1
    return 1.0 if i < 0 else float(kmt[i, 1])

def rmst(kmt, tau):
    ts = np.r_[0, kmt[:, 0][kmt[:, 0] < tau], tau]
    ss = np.r_[1, kmt[:, 1][kmt[:, 0] < tau]]
    return float(np.sum(np.diff(ts) * ss))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="output")
    o = ap.parse_args().out
    path = os.path.join(o, "ipd.csv")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    df = pd.read_csv(path)
    res = {"csv": "ipd.csv", "sha256": sha, "columns": list(df.columns),
           "km_tolerance": TOL, "tolerance_justification":
           "line 4 px (1 px = 0.00133 S); reading error ~1-2 px; integer event steps "
           "reach ~0.004-0.005 near the tail (n_risk ~40-50)", "groups": {}}
    fig, ax = plt.subplots(figsize=(9, 6))
    for g in ["A", "B"]:
        d = df[df.group == g]; m = pd.read_csv(os.path.join(o, "work", f"measured_{g}.csv"))
        k = km(d); gr = {"n": int(len(d)), "n_expected": RISK[g][0],
                         "n_pass": bool(len(d) == RISK[g][0]),
                         "event_values_ok": bool(set(d.event.unique()) <= {0, 1}),
                         "times_finite_nonneg": bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                         "events": int(d.event.sum()), "censored": int((d.event == 0).sum()),
                         "supplied_event_total": "unavailable (not in manifest)"}
        rows = []
        for t in CHECK_T:
            j = int(np.argmin(np.abs(m.t_col.values - t)))
            sm = float(m.S.values[j]); sr = S_at(k, t)
            rows.append(dict(t=t, measured=round(sm, 4), measured_filled=bool(m.filled.values[j]),
                             reconstructed=round(sr, 4), residual=round(sr - sm, 4),
                             status="pass" if abs(sr - sm) <= TOL else "fail"))
        gr["km_vs_measured"] = rows
        # dense summary over every column
        rec = np.array([S_at(k, t) for t in m.t_col.values]); r = rec - m.S.values
        gr["all_columns_abs_residual"] = {"max": round(float(np.abs(r).max()), 4),
                                          "mean": round(float(np.abs(r).mean()), 5),
                                          "frac_within_tol": round(float((np.abs(r) <= TOL).mean()), 4)}
        rk = []
        for t, n_tab in zip(RISK_T, RISK[g]):
            n_rec = int((d.observed_time >= t).sum())
            rk.append(dict(t=t, table=n_tab, reconstructed=n_rec, residual=n_rec - n_tab,
                           status="pass" if n_rec == n_tab else "fail"))
        gr["risk_table"] = rk
        gr["max_time"] = float(d.observed_time.max())
        gr["last_event_time"] = float(d.observed_time[d.event == 1].max())
        res["groups"][g] = gr
        ax.plot(m.t_col, m.S, lw=3, alpha=.35, label=f"{g} measured")
        ax.step(np.r_[0, k[:, 0]], np.r_[1, k[:, 1]], where="post", lw=.8, label=f"{g} reconstructed KM")
    ax.legend(); ax.set_xlabel("months"); ax.set_ylabel("S(t)")
    fig.savefig(os.path.join(o, "work", "overlay.png"), dpi=110)
    sp = os.path.join(o, "sensitivity.csv")
    if os.path.exists(sp):
        s = pd.read_csv(sp); comp = {"horizon_months": HORIZON,
            "assumption": "censorings spread uniformly over columns within each risk-table interval (ignores tick positions)"}
        for g in ["A", "B"]:
            kp, ks = km(df[df.group == g]), km(s[s.group == g])
            comp[g] = {"S_primary": round(S_at(kp, HORIZON), 4), "S_sensitivity": round(S_at(ks, HORIZON), 4),
                       "S12_primary": round(S_at(kp, 12), 4), "S12_sensitivity": round(S_at(ks, 12), 4),
                       "RMST_primary": round(rmst(kp, HORIZON), 3), "RMST_sensitivity": round(rmst(ks, HORIZON), 3),
                       "events_primary": int(df[df.group == g].event.sum()),
                       "events_sensitivity": int(s[s.group == g].event.sum())}
        res["sensitivity"] = comp
    json.dump(res, open(os.path.join(o, "checks.json"), "w"), indent=1)
    for g in "AB":
        gr = res["groups"][g]
        print(g, gr["n"], gr["events"], gr["all_columns_abs_residual"],
              [r["status"] for r in gr["risk_table"]], [(r["t"], r["residual"]) for r in gr["km_vs_measured"] if r["status"] != "pass"])
    print(json.dumps(res.get("sensitivity"), indent=0))

if __name__ == "__main__":
    main()
