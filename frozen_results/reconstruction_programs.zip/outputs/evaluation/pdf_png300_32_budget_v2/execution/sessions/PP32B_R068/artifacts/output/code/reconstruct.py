#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation).

Usage: python reconstruct.py [--input DIR] [--out DIR] [--censor-mode ticks|uniform]
Defaults: input=../input (relative to the working directory), out=output.
Deterministic; the supplied seed is recorded and used for numpy's RNG, though no
random draws are required by the algorithm.
"""
import argparse, json, os, tempfile
import numpy as np, pandas as pd
from PIL import Image

SEED = 1456377914
COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}  # either may occlude the other
# Axis calibration from labelled tick marks (pixel rows/cols of 2-px-wide ticks;
# continuous coordinate = index + 0.5, so tick pair 269/270 -> 270.0).
X0, X36 = 270.0, 1710.0      # t = 0 and t = 36 months
Y1, Y0 = 180.0, 930.0        # S = 1.0 and S = 0.0
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [1000, 699, 488, 336, 233, 85, 0],
        "B": [1000, 746, 559, 422, 308, 114, 0]}
LINE_H, TICK_H = 4, 17        # measured line thickness and censor-tick height (px)

def t_of(xc): return (xc - X0) / (X36 - X0) * 36.0
def s_of(yc): return (Y0 - yc) / (Y0 - Y1)

def runs(idx):
    """contiguous runs in sorted index array -> list of (start, end_inclusive)"""
    if len(idx) == 0: return []
    br = np.where(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br + 1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st, en))

def measure(img, g):
    a = np.asarray(img.convert("RGB")).astype(int)
    own = np.all(a == COLORS[g], axis=2)
    other = np.all(a == COLORS["B" if g == "A" else "A"], axis=2)
    rows = []
    prev_top = Y1 - LINE_H / 2.0             # line top at S = 1
    for i in range(int(X0), int(X36)):          # columns with centre in [0,36)
        ys = np.where(own[150:940, i])[0] + 150
        occl = bool(other[150:940, i].any())
        rec = dict(col=i, t_col=t_of(i + 0.5), n_px=len(ys), occluded=occl,
                   tick=False, level_row=np.nan, reliable=False)
        if len(ys):
            rr = runs(ys)
            low = rr[-1]                           # lowest run = current level / tick
            h = low[1] - low[0] + 1
            rec["h"] = h
            # a censor tick protrudes ~6.5 px above the line top of the preceding
            # plain-line column; a pure drop segment does not
            if h >= TICK_H - 2 and low[0] < prev_top - 3:
                rec["tick"] = True
                if h <= TICK_H + 1:                # isolated tick: centre = level
                    rec["level_row"] = (low[1] + 1) - TICK_H / 2.0
                # merged ticks/drop (h > 18): level left NaN -> interpolated
            else:
                rec["level_row"] = (low[1] + 1) - LINE_H / 2.0
                prev_top = low[1] + 1 - LINE_H
            # own pixels touching the other arm's colour may be partially hidden
            if occl:
                nb = other[max(low[0] - 3, 0):low[1] + 4, i].any()
                rec["reliable"] = not nb
            else:
                rec["reliable"] = True
        rows.append(rec)
    m = pd.DataFrame(rows)
    m["S_raw"] = s_of(m["level_row"])
    # second pass: a tall run read as a drop, followed by a HIGHER plain level, is a
    # tick sitting on a drop (tick centre = new level); re-read it as a tick
    h = m["h"].fillna(0).values; S = m["S_raw"].values.copy(); tk = m["tick"].values.copy()
    for i in range(len(m) - 1):
        if not tk[i] and h[i] >= TICK_H - 2 and np.isfinite(S[i]):
            nxt = [S[j] for j in range(i + 1, min(i + 5, len(m))) if not tk[j] and np.isfinite(S[j])]
            if nxt and nxt[0] - S[i] > 0.004:
                tk[i] = True
                S[i] = S[i] + (TICK_H / 2.0 - LINE_H / 2.0) / (Y0 - Y1) if h[i] <= TICK_H + 1 else np.nan
    # third pass: a tick-height run adjacent to a detected tick column (ticks are
    # 3 px wide) is part of a tick cluster, not a drop segment
    for i in range(1, len(m) - 1):
        if not tk[i] and TICK_H - 2 <= h[i] <= TICK_H + 1 and (tk[i - 1] or tk[i + 1]):
            tk[i] = True
            S[i] = S[i] + (TICK_H / 2.0 - LINE_H / 2.0) / (Y0 - Y1)
    m["S_raw"] = S; m["tick"] = tk
    # fill unreliable/missing columns by carrying the next reliable level backward
    # (a hidden stretch of a step curve lies between the two visible levels; we use
    # linear interpolation in pixel space, flagged as occluded, not a running minimum)
    ok = m["reliable"] & m["S_raw"].notna()
    m["S"] = m["S_raw"].where(ok)
    # leading columns hidden by the other arm / y-axis: the curve starts at S = 1
    # (confirmed by own pixels at the S = 1 row just right of the axis); anchor only
    # the hidden leading columns locally, no global rescaling
    first = int(np.argmax(ok.values))
    if first > 0: m.loc[0, "S"] = 1.0
    m["S"] = m["S"].interpolate(limit_direction="both")
    m["filled"] = ~ok
    return m

def allocate(counts_total, w):
    w = np.asarray(w, float)
    if counts_total <= 0 or w.sum() <= 0: return np.zeros(len(w), int)
    cw = np.cumsum(w) / w.sum()
    r = np.round(counts_total * cw).astype(int)
    return np.diff(np.r_[0, r])

def run_interval(n0, S_hat0, Smeas, cens):
    """sequential KM tracking: events at each column chosen so the reconstructed
    KM tracks the measured level; censors (after events at a tie) as given."""
    n, S_hat = n0, S_hat0
    d_out = np.zeros(len(Smeas), int)
    for k, s in enumerate(Smeas):
        if n > 0 and S_hat > 0:
            d = int(np.round(n * (1.0 - s / S_hat)))
            d = min(max(d, 0), n)
            if d:
                S_hat *= (1 - d / n); n -= d; d_out[k] = d
        c = min(cens[k], n); cens[k] = c; n -= c
    return d_out, cens, n, S_hat

def reconstruct(m, g, mode):
    recs, diag = [], []
    n, S_hat = RISK[g][0], 1.0
    t_ev = t_of(m["col"].values + 2.0)   # drop starts ~2 px (half line) left of event
    t_ce = m["t_col"].values
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        sel = np.where((t_ce >= lo) & (t_ce < hi))[0]
        Smeas = m["S"].values[sel]
        if mode == "ticks":
            w = m["tick"].values[sel].astype(float)
            if True:   # ticks hidden under the other arm: give them the visible density
                hid = m["filled"].values[sel]
                vis = ~hid
                dens = w[vis].mean() if vis.any() else 0.0
                w = np.where(hid, dens, w)
            if w.sum() == 0: w = np.ones(len(sel))
        else:
            w = np.ones(len(sel))
        target = RISK[g][k + 1]
        best = None
        for c in range(0, n + 1):
            d, cs, n_end, Sh = run_interval(n, S_hat, Smeas, allocate(c, w))
            err = abs(n_end - target)
            if best is None or err < best[0]:
                best = (err, c, d, cs, n_end, Sh)
            if n_end < target - 2: break
        err, c, d, cs, n_end, Sh = best
        if hi == 36 and n_end > 0:          # nobody at risk at 36: censor leftovers
            j = np.where(w > 0)[0][-1]; cs[j] += n_end; n_end = 0
        for j, idx in enumerate(sel):
            te = min(t_ev[idx], hi - 1e-3)
            recs += [(g, round(te, 4), 1)] * int(d[j])
            recs += [(g, round(t_ce[idx], 4), 0)] * int(cs[j])
        diag.append(dict(group=g, interval=[lo, hi], n_start=int(n), events=int(d.sum()),
                         censored=int(cs.sum()), n_end_recon=int(n_end), n_end_table=target,
                         S_hat_end=Sh, S_meas_end=float(Smeas[-1])))
        n, S_hat = n_end, Sh
    return recs, diag

def atomic_csv(df, path):
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp"); os.close(fd)
    df.to_csv(tmp, index=False); os.replace(tmp, path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input")
    ap.add_argument("--out", default="output")
    ap.add_argument("--censor-mode", default="ticks", choices=["ticks", "uniform"])
    ap.add_argument("--csv-name", default="ipd.csv")
    a = ap.parse_args()
    np.random.seed(SEED)
    man = json.load(open(os.path.join(a.input, "manifest.json")))
    img = Image.open(os.path.join(a.input, "figure.png"))
    os.makedirs(os.path.join(a.out, "work"), exist_ok=True)
    allrecs, alldiag = [], []
    for g in ["A", "B"]:
        assert man["groups"][g] == RISK[g][0]
        m = measure(img, g)
        m.to_csv(os.path.join(a.out, "work", f"measured_{g}.csv"), index=False)
        recs, diag = reconstruct(m, g, a.censor_mode)
        assert len(recs) == man["groups"][g], (g, len(recs))
        allrecs += recs; alldiag += diag
    df = pd.DataFrame(allrecs, columns=["group", "observed_time", "event"])
    atomic_csv(df, os.path.join(a.out, a.csv_name))
    json.dump(alldiag, open(os.path.join(a.out, "work",
              f"interval_diag_{a.censor_mode}.json"), "w"), indent=1)
    print(pd.DataFrame(alldiag).to_string())

if __name__ == "__main__":
    main()
