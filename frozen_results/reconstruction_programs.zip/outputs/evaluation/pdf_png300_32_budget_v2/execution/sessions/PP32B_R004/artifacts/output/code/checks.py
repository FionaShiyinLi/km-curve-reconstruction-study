"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve & risk table."""
import sys, json, hashlib, os, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
csv = f'{out}/ipd.csv'; df = pd.read_csv(csv)
ex = json.load(open(f'{out}/extracted_curves.json'))
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [1000, 737, 506, 356, 236, 91, 0], 'B': [1000, 763, 580, 433, 314, 121, 0]}
def km(d):
    ts = np.sort(d.loc[d.event == 1, 'observed_time'].unique()); S = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        S *= 1 - e / n; out.append((t, S))
    return out
def at(curve, t):   # right-continuous step
    s = 1.0
    for tt, v in curve:
        if tt <= t: s = v
        else: break
    return s
def meas(steps, t):
    s = 1.0
    for tt, v in steps:
        if tt <= t: s = v
        else: break
    return s
TOL = 1e-6
res = {'csv_sha256': hashlib.sha256(open(csv, 'rb').read()).hexdigest(),
       'columns_ok': list(df.columns) == ['group', 'observed_time', 'event'],
       'event_integer_01': bool(df.event.isin([0, 1]).all()),
       'time_finite_nonneg': bool(np.isfinite(df.observed_time).all() and (df.observed_time >= 0).all()),
       'supplied_event_totals': 'unavailable (not in manifest)',
       'survival_tolerance': f'{TOL} (vector coordinates to 1e-4 pt => <=2.8e-7 in S)'}
for g in 'AB':
    d = df[df.group == g]; c = km(d); st = ex[g]['steps']
    probe = [0.01, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.9]
    # also just after a sample of drops, and just before
    rows = []
    for t in probe:
        m, r = meas(st, t), at(c, t)
        rows.append(dict(t=t, measured=m, reconstructed=r, residual=r - m, status='pass' if abs(r - m) <= TOL else 'fail'))
    allres = max(abs(at(c, t + 1e-7) - v) for t, v in st)  # 1e-7 mo offset absorbs CSV float round-trip (min drop gap 7.3e-5)
    risk = []
    for T, nr in zip(RT_T, RT[g]):
        k = int((d.observed_time >= T).sum())
        risk.append(dict(t=T, table=nr, reconstructed=k, residual=k - nr, status='pass' if k == nr else 'fail'))
    res[g] = dict(n=len(d), n_ok=len(d) == 1000, events=int(d.event.sum()), censored=int((d.event == 0).sum()),
                  max_time=float(d.observed_time.max()), curve_end_time=ex[g]['end_time'],
                  km_vs_measured=rows, max_abs_residual_all_step_levels=allres,
                  all_levels_status='pass' if allres <= TOL else 'fail', risk_table=risk)
    print(g, len(d), res[g]['events'], allres, [r['residual'] for r in risk])
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1, default=float)
print(res['csv_sha256'])
