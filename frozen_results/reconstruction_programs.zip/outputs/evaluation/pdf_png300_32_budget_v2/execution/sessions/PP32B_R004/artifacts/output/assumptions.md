# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf` (vector PDF) and `../input/manifest.json`: n = 1000 per arm, time in months, code seed 302434092.
- The number-at-risk table was read from the PDF text layer. Times are 0, 6, ..., 36. A: 1000, 737, 506, 356, 236, 91, 0. B: 1000, 763, 580, 433, 314, 121, 0.
- The manifest gives no arm-specific event totals, so no event-total check was possible (recorded as unavailable).

## Measurement
- The figure is vector graphics. Each arm is a single stroked path: blue (0.12, 0.47, 0.71) and orange (1.0, 0.50, 0.05). Legend line colors map blue to Group A and orange to Group B. Censor marks are separate vertical line segments, 4 pt long, in the arm color.
- Calibration uses the labelled axis tick segments: x = 64.8 pt is t = 0 and x = 410.4 pt is t = 36; y = 223.2 pt is S = 0 and y = 43.2 pt is S = 1. The calibration is linear with no correction or global rescaling. Both curves begin exactly at (0, 1), so no origin adjustment was needed.
- Step times come from the vertical segments of each path and levels from the horizontal segments. Coordinates are stored to about 1e-4 pt, which is at most 2.8e-7 in S. Extracted values are in `extracted_curves.json`.
- Tick counts: A has 245 tick objects at 245 distinct x positions, and B has 316 at 316. No tick is duplicated at the same x.

## Algorithm (`code/extract.py`, then `code/reconstruct.py`, then `code/checks.py`)
1. Walk forward through the drops, starting from n = 1000 and S = 1. At each drop, search over integer d (1-15) and integer censoring counts c since the previous drop, using S_new = S_model_prev * (1 - d/(n - c)). S_model is the exact product, so measurement error does not accumulate.
2. Among (d, c) pairs within the tolerance |S_new - S_measured| <= 1e-6, choose the one whose c is closest to the number of ticks in the interval. Tick counts are therefore a tie-breaker, not a hard constraint. If no pair met the tolerance, the pair with the smallest error would be used and flagged. This never happened.
3. Result: every drop fits with d = 1 (maximum error 2.78e-7). The inferred c equals the tick count in every interval (0 flags). Totals: A has 755 events and 245 censorings; B has 684 and 316.
   - d = 1 was not assumed. It was chosen because it reproduces the absolute S level at every drop, with n given by the tick-consistent censoring path.
   - A tied d > 1 would need a risk set inconsistent with the adjacent drops, unless the censoring counts deviate from the visible ticks. So the choice rests on the joint fit plus the tick counts, not on the ratio alone.
4. Censorings are placed at the exact x of their ticks. After the last drop, the remaining 26 (A) and 36 (B) participants are censored at the 26 and 36 ticks there. The last tick coincides with the end of the curve (35.97 and 35.96 months). No follow-up beyond the drawn curve was invented.
5. The code includes a risk-table split step for intervals containing a table time. It never had to override tick placement: all 14 readable counts reproduce exactly (at-risk = #{observed_time >= t}; no event/censor ties occur). The zero at 36 months is met because every record is ≤ 35.97.
6. The seed is recorded, but the algorithm is deterministic and uses no random draws.

## Checks (`checks.json`, regenerated from the final committed CSV)
- The CSV is reloaded, the right-continuous KM is recomputed, and it is compared with the measured step function at 18 probe times per arm (0.01 to 35.9 months, including the tail) and at every measured step level.
- Every step level matches within 2.8e-7. Step levels are evaluated at t + 1e-7 months, only to absorb a 1-ulp float round-trip in CSV I/O; the smallest gap between drops is 7.3e-5 months.
- An earlier draft rounded times to 6 decimals. That moved events past their drawn step times and was corrected; this was primary correction cycle 1. The same cycle added the float offset.
- Risk table: 14 of 14 exact. Arm sizes are 1000 and 1000, and event indicators are integer 0/1.

## Limitations
- Tick placement and tick count agree exactly, and the S levels are reproduced to coordinate precision. Still, recovery is exact only up to what the figure encodes:
  - Two censorings drawn at the same x would be indistinguishable from one. The S fit, though, independently implies exactly one censoring per tick in every interval.
  - Within-pixel ordering is taken from vector coordinates.
- Event totals were not supplied and could not be cross-checked.
- Sensitivity analysis was not run. The data did not leave a materially different feasible censor/event allocation: every alternative (d, c) either violates the S tolerance or contradicts the tick counts. Consequently `sensitivity.csv` was not produced. This is not a claim of zero reconstruction error.
