"""Extract KM step curves and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber, collections
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
COL = {(0.121569, 0.466667, 0.705882): 'A', (1.0, 0.498039, 0.054902): 'B'}  # legend lines
pg = pdfplumber.open(pdf).pages[0]
# axis calibration from labelled tick marks: x ticks 0..36 at 64.8..410.4, y ticks 0..1 at 223.2..43.2
ax = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
xt = sorted(l['pts'][0][0] for l in ax if abs(l['pts'][0][1]-l['pts'][1][1]) > 2 and l['pts'][1][1] > 224)
yt = sorted(l['pts'][0][1] for l in ax if abs(l['pts'][0][0]-l['pts'][1][0]) > 2 and l['pts'][0][0] < 63)
x0, x36 = xt[0], xt[-1]; ytop, ybot = yt[0], yt[-1]
tx = lambda x: (x - x0) / (x36 - x0) * 36.0
sy = lambda y: (ybot - y) / (ybot - ytop)
res = {'calibration': {'x_ticks_pt': xt, 'y_ticks_pt': yt, 'x0': x0, 'x36': x36, 'y1': ytop, 'y0': ybot}}
for c in pg.curves:
    g = COL[tuple(c['stroking_color'])]
    pts = c['pts']
    steps = [(tx(pts[0][0]), sy(pts[0][1]))]   # (time of level start, level)
    for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
        if abs(xa - xb) < 1e-9 and yb != ya:
            steps.append((tx(xa), sy(yb)))
    ticks = [l for l in pg.lines if l['linewidth'] == 0.65 and COL.get(tuple(l['stroking_color'])) == g]
    tk = [(tx(l['pts'][0][0]), sy((l['pts'][0][1] + l['pts'][1][1]) / 2)) for l in ticks]
    dup = collections.Counter(round(t, 6) for t, _ in tk)
    res[g] = {'steps': steps, 'end_time': tx(pts[-1][0]), 'ticks': sorted(tk),
              'n_tick_objects': len(tk), 'n_unique_tick_x': len(dup)}
    print(g, 'steps', len(steps), 'end', res[g]['end_time'], 'final S', steps[-1][1], 'ticks', len(tk), 'unique', len(dup))
json.dump(res, open(f'{out}/extracted_curves.json', 'w'), indent=1)
