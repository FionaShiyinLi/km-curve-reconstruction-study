"""Reconstruct IPD from extracted vector KM steps, censor ticks and the risk table.
Usage: python reconstruct.py [manifest.json] [outdir]   (run extract.py first)"""
import sys, json, os, numpy as np, pandas as pd
man = json.load(open(sys.argv[1] if len(sys.argv) > 1 else '../input/manifest.json'))
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
SEED = man['code_seed']; rng = np.random.default_rng(SEED)   # recorded; allocation below is deterministic
ex = json.load(open(f'{out}/extracted_curves.json'))
# risk table read from the PDF text layer (times 0,6,...,36)
RT_T = [0, 6, 12, 18, 24, 30, 36]
RT = {'A': [1000, 737, 506, 356, 236, 91, 0], 'B': [1000, 763, 580, 433, 314, 121, 0]}
TOL = 1e-6          # measurement tolerance on S (vector coords rounded to 1e-4 pt -> <=2.8e-7 in S)

def place(c, lo, hi, ticks):
    """Place c censorings in (lo, hi]: at tick times (>=1 per tick if c allows, extra round-robin),
    uniform spacing if no tick exists (assumption)."""
    tk = [t for t in ticks if lo < t <= hi]
    if c == 0: return [], len(tk)
    if not tk:
        return list(lo + (hi - lo) * (np.arange(c) + 0.5) / c), 0
    if c < len(tk):   # fewer censorings than visible ticks: keep evenly spaced subset (flagged)
        idx = np.round(np.linspace(0, len(tk) - 1, c)).astype(int)
        return [tk[i] for i in idx], len(tk)
    return [tk[i % len(tk)] for i in range(c)], len(tk)

log = {}
recs = []
for g in 'AB':
    N = man['groups'][g]; st = ex[g]['steps']; ticks = [t for t, _ in ex[g]['ticks']]
    end = ex[g]['end_time']
    n = N; S = 1.0; tprev = 0.0; drops = []; flags = []
    for t, Sm in st[1:]:
        best = None
        for d in range(1, 16):
            for c in range(0, n - d + 1):
                nn = n - c
                Sp = S * (1 - d / nn)
                if Sp < Sm - 5e-3: break
                err = abs(Sp - Sm)
                if err < 5e-3:
                    ntk = sum(tprev < x < t + 1e-9 for x in ticks)
                    key = (err > TOL, abs(c - ntk) if err <= TOL else err, d)
                    if best is None or key < best[0]: best = (key, d, c, Sp, err, ntk)
        _, d, c, Sp, err, ntk = best
        if err > TOL: flags.append(('S_mismatch', t, err))
        if c != ntk: flags.append(('censor_vs_ticks', t, c, ntk))
        drops.append(dict(t=t, d=d, c_before=c, n_risk=n - c, S_model=Sp, S_meas=Sm, err=err, lo=tprev))
        n = n - c - d; S = Sp; tprev = t
    # censorings in each inter-drop interval; split an interval that contains a risk-table time so
    # the at-risk count at that time matches the table where feasible
    times, ev = [], []
    for dr in drops:
        times += [dr['t']] * dr['d']; ev += [1] * dr['d']
    cens = []
    bounds = [dr['lo'] for dr in drops] + [tprev]
    his = [dr['t'] for dr in drops] + [end]
    cs = [dr['c_before'] for dr in drops] + [n]   # remaining n censored after last drop, by curve end
    for lo, hi, c in zip(bounds, his, cs):
        inner = [T for T in RT_T if lo < T <= hi and T > 0]
        segs = [lo] + inner + [hi]
        if len(segs) == 2:
            cens += place(c, lo, hi, ticks)[0]; continue
        # required: records with time >= T equals table -> censorings before T within interval
        rem = c; prev = lo
        for T in inner:
            ev_after = sum(1 for x in times if x >= T); c_after_all = sum(1 for x in cens if x >= T)
            # at risk at T = events >= T + censorings already placed >= T (none, earlier intervals end < T)
            # + censorings of this interval at >= T + all later-interval censorings
            later = sum(cc for l2, cc in zip(bounds, cs) if l2 >= hi)
            need_ge = RT[g][RT_T.index(T)] - ev_after - later
            k = int(np.clip(rem - need_ge, 0, rem))     # censorings placed in (prev, T)
            if rem - need_ge != k: flags.append(('risk_table_infeasible', T, rem - need_ge))
            cens += place(k, prev, T - 1e-9, ticks)[0]; rem -= k; prev = T - 1e-9
        cens += place(rem, prev, hi, ticks)[0]
    times += cens; ev += [0] * len(cens)
    assert len(times) == N, (g, len(times))
    recs += [(g, float(x), int(e)) for x, e in zip(times, ev)]
    log[g] = dict(events=int(sum(ev)), censored=len(cens), n_drops=len(drops),
                  d_hist={int(k): int(v) for k, v in pd.Series([dr['d'] for dr in drops]).value_counts().items()},
                  max_S_err=max(dr['err'] for dr in drops), n_flags=len(flags), flags=flags[:40])
    pd.DataFrame(drops).to_csv(f'{out}/drops_{g}.csv', index=False)
    print(g, {k: v for k, v in log[g].items() if k != 'flags'})
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
# full float precision retained (rounding shifted events past measured step times)
tmp = f'{out}/.ipd.csv.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(dict(seed=SEED, **log), open(f'{out}/reconstruction_log.json', 'w'), indent=1, default=str)
