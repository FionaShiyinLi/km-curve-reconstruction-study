"""Reload committed ipd.csv, recompute right-continuous KM, compare to measurements and risk table.
Usage: python checks.py [outdir] [figure.png]"""
import sys, json, hashlib, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
FIG = sys.argv[2] if len(sys.argv) > 2 else '../input/figure.png'
sys.path.insert(0, f'{OUT}/code'); sys.argv = sys.argv[:1]
from reconstruct import RISK, RISK_T, X0, XPM, Y1, YPU
csv = f'{OUT}/ipd.csv'; sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); meas = pd.read_csv(f'{OUT}/measured_curve.csv')
def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = []
    for u in ts:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        S *= 1 - e/n; out.append((u, S))
    return np.array(out)
def km_at(tab, t):
    i = np.searchsorted(tab[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else tab[i, 1]
TOL = 0.006   # ~4.5 px: line half-width (2 px) + tick/antialias ambiguity + column quantisation
chk = {'csv_sha256': sha, 'tolerance_S': TOL, 'tolerance_note':
       'about 4.5 px at 750 px/unit; covers 5-px line width and 1-column (0.025 mo) placement of drops',
       'groups': {}}
fig, ax = plt.subplots(figsize=(10, 6))
for g in 'AB':
    d = df[df.group == g]; m = meas[meas.group == g]; tab = km(d)
    g_ok = {'n': int(len(d)), 'n_expected': 1000, 'n_pass': bool(len(d) == 1000),
            'event_values_ok': bool(set(d.event.unique()) <= {0, 1}),
            'events': int(d.event.sum()), 'event_total_supplied': 'unavailable (not in manifest)',
            'max_time': float(d.observed_time.max()), 'finite_nonneg': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all())}
    rk = []
    for t, nr in zip(RISK_T, RISK[g]):
        rec = int((d.observed_time >= t).sum())
        rk.append(dict(t=t, displayed=nr, reconstructed=rec, residual=rec-nr, status='pass' if rec == nr else 'fail'))
    g_ok['risk_table'] = rk
    cmp = []
    for t in [0.5, 1, 2, 3, 4.5, 6, 7.5, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.8]:
        # measured value: column just left of t (right-continuous step already applied)
        row = m.iloc[(m.t - t).abs().argsort().iloc[0]]
        mv, rv = float(row.S), float(km_at(tab, t))
        cmp.append(dict(t=t, measured_S=round(mv, 4), measured_kind=row.kind, km_S=round(rv, 4),
                        residual=round(rv-mv, 4), status='pass' if abs(rv-mv) <= TOL else 'fail'))
    g_ok['km_vs_measured'] = cmp
    allres = np.array([km_at(tab, t) for t in m.t]) - m.S.values
    g_ok['all_columns'] = dict(max_abs_residual=round(float(np.abs(allres).max()), 4),
                               mean_abs_residual=round(float(np.abs(allres).mean()), 4),
                               t_of_max=float(m.t.values[np.abs(allres).argmax()]))
    chk['groups'][g] = g_ok
    ax.plot(m.t, m.S_raw, '.', ms=1.5, color='gray')
    ax.step(np.r_[0, tab[:, 0]], np.r_[1, tab[:, 1]], where='post', lw=0.8, label=f'KM from ipd {g}')
    ax.plot(m.t, m.S, lw=0.6, ls='--', label=f'measured {g}')
ax.legend(); fig.savefig(f'{OUT}/overlay_check.png', dpi=130)
json.dump(chk, open(f'{OUT}/checks.json', 'w'), indent=1)
for g in 'AB':
    c = chk['groups'][g]; print(g, c['n'], c['events'], c['all_columns'], [r['status'] for r in c['risk_table']])
    print('  ', [(r['t'], r['measured_S'], r['km_S'], r['measured_kind']) for r in c['km_vs_measured']])
