# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (1800x1350 raster) and `../input/manifest.json`: n = 1000 per arm, time in months, seed 1237768164. The seed is set in `reconstruct.py`, but the algorithm is deterministic and never draws from it.
- The number-at-risk table was read visually from the figure. A: 1000, 698, 487, 356, 249, 81, 0; B: 1000, 659, 552, 454, 385, 166, 0, at 0, 6, ..., 36 months. All values are printed clearly, so I treat the readings as certain.
- The manifest supplies no event totals, so the event-total check is marked unavailable. The reconstructed totals (A 772, B 602) are outputs of the method, not supplied information.

## Measurement (`code/reconstruct.py::measure`)
- Calibration comes from detected axis tick pixels. The x ticks for 0 to 36 sit at columns 269.5 + 40k, i.e. 40 px/month. The y ticks for 1.0 to 0.0 sit at rows 179.5 + 150k, i.e. 750 px per unit. No global rescaling was applied to either arm.
- Arms are separated by their exact line colors. A horizontal opening (run length >= 3) removes isolated censor ticks, which are 2 px wide, 17 px tall and centered on the line.
- Each pixel column is classified as follows:
  - Flat (extent <= 6 px): the level is the line center.
  - Drop: the level is the bottom edge minus the half-width (2 px), i.e. the post-drop, right-continuous value.
  - Dense tick block (extent 15–18 px, centered within 2 px of a nearby flat level, or continuing an identical block): the level is the block center.
- Monotonicity is imposed by isotonic regression (pool-adjacent-violators), not by a running minimum.
- Origin: A's first ~5 columns are overdrawn by B, but the visible pixels at 0.1 month lie at S = 1.0. B has a genuine drop starting near t = 0, and it is preserved.
- The overlays (`overlay_zoom.png`, `overlay_check.png`) show the measured levels on the line center at the origin, at the crossing near 7–8 months, and in both dense-tick tails. Per-column measurements are in `measured_curve.csv` and tick locations in `ticks_A.csv` and `ticks_B.csv`.

## Reconstruction (`reconstruct.py::reconstruct`)
- Guyot-style forward recursion (own implementation), applied separately within each risk-table interval:
  - At each column where the measured S falls, d = round(n_risk × (1 − S_measured/Ŝ_previous)).
  - Ŝ is the running reconstructed KM, so rounding errors self-correct and d is not fixed at 1. Multi-event columns arise naturally.
  - Events precede censorings at tied times.
- The censoring count in each interval is solved iteratively so that the at-risk count at the next table time matches the displayed value exactly.
- Censor times (assumption): placed at the detected tick locations in that interval, with the count shared evenly across locations. Tick visibility gives location only. Multiplicity is not identified, especially in the overlapping tick blocks after about 24 months.
- Risk count 0 at 36: every participant still at risk after the last drop is censored at or before the last visible tick (A max 35.84, B max 35.94). Nobody is placed at 36, and no follow-up beyond the plotted curve is invented.

## Checks (`checks.json`, from the reloaded final CSV; SHA-256 recorded)
- The right-continuous KM step function computed from `ipd.csv` was compared with the measured curve:
  - 19 times per arm, including 0.5 months and 34–35.8 months: all within ±0.006. That tolerance is ~4.5 px, covering the 5-px line width and one-column placement.
  - All columns: max absolute residual 0.0012 (A) and 0.0034 (B).
- Risk-table counts of observed_time >= t match exactly at all 7 times in both arms.
- The residuals only show agreement with my own measurement. They are not an error bound on the individual records.

## Correction cycles
- One correction after the first complete file: B's last two columns were a dense tick block misclassified as a drop. Isotonic pooling had lowered B's final level from 0.310 to 0.309. The fix changed B's events from 601 to 602, and the checks were regenerated.

## Sensitivity (`sensitivity.csv`, one alternative)
- Alternative assumption: censor times spread uniformly within each risk interval instead of at tick locations.
- Common supported horizon: 35.8 months.
- RMST at 35.8 months (primary / sensitivity): A 15.648 / 15.635; B 18.949 / 18.943.
- S(35.8) (primary / sensitivity): A 0.1498 / 0.1479; B 0.3069 / 0.3020.
- Events (primary / sensitivity): A 772 / 773; B 602 / 604.
- This is a single alternative. It is not a confidence interval or a bound on reconstruction error.

## Unresolved limitations
- Censoring times inside intervals, and the multiplicity of overlapping ticks, are not identified by the figure. The allocation above is an assumption, constrained only by the tick positions and the risk table.
- Event times are resolved to the pixel column (0.025 months). Steep early segments (B, 0–4 months) contain few flat columns, so event timing there relies on bottom-edge measurement.
- The tail beyond the last tick carries no information about the censoring distribution or follow-up.
- Software: Python 3.12 (versions recorded in `checks.json`). The org default is R, but only Python was available in this runtime.

Reproduce from the work directory:
```
python output/code/reconstruct.py [fig] [manifest] [outdir]
python output/code/checks.py
CENSOR_MODE=uniform python output/code/reconstruct.py
python output/code/sensitivity_compare.py
```
