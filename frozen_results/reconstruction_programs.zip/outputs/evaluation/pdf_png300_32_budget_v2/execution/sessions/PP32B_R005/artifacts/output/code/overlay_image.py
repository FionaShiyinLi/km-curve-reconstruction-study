"""Draw measured levels (black) onto crops of the original raster for visual verification."""
import sys, numpy as np, pandas as pd
from PIL import Image
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
FIG = sys.argv[2] if len(sys.argv) > 2 else '../input/figure.png'
im = np.asarray(Image.open(FIG).convert('RGB')).copy()
m = pd.read_csv(f'{OUT}/measured_curve.csv')
for g in 'AB':
    d = m[m.group == g]
    for c, y in zip(d.col, d.y_mono): im[int(round(y)), c] = (0, 0, 0)
crops = [(170, 300, 265, 420), (380, 520, 400, 600), (640, 840, 1400, 1715)]
tiles = [Image.fromarray(im[r0:r1, c0:c1]).resize(((c1-c0)*3, (r1-r0)*3), Image.NEAREST) for r0, r1, c0, c1 in crops]
W = max(t.width for t in tiles); H = sum(t.height for t in tiles)
canvas = Image.new('RGB', (W, H), 'white'); y = 0
for t in tiles: canvas.paste(t, (0, y)); y += t.height
canvas.save(f'{OUT}/overlay_zoom.png')
