"""Compare primary (ipd.csv) and sensitivity (sensitivity.csv) at a common horizon; appends to checks.json."""
import sys, json, platform, numpy as np, pandas as pd, scipy, PIL
OUT = sys.argv[1] if len(sys.argv) > 1 else 'output'
def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); S = 1.0; out = [(0.0, 1.0)]
    for u in ts:
        n = (d.observed_time >= u).sum(); e = ((d.observed_time == u) & (d.event == 1)).sum()
        S *= 1 - e/n; out.append((u, S))
    return np.array(out)
def S_at(tab, t): return tab[np.searchsorted(tab[:, 0], t, side='right')-1, 1]
def rmst(tab, h):
    x = np.r_[tab[tab[:, 0] < h, 0], h]; s = tab[tab[:, 0] < h, 1]
    return float(np.sum(np.diff(x)*s))
P = pd.read_csv(f'{OUT}/ipd.csv'); Q = pd.read_csv(f'{OUT}/sensitivity.csv')
H = float(min(P.groupby('group').observed_time.max().min(), Q.groupby('group').observed_time.max().min()))
H = np.floor(H*10)/10
res = {'assumption': 'censor times spread uniformly within each risk-table interval instead of at detected tick locations; events from the same measured curve',
       'common_horizon_months': H, 'arms': {}}
for g in 'AB':
    a, b = km(P[P.group == g]), km(Q[Q.group == g])
    res['arms'][g] = {'events_primary': int(P[P.group == g].event.sum()), 'events_sensitivity': int(Q[Q.group == g].event.sum()),
        'S_primary': {t: round(float(S_at(a, t)), 4) for t in [6, 12, 18, 24, 30, H]},
        'S_sensitivity': {t: round(float(S_at(b, t)), 4) for t in [6, 12, 18, 24, 30, H]},
        'RMST_primary': round(rmst(a, H), 3), 'RMST_sensitivity': round(rmst(b, H), 3)}
c = json.load(open(f'{OUT}/checks.json')); c['sensitivity'] = res
c['software'] = {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__,
                 'scipy': scipy.__version__, 'Pillow': PIL.__version__, 'platform': platform.platform()}
json.dump(c, open(f'{OUT}/checks.json', 'w'), indent=1, default=str)
print(json.dumps(res, indent=1, default=str)); print(c['software'])
