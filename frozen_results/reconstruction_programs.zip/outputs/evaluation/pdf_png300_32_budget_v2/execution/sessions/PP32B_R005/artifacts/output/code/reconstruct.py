"""Own implementation of a Guyot-style KM reconstruction (no KM-to-IPD package).
Usage: python reconstruct.py [figure.png] [manifest.json] [outdir]
Steps: (1) pixel measurement of each arm (measure()), (2) monotone correction (PAVA),
(3) interval-wise forward recursion constrained by the number-at-risk table."""
import sys, os, json, numpy as np, pandas as pd
from PIL import Image
FIG = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
MAN = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
OUT = sys.argv[3] if len(sys.argv) > 3 else 'output'
man = json.load(open(MAN)); SEED = man['code_seed']
rng = np.random.default_rng(SEED)   # recorded; algorithm below is deterministic
X0, XPM, Y1, YPU = 269.5, 40.0, 179.5, 750.0   # from detected axis tick pixels
t_of = lambda c: (c - X0) / XPM
s_of = lambda r: 1 - (r - Y1) / YPU
HALF = 2.0            # half line thickness (5-px line: rows y-2..y+2)
COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}
# number at risk, read visually from the figure's risk table
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 698, 487, 356, 249, 81, 0], 'B': [1000, 659, 552, 454, 385, 166, 0]}
CMIN, CMAX = 270, 1710
MODE = os.environ.get('CENSOR_MODE', 'ticks')   # 'uniform' = sensitivity allocation
OUTNAME = 'ipd.csv' if MODE == 'ticks' else 'sensitivity.csv'

def pava_increasing(y):
    y = list(map(float, y)); w = [1.0]*len(y); blocks = []
    for v in y:
        blocks.append([v, 1.0, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            a, b = blocks[-2], blocks.pop()
            a[0] = (a[0]*a[1] + b[0]*b[1])/(a[1]+b[1]); a[1] += b[1]; a[2] += b[2]
    out = []
    for v, _, n in blocks: out += [v]*n
    return np.array(out)

def measure(a, g):
    m = np.abs(a - COLORS[g]).sum(2) < 60
    m[:, :CMIN] = False; m[:, CMAX+2:] = False; m[:150] = False; m[935:] = False
    op = np.zeros_like(m)      # horizontal opening, run>=3, removes isolated 2-px ticks
    for r in np.where(m.any(1))[0]:
        row = m[r]; c = 0
        while c < len(row):
            if row[c]:
                e = c
                while e < len(row) and row[e]: e += 1
                if e - c >= 3: op[r, c:e] = True
                c = e
            else: c += 1
    iso_tick = (m & ~op).sum(0) >= 4
    cols = np.arange(CMIN, CMAX+1)
    top = np.full(len(cols), np.nan); bot = top.copy()
    for i, c in enumerate(cols):
        rr = np.where(op[:, c])[0]
        if len(rr) == 0: rr = np.where(m[:, c])[0]
        if len(rr): top[i], bot[i] = rr.min(), rr.max()
    ext = bot - top + 1
    flat = ext <= 6
    center = (top + bot)/2
    yr = bot - HALF                       # level at right edge of column (post-drop)
    kind = np.where(flat, 'flat', 'drop').astype(object)
    # dense tick blocks survive the opening: extent 15-18 centred on nearby flat level
    for i in np.where((ext >= 15) & (ext <= 18))[0]:
        nb = [center[j] for j in range(max(0, i-8), min(len(cols), i+9)) if flat[j]]
        if nb and min(abs(center[i]-v) for v in nb) <= 2.0:
            yr[i] = center[i]; kind[i] = 'tick'
    # continuation of a dense tick block (identical top/bottom to previous tick column)
    for i in range(1, len(cols)):
        if kind[i] == 'drop' and kind[i-1] == 'tick' and top[i] == top[i-1] and bot[i] == bot[i-1]:
            yr[i] = center[i]; kind[i] = 'tick'
    yr[flat] = center[flat]
    miss = np.isnan(yr)
    kind[miss] = 'missing'
    # missing columns (curve overdrawn by the other arm): fill from next measured column
    s = pd.Series(yr); yr = s.bfill().ffill().values
    ymono = pava_increasing(yr)
    S = s_of(ymono)
    tickcols = [cols[i] for i in range(len(cols)) if iso_tick[cols[i]] or kind[i] == 'tick']
    # merge isolated ticks (2 px wide) into single locations; keep block columns individually
    locs = []
    for c in tickcols:
        if locs and c - locs[-1][-1] <= 1 and iso_tick[c] and not any(kind[cc-CMIN]=='tick' for cc in locs[-1]):
            locs[-1].append(c)
        else: locs.append([c])
    ticks = np.array([t_of(np.mean(l)) for l in locs])
    return pd.DataFrame(dict(col=cols, t=t_of(cols), top=top, bot=bot, kind=kind,
                             y_raw=yr, y_mono=ymono, S_raw=s_of(yr), S=S)), ticks

def reconstruct(meas, ticks, risk):
    """Forward KM recursion. Event times = columns where measured S drops.
    Censor counts per risk interval solved so that the at-risk count at the next
    table time matches; censor times placed at visible tick locations (evenly
    shared across ticks; multiplicity not identified) or uniformly if none."""
    t = meas.t.values; S = meas.S.values.copy()
    S[t <= 0.15] = np.minimum(S[t <= 0.15], 1.0)
    recs = []; n = risk[0]; Shat = 1.0
    for k in range(len(RISK_T)-1):
        a, b = RISK_T[k], RISK_T[k+1]
        idx = np.where((t >= a) & (t < b))[0]
        tk = ticks[(ticks >= a) & (ticks < b)]
        def run(ncen, commit=False):
            nr, Sh = n, Shat; ev = []; ce = []
            if ncen > 0:
                if len(tk) and MODE == 'ticks': ct = tk[np.floor(np.arange(ncen)*len(tk)/ncen).astype(int)]
                else: ct = a + (np.arange(ncen)+0.5)*(t[idx[-1]]-a)/ncen
            else: ct = np.array([])
            ct = np.sort(ct); ci = 0
            for j in idx:
                # events at column j (censored at the same time still at risk)
                d = 0
                if S[j] < Sh - 1e-9 and nr > 0:
                    d = int(round(nr*(1 - S[j]/Sh))); d = max(0, min(d, nr))
                if d:
                    ev += [t[j]]*d; Sh *= (1 - d/nr); nr -= d
                # censor those with times in (t_j - dt, t_j]
                while ci < len(ct) and ct[ci] <= t[j] + 1e-9:
                    if nr > 0: ce.append(ct[ci]); nr -= 1
                    ci += 1
            while ci < len(ct):                    # any leftover censors before b
                if nr > 0: ce.append(min(ct[ci], t[idx[-1]])); nr -= 1
                ci += 1
            return nr, Sh, ev, ce
        target = risk[k+1]
        ncen = max(0, n - target - int(round(n*(1 - S[idx[-1]]/Shat))))
        seen = {}
        for it in range(200):
            nr, Sh, ev, ce = run(ncen)
            seen[ncen] = abs(nr - target)
            if nr == target: break
            ncen = max(0, ncen + (nr - target))
            if ncen in seen: break
        best = min(seen, key=seen.get)
        nr, Sh, ev, ce = run(best)
        if b == RISK_T[-1] and nr > 0:            # risk 0 at 36: censor remainder at last tick/time
            last = tk.max() if len(tk) else t[idx[-1]]
            ce += [last]*nr; nr = 0
        recs += [(x, 1) for x in ev] + [(x, 0) for x in ce]
        print(f'  [{a},{b}) events={len(ev)} censored={len(ce)} n_end={nr} target={target} ticks={len(tk)}')
        n, Shat = nr, Sh
    return recs

if __name__ == '__main__':
    a = np.asarray(Image.open(FIG).convert('RGB')).astype(int)
    rows = []; allmeas = []
    for g in 'AB':
        meas, ticks = measure(a, g)
        if g == 'A':   # A's first columns are overdrawn by B; KM(0)=1 by definition
            pass
        meas.insert(0, 'group', g); allmeas.append(meas)
        pd.DataFrame({'group': g, 'tick_time': ticks}).to_csv(f'{OUT}/ticks_{g}.csv', index=False)
        print(g, 'ticks detected:', len(ticks), 'kinds:', meas.kind.value_counts().to_dict())
        recs = reconstruct(meas, ticks, RISK[g])
        assert len(recs) == man['groups'][g], (g, len(recs))
        rows += [(g, round(float(x), 4), e) for x, e in recs]
    if MODE == 'ticks': pd.concat(allmeas).to_csv(f'{OUT}/measured_curve.csv', index=False)
    df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
    tmp = f'{OUT}/.{OUTNAME}.tmp'; df.to_csv(tmp, index=False); os.replace(tmp, f'{OUT}/{OUTNAME}')
    print('written', len(df), df.groupby('group').event.agg(['size', 'sum']).to_dict())
