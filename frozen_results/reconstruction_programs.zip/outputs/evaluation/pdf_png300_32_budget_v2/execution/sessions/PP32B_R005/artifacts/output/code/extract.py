"""Pixel extraction of KM curves from figure.png (own code, no KM-to-IPD package).
Usage: python extract.py [path/to/figure.png] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
a = np.asarray(Image.open(fig).convert('RGB')).astype(int)
# Axis calibration from labelled tick marks (detected dark tick pixels):
# x ticks 0,6,...,36 at columns 269.5,509.5,...,1709.5 ; y ticks 1.0..0.0 at rows 179.5..929.5
X0, XPM = 269.5, 40.0          # pixel of t=0, pixels per month
Y1, YPU = 179.5, 750.0         # pixel of S=1, pixels per unit S
t_of = lambda c: (c - X0) / XPM
s_of = lambda r: 1 - (r - Y1) / YPU
cols = {'A': (31, 119, 180), 'B': (255, 127, 14)}
res = {}
for g, rgb in cols.items():
    m = np.abs(a - rgb).sum(2) < 60
    m[:, :265] = False; m[:, 1715:] = False; m[:150] = False; m[935:] = False
    # horizontal opening (run length >=3) removes isolated 2-px-wide censor ticks
    op = np.zeros_like(m)
    for r in range(m.shape[0]):
        row = m[r]; c = 0; n = len(row)
        while c < n:
            if row[c]:
                e = c
                while e < n and row[e]: e += 1
                if e - c >= 3: op[r, c:e] = True
                c = e
            else: c += 1
    tick = m & ~op
    recs = []
    for c in range(270, 1712):
        rr = np.where(m[:, c])[0]; ro = np.where(op[:, c])[0]; rt = np.where(tick[:, c])[0]
        recs.append(dict(col=c, t=t_of(c),
                         raw_top=int(rr.min()) if len(rr) else None, raw_bot=int(rr.max()) if len(rr) else None,
                         op_top=int(ro.min()) if len(ro) else None, op_bot=int(ro.max()) if len(ro) else None,
                         ntick=int(len(rt))))
    res[g] = recs
json.dump(res, open(f'{out}/pixel_columns.json', 'w'))
