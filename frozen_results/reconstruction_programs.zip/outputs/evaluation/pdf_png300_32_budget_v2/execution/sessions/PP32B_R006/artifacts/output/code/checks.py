"""Verify committed output/ipd.csv against measured vector curve and risk table."""
import sys, os, json, hashlib
import numpy as np, pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path); M = json.load(open(os.path.join(OUT, "measurements.json")))
man = json.load(open(os.path.join(os.path.dirname(os.path.abspath(OUT)), "..", "input", "manifest.json"))) \
    if len(sys.argv) < 3 else json.load(open(sys.argv[2]))

def km(d):
    ts = np.sort(d.observed_time[d.event == 1].unique()); s = 1.0; out = []
    for t in ts:
        n = (d.observed_time >= t).sum(); e = ((d.observed_time == t) & (d.event == 1)).sum()
        s *= 1 - e / n; out.append((t, s))
    return out
def S_at(steps, t):  # right-continuous
    s = 1.0
    for tt, v in steps:
        if tt <= t: s = v
    return s
def meas_at(drops, t):
    s = 1.0
    for tt, sb, sa in drops:
        if tt <= t: s = sa
    return s

TOL = 0.0025  # vector coordinates: half the smallest possible KM step (~1/100 * S) exceeds this; float rounding ~1e-6
chk = {"csv_sha256": sha, "tolerance_survival": TOL, "groups": {}}
for g in ("A", "B"):
    d = df[df.group == g]; st = km(d); m = M["measured"][g]
    drops = m["drops"]
    times = sorted(set([0.0, 3, 6, 9, 12, 18, 24, 30, m["curve_end_t"]] + [x[0] + 1e-3 for x in drops[-3:]] + [x[0] - 1e-3 for x in drops[-3:]]))
    comp = []
    for t in times:
        a, b = meas_at(drops, t), S_at(st, t)
        comp.append({"t": t, "measured": round(a, 5), "reconstructed": round(b, 5),
                     "resid": round(b - a, 5), "status": "pass" if abs(b - a) <= TOL else "fail"})
    maxres = max(abs(S_at(st, t) - meas_at(drops, t)) for t in np.linspace(0, m["curve_end_t"], 2000))
    # implied event multiplicity per drawn drop: d = n_risk*(1 - S_after/S_before)
    dd = []; ev = 0
    for tt, sb, sa in drops:
        nr = int((d.observed_time >= tt - 1e-4).sum()); x = nr * (1 - sa / sb)
        dd.append({"t": round(tt, 4), "n_risk": nr, "implied_d": round(x, 4), "adopted_d": int(round(x))})
    rt = []
    for t, r in zip([0, 6, 12, 18, 24, 30, 36], M["risk_table"][g]):
        n = int((d.observed_time >= t).sum())
        rt.append({"t": t, "table": r, "reconstructed": n, "resid": n - r, "status": "pass" if n == r else "fail"})
    chk["groups"][g] = {
        "n_records": int(len(d)), "n_manifest": man["groups"][g], "size_status": "pass" if len(d) == man["groups"][g] else "fail",
        "event_values_ok": bool(d.event.isin([0, 1]).all()), "n_events": int(d.event.sum()),
        "supplied_event_total": "unavailable (not in manifest)",
        "n_censor_marks_drawn": len(m["censor_marks_t"]), "n_censored": int((d.event == 0).sum()),
        "km_vs_measured": comp, "max_abs_resid_dense_grid": round(maxres, 6), "drop_multiplicity": dd, "max_nonintegrality": round(max(abs(x["implied_d"]-x["adopted_d"]) for x in dd), 5), "n_drops": len(dd), "n_drops_d_gt1": sum(x["adopted_d"] > 1 for x in dd), "risk_table": rt,
        "max_time": float(d.observed_time.max()), "curve_end_t": m["curve_end_t"]}
json.dump(chk, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
for g in chk["groups"]:
    c = chk["groups"][g]; print(g, c["n_records"], c["n_events"], c["max_abs_resid_dense_grid"],
          [x["reconstructed"] for x in c["risk_table"]], [x["status"] for x in c["risk_table"]],
          all(x["status"] == "pass" for x in c["km_vs_measured"]))
