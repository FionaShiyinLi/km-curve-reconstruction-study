"""KM -> IPD reconstruction from vector PDF objects (own implementation).
Usage: python reconstruct.py [input_dir] [output_dir]   (defaults ../input, output)
"""
import sys, os, json, hashlib
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
man = json.load(open(os.path.join(IN, "manifest.json")))
np.random.seed(man["code_seed"])  # no randomness used; seed recorded
pg = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]
COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}

# --- axis calibration from labelled tick marks (black 0.6pt lines) ---
blk = [l for l in pg.lines if tuple(l["stroking_color"]) == (0.0, 0.0, 0.0)]
xt = sorted({round(l["x0"], 3) for l in blk if l["top"] == 223.2 and l["bottom"] > 223.2 + 1})
yt = sorted({round(l["top"], 3) for l in blk if l["x1"] - l["x0"] < 4})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]  # labels read from text layer
bx = np.polyfit(xt, xlab, 1); by = np.polyfit(yt, ylab, 1)
res_x = np.polyval(bx, xt) - xlab; res_y = np.polyval(by, yt) - ylab
T = lambda x: float(np.polyval(bx, x)); S = lambda y: float(np.polyval(by, y))

# risk table from text layer
words = pg.extract_words()
rows = {}
for g, key in (("A", 283.9), ("B", 297.9)):
    ws = sorted([w for w in words if abs(w["top"] - key) < 1 and w["x0"] > 55], key=lambda w: w["x0"])
    rows[g] = [int(w["text"]) for w in ws]
risk_t = xlab

meas, recs, info = {}, [], {}
for g in ("A", "B"):
    cur = [c for c in pg.curves if tuple(c["stroking_color"]) == COL[g]][0]
    pts = [(T(x), S(y)) for x, y in cur["pts"]]
    # step curve: horizontal segments -> (t_start, level)
    steps = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(s1 - s0) > 1e-9 and abs(t1 - t0) < 1e-6:
            steps.append((t0, s0, s1))
    t_end = pts[-1][0]
    marks = sorted(T(l["x0"]) for l in pg.lines if tuple(l["stroking_color"]) == COL[g]
                   and abs(l["bottom"] - l["top"] - 4) < 0.01)
    mark_s = {}
    meas[g] = {"curve_vertices": pts, "drops": steps, "censor_marks_t": marks, "curve_end_t": t_end}
    n = man["groups"][g]
    tbl = rows[g]

    def simulate(extra):
        """extra: list of hidden censor times. Returns events list, censors list, n_at_risk fn."""
        cens = sorted(marks + extra)
        ev = []
        for (t, sb, sa) in steps:
            nr = n - sum(1 for e in ev) - sum(1 for c in cens if c < t)
            # events counted before censoring at ties; subtract prior events properly
            nr = n - len(ev) - sum(1 for c in cens if c < t)
            d = int(round(nr * (1 - sa / sb)))
            ev += [t] * max(d, 0)
        return ev, cens

    # hidden censoring, interval by interval, so that risk counts match table
    extra = []
    for k in range(len(risk_t) - 1):
        a, b = risk_t[k], risk_t[k + 1]
        target = tbl[k + 1]
        best = None
        for m in range(0, 60):
            # hidden censors spread evenly inside (a,b) - assumption
            hid = list(a + (b - a) * (np.arange(m) + 0.5) / m) if m else []
            if target == 0:
                hid = [min(h, t_end) for h in hid]
            ev, cens = simulate(extra + hid)
            nb = n - sum(1 for e in ev if e < b) - sum(1 for c in cens if c < b)
            if best is None or abs(nb - target) < abs(best[1] - target):
                best = (hid, nb)
            if nb <= target:
                break
        extra += best[0]
    ev, cens = simulate(extra)
    left = n - len(ev) - len(cens)
    info[g] = {"n_events": len(ev), "n_marks": len(marks), "n_hidden_censors": len(extra),
               "left_over_censored_at_curve_end": max(left, 0), "overcount": max(-left, 0)}
    cens = cens + [t_end] * max(left, 0)
    if left < 0:  # too many records: drop latest hidden censors
        raise SystemExit(f"group {g}: record overcount {left}")
    recs += [(g, round(t, 4), 1) for t in ev] + [(g, round(t, 4), 0) for t in cens]

df = pd.DataFrame(recs, columns=["group", "observed_time", "event"]).sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
assert (df.groupby("group").size() == pd.Series(man["groups"])).all()
os.makedirs(OUT, exist_ok=True)
tmp = os.path.join(OUT, "ipd.csv.tmp"); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, "ipd.csv"))
json.dump({"calibration": {"x_ticks_pt": xt, "y_ticks_pt": yt, "x_fit": list(bx), "y_fit": list(by),
           "x_resid": list(res_x), "y_resid": list(res_y)}, "risk_table": rows, "info": info, "measured": meas},
          open(os.path.join(OUT, "measurements.json"), "w"), indent=1)
print(json.dumps(info))
