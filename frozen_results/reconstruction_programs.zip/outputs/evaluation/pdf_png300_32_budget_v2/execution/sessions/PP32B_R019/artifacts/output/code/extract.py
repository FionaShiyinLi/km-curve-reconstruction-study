"""Extract vector step curves and censor ticks from the KM figure PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
p = pdfplumber.open(pdf).pages[0]
H = p.height
# Axis calibration from labelled tick marks (black 0.6pt lines) and words
blk = [l for l in p.lines if tuple(l['stroking_color']) == (0.0, 0.0, 0.0)]
xt = sorted({round(l['x0'], 3) for l in blk if abs(l['bottom'] - l['top']) > 1 and l['top'] >= 223})
yt = sorted({round(l['top'], 3) for l in blk if abs(l['x1'] - l['x0']) < 4})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
# linear fit
import numpy as np
ax_, bx_ = np.polyfit(xt, xlab, 1); ay_, by_ = np.polyfit(yt[::-1], ylab, 1)
cal = dict(x_ticks_pt=xt, x_labels=xlab, y_ticks_top_pt=yt, y_labels_desc=ylab[::-1],
           months_per_pt=ax_, month_offset=bx_, surv_per_pt=ay_, surv_offset=by_,
           x_resid=list(np.array(xt)*ax_+bx_-xlab), y_resid=list(np.array(yt[::-1])*ay_+by_-ylab))
T = lambda x: ax_*x+bx_; S = lambda top: ay_*top+by_
# Legend: coloured line segment left of "Group A"/"Group B" text
words = p.extract_words()
leg = {}
for l in p.lines:
    if l['top'] < 30 and tuple(l['stroking_color']) != (0, 0, 0):
        near = min((w for w in words if w['text'] == 'Group' and w['top'] < 30), key=lambda w: abs(w['x0']-l['x1']))
        nxt = [w for w in words if w['top'] < 30 and w['x0'] > near['x1']][0]['text']
        leg[str(tuple(l['stroking_color']))] = nxt
res = {'calibration': cal, 'legend_colour_to_group': leg, 'groups': {}}
for c in p.curves:
    g = leg[str(tuple(c['stroking_color']))]
    pts = [(T(x), S(y)) for x, y in c['pts']]   # pdfplumber pts are top-based
    ticks = sorted(T(l['x0']) for l in p.lines if str(tuple(l['stroking_color'])) == str(tuple(c['stroking_color']))
                   and abs(l['bottom']-l['top']) > 3 and l['top'] > 30)
    tick_s = sorted(((T(l['x0']), S((l['top']+l['bottom'])/2)) for l in p.lines if str(tuple(l['stroking_color'])) == str(tuple(c['stroking_color']))
                   and abs(l['bottom']-l['top']) > 3 and l['top'] > 30))
    res['groups'][g] = {'curve_vertices': pts, 'censor_ticks': tick_s}
json.dump(res, open(f'{out}/extracted_observations.json', 'w'), indent=1)
print(json.dumps(cal, indent=1)); print(leg)
for g, d in res['groups'].items():
    print(g, len(d['curve_vertices']), 'ticks', len(d['censor_ticks']), 'end', d['curve_vertices'][-1])
