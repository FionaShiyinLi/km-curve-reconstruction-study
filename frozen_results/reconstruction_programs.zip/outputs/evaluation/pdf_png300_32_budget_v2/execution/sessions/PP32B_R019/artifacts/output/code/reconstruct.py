"""KM -> participant records reconstruction from extracted vector observations.
Usage: python reconstruct.py [extracted_observations.json] [manifest.json] [outdir]
Deterministic (no randomness used); seed from manifest recorded for provenance."""
import sys, json, os, numpy as np
obs = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'output/extracted_observations.json'))
man = json.load(open(sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'))
out = sys.argv[3] if len(sys.argv) > 3 else 'output'
SEED = man['code_seed']; np.random.seed(SEED)
risk_table = {'A': {0: 100, 6: 70, 12: 44, 18: 26, 24: 17, 30: 5, 36: 0},
              'B': {0: 100, 6: 82, 12: 62, 18: 46, 24: 34, 30: 11, 36: 0}}
EPS = 1e-6
def steps(vertices):
    """Return list of (time, S_before, S_after) for each vertical drop."""
    v = np.array(vertices); dr = []
    for (x0, y0), (x1, y1) in zip(v[:-1], v[1:]):
        if abs(x1 - x0) < EPS and y1 < y0 - EPS:
            dr.append((x0, y0, y1))
    # merge consecutive drops at identical time
    m = []
    for t, a, b in dr:
        if m and abs(m[-1][0] - t) < EPS: m[-1] = (t, m[-1][1], b)
        else: m.append((t, a, b))
    return m
recs, diag = [], {}
for g in ['A', 'B']:
    n = man['groups'][g]
    d = obs['groups'][g]
    drops = steps(d['curve_vertices'])
    ticks = [t for t, s in d['censor_ticks']]
    end_t = d['curve_vertices'][-1][0]
    # event list ordering: process events and censor ticks chronologically, events first at ties
    evs = [(t, 0, a, b) for t, a, b in drops] + [(t, 1, None, None) for t in ticks]
    evs.sort(key=lambda z: (round(z[0], 6), z[1]))
    nrisk = n; rows = []; dlog = []
    for t, kind, a, b in evs:
        if kind == 0:
            draw = nrisk * (1 - b / a)
            k = int(round(draw))
            dlog.append(dict(time=t, S_before=a, S_after=b, n_risk=nrisk, d_raw=draw, d=k))
            rows += [(g, t, 1)] * k; nrisk -= k
        else:
            rows.append((g, t, 0)); nrisk -= 1
    diag[g] = dict(n_drops=len(drops), n_ticks=len(ticks), remaining_after_all=nrisk, end_time=end_t,
                   max_abs_d_resid=max(abs(z['d_raw'] - z['d']) for z in dlog), drops=dlog)
    if nrisk > 0:   # unmarked survivors: censor at end of drawn curve (documented assumption)
        rows += [(g, end_t, 0)] * nrisk
    recs += rows
import pandas as pd
df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event'])
df['observed_time'] = df['observed_time'].round(6)
tmp = os.path.join(out, 'ipd.csv.tmp'); df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(out, 'ipd.csv'))
json.dump(diag, open(os.path.join(out, 'reconstruction_diagnostics.json'), 'w'), indent=1)
for g in diag:
    z = diag[g]; print(g, {k: v for k, v in z.items() if k != 'drops'}, 'events', sum(x['d'] for x in z['drops']))
    print('  multi-event drops:', [(round(x['time'],3), x['d'], round(x['d_raw'],3)) for x in z['drops'] if x['d'] != 1])
print(df.groupby('group').agg(n=('event', 'size'), ev=('event', 'sum')))
