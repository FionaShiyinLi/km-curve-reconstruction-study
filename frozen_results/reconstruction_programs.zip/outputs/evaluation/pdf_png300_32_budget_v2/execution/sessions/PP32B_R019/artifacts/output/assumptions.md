# Reconstruction assumptions and methods

## Inputs used
- `../input/figure.pdf` (a vector PDF). Survival curves, censor ticks, axis ticks, legend and number-at-risk table are all read from the PDF's vector objects and text.
- `../input/manifest.json`: n = 100 per group, time in months, code seed 2113320190. The algorithm is deterministic. The seed is set in `reconstruct.py` and recorded there, but no random draws are made.
- The manifest has no arm-specific event totals, so the event-total check is marked unavailable in `checks.json`.

## Measurement
- Calibration comes from the labelled axis tick marks: x = 64.8 pt is 0 months and x = 410.4 pt is 36 months (9.6 pt per month); y = 223.2 pt is S = 0 and y = 43.2 pt is S = 1. Residuals of the linear fit at all seven x ticks and all six y ticks are below 1e-13. No global rescaling or origin correction was applied: both curves start exactly at S = 1.0 at t = 0, and no running-minimum correction was used.
- Arm identity comes from the legend colours: blue (0.12, 0.47, 0.71) is Group A and orange is Group B. Each arm is one polyline (A: 170 vertices, B: 129). Censor marks are 4-pt vertical strokes in the arm colour, centred on the curve: 16 in A and 36 in B.
- Extracted observations are saved in `extracted_observations.json`. Per-drop diagnostics are in `reconstruction_diagnostics.json`.

## Algorithm (`code/reconstruct.py`)
Vertical drops and censor ticks are processed in time order, with events placed before censorings at tied times. At each drop the number of events is d = n_risk(1 − S_after/S_before), rounded to the nearest integer, where n_risk = n minus all earlier events and censorings. Each tick is one censoring at the tick's x-time.
- Evidence for tick multiplicity: every drop in both arms gives a raw d within 5e-5 of an integer. This only holds if n_risk is correct at every step, which means each tick is exactly one censoring and no censorings are unmarked. Every drop came out as d = 1; this is computed from the ratio, not assumed. The closest pair of ticks is 0.0074 months apart (B), and none overlap within the vector precision.
- Totals: A has 84 events and 16 censorings; B has 64 events and 36 censorings. No participants remain unaccounted for, so no end-of-curve censorings had to be added.
- Tail: A's last record is a censoring at 34.76 months (S = 0.086). B's last participant (n_risk = 1) has an event at 33.10 months, which matches the drawn drop to S = 0.
- Times are stored to 6 decimals. Their accuracy is limited by the PDF coordinate precision (about 1e-4 months), not by pixel resolution.

## Risk table and checks (`code/check.py`)
`check.py` reloads `ipd.csv` and recomputes the right-continuous KM curve. It compares that curve with the measured step curve at fixed times (0–34.7 months, including the tail and the last vertex) and at points just before and after every eighth drop. Tolerance is half a PDF point (0.0028 in S), which is appropriate because the coordinates are exact vector values. The maximum residual is 0 in both arms.

The number at risk, counted as observed_time ≥ t, equals the displayed table at every time 0, 6, …, 36 in both arms (A: 100/70/44/26/17/5/0; B: 100/82/62/46/34/11/0). Both displayed zeros at 36 months hold because all records end before 36. The risk table was not used as an input; it serves only as independent verification.

## Limitations
- The records reproduce the published KM step function and risk table exactly. They can differ from the original data only in ways the figure cannot show: event times are the drawn step times, which may be rounded in the source, and censoring times are the tick positions.
- Sensitivity analysis was not run. The drop ratios, tick counts and risk table jointly pin down the event/censor allocation, so no materially different feasible allocation was found that would justify one. This is not a bound on reconstruction error.
- One correction cycle was used. It changed only the time rounding (4 dp to 6 dp) so that the check and the CSV use the same time basis at B's final event. The allocation did not change.
