"""Reload committed ipd.csv, recompute right-continuous KM, compare to extracted curve and risk table.
Usage: python check.py [output_dir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
csv = f'{out}/ipd.csv'; sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
df = pd.read_csv(csv); obs = json.load(open(f'{out}/extracted_observations.json'))
risk = {'A': {0: 100, 6: 70, 12: 44, 18: 26, 24: 17, 30: 5, 36: 0}, 'B': {0: 100, 6: 82, 12: 62, 18: 46, 24: 34, 30: 11, 36: 0}}
def km(t, e):
    ts = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ts:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n; out.append((u, s))
    return out
def km_at(k, x):  # right-continuous
    s = 1.0
    for u, v in k:
        if u <= x + 1e-9: s = v
    return s
def curve_at(vs, x):  # measured step curve value at x (right-continuous: take last vertex with t<=x)
    s = vs[0][1]
    for t, y in vs:
        if t <= x + 1e-9: s = y
        else: break
    return s
TOL = 0.0056 / 2  # half of 1 pt vertical in survival units (1pt = 0.00556); vector coordinates are exact to ~1e-6
res = {'csv_sha256': sha, 'survival_tolerance': TOL,
       'tolerance_justification': 'Curve read from PDF vector coordinates (exact); tolerance = half a PDF point.', 'groups': {}}
for g in ['A', 'B']:
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    k = km(t, e); vs = [(round(a, 6), b) for a, b in obs['groups'][g]['curve_vertices']]  # same 6-dp time basis as CSV
    drops = [vs[i][0] for i in range(1, len(vs)) if abs(vs[i][0]-vs[i-1][0]) < 1e-9 and vs[i][1] < vs[i-1][1]]
    grid = sorted(set([0, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 34.7, vs[-1][0]] +
                      [x + 1e-4 for x in drops[::8]] + [x - 1e-4 for x in drops[::8]]))
    grid = [round(x, 6) for x in grid if x <= vs[-1][0] + 1e-9]
    sc = []
    for x in grid:
        m = curve_at(vs, x); r = km_at(k, x)
        sc.append(dict(time=round(x, 4), measured=round(m, 6), reconstructed=round(r, 6), residual=round(r - m, 6),
                       status='pass' if abs(r - m) <= TOL else 'fail'))
    rc = []
    for tt, nr in risk[g].items():
        c = int((t >= tt).sum())
        rc.append(dict(time=tt, displayed=nr, reconstructed=c, residual=c - nr, status='pass' if c == nr else 'fail'))
    res['groups'][g] = dict(n=len(d), n_expected=100, n_ok=len(d) == 100, events=int(e.sum()), censored=int((e == 0).sum()),
                           event_indicator_integer_01=bool(set(np.unique(e)) <= {0, 1}),
                           supplied_event_total='unavailable (not in manifest)',
                           max_followup=float(t.max()), curve_end=vs[-1][0], survival_checks=sc, risk_table_checks=rc,
                           n_fail=sum(z['status'] == 'fail' for z in sc + rc))
    print(g, len(d), int(e.sum()), 'fails', res['groups'][g]['n_fail'], 'max|resid|', max(abs(z['residual']) for z in sc))
    print('  risk', [(z['time'], z['displayed'], z['reconstructed']) for z in rc])
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
print(sha)
