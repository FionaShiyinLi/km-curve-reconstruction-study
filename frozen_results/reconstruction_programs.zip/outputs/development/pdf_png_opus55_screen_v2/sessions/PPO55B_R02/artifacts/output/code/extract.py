"""Extract vector KM step curves and censor ticks from the figure PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.pdf"
out = sys.argv[2] if len(sys.argv) > 2 else "output"
pg = pdfplumber.open(pdf).pages[0]
# axis calibration from labelled tick marks (black lines) and tick labels
X0, X1, T0, T1 = 64.8, 410.4, 0.0, 36.0   # x ticks labelled 0 and 36
Y0, Y1 = 223.2, 43.2                      # y ticks labelled 0.0 and 1.0
tx = lambda x: T0 + (x - X0) * (T1 - T0) / (X1 - X0)
sy = lambda y: (Y0 - y) / (Y0 - Y1)
BLUE, ORANGE = (0.121569, 0.466667, 0.705882), (1.0, 0.498039, 0.054902)
col = {BLUE: "A", ORANGE: "B"}   # legend: blue swatch beside "Group A", orange beside "Group B"
res = {"calibration": dict(X0=X0, X1=X1, Y0=Y0, Y1=Y1), "curves": {}, "ticks": {"A": [], "B": []}}
for c in pg.curves:
    g = col[tuple(c["stroking_color"])]
    res["curves"][g] = [(tx(x), sy(y)) for x, y in c["pts"]]
for l in pg.lines:
    g = col.get(tuple(l["stroking_color"]) if l["stroking_color"] else None)
    if g and abs(l["x0"] - l["x1"]) < 1e-6 and 3.5 < l["bottom"] - l["top"] < 4.5:
        res["ticks"][g].append((tx(l["x0"]), sy((l["top"] + l["bottom"]) / 2)))
for g in res["ticks"]: res["ticks"][g].sort()
json.dump(res, open(f"{out}/extracted_vectors.json", "w"), indent=1)
print({g: len(v) for g, v in res["curves"].items()}, {g: len(v) for g, v in res["ticks"].items()})
