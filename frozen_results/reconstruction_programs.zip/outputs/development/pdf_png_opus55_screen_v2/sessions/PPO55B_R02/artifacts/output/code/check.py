"""Reload committed ipd.csv, recompute right-continuous KM and compare to measured vector curve and risk table."""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else "output"
path = f"{out}/ipd.csv"
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path); V = json.load(open(f"{out}/extracted_vectors.json"))
D = json.load(open(f"{out}/drop_diagnostics.json")); man = json.load(open("../input/manifest.json"))
def km(sub, t):
    s = 1.0
    for u in np.sort(sub.observed_time[sub.event == 1].unique()):
        if u > t: break
        n = (sub.observed_time >= u).sum(); d = ((sub.observed_time == u) & (sub.event == 1)).sum(); s *= 1 - d / n
    return s
def curve(pts, t):  # right-continuous value of the drawn step path at t
    s = pts[0][1]
    for x, y in pts:
        if x <= t + 1e-9: s = y
        else: break
    return s
C = {"ipd_sha256": sha, "tolerance_survival": 0.002,
     "tolerance_note": "vector path coordinates are exact to ~1e-5 pt; 0.002 (~0.36 pt) only absorbs float rounding in PDF output",
     "arms": {}}
allpass = True
for g in "AB":
    sub = df[df.group == g]; pts = V["curves"][g]; end = pts[-1][0]
    times = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, round(end - 0.01, 3), round(end, 3)]
    sc = []
    for t in times:
        m, r = curve(pts, t), km(sub, t); ok = abs(m - r) <= 0.002; allpass &= ok
        sc.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), residual=round(r - m, 6), status="pass" if ok else "fail"))
    rk = []
    for t, v in D["risk_table"][g].items():
        n = int((sub.observed_time >= float(t)).sum()); ok = n == v; allpass &= ok
        rk.append(dict(t=float(t), displayed=v, reconstructed=n, residual=n - v, status="pass" if ok else "fail"))
    C["arms"][g] = dict(n_records=len(sub), n_expected=man["groups"][g], n_events=int(sub.event.sum()),
        events_supplied="unavailable (manifest has no event totals)",
        event_indicator_integer=bool(sub.event.isin([0, 1]).all()), max_time=float(sub.observed_time.max()),
        curve_end=end, survival_checks=sc, risk_checks=rk)
    allpass &= len(sub) == man["groups"][g]
C["overall"] = "pass" if allpass else "fail"
json.dump(C, open(f"{out}/checks.json", "w"), indent=1)
print(json.dumps({g: [(x["t"], x["residual"], x["status"]) for x in C["arms"][g]["risk_checks"]] for g in "AB"}), C["overall"])
for g in "AB": print(g, max(abs(x["residual"]) for x in C["arms"][g]["survival_checks"]))
