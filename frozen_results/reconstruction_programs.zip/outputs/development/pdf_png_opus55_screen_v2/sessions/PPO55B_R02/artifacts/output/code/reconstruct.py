"""Reconstruct IPD from the vector KM figure.
Usage (from work dir): python output/code/reconstruct.py [../input] [output]
Deterministic; seed recorded for completeness (no random draws are used)."""
import sys, os, json, hashlib, subprocess
import numpy as np, pandas as pd, pdfplumber
SEED = 1185688928
np.random.seed(SEED % 2**32)
inp = sys.argv[1] if len(sys.argv) > 1 else "../input"
out = sys.argv[2] if len(sys.argv) > 2 else "output"
here = os.path.dirname(os.path.abspath(__file__))
subprocess.run([sys.executable, os.path.join(here, "extract.py"), f"{inp}/figure.pdf", out], check=True)
man = json.load(open(f"{inp}/manifest.json"))
V = json.load(open(f"{out}/extracted_vectors.json"))

# ---- risk table from PDF text (rows at 'Group A'/'Group B' baselines, columns by x of time ticks)
pg = pdfplumber.open(f"{inp}/figure.pdf").pages[0]
words = pg.extract_words()
rowy = {w["text"][-1]: w["top"] for w in pg.extract_words(keep_blank_chars=True) if w["text"].startswith("Group") and w["top"] > 260}
risk = {}
for g, y in rowy.items():
    cells = sorted((w["x0"], int(w["text"])) for w in words if abs(w["top"] - y) < 1 and w["text"].isdigit())
    risk[g] = {int(round((((x0 + 0) - 64.8) / 9.6) / 6) * 6): v for x0, v in cells}  # nearest 6-month tick
    # label centres fall ~2-5 pt left of tick; rounding to nearest multiple of 6 is unambiguous here

def steps(pts):
    return [(pts[i][0], pts[i][1], pts[i + 1][1]) for i in range(len(pts) - 1)
            if abs(pts[i][0] - pts[i + 1][0]) < 1e-9 and pts[i + 1][1] < pts[i][1] - 1e-9]

recs, diag = [], {}
for g in "AB":
    N = man["groups"][g]
    drops = steps(V["curves"][g]); ticks = V["ticks"][g]
    avail, rows, prev_t = N, [], -1.0
    for t, a, b in drops:
        # censored strictly before this drop time (ticks at the same x sit on post-drop level -> after events)
        cen = [tt for tt, s in ticks if prev_t <= tt < t and not (abs(tt - prev_t) < 1e-9 and s > a + 1e-6)]
        n_tick = avail - len(cen)
        r = b / a
        # smallest d whose implied n (d/(1-r)) is integer within tolerance and <= available at risk
        cand = [(d, d / (1 - r)) for d in range(1, 11) if abs(d / (1 - r) - round(d / (1 - r))) < 0.02 and round(d / (1 - r)) <= avail]
        d, nimp = cand[0]; nimp = int(round(nimp))
        rows.append(dict(t=t, S_before=a, S_after=b, d=d, n_implied=nimp, n_from_ticks=n_tick,
                         alt_d=[c[0] for c in cand[1:]], censored_before=len(cen)))
        avail = n_tick - d; prev_t = t
    diag[g] = rows
    ev = [(r["t"], 1) for r in rows for _ in range(r["d"])]
    cz = [(tt, 0) for tt, s in ticks]
    for t, e in ev + cz: recs.append((g, round(t, 6), e))
    assert len(ev) + len(cz) == N, (g, len(ev), len(cz))
    assert all(r["n_implied"] == r["n_from_ticks"] for r in rows), g

df = pd.DataFrame(recs, columns=["group", "observed_time", "event"]).sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
tmp = f"{out}/ipd.csv.tmp"; df.to_csv(tmp, index=False); os.replace(tmp, f"{out}/ipd.csv")
json.dump({"risk_table": risk, "drops": diag}, open(f"{out}/drop_diagnostics.json", "w"), indent=1)
print("wrote", len(df), df.groupby("group").event.agg(["size", "sum"]).to_dict())
