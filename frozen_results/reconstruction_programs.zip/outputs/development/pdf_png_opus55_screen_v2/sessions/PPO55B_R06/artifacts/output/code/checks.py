"""Verify the committed ipd.csv against the extracted measurements.

Usage: python checks.py [path/to/input_dir] [output_dir]
Reloads ipd.csv, recomputes the right-continuous KM step function per arm and
compares it with the measured step path, the risk table, arm sizes, event
indicators and censor ticks. Writes checks.json.
"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
INP = (Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "../../../input").resolve()
OUT = (Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / "..").resolve()

manifest = json.load(open(INP / "manifest.json"))
obs = json.load(open(OUT / "extracted_observations.json"))
csv_path = OUT / "ipd.csv"
sha = hashlib.sha256(open(csv_path, "rb").read()).hexdigest()
ipd = pd.read_csv(csv_path)
cal = obs["calibration"]
t_of = lambda x: cal["time_per_pt"] * x + cal["time_intercept"]
s_of = lambda y: cal["surv_per_pt"] * y + cal["surv_intercept"]

# Vector coordinates are stored to 0.01 pt = 5.6e-5 survival units; allow
# 1e-3 (about 18 such rounding units) for accumulated rounding over ~80 steps.
TOL_S = 1e-3
# ipd.csv stores times to 4 decimals (up to 5e-5 after the unrounded drop);
# "at drop" values are evaluated EPS_T later, below the 0.001-month source
# resolution (0.01 pt).
EPS_T = 1e-4


def km_step(df):
    """Right-continuous KM: returns function S(t) = prod_{t_j <= t}(1 - d_j/n_j)."""
    ts = np.sort(df.loc[df.event == 1, "observed_time"].unique())
    T = df.observed_time.values
    E = df.event.values
    s, surv = 1.0, []
    for t in ts:
        n = (T >= t).sum()
        d = ((T == t) & (E == 1)).sum()
        s *= 1 - d / n
        surv.append(s)
    surv = np.array(surv)

    def S(t):
        k = np.searchsorted(ts, t, side="right")
        return 1.0 if k == 0 else float(surv[k - 1])
    return S, ts


def measured_step(verts):
    """Right-continuous step function from the drawn path; None beyond its end."""
    v = [(t_of(x), s_of(y)) for x, y in verts]
    t_end = v[-1][0]

    def S(t):
        if t > t_end + 1e-9:
            return None
        val = v[0][1]
        for (t0, s0), (t1, s1) in zip(v[:-1], v[1:]):
            if t0 <= t + 1e-9:
                val = s1 if abs(t0 - t1) < 1e-9 else s0
                if t1 <= t + 1e-9:
                    val = s1
        return val
    return S, t_end


out = {"ipd_sha256": sha, "csv": "ipd.csv", "tolerance_survival": TOL_S,
       "tolerance_justification": "PDF vector coordinates rounded to 0.01 pt (5.6e-5 in S); "
                                  "1e-3 allows accumulated rounding over all steps",
       "time_offset_at_drops": EPS_T,
       "event_totals": "unavailable (not supplied in manifest)",
       "groups": {}}
all_pass = True
for g, N in manifest["groups"].items():
    df = ipd[ipd.group == g]
    G = obs["groups"][g]
    S_km, ev_times = km_step(df)
    S_meas, t_end = measured_step(G["vertices_pt"])
    res = {"n_records": int(len(df)), "n_expected": N, "n_pass": bool(len(df) == N),
           "event_values_ok": bool(set(df.event.unique()) <= {0, 1}),
           "times_finite_nonneg": bool(np.isfinite(df.observed_time).all() and (df.observed_time >= 0).all()),
           "n_events": int(df.event.sum()), "n_censored": int((df.event == 0).sum()),
           "event_total_check": "unavailable",
           "measured_curve_end_time": t_end}
    # survival comparisons: a grid, each drop time (right-continuous value),
    # just before each drop, and the tail
    drops = [d["time"] for d in G["drops"]]
    grid = sorted(set([0.0, 0.25, 0.5] + list(np.arange(1, 36, 1.0)) +
                      [drops[-1] + EPS_T, drops[-1] - 0.01, t_end - 0.01, t_end, t_end + 0.5]))
    comps = []
    for t in grid:
        m = S_meas(t)
        r = S_km(t)
        if m is None:
            comps.append({"time": round(t, 4), "measured": None, "reconstructed": r,
                          "status": "unavailable (beyond drawn curve)"})
            continue
        ok = abs(r - m) <= TOL_S
        comps.append({"time": round(t, 4), "measured": round(m, 6), "reconstructed": round(r, 6),
                      "residual": round(r - m, 6), "status": "pass" if ok else "fail"})
    # every drop, at the drop and immediately before it
    drop_resid = []
    for d in G["drops"]:
        drop_resid.append(abs(S_km(d["time"] + EPS_T) - d["S_after"]))
        drop_resid.append(abs(S_km(d["time"] - 1e-4) - d["S_before"]))
    res["survival_grid"] = comps
    res["all_drops_max_abs_residual"] = float(max(drop_resid))
    res["all_drops_status"] = "pass" if max(drop_resid) <= TOL_S else "fail"
    res["km_event_times_match_drops"] = bool(len(ev_times) == len(drops) and
                                              np.allclose(ev_times, drops, atol=1e-3))
    # censor ticks vs censored records
    tick_t = np.sort([c["time"] for c in G["censor_ticks"]])
    ct = np.sort(df.loc[df.event == 0, "observed_time"].values)
    res["censor_ticks"] = int(len(tick_t))
    res["censor_times_match_ticks"] = bool(len(ct) == len(tick_t) and np.allclose(ct, tick_t, atol=1e-3))
    # tick vertical position lies on the curve at that time
    res["tick_on_curve_max_abs"] = float(max(abs(S_meas(c["time"]) - c["S_at_mid"])
                                             for c in G["censor_ticks"]))
    # risk table: count observed_time >= t
    rt = []
    for r in obs["risk_table"][g]:
        n_rec = int((df.observed_time >= r["time"]).sum())
        rt.append({"time": r["time"], "table": r["n"], "reconstructed": n_rec,
                   "residual": n_rec - r["n"], "status": "pass" if n_rec == r["n"] else "fail"})
    res["risk_table"] = rt
    res["max_observed_time"] = float(df.observed_time.max())
    g_pass = (res["n_pass"] and res["event_values_ok"] and res["times_finite_nonneg"]
              and all(c["status"] in ("pass",) or c["status"].startswith("unavailable") for c in comps)
              and res["all_drops_status"] == "pass" and res["km_event_times_match_drops"]
              and res["censor_times_match_ticks"] and all(x["status"] == "pass" for x in rt))
    res["overall"] = "pass" if g_pass else "fail"
    all_pass &= g_pass
    out["groups"][g] = res
out["overall"] = "pass" if all_pass else "fail"
json.dump(out, open(OUT / "checks.json", "w"), indent=1)
for g, r in out["groups"].items():
    print(g, r["overall"], "n", r["n_records"], "events", r["n_events"], "drop max resid",
          r["all_drops_max_abs_residual"], "tick on curve", r["tick_on_curve_max_abs"],
          "risk", [(x["time"], x["table"], x["reconstructed"]) for x in r["risk_table"]])
    print("  tail", [c for c in r["survival_grid"] if c["time"] > 33])
print("overall", out["overall"], sha)
