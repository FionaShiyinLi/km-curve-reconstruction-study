"""Measurement step: extract calibrated KM step vertices, censor ticks and the
number-at-risk table from the vector PDF. No correction is applied here.

Usage: python extract.py [path/to/figure.pdf] [output_dir]
"""
import json
import sys
from pathlib import Path

import numpy as np
import pdfplumber

HERE = Path(__file__).resolve().parent
PDF = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "../../../input/figure.pdf"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / ".."

page = pdfplumber.open(str(PDF)).pages[0]
words = page.extract_words()
BLACK = (0.0, 0.0, 0.0)

# ---- axis calibration from labelled tick marks -------------------------------
ax_lines = [l for l in page.lines if tuple(l["stroking_color"]) == BLACK]
xticks = sorted({round(l["x0"], 3) for l in ax_lines
                 if abs(l["x0"] - l["x1"]) < 1e-6 and abs(l["bottom"] - l["top"] - 3) < 0.01})
yticks = sorted({round(l["top"], 3) for l in ax_lines
                 if abs(l["top"] - l["bottom"]) < 1e-6 and abs(l["x1"] - l["x0"] - 3) < 0.01})


def label_near(pos, axis):
    best = None
    for w in words:
        try:
            v = float(w["text"])
        except ValueError:
            continue
        if axis == "x":
            if not (225 < w["top"] < 235):
                continue
            d = abs((w["x0"] + w["x1"]) / 2 - pos)
        else:
            if not (w["x1"] < 62):
                continue
            d = abs((w["top"] + w["bottom"]) / 2 - pos)
        if best is None or d < best[0]:
            best = (d, v)
    return best[1]


xl = np.array([label_near(x, "x") for x in xticks])
yl = np.array([label_near(y, "y") for y in yticks])
bx = np.polyfit(np.array(xticks), xl, 1)   # time = bx0*x + bx1
by = np.polyfit(np.array(yticks), yl, 1)   # surv = by0*top + by1
resx = np.polyval(bx, xticks) - xl
resy = np.polyval(by, yticks) - yl
t_of = lambda x: float(np.polyval(bx, x))
s_of = lambda y: float(np.polyval(by, y))

# ---- legend: colour -> group ------------------------------------------------
colour_group = {}
for l in page.lines:
    if abs(l["top"] - 20.0) < 0.5 and l["x1"] - l["x0"] > 10:
        # legend swatch; nearest following "A"/"B" word
        cands = [w for w in words if w["text"] in ("A", "B") and abs(w["top"] - 16.16) < 1
                 and w["x0"] > l["x1"]]
        w = min(cands, key=lambda w: w["x0"] - l["x1"])
        colour_group[tuple(l["stroking_color"])] = w["text"]

data = {"calibration": {
    "x_ticks_pt": xticks, "x_labels": xl.tolist(), "time_per_pt": bx[0], "time_intercept": bx[1],
    "x_fit_max_abs_resid": float(np.abs(resx).max()),
    "y_ticks_pt": yticks, "y_labels": yl.tolist(), "surv_per_pt": by[0], "surv_intercept": by[1],
    "y_fit_max_abs_resid": float(np.abs(resy).max())},
    "groups": {}}

for curve in page.curves:
    col = tuple(curve["stroking_color"])
    g = colour_group[col]
    pts = [(round(x, 4), round(y, 4)) for x, y in curve["pts"]]
    steps = []   # vertical segments = drops
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x0 - x1) < 1e-9 and y1 > y0:
            steps.append({"x_pt": x0, "time": t_of(x0), "top_before": y0, "top_after": y1,
                          "S_before": s_of(y0), "S_after": s_of(y1)})
    ticks = []
    for l in page.lines:
        if tuple(l["stroking_color"]) != col or abs(l["x0"] - l["x1"]) > 1e-9:
            continue
        mid = (l["top"] + l["bottom"]) / 2
        ticks.append({"x_pt": round(l["x0"], 4), "time": t_of(l["x0"]), "mid_top": mid,
                      "S_at_mid": s_of(mid)})
    ticks.sort(key=lambda d: d["time"])
    data["groups"][g] = {
        "colour": col, "start": {"time": t_of(pts[0][0]), "S": s_of(pts[0][1])},
        "end": {"time": t_of(pts[-1][0]), "S": s_of(pts[-1][1])},
        "vertices_pt": pts, "drops": steps, "censor_ticks": ticks}

# ---- number at risk table ----------------------------------------------------
risk = {}
for g in ("A", "B"):
    row = [w for w in words if w["text"] == "Group" and w["top"] > 280]
    rows = {}
    for w in row:
        lab = [v for v in words if abs(v["top"] - w["top"]) < 1 and v["text"] in ("A", "B")][0]["text"]
        nums = [v for v in words if abs(v["top"] - w["top"]) < 1 and v["text"].isdigit()]
        rows[lab] = [{"time": round(t_of((v["x0"] + v["x1"]) / 2)), "x_center_time": t_of((v["x0"] + v["x1"]) / 2),
                      "n": int(v["text"])} for v in sorted(nums, key=lambda v: v["x0"])]
    risk = rows
data["risk_table"] = risk

with open(OUT / "extracted_observations.json", "w") as f:
    json.dump(data, f, indent=1)
print(json.dumps(data["calibration"], indent=1))
for g, d in data["groups"].items():
    print(g, d["colour"], "drops", len(d["drops"]), "ticks", len(d["censor_ticks"]), d["start"], d["end"])
print(risk)
