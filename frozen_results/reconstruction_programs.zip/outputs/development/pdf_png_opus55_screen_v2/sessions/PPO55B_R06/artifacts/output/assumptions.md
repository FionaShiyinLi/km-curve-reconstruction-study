# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`: a vector PDF (one page, no raster images).
- `../input/manifest.json`: N = 100 per arm, time unit months, code seed 1019317259.
- The manifest has no arm-specific event totals, so that check is marked unavailable. No other auxiliary information was used.

## Measurement (`code/extract.py`, saved output `extracted_observations.json`)
- **Calibration.** Time and survival were calibrated by linear fits to the labelled axis tick marks: x ticks labelled 0, 6, ..., 36 months, and y ticks labelled 0.0, 0.2, ..., 1.0. Both fits are exact (maximum residual below 1e-13). No global rescaling or other correction was applied.
- **Arm identity.** Each arm was identified from its legend swatch colour: blue is A and orange is B.
- **Curve geometry.** Each arm is a single path of step vertices, and each vertical segment was taken as a drop. Both curves start exactly at (0, 1.000), so no origin correction was needed. Genuine early drops are preserved; the first ones are at 0.214 months in A and 0.044 months in B.
- **Censor marks.** These are vertical ticks, 4 pt long, in the arm's colour. There were 23 in A and 42 in B. I checked for ticks drawn more than once at identical coordinates and found none. Every tick midpoint lies on its arm's curve, to within 1e-15.
- **Risk table.** The "number at risk" table was read from the PDF text layer at 0, 6, ..., 36 months.
- **Resolution.** Coordinates are stored to 0.01 pt, which is 0.00104 months in time and 5.6e-5 in survival.

## Reconstruction (`code/reconstruct.py`)
- **Event counts.** At each drop, the number at risk was computed as N minus the earlier events minus the censorings strictly earlier. A censoring tied with an event would stay at risk, but no tick coincides with a drop. The event count is then d = n_risk·(1 − S_after/S_before), rounded to an integer.
  - Every unrounded d was within 6e-5 of 1, giving 77 events in A and 58 in B.
  - d = 1 was **not assumed**. It follows from the counted risk sets. A drop with d = 2 would need twice as many at risk as the preceding counts allow.
  - A censoring hidden in overlapping ticks would lower later risk sets. That would make later d values non-integer and break the risk-table agreement.
- **Censored records.** Each tick became one censored record at the tick's time. Events plus ticks come to exactly 100 in each arm, so no participant is left unaccounted for.
  - The script has a fallback rule for unmarked survivors (censor at the end of the drawn curve), but it was not triggered.
  - No follow-up beyond the last drawn point was invented. The last records are at 35.158 months in A and 35.859 months in B, both censorings drawn at the curve ends.
- **Randomness.** The algorithm is deterministic. The seed is set and recorded anyway.
- **Output format.** Times are written to 4 decimals. The CSV was written to a temporary file and renamed into place atomically.

## Risk table and checks (`code/checks.py`, output `checks.json`)
- **Risk table.** For each table time t, I counted records with observed_time ≥ t. The reconstruction matches all 14 displayed counts exactly, including 0 at 36 months, because every record is below 36.
- **Survival curve.**
  - The right-continuous KM curve recomputed from the saved CSV matches the measured step path at a 1-month grid and at 0.25 and 0.5 months.
  - It also matches just before and just after every drop, and at the tail: around each arm's last drop and at the curve end.
  - The maximum absolute difference is about 3e-7, against a tolerance of 1e-3.
  - Because the CSV rounds times to 4 decimals, values "at the drop" are taken 1e-4 months after the drop. This is below the source's time resolution.
- **Other checks.** Censored times match tick times to 1e-3 months. Arm sizes and 0/1 event indicators were also checked.
- **Beyond the curves.** After the end of each drawn curve, the comparisons are marked unavailable.

## Limitations
- **Time precision.** Times are recovered only to the PDF coordinate precision, about 0.001 months. The original data may have had tied times that were drawn with coincident vertices; within that resolution, ties at identical x would have been merged into multi-event drops, and none were found.
- **Sensitivity analysis not run.** I found no materially different allocation consistent with the inputs. Every drop is a single event under the counted risk sets, every tick is a single censoring, and nobody is left unassigned. `sensitivity.csv` was therefore not produced. This is a statement about consistency with the displayed figure, not an error bound on the original data.
- **Scope.** No covariates or event histories beyond the displayed curve were constructed. The analysis includes no hazard ratio, RMST or other summary statistic.
