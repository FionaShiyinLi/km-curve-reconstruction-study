"""Reconstruct participant-level records from the extracted KM vector geometry.

Usage: python reconstruct.py [path/to/input_dir] [output_dir]
  input_dir must contain figure.pdf and manifest.json (default ../../../input
  relative to this file); output_dir defaults to the parent of this file.

Algorithm (deterministic; the seed is recorded but no randomness is used):
  * each vertical segment of an arm's step path is an event time;
  * each coloured vertical tick of that arm is one censoring at the tick's x;
  * at each drop, n_risk = N - earlier events - censorings strictly earlier
    (censorings tied with an event remain at risk); the event count is
    d = n_risk * (1 - S_after / S_before), rounded, and the unrounded value
    and its residual are logged for inspection;
  * anyone not accounted for by drops or ticks would be allocated by an
    explicit rule, but in this figure the remainder is zero in both arms.
"""
import csv
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
INP = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "../../../input"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / ".."
INP, OUT = INP.resolve(), OUT.resolve()

manifest = json.load(open(INP / "manifest.json"))
SEED = manifest["code_seed"]
np.random.seed(SEED)  # recorded; the algorithm below is deterministic

subprocess.run([sys.executable, str(HERE / "extract.py"), str(INP / "figure.pdf"), str(OUT)],
               check=True, stdout=subprocess.DEVNULL)
obs = json.load(open(OUT / "extracted_observations.json"))

TIE = 1e-6
records, log = [], {"seed": SEED, "groups": {}}
for g, N in manifest["groups"].items():
    G = obs["groups"][g]
    cens = sorted(c["time"] for c in G["censor_ticks"])
    events, drops_log = [], []
    for s in G["drops"]:
        t = s["time"]
        n_risk = N - sum(d for _, d in events) - sum(c < t - TIE for c in cens)
        q = 1 - s["S_after"] / s["S_before"]
        d_raw = n_risk * q
        d = int(round(d_raw))
        if d < 1:
            raise RuntimeError(f"{g}: drop at {t} implies d<1 (d_raw={d_raw})")
        events.append((t, d))
        drops_log.append({"time": t, "n_risk": n_risk, "rel_drop": q, "d_raw": d_raw, "d": d,
                          "resid": d_raw - d})
    n_ev = sum(d for _, d in events)
    remainder = N - n_ev - len(cens)
    if remainder < 0:
        raise RuntimeError(f"{g}: more events+ticks than participants")
    # Rule for unmarked survivors (not triggered here): censor at the end of
    # the drawn curve, the last time the plot supports follow-up.
    extra = [G["end"]["time"]] * remainder
    ties = [c for c in cens if any(abs(c - t) < TIE for t, _ in events)]
    for t, d in events:
        records += [(g, round(t, 4), 1)] * d
    for c in cens + extra:
        records.append((g, round(c, 4), 0))
    log["groups"][g] = {"N": N, "events": n_ev, "censor_ticks": len(cens),
                        "unmarked_remainder": remainder, "ticks_tied_with_drops": len(ties),
                        "max_abs_d_resid": max(abs(x["resid"]) for x in drops_log),
                        "max_d": max(x["d"] for x in drops_log), "drops": drops_log}

# complete-group check before committing
for g, N in manifest["groups"].items():
    assert sum(r[0] == g for r in records) == N, g
records.sort(key=lambda r: (r[0], r[1], -r[2]))

tmp = OUT / "ipd.csv.tmp"
with open(tmp, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["group", "observed_time", "event"])
    w.writerows(records)
    f.flush()
    os.fsync(f.fileno())
os.replace(tmp, OUT / "ipd.csv")
log["ipd_sha256"] = hashlib.sha256(open(OUT / "ipd.csv", "rb").read()).hexdigest()
json.dump(log, open(OUT / "reconstruction_log.json", "w"), indent=1)
for g, v in log["groups"].items():
    print(g, {k: v[k] for k in v if k != "drops"})
print("sha256", log["ipd_sha256"])
