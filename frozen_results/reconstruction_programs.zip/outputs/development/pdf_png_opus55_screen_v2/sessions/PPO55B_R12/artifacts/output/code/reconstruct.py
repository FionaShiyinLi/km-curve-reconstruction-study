"""Reconstruct participant-level records from the vector KM figure.

Run from the work directory:  python output/code/reconstruct.py [--input ../input/figure.pdf]
    [--manifest ../input/manifest.json] [--outdir output]
Steps: (1) extract step paths / censor ticks / risk table from PDF objects (extract.py);
(2) forward KM pass: at each drop, d = round(n_risk * (1 - S_after/S_before)), with n_risk
counted from records already allocated (censor ticks strictly before the drop leave the risk set);
(3) each censor tick -> one censored record at the tick's time; (4) any participants left after
the last drawn object would be censored at the curve's drawn end (none remain here);
(5) write output/ipd.csv via temp file + atomic rename.
"""
import argparse, json, os, sys, tempfile
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import extract

def reconstruct_group(G, N):
    steps, ticks = G["steps"], G["ticks"]
    recs, diag = [], []
    n, ti, S_rec = N, 0, 1.0
    for s in steps:
        while ti < len(ticks) and ticks[ti]["t"] < s["t"] - 1e-9:
            recs.append((ticks[ti]["t"], 0)); n -= 1; ti += 1
        raw = n * (1 - s["S_after"] / s["S_before"])
        # choose d so the reconstructed cumulative KM best matches the measured post-drop level
        cands = range(max(0, int(np.floor(raw)) - 1), int(np.ceil(raw)) + 2)
        d = min(cands, key=lambda k: abs(S_rec * (1 - k / n) - s["S_after"]))
        if d == 0:
            raise RuntimeError(f"drawn drop with d=0 at t={s['t']}")
        S_rec *= 1 - d / n
        recs += [(s["t"], 1)] * d
        diag.append({"t": s["t"], "n_risk": n, "d_raw": raw, "d": d})
        n -= d
    while ti < len(ticks):  # ticks at/after last drop (none coincide with a drop time)
        recs.append((ticks[ti]["t"], 0)); n -= 1; ti += 1
    if n < 0:
        raise RuntimeError("more records than participants")
    extra = n
    recs += [(G["end"][0], 0)] * n  # unticked remainder censored at drawn curve end
    return recs, diag, extra

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input/figure.pdf")
    ap.add_argument("--manifest", default="../input/manifest.json")
    ap.add_argument("--outdir", default="output")
    a = ap.parse_args()
    man = json.load(open(a.manifest))
    np.random.seed(man["code_seed"])  # recorded; the algorithm itself is deterministic
    ex = extract.run(a.input, a.outdir)
    rows, summ = [], {}
    for g in ("A", "B"):
        N = man["groups"][g]
        recs, diag, extra = reconstruct_group(ex["groups"][g], N)
        assert len(recs) == N, (g, len(recs), N)
        rows += [(g, t, e) for t, e in recs]
        summ[g] = {"N": N, "events": sum(e for _, e in recs), "censored_ticks": len(ex["groups"][g]["ticks"]),
                   "censored_untracked_at_end": extra, "max_abs_d_raw_minus_d": max(abs(x["d_raw"] - x["d"]) for x in diag),
                   "d_counts": {str(k): sum(1 for x in diag if x["d"] == k) for k in sorted({x["d"] for x in diag})}}
    Path(a.outdir, "reconstruction_diagnostics.json").write_text(json.dumps(summ, indent=1))
    fd, tmp = tempfile.mkstemp(dir=a.outdir, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in rows:
            f.write(f"{g},{max(t, 0.0):.6f},{int(e)}\n")
    os.replace(tmp, Path(a.outdir, "ipd.csv"))
    print(json.dumps(summ, indent=1))

if __name__ == "__main__":
    main()
