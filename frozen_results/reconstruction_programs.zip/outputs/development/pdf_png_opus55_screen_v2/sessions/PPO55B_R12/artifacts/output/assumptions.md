# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.pdf` (single vector page; no embedded raster images).
- `../input/manifest.json`: N = 1000 per group, time unit months, code seed 316825054. The manifest has no arm-specific event totals. That is recorded as *unavailable* and is not read as zero events.
- Nothing else was used. No HR, RMST, or standard error was used.

## Measurement
- Everything was read from PDF drawing objects with `pdfplumber` (`code/extract.py`). No pixels were measured. A 150-dpi render (`figure_render-1.png`) was inspected only to confirm that the vector parse captured all visible content.
- Calibration comes from the labelled axis ticks. Time: x = 64.8 pt → 0 and x = 410.4 pt → 36, which is 9.6 pt per month. Survival: y = 223.2 → 0 and y = 43.2 → 1.0. A linear fit to all 7 (time) and 6 (survival) label/tick pairs gives maximum residuals of about 1e-15. No global correction or rescaling was applied.
- Arm identity comes from the legend line colors: blue (0.12, 0.47, 0.71) is Group A and orange (1.0, 0.50, 0.05) is Group B.
- Each arm is one monotone step path with no diagonal segments. Each path starts exactly at (t = 0, S = 1). The first drop is at t ≈ 0.012 months in A and ≈ 0.01 months in B. These genuine early drops were kept as drawn.
- Censor marks are 4-pt vertical line objects in the arm's color: 213 in A and 296 in B. Every mark is centered on its own arm's curve (deviation < 1e-15 in S). No two marks share an x-coordinate, and no mark falls at a drop time. Marks overlap visually after about 24 months. Multiplicity therefore comes from counting objects, not from what is visible.
- The extracted paths, ticks, and risk table are saved in `extracted.json`.

## Algorithm (`code/reconstruct.py`)
- The method is a forward Kaplan–Meier pass in time order.
- Before each drop, censor ticks that lie strictly earlier are removed from the risk set. Each one becomes a censored record at the tick's time.
- At each drawn drop, d is the integer that brings the cumulative reconstructed KM closest to the measured post-drop level. The raw value n_risk·(1 − S_after/S_before) was within 5.4e-4 of an integer at every drop, and that integer was 1 at every drop. d = 1 was therefore derived from the relation S_after/S_before = 1 − d/n_risk, with n_risk counted independently. It was not assumed.
- The code censors any participants left after all drawn objects at the curve's drawn end. Here the remainder was 0 in both arms: A has 787 events + 213 censored and B has 704 + 296.
- Output times are the calibrated coordinates rounded to 1e-6 months.
- The algorithm is deterministic. The seed is set and recorded but does not affect results.
- The CSV is written to a temporary file and then atomically renamed.

## Risk table
- Readings from PDF text: A = 1000, 665, 459, 312, 217, 68, 0 and B = 1000, 751, 568, 419, 303, 112, 0, at 0, 6, …, 36 months.
- The risk table was not used as a constraint; it was used only for checking.
- In every 6-month interval the drawn ticks exactly equal the censorings the table implies (n_start − n_end − events). For example, A over [24, 30) has 101 ticks and 101 implied censorings. Counting `observed_time >= t` in the saved CSV reproduces all 14 displayed counts exactly.
- The zero at 36 months holds because the last records are at 35.796 (A) and 35.989 (B).

## Checks
Checks are in `checks.json` and come from reloading the committed CSV. For each arm:
- A right-continuous KM was compared with the measured step function at 20 grid times, including 35, 35.5, and the drawn end. It was also compared at the midpoint of every drawn plateau. Maximum absolute residual: 2.8e-7. The tolerance is 1e-5, which is justified by the vector coordinate precision.
- The tail level at the maximum observed time matches the drawn end within 2e-7.
- Censored-record times match tick times within 5e-7.
- Arm sizes, 0/1 event indicators, and finite nonnegative times all pass.

## Limitations
- Times are recovered only to the precision of the drawn coordinates. If the source data were on a coarser grid, such as days, that discretization is not recovered.
- Two censorings at exactly the same coordinate, drawn as a single tick object, could not be distinguished in the PDF. There is no evidence of this: the counts reconcile exactly with the risk table in every interval. It still cannot be excluded at sub-interval resolution.
- No covariates or other follow-up information were inferred.
- Sensitivity analysis was not run. The drawn events, ticks, and risk table jointly allow only this one allocation up to coordinate precision, so no materially different allocation was available to test. A single alternative would in any case not bound reconstruction error.
