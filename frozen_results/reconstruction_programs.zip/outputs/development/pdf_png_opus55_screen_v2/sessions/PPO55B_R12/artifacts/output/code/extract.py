"""Extract KM step paths, censor ticks and risk table from the vector PDF.
Usage: python extract.py [--input ../input/figure.pdf] [--outdir output]
"""
import argparse, json
from pathlib import Path
import pdfplumber

BLUE = (0.121569, 0.466667, 0.705882)   # legend line next to "Group A"
ORANGE = (1.0, 0.498039, 0.054902)      # legend line next to "Group B"
COL = {BLUE: "A", ORANGE: "B"}

def calib(pg):
    """Axis calibration from labelled tick marks (PDF top-down y)."""
    words = pg.extract_words()
    lines = pg.lines
    xt = sorted({round(l["x0"], 4) for l in lines if l["stroking_color"] == (0, 0, 0)
                 and l["x0"] == l["x1"] and l["top"] >= 223.19 and l["bottom"] - l["top"] < 5})
    yt = sorted({round(l["top"], 4) for l in lines if l["stroking_color"] == (0, 0, 0)
                 and l["top"] == l["bottom"] and l["x1"] - l["x0"] < 5})
    xlab = sorted([(w["x0"] + w["x1"]) / 2, float(w["text"])] for w in words
                  if 229 < w["top"] < 231 and w["text"].isdigit())
    ylab = sorted([(w["top"] + w["bottom"]) / 2, float(w["text"])] for w in words
                  if w["x0"] < 44 and w["x1"] < 58 and w["text"].replace(".", "").isdigit())
    # match each labelled value to nearest tick mark
    xa = [(min(xt, key=lambda t: abs(t - c)), v) for c, v in xlab]
    ya = [(min(yt, key=lambda t: abs(t - c)), v) for c, v in ylab]
    def fit(pairs):
        n = len(pairs); mx = sum(p for p, _ in pairs) / n; mv = sum(v for _, v in pairs) / n
        b = sum((p - mx) * (v - mv) for p, v in pairs) / sum((p - mx) ** 2 for p, _ in pairs)
        a = mv - b * mx
        res = max(abs(a + b * p - v) for p, v in pairs)
        return a, b, res
    return fit(xa), fit(ya), xa, ya

def run(input_pdf, outdir):
    pg = pdfplumber.open(input_pdf).pages[0]
    (xa, xb, xres), (ya, yb, yres), xanch, yanch = calib(pg)
    T = lambda x: xa + xb * x
    S = lambda y: ya + yb * y
    out = {"calibration": {"time": [xa, xb, xres, xanch], "surv": [ya, yb, yres, yanch]}, "groups": {}}
    for c in pg.curves:
        g = COL[c["stroking_color"]]
        pts = c["pts"]
        # collapse to steps: vertical runs at a fixed x are drops
        drops = []
        for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
            if abs(x1 - x0) < 1e-9 and y1 != y0:
                if drops and abs(drops[-1][0] - x0) < 1e-9:
                    drops[-1][2] = y1
                else:
                    drops.append([x0, y0, y1])
        steps = [{"x": x, "t": T(x), "S_before": S(y0), "S_after": S(y1)} for x, y0, y1 in drops]
        ticks = []
        for l in pg.lines:
            if l["stroking_color"] == c["stroking_color"] and l["linewidth"] < 0.9:
                ticks.append({"x": l["x0"], "t": T(l["x0"]), "S_center": S((l["top"] + l["bottom"]) / 2)})
        ticks.sort(key=lambda d: d["x"])
        out["groups"][g] = {"start": [T(pts[0][0]), S(pts[0][1])], "end": [T(pts[-1][0]), S(pts[-1][1])],
                            "steps": steps, "ticks": ticks}
    # risk table
    words = pg.extract_words()
    head = [w for w in words if 229 < w["top"] < 231 and w["text"].isdigit()]
    rt = {}
    for g, top in (("A", 283.92), ("B", 297.92)):
        row = [w for w in words if abs(w["top"] - top) < 0.5 and w["text"].isdigit() and w["x0"] > 50]
        rt[g] = []
        for w in sorted(row, key=lambda w: w["x0"]):
            cx = (w["x0"] + w["x1"]) / 2
            h = min(head, key=lambda h: abs((h["x0"] + h["x1"]) / 2 - cx))
            rt[g].append([float(h["text"]), int(w["text"])])
    out["risk_table"] = rt
    Path(outdir).mkdir(parents=True, exist_ok=True)
    Path(outdir, "extracted.json").write_text(json.dumps(out, indent=1))
    print(json.dumps(out["calibration"]), json.dumps(rt))
    for g, d in out["groups"].items():
        print(g, "start", d["start"], "end", d["end"], "drops", len(d["steps"]), "ticks", len(d["ticks"]))
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="../input/figure.pdf")
    ap.add_argument("--outdir", default="output")
    a = ap.parse_args()
    run(a.input, a.outdir)

if __name__ == "__main__":
    main()
