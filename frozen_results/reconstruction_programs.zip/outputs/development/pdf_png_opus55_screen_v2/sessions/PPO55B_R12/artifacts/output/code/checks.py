"""Reload committed output/ipd.csv and compare with the measured figure. Writes output/checks.json.
Run from the work directory: python output/code/checks.py [--outdir output]"""
import argparse, hashlib, json
from pathlib import Path
import numpy as np, pandas as pd

TOL_S = 1e-5  # survival tolerance: PDF path coordinates carry >=4 decimals of a point; 1e-4 pt = 5.6e-7 in S

def km(df):
    """Right-continuous KM: returns (unique event times, S just after)."""
    t = df.observed_time.to_numpy(); e = df.event.to_numpy()
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append(S)
    return ut, np.array(out)

def step_eval(times, vals, q):
    i = np.searchsorted(times, q, side="right") - 1
    return np.where(i >= 0, vals[np.clip(i, 0, None)], 1.0)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--outdir", default="output")
    ap.add_argument("--manifest", default="../input/manifest.json"); a = ap.parse_args()
    csv = Path(a.outdir, "ipd.csv"); ex = json.load(open(Path(a.outdir, "extracted.json")))
    man = json.load(open(a.manifest))
    df = pd.read_csv(csv)
    res = {"csv_sha256": hashlib.sha256(csv.read_bytes()).hexdigest(), "survival_tolerance": TOL_S,
           "tolerance_justification": "vector path coordinates; calibration residual ~1e-15; coordinate rounding << 1e-5 in S",
           "columns_ok": list(df.columns) == ["group", "observed_time", "event"], "groups": {}}
    for g in ("A", "B"):
        d = df[df.group == g]; G = ex["groups"][g]
        mt = np.array([s["t"] for s in G["steps"]]); ms = np.array([s["S_after"] for s in G["steps"]])
        ut, us = km(d)
        grid = sorted(set([0.0, 0.5, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 34, 35, 35.5,
                           round(G["end"][0] - 1e-4, 6), round(G["end"][0], 6)]))
        comp = []
        for q in grid:
            m = float(step_eval(mt, ms, q)); r = float(step_eval(ut, us, q))
            comp.append({"t": q, "measured": round(m, 7), "reconstructed": round(r, 7), "residual": round(r - m, 9),
                         "status": "pass" if abs(r - m) <= TOL_S else "fail"})
        # every drawn plateau, evaluated at the midpoint between consecutive drops (CSV times are
        # rounded to 1e-6 months, so evaluating exactly at an unrounded drop coordinate is ill-posed)
        mids = (mt + np.append(mt[1:], G["end"][0])) / 2
        allres = step_eval(ut, us, mids) - step_eval(mt, ms, mids)
        # risk table: count observed_time >= t
        rt = []
        for t, nshow in ex["risk_table"][g]:
            nr = int((d.observed_time >= t).sum())
            rt.append({"t": t, "table": nshow, "reconstructed": nr, "residual": nr - nshow,
                       "status": "pass" if nr == nshow else "fail"})
        tks = G["ticks"]; cens = np.sort(d.observed_time[d.event == 0].to_numpy())
        res["groups"][g] = {
            "n_records": int(len(d)), "n_manifest": man["groups"][g], "n_status": "pass" if len(d) == man["groups"][g] else "fail",
            "event_values_ok": bool(d.event.isin([0, 1]).all()), "times_finite_nonneg": bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
            "events": int(d.event.sum()), "supplied_event_total": "unavailable (not in manifest)",
            "drawn_drops": len(mt), "km_event_times": len(ut),
            "survival_grid": comp,
            "all_plateau_midpoints": {"n": int(len(mt)), "max_abs_residual": float(np.abs(allres).max()),
                                "status": "pass" if np.abs(allres).max() <= TOL_S and len(ut) == len(mt) else "fail"},
            "tail": {"measured_curve_end_t": G["end"][0], "measured_curve_end_S": G["end"][1],
                     "max_observed_time": float(d.observed_time.max()),
                     "reconstructed_S_at_max": float(step_eval(ut, us, d.observed_time.max())),
                     "status": "pass" if abs(float(step_eval(ut, us, d.observed_time.max())) - G["end"][1]) <= TOL_S else "fail"},
            "censor_ticks": {"drawn": len(tks), "censored_records": int(len(cens)),
                             "max_abs_time_diff": float(np.abs(cens - np.array([k["t"] for k in tks])).max()) if len(cens) == len(tks) else None,
                             "status": "pass" if len(cens) == len(tks) else "fail"},
            "risk_table": rt}
    Path(a.outdir, "checks.json").write_text(json.dumps(res, indent=1))
    for g, r in res["groups"].items():
        print(g, r["n_status"], r["events"], r["all_plateau_midpoints"], r["tail"], r["censor_ticks"],
              [x["status"] for x in r["risk_table"]], {x["status"] for x in r["survival_grid"]})
    print(res["csv_sha256"])

if __name__ == "__main__":
    main()
