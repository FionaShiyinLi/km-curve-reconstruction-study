"""KM-to-IPD reconstruction from the vector paths of ../input/figure.pdf.

Usage: python3 output/code/reconstruct.py [--input ../input] [--out output]
Deterministic; the supplied seed is set and recorded but no random draws are needed
for the primary allocation.
"""
import argparse, json, hashlib, os, random
import numpy as np, pandas as pd, pdfplumber

SEED = 693742476
random.seed(SEED); np.random.seed(SEED)

ap = argparse.ArgumentParser()
ap.add_argument("--input", default="../input")
ap.add_argument("--out", default="output")
ap.add_argument("--stage", default="all")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
man = json.load(open(os.path.join(args.input, "manifest.json")))
pg = pdfplumber.open(os.path.join(args.input, "figure.pdf")).pages[0]

# ---------- axis calibration from labelled tick marks ----------
chars = pg.chars
def words(ymin, ymax):
    out, cur = [], None
    for c in sorted([c for c in chars if ymin <= c["top"] <= ymax], key=lambda c: c["x0"]):
        if cur and abs(c["x0"] - cur["x1"]) < 0.5:
            cur["text"] += c["text"]; cur["x1"] = c["x1"]
        else:
            cur = dict(text=c["text"], x0=c["x0"], x1=c["x1"], top=c["top"], bottom=c["bottom"]); out.append(cur)
    return out
blk = [l for l in pg.lines if l["stroking_color"] in [(0, 0, 0), (0.0, 0.0, 0.0)]]
xt = sorted([l for l in blk if abs(l["x0"] - l["x1"]) < 1e-6 and l["top"] > 222], key=lambda l: l["x0"])
yt = sorted([l for l in blk if abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 5], key=lambda l: l["top"])
xlab = [w for w in words(229, 231)]
ylab = [w for w in chars if w["x0"] < 45]  # first char of y labels; full labels parsed below
ylabs = sorted({round(c["top"], 2) for c in chars if 40 < c["x0"] < 58 and c["top"] < 225})
ylabtxt = ["".join(c["text"] for c in sorted([c for c in chars if 40 < c["x0"] < 58 and round(c["top"], 2) == t], key=lambda c: c["x0"])) for t in ylabs]
xpairs = []
for w in xlab:
    xc = (w["x0"] + w["x1"]) / 2
    tk = min(xt, key=lambda l: abs(l["x0"] - xc))
    xpairs.append((float(w["text"]), tk["x0"]))
ypairs = []
for t, txt in zip(ylabs, ylabtxt):
    yc = t + 4.5
    tk = min(yt, key=lambda l: abs(l["top"] - yc))
    ypairs.append((float(txt), tk["top"]))
xp = np.array(xpairs); yp = np.array(ypairs)
bx = np.polyfit(xp[:, 1], xp[:, 0], 1); by = np.polyfit(yp[:, 1], yp[:, 0], 1)
calib = dict(x_pairs=xpairs, y_pairs=ypairs, t_per_pt=bx[0], t_at_0=bx[1], s_per_pt=by[0], s_at_0=by[1],
             x_resid_max=float(np.abs(np.polyval(bx, xp[:, 1]) - xp[:, 0]).max()),
             y_resid_max=float(np.abs(np.polyval(by, yp[:, 1]) - yp[:, 0]).max()))
T = lambda x: float(np.polyval(bx, x)); S = lambda y: float(np.polyval(by, y))

# ---------- legend: map colour -> group ----------
leg = [l for l in pg.lines if l["top"] < 30 and l["stroking_color"] not in [(0, 0, 0)]]
legw = [w for w in words(0, 30) if w["text"].startswith("Group")]
# 'Group A' / 'Group B' may be split by space; rebuild with chars on legend row
row = sorted([c for c in chars if c["top"] < 30], key=lambda c: c["x0"])
txt = "".join(c["text"] for c in row)
col2grp = {}
for l in leg:
    after = [c for c in row if c["x0"] > l["x1"]]
    s = "".join(c["text"] for c in after)[:8]
    col2grp[tuple(l["stroking_color"])] = s.replace("Group", "").strip()[0]

# ---------- risk table ----------
rt_rows = {}
for gname in ["A", "B"]:
    lab = [c for c in chars if c["x0"] < 60 and c["top"] > 260]
tops = sorted({round(c["top"], 1) for c in chars if c["top"] > 262})
risk = {}
for t in tops:
    rowc = sorted([c for c in chars if round(c["top"], 1) == t], key=lambda c: c["x0"])
    s = "".join(c["text"] for c in rowc)
    if s.startswith("Group"):
        g = s[6]
        nums = [w for w in words(t - 0.05, t + 0.05) if w["x0"] > 52 and w["text"].isdigit()]
        risk[g] = [(round(T((w["x0"] + w["x1"]) / 2) / 6) * 6, int(w["text"])) for w in nums]

# ---------- curves and censor ticks ----------
curves = {}
for cv in pg.curves:
    g = col2grp[tuple(cv["stroking_color"])]
    pts = [(T(x), S(y)) for x, y in cv["pts"]]
    curves[g] = pts
ticks = {"A": [], "B": []}
for l in pg.lines:
    c = tuple(l["stroking_color"])
    if c in col2grp and abs(l["x0"] - l["x1"]) < 1e-6 and l["top"] > 30:
        ticks[col2grp[c]].append((T(l["x0"]), S((l["top"] + l["bottom"]) / 2)))

def drops(pts):
    out = []
    for (x0, y0), (x1, y1) in zip(pts[:-1], pts[1:]):
        if abs(x1 - x0) < 1e-9 and y1 < y0 - 1e-9:
            out.append((x0, y0, y1))
    return out

# ---------- reconstruction ----------
def reconstruct(g, N, tick_list, dr, verbose=False):
    """Sequential KM inversion. n_risk at each drop = N - prior events - prior censorings.
    Censorings = visible ticks (one record per drawn tick object) strictly before the drop time
    (ticks tied with a drop are placed after the events, KM convention). For each drop d is
    chosen as the integer minimising |S_before*(1-d/n) - S_after| with n from the tick count;
    the implied-n residual is recorded as a diagnostic of hidden censorings."""
    tk = sorted(t for t, s in tick_list)
    rec, diag = [], []
    n = N; ci = 0; Sprev = 1.0
    for (t, sb, sa) in dr:
        while ci < len(tk) and tk[ci] < t - 1e-9:
            rec.append((tk[ci], 0)); n -= 1; ci += 1
        ratio = sa / sb
        d = max(1, int(round(n * (1 - ratio))))
        pred = sb * (1 - d / n)
        n_impl = d / (1 - ratio)
        diag.append(dict(time=t, S_before=sb, S_after=sa, n_risk_from_ticks=n, d=d,
                         implied_n=n_impl, S_after_pred=pred, resid_pt=(pred - sa) / abs(calib["s_per_pt"])))
        rec += [(t, 1)] * d; n -= d
    while ci < len(tk):
        rec.append((tk[ci], 0)); n -= 1; ci += 1
    return rec, n, diag

res = {}
for g in ["A", "B"]:
    dr = drops(curves[g])
    rec, left, diag = reconstruct(g, man["groups"][g], ticks[g], dr)
    res[g] = dict(rec=rec, left=left, diag=diag, drops=dr)
    if args.stage == "diag":
        print(g, "drops", len(dr), "ticks", len(ticks[g]), "remaining unassigned", left,
              "curve end", curves[g][-1])
        for dd in diag:
            flag = "" if abs(dd["implied_n"] - dd["n_risk_from_ticks"]) < 0.5 * dd["d"] else " <<"
            print(f"  t={dd['time']:.3f} n={dd['n_risk_from_ticks']} d={dd['d']} impl={dd['implied_n']:.2f} res={dd['resid_pt']:.3f}{flag}")
if args.stage == "diag":
    print(json.dumps(calib, indent=0)); print(col2grp); print(risk); raise SystemExit

# ---------- save extracted observations ----------
obs = []
for g in ["A", "B"]:
    for dd in res[g]["diag"]:
        obs.append(dict(group=g, kind="drop", **dd))
    for t, s_ in ticks[g]:
        obs.append(dict(group=g, kind="censor_tick", time=t, S_before=s_))
pd.DataFrame(obs).to_csv(os.path.join(args.out, "extracted_observations.csv"), index=False)

# ---------- commit CSV atomically (only complete groups) ----------
rows = []
for g in ["A", "B"]:
    assert res[g]["left"] == 0 and len(res[g]["rec"]) == man["groups"][g], g
    rows += [(g, round(t, 4), e) for t, e in res[g]["rec"]]
df = pd.DataFrame(rows, columns=["group", "observed_time", "event"]).sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
final = os.path.join(args.out, "ipd.csv"); tmp = final + ".tmp"
df.to_csv(tmp, index=False); os.replace(tmp, final)

# ---------- verification from the reloaded CSV ----------
ipd = pd.read_csv(final)
sha = hashlib.sha256(open(final, "rb").read()).hexdigest()
def km_step(d, t):
    """right-continuous KM at time t (events at t included)."""
    s = 1.0
    for u in sorted(d.loc[d.event == 1, "observed_time"].unique()):
        if u > t: break
        n = (d.observed_time >= u).sum(); k = ((d.observed_time == u) & (d.event == 1)).sum()
        s *= 1 - k / n
    return s
def curve_at(pts, t):
    """measured step curve (vector path) at t, right-continuous."""
    val = pts[0][1]
    for x, y in pts:
        if x <= t + 1e-9: val = y
        else: break
    return val
TOL = 0.5 * abs(calib["s_per_pt"])  # half a PDF point = 0.0028 survival; coordinates are given to 0.01 pt
checks = dict(csv="output/ipd.csv", sha256=sha, seed=SEED, calibration=calib, group_map={str(k): v for k, v in col2grp.items()},
              survival_tolerance=TOL, tolerance_note="half of one PDF point on the survival axis; vector coordinates are reported at 0.01 pt precision",
              groups={})
for g in ["A", "B"]:
    d = ipd[ipd.group == g]; pts = curves[g]
    tlast = pts[-1][0]
    times = sorted(set([0, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 35] +
                       [round(x, 4) for x in (res[g]["drops"][-1][0] + 1e-4, tlast)]))
    times = [t for t in times if t <= tlast]
    sc = []
    for t in times:
        m, r = curve_at(pts, t), km_step(d, t)
        sc.append(dict(time=t, measured=round(m, 5), reconstructed=round(r, 5), resid=round(r - m, 6), status="pass" if abs(r - m) <= TOL else "fail"))
    # all drop points: max abs residual just after each step
    dres = [abs(km_step(d, t + 1e-4) - sa) for t, sb, sa in res[g]["drops"]]
    rk = []
    for t, n in [(0, man["groups"][g])] + [x for x in risk.get(g, []) if x[0] != 0]:
        c = int((d.observed_time >= t).sum())
        rk.append(dict(time=t, displayed=n, reconstructed=c, resid=c - n, status="pass" if c == n else "fail"))
    checks["groups"][g] = dict(
        n_manifest=man["groups"][g], n_records=int(len(d)), n_status="pass" if len(d) == man["groups"][g] else "fail",
        events=int(d.event.sum()), censored=int((d.event == 0).sum()),
        event_indicator_integer_01=bool(d.event.isin([0, 1]).all()),
        supplied_event_total="unavailable (not in manifest)",
        n_drops_measured=len(res[g]["drops"]), n_censor_ticks=len(ticks[g]),
        max_abs_resid_after_every_drop=float(max(dres)),
        last_drawn_time=tlast, max_observed_time=float(d.observed_time.max()),
        survival_checks=sc, risk_table_checks=rk)
json.dump(checks, open(os.path.join(args.out, "checks.json"), "w"), indent=1, default=float)
for g in ["A", "B"]:
    c = checks["groups"][g]
    print(g, c["n_records"], c["events"], c["max_abs_resid_after_every_drop"],
          [x["status"] for x in c["survival_checks"]], [(x["time"], x["displayed"], x["reconstructed"]) for x in c["risk_table_checks"]])
print(sha)
