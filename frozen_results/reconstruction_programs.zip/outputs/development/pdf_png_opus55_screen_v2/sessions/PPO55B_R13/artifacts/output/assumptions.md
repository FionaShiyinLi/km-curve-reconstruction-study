# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf` (single page, vector graphics) and `../input/manifest.json` (A = 100, B = 100, months, seed 693742476).
- The manifest has no arm-specific event totals, so that check is marked unavailable. Its absence was not read as zero events.
- The figure has no other auxiliary information (such as a hazard ratio or event counts), and none was used.

## Measurement
- The figure is vector-drawn. Each KM curve is one polyline path, and each censor mark is a separate short vertical line in the arm's color. I read the coordinates with pdfplumber (0.01 pt precision). No pixel tracing was needed. A 100 dpi render (`work/fig-1.png`) was inspected visually to confirm the object mapping.
- Calibration comes from the labelled axis ticks. Time: x = 64.8 pt is 0 and x = 410.4 pt is 36, fitted by least squares over all 7 labels (9.6 pt per month, maximum residual about 1e-14). Survival: y = 223.2 pt is 0 and y = 43.2 pt is 1, fitted over all 6 labels (180 pt per unit). No global rescaling was applied. Both curves start exactly at S = 1.0 (y = 43.2), so the origin needed no correction, and no running-minimum or other smoothing was used.
- The color-to-group mapping (blue = A, orange = B) comes from the legend text next to each legend line segment. The risk table was parsed from the PDF text layer. A: 100, 72, 50, 32, 21, 9, 0. B: 100, 81, 59, 47, 38, 11, 0, at 0, 6, ..., 36 months.
- Extracted drops and ticks are saved in `extracted_observations.csv`.

## Algorithm (`code/reconstruct.py`)
The program runs a sequential KM inversion. It starts from n = N and walks through the drops in time order. Before each drop, it removes one record for each drawn censor tick with a time strictly earlier than the drop. At a drop, d is the integer that best fits S_after/S_before = 1 - d/n. For every drop in both arms, d = 1 reproduces S_after to within about 3e-7 in survival (rounding level), and the implied n = d/(1 - S_after/S_before) equals the tick-derived n exactly (to 2 decimals). That consistency is the evidence for d = 1. A larger d would require an integer multiple of the at-risk count, which the ticks and risk table contradict. The integer reciprocal was not assumed on its own.

Ticks after the last drop become censorings at their drawn times. Each drawn tick object counts as one censoring, including near-coincident pairs such as A at 30.880/30.886 months and B at 25.408/25.421 and 27.527/27.536 months. Event times are the x positions of the vertical step segments, and censoring times are the tick x positions, rounded to 1e-4 month. No tick is exactly tied with a drop. At a tie, events would be ordered before censorings.

Result: A has 74 events and 26 censorings; B has 63 events and 37 censorings. With this ordering, no participants are left over and none are missing. The code does not use randomness (the seed is set and recorded anyway).

## Handling of censoring and risk tables
The risk table was not used to fit the records. It serves as an independent check. For every displayed time t, the count of records with observed_time >= t matches the displayed number in both arms, including 0 at 36 months. The last records are at 35.21 (A) and 35.86 (B), the final drawn ticks. No follow-up beyond the drawn curve was invented.

## Verification (`checks.json`)
- The CSV was reloaded and the right-continuous KM step function recomputed. It was compared with the measured vector curve at 0, 1, 3, ..., 35 months, just after the last event, and at the last drawn time. It was also compared just after every drop. The tolerance is half a PDF point (0.0028 survival), and all comparisons pass (maximum drop residual about 3e-7).
- All risk-table counts pass. Arm sizes are 100/100, and event indicators are integers in {0, 1}.

## Limitations
- Times carry rendering precision of about 0.001 month (0.01 pt / 9.6 pt per month), and the source's original time resolution is unknown.
- If two censorings at exactly the same time were drawn as a single tick object, they could not be seen. Here, however, the at-risk numbers implied by every drop and by the risk table agree exactly with one censoring per drawn tick. So no hidden censoring is indicated, although that cannot be proved.
- Censorings in the region between the last event and the final tick are placed at the drawn ticks. Nothing beyond the ticks is claimed about the censoring or accrual distribution.

## Sensitivity analysis
Not run. The drawn objects, the exact d/n consistency at every drop and the risk table together leave no materially different feasible event/censoring allocation (to rendering precision), so an alternative allocation would be arbitrary. This is not a claim of an error bound.
