"""Pixel extraction of the two KM curves and censor ticks from figure.png.

Usage: python3 extract.py [path/to/figure.png] [outdir]
Writes curve_<arm>.csv (column-wise measured survival) and ticks_<arm>.csv.
"""
import sys, os, json
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input', 'figure.png')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), '..', 'extracted')
os.makedirs(OUT, exist_ok=True)

# Axis calibration from labelled tick marks (pixel-centre coordinates):
# x ticks 0,6,...,36 months at columns 269.5,509.5,...,1709.5 (2-px ticks);
# y ticks 1.0,...,0.0 at rows 179.5,...,929.5.
X0, PX_PER_MONTH = 269.5, 40.0
Y1, Y0 = 179.5, 929.5
LINE_HALF = 1.5          # 4-px line: centre = bottom row - 1.5
COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}
YMIN, YMAX, XMIN, XMAX = 170, 935, 266, 1716

a = np.array(Image.open(FIG).convert('RGB')).astype(int)


def mask(col):
    return np.abs(a - np.array(col)).sum(2) < 60


def t_of(x):
    return (x - X0) / PX_PER_MONTH


def s_of(row_centre):
    return (Y0 - row_centre) / (Y0 - Y1)


LOCAL_LEVEL_A = {}
masks = {k: mask(v) for k, v in COLORS.items()}
summary = {}
for arm, col in COLORS.items():
    M = masks[arm]
    other = masks['B' if arm == 'A' else 'A']
    xs, bots, tops, occl = [], [], [], []
    for x in range(XMIN, XMAX):
        ys = np.where(M[YMIN:YMAX, x])[0] + YMIN
        if len(ys) == 0:
            xs.append(x); bots.append(np.nan); tops.append(np.nan); occl.append(True); continue
        b = ys.max()
        # bottom edge unreliable if the pixel directly below is the other arm's colour
        # (orange B is drawn over blue A, so only A can be hidden; the y-axis line
        # also covers A at columns 269-270)
        oc = arm == 'A' and (bool(other[b + 1, x]) or x in (269, 270))
        xs.append(x); bots.append(b); tops.append(ys.min()); occl.append(oc)
    # Local origin re-measurement (A only): at columns 271-273 the visible blue rows
    # 190-193 are the lower half of a censor tick whose upper half lies under B's tick;
    # column 274 shows the line's vertical segment spanning rows 185-192, so the line
    # bottom at 271-273 is taken as row 188.  No other column is altered.
    if arm == 'A':
        for x in (271, 272, 273):
            i = x - XMIN
            bots[i] = max(bots[i], 188)  # keep tick excursion for tick detection
            LOCAL_LEVEL_A[x] = 188
    xs = np.array(xs); bots = np.array(bots, float); tops = np.array(tops, float); occl = np.array(occl)
    valid = ~np.isnan(bots) & ~occl
    last = xs[~np.isnan(bots)].max()
    # step level: reverse running minimum of the bottom edge (the KM curve never rises,
    # so tick marks, which extend ~6 px below the line, appear as transient excursions)
    lev = np.full(len(xs), np.nan)
    run = np.inf
    for i in range(len(xs) - 1, -1, -1):
        if valid[i]:
            run = min(run, LOCAL_LEVEL_A.get(xs[i], bots[i]) if arm == 'A' else bots[i])
        lev[i] = run if np.isfinite(run) else np.nan
    # tick columns: bottom edge at least 4 px below the step level
    exc = np.where(valid, bots - lev, 0)
    tickcol = exc >= 4
    groups = []
    i = 0
    while i < len(xs):
        if tickcol[i]:
            j = i
            while j + 1 < len(xs) and tickcol[j + 1]:
                j += 1
            groups.append((xs[i], xs[j]))
            i = j + 1
        else:
            i += 1
    with open(os.path.join(OUT, f'curve_{arm}.csv'), 'w') as f:
        f.write('x,t,bottom_row,top_row,occluded,level_row,S\n')
        for i in range(len(xs)):
            if xs[i] > last:
                break
            S = s_of(lev[i] - LINE_HALF) if np.isfinite(lev[i]) else np.nan
            f.write(f'{xs[i]},{t_of(xs[i]):.4f},{bots[i]},{tops[i]},{int(occl[i])},{lev[i]},{S:.5f}\n')
    with open(os.path.join(OUT, f'ticks_{arm}.csv'), 'w') as f:
        f.write('x_start,x_end,width_px,t_centre\n')
        for g0, g1 in groups:
            f.write(f'{g0},{g1},{g1 - g0 + 1},{t_of((g0 + g1) / 2):.4f}\n')
    summary[arm] = dict(last_col=int(last), t_last=t_of(last), n_tick_groups=len(groups),
                        tick_cols=int(tickcol.sum()), n_occluded=int(occl[xs <= last].sum()))
print(json.dumps(summary, indent=1))
