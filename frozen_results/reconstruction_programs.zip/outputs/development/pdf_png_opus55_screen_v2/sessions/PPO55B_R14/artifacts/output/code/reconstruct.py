"""Reconstruct participant-level (time, event) records from the extracted KM curves.

Usage: python3 reconstruct.py [extracted_dir] [output_dir] [--alt]
  default: extracted_dir = ../extracted, output_dir = .. (relative to this file)
  --alt   : sensitivity allocation (censorings uniform within each risk interval,
            ignoring tick positions); writes sensitivity.csv instead of ipd.csv.
Run extract.py first.  Deterministic; seed recorded for completeness.
"""
import sys, os, json
import numpy as np
import pandas as pd

SEED = 1511082744
np.random.seed(SEED)  # no stochastic step is used

HERE = os.path.dirname(os.path.abspath(__file__))
args = [a for a in sys.argv[1:] if not a.startswith('--')]
ALT = '--alt' in sys.argv
EXT = args[0] if len(args) > 0 else os.path.join(HERE, '..', 'extracted')
OUT = args[1] if len(args) > 1 else os.path.join(HERE, '..')

X0, PPM = 269.5, 40.0
DROP_SHIFT = 1.5 / PPM       # first column showing a new level is ~1.5 px left of the step
N = {'A': 1000, 'B': 1000}   # manifest
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 665, 459, 312, 217, 68, 0],   # read from figure risk table
        'B': [1000, 751, 568, 419, 303, 112, 0]}


def load(arm):
    c = pd.read_csv(os.path.join(EXT, f'curve_{arm}.csv'))
    c = c[c.x >= 270].reset_index(drop=True)
    S = c.S.ffill().values
    t = c.t.values
    t_end = t[-1] - DROP_SHIFT          # data end: line has a ~2 px projecting cap
    drops = []                          # (event time, measured level after drop)
    prev = 1.0
    for i in range(len(S)):
        if S[i] < prev - 1e-9:
            drops.append((min(t[i] + DROP_SHIFT, t_end), S[i]))
            prev = S[i]
    tk = pd.read_csv(os.path.join(EXT, f'ticks_{arm}.csv'))
    tk = tk[tk.x_start >= 270]
    ticks = []                          # (time, visible-multiplicity weight)
    for _, r in tk.iterrows():
        m = max(1, int(round((r.width_px - 1) / 2)))   # single tick is 2-3 px wide
        if m == 1:
            ticks.append((r.t_centre, 1))
        else:
            for tt in np.linspace((r.x_start + 1 - X0) / PPM, (r.x_end - 1 - X0) / PPM, m):
                ticks.append((tt, 1))
    return dict(t=t, S=S, t_end=t_end, drops=drops, ticks=ticks)


def allocate(c, lo, hi, ticks, alt):
    """Place c censoring times in [lo, hi)."""
    if c <= 0:
        return []
    tt = [x for x, _ in ticks if lo <= x < hi]
    if alt or not tt:
        return list(lo + (hi - lo) * (np.arange(c) + 0.5) / c)
    tt = np.array(sorted(tt))
    k = len(tt)
    base = np.full(k, c // k)
    base[: c - base.sum()] += 1        # spread remainder over earliest ticks
    out = []
    for x, b in zip(tt, base):
        out += [x] * int(b)
    return out


def simulate(n0, S0, events, cens):
    """Forward KM tracking. events: list of (t, S_meas); cens: list of t.
    Events precede censorings at tied times. Returns records, n remaining, S_hat, sse."""
    ev = [(t, 0, s) for t, s in events] + [(t, 1, None) for t in cens]
    ev.sort(key=lambda z: (z[0], z[1]))
    n, S, rec, sse = n0, S0, [], 0.0
    for t, kind, s in ev:
        if n <= 0:
            break
        if kind == 1:
            rec.append((t, 0)); n -= 1
        else:
            d = int(round(n * (1 - s / S))) if S > 0 else 0
            d = min(max(d, 0), n)
            if d:
                S *= 1 - d / n
                n -= d
                rec += [(t, 1)] * d
            sse += ((S - s) * 750) ** 2   # squared residual in pixels
    return rec, n, S, sse


def reconstruct(arm, alt=False):
    D = load(arm)
    n, S, rec, log = N[arm], 1.0, [], []
    for k in range(len(RISK_T) - 1):
        lo, hi = RISK_T[k], RISK_T[k + 1]
        evs = [(t, s) for t, s in D['drops'] if lo <= t < hi]
        last = k == len(RISK_T) - 2
        target = RISK[arm][k + 1]
        best = None
        cmax = n if last else max(n - target, 0)
        # visibility lower bound: each visible tick position implies >= 1 censoring
        lb = min(sum(1 for x, _ in D['ticks'] if lo <= x < min(hi, D['t_end'])), cmax)
        for c in range(0, cmax + 1):
            cens = allocate(c, lo, min(hi, D['t_end']), D['ticks'], alt)
            r, nr, Sh, sse = simulate(n, S, evs, cens)
            if last:
                score = (0, int(c < lb), sse)
            else:
                score = (abs(nr - target), int(c < lb), sse)
            if best is None or score < best[0]:
                best = (score, c, r, nr, Sh, sse)
        score, c, r, nr, Sh, sse = best
        if last and nr > 0:            # remaining participants censored at end of curve
            r += [(D['t_end'], 0)] * nr
            nr_end = nr; nr = 0
        else:
            nr_end = 0
        nev = sum(e for _, e in r)
        log.append(dict(interval=[lo, hi], n_start=n, censored_in_ticks=c, end_censored=nr_end,
                        events=nev, n_end=nr, target=target,
                        visible_ticks=lb,
                        rms_px=float(np.sqrt(sse / max(len(evs), 1)))))
        rec += r
        n, S = nr, Sh
    assert len(rec) == N[arm], (arm, len(rec))
    return rec, log


if __name__ == '__main__':
    rows, logs = [], {}
    for arm in 'AB':
        rec, log = reconstruct(arm, ALT)
        logs[arm] = log
        rows += [(arm, round(float(t), 4), int(e)) for t, e in rec]
    df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
    name = 'sensitivity.csv' if ALT else 'ipd.csv'
    tmp = os.path.join(OUT, name + '.tmp')
    df.to_csv(tmp, index=False)
    os.replace(tmp, os.path.join(OUT, name))
    with open(os.path.join(OUT, 'extracted', ('alloc_log_alt.json' if ALT else 'alloc_log.json')), 'w') as f:
        json.dump(logs, f, indent=1)
    print(json.dumps(logs, indent=1))
