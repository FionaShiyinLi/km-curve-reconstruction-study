"""Verify committed ipd.csv against the measured curves and the risk table.

Usage: python3 checks.py [output_dir]   (default: .. relative to this file)
Writes checks.json; if sensitivity.csv exists, adds a same-horizon comparison.
"""
import sys, os, json, hashlib
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..')
EXT = os.path.join(OUT, 'extracted')
X0, PPM, PX_S = 269.5, 40.0, 1 / 750
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 665, 459, 312, 217, 68, 0], 'B': [1000, 751, 568, 419, 303, 112, 0]}
N = {'A': 1000, 'B': 1000}
HORIZON = 35.7   # common supported horizon (A's curve ends at ~35.78 months)


def km(df):
    """Right-continuous KM step: returns (event times, S after each)."""
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1])
    S, out = 1.0, []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        S *= 1 - d / n; out.append(S)
    return ut, np.array(out)


def S_at(ut, s, x):
    i = np.searchsorted(ut, x, side='right') - 1
    return 1.0 if i < 0 else float(s[i])


def rmst(ut, s, h):
    grid = np.concatenate([[0], ut[ut < h], [h]])
    vals = [S_at(ut, s, g) for g in grid[:-1]]
    return float(np.sum(np.diff(grid) * vals))


path = os.path.join(OUT, 'ipd.csv')
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
res = {'csv_sha256': sha, 'csv': 'ipd.csv', 'arms': {}}
assert list(df.columns) == ['group', 'observed_time', 'event']
for arm in 'AB':
    d = df[df.group == arm]
    c = pd.read_csv(os.path.join(EXT, f'curve_{arm}.csv'))
    c = c[c.x >= 270].reset_index(drop=True)
    lev = c.S.ffill().values
    ut, s = km(d)
    arm_res = {'n_records': int(len(d)), 'n_expected': N[arm], 'n_pass': bool(len(d) == N[arm]),
               'event_indicator_integer_0_1': bool(d.event.isin([0, 1]).all()),
               'times_finite_nonneg': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
               'n_events': int(d.event.sum()), 'n_censored': int((d.event == 0).sum()),
               'max_time': float(d.observed_time.max()),
               'supplied_event_total': 'unavailable (not in manifest)'}
    curve = []
    times = [0.25, 0.5, 1, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 33, 34, 35, 35.5, 35.7]
    if arm == 'B':
        times += [35.9]
    for t in times:
        # column whose level shows S(t): steps appear ~1.5 px left of the step time
        i = int(round(X0 + PPM * t - 1.5)) - 270
        i = min(max(i, 0), len(lev) - 1)
        m = float(lev[i])
        win = lev[max(i - 2, 0): i + 3]
        tol = float(np.nanmax(win) - np.nanmin(win)) + 1.5 * PX_S   # local slope +-2 px + 1.5 px level
        r = S_at(ut, s, t)
        curve.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), residual=round(r - m, 5),
                          tol=round(tol, 5), status='pass' if abs(r - m) <= tol else 'fail'))
    arm_res['curve'] = curve
    risk = []
    for t, n in zip(RISK_T, RISK[arm]):
        k = int((d.observed_time >= t).sum())
        risk.append(dict(t=t, table=n, reconstructed=k, residual=k - n, status='pass' if k == n else 'fail'))
    arm_res['risk_table'] = risk
    arm_res['rmst_to_horizon'] = round(rmst(ut, s, HORIZON), 4)
    res['arms'][arm] = arm_res

sp = os.path.join(OUT, 'sensitivity.csv')
if os.path.exists(sp):
    sd = pd.read_csv(sp)
    comp = {'horizon_months': HORIZON, 'assumption': 'censorings uniform within each risk-table interval (tick positions ignored); same event-extraction and risk-table matching',
            'csv_sha256': hashlib.sha256(open(sp, 'rb').read()).hexdigest()}
    for arm in 'AB':
        u1, s1 = km(df[df.group == arm]); u2, s2 = km(sd[sd.group == arm])
        comp[arm] = dict(S_primary=round(S_at(u1, s1, HORIZON), 4), S_alt=round(S_at(u2, s2, HORIZON), 4),
                         S12_primary=round(S_at(u1, s1, 12), 4), S12_alt=round(S_at(u2, s2, 12), 4),
                         S30_primary=round(S_at(u1, s1, 30), 4), S30_alt=round(S_at(u2, s2, 30), 4),
                         rmst_primary=round(rmst(u1, s1, HORIZON), 4), rmst_alt=round(rmst(u2, s2, HORIZON), 4),
                         events_primary=int(df[df.group == arm].event.sum()),
                         events_alt=int(sd[sd.group == arm].event.sum()),
                         risk_alt=[int((sd[sd.group == arm].observed_time >= t).sum()) for t in RISK_T])
    res['sensitivity'] = comp
tmp = os.path.join(OUT, 'checks.json.tmp')
json.dump(res, open(tmp, 'w'), indent=1)
os.replace(tmp, os.path.join(OUT, 'checks.json'))
for arm in 'AB':
    a = res['arms'][arm]
    print(arm, a['n_records'], a['n_events'], 'fails:', [x['t'] for x in a['curve'] if x['status'] != 'pass'],
          [x['t'] for x in a['risk_table'] if x['status'] != 'pass'], 'max|res|', max(abs(x['residual']) for x in a['curve']))
if 'sensitivity' in res:
    print(json.dumps(res['sensitivity'], indent=1))
