#!/bin/sh
# Full pipeline from a fresh workspace: python3 extract.py [figure.png] [outdir]; then reconstruct, sensitivity, checks.
set -e
cd "$(dirname "$0")"
python3 extract.py "${1:-../../../input/figure.png}" ../extracted
python3 reconstruct.py ../extracted ..
python3 reconstruct.py ../extracted .. --alt
python3 checks.py ..
