#!/usr/bin/env python3
"""Reconstruct approximate participant-level (event/censoring) records from a
raster Kaplan-Meier figure.  Own implementation (no KM-to-IPD package).

Usage: python3 output/code/reconstruct.py [--input ../input] [--out output]
       [--variant primary|uniform_extra]

Steps
 1. Calibrate axes from the tick marks of the labelled axes (0..36 months,
    0.0..1.0 survival).
 2. For each arm colour, measure per-pixel-column bottom/top of the curve,
    classify censor-tick columns, derive the line level (survival after drops).
 3. Isotonic (PAVA) smoothing of the measured levels; violations are reported.
 4. Forward KM tracking per risk-table interval: events per column are
    d = round(n * (1 - S_target / S_km)); the number censored in the interval is
    solved so that the number at risk at the next risk-table time matches;
    censorings are allocated to the visible censor-tick runs.
The algorithm is deterministic; the manifest seed is recorded and set anyway.
"""
import argparse, json, math, os, random, tempfile
import numpy as np
import pandas as pd
from PIL import Image

SEED = 1116920233
COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}   # legend: A blue, B orange
DRAW_ORDER = ['A', 'B']        # B is drawn on top of A (checked at origin/tail)
# Axis labels and risk table transcribed visually from the figure (no OCR
# engine is available in this runtime).
X_LABELS = [0, 6, 12, 18, 24, 30, 36]
Y_LABELS = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
RISK_TIMES = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 665, 459, 312, 217, 68, 0],
        'B': [1000, 751, 568, 419, 303, 112, 0]}
TICK_BELOW = 6     # tick extends 6 rows below the line bottom (measured)
LINE_HALF = 1.5    # line is 4 rows: centre = bottom - 1.5


def runs_of(idx):
    out = []
    for v in idx:
        if out and v == out[-1][1] + 1:
            out[-1][1] = v
        else:
            out.append([v, v])
    return out


def calibrate(im):
    dark = im.sum(2) < 300
    spine_x = int(np.argmax(dark.sum(0)))            # left spine (first of 2 px)
    axis_y = int(np.argmax(dark.sum(1)))              # x-axis (first of 2 px)
    row = axis_y + 5
    xs = [(a + b) / 2 for a, b in runs_of(np.where(dark[row])[0])
          if a >= spine_x - 1 and b - a <= 3]
    col = spine_x - 4
    ys = [(a + b) / 2 for a, b in runs_of(np.where(dark[:axis_y + 3, col])[0])
          if b - a <= 3]
    assert len(xs) == len(X_LABELS) and len(ys) == len(Y_LABELS), (xs, ys)
    ax = np.polyfit(xs, X_LABELS, 1)
    ay = np.polyfit(ys, Y_LABELS, 1)
    cal = dict(x_tick_px=xs, y_tick_px=ys, t_per_px=ax[0], t0=ax[1],
               s_per_px=ay[0], s0=ay[1],
               x_resid=list(np.polyval(ax, xs) - X_LABELS),
               y_resid=list(np.polyval(ay, ys) - Y_LABELS))
    return cal, spine_x, axis_y


def measure_arm(im, arm, cal, axis_y):
    col = np.array(COLORS[arm])
    masks = {g: np.abs(im - np.array(c)).sum(2) < 60 for g, c in COLORS.items()}
    m = masks[arm]
    occl = im.sum(2) < 150
    for g in DRAW_ORDER[DRAW_ORDER.index(arm) + 1:]:
        occl = occl | masks[g]
    tx = lambda x: cal['t_per_px'] * x + cal['t0']
    sy = lambda y: cal['s_per_px'] * y + cal['s0']
    x_first = int(math.ceil((0 - cal['t0']) / cal['t_per_px']))   # first column t>0
    top_row = int((1.0 - cal['s0']) / cal['s_per_px']) - 20
    cols = [x for x in range(x_first, im.shape[1])
            if m[top_row:axis_y, x].any() or
            (occl[top_row:axis_y - 1, x].any() and m[top_row:axis_y, x - 5:x].any())]
    x_last = max(cols)
    rec = []
    for x in range(x_first, x_last + 1):
        ys = np.where(m[top_row:axis_y, x])[0] + top_row
        if len(ys) == 0:
            rec.append(dict(x=x, top=np.nan, bot=np.nan, occluded=True))
            continue
        b, t = int(ys.max()), int(ys.min())
        rec.append(dict(x=x, top=t, bot=b, occluded=bool(occl[b + 1, x])))
    df = pd.DataFrame(rec)
    # --- censor-tick classification -------------------------------------
    ok = (~df.occluded) & df.bot.notna()
    bvals = np.where(ok, df.bot, np.inf)
    sufmin = np.minimum.accumulate(bvals[::-1])[::-1]     # used only to flag ticks
    tick = np.zeros(len(df), bool)
    level = np.full(len(df), np.nan)
    c_last = (1.0 - cal['s0']) / cal['s_per_px']
    for i, r in df.iterrows():
        if np.isnan(r.bot):
            continue
        ext = r.bot - r.top
        sym = 15 <= ext <= 18 and abs((r.bot + r.top) / 2 - c_last) <= 1.5
        bot_ex = ok[i] and np.isfinite(sufmin[i]) and r.bot - sufmin[i] >= 3
        if sym or bot_ex:
            tick[i] = True
            level[i] = r.bot - TICK_BELOW - LINE_HALF
        elif ok[i]:
            level[i] = r.bot - LINE_HALF
        if not np.isnan(level[i]) and not tick[i]:
            c_last = level[i]
    df['tick'] = tick
    df['level_row'] = level
    # leading occluded columns showing a stroke below the S=1 line -> backfill
    row1 = (1.0 - cal['s0']) / cal['s_per_px']
    first_meas = int(np.where(~np.isnan(level))[0][0])
    for i in range(first_meas):
        if not np.isnan(df.bot[i]) and df.bot[i] > row1 + LINE_HALF + 0.5:
            level[i] = level[first_meas]
            df.loc[i, 'note'] = 'origin: stroke visible, level backfilled'
    df['level_row'] = level
    # time at which the level of column x applies (drop stroke 4 px wide)
    df['t'] = tx(df.x + LINE_HALF)
    df['S_raw'] = sy(df.level_row)
    # fill: leading unknown -> 1, interior unknown -> carry last
    s = df.S_raw.copy()
    if np.isnan(s.iloc[0]):
        s.iloc[0] = 1.0
    s = s.ffill()
    # monotonicity diagnostics before PAVA
    d = np.diff(s.values)
    viol = [(int(df.x[i + 1]), float(d[i]) / abs(cal['s_per_px']))
            for i in range(len(d)) if d[i] > 1e-9]
    df['S_iso'] = pava_decreasing(np.minimum(s.values, 1.0))
    # tick runs
    truns = []
    for a, b in runs_of(list(df.x[df.tick])):
        w = b - a + 1
        lv = float(np.nanmedian(df.level_row[(df.x >= a) & (df.x <= b)]))
        truns.append(dict(x_start=a, x_end=b, width=w, min_ticks=int(math.ceil(w / 3)),
                          max_positions=max(1, w - 2), t_start=tx(a + 1), t_end=tx(b - 1),
                          t_center=tx((a + b) / 2), S_at_tick=sy(lv)))
    return df, truns, viol


def pava_decreasing(y):
    v = list(-np.asarray(y, float)); w = [1.0] * len(v); idx = [[i] for i in range(len(v))]
    out_v, out_w, out_i = [], [], []
    for vi, wi, ii in zip(v, w, idx):
        out_v.append(vi); out_w.append(wi); out_i.append(ii)
        while len(out_v) > 1 and out_v[-2] > out_v[-1]:
            vv = (out_v[-2] * out_w[-2] + out_v[-1] * out_w[-1]) / (out_w[-2] + out_w[-1])
            ww = out_w[-2] + out_w[-1]; ii2 = out_i[-2] + out_i[-1]
            out_v[-2:] = [vv]; out_w[-2:] = [ww]; out_i[-2:] = [ii2]
    res = np.empty(len(v))
    for vv, ii in zip(out_v, out_i):
        res[ii] = -vv
    return res


def largest_remainder(total, weights):
    weights = np.asarray(weights, float)
    if total <= 0 or weights.sum() == 0:
        return np.zeros(len(weights), int)
    q = total * weights / weights.sum()
    k = np.floor(q).astype(int)
    for j in np.argsort(-(q - k))[: total - k.sum()]:
        k[j] += 1
    return k


def allocate(C, runs, t_lo, t_hi, cal, variant):
    """Return censoring times for C censorings in [t_lo, t_hi) and a flag."""
    tx = lambda x: cal['t_per_px'] * x + cal['t0']
    if C <= 0:
        return [], 'none'
    if not runs:
        return list(np.linspace(t_lo, t_hi, C + 2)[1:-1]), 'no visible ticks: uniform'
    m = np.array([r['min_ticks'] for r in runs]); w = np.array([r['width'] for r in runs])
    flag = 'ok'
    if C >= m.sum():
        extra = C - m.sum()
        if variant == 'uniform_extra':
            k = m.copy()
            times_extra = list(np.linspace(t_lo, t_hi, extra + 2)[1:-1])
        else:
            k = m + largest_remainder(extra, w); times_extra = []
    else:
        flag = f'conflict: {C} censored < {m.sum()} minimum visible ticks'
        k = largest_remainder(C, m); times_extra = []
    times = []
    for r, kr in zip(runs, k):
        if kr == 1:
            times.append(r['t_center'])
        elif kr > 1:
            times += list(np.linspace(tx(r['x_start'] + 1), tx(r['x_end'] - 1), kr))
    return sorted(min(max(t, t_lo), np.nextafter(t_hi, 0)) for t in times + times_extra), flag


def simulate_interval(n, S_km, cols, cens_times):
    """cols: list of (t, S_target) in time order.  Events before censoring at ties."""
    ev, ce = [], []
    ci = 0
    for t, s_t in cols:
        while ci < len(cens_times) and cens_times[ci] < t and n > 0:
            ce.append(cens_times[ci]); n -= 1; ci += 1
        if n > 0 and s_t < S_km:
            d = int(round(n * (1 - s_t / S_km)))
            d = min(d, n)
            if d > 0:
                ev += [t] * d; S_km *= (1 - d / n); n -= d
    while ci < len(cens_times) and n > 0:
        ce.append(cens_times[ci]); n -= 1; ci += 1
    return n, S_km, ev, ce


def reconstruct_arm(arm, df, truns, cal, variant):
    n, S_km = RISK[arm][0], 1.0
    ev_all, ce_all, log = [], [], []
    t_curve_end = float(cal['t_per_px'] * df.x.max() + cal['t0'])
    for i in range(len(RISK_TIMES) - 1):
        lo, hi = RISK_TIMES[i], RISK_TIMES[i + 1]
        target = RISK[arm][i + 1]
        sel = df[(df.t >= lo) & (df.t < hi)]
        cols = [(min(t, hi - 1e-6), s) for t, s in zip(sel.t, sel.S_iso)]
        runs = [r for r in truns if lo <= r['t_center'] < hi]
        best = None
        for C in range(0, n + 1):
            ct, flag = allocate(C, runs, lo, min(hi, t_curve_end + 1e-9), cal, variant)
            n2, S2, ev, ce = simulate_interval(n, S_km, cols, ct)
            leftover = C - len(ce)
            score = (abs(n2 - target), leftover, abs(C - (n - target)))
            if best is None or score < best[0]:
                best = (score, C, n2, S2, ev, ce, flag)
            if n2 < target - 2:
                break
        score, C, n2, S2, ev, ce, flag = best
        log.append(dict(interval=[lo, hi], n_start=n, n_end=n2, target=target,
                        events=len(ev), censored=len(ce), tick_runs=len(runs),
                        min_visible_ticks=int(sum(r['min_ticks'] for r in runs)),
                        allocation=flag, S_km_end=S2))
        ev_all += ev; ce_all += ce; n, S_km = n2, S2
    rows = [(arm, t, 1) for t in ev_all] + [(arm, t, 0) for t in ce_all]
    # any participants still unassigned (should not happen): report, do not invent
    return rows, log, n


def km(times, events):
    o = np.lexsort((-np.asarray(events), times))
    t = np.asarray(times)[o]; e = np.asarray(events)[o]
    n = len(t); S = 1.0; out = []
    ut = np.unique(t)
    for u in ut:
        at = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        if d:
            S *= 1 - d / at; out.append((u, S))
    return out


def S_at(stepfun, t):
    s = 1.0
    for u, v in stepfun:
        if u <= t:
            s = v
        else:
            break
    return s


def atomic_csv(df, path):
    d = os.path.dirname(path) or '.'
    fd, tmp = tempfile.mkstemp(dir=d, suffix='.tmp')
    os.close(fd)
    df.to_csv(tmp, index=False)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default='../input')
    ap.add_argument('--out', default='output')
    ap.add_argument('--variant', default='primary', choices=['primary', 'uniform_extra'])
    a = ap.parse_args()
    random.seed(SEED); np.random.seed(SEED % 2**32)
    man = json.load(open(os.path.join(a.input, 'manifest.json')))
    assert man['code_seed'] == SEED
    im = np.array(Image.open(os.path.join(a.input, 'figure.png')).convert('RGB')).astype(int)
    cal, spine_x, axis_y = calibrate(im)
    inter = os.path.join(a.out, 'intermediate'); os.makedirs(inter, exist_ok=True)
    all_rows, info = [], {'calibration': cal, 'arms': {}}
    for arm in ['A', 'B']:
        df, truns, viol = measure_arm(im, arm, cal, axis_y)
        if a.variant == 'primary':
            df.to_csv(os.path.join(inter, f'curve_{arm}.csv'), index=False)
            pd.DataFrame(truns).to_csv(os.path.join(inter, f'ticks_{arm}.csv'), index=False)
        rows, log, left = reconstruct_arm(arm, df, truns, cal, a.variant)
        assert len(rows) == man['groups'][arm], (arm, len(rows), left)
        all_rows += rows
        info['arms'][arm] = dict(n_tick_runs=len(truns),
                                 min_visible_ticks=int(sum(r['min_ticks'] for r in truns)),
                                 monotonic_violations_px=viol, intervals=log,
                                 curve_last_t=float(df.t.max()))
    out = pd.DataFrame(all_rows, columns=['group', 'observed_time', 'event'])
    out['observed_time'] = out.observed_time.clip(lower=0).round(4)
    out['event'] = out.event.astype(int)
    out = out.sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
    name = 'ipd.csv' if a.variant == 'primary' else 'sensitivity.csv'
    atomic_csv(out, os.path.join(a.out, name))
    json.dump(info, open(os.path.join(inter, f'reconstruction_log_{a.variant}.json'), 'w'),
              indent=1, default=float)
    print(json.dumps({k: v for k, v in info['arms'].items()}, default=float, indent=1)[:6000])


if __name__ == '__main__':
    main()
