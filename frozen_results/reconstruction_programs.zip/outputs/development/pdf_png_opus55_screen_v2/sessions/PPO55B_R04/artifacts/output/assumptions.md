# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.pdf` (single-page vector PDF) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 774015458).
- The manifest gives no arm-specific event totals, so that check is marked unavailable. No other auxiliary information was used.

## Measurement
- The figure is fully vector. `extract.py` reads the PDF drawing objects with pdfplumber. It extracts one stroked step path per arm (identified by stroke color, blue = A, orange = B, matched to the legend), every 4-pt vertical censor-tick segment in each arm's color, the black axis ticks with their text labels, and the number-at-risk table text.
- Calibration comes from the labeled anchors: seven x ticks (0 to 36 months) and six y ticks (0 to 1.0). Least-squares fits give x_pt = 64.8 + 9.6·t and y_pt = 223.2 − 180·S, with maximum anchor residuals of about 1e-13 pt. No global or origin correction was applied. Both paths start exactly at (t = 0, S = 1), and the first drops are measured directly from the path.
- PDF coordinates carry 4 decimals in points. The display resolution is therefore about 1.0e-5 months in time and 5.6e-7 in S.
- Every censor tick's center lies on its own arm's path (maximum deviation about 3e-14 pt). No two ticks in an arm share a position, so each tick object is counted as one censoring. Exactly coincident ticks would appear as duplicate objects, and there are none.
- The raw extraction is saved in `extracted_raw.json`. Calibrated path vertices and tick positions are in `measured_observations.csv`.

## Algorithm (`reconstruct.py`, deterministic; the seed is set and recorded, but no random draws are made)
1. Take the drops of each path in time order. At each drop, first remove from the risk set the ticks lying strictly between the previous drop and this one. Then set d = round(n·(1 − S_after/S_before)).
   - Every drop gave d = 1 (A: 779 drops, B: 620). The maximum |n·q − d| was 4.9e-4, while the nearest alternative integer (d ± 1) was never closer than 0.9995. Multiplicity is therefore established by the drop ratios, not assumed.
2. Event times are the drop abscissae. Censoring times are the tick abscissae.
3. Ticks within half a display resolution of a drop were allocated by comparing the drop ratio under "in risk set" versus "excluded":
   - **A, 22.1448 months:** the ratio fits n = 255 (error 8e-5) rather than n = 256 (error 3.8e-3, about 8 times the largest error at any other drop). This censoring is placed 5e-6 months before the event. That shift is below display resolution and is needed only because the standard convention counts censorings tied at t as still at risk.
   - **B, 0.0501 months:** the ratio fits in-risk-set exactly. The censoring is tied with the event and counted in the risk set.
4. Ticks after the last drop are censorings, and the arm is exhausted exactly: the final path segment ends at the last tick. The program stops with an error if the tick-tracked risk set does not reach 0 with every tick used. Result: A has 779 events and 221 censorings; B has 620 events and 380 censorings.

## Risk table and checks (`check.py` → `checks.json`)
- The committed CSV is reloaded and a right-continuous KM curve is recomputed for each arm. It is compared with the measured path level on every horizontal segment (780 in A, 621 in B), where the maximum |residual| is 2.8e-7. It is also compared at 17 listed times per arm, including 33, 34, 35, 35.5 months and the path end. The tolerance is 1e-5, about 18 times the S resolution.
- Risk counts use observed_time ≥ t. All displayed counts at 0, 6, 12, 18, 24, 30 and 36 months are reproduced exactly (A: 1000/692/485/331/234/88/0; B: 1000/647/525/436/354/143/0). No records lie at or beyond 36 months; the maximum times are 35.958 (A) and 35.962 (B).
- The risk table was not used in fitting. It serves as an independent check on the tick counts.

## Limitations
- Recorded times are the plotted times, so they are only as precise as the display (about 1e-5 months). Any rounding in the original data before plotting cannot be recovered.
- Near n ≈ 1000, an unseen or duplicated censoring changes n·q by only about 0.001. The drop ratios therefore corroborate tick counts only weakly early on, and more strongly as n falls. There, the tick objects and the exact 6-month risk count are the main evidence.
- The single below-resolution shift in A (step 3) is an assumption supported by the drop ratio, not an observed time.

## Sensitivity analysis
Not run. The only allocation choices are the two ticks at drop times, each affecting one participant by less than 1e-5 months. Within the supplied inputs there is no materially different feasible allocation, so a sensitivity file would not be informative. This is not a claim of unique recovery of the original records.

## Reproduce
`python output/code/reconstruct.py --input ../input --output output && python output/code/check.py --input ../input --output output`
A fresh-workspace rerun reproduced the same `ipd.csv` SHA-256.
