"""Reconstruct participant-level (time, event) records from the vector KM figure.
Usage: python reconstruct.py [--input DIR] [--output DIR]
Defaults: input = ../input relative to cwd, output = ./output.
Deterministic; the supplied seed is set and recorded although no random draws are used."""
import argparse, hashlib, json, os, subprocess, sys
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--input', default=os.path.join('..', 'input'))
ap.add_argument('--output', default='output')
a = ap.parse_args()
here = os.path.dirname(os.path.abspath(__file__))
man = json.load(open(os.path.join(a.input, 'manifest.json')))
SEED = man['code_seed']; np.random.seed(SEED)
os.makedirs(a.output, exist_ok=True)
subprocess.run([sys.executable, os.path.join(here, 'extract.py'), os.path.join(a.input, 'figure.pdf'), a.output], check=True)
raw = json.load(open(os.path.join(a.output, 'extracted_raw.json')))

def lin(an):
    v = np.array([x[0] for x in an]); p = np.array([x[1] for x in an])
    b, c = np.polyfit(v, p, 1); return c, b, float(np.abs(p - (c + b * v)).max())
x0, bx, rx = lin(raw['x_anchors']); y0, by, ry = lin(raw['y_anchors'])
T = lambda x: (np.asarray(x, float) - x0) / bx
S = lambda y: (np.asarray(y, float) - y0) / by
RES_T = 1e-4 / bx          # coordinates are written to 4 decimals in PDF points
RES_S = 1e-4 / abs(by)

recs, obs_rows, diag = [], [], {}
for g in 'AB':
    N = man['groups'][g]
    p = np.array(raw['curves'][g]); t = T(p[:, 0]); s = S(p[:, 1])
    k = np.where(np.diff(s) < -1e-9)[0]
    et, sb, sa = t[k], s[k], s[k + 1]
    tk = np.array(raw['ticks'][g]); ct = T(tk[:, 0]); cs = S(tk[:, 1])
    for ti, si in zip(t, s): obs_rows.append((g, 'path_vertex', ti, si))
    for ti, si in zip(ct, cs): obs_rows.append((g, 'censor_tick', ti, si))
    used = np.zeros(len(ct), bool); n = N; prev = -np.inf; cens_t = []; ev = []; notes = []; alt_err = []
    for j in range(len(k)):
        q = 1 - sa[j] / sb[j]
        # ticks strictly between previous and current drop are censorings before this event time
        m = (ct > prev + RES_T / 2) & (ct < et[j] - RES_T / 2) & ~used
        cens_t += list(ct[m]); used |= m; n -= m.sum()
        # ticks drawn at the drop abscissa: decide from the drop ratio whether the subject was in the risk set
        m2 = (np.abs(ct - et[j]) <= RES_T / 2) & ~used
        dd = max(1, int(round(n * q)))
        if m2.any():
            nin = n; nout = n - m2.sum()
            e_in = abs(nin * q - round(nin * q)); e_out = abs(nout * q - round(nout * q))
            if e_out < e_in:   # censored subject not at risk: censored just before event, below display resolution
                cens_t += list(ct[m2] - RES_T / 2); used |= m2; n = nout
                notes.append(dict(time=float(et[j]), ticks=int(m2.sum()), fit_err_in_riskset=float(e_in), fit_err_excluded=float(e_out),
                                  resolution='censored at event time minus half display resolution'))
            dd = max(1, int(round(n * q)))
        alt_err.append((abs(n * q - dd), min(abs(n * q - (dd + 1)), abs(n * q - (dd - 1)) if dd > 1 else 9)))
        ev += [et[j]] * dd; n -= dd; prev = et[j]
        if m2.any() and not used[m2].all():   # tied censoring kept at the event time (in the risk set)
            m3 = m2 & ~used; cens_t += list(ct[m3]); used |= m3; n -= m3.sum()
            notes.append(dict(time=float(et[j]), ticks=int(m3.sum()), fit_err_in_riskset=float(e_in), fit_err_excluded=float(e_out),
                              resolution='censoring tied with event, kept in risk set'))
    m = ~used & (ct > prev - RES_T / 2); cens_t += list(ct[m]); used |= m; n -= m.sum()
    if n != 0 or not used.all():
        raise SystemExit(f'group {g}: unreconciled count n={n}, unused ticks={(~used).sum()}')
    recs += [(g, float(x), 1) for x in ev] + [(g, float(x), 0) for x in cens_t]
    ae = np.array(alt_err)
    diag[g] = dict(n_events=len(ev), n_censored=len(cens_t), n_drops=len(k), max_events_per_drop=int(max(np.bincount(np.searchsorted(et, ev))) if ev else 0),
                   max_abs_nq_minus_d=float(ae[:, 0].max()), min_abs_nq_minus_alt_d=float(ae[:, 1].min()),
                   tie_decisions=notes, path_end_time=float(t[-1]), last_tick_time=float(ct.max()))

df = pd.DataFrame(recs, columns=['group', 'observed_time', 'event']).sort_values(['group', 'observed_time', 'event'], ascending=[True, True, False])
assert (df.observed_time >= 0).all() and np.isfinite(df.observed_time).all()
os.makedirs(a.output, exist_ok=True)
tmp = os.path.join(a.output, '.ipd.csv.tmp')
df.to_csv(tmp, index=False, float_format='%.7f'); os.replace(tmp, os.path.join(a.output, 'ipd.csv'))
pd.DataFrame(obs_rows, columns=['group', 'kind', 'time_months', 'survival']).to_csv(os.path.join(a.output, 'measured_observations.csv'), index=False, float_format='%.7f')
json.dump(dict(seed=SEED, calibration=dict(x_pt=[x0, bx, rx], y_pt=[y0, by, ry], res_t=RES_T, res_s=RES_S), groups=diag),
          open(os.path.join(a.output, 'reconstruction_diagnostics.json'), 'w'), indent=1)
print(json.dumps(diag, indent=1))
