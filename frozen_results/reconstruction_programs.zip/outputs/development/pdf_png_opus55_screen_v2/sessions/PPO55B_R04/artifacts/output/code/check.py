"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured PDF path, risk table and sizes.
Usage: python check.py [--input DIR] [--output DIR]"""
import argparse, hashlib, json, os
import numpy as np, pandas as pd
ap = argparse.ArgumentParser(); ap.add_argument('--input', default=os.path.join('..', 'input')); ap.add_argument('--output', default='output')
a = ap.parse_args()
man = json.load(open(os.path.join(a.input, 'manifest.json')))
raw = json.load(open(os.path.join(a.output, 'extracted_raw.json')))
dg = json.load(open(os.path.join(a.output, 'reconstruction_diagnostics.json')))
x0, bx, _ = dg['calibration']['x_pt']; y0, by, _ = dg['calibration']['y_pt']
TOL_S = 1e-5   # ~18x the 5.6e-7 survival resolution of 4-decimal PDF coordinates, plus accumulation of rounding in products
path = os.path.join(a.output, 'ipd.csv')
sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
df = pd.read_csv(path)
def km(tt, ee):
    ut = np.unique(tt[ee == 1]); S = 1.0; out = []
    for u in ut:
        n = np.sum(tt >= u); d = np.sum((tt == u) & (ee == 1)); S *= 1 - d / n; out.append((u, S))
    return np.array(out)
def step(K, t):   # right-continuous
    i = np.searchsorted(K[:, 0], t, side='right') - 1
    return 1.0 if i < 0 else float(K[i, 1])
def meas(pts, t):  # measured path level at t (right-continuous: last vertex with time <= t)
    tt = (pts[:, 0] - x0) / bx; ss = (pts[:, 1] - y0) / by
    i = np.where(tt <= t + 1e-12)[0]; return float(ss[i[-1]])
chk = dict(csv_sha256=sha, tolerance=dict(survival=TOL_S, justification='PDF coordinates carry 4 decimals in points (1e-4/180 = 5.6e-7 in S); tolerance allows accumulated rounding'), groups={})
allpass = True
for g in 'AB':
    d = df[df.group == g]; tt = d.observed_time.values; ee = d.event.values
    K = km(tt, ee); pts = np.array(raw['curves'][g])
    tv = (pts[:, 0] - x0) / bx
    # every path vertex (after each drop) plus grid and tail times
    grid = sorted(set([0, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 34, 35, 35.5, float(tv[-1])]))
    comp = []
    for t in grid:
        if t > tv[-1] + 1e-9: continue
        m = meas(pts, t); r = step(K, t); comp.append(dict(time=round(t, 6), measured=round(m, 7), reconstructed=round(r, 7), residual=round(r - m, 8), status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # level of every horizontal path segment, evaluated at its midpoint (avoids float ties at drop abscissae)
    vres = []
    sv = (pts[:, 1] - y0) / by
    for i in range(len(pts) - 1):
        if tv[i + 1] - tv[i] > 1e-9:
            vres.append(abs(step(K, 0.5 * (tv[i] + tv[i + 1])) - sv[i]))
    # risk table
    rk = []
    for n_disp, xc in raw['risk_raw'][g]:
        t = round((xc - x0) / bx, 4)
        nr = int(np.sum(tt >= t)); st = 'pass' if nr == n_disp else 'fail'
        rk.append(dict(time=t, displayed=n_disp, reconstructed=nr, residual=nr - n_disp, status=st))
    ev_total = man.get('events', {}).get(g) if isinstance(man.get('events'), dict) else None
    G = dict(n_records=len(d), n_expected=man['groups'][g], size_status='pass' if len(d) == man['groups'][g] else 'fail',
             event_indicator_status='pass' if set(np.unique(ee)) <= {0, 1} and d.event.dtype.kind == 'i' else 'fail',
             n_events=int(ee.sum()), supplied_event_total='unavailable (not in manifest)' if ev_total is None else ev_total,
             time_min=float(tt.min()), time_max=float(tt.max()),
             km_vs_measured_selected=comp,
             km_vs_measured_all_flat_segments=dict(n_times=len(vres), max_abs_residual=float(max(vres)), status='pass' if max(vres) <= TOL_S else 'fail'),
             risk_table=rk)
    ok = G['size_status'] == 'pass' and G['event_indicator_status'] == 'pass' and all(c['status'] == 'pass' for c in comp) and G['km_vs_measured_all_flat_segments']['status'] == 'pass' and all(c['status'] == 'pass' for c in rk)
    G['overall'] = 'pass' if ok else 'fail'; allpass &= ok
    chk['groups'][g] = G
chk['overall'] = 'pass' if allpass else 'fail'
json.dump(chk, open(os.path.join(a.output, 'checks.json'), 'w'), indent=1)
for g in 'AB':
    G = chk['groups'][g]; print(g, G['overall'], G['n_records'], G['n_events'], G['km_vs_measured_all_flat_segments'], [(r['time'], r['displayed'], r['reconstructed']) for r in G['risk_table']])
    print('  ', [(c['time'], c['measured'], c['residual']) for c in G['km_vs_measured_selected']])
print(sha)
