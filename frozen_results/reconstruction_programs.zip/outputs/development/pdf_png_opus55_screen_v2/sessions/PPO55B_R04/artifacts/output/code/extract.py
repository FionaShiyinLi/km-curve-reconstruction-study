"""Extract KM step paths, censor ticks, axis calibration and risk table from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, os
import pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', '..', 'input', 'figure.pdf')
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), '..')
pg = pdfplumber.open(pdf).pages[0]
COL = {'A': (0.121569, 0.466667, 0.705882), 'B': (1.0, 0.498039, 0.054902)}
words = pg.extract_words()
# axis anchors: tick labels and black tick marks
xt = [l for l in pg.lines if l['stroking_color'] in ((0, 0, 0), (0.0, 0.0, 0.0)) and abs(l['x1'] - l['x0']) < 1e-6 and abs(l['bottom'] - l['top'] - 3) < 1e-6]
yt = [l for l in pg.lines if l['stroking_color'] in ((0, 0, 0), (0.0, 0.0, 0.0)) and abs(l['bottom'] - l['top']) < 1e-6 and abs(l['x1'] - l['x0'] - 3) < 1e-6]
xlab = sorted([(float(w['text']), (w['x0'] + w['x1']) / 2) for w in words if w['top'] > 229 and w['top'] < 240])
ylab = sorted([(float(w['text']), (w['top'] + w['bottom']) / 2) for w in words if w['x0'] > 40 and w['x1'] < 60 and w['top'] < 230])
xtick = sorted(l['x0'] for l in xt); ytick = sorted(l['top'] for l in yt)
# pair tick labels with nearest tick mark
xa = [(v, min(xtick, key=lambda t: abs(t - c))) for v, c in xlab]
ya = [(v, min(ytick, key=lambda t: abs(t - c))) for v, c in ylab]
res = {'x_anchors': xa, 'y_anchors': ya, 'curves': {}, 'ticks': {}}
for g, col in COL.items():
    cv = [c for c in pg.curves if tuple(c['stroking_color']) == col]
    assert len(cv) == 1
    res['curves'][g] = [list(p) for p in cv[0]['pts']]
    tk = [l for l in pg.lines if tuple(l['stroking_color']) == col and abs(l['x1'] - l['x0']) < 1e-9 and abs(l['bottom'] - l['top'] - 4) < 1e-6]
    res['ticks'][g] = sorted([[l['x0'], (l['top'] + l['bottom']) / 2] for l in tk])
# risk table
rows = {}
for w in words:
    if w['top'] > 280:
        rows.setdefault(round(w['top']), []).append(w)
risk = {}
for top, ws in rows.items():
    ws.sort(key=lambda w: w['x0'])
    g = ws[1]['text']
    risk[g] = [(int(w['text']), (w['x0'] + w['x1']) / 2) for w in ws[2:]]
res['risk_raw'] = risk
json.dump(res, open(os.path.join(out, 'extracted_raw.json'), 'w'))
print(xa, ya, {g: len(v) for g, v in res['ticks'].items()}, risk)
