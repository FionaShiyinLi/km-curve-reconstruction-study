#!/usr/bin/env python3
"""Reload committed output/ipd.csv, recompute right-continuous KM per arm, compare with the
measured curve and printed risk table; write output/checks.json. Optionally compare
output/sensitivity.csv at a common horizon.
Usage: python3 output/code/checks.py [--out output]"""
import argparse, hashlib, json, os
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument('--out', default='output'); args = ap.parse_args()
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 692, 485, 331, 234, 88, 0], 'B': [1000, 647, 525, 436, 354, 143, 0]}
N = {'A': 1000, 'B': 1000}
# tolerance: plotted line is 4-5 px thick (1 px = 0.00133 survival); centre uncertainty ~ +/-2 px
# plus column-level step-timing uncertainty (1 px = 0.025 mo) on steep segments -> 0.006
TOL = 0.006
CHECK_T = [0.25, 1, 2, 3, 4.5, 6, 8, 10, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.9]


def km(df):
    t = df.observed_time.values; e = df.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n; out.append((u, s))
    return np.array(out)


def S_at(curve, t):  # right-continuous step
    k = np.searchsorted(curve[:, 0], t, side='right')
    return 1.0 if k == 0 else curve[k - 1, 1]


def rmst(curve, h):
    ts = np.concatenate([[0], curve[curve[:, 0] < h, 0], [h]])
    ss = np.concatenate([[1.0], curve[curve[:, 0] < h, 1]])
    return float(np.sum(np.diff(ts) * ss))


path = os.path.join(args.out, 'ipd.csv')
raw = open(path, 'rb').read()
ipd = pd.read_csv(path)
mc = pd.read_csv(os.path.join(args.out, 'measured_curve.csv'))
res = {'csv': 'output/ipd.csv', 'sha256': hashlib.sha256(raw).hexdigest(), 'tolerance_surv': TOL,
       'tolerance_justification': 'line 4-5 px thick (1 px = 0.00133 survival) and 1 px = 0.025 months '
                                  'step-timing uncertainty on steep segments',
       'event_totals': 'unavailable (not supplied in manifest)', 'arms': {}}
ok_all = True
for g in ['A', 'B']:
    d = ipd[ipd.group == g]
    a = {'n_records': int(len(d)), 'n_expected': N[g], 'n_pass': bool(len(d) == N[g]),
         'event_integer_01': bool(d.event.isin([0, 1]).all()),
         'times_finite_nonneg': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
         'events': int(d.event.sum()), 'censored': int((d.event == 0).sum()),
         'max_time': float(d.observed_time.max())}
    c = km(d); m = mc[mc.group == g]
    comp = []
    for t in CHECK_T:
        # measured value: curve level in the pixel column at time t
        j = np.argmin(np.abs(m.time.values - t))
        if abs(m.time.values[j] - t) > 0.05:
            comp.append(dict(time=t, status='unavailable')); continue
        meas = float(m.surv.values[j]); rec = float(S_at(c, t))
        r = rec - meas
        comp.append(dict(time=t, measured=round(meas, 4), reconstructed=round(rec, 4), residual=round(r, 4),
                         status='pass' if abs(r) <= TOL else 'fail'))
    a['km_vs_measured'] = comp
    # dense comparison over all measured columns
    rr = np.array([S_at(c, t) for t in m.time.values]) - m.surv.values
    a['all_columns_max_abs_residual'] = round(float(np.abs(rr).max()), 4)
    a['all_columns_mean_abs_residual'] = round(float(np.abs(rr).mean()), 5)
    risk = []
    for t, n in zip(RISK_T, RISK[g]):
        r = int((d.observed_time >= t).sum())
        risk.append(dict(time=t, printed=n, reconstructed=r, residual=r - n, status='pass' if r == n else 'fail'))
    a['risk_table'] = risk
    a['risk_table_convention'] = 'count observed_time >= t'
    ok_all &= a['n_pass'] and all(x['status'] == 'pass' for x in risk)
    res['arms'][g] = a

sp = os.path.join(args.out, 'sensitivity.csv')
if os.path.exists(sp):
    sen = pd.read_csv(sp)
    H = 35.9
    sc = {'horizon_months': H, 'assumption': 'censorings spread uniformly over measured columns of each '
          'risk-table interval, ignoring tick positions', 'arms': {}}
    for g in ['A', 'B']:
        cp, cs = km(ipd[ipd.group == g]), km(sen[sen.group == g])
        sc['arms'][g] = {'S_primary': {t: round(S_at(cp, t), 4) for t in [6, 12, 18, 24, 30, H]},
                         'S_sensitivity': {t: round(S_at(cs, t), 4) for t in [6, 12, 18, 24, 30, H]},
                         'RMST_primary': round(rmst(cp, H), 3), 'RMST_sensitivity': round(rmst(cs, H), 3),
                         'events_primary': int(ipd[ipd.group == g].event.sum()),
                         'events_sensitivity': int(sen[sen.group == g].event.sum()),
                         'sensitivity_risk_table': [int((sen[sen.group == g].observed_time >= t).sum()) for t in RISK_T]}
    sc['sha256'] = hashlib.sha256(open(sp, 'rb').read()).hexdigest()
    res['sensitivity'] = sc
else:
    res['sensitivity'] = 'not run'
json.dump(res, open(os.path.join(args.out, 'checks.json'), 'w'), indent=1)
for g in ['A', 'B']:
    a = res['arms'][g]
    print(g, a['n_records'], a['events'], a['max_time'], a['all_columns_max_abs_residual'], a['all_columns_mean_abs_residual'])
    print('  ', [(x['time'], x.get('residual'), x['status']) for x in a['km_vs_measured']])
    print('  ', [(x['time'], x['reconstructed'], x['status']) for x in a['risk_table']])
if isinstance(res['sensitivity'], dict): print(json.dumps(res['sensitivity']['arms'], indent=0))
