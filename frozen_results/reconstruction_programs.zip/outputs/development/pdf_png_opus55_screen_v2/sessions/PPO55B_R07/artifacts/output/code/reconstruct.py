#!/usr/bin/env python3
"""KM-figure -> approximate IPD reconstruction (own implementation, no KM-to-IPD package).

Usage: python3 output/code/reconstruct.py [--input ../input] [--out output] [--variant primary|sensitivity]

Steps
1. Calibrate axes from detected tick marks (x: 0..36 months, y: 0..1).
2. Per arm, colour-segment the curve, measure the line centre in every pixel column
   (horizontal-run pixels preferred so that censor ticks do not bias the level),
   despike, and enforce monotonicity (pool-adjacent-violators).
3. Detect censor ticks as colour pixels lying above the left-hand line level
   (a KM drop never rises above the preceding level).
4. Per risk-table interval, search the integer number of censorings c so that the
   reconstructed number at risk at the next table time matches the printed number.
   Events at each column: d = round(n_risk * (1 - S_meas / S_hat_prev)) (self-correcting,
   Guyot-style). Censorings are placed at detected tick clusters (primary) or uniformly
   in the interval (sensitivity variant).
"""
import argparse, hashlib, json, os, sys
import numpy as np
import pandas as pd
from PIL import Image

SEED = 1594711583  # supplied code seed; the algorithm is deterministic, seed recorded only
np.random.seed(SEED)

ap = argparse.ArgumentParser()
ap.add_argument('--input', default='../input')
ap.add_argument('--out', default='output')
ap.add_argument('--variant', default='primary', choices=['primary', 'sensitivity'])
args = ap.parse_args()

man = json.load(open(os.path.join(args.input, 'manifest.json')))
img = np.asarray(Image.open(os.path.join(args.input, 'figure.png')).convert('RGB')).astype(int)
R, G, B = img[..., 0], img[..., 1], img[..., 2]
H, W = R.shape

# ---------------- 1. axis calibration from tick marks ----------------
blk = (R < 80) & (G < 80) & (B < 80)
xaxis_row = int(np.argmax(blk.sum(1)))            # horizontal axis line
yaxis_col = int(np.argmax(blk.sum(0)))            # vertical axis line
# x ticks: black columns in the rows just below the axis line, right of y-axis
below = blk[xaxis_row + 3:xaxis_row + 10, :].all(0)
xs = np.where(below)[0]
xs = xs[xs >= yaxis_col - 3]
groups = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1)
xtick_px = np.array([g.mean() for g in groups])
xtick_val = np.arange(len(xtick_px)) * 6.0        # labels 0,6,...,36 (read from figure)
# y ticks: black rows just left of the axis line
left = blk[:, yaxis_col - 10:yaxis_col - 3].all(1)
ys = np.where(left)[0]
groups = np.split(ys, np.where(np.diff(ys) > 1)[0] + 1)
ytick_px = np.array([g.mean() for g in groups])
ytick_val = 1.0 - np.arange(len(ytick_px)) * 0.2  # labels 1.0,0.8,...,0.0 (top to bottom)
ax_, bx_ = np.polyfit(xtick_px, xtick_val, 1)
ay_, by_ = np.polyfit(ytick_px, ytick_val, 1)
xres = np.max(np.abs(np.polyval([ax_, bx_], xtick_px) - xtick_val))
yres = np.max(np.abs(np.polyval([ay_, by_], ytick_px) - ytick_val))
t_of = lambda x: ax_ * x + bx_
s_of = lambda y: ay_ * y + by_
calib = dict(xtick_px=xtick_px.tolist(), xtick_val=xtick_val.tolist(), ytick_px=ytick_px.tolist(),
             ytick_val=ytick_val.tolist(), months_per_px=ax_, surv_per_px=ay_,
             max_abs_resid_months=xres, max_abs_resid_surv=yres)

# risk table read visually from the figure (OCR not available; digits are clear)
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [1000, 692, 485, 331, 234, 88, 0], 'B': [1000, 647, 525, 436, 354, 143, 0]}

plot_top = int(ytick_px.min()) - 25
plot_bot = xaxis_row - 2
masks = {'A': (B - R > 50) & (B > 100), 'B': (R - B > 100) & (R > 150)}
LINE_HALF = 2.0      # line ~4-5 px thick
TICK_HALF = 8        # censor tick spans ~17 px, i.e. +/-8 px about line centre


def measure(m):
    m = m.copy(); m[:plot_top] = 0; m[plot_bot:] = 0; m[:, :yaxis_col + 2] = 0
    # horizontal-run pixels: run of >=5 centred on pixel
    hm = m.copy()
    for k in (-2, -1, 1, 2):
        hm &= np.roll(m, k, axis=1)
    cols = np.where(m.any(0))[0]
    x0, x1 = cols.min(), cols.max()
    level = np.full(W, np.nan)
    tickcol = np.zeros(W, bool)
    for x in range(x0, x1 + 1):
        r = np.where(hm[:, x])[0]
        if len(r):
            grp = np.split(r, np.where(np.diff(r) > 1)[0] + 1)[-1]   # lowest horizontal group
            level[x] = grp.mean()
            continue
        r = np.where(m[:, x])[0]
        if not len(r):
            continue
        grp = np.split(r, np.where(np.diff(r) > 1)[0] + 1)
        g = max(grp, key=len)
        level[x] = g.mean() if len(g) <= 6 else g.max() - 1.5       # post-drop level in steep columns
        if len(g) >= 12:
            # censor tick on a steep segment: its run extends above the top of the column 3 px
            # to the left AND below the bottom of the column 3 px to the right (a drop does not).
            rl = np.where(m[:, x - 3])[0]; rr = np.where(m[:, x + 3])[0]
            t_l = rl.min() if len(rl) else ytick_px.min() - LINE_HALF   # left of curve start: S=1 line
            b_r = rr.max() if len(rr) else g.max()
            if g.min() < t_l - 3 and g.max() > b_r + 3:
                tickcol[x] = True
    raw = level.copy()
    # tick-contaminated steep columns: linear interpolation between neighbouring clean columns
    good = ~np.isnan(level) & ~tickcol
    xs_ = np.arange(W)
    for x in np.where(tickcol)[0]:
        lg = xs_[:x][good[:x]]; rg = xs_[x + 1:][good[x + 1:]]
        if len(lg) and len(rg) and rg[0] - lg[-1] <= 12:
            level[x] = np.interp(x, [lg[-1], rg[0]], [level[lg[-1]], level[rg[0]]])
        elif len(rg) and not len(lg):   # at the origin: interpolate from S=1 at the axis
            level[x] = np.interp(x, [xtick_px[0], rg[0]], [ytick_px.min(), level[rg[0]]])
    # forward fill occluded columns (curve hidden under the other arm)
    last = np.nan
    for x in range(x0, x1 + 1):
        if np.isnan(level[x]): level[x] = last
        else: last = level[x]
    # despike: replace values > 3 px from 9-column median
    seg = level[x0:x1 + 1].copy()
    med = np.array([np.nanmedian(seg[max(0, i - 4):i + 5]) for i in range(len(seg))])
    spike = np.abs(seg - med) > 3
    seg[spike] = med[spike]
    # PAVA: y pixel must be non-decreasing (survival non-increasing)
    vals, wts = [], []
    for v in seg:
        vals.append(v); wts.append(1)
        while len(vals) > 1 and vals[-2] > vals[-1]:
            v2, w2 = vals.pop(), wts.pop(); v1, w1 = vals.pop(), wts.pop()
            vals.append((v1 * w1 + v2 * w2) / (w1 + w2)); wts.append(w1 + w2)
    iso = np.concatenate([[v] * w for v, w in zip(vals, wts)])
    level[x0:x1 + 1] = iso
    # censor ticks: a tick extends both above AND below the line centre (+/-TICK_HALF px);
    # a KM drop column only has pixels above the post-drop level, never below it.
    tick = np.zeros(W, bool)
    for x in range(x0 + 1, x1 + 1):
        L = level[x]
        up = m[int(round(L - TICK_HALF)):int(round(L - LINE_HALF - 1.5)), x].sum()
        dn = m[int(round(L + LINE_HALF + 2)):int(round(L + TICK_HALF + 1)), x].sum()
        if up >= 3 and dn >= 3:
            tick[x] = True
    tc = np.where(tick)[0]
    clusters = [] if not len(tc) else np.split(tc, np.where(np.diff(tc) > 1)[0] + 1)
    return x0, x1, raw, level, clusters, (int(spike.sum()), int(tickcol.sum()))


def reconstruct(arm, x0, x1, level, clusters, variant):
    xcols = np.arange(x0, x1 + 1)
    tcol = t_of(xcols)
    tcol = np.clip(tcol, 0, None)
    S = np.clip(s_of(level[x0:x1 + 1]), 0, 1)
    S = np.minimum(S, 1.0)
    # tick clusters -> (time, weight). Width of a single tick measured as modal cluster width.
    widths = np.array([len(c) for c in clusters])
    w1 = max(1, int(np.median(widths))) if len(widths) else 1
    ticks = [(t_of(c.mean()), max(1.0, len(c) / w1)) for c in clusters]
    nrisk = RISK[arm]
    ev_t, ce_t = [], []
    S_hat = 1.0
    n = nrisk[0]
    info = []
    for i in range(len(RISK_T) - 1):
        ta, tb = RISK_T[i], RISK_T[i + 1]
        idx = np.where((tcol >= ta) & (tcol < tb))[0]
        if not len(idx):
            break
        tk = [(t, w) for t, w in ticks if ta <= t < tb and t <= tcol[idx[-1]]]
        last_iv = (nrisk[i + 1] == 0)
        target = nrisk[i + 1]

        def place(c):
            if c <= 0: return np.array([])
            if variant == 'primary' and tk:
                tt = np.array([t for t, _ in tk]); ww = np.array([w for _, w in tk])
                if c >= len(tk):
                    extra = c - len(tk)
                    q = extra * ww / ww.sum(); k = np.floor(q).astype(int)
                    rem = extra - k.sum()
                    k[np.argsort(-(q - k))[:rem]] += 1
                    return np.repeat(tt, 1 + k)
                pick = np.round(np.linspace(0, len(tk) - 1, c)).astype(int)
                return tt[pick]
            # uniform over the interval's measured columns
            lo, hi = tcol[idx[0]], tcol[idx[-1]]
            return lo + (hi - lo) * (np.arange(c) + 0.5) / c

        def run(c):
            cts = np.sort(place(c))
            nn, sh = n, S_hat
            evs = []
            ci = 0
            for j in idx:
                # censorings strictly before this column's time leave the risk set first
                while ci < len(cts) and cts[ci] < tcol[j] - 1e-9:
                    nn -= 1; ci += 1
                if nn > 0 and S[j] < sh:
                    d = int(round(nn * (1 - S[j] / sh)))
                    d = max(0, min(d, nn))
                    if d:
                        evs += [tcol[j]] * d
                        sh *= (1 - d / nn); nn -= d
                while ci < len(cts) and cts[ci] <= tcol[j] + 1e-9:
                    nn -= 1; ci += 1
            nn -= (len(cts) - ci)
            return nn, evs, cts, sh

        best = None
        for c in range(0, n + 1):
            nn, evs, cts, sh = run(c)
            if nn < 0: break
            err = abs(nn - target)
            if best is None or err < best[0]:
                best = (err, c, nn, evs, cts, sh)
            if nn < target: break
        err, c, nn, evs, cts, sh = best
        if last_iv and nn > 0:
            # printed 0 at 36: remaining participants censored at the last measured column (<36)
            cts = np.concatenate([cts, [tcol[idx[-1]]] * nn]); nn = 0
        ev_t += list(evs); ce_t += list(cts)
        info.append(dict(interval=[ta, tb], n_start=n, n_end_printed=target, n_end_recon=int(nn),
                         events=len(evs), censored=int(len(cts)), tick_clusters=len(tk),
                         tick_weight=float(sum(w for _, w in tk))))
        n, S_hat = nn, sh
    df = pd.DataFrame({'group': arm,
                       'observed_time': np.round(np.concatenate([ev_t, ce_t]), 4),
                       'event': [1] * len(ev_t) + [0] * len(ce_t)})
    return df, info, w1


os.makedirs(args.out, exist_ok=True)
frames, meta, meas_out = [], {'calibration': calib, 'seed': SEED, 'variant': args.variant, 'arms': {}}, []
for arm in ['A', 'B']:
    x0, x1, raw, level, clusters, nspk = measure(masks[arm])
    df, info, w1 = reconstruct(arm, x0, x1, level, clusters, args.variant)
    if len(df) != man['groups'][arm]:
        print(f'arm {arm}: {len(df)} records != {man["groups"][arm]}; not committed', file=sys.stderr)
        continue
    frames.append(df)
    meta['arms'][arm] = dict(x_range=[int(x0), int(x1)], despiked_columns=nspk[0], steep_tick_columns_interpolated=nspk[1], n_tick_clusters=len(clusters),
                             single_tick_width_px=w1, intervals=info,
                             events=int(df.event.sum()), censored=int((df.event == 0).sum()))
    for x in range(x0, x1 + 1):
        meas_out.append(dict(group=arm, x_px=x, time=round(t_of(x), 4),
                             raw_y_px=None if np.isnan(raw[x]) else round(raw[x], 2),
                             y_px=round(level[x], 2), surv=round(float(s_of(level[x])), 5)))
    pd.DataFrame([dict(group=arm, time=round(t_of(c.mean()), 4), width_px=len(c)) for c in clusters]) \
        .to_csv(os.path.join(args.out, f'ticks_{arm}.csv'), index=False)

name = 'ipd.csv' if args.variant == 'primary' else 'sensitivity.csv'
if frames:
    out = pd.concat(frames, ignore_index=True)
    tmp = os.path.join(args.out, name + '.tmp')
    out.to_csv(tmp, index=False)
    os.replace(tmp, os.path.join(args.out, name))
    print('wrote', name, out.groupby('group').event.agg(['size', 'sum']).to_dict())
pd.DataFrame(meas_out).to_csv(os.path.join(args.out, 'measured_curve.csv'), index=False)
json.dump(meta, open(os.path.join(args.out, f'recon_meta_{args.variant}.json'), 'w'), indent=1, default=float)
print(json.dumps(meta, indent=1, default=float)[:4000])
