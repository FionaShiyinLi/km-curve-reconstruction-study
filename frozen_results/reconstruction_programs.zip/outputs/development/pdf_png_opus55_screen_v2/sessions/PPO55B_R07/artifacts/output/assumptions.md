# Reconstruction assumptions and limitations

## Inputs used
- `../input/figure.png` (raster, 1800x1350 pixels) and `../input/manifest.json` (n = 1000 per arm, months, seed 1594711583).
- I read the number-at-risk table visually from the figure (OCR was unavailable; the digits are unambiguous):
  A 1000/692/485/331/234/88/0 and B 1000/647/525/436/354/143/0 at 0/6/12/18/24/30/36 months.
- No arm-specific event totals were supplied. Event totals are therefore unconstrained by auxiliary data
  (reported as `unavailable` in checks.json). A missing total is not treated as zero events.

## Algorithm (`code/reconstruct.py`, deterministic; seed set and recorded but unused)
1. **Calibration.** The axis lines and tick marks are detected in the pixels. x: 0 months at px 269.5 and 36 months at px 1709.5
   (0.025 months/px). y: 1.0 at px 179.5 and 0.0 at px 929.5. A linear fit through all 7 and 6 ticks has zero residual.
   I applied no global rescaling or renormalization of the curve.
2. **Curve measurement.** Each arm is segmented by colour. In every pixel column, the line centre is taken from
   horizontal-run pixels (run of 5 or more), which excludes the vertical censor ticks. On steep segments with no horizontal run,
   the post-drop level of the vertical run is used. Columns hidden under the other arm are forward-filled.
   Isolated spikes (>3 px from the 9-column median; 4 columns in A, 2 in B) are replaced by the median.
   Monotonicity is then enforced by pool-adjacent-violators. No running-minimum propagation is used.
   Measurements are in `measured_curve.csv` (raw and final pixel level per column).
3. **Origin.** Both arms start at S=1 (KM definition) and drop steeply in the first 0.3 months. I zoomed into the origin
   neighborhood and checked it. B has a mark at about 0.05 months whose top coincides with the S=1 line. It could be a censor tick
   or a steep drop. The measured level (S≈0.986 by 0.04 months) is kept, so about 14 B events sit at 0.04 months. If that mark is a tick,
   those events belong over roughly the first 0.2 months instead (a timing difference below 0.2 months, S difference ≤0.005).
   A guard that interpolates tick-contaminated steep columns was added. It triggered on no columns, so the primary file
   did not change. These early drops are kept as genuine drops rather than forced flat.
4. **Censor ticks.** Ticks are columns with colour pixels both 4-8 px above and 4-8 px below the line centre.
   A KM drop never extends below its post-drop level. Adjacent tick columns are merged into clusters (`ticks_A.csv`, `ticks_B.csv`).
   The single-tick width is 3 px. Tick *visibility* does not identify *multiplicity*: overlapping ticks, especially the dense blocks
   after 24 months, are given weight width/3 only as an allocation device.
5. **Events and censoring per risk-table interval [t_i, t_{i+1}).** For each candidate integer censoring count c, censorings are
   placed at the tick clusters in the interval. Each cluster gets at least one when c ≥ number of clusters, and the extra censorings are split in proportion to cluster width.
   Events are then computed column by column as d = round(n_risk·(1 − S_meas/Ŝ_prev)), with Ŝ the reconstructed KM.
   This self-corrects rounding drift and does **not** assume d=1 per visible step: a column drop can yield several tied events.
   Events in a column are processed before censorings in the same column. The chosen c reproduces the printed number at risk
   at t_{i+1} exactly (count of observed_time ≥ t). In the last interval the printed count at 36 is 0. Anyone remaining after
   the last measured column would be censored at that column (35.96 months, <36), never at 36.
   Interval details are in `recon_meta_primary.json`.

## Result
A: 781 events, 219 censored. B: 621 events, 379 censored. Most censoring falls in 24-36 months (A 176, B 296),
consistent with the dense tick blocks. Earlier intervals have 5-33 censorings each.

## Verification (`code/checks.py`, results in `checks.json`)
The checks reload the committed CSV and recompute the right-continuous KM step function (no interpolation).
- KM versus measured curve at 20 times from 0.25 to 35.9 months: all within the ±0.006 tolerance (line 4-5 px thick; 1 px = 0.00133).
  Over all columns, the maximum absolute residual is 0.0023 (A) and 0.0040 (B); the mean is 0.0004 and 0.0006.
  The largest residuals are in the tail (34-35.9 months, B +0.004). The last events there are allocated with small risk sets, where one event ≈0.002-0.003.
- Risk table: exact match at all 7 times in both arms, including 0 at 36 months (maximum time 35.9625).
- 1000 records per arm, event ∈ {0,1}, all times finite and nonnegative.

## Sensitivity (one alternative, `sensitivity.csv`)
The alternative spreads censorings uniformly over each interval's measured columns and ignores tick positions.
The risk table is still matched exactly. At the common supported horizon of 35.9 months:
S_A 0.1420 (primary) vs 0.1417 (alternative), S_B 0.2940 vs 0.2899. RMST(35.9) is 15.293 vs 15.290 months for A and 18.423 vs 18.417 for B.
Event counts are A 781 vs 784 and B 621 vs 621. This single alternative is not a bound on reconstruction error.

## Unresolved limitations
- Exact event and censoring times are known only to column resolution (0.025 months). Tie structure within a column is not identified.
- Censoring multiplicity in overlapping tick blocks and the within-interval censoring pattern are assumptions, constrained only by
  the printed risk counts and the visible tick positions. Censorings hidden under the other arm's line (crossing region, 6.5-9 months) cannot be seen.
- Where arm A is hidden beneath arm B (origin and 6.5-9 months), the A level is forward-filled, which can delay A drops by a few columns.
- The flat tails do not identify follow-up beyond the last plotted time. No follow-up beyond 35.96 months is assumed.
