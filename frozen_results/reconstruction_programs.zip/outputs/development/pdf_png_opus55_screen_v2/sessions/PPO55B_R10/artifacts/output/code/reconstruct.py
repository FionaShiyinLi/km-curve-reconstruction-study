#!/usr/bin/env python3
"""Reconstruct approximate participant-level time-to-event records from a KM raster figure.

Own implementation (no KM-to-IPD package). Steps:
  1. calibrate axes from tick-mark pixels (x: 0..36 months, y: 0..1);
  2. unmix antialiased pixels into blue (group A) / orange (group B) coverage;
  3. per pixel column, measure the sub-pixel line centre on "clean" columns
     (no censor tick, no occlusion by the other arm), fit a nonincreasing
     curve by isotonic regression (PAVA), interpolate across unclean columns;
  4. detect censor ticks (ink 5-8 px below and above the line) and estimate
     a lower-bound multiplicity per tick cluster from its ink mass;
  5. within each risk-table interval, choose the number censored so that the
     reconstructed number at risk at the next table time matches the table,
     deriving events per column from d = round(n_risk * (1 - S_c / Shat_prev)).

Usage: python3 reconstruct.py [--input ../input] [--out output] [--alloc tick|uniform]
Deterministic; the manifest seed is recorded and used to seed numpy although
no random draws are made.
"""
import argparse, json, os, hashlib
import numpy as np
import pandas as pd
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
WHITE = np.array([255., 255., 255.])
BLUE = np.array([31., 119., 180.])
ORANGE = np.array([255., 127., 14.])
ARMS = {"A": 0, "B": 1}  # index into unmixed channels: A = blue, B = orange


def load(path):
    return np.array(Image.open(path).convert("RGB")).astype(float)


def unmix(a):
    M = np.stack([BLUE - WHITE, ORANGE - WHITE], 1)
    P = np.linalg.pinv(M)
    x = (a - WHITE) @ P.T
    resid = np.linalg.norm((a - WHITE) - x @ M.T, axis=2)
    x = np.clip(x, 0, 1)
    x[resid > 40] = 0  # black/grey (axes, text) are not curve ink
    return x


def groups(idx):
    out, cur = [], [idx[0]]
    for v in idx[1:]:
        if v == cur[-1] + 1:
            cur.append(v)
        else:
            out.append(cur); cur = [v]
    out.append(cur)
    return [np.mean(g) for g in out]


def calibrate(a):
    blk = a.sum(2) < 300
    axis_row = int(np.argmax(blk.sum(1)))          # x-axis line (lower of 2 px)
    axis_col = int(np.argmax(blk.sum(0)))          # y-axis line
    xt = groups(np.where(blk[axis_row + 3:axis_row + 12, axis_col - 2:].sum(0) > 5)[0] + axis_col - 2)
    yt = groups(np.where(blk[:axis_row + 3, axis_col - 12:axis_col - 2].sum(1) > 5)[0])
    xv = np.arange(0, 37, 6.0); yv = np.round(np.arange(1.0, -0.01, -0.2), 1)
    assert len(xt) == len(xv) and len(yt) == len(yv), (xt, yt)
    bx = np.polyfit(xv, xt, 1); by = np.polyfit(yv, yt, 1)
    res = {"x_px_per_month": bx[0], "x0_px": bx[1], "y_px_per_unit": by[0], "y0_px": by[1],
           "x_tick_px": xt, "y_tick_px": yt,
           "x_resid_px": list(np.array(xt) - np.polyval(bx, xv)),
           "y_resid_px": list(np.array(yt) - np.polyval(by, yv)),
           "axis_row": axis_row, "axis_col": axis_col}
    return res


def pava_decreasing(y):
    # isotonic (nonincreasing) least-squares fit
    y = list(-np.asarray(y, float)); blocks = []
    for v in y:
        blocks.append([v, 1])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            v2, n2 = blocks.pop(); v1, n1 = blocks.pop()
            blocks.append([(v1 * n1 + v2 * n2) / (n1 + n2), n1 + n2])
    out = []
    for v, n in blocks:
        out += [-v] * n
    return np.array(out)


def measure(alpha, cal, arm):
    k = ARMS[arm]; other = 1 - k
    al = alpha[..., k]; ao = alpha[..., other]
    r0, r1 = 150, cal["axis_row"] - 3
    c0 = cal["axis_col"] + 2
    cols_with = [c for c in range(c0, al.shape[1]) if al[r0:r1, c].max() > 0.3]
    c_end = max(cols_with)
    rec = []
    for c in range(c0, c_end + 1):
        prof = al[r0:r1, c]; rows = np.where(prof > 0.15)[0]
        if len(rows) == 0:
            rec.append((c, np.nan, 0.0, 0, False, True)); continue  # fully hidden
        top, bot = rows.min(), rows.max()
        mass = prof.sum(); span = bot - top + 1
        centre = r0 + (np.arange(len(prof)) * prof).sum() / mass
        # the other arm's ink touching/near this arm's ink can hide pixels (either draw order)
        occl = ao[r0 + max(top - 4, 0): r0 + bot + 5, c].max() > 0.3
        # tick ink is symmetric about the line, so the ink-weighted centre is usable in
        # tick columns too; only occluded columns are excluded
        clean = not occl
        rec.append((c, centre, mass, span, clean, occl))
    df = pd.DataFrame(rec, columns=["col", "centre_row", "mass", "span", "clean", "occluded"])
    df["time"] = (df.col - cal["x0_px"]) / cal["x_px_per_month"]
    df["S_raw"] = (df.centre_row - cal["y0_px"]) / cal["y_px_per_unit"]
    cl = df[df.clean].copy()
    cl["S_iso"] = pava_decreasing(cl.S_raw.values)
    # anchor S(0)=1 at the calibrated origin (KM definition); interpolate across unclean columns
    xs = np.r_[cal["x0_px"], cl.col.values]; ys = np.r_[1.0, np.minimum(cl.S_iso.values, 1.0)]
    ys = pava_decreasing(ys)
    df["S"] = np.interp(df.col.values, xs, ys)
    df["row_fit"] = cal["y0_px"] + cal["y_px_per_unit"] * df.S
    # --- censor ticks: ink 3..8 px below the lowest nearby line level and above the highest
    rf = df.row_fit.values; below = np.zeros(len(df)); above = np.zeros(len(df))
    for i, c in enumerate(df.col.values):
        lo = rf[max(i - 1, 0):i + 2].max(); hi = rf[max(i - 1, 0):i + 2].min()
        rr = np.arange(r0, r1)
        # tick arms reach ~7.5 px from the line centre; the 4-px line plus a steep
        # antialiased staircase stays within ~4.5 px, so use the 5..8 px bands
        mb = (rr - lo >= 5) & (rr - lo <= 8); ma = (hi - rr >= 5) & (hi - rr <= 8)
        below[i] = al[r0:r1, c][mb].sum(); above[i] = al[r0:r1, c][ma].sum()
    df["tick_below"] = below; df["tick_above"] = above
    is_t = (below > 1.0) & (above > 1.0)
    # a tick's upper half can be hidden by the other arm: accept below-only evidence when occluded
    is_t |= (below > 1.0) & (above <= 1.0) & df.occluded.values
    df["tick"] = is_t
    return df, c_end


def tick_clusters(df, cal):
    idx = np.where(df.tick.values)[0]
    cl = []
    if len(idx) == 0:
        return pd.DataFrame(columns=["c_first", "c_last", "c_centre", "mass", "width"])
    start = idx[0]; prev = idx[0]
    for i in list(idx[1:]) + [None]:
        if i is not None and i == prev + 1:
            prev = i; continue
        sub = df.iloc[start:prev + 1]
        m = sub.tick_below.sum()
        cl.append((sub.col.iloc[0], sub.col.iloc[-1], (sub.col * sub.tick_below).sum() / m, m, len(sub)))
        if i is not None:
            start = prev = i
    t = pd.DataFrame(cl, columns=["c_first", "c_last", "c_centre", "mass", "width"])
    single = float(np.median(t.mass[t.width <= 4]))
    t["k_min"] = np.maximum(1, np.floor(t.mass / single + 0.5)).astype(int)
    t["time"] = (t.c_centre - cal["x0_px"]) / cal["x_px_per_month"]
    t.attrs["single_mass"] = single
    return t


def lr_alloc(total, weights):
    w = np.asarray(weights, float)
    if total <= 0 or w.sum() == 0:
        return np.zeros(len(w), int)
    q = total * w / w.sum(); n = np.floor(q).astype(int)
    rem = total - n.sum()
    order = np.argsort(-(q - n), kind="stable")
    n[order[:rem]] += 1
    return n


def censor_times(c_i, clus, T0, T1, cal, alloc):
    """Return censoring times in [T0,T1) for c_i censorings."""
    if c_i <= 0:
        return np.array([])
    if len(clus) == 0:
        return T0 + (np.arange(c_i) + 0.5) * (T1 - T0) / c_i
    K = clus.k_min.sum()
    if alloc == "tick" or c_i <= K:
        if c_i >= K:
            m = clus.k_min.values + lr_alloc(c_i - K, clus.k_min.values)
        else:
            m = lr_alloc(c_i, clus.k_min.values)
        extra = np.array([])
    else:  # uniform: visible ticks at k_min, remainder spread evenly over the interval
        m = clus.k_min.values; e = c_i - K
        extra = T0 + (np.arange(e) + 0.5) * (T1 - T0) / e
    out = []
    for (_, r), mj in zip(clus.iterrows(), m):
        if mj == 0:
            continue
        if mj == 1:
            cols = [r.c_centre]
        else:
            cols = np.linspace(r.c_first + 0.5, max(r.c_last - 0.5, r.c_first + 0.5), mj)
        out += list((np.asarray(cols) - cal["x0_px"]) / cal["x_px_per_month"])
    t = np.clip(np.r_[out, extra], T0, np.nextafter(T1, T0))
    return np.sort(t)


def simulate(cols_t, S, Shat0, n0, ctimes):
    d = np.zeros(len(cols_t), int); Shat = Shat0; n_ev = 0
    for j, t in enumerate(cols_t):
        n = n0 - n_ev - np.sum(ctimes < t)
        if n <= 0 or S[j] >= Shat:
            continue
        dj = int(np.clip(np.round(n * (1 - S[j] / Shat)), 0, n))
        d[j] = dj; n_ev += dj; Shat *= (1 - dj / n)
    return d, Shat


def reconstruct_arm(df, clus, rt_times, rt_n, cal, alloc, log):
    t_col = df.time.values; S = df.S.values
    events, cens = [], []; Shat = 1.0
    for i in range(len(rt_times) - 1):
        T0, T1 = rt_times[i], rt_times[i + 1]; n0, n1 = rt_n[i], rt_n[i + 1]
        sel = (t_col >= T0) & (t_col < T1)
        cl = clus[(clus.time >= T0) & (clus.time < T1)]
        best = None
        for c_i in range(0, n0 + 1):
            ct = censor_times(c_i, cl, T0, T1, cal, alloc)
            d, Sh = simulate(t_col[sel], S[sel], Shat, n0, ct)
            n_end = n0 - d.sum() - c_i
            if best is None or abs(n_end - n1) < abs(best[0] - n1):
                best = (n_end, c_i, d, Sh, ct)
            if n_end < n1:
                break
        n_end, c_i, d, Sh, ct = best
        note = ""
        if n_end != n1:
            note = f"could not match table exactly (reconstructed {n_end} vs {n1})"
        log.append({"interval": [T0, T1], "n_start": int(n0), "n_end_table": int(n1),
                    "n_end_recon": int(n_end), "censored": int(c_i), "events": int(d.sum()),
                    "visible_tick_clusters": int(len(cl)), "tick_k_min_sum": int(cl.k_min.sum()),
                    "note": note})
        for tj, dj in zip(t_col[sel], d):
            events += [tj] * int(dj)
        cens += list(ct); Shat = Sh
    return np.array(events), np.array(cens)


def write_atomic(df, path):
    tmp = path + ".tmp"
    df.to_csv(tmp, index=False, float_format="%.4f")
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=os.path.join(HERE, "..", "..", "..", "input"))
    ap.add_argument("--out", default=os.path.join(HERE, ".."))
    ap.add_argument("--alloc", default="tick", choices=["tick", "uniform"])
    ap.add_argument("--csv", default="ipd.csv")
    args = ap.parse_args()
    man = json.load(open(os.path.join(args.input, "manifest.json")))
    np.random.seed(man["code_seed"])  # recorded; algorithm is deterministic
    rt = json.load(open(os.path.join(HERE, "risk_table.json")))
    a = load(os.path.join(args.input, "figure.png"))
    cal = calibrate(a); alpha = unmix(a)
    wdir = os.path.join(args.out, "work"); os.makedirs(wdir, exist_ok=True)
    recs, meta = [], {"calibration": {k: (list(map(float, v)) if isinstance(v, list) else float(v))
                                       for k, v in cal.items()}, "seed": man["code_seed"], "alloc": args.alloc, "arms": {}}
    for arm in ["A", "B"]:
        df, c_end = measure(alpha, cal, arm)
        clus = tick_clusters(df, cal)
        if args.alloc == "tick":
            df.to_csv(os.path.join(wdir, f"curve_{arm}.csv"), index=False, float_format="%.5f")
            clus.to_csv(os.path.join(wdir, f"ticks_{arm}.csv"), index=False, float_format="%.4f")
        log = []
        ev, ce = reconstruct_arm(df, clus, rt["times"], rt[arm], cal, args.alloc, log)
        n = man["groups"][arm]
        assert len(ev) + len(ce) == n, (arm, len(ev), len(ce))
        recs.append(pd.DataFrame({"group": arm, "observed_time": np.r_[ev, ce],
                                  "event": np.r_[np.ones(len(ev), int), np.zeros(len(ce), int)]}))
        meta["arms"][arm] = {"n": n, "events": int(len(ev)), "censored": int(len(ce)),
                             "last_curve_col": int(c_end), "last_curve_time": float(df.time.iloc[-1]),
                             "clean_columns": int(df.clean.sum()), "columns": int(len(df)),
                             "occluded_columns": int(df.occluded.sum()),
                             "tick_clusters": int(len(clus)), "tick_single_mass": clus.attrs["single_mass"],
                             "tick_k_min_total": int(clus.k_min.sum()), "intervals": log}
    out = pd.concat(recs).sort_values(["group", "observed_time", "event"], ascending=[True, True, False])
    out["observed_time"] = out.observed_time.round(4)
    write_atomic(out, os.path.join(args.out, args.csv))
    tag = "" if args.alloc == "tick" else "_" + args.alloc
    json.dump(meta, open(os.path.join(wdir, f"reconstruction_log{tag}.json"), "w"), indent=1, default=float)
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "intervals"} for k, v in meta["arms"].items()}, indent=1, default=float))
    for arm in meta["arms"]:
        for r in meta["arms"][arm]["intervals"]:
            print(arm, r)


if __name__ == "__main__":
    main()
