"""Diagnostic overlay: fitted curve (black) and detected tick clusters (red=A, green=B dots, one per k_min)."""
import sys, os, pandas as pd
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "..")
inp = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "..", "input")
im = Image.open(os.path.join(inp, "figure.png")).convert("RGB"); dr = ImageDraw.Draw(im)
for arm, col in [("A", (255, 0, 0)), ("B", (0, 170, 0))]:
    d = pd.read_csv(os.path.join(OUT, "work", f"curve_{arm}.csv")); t = pd.read_csv(os.path.join(OUT, "work", f"ticks_{arm}.csv"))
    dr.line(list(zip(d.col, d.row_fit)), fill=(0, 0, 0), width=1)
    for _, x in t.iterrows():
        y = float(d.row_fit[d.col == int(round(x.c_centre))].iloc[0])
        for j in range(int(x.k_min)):
            dr.point([(x.c_centre, y + 10 + 2 * j), (x.c_centre + 1, y + 10 + 2 * j)], fill=col)
im.save(os.path.join(OUT, "work", "overlay.png"))
for name, box in [("early", (265, 170, 525, 500)), ("mid", (700, 380, 1100, 700)), ("tail", (1220, 580, 1712, 850))]:
    c = im.crop(box); c.resize((c.width * 3, c.height * 3), Image.NEAREST).save(os.path.join(OUT, "work", f"overlay_{name}.png"))
