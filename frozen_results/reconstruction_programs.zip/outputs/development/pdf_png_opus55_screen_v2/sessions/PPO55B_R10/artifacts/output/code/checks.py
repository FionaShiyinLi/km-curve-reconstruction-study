#!/usr/bin/env python3
"""Reload the committed CSV, recompute right-continuous KM per arm, compare with the
measured curve and the transcribed risk table; optionally compare a sensitivity CSV.
Usage: python3 checks.py [--input ../input]   (run after reconstruct.py)
"""
import argparse, json, os, hashlib
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "..")


def km(t, e):
    """Right-continuous KM step function: returns (event times, S after each)."""
    t = np.asarray(t, float); e = np.asarray(e, int)
    ut = np.unique(t[e == 1]); s = 1.0; S = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); s *= 1 - d / n; S.append(s)
    return ut, np.array(S)


def S_at(ut, S, x):
    i = np.searchsorted(ut, x, side="right") - 1
    return 1.0 if i < 0 else float(S[i])


def rmst(ut, S, tau):
    grid = np.r_[0, ut[ut < tau], tau]; vals = [S_at(ut, S, g) for g in grid[:-1]]
    return float(np.sum(np.diff(grid) * vals))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--input", default=os.path.join(HERE, "..", "..", "..", "input"))
    args = ap.parse_args()
    man = json.load(open(os.path.join(args.input, "manifest.json")))
    rt = json.load(open(os.path.join(HERE, "risk_table.json")))
    path = os.path.join(OUT, "ipd.csv"); raw = open(path, "rb").read()
    ipd = pd.read_csv(path)
    chk = {"csv": "output/ipd.csv", "csv_sha256": hashlib.sha256(raw).hexdigest(),
           "columns_ok": list(ipd.columns) == ["group", "observed_time", "event"],
           "tolerance_rule": ("curve: |KM_recon - measured| <= 0.0027 (2 px of the 750 px/unit axis: line-centre "
                              "measurement plus up-to-half-column time offset on steep segments) + S/n_risk(t) "
                              "(one-event granularity of the reconstructed step function at that time)"),
           "arms": {}}
    times = [0.1, 0.25, 0.5, 1, 1.5, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30,
             31, 32, 32.5, 33, 34, 34.5, 35, 35.5, 35.9]
    for arm in ["A", "B"]:
        g = ipd[ipd.group == arm]; t = g.observed_time.values; e = g.event.values
        ut, S = km(t, e)
        cur = pd.read_csv(os.path.join(OUT, "work", f"curve_{arm}.csv"))
        a = {"n_records": int(len(g)), "n_manifest": man["groups"][arm], "n_ok": int(len(g)) == man["groups"][arm],
             "event_values_ok": bool(set(np.unique(e)) <= {0, 1}), "times_finite_nonneg": bool(np.all(np.isfinite(t)) and np.all(t >= 0)),
             "events": int(e.sum()), "censored": int((e == 0).sum()),
             "supplied_event_total": "unavailable (manifest has no event totals)",
             "max_time": float(t.max()), "curve_last_time": float(cur.time.iloc[-1]), "curve": [], "risk_table": []}
        for x in times:
            near = cur[(abs(cur.time - x) <= 2.5 / 40) & cur.clean]
            if len(near) == 0:
                a["curve"].append({"t": x, "status": "unavailable (occluded columns)"}); continue
            meas = float(near.S_raw.median()); rec = S_at(ut, S, x)
            n = max(int(np.sum(t >= x)), 1); tol = 0.0027 + rec / n
            a["curve"].append({"t": x, "measured": round(meas, 4), "recon": round(rec, 4), "resid": round(rec - meas, 4),
                               "tol": round(tol, 4), "status": "pass" if abs(rec - meas) <= tol else "fail"})
        for T, n_tab in zip(rt["times"], rt[arm]):
            n_rec = int(np.sum(t >= T))
            a["risk_table"].append({"t": T, "table": n_tab, "recon": n_rec, "resid": n_rec - n_tab,
                                    "status": "pass" if n_rec == n_tab else "fail",
                                    "reading": "transcribed by eye; digits unambiguous at native resolution"})
        a["curve_fail"] = sum(c.get("status") == "fail" for c in a["curve"])
        a["risk_fail"] = sum(c["status"] == "fail" for c in a["risk_table"])
        chk["arms"][arm] = a
    sp = os.path.join(OUT, "sensitivity.csv")
    if os.path.exists(sp):
        sen = pd.read_csv(sp)
        tau = float(min(d[d.group == g].observed_time.max() for d in (ipd, sen) for g in "AB"))
        tau = float(np.floor(tau * 10) / 10)
        sc = {"assumption": "censorings beyond the visible-tick lower bound spread uniformly over each risk interval "
                            "(primary: added to visible tick clusters in proportion to their lower-bound multiplicity)",
              "common_horizon_months": tau, "sha256": hashlib.sha256(open(sp, "rb").read()).hexdigest(), "arms": {}}
        for g in "AB":
            r = {}
            for lab, d in (("primary", ipd), ("sensitivity", sen)):
                x = d[d.group == g]; ut, S = km(x.observed_time, x.event)
                r[lab] = {"events": int(x.event.sum()), "RMST_tau": round(rmst(ut, S, tau), 4),
                          "S": {str(h): round(S_at(ut, S, h), 4) for h in (6, 12, 18, 24, 30, tau)}}
            r["RMST_diff"] = round(r["sensitivity"]["RMST_tau"] - r["primary"]["RMST_tau"], 4)
            sc["arms"][g] = r
        chk["sensitivity"] = sc
    else:
        chk["sensitivity"] = "not run"
    json.dump(chk, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
    for g, a in chk["arms"].items():
        print(g, {k: a[k] for k in ("n_ok", "events", "censored", "max_time", "curve_fail", "risk_fail")})
        for c in a["curve"]:
            if c.get("status") != "pass":
                print("  ", c)
    print(json.dumps(chk["sensitivity"], indent=1) if isinstance(chk["sensitivity"], dict) else chk["sensitivity"])


if __name__ == "__main__":
    main()
