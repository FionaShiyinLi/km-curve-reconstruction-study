"""Reload the committed CSV, recompute right-continuous KM per arm and compare with the
measured curve, the risk table and the arm sizes. Writes <outdir>/checks.json.

Usage: python3 check.py [workdir] [outdir]
"""
import csv
import hashlib
import json
import sys

WORK = sys.argv[1] if len(sys.argv) > 1 else "output/work"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
N = {"A": 100, "B": 100}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {"A": [100, 68, 48, 29, 18, 7, 0], "B": [100, 69, 59, 47, 39, 11, 0]}
# measurement tolerance for survival: level centre +-1 px (0.0013) plus 4-vs-5 px line
# rounding (0.0007) and a 2x margin -> 0.004; one event at n=100 is 0.01 (7.5 px)
TOL_S = 0.004
DROP_GUARD = 0.1     # months: skip check points within 4 px of a measured drop


def load(path):
    recs = {"A": [], "B": []}
    with open(path) as f:
        for r in csv.DictReader(f):
            recs[r["group"]].append((float(r["observed_time"]), int(r["event"])))
    return recs


def km(rec):
    """Right-continuous KM: list of (t, S(t)) at event times."""
    times = sorted({t for t, e in rec if e == 1})
    S, out = 1.0, []
    for t in times:
        n = sum(1 for u, _ in rec if u >= t)
        d = sum(1 for u, e in rec if u == t and e == 1)
        S *= 1 - d / n
        out.append((t, S))
    return out


def S_at(curve, t):
    s = 1.0
    for u, v in curve:
        if u <= t:
            s = v
        else:
            break
    return s


def rmst(curve, tau):
    area, last_t, last_s = 0.0, 0.0, 1.0
    for u, v in curve:
        if u >= tau:
            break
        area += last_s * (u - last_t)
        last_t, last_s = u, v
    return area + last_s * (tau - last_t)


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main():
    path = f"{OUT}/ipd.csv"
    recs = load(path)
    res = {"csv": "output/ipd.csv", "sha256": sha(path), "arms": {}}
    allpass = True
    for arm in "AB":
        st = json.load(open(f"{WORK}/steps_{arm}.json"))
        rec = recs[arm]
        cur = km(rec)
        drop_t = [d["t"] for d in st["drops"]]
        a = {"n_records": len(rec), "n_expected": N[arm],
             "n_pass": len(rec) == N[arm],
             "event_indicator_integer_0_1": all(e in (0, 1) for _, e in rec),
             "times_finite_nonneg": all(0 <= t < float("inf") for t, _ in rec),
             "events": sum(e for _, e in rec), "censored": sum(1 - e for _, e in rec),
             "supplied_event_total": "unavailable (not in manifest)",
             "max_time": max(t for t, _ in rec), "curve_drawn_to": st["t_last"]}
        # curve comparisons at the midpoint of every measured level with >=3 clean columns
        pts = []
        for L in st["levels"]:
            if L["n_clean_cols"] < 3:
                continue
            t = (L["t0"] + L["t1"]) / 2
            if any(abs(t - u) < DROP_GUARD for u in drop_t):
                continue
            pts.append((t, L["S"], "level-mid"))
        # tail checks: last 3 levels at their right end (just before the next drop / end)
        for L in st["levels"][-3:]:
            t = L["t1"] - 0.05
            pts.append((t, L["S"], "tail"))
        comp = []
        for t, s_meas, kind in pts:
            s_rec = S_at(cur, t)
            r = s_rec - s_meas
            ok = abs(r) <= TOL_S
            allpass &= ok
            comp.append({"t": round(t, 3), "kind": kind, "S_measured": round(s_meas, 4),
                         "S_reconstructed": round(s_rec, 4), "residual": round(r, 4),
                         "status": "pass" if ok else "fail"})
        a["curve_checks"] = comp
        a["curve_max_abs_residual"] = max(abs(c["residual"]) for c in comp)
        a["curve_fail_count"] = sum(c["status"] == "fail" for c in comp)
        rk = []
        for t, n_tab in zip(RISK_T, RISK[arm]):
            n_rec = sum(1 for u, _ in rec if u >= t)
            ok = n_rec == n_tab
            allpass &= ok
            rk.append({"t": t, "n_risk_table": n_tab, "n_reconstructed": n_rec,
                       "residual": n_rec - n_tab, "status": "pass" if ok else "fail"})
        a["risk_table_checks"] = rk
        allpass &= a["n_pass"] and a["event_indicator_integer_0_1"] and a["times_finite_nonneg"]
        res["arms"][arm] = a
    res["tolerance"] = {"S_abs": TOL_S, "risk_counts": "exact (observed_time >= t)",
                        "justification": "level centre +-1 px (0.0013) + line-thickness rounding "
                        "(0.0007), doubled; points within 0.1 month of a measured drop skipped"}
    res["all_required_checks_pass"] = bool(allpass)
    # optional sensitivity comparison
    try:
        sens = load(f"{OUT}/sensitivity.csv")
        tau = min(json.load(open(f"{WORK}/steps_{a}.json"))["t_last"] for a in "AB")
        sc = {"sha256": sha(f"{OUT}/sensitivity.csv"), "horizon_months": round(tau, 3), "arms": {}}
        for arm in "AB":
            p, s = km(recs[arm]), km(sens[arm])
            row = {}
            for t in (6, 12, 18, 24, 30, round(tau, 3)):
                row[f"S({t})"] = {"primary": round(S_at(p, t), 4), "sensitivity": round(S_at(s, t), 4)}
            row["RMST(0-horizon)"] = {"primary": round(rmst(p, tau), 3), "sensitivity": round(rmst(s, tau), 3)}
            row["risk_counts_sensitivity"] = [sum(1 for u, _ in sens[arm] if u >= t) for t in RISK_T]
            sc["arms"][arm] = row
        res["sensitivity_comparison"] = sc
    except FileNotFoundError:
        res["sensitivity_comparison"] = "not run"
    json.dump(res, open(f"{OUT}/checks.json", "w"), indent=1)
    for arm in "AB":
        a = res["arms"][arm]
        print(arm, "n", a["n_records"], "events", a["events"], "maxres", a["curve_max_abs_residual"],
              "fails", a["curve_fail_count"], "/", len(a["curve_checks"]),
              "risk", [x["n_reconstructed"] for x in a["risk_table_checks"]])
        for c in a["curve_checks"]:
            if c["status"] == "fail":
                print("   FAIL", c)
    print("all pass:", res["all_required_checks_pass"], "sha", res["sha256"][:12])
    if isinstance(res["sensitivity_comparison"], dict):
        print(json.dumps(res["sensitivity_comparison"]["arms"], indent=0)[:1500])


if __name__ == "__main__":
    main()
