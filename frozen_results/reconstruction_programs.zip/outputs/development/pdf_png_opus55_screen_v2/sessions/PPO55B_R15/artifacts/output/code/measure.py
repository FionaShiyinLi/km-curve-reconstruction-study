"""Pixel measurement of the two KM curves in figure.png.

Usage: python3 measure.py [path/to/figure.png] [outdir]
Writes <outdir>/measure_<arm>.json with step segments, drops and censor-tick groups.
Measurement only; no correction or reconstruction happens here.
"""
import json
import sys
import numpy as np
from PIL import Image

FIG = sys.argv[1] if len(sys.argv) > 1 else "../input/figure.png"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output/work"

COLORS = {"A": (31, 119, 180), "B": (255, 127, 14)}
# Axis calibration from labelled tick marks (2-px wide ticks; centre = mean of pixel indices)
# x ticks at columns 269/270 (0), 509/510 (6), ..., 1709/1710 (36) -> 40 px per month
# y ticks at rows 179/180 (1.0), 329/330 (0.8), ..., 929/930 (0.0) -> 750 px per unit
X0, XPM = 269.5, 40.0
Y0, YPU = 929.5, 750.0
ROW_LO, ROW_HI = 150, 928          # plot rows (exclude legend and x axis)
COL_LO, COL_HI = 271, 1712         # exclude y-axis columns
LW = 4                             # line thickness in px (measured)


def t_of(x):
    return (x - X0) / XPM


def s_of(y):
    return (Y0 - y) / YPU


def runs(v):
    ys = np.where(v)[0]
    if len(ys) == 0:
        return []
    out, s, p = [], ys[0], ys[0]
    for y in ys[1:]:
        if y != p + 1:
            out.append((int(s), int(p)))
            s = y
        p = y
    out.append((int(s), int(p)))
    return out


def main():
    a = np.array(Image.open(FIG).convert("RGB")).astype(int)
    masks = {k: (np.abs(a - np.array(c)).sum(2) < 60) for k, c in COLORS.items()}
    import os
    os.makedirs(OUT, exist_ok=True)
    for arm, col in COLORS.items():
        m = masks[arm]
        other = masks["B" if arm == "A" else "A"]
        percol = {}
        for c in range(COL_LO, COL_HI):
            rr = [(s + ROW_LO, e + ROW_LO) for s, e in runs(m[ROW_LO:ROW_HI, c])]
            if not rr:
                continue
            # occlusion flags: other colour directly adjacent above/below
            info = []
            for s, e in rr:
                occ_top = bool(other[s - 1, c]) if s - 1 >= 0 else False
                occ_bot = bool(other[e + 1, c])
                info.append({"s": s, "e": e, "occ_top": occ_top, "occ_bot": occ_bot})
            percol[c] = info
        # clean columns: single run whose visible length is consistent with a horizontal line
        clean = {}
        for c, info in percol.items():
            if len(info) != 1:
                continue
            r = info[0]
            L = r["e"] - r["s"] + 1
            if L == LW:
                clean[c] = (r["s"] + r["e"]) / 2
            elif L < LW and (r["occ_top"] or r["occ_bot"]):
                clean[c] = (r["s"] + 1.5) if r["occ_bot"] else (r["e"] - 1.5)
        # bottom envelope in every column (level after any drop that starts in the column)
        cols = sorted(percol)
        json.dump({"arm": arm, "calib": {"X0": X0, "XPM": XPM, "Y0": Y0, "YPU": YPU},
                   "percol": {str(c): percol[c] for c in cols},
                   "clean": {str(c): v for c, v in clean.items()}},
                  open(f"{OUT}/raw_{arm}.json", "w"))
        print(arm, "columns with pixels", len(cols), "first", cols[0], "last", cols[-1],
              "clean", len(clean))


if __name__ == "__main__":
    main()
