"""Reconstruct participant records from the measured step function (extract.py output)
and the number-at-risk table printed under the figure.

Usage: python3 reconstruct.py [workdir] [outdir] [--mode uniform|ticks]
  uniform (primary): censorings not accounted for by visible ticks are spread evenly
                     over the risk-table interval (clipped to the drawn curve extent)
  ticks (sensitivity): they are added as tied censorings at the visible tick positions
                     of that interval (tick multiplicity); uniform if the interval has none
Writes <outdir>/ipd.csv (or sensitivity.csv for --mode ticks) via temp file + atomic rename.
"""
import json
import os
import random
import sys

SEED = 1392395424          # manifest code_seed; the algorithm is deterministic, seed recorded
random.seed(SEED)

args = [a for a in sys.argv[1:] if not a.startswith("--")]
WORK = args[0] if len(args) > 0 else "output/work"
OUT = args[1] if len(args) > 1 else "output"
MODE = "ticks" if "--mode" in sys.argv and sys.argv[sys.argv.index("--mode") + 1] == "ticks" else "uniform"

N = {"A": 100, "B": 100}                        # manifest group sizes
RISK_T = [0, 6, 12, 18, 24, 30, 36]            # read from the figure's risk table
RISK = {"A": [100, 68, 48, 29, 18, 7, 0],
        "B": [100, 69, 59, 47, 39, 11, 0]}


def simulate(n0, drops, cens, S0):
    """Run KM forward through time-ordered drops (target levels) and censorings.
    Returns records, n at end, KM at end. Events precede censorings at tied times."""
    items = [(d["t"], 0, d["S_after"]) for d in drops] + [(t, 1, None) for t in cens]
    items.sort(key=lambda x: (x[0], x[1]))
    n, S, recs = n0, S0, []
    for t, kind, tgt in items:
        if kind == 0:
            if n <= 0:
                continue
            d = round(n * (1 - tgt / S)) if S > 0 else 0
            d = max(0, min(n, d))
            for _ in range(d):
                recs.append((t, 1))
            if d:
                S *= (1 - d / n)
            n -= d
        else:
            if n <= 0:
                continue
            recs.append((t, 0))
            n -= 1
    return recs, n, S


def extra_times(k, a, b, tick_times):
    if k <= 0:
        return []
    if MODE == "ticks" and tick_times:
        # round-robin over visible tick positions (tied censorings)
        return [tick_times[i % len(tick_times)] for i in range(k)]
    w = (b - a) / k
    return [a + (i + 0.5) * w for i in range(k)]


def reconstruct(arm):
    st = json.load(open(f"{WORK}/steps_{arm}.json"))
    drops = st["drops"]
    t_end = st["t_last"]
    ticks = []           # expanded visible censorings: (t, removable-priority)
    for g in st["ticks"]:
        for j in range(g["n_visible"]):
            ticks.append((g["t"], j))       # j>0 = inferred from overlap width (less certain)
    n, S = N[arm], 1.0
    recs, log = [], []
    for j in range(len(RISK_T) - 1):
        a, b = RISK_T[j], RISK_T[j + 1]
        dj = [d for d in drops if a <= d["t"] < b]
        tj = sorted([t for t in ticks if a <= t[0] < b], key=lambda x: (-x[1], x[0]))
        target = RISK[arm][j + 1]
        vis = [t for t, _ in tj]
        best = None
        # k>0: add k censorings; k<0: drop |k| visible censorings (overlap-inferred first)
        for k in range(-len(vis), n + 1):
            if k < 0:
                cens = [t for t, _ in tj[-k:]]
            else:
                cens = vis + extra_times(k, a, min(b, t_end), sorted(set(vis)))
            r, n_end, S_end = simulate(n, dj, cens, S)
            score = abs(n_end - target)
            if best is None or score < best[0] or (score == best[0] and abs(k) < abs(best[1])):
                best = (score, k, r, n_end, S_end)
            if score == 0 and k >= 0:
                break
        score, k, r, n_end, S_end = best
        ev = sum(e for _, e in r)
        log.append({"interval": [a, b], "n_start": n, "visible_censor": len(vis), "extra_censor": k,
                    "events": ev, "censored": len(r) - ev, "n_end": n_end, "risk_table_end": target,
                    "matched": score == 0})
        recs += r
        n, S = n_end, S_end
    # anyone remaining (only if the last interval could not be matched): censor at curve end
    for _ in range(n):
        recs.append((t_end, 0))
    if n:
        log.append({"note": f"{n} participants left after last interval; censored at curve end {t_end:.3f}"})
    assert len(recs) == N[arm], (arm, len(recs))
    return recs, log


def main():
    rows, logs = [], {}
    for arm in "AB":
        r, lg = reconstruct(arm)
        logs[arm] = lg
        rows += [(arm, t, e) for t, e in sorted(r)]
        for x in lg:
            print(arm, x)
    os.makedirs(OUT, exist_ok=True)
    name = "ipd.csv" if MODE == "uniform" else "sensitivity.csv"
    tmp = f"{OUT}/.{name}.tmp"
    with open(tmp, "w") as f:
        f.write("group,observed_time,event\n")
        for g, t, e in rows:
            f.write(f"{g},{t:.4f},{e}\n")
    os.replace(tmp, f"{OUT}/{name}")
    json.dump({"mode": MODE, "seed": SEED, "intervals": logs},
              open(f"{WORK}/reconstruct_log_{MODE}.json", "w"), indent=1)
    print("wrote", f"{OUT}/{name}")


if __name__ == "__main__":
    main()
