"""Convert per-column pixel runs (from measure.py) into a measured step function:
levels, drop locations and censor-tick locations. Measurement only (no KM correction).

Envelope method. In every column the true step line occupies rows [top(c), bot(c)], where
bot(c) is the bottom of the level reached so far (a drop's vertical reaches the new level's
bottom in its first column) and top(c) is the top of the level before any drop in progress.
Both are non-decreasing in c (survival non-increasing). Censor ticks (16-17 px tall, 3 px
wide, centred on the line) show up as short-lived bumps: bot above the future minimum, or
top above the past maximum. Bumps are removed with a forward min / backward max filter.

Usage: python3 extract.py [workdir]    (reads raw_<arm>.json, writes steps_<arm>.json)
"""
import json
import math
import sys

WORK = sys.argv[1] if len(sys.argv) > 1 else "output/work"
WIN = 9          # filter window (px); exceeds the widest overlapping tick group seen (7 px)
TICK_HALF = 8    # tick extends ~8 px either side of the line centre (16-17 px total)


def extract(arm):
    d = json.load(open(f"{WORK}/raw_{arm}.json"))
    cal = d["calib"]
    pc = {int(k): v for k, v in d["percol"].items()}
    c_first, c_last = min(pc), max(pc)
    cols = list(range(c_first, c_last + 1))
    top, bot = {}, {}
    for c in cols:
        rr = pc.get(c)
        if not rr:
            top[c] = bot[c] = None          # fully hidden (axis or other arm)
            continue
        t = min(r["s"] for r in rr)
        b = max(r["e"] for r in rr)
        rb = max(rr, key=lambda r: r["e"])
        rt = min(rr, key=lambda r: r["s"])
        # a boundary touching the other arm's colour is not observed
        # (lower/upper bound assuming the 4-px line's other edge is visible)
        bot[c] = max(b, rb["s"] + 3) if rb["occ_bot"] else b
        top[c] = min(t, rt["e"] - 3) if rt["occ_top"] else t
    # the final column group is a censor tick if the last run is 14+ px tall; the line
    # there is at the level of the preceding clean columns: pad with that level
    fwd = [bot[c] for c in cols] + [None] * WIN
    Lb = {}
    for i, c in enumerate(cols):
        vals = [v for v in fwd[i:i + WIN] if v is not None]
        Lb[c] = min(vals) if vals else None
    # end-of-curve tick: future window truncated -> use last level before the tick
    tail = [c for c in cols if c > c_last - WIN]
    ref = [bot[c] for c in cols if c_last - 2 * WIN < c <= c_last - WIN and bot[c] is not None]
    if ref:
        for c in tail:
            if Lb[c] is not None and Lb[c] > min(ref) + 3 and top[c] is not None and \
               top[c] < min(ref) - 6:
                Lb[c] = min(ref)
    Ut = {}
    for i, c in enumerate(cols):
        vals = [top[cols[j]] for j in range(max(0, i - WIN + 1), i + 1) if top[cols[j]] is not None]
        Ut[c] = max(vals) if vals else None
    # enforce monotonicity of the filtered envelopes (fill hidden columns forward)
    last = None
    for c in cols:
        if Lb[c] is None or (last is not None and Lb[c] < last):
            Lb[c] = last
        last = Lb[c]

    # ---- ticks
    tickcols = []
    for c in cols:
        if bot[c] is not None and Lb[c] is not None and bot[c] > Lb[c] + 3:
            tickcols.append((c, bot[c] - TICK_HALF, "bottom"))
        elif top[c] is not None and Ut[c] is not None and top[c] < Ut[c] - 3:
            tickcols.append((c, top[c] + TICK_HALF, "top"))
    groups = []
    for c, y, how in tickcols:
        if groups and c - groups[-1]["c1"] <= 1 and abs(groups[-1]["y"] - y) <= 3:
            g = groups[-1]
            g["c1"] = c
            g["ys"].append(y)
        else:
            groups.append({"c0": c, "c1": c, "y": y, "ys": [y], "how": how})
    for g in groups:
        g["width"] = g["c1"] - g["c0"] + 1
        g["y"] = sorted(g["ys"])[len(g["ys"]) // 2]
        # single tick = 3 px wide; width>=4 implies >=2 overlapping positions
        # (minimum number of 3-4 px wide ticks able to cover the contiguous width)
        w = g["width"]
        g["n_visible"] = 1 if w <= 3 else (2 if w <= 6 else math.ceil(w / 3.5))
        g["x"] = (g["c0"] + g["c1"]) / 2

    # ---- levels: runs of constant Lb; level centre refined from clean 4/5-px columns
    levels = []   # dict(c0, c1, lb)
    for c in cols:
        if Lb[c] is None:
            continue
        if levels and Lb[c] - levels[-1]["lb"] <= 1:
            levels[-1]["c1"] = c
        else:
            levels.append({"c0": c, "c1": c, "lb": Lb[c]})
    for L in levels:
        cent = []
        for c in range(L["c0"], L["c1"] + 1):
            rr = pc.get(c)
            if rr and len(rr) == 1 and 4 <= rr[0]["e"] - rr[0]["s"] + 1 <= 5 \
               and not rr[0]["occ_top"] and not rr[0]["occ_bot"] and abs(rr[0]["e"] - L["lb"]) <= 1:
                cent.append((rr[0]["s"] + rr[0]["e"]) / 2)
        L["n_clean"] = len(cent)
        L["y"] = sum(cent) / len(cent) if cent else L["lb"] - 1.5
    # curve starts at S=1 (axis anchor); a level visible from the first column but below
    # 1.0 means drops hidden under the y axis / first columns
    y_start = cal["Y0"] - cal["YPU"] * 1.0
    drops = []
    prev_y = y_start
    for L in levels:
        if L["y"] > prev_y + 2:
            drops.append({"x": L["c0"] + 1.5, "y_before": prev_y, "y_after": L["y"],
                          "hidden_start": L["c0"] == c_first})
        prev_y = L["y"]

    def T(x):
        return (x - cal["X0"]) / cal["XPM"]

    def S(y):
        return (cal["Y0"] - y) / cal["YPU"]

    out = {
        "arm": arm,
        "levels": [{"t0": T(L["c0"]), "t1": T(L["c1"]), "S": S(L["y"]), "y": L["y"],
                    "n_clean_cols": L["n_clean"]} for L in levels],
        "drops": [{"t": max(0.0, T(dd["x"])), "S_before": S(dd["y_before"]), "S_after": S(dd["y_after"]),
                   "px": dd["x"], "y_before": dd["y_before"], "y_after": dd["y_after"],
                   "hidden_start": dd["hidden_start"]} for dd in drops],
        "ticks": [{"t": T(g["x"]), "S": S(g["y"]), "width_px": g["width"], "n_visible": g["n_visible"],
                   "c0": g["c0"], "c1": g["c1"], "detected_by": g["how"]} for g in groups],
        "first_col": c_first, "last_col": c_last, "t_last": T(c_last + 0.5),
    }
    json.dump(out, open(f"{WORK}/steps_{arm}.json", "w"), indent=1)
    return out


if __name__ == "__main__":
    for arm in "AB":
        o = extract(arm)
        print(f"== {arm}: {len(o['levels'])} levels, {len(o['drops'])} drops, "
              f"{len(o['ticks'])} tick groups, curve ends t={o['t_last']:.3f}")
        print(" drops:", " ".join(f"{x['t']:.3f}:{x['S_before']:.4f}>{x['S_after']:.4f}" for x in o["drops"]))
        print(" ticks:", " ".join(f"{g['t']:.2f}@{g['S']:.3f}w{g['width_px']}{g['detected_by'][0]}" for g in o["ticks"]))
