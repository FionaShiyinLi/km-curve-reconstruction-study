import json
E = json.load(open('output/work/extracted.json'))
for g, a in E['arms'].items():
    p = a['curve_pts']; ticks = a['censor_ticks']
    drops = [(p[i][0], p[i][1], p[i+1][1]) for i in range(len(p)-1) if abs(p[i][0]-p[i+1][0]) < 1e-9 and p[i+1][1] < p[i][1]]
    print(g, 'drops', len(drops), 'ticks', len(ticks), 'end', p[-1])
    n = 100; ti = 0; tot = 0
    for t, s0, s1 in drops:
        c = 0
        while ti < len(ticks) and ticks[ti] < t - 1e-6: ti += 1; c += 1
        n -= c
        df = n*(1 - s1/s0)
        # implied n for d=1..3
        imp = [round(d/(1-s1/s0), 2) for d in (1, 2, 3)]
        print(f'{t:7.3f} n={n:3d} cens_before={c} d_float={df:6.3f} implied_n={imp}')
        d = round(df); n -= d; tot += d
    print(g, 'events', tot, 'ticks after last drop', len(ticks)-ti, 'remaining n', n, [round(x,3) for x in ticks[ti:]])
