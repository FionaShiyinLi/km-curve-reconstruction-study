"""Reload committed ipd.csv, recompute right-continuous KM, compare with measured curve and risk table."""
import sys, json, hashlib, csv
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
E = json.load(open(f'{out}/work/extracted.json')); M = json.load(open(sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'))
raw = open(f'{out}/ipd.csv', 'rb').read(); sha = hashlib.sha256(raw).hexdigest()
rows = list(csv.DictReader(open(f'{out}/ipd.csv')))
TOL_S = 0.001  # vector coords are given to 0.01 pt = 5.6e-5 survival; also csv time rounding 1e-4 mo
def km(recs, t):
    s = 1.0
    for u in sorted({r[0] for r in recs if r[1] == 1 and r[0] <= t}):
        n = sum(1 for r in recs if r[0] >= u); d = sum(1 for r in recs if r[0] == u and r[1] == 1)
        s *= 1 - d/n
    return s
def measured(pts, t):   # right-continuous step read from the vector path
    s = pts[0][1]
    for x, y in pts:
        if x <= t + 1e-9: s = y
    return s
C = dict(csv_sha256=sha, n_rows=len(rows), survival_tolerance=TOL_S,
         tolerance_note='vector path coordinates quantised at 0.01 pt (5.6e-5 survival, 1e-3 month); CSV times rounded to 1e-4 month', arms={})
for g in sorted(M['groups']):
    R = [(float(r['observed_time']), int(r['event'])) for r in rows if r['group'] == g]
    pts = E['arms'][g]['curve_pts']; end = pts[-1][0]
    drop_t = [pts[i][0] for i in range(len(pts)-1) if abs(pts[i][0]-pts[i+1][0]) < 1e-9]
    times = sorted(set([0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, round(end - 0.01, 3), round(end, 3)]
                       + [round(t + 0.005, 3) for t in drop_t[-3:]]))  # tail, just after last drops
    kmc = []
    for t in times:
        m = measured(pts, t); r = km(R, t)
        kmc.append(dict(t=t, measured=round(m, 5), reconstructed=round(r, 5), residual=round(r - m, 5),
                        status='pass' if abs(r - m) <= TOL_S else 'fail'))
    # max over all drop points (just after each step)
    allres = max(abs(km(R, t + 1e-4) - measured(pts, t + 1e-4)) for t in drop_t)
    rt = E['risk_table']; risk = []
    for t, obs in zip(rt['times'], rt[g]):
        rec = sum(1 for x in R if x[0] >= t)
        risk.append(dict(t=t, displayed=obs, reconstructed=rec, residual=rec - obs,
                         status='pass' if rec == obs else 'fail'))
    ev = sum(e for _, e in R)
    C['arms'][g] = dict(n=len(R), n_expected=M['groups'][g], n_status='pass' if len(R) == M['groups'][g] else 'fail',
        events=ev, censored=len(R) - ev, event_indicator_integer_01=all(e in (0, 1) for _, e in R),
        supplied_event_total='unavailable (not in manifest)', max_time=max(x[0] for x in R),
        curve_end=end, km_checks=kmc, max_abs_residual_all_steps=allres,
        censor_ticks=len(E['arms'][g]['censor_ticks']), censored_records=len(R) - ev,
        risk_table=risk)
json.dump(C, open(f'{out}/checks.json', 'w'), indent=1)
for g, a in C['arms'].items():
    print(g, a['n'], a['events'], 'maxres', a['max_abs_residual_all_steps'],
          [k['status'] for k in a['km_checks']].count('fail'), 'km fails;',
          [(r['t'], r['displayed'], r['reconstructed']) for r in a['risk_table']])
print(sha)
