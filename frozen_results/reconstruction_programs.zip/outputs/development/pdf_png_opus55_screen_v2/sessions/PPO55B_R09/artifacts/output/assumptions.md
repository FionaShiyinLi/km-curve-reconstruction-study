# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`, a single-page vector PDF with no embedded images. It contains one step path per arm, one short vertical line per censor mark, black axis ticks, and a text risk table.
- `../input/manifest.json`: A = 100, B = 100, time unit months, code seed 173340985. The manifest has no arm-specific event totals, so that check is marked unavailable.
- Arms were matched to colours by the legend (the coloured line immediately left of each "Group X" label): blue = A, orange = B.

## Calibration
Time and survival were fitted linearly to the labelled axis tick marks (7 x ticks at 0–36 months, 6 y ticks at 0–1.0); the maximum anchor residual is about 1e-15. The same transform is used everywhere, with no global rescaling and no running-minimum correction. Both paths start exactly at (0, 1.0), and the first drops at 0.200 months (A) and 0.075 months (B) are kept. Coordinates are quantised at 0.01 pt, which is 1e-3 months and 5.6e-5 in survival.

## Algorithm (`output/code/reconstruct.py`, which calls `extract.py`)
1. Read the vertical segments of each path as event drops (S_before to S_after at time t), and the censor-mark x positions as censoring times.
2. Go through the drops in time order. Before each drop, remove censorings with time < t from the risk set; a censoring tied with an event would stay at risk. Then set d = round(n_risk·(1 − S_after/S_before)).
3. The procedure stops if any d is non-integer by more than 0.05, or if the number of participants left after the last drop differs from the number of later censor marks.

The algorithm uses no randomness, so the seed is recorded but not used.

## Why d = 1 and one participant per mark are supported (not assumed)
- With n_risk taken from the preceding marks, n·(1 − ratio) differs from 1 by at most 3.7e-5 at every drop (74 drops in A, 63 in B).
- Setting d = 2 or 3 at any drop would require a risk set 2 or 3 times as large, which is incompatible with N = 100 and the preceding steps.
- Events plus marks sum exactly to 100 in each arm (A: 74 + 26; B: 63 + 37).
- Near-coincident marks (for example A at about 30.88/30.886 months, B at about 25.3 months) are separate vector objects. Counting each as one participant is what makes later drop ratios consistent, so the evidence supports this reading of multiplicity.
- Every mark lies on its own arm's curve level.

## Censoring and follow-up
Censoring times are the mark positions; nothing is imputed beyond them. The last record in each arm is a censoring at the curve end (A 35.214, B 35.857 months). The displayed "0 at risk" at 36 months is therefore met by records that end before 36 months, not by records placed at 36.

## Risk table
All 14 displayed counts (0, 6, …, 36 months) are reproduced exactly by counting records with observed_time ≥ t. These counts were a check only; they were not used as inputs.

## Verification (`output/code/checks.py` produces `output/checks.json`)
- The committed CSV was reloaded and a right-continuous KM curve recomputed for each arm, then compared with the vector step curve at 0, 0.5, 1, 3, 6, …, 33 months, just after the last three drops, and at the curve end. The maximum residual across all steps is about 3e-7; the tolerance is 0.001.
- Arm sizes, 0/1 event indicators and the SHA-256 of the CSV are recorded.

## Limitations
- Times are accurate to the plot resolution (about 0.001 months). Events or censorings that are exactly tied in the source cannot be told apart from near-ties.
- A censoring hidden exactly under a drop at the same x position would be counted as at risk at that drop. No such case appears, because all ratios are exact integers under the tick-based risk sets.
- Standard caveat: this assumes the figure displays every censoring as a mark. The integer consistency above supports that assumption strongly but cannot prove it.

## Sensitivity analysis
None was run. The drop ratios, mark counts, N and the risk table together leave no materially different feasible allocation of events and censorings, so no `sensitivity.csv` was produced.
