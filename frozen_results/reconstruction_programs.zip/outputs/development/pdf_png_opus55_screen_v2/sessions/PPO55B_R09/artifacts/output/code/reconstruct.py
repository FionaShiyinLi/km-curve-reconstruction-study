"""Reconstruct IPD from vector KM figure. Deterministic (no randomness; seed recorded only).
Usage (from work dir): python output/code/reconstruct.py [../input/figure.pdf] [../input/manifest.json] [output]"""
import sys, os, json, hashlib, subprocess, bisect
here = os.path.dirname(os.path.abspath(__file__))
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
man = sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'
out = sys.argv[3] if len(sys.argv) > 3 else 'output'
os.makedirs(f'{out}/work', exist_ok=True)
M = json.load(open(man)); SEED = M['code_seed']   # recorded; algorithm is deterministic
ext = f'{out}/work/extracted.json'
subprocess.run([sys.executable, f'{here}/extract.py', pdf, ext], check=True)
E = json.load(open(ext))
EPS = 1e-6
recs, alloc = [], {}
for g in sorted(M['groups']):
    N = M['groups'][g]; a = E['arms'][g]; p = a['curve_pts']; ticks = a['censor_ticks']
    drops = [(p[i][0], p[i][1], p[i+1][1]) for i in range(len(p)-1)
             if abs(p[i][0]-p[i+1][0]) < 1e-9 and p[i+1][1] < p[i][1]]
    n, ti, log = N, 0, []
    for t, s0, s1 in drops:
        while ti < len(ticks) and ticks[ti] < t - EPS:      # censored strictly before t leave risk set
            recs.append((g, ticks[ti], 0)); ti += 1; n -= 1
        dfl = n * (1 - s1/s0); d = round(dfl)
        log.append(dict(t=t, n_risk=n, d_float=dfl, d=d))
        if d < 1 or abs(dfl - d) > 0.05: raise SystemExit(f'{g}: non-integer drop at {t}: {dfl}')
        recs += [(g, t, 1)] * d; n -= d
    rest = ticks[ti:]
    if len(rest) != n: raise SystemExit(f'{g}: {n} remaining but {len(rest)} ticks after last drop')
    recs += [(g, t, 0) for t in rest]
    alloc[g] = dict(n_drops=len(drops), events=sum(x['d'] for x in log), ticks=len(ticks),
                    max_abs_d_residual=max(abs(x['d_float']-x['d']) for x in log), drop_log=log)
json.dump(alloc, open(f'{out}/work/allocation.json', 'w'), indent=1)
tmp = f'{out}/ipd.csv.tmp'
with open(tmp, 'w') as f:
    f.write('group,observed_time,event\n')
    for g, t, e in sorted(recs, key=lambda r: (r[0], r[1], -r[2])):
        f.write(f'{g},{round(t, 4)},{e}\n')
os.replace(tmp, f'{out}/ipd.csv')
print({g: (v['events'], v['ticks'], v['max_abs_d_residual']) for g, v in alloc.items()}, 'seed', SEED)
