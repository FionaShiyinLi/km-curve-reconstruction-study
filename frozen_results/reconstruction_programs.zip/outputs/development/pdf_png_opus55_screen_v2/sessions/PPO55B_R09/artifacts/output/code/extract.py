"""Extract KM step curves and censor ticks from the vector PDF (no reconstruction yet).
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output/work/extracted.json'
pg = pdfplumber.open(pdf).pages[0]
words = pg.extract_words()
# axis anchors from labelled ticks: x tick marks (black, vertical, below axis) and y tick marks
blk = [l for l in pg.lines if tuple(l['stroking_color']) == (0.0, 0.0, 0.0)]
xt = sorted(l['x0'] for l in blk if l['x0'] == l['x1'] and l['top'] >= 223.0 and l['bottom'] - l['top'] < 5)
yt = sorted(l['top'] for l in blk if l['top'] == l['bottom'] and l['x1'] - l['x0'] < 5)
xlab = [float(w['text']) for w in words if abs(w['top'] - 229.66) < 1 and w['text'].isdigit()]
ylab = [float(w['text']) for w in words if abs(w['x0'] - 43.49) < 1 and w['top'] < 230]
cal = dict(x_ticks=xt, x_labels=xlab, y_ticks=yt, y_labels=sorted(ylab, reverse=True))
# linear fits
def fit(p, v):
    n = len(p); mp = sum(p)/n; mv = sum(v)/n
    b = sum((a-mp)*(c-mv) for a, c in zip(p, v)) / sum((a-mp)**2 for a in p)
    return b, mv - b*mp, max(abs(b*a + mv - b*mp - c) for a, c in zip(p, v))
bx, ax, ex = fit(xt, xlab); by, ay, ey = fit(yt, cal['y_labels'])
cal.update(time_per_pt=bx, time_icpt=ax, max_x_resid=ex, surv_per_pt=by, surv_icpt=ay, max_y_resid=ey)
T = lambda x: bx*x + ax; S = lambda y: by*y + ay
# legend: coloured short horizontal line followed by 'Group X'
leg = {}
for l in pg.lines:
    if l['top'] == l['bottom'] and l['top'] < 30:
        w = min((w for w in words if w['text'] in 'AB' and abs(w['top']-16.16) < 1 and w['x0'] > l['x1']), key=lambda w: w['x0'])
        leg[tuple(round(c, 4) for c in l['stroking_color'])] = w['text']
res = dict(calibration=cal, legend={str(k): v for k, v in leg.items()}, arms={})
for c in pg.curves:
    col = tuple(round(v, 4) for v in c['stroking_color']); g = leg[col]
    pts = [(T(x), S(y)) for x, y in c['pts']]
    ticks = sorted(T(l['x0']) for l in pg.lines if tuple(round(v, 4) for v in l['stroking_color']) == col
                   and l['x0'] == l['x1'] and l['top'] > 30)
    tick_y = sorted((T(l['x0']), S((l['top']+l['bottom'])/2)) for l in pg.lines if tuple(round(v, 4) for v in l['stroking_color']) == col
                   and l['x0'] == l['x1'] and l['top'] > 30)
    res['arms'][g] = dict(colour=col, curve_pts=pts, censor_ticks=ticks, censor_tick_mid=tick_y)
# risk table
rows = {}
for g in 'AB':
    lab = [w for w in words if w['text'] == g and w['x0'] < 55 and w['top'] > 280]
    top = lab[0]['top']
    vals = sorted((w for w in words if abs(w['top']-top) < 1 and w['x0'] > 55), key=lambda w: w['x0'])
    rows[g] = [int(w['text']) for w in vals]
res['risk_table'] = dict(times=xlab, **rows)
json.dump(res, open(out, 'w'), indent=1)
print(json.dumps(cal), res['legend'], rows)
