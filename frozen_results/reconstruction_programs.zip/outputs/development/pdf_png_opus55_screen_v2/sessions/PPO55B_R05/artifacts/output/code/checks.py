"""Reload output/ipd.csv, recompute right-continuous KM per arm, compare with the measured
vector curve, risk table, tick counts; write output/checks.json.
Usage: python checks.py [OUTPUT_DIR]"""
import sys, os, json, hashlib
import numpy as np, pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "output"
path = os.path.join(OUT, "ipd.csv")
sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
df = pd.read_csv(path)
summ = json.load(open(os.path.join(OUT, "extraction_summary.json")))
man_n = {"A": 1000, "B": 1000}

def km(sub):
    t = sub.observed_time.values; e = sub.event.values
    ut = np.unique(t[e == 1]); s = 1.0; out = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); s *= 1 - d / n; out.append((u, s))
    return np.array(out)

def step(tab, x):  # right-continuous step function value at x
    i = np.searchsorted(tab[:, 0], x, side="right") - 1
    return 1.0 if i < 0 else tab[i, 1]

def measured(curve, x):  # measured curve: value of last horizontal level at or before x (right-continuous)
    c = curve[curve.time <= x + 1e-9]
    return float(c.surv.iloc[-1])

TOL_S = 1e-4  # survival tolerance: vector coords to ~1e-4 pt => ~1e-6 in S; 1e-4 allows float/rounding slack
checks = {"csv_sha256": sha, "survival_tolerance": TOL_S,
          "tolerance_justification": "curve read from PDF vector coordinates (~1e-4 pt precision, 180 pt per unit survival); CSV times rounded to 1e-6 months",
          "groups": {}}
for g in "AB":
    sub = df[df.group == g]; curve = pd.read_csv(os.path.join(OUT, f"extracted_curve_{g}.csv"))
    ticks = pd.read_csv(os.path.join(OUT, f"extracted_ticks_{g}.csv")).tick_time.values
    tab = km(sub); end = curve.time.max()
    times = [0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 34, 35, 35.5, round(end - 0.01, 3)]
    comp = []
    for x in times:
        m = measured(curve, x); r = step(tab, x)
        comp.append({"t": x, "measured": round(m, 6), "reconstructed": round(r, 6), "residual": round(r - m, 7),
                     "status": "pass" if abs(r - m) <= TOL_S else "fail"})
    risk = []
    for t, R in sorted(summ["risk_table"][g].items(), key=lambda kv: float(kv[0])):
        t = float(t); n = int((sub.observed_time >= t).sum())
        risk.append({"t": t, "displayed": R, "reconstructed": n, "residual": n - R, "status": "pass" if n == R else "fail"})
    cens_t = np.sort(sub.observed_time[sub.event == 0].values)
    tick_match = bool(len(cens_t) == len(ticks) and np.allclose(cens_t, np.sort(ticks), atol=1e-5))
    checks["groups"][g] = {
        "n_records": int(len(sub)), "n_expected": man_n[g], "n_status": "pass" if len(sub) == man_n[g] else "fail",
        "event_indicator_integer_01": bool(set(sub.event.unique()) <= {0, 1}),
        "events": int(sub.event.sum()), "censored": int((sub.event == 0).sum()),
        "supplied_event_total": "unavailable (manifest has no event totals)",
        "n_visible_ticks": int(len(ticks)), "censor_times_equal_tick_times_one_to_one": tick_match,
        "max_time": float(sub.observed_time.max()), "curve_end_time": float(end),
        "km_vs_measured": comp, "risk_table": risk,
        # evaluated at midpoints between consecutive drops (avoids evaluating exactly on a vertical edge)
        "max_abs_km_residual_all_interdrop_midpoints": float(max(abs(step(tab, x) - measured(curve, x)) for x in
            (lambda d: np.r_[(d[:-1] + d[1:]) / 2, d[-1] + 0.05])(
                pd.read_csv(os.path.join(OUT, f"extracted_drops_{g}.csv")).time.values))),
    }
json.dump(checks, open(os.path.join(OUT, "checks.json"), "w"), indent=1)
for g in "AB":
    c = checks["groups"][g]
    print(g, c["n_status"], c["events"], c["censored"], c["censor_times_equal_tick_times_one_to_one"],
          c["max_abs_km_residual_all_interdrop_midpoints"], [r["status"] for r in c["risk_table"]],
          sum(x["status"] == "fail" for x in c["km_vs_measured"]))
print(sha)
