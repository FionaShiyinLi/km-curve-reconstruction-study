"""Reconstruct participant-level (observed_time, event) records from the vector KM figure.

Usage: python reconstruct.py [INPUT_DIR] [OUTPUT_DIR]
Defaults: ../input and ./output relative to the current working directory.

Only pdfplumber/numpy/pandas are used; no KM-to-IPD package. The algorithm is
deterministic; the manifest seed is recorded and set for reproducibility only.
"""
import sys, os, json, hashlib, tempfile
import numpy as np, pandas as pd, pdfplumber

IN = sys.argv[1] if len(sys.argv) > 1 else "../input"
OUT = sys.argv[2] if len(sys.argv) > 2 else "output"
os.makedirs(OUT, exist_ok=True)
man = json.load(open(os.path.join(IN, "manifest.json")))
SEED = man["code_seed"]; np.random.seed(SEED)
NGRP = man["groups"]

COL = {"A": (0.121569, 0.466667, 0.705882), "B": (1.0, 0.498039, 0.054902)}  # legend colours
pg = pdfplumber.open(os.path.join(IN, "figure.pdf")).pages[0]

# ---- axis calibration from black tick marks + tick labels -------------------
blk = [l for l in pg.lines if l["stroking_color"] == (0.0, 0.0, 0.0)]
xt = sorted({round(l["x0"], 4) for l in blk if abs(l["x0"] - l["x1"]) < 1e-6 and l["bottom"] - l["top"] < 4})
yt = sorted({round(l["top"], 4) for l in blk if abs(l["top"] - l["bottom"]) < 1e-6 and l["x1"] - l["x0"] < 4})
xlab = [0, 6, 12, 18, 24, 30, 36]; ylab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]   # read from text layer
assert len(xt) == 7 and len(yt) == 6
ax, bx = np.polyfit(xt, xlab, 1); ay, by = np.polyfit(yt, ylab, 1)
T = lambda x: ax * x + bx
S = lambda y: ay * y + by
calib = {"x_ticks_pt": xt, "x_labels": xlab, "y_ticks_pt": yt, "y_labels": ylab,
         "month_per_pt": ax, "surv_per_pt": ay,
         "x_resid": list(np.array(xlab) - T(np.array(xt))), "y_resid": list(np.array(ylab) - S(np.array(yt)))}

# ---- risk table from text layer ---------------------------------------------
def risk_row(label_top):
    ch = sorted([c for c in pg.chars if abs(c["top"] - label_top) < 1 and c["x0"] > 50], key=lambda c: c["x0"])
    groups, cur, last = [], "", None
    for c in ch:
        if last is not None and c["x0"] - last > 7: groups.append(cur); cur = ""
        cur += c["text"]; last = c["x0"]
    groups.append(cur); return [int(g) for g in groups]
rows = {}
for c in pg.chars:
    if c["text"] in "AB" and c["top"] > 280: rows[c["text"]] = c["top"]
RISK = {g: dict(zip(xlab, risk_row(rows[g]))) for g in "AB"}

res = {"calibration": calib, "risk_table": RISK, "seed": SEED}
records, diag = [], {}
TOL = 2e-5   # survival-scale tolerance for matching a drop to d/n (coords given to ~1e-4 pt => ~1e-6)

for g in "AB":
    cv = [c for c in pg.curves if c["stroking_color"] == COL[g]][0]
    pts = [(T(x), S(y)) for x, y in cv["pts"]]
    # drops: vertical segments (same x, y decreasing); merge consecutive at same x
    drops = []
    for (t0, s0), (t1, s1) in zip(pts[:-1], pts[1:]):
        if abs(t1 - t0) < 1e-7 and s1 < s0 - 1e-9:
            if drops and abs(drops[-1][0] - t0) < 1e-7: drops[-1][2] = s1
            else: drops.append([t0, s0, s1])
    s_start, t_end = pts[0][1], pts[-1][0]
    ticks = sorted(T(l["x0"]) for l in pg.lines if l["stroking_color"] == COL[g] and l["linewidth"] < 0.9)
    ticks = np.array(ticks)
    N = NGRP[g]; n_avail = N          # number still at risk (not yet event/censored)
    rt = sorted(RISK[g].items())
    ev_times, ev_d, ev_n, cens = [], [], [], []
    prev_t = -1.0
    unmatched = []
    for j, (t, sb, sa) in enumerate(drops):
        # ticks strictly between previous drop and this drop (tick at a drop time = censored after the event)
        k_between = int(((ticks > prev_t + 1e-7) & (ticks < t - 1e-7)).sum())
        n_max = n_avail - k_between
        for tk, r in rt:                # risk table cap: at-risk at any t >= tk is <= R(tk)
            if t >= tk - 1e-9: n_max = min(n_max, r)
        best = None
        for n in range(n_max, 0, -1):
            d = int(round((1 - sa / sb) * n))
            if d < 1: continue
            err = abs(sb * (1 - d / n) - sa)
            if err < TOL: best = (n, d, err); break
        if best is None:  # fall back to nearest fit
            cand = [(abs(sb * (1 - max(1, round((1 - sa / sb) * n)) / n) - sa), n) for n in range(1, n_max + 1)]
            e, n = min(cand); best = (n, max(1, int(round((1 - sa / sb) * n))), e); unmatched.append((t, e))
        n, d, err = best
        c = n_avail - n                 # censored in (prev_t, t)
        cens.append((prev_t, t, c))
        ev_times.append(t); ev_d.append(d); ev_n.append(n)
        n_avail = n - d; prev_t = t
    cens.append((prev_t, 36.0, n_avail))  # remainder: censored after last drop, before 36 (risk 0 at 36)
    # allocate censorings to tick times in each interval; ticks at the drop time itself are
    # assigned to the interval following that drop (censored at t, after the event at t)
    ctimes = []
    for (a, b, c) in cens:
        if c == 0: continue
        lo = a - 1e-7 if a >= 0 else -1.0
        tk = ticks[(ticks > lo) & (ticks < b - 1e-7)] if b < 36 else ticks[ticks > lo]
        # avoid double use of a tick at drop time a by previous interval: previous excluded (< b-1e-7)
        if len(tk) == 0:
            hi = min(b, t_end) if b >= 36 else b
            tk = np.linspace(a if a > 0 else 0, hi, c + 2)[1:-1]   # assumption: uniform spacing
            ctimes += list(tk); continue
        if c >= len(tk):
            rep = np.full(len(tk), c // len(tk)); rep[: c % len(tk)] += 1
            ctimes += list(np.repeat(tk, rep))
        else:
            # fewer censorings than visible ticks: evenly spaced subset (should not occur by construction)
            ctimes += list(tk[np.linspace(0, len(tk) - 1, c).round().astype(int)])
    for t, d in zip(ev_times, ev_d): records += [(g, t, 1)] * d
    records += [(g, t, 0) for t in ctimes]
    diag[g] = {"n_drops": len(drops), "n_ticks": int(len(ticks)), "events": int(sum(ev_d)),
               "censored": int(sum(c for _, _, c in cens)), "start_S": s_start, "curve_end_time": t_end,
               "final_S": drops[-1][2], "unmatched_drops": unmatched,
               "n_intervals_with_censoring": sum(1 for (a, b, c) in cens if c > 0)}
    pd.DataFrame({"time": ev_times, "d": ev_d, "n_risk": ev_n,
                  "S_before": [x[1] for x in drops], "S_after": [x[2] for x in drops]}).to_csv(
        os.path.join(OUT, f"extracted_drops_{g}.csv"), index=False)
    pd.DataFrame({"tick_time": ticks}).to_csv(os.path.join(OUT, f"extracted_ticks_{g}.csv"), index=False)
    pd.DataFrame(pts, columns=["time", "surv"]).to_csv(os.path.join(OUT, f"extracted_curve_{g}.csv"), index=False)

df = pd.DataFrame(records, columns=["group", "observed_time", "event"])
df["observed_time"] = df["observed_time"].clip(lower=0).round(6)
for g in "AB": assert (df.group == g).sum() == NGRP[g], (g, (df.group == g).sum())
fd, tmp = tempfile.mkstemp(dir=OUT, suffix=".csv"); os.close(fd)
df.to_csv(tmp, index=False); os.replace(tmp, os.path.join(OUT, "ipd.csv"))
res["diag"] = diag
json.dump(res, open(os.path.join(OUT, "extraction_summary.json"), "w"), indent=1, default=float)
print(json.dumps(diag, indent=1, default=float))
