# Reconstruction assumptions and method

## Inputs used
- `../input/figure.pdf`, a vector PDF. I read the curves, censor ticks, axis ticks, labels and the number-at-risk table from its drawing objects and text layer with pdfplumber. No rasterization or OCR was needed.
- `../input/manifest.json`: n = 1000 per arm, time in months, seed 2101118176. The algorithm is deterministic; the seed is set and recorded but nothing depends on it.
- The manifest gives no arm-specific event totals, so that check is marked unavailable. Its absence was not taken to mean zero events.

## Measurement
- **Calibration.** The x axis uses the 7 black tick marks at 0, 6, ..., 36 months (x = 64.8 to 410.4 pt, 9.6 pt/month). The y axis uses the 6 ticks at 0.0, ..., 1.0 (180 pt per unit survival). Linear fits have zero residual at every anchor. No global rescaling was applied.
- **Curve origin.** Both curves start exactly at S = 1.000 at t = 0, so no origin correction was needed. Both arms have genuine early drops (first event at 0.012 months in A and 0.004 months in B); these were kept.
- **Curve reading.** Arm colors come from the legend (A blue, B orange). Each curve is one step path of 1576 (A) and 1410 (B) vertices. A vertical segment is a drop; consecutive vertical segments at the same x are merged. This gives 787 drops in A and 704 in B.
- **Censor ticks.** Censor ticks are short vertical strokes (0.65 pt) in the arm's color: 213 in A and 296 in B. The tick's x position is taken as the censoring time.
- **Risk table.** Read from the text layer at 0, 6, ..., 36 months:
  - A: 1000, 665, 459, 312, 217, 68, 0
  - B: 1000, 751, 568, 419, 303, 112, 0

  All values were readable.
- **Saved observations.** Extracted values are saved as `extracted_curve_*.csv`, `extracted_drops_*.csv` and `extracted_ticks_*.csv`, with calibration details in `extraction_summary.json`.

## Algorithm (`code/reconstruct.py`)
1. **Assigning each drop.** For each drop with measured levels S_before and S_after, the program searches for integers (n_risk, d) such that S_before(1 − d/n_risk) = S_after within 2e-5 on the survival scale. Coordinates are accurate to about 1e-4 pt, which is about 1e-6 in S.
2. **Constraints on n_risk.** The candidate n_risk is capped by:
   - the number still under observation minus the visible ticks strictly between the previous drop and this one;
   - the displayed risk count at the most recent table time.

   Within that cap, the largest n_risk that fits is chosen, which is the fewest censorings consistent with the ticks. d is not assumed to be 1; it is solved for. The result was d = 1 at every drop in both arms. The alternatives d = 2k at n_risk = 2n are excluded by the at-risk cap rather than assumed away.
3. **Censorings.** Censorings in each gap are c = n_available − n_risk. They are placed at the visible tick times in that gap. A tick exactly at a drop time is treated as censored after the event at that time, the usual KM convention.
4. **Tail.** Participants still under observation after the last drop are censored at the tail ticks. The displayed risk of 0 at 36 months is respected, and no records are placed at t = 36.
5. **Unused fallbacks.** The code has fallbacks for more censorings than ticks (ticks repeated evenly) or none (uniform spacing). Neither was triggered. The total censorings equal the tick counts exactly (A 213, B 296), and the censoring times match the ticks one to one.
6. **Output.** The CSV is written to a temporary file and moved into place with an atomic rename.

## Result
- **A:** 787 events and 213 censorings.
- **B:** 704 events and 296 censorings.
- **Latest record:** A 35.80 months; B 35.99 months. These are the curve end points and are not extrapolated.

## Verification (`code/checks.py` → `checks.json`)
- The checks reload the committed CSV and recompute a right-continuous KM step function; no interpolation is used.
- **Curve agreement.** Across all midpoints between drops, the largest difference from the measured curve is 2.8e-7 in both arms. The table of 17 checked times, including 35, 35.5 months and the curve end, all pass at a tolerance of 1e-4.
- **Risk table.** The count of records with observed_time ≥ t, with events before censorings at ties, equals the displayed risk count at every time in both arms, including 0 at 36 months.
- **Records.** Arm sizes are 1000 each, and the event indicator takes only the values 0 and 1.

## Limitations and unresolved points
- Tick visibility is not the same as tick multiplicity. The one-tick-per-censoring reading is an assumption. It is supported, but not proven, by the drop ratios, the at-risk cap and all seven risk counts reconciling exactly with no hidden censorings.
- The within-gap order of a censoring tick at the exact x of a drop cannot be determined from the figure. The KM convention was used, and this has no effect on the curve or the risk counts.
- Times carry the precision of the PDF coordinates (about 1e-5 months); the figure's plotted times may themselves be rounded.
- **Sensitivity analysis not run.** The data left no materially different feasible allocation (all constraints reconcile exactly), so no `sensitivity.csv` was produced. This is not an error bound on the reconstruction.
