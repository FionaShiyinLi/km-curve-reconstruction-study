#!/bin/sh
# Run from the work directory: sh output/code/run.sh [../input]
IN=${1:-../input}
python3 output/code/extract.py "$IN/figure.pdf" output
python3 output/code/reconstruct.py output "$IN/manifest.json"
python3 output/code/checks.py output "$IN/manifest.json"
