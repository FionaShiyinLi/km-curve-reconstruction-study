"""Reconstruct IPD from extracted vector KM paths (output of extract.py).
Usage: python reconstruct.py [output_dir]   (reads <out>/extracted_curves.json)
Algorithm: at each distinct drop time, q = 1/(1 - S_after/S_before) = n_risk/d.
Choose the smallest multiplicity d whose implied n_risk = round(d*q) is integer-consistent
and <= the upper bound U (previous n_risk minus previous events). Censorings between drops
= U - n_risk; they are placed at the drawn censor-tick times in that gap (exact counts are
checked). Participants remaining after the last drop are censored at the ticks after it."""
import sys, os, json, numpy as np, pandas as pd
SEED = 394085965                         # supplied code seed; the algorithm is deterministic
np.random.seed(SEED)
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
r = json.load(open(f'{out}/extracted_curves.json'))
N = json.load(open(sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'))['groups']
rows, log = [], {}
for g in 'AB':
    m = []
    for t, a, b in r[g]['drops_t_Sbefore_Safter']:
        if m and abs(m[-1][0] - t) < 1e-7: m[-1][2] = b      # consecutive segments at one time
        else: m.append([t, a, b])
    tk = np.array(sorted(t for t, _ in r[g]['censor_ticks_t_S']))
    U, prev, notes, D, dmax = N[g], -1.0, [], 0, 1
    recs = []
    for t, a, b in m:
        q = 1 / (1 - b / a)
        best = None
        for d in range(1, 8):
            n = round(d * q)
            if n <= U and abs(d * q - n) < 0.3 * d ** 0.5 + 0.1: best = (d, n); break
        if best is None:                                    # ratio slightly above bound: coordinate rounding
            best = (max(1, round(U * (1 - b / a))), U)
            notes.append(f't={t:.4f}: q={q:.2f} > U={U}; set n_risk=U, d={best[0]}')
        d, n = best
        c = U - n
        gap = tk[(tk > prev) & (tk <= t)]
        if len(gap) == c: ct = list(gap)
        else:                                               # not triggered for this figure
            notes.append(f'gap ({prev:.3f},{t:.3f}]: {c} censorings vs {len(gap)} ticks; spread uniformly')
            ct = list(np.linspace(prev, t, c + 2)[1:-1]) if c > 0 else []
        recs += [(g, x, 0) for x in ct] + [(g, t, 1)] * d
        D += d; dmax = max(dmax, d); U = n - d; prev = t
    tail = tk[tk > prev]
    if len(tail) == U: recs += [(g, x, 0) for x in tail]
    else:
        notes.append(f'tail: {U} remaining vs {len(tail)} ticks; censored uniformly to curve end')
        recs += [(g, x, 0) for x in np.linspace(prev, r[g]['end'][0], U + 1)[1:]]
    assert len(recs) == N[g], (g, len(recs))
    rows += recs
    log[g] = {'events': D, 'censored': N[g] - D, 'ticks': len(tk), 'notes': notes,
              'max_multiplicity': dmax}
    # atomic write after each completed group
    df = pd.DataFrame(rows, columns=['group', 'observed_time', 'event'])
    df['observed_time'] = df['observed_time'].clip(lower=0).round(6)
    tmp = f'{out}/ipd.csv.tmp'
    df.to_csv(tmp, index=False); os.replace(tmp, f'{out}/ipd.csv')
json.dump(log, open(f'{out}/reconstruction_log.json', 'w'), indent=1)
print(json.dumps(log, indent=1))
