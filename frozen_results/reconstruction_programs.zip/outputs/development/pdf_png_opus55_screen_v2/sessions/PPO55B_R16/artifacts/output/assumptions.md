# Reconstruction assumptions and method

## Inputs
- `../input/figure.pdf` (single-page vector PDF) and `../input/manifest.json` (A = 1000, B = 1000, months, seed 394085965).
- The manifest has no arm-specific event totals, so that check is marked unavailable. The risk table (0–36 months by 6) was read from the PDF text layer: A 1000/692/485/331/234/88/0; B 1000/647/525/436/354/143/0.
- Legend: blue path = Group A, orange path = Group B (from the legend line segment next to each label).

## Measurement
- The figure is vector graphics, so no pixel measurement was needed. Calibration uses the black axis tick segments: x ticks at 64.8…410.4 pt for 0…36 months (9.6 pt/month), and y ticks at 223.2 pt (S = 0) to 43.2 pt (S = 1). No global rescaling was applied. Both paths start exactly at (0, 1.0), so the origin needed no correction.
- Each KM path was parsed into its vertical drops (time, S_before, S_after): A has 779 drops and B has 620. Censor marks are separate 4-pt vertical segments centered on the curve: A has 221 and B has 380. No two marks in an arm share an x coordinate. Extracted values are in `extracted_curves.json`.

## Algorithm (`code/reconstruct.py`)
At each distinct drop time, q = 1/(1 − S_after/S_before) = n_risk/d. U is the upper bound on n_risk (previous n_risk minus previous d). The algorithm picks the smallest d ≥ 1 for which round(d·q) ≤ U and d·q is close to an integer. The censorings in the gap since the previous drop are then U − n_risk.
- Result: every drop implies d = 1. In every gap, the number of censorings implied by the step ratios equals the number of drawn censor marks. This agreement between the step ratios and the marks is the evidence for d = 1 and for one censoring per mark. It was not assumed.
- Censorings are placed at the censor-mark times. After the last drop, the remaining participants (A 18, B 26) equal the marks after it and are censored at those marks. The last times are 35.958 (A) and 35.962 (B), so no one is at risk at 36, consistent with the displayed 0.
- In three places, q exceeded U by about 0.45, which is coordinate rounding in the PDF. There n_risk was set to U with d = 1 (logged in `reconstruction_log.json`).
- The method is deterministic. The seed is set and recorded but not used.
- Totals: A has 779 events and 221 censored; B has 620 events and 380 censored.

## Checks (`code/checks.py` → `checks.json`)
The checks reload the committed CSV and recompute the right-continuous KM curve.
- At 18 times per arm, including 0 to 0.5 months and the 32–35.95 month tail, and at the midpoint of every plateau, the recomputed KM matches the measured path. The maximum absolute difference is 4.4e-6 for A and 2.8e-7 for B, against a tolerance of 1e-3, which is one event at n = 1000.
- Risk-table counts (observed_time ≥ t) match exactly at all 7 times in both arms. Arm sizes, 0/1 event indicators and finite nonnegative times all pass.

## Limitations
- One A censor mark coincides with an event time. The algorithm counted that censoring as leaving before the event. The KM convention (events before censoring at ties) keeps it in the risk set, which changes n_risk at that drop by 1. The effect on S is below 1e-5.
- Times are exact only to the precision of the plotted coordinates (about 1e-6 months), which may themselves be rounded from the source data. The recovered records are consistent with every displayed feature, but uniqueness cannot be proven: for example, exact within-mark multiplicities or censoring hidden under drops cannot be seen. However, no alternative allocation is consistent with the ratios, the marks and the risk table together.
- A sensitivity analysis was not run. Once the integer consistency above holds, the inputs leave no materially different allocation.

## Reproduce
From the work directory: `sh output/code/run.sh ../input`.
