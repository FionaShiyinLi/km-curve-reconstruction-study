"""Reload committed ipd.csv, recompute right-continuous KM, compare with the vector-measured curve,
risk table and censor ticks; write output/checks.json.  Usage: python checks.py [output_dir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
man = json.load(open(sys.argv[2] if len(sys.argv) > 2 else '../input/manifest.json'))
r = json.load(open(f'{out}/extracted_curves.json'))
df = pd.read_csv(f'{out}/ipd.csv')
sha = hashlib.sha256(open(f'{out}/ipd.csv', 'rb').read()).hexdigest()
# risk table read from PDF text (numbers at 0,6,...,36 months)
RISK = {'A': [1000, 692, 485, 331, 234, 88, 0], 'B': [1000, 647, 525, 436, 354, 143, 0]}
RT = [0, 6, 12, 18, 24, 30, 36]
TOL_S = 1e-3   # vector coordinates: rounding ~1e-5 pt; one event at n=1000 changes S by 1e-3

def km(t, e):
    ut = np.unique(t[e == 1]); S = 1.0; st = []
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum(); S *= 1 - d / n; st.append((u, S))
    return np.array(st)
def step(st, x):           # right-continuous
    i = np.searchsorted(st[:, 0], x, side='right') - 1
    return 1.0 if i < 0 else st[i, 1]
def measured(g, x):        # step function from the vector path
    S = r[g]['start'][1]
    for t, a, b in r[g]['drops_t_Sbefore_Safter']:
        if t <= x: S = b
        else: break
    return S
res = {'csv_sha256': sha, 'tolerance_S': TOL_S,
       'tolerance_justification': 'vector PDF coordinates (no raster error); 1e-3 = one event at n=1000',
       'groups': {}}
allpass = True
for g in 'AB':
    d = df[df.group == g]; t = d.observed_time.values; e = d.event.values
    st = km(t, e); G = {}
    G['n'] = {'observed': int(len(d)), 'manifest': man['groups'][g], 'status': 'pass' if len(d) == man['groups'][g] else 'fail'}
    G['event_indicator_integer_01'] = bool(set(np.unique(e)) <= {0, 1})
    G['time_finite_nonneg'] = bool(np.all(np.isfinite(t)) and (t >= 0).all())
    G['events'] = int(e.sum()); G['supplied_event_total'] = 'unavailable (not in manifest)'
    times = [0, 0.5, 1, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 32, 33, 34, 35, 35.95]
    cmp = []
    for x in times:
        mv, rv = measured(g, x), step(st, x)
        cmp.append({'t': x, 'measured': round(mv, 6), 'reconstructed': round(rv, 6), 'resid': round(rv - mv, 6),
                    'status': 'pass' if abs(rv - mv) <= TOL_S else 'fail'})
    # every drop: max abs difference just after each drop time
    # evaluate at the midpoint of each measured plateau (CSV times are rounded to 1e-6,
    # so evaluating exactly at an unrounded drop time can fall just before the step)
    dr = r[g]['drops_t_Sbefore_Safter']; ends = [x[0] for x in dr[1:]] + [r[g]['end'][0]]
    mids = [((tt + te) / 2, b) for (tt, a, b), te in zip(dr, ends) if te - tt > 2e-6]
    mx = max(abs(step(st, x) - b) for x, b in mids)
    G['n_plateaus_checked'] = len(mids)
    G['km_vs_measured'] = cmp; G['max_abs_resid_all_drops'] = float(mx)
    G['max_abs_resid_status'] = 'pass' if mx <= TOL_S else 'fail'
    rk = []
    for tt, obs in zip(RT, RISK[g]):
        rec = int((t >= tt).sum())
        rk.append({'t': tt, 'table': obs, 'reconstructed': rec, 'resid': rec - obs, 'status': 'pass' if rec == obs else 'fail'})
    G['risk_table'] = rk
    ctk = np.array([x for x, _ in r[g]['censor_ticks_t_S']])
    ct = np.sort(t[e == 0])
    G['censor_ticks'] = {'n_ticks': int(len(ctk)), 'n_censored': int(len(ct)),
                         'max_abs_time_diff': float(np.abs(np.sort(ctk) - ct).max()) if len(ct) == len(ctk) else None}
    G['last_time'] = float(t.max()); G['curve_end_t'] = r[g]['end'][0]
    G['tail_S_measured_end'] = r[g]['end'][1]; G['tail_S_reconstructed_end'] = float(st[-1, 1])
    allpass &= all(c['status'] == 'pass' for c in cmp + rk) and G['n']['status'] == 'pass' and mx <= TOL_S
    res['groups'][g] = G
res['overall'] = 'pass' if allpass else 'fail'
json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
print(res['overall'], sha)
for g in 'AB':
    G = res['groups'][g]
    print(g, G['n'], G['events'], G['max_abs_resid_all_drops'], [x['reconstructed'] for x in G['risk_table']], G['censor_ticks'], G['last_time'])
