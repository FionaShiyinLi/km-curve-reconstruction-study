"""Extract KM step vertices and censor ticks from the vector PDF.
Usage: python extract.py [path/to/figure.pdf] [outdir]"""
import sys, json, pdfplumber
pdf = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.pdf'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
pg = pdfplumber.open(pdf).pages[0]
blk = [l for l in pg.lines if l['stroking_color'] == (0.0, 0.0, 0.0)]
# axis calibration from black tick marks and their labels (0..36 by 6; 0..1 by 0.2)
xt = sorted(l['x0'] for l in blk if l['top'] == 223.2 and l['bottom'] > 224)
yt = sorted(l['top'] for l in blk if l['x0'] < 64 and l['x1'] == 64.8)
assert len(xt) == 7 and len(yt) == 6, (xt, yt)
x0, dx = xt[0], (xt[-1] - xt[0]) / 36.0
yb, dy = yt[-1], (yt[-1] - yt[0]) / 1.0
T = lambda x: (x - x0) / dx
S = lambda y: (yb - y) / dy
cols = {(0.121569, 0.466667, 0.705882): 'A', (1.0, 0.498039, 0.054902): 'B'}  # legend: blue=A, orange=B
res = {'calibration': {'x0': x0, 'pt_per_month': dx, 'y_S0': yb, 'pt_per_unitS': dy,
                       'x_ticks': xt, 'y_ticks': yt}}
for c in pg.curves:
    g = cols[tuple(c['stroking_color'])]
    pts = c['pts']
    # step path: horizontal then vertical segments; record each vertical drop
    drops = []
    for (xa, ya), (xb, yb2) in zip(pts[:-1], pts[1:]):
        if abs(xa - xb) < 1e-9 and yb2 > ya + 1e-9:
            drops.append([T(xa), S(ya), S(yb2)])
    ticks = sorted([T(l['x0']), S((l['top'] + l['bottom']) / 2)] for l in pg.lines
                   if l['linewidth'] == 0.65 and cols.get(tuple(l['stroking_color'])) == g)
    res[g] = {'start': [T(pts[0][0]), S(pts[0][1])], 'end': [T(pts[-1][0]), S(pts[-1][1])],
              'drops_t_Sbefore_Safter': drops, 'censor_ticks_t_S': ticks}
json.dump(res, open(f'{out}/extracted_curves.json', 'w'), indent=1)
for g in 'AB':
    print(g, 'start', res[g]['start'], 'end', res[g]['end'], 'drops', len(res[g]['drops_t_Sbefore_Safter']),
          'ticks', len(res[g]['censor_ticks_t_S']))
