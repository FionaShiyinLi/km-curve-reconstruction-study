import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
H,W,_=im.shape
dark=(im.sum(2)<150)
# axis lines
cols=dark.sum(0); rows=dark.sum(1)
print('dark cols',[ (i,cols[i]) for i in np.argsort(cols)[-5:]])
print('dark rows',[ (i,rows[i]) for i in np.argsort(rows)[-5:]])
# unique colors
from collections import Counter
c=Counter(map(tuple,im.reshape(-1,3)))
print([k for k in c.most_common(12)])
