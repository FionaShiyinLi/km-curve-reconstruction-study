"""KM -> participant records, own implementation.
Usage: python3 reconstruct.py [figure.png] [--alt]   (run from anywhere; outputs to ../)
Algorithm
 1. extract.py measures the step curve (per-column level), drops and censor marks.
 2. Events: at each measured drop, d = round(n_risk * (1 - S_meas_after / S_recon_before)),
    i.e. self-correcting against the reconstructed KM, n_risk from the current record set.
 3. Censorings: start from 'strong' marks (one censor per ~3 px of mark width).
    Risk-table reconciliation, interval by interval (left to right): if the implied number of
    censorings in [t_k, t_k+1) differs from n_k - n_k+1 - events_k, add/remove censors one at a
    time. Added censors go to the candidate position (any detected mark in the interval, incl.
    weak/artifact-class marks, as extra multiplicity) minimising SSE between reconstructed and
    measured KM. (--alt: added censors spread uniformly over the interval instead.)
"""
import sys, os, json, hashlib
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.argv = [a for a in sys.argv]
ALT = '--alt' in sys.argv
args = [a for a in sys.argv[1:] if a != '--alt']
if args: sys.argv = [sys.argv[0], args[0]]
else: sys.argv = [sys.argv[0]]
import extract
calib, res, S_of, T_of = extract.load()
OUT = os.path.join(HERE, '..')
SEED = 1591765012
np.random.seed(SEED)   # recorded; algorithm is deterministic

N0 = {'A': 100, 'B': 100}
RISK_T = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 68, 48, 29, 18, 7, 0], 'B': [100, 69, 59, 47, 39, 11, 0]}
PRIO = {'strong': 0, 'weak': 1, 'artifact': 2}

def build(g, cens):
    """cens: list of censor times. Returns (times, events) arrays and recon S after each drop."""
    r = res[g]; n0 = N0[g]
    cens = np.sort(np.array(cens, float))
    ev_t, S = [], 1.0
    nev = 0
    for d in r['drops']:
        t = d['t']
        n_risk = n0 - nev - np.sum(cens < t)
        if n_risk <= 0: continue
        k = int(round(n_risk * (1 - d['S_after'] / S)))
        k = max(0, min(k, n_risk))
        if k:
            ev_t += [t]*k; nev += k; S *= (1 - k/n_risk)
    return np.array(ev_t), cens

def km(times, events):
    o = np.lexsort((1 - events, times)); t = times[o]; e = events[o]
    ut = np.unique(t[e == 1]); S = 1.0; out = []
    for u in ut:
        n = np.sum(t >= u); d = np.sum((t == u) & (e == 1)); S *= 1 - d/n; out.append((u, S))
    return out

def S_at(step, t):
    s = 1.0
    for u, v in step:
        if u <= t: s = v
        else: break
    return s

def sse(g, ev, ce):
    r = res[g]; lv = r['level']
    times = np.r_[ev, ce]; e = np.r_[np.ones(len(ev)), np.zeros(len(ce))]
    step = km(times, e)
    dx = np.array([d['x'] for d in r['drops']])
    tot = 0.0
    for x in range(r['xmin'], r['xmax']+1, 2):
        if np.min(np.abs(dx - x)) <= 3: continue
        tot += (S_at(step, T_of(x)) - S_of(lv[x]))**2
    return tot

def counts(ev, ce, n0):
    out = []
    for t in RISK_T:
        out.append(int(np.sum(ev >= t) + np.sum(ce >= t)))
    return out

def reconstruct(g, alt=False):
    r = res[g]
    marks = r['ticks']
    cens = []
    for m in marks:
        if m['cls'] == 'strong': cens += [m['t']] * m['n_visible']
    log = []
    for it in range(400):
        ev, ce = build(g, cens)
        # remaining participants beyond the last drawn time are not allowed (risk at 36 = 0):
        n_rec = len(ev) + len(ce)
        extra = N0[g] - n_rec   # participants not yet placed
        nk = counts(ev, ce, N0[g])
        # target: records placed so that #(time>=t_k) == RISK[k]; unplaced participants are censors to add
        changed = False
        for k in range(len(RISK_T) - 1):
            a, b = RISK_T[k], RISK_T[k+1]
            # number at risk at b implied if all unplaced were placed after b: nk[k+1] + extra
            have_b = nk[k+1] + extra
            need = have_b - RISK[g][k+1]      # >0: too many at risk at b -> add censors in [a,b)
            if need > 0:
                lo = a; hi = min(b, r['t_end'])
                if alt:
                    inside = [c for c in cens if lo <= c < b]
                    pos = lo + (hi - lo) * (len([c for c in cens if lo <= c < b and c not in [m['t'] for m in marks]]) + 0.5) / max(1, need + 1)
                    cands = [pos]
                else:
                    cands = sorted({m['t'] for m in marks if lo <= m['t'] < b},
                                   key=lambda t: min(PRIO[m['cls']] for m in marks if m['t'] == t))
                    if not cands:
                        cands = list(lo + (hi - lo) * (np.arange(5) + 0.5) / 5)
                scored = []
                for c in cands:
                    e2, c2 = build(g, cens + [c]); s = sse(g, e2, c2)
                    wid = max([m['width'] for m in marks if m['t'] == c] + [3])
                    load = cens.count(c) / (wid / 3.0)   # assigned censors per visible tick width
                    scored.append((s, load, c))
                smin = min(z[0] for z in scored)
                # among fits equal within 1e-4 SSE (flat curve: no information), spread by width load
                best = min([z for z in scored if z[0] <= smin + 1e-4], key=lambda z: (z[1], z[2]))
                best = (best[0], best[2])
                cens.append(best[1]); log.append(('add', k, round(best[1], 3))); changed = True
                break
            if need < 0:
                # too few at risk at b: remove a censor in [a,b) (weakest first by SSE)
                inside = [c for c in cens if a <= c < b]
                if not inside:
                    log.append(('unresolved_short', k, need)); continue
                best = None
                for c in set(inside):
                    c2l = list(cens); c2l.remove(c)
                    e2, c2 = build(g, c2l); s = sse(g, e2, c2)
                    if best is None or s < best[0] - 1e-9: best = (s, c)
                cens.remove(best[1]); log.append(('remove', k, round(best[1], 3))); changed = True
                break
        if not changed:
            break
    ev, ce = build(g, cens)
    if len(ev) + len(ce) != N0[g]:
        log.append(('size_mismatch', len(ev) + len(ce)))
    return ev, ce, log

def write_atomic(path, rows):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        f.write('group,observed_time,event\n')
        for g, t, e in rows: f.write(f'{g},{t:.4f},{e}\n')
    os.replace(tmp, path)

if __name__ == '__main__':
    rows = []; info = {}
    for g in ['A', 'B']:
        ev, ce, log = reconstruct(g, ALT)
        ok = len(ev) + len(ce) == N0[g]
        info[g] = dict(events=int(len(ev)), censored=int(len(ce)), complete=ok, log=log,
                       risk_counts=counts(ev, ce, N0[g]))
        print(g, info[g])
        if ok:
            rows += [(g, t, 1) for t in ev] + [(g, t, 0) for t in ce]
    rows.sort(key=lambda z: (z[0], z[1], -z[2]))
    name = 'sensitivity.csv' if ALT else 'ipd.csv'
    write_atomic(os.path.join(OUT, name), rows)
    json.dump(info, open(os.path.join(OUT, ('recon_log_alt.json' if ALT else 'recon_log.json')), 'w'), indent=1, default=str)
