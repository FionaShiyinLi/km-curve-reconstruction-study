"""Pixel extraction of the two KM step curves and censor ticks from figure.png.
Usage: python3 extract.py [path/to/figure.png]  -> writes ../extracted_*.csv"""
import sys, os, json
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', '..', 'input', 'figure.png')
OUT = os.path.join(HERE, '..')
im = np.asarray(Image.open(FIG).convert('RGB')).astype(int)
dark = im.sum(2) < 300

# --- axis calibration from labelled tick marks (tick marks are 2 px wide) ---
yt = np.where(dark[:, 262])[0]; yt = yt[yt < 940]
ypairs = [yt[i:i+2].mean() for i in range(0, len(yt), 2)]   # rows for 1.0,0.8,...,0.0
xt = np.where(dark[936, 260:1720])[0] + 260
xpairs = [xt[i:i+2].mean() for i in range(0, len(xt), 2)]   # cols for 0,6,...,36
yv = np.array([1.0, 0.8, 0.6, 0.4, 0.2, 0.0]); xv = np.arange(0, 37, 6)
ay, by = np.polyfit(yv, ypairs, 1); ax, bx = np.polyfit(xv, xpairs, 1)
calib = dict(y_ticks_rows=list(map(float, ypairs)), x_ticks_cols=list(map(float, xpairs)),
             row_per_unit=ay, row_at_0=by, col_per_month=ax, col_at_0=bx,
             y_resid=list(map(float, np.array(ypairs) - (ay*yv+by))),
             x_resid=list(map(float, np.array(xpairs) - (ax*xv+bx))))
S_of = lambda r: (r - by) / ay
T_of = lambda c: (c - bx) / ax

COLORS = {'A': (31, 119, 180), 'B': (255, 127, 14)}
Y0, Y1 = 150, 926   # plot rows (exclude x-axis line)

def runs(v):
    idx = np.where(v)[0]
    if len(idx) == 0: return []
    br = np.where(np.diff(idx) > 1)[0]
    st = np.r_[idx[0], idx[br+1]]; en = np.r_[idx[br], idx[-1]]
    return list(zip(st, en))

res = {}
for g, col in COLORS.items():
    m = np.abs(im - np.array(col)).sum(2) < 60
    m[:Y0] = False; m[Y1:] = False
    H, W = m.shape
    # pass 1: horizontal-line support from runs >= 11 px (wider than any merged tick cluster,
    # which reach 7 px); level from the bottom edge (3 px core + 1 px antialias -> centre = bottom-1.5)
    hs = np.zeros_like(m)
    for r in range(Y0, Y1):
        for a, b in runs(m[r]):
            if b - a + 1 >= 11: hs[r, a:b+1] = True
    xs = np.where(m.any(0))[0]; xmin, xmax = xs.min(), xs.max()
    level = np.full(W, np.nan)
    for x in range(xmin, xmax+1):
        rr = runs(hs[:, x])
        if rr:
            level[x] = rr[-1][1] - 1.5
    top_anchor = by + ay*1.0
    sup = level.copy()
    # pass 2: columns without long-run support (dense staircases, ticks, occlusion):
    # level = bottom edge of the stroke, bounded by the supported levels on either side;
    # tick columns (pixels > 5 rows above the running level) carry the running level.
    lv = np.full(W, np.nan); cur = top_anchor
    nxt = np.full(W, np.nan); last = np.nan
    for x in range(xmax, xmin-1, -1):
        if not np.isnan(sup[x]): last = sup[x]
        nxt[x] = last
    for x in range(xmin, xmax+1):
        if not np.isnan(sup[x]) and sup[x] >= cur - 1.0:
            v = sup[x]
        else:
            col = np.where(m[:, x])[0]
            hi = nxt[x] if not np.isnan(nxt[x]) else cur
            col = col[(col >= cur - 12) & (col <= hi + 1.5 + 0.5)]
            if len(col) == 0 or col.min() < cur - 1.5 - 4:   # empty/occluded or tick column
                v = cur
            else:
                v = min(max(col.max() - 1.5, cur), hi)
        lv[x] = max(v, cur); cur = lv[x]
    level = sup
    # tick detection: pixels 4..13 rows above the pre-drop level
    tickcol = np.zeros(W, bool)
    for x in range(xmin, xmax+1):
        ref = np.nanmin(lv[max(xmin, x-4):x+1])
        lo, hi = int(round(ref - 13)), int(round(ref - 4))
        tickcol[x] = m[lo:hi+1, x].any()
    ticks = []
    for a, b in runs(tickcol):
        w = b - a + 1
        ref = np.nanmin(lv[max(xmin, a-4):b+1])
        # height of the mark above the line centre, per column
        hts = []
        for x in range(a, b+1):
            rr = np.where(m[int(ref-16):int(ref), x])[0]
            hts.append(16 - rr.min() if len(rr) else 0)
        h = max(hts); ncol6 = sum(v >= 6 for v in hts)
        cls = 'strong' if (ncol6 >= 2) else ('weak' if h >= 6 else 'artifact')
        if a - xmin < 5:   # reference level unreliable in the dense initial staircase
            cls = 'artifact'
        ticks.append(dict(x0=int(a), x1=int(b), width=w, t=T_of((a+b)/2), height=int(h), cls=cls,
                          n_visible=max(1, int(round(w/3))), S=S_of(lv[(a+b)//2])))
    # drops
    drops = []
    lv[xmin-1] = by + ay*1.0
    for x in range(xmin, xmax+1):
        if lv[x] > lv[x-1] + 0.75:
            drops.append(dict(x=int(x), t=max(0.0, T_of(x+1)), S_before=S_of(lv[x-1]), S_after=S_of(lv[x]),
                              occluded_before=bool(np.isnan(level[x-1]))))
    res[g] = dict(xmin=int(xmin), xmax=int(xmax), t_end=T_of(xmax), ticks=ticks, drops=drops,
                  level=lv, raw=level)
    import csv
    with open(os.path.join(OUT, f'extracted_curve_{g}.csv'), 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['col', 'time', 'row_level_raw', 'row_level_used', 'S_measured'])
        for x in range(xmin, xmax+1):
            w.writerow([x, round(T_of(x), 4), '' if np.isnan(level[x]) else level[x], lv[x], round(S_of(lv[x]), 5)])
    with open(os.path.join(OUT, f'extracted_ticks_{g}.csv'), 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['x0', 'x1', 'width_px', 'height_px', 'class', 'time', 'n_visible_est', 'S_at_tick'])
        for t in ticks: w.writerow([t['x0'], t['x1'], t['width'], t['height'], t['cls'], round(t['t'], 4), t['n_visible'], round(t['S'], 4)])
    with open(os.path.join(OUT, f'extracted_drops_{g}.csv'), 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['col', 'time', 'S_before', 'S_after', 'occluded_before'])
        for d in drops: w.writerow([d['x'], round(d['t'], 4), round(d['S_before'], 5), round(d['S_after'], 5), d['occluded_before']])

json.dump(calib, open(os.path.join(OUT, 'calibration.json'), 'w'), indent=1)

def load():
    return calib, res, S_of, T_of

if __name__ == '__main__':
    print(json.dumps(calib))
    for g in res:
        r = res[g]
        print(g, 'xrange', r['xmin'], r['xmax'], 't_end', round(r['t_end'], 3), 'ndrops', len(r['drops']), 'nticks', len(r['ticks']))
        print(' ticks:', [(round(t['t'], 2), t['width'], t['height'], t['cls']) for t in r['ticks']])
        print(' first drops:', [(round(d['t'],3), round(d['S_before'],3), round(d['S_after'],3)) for d in r['drops'][:3]])
        continue
        print(' drops:', [(round(d['t'], 2), round(d['S_before'], 3), round(d['S_after'], 3), 'O' if d['occluded_before'] else '') for d in r['drops']])
        occ = np.where(np.isnan(r['raw'][r['xmin']:r['xmax']+1]))[0] + r['xmin']
        print(' occluded cols:', [(a, b) for a, b in runs(np.isin(np.arange(2000), occ))])
