import numpy as np
from PIL import Image
im=np.asarray(Image.open('../../../input/figure.png').convert('RGB')).astype(int)
dark=(im.sum(2)<300)
r=np.where(dark[:,262])[0]; print('ytick rows',r)
c=np.where(dark[936,:])[0]; print('xtick cols',c)
def mask(col,tol=60): return (np.abs(im-np.array(col)).sum(2)<tol)
for name,col in [('A',(31,119,180)),('B',(255,127,14))]:
    m=mask(col)
    xs=np.where(m[150:935].any(0))[0]; print(name,'x range',xs.min(),xs.max())
    for x in list(range(268,285))+[296,297,298,299,300]:
        ys=np.where(m[150:935,x])[0]+150
        print(name,x,ys.tolist()[:3],ys.tolist()[-3:],len(ys))
