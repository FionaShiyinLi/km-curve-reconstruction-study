"""Reload committed CSV, recompute right-continuous KM, compare with measurements and risk table.
Usage: python checks.py [outdir]"""
import sys, json, hashlib, numpy as np, pandas as pd
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
RT = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 72, 50, 32, 21, 9, 0], 'B': [100, 81, 59, 47, 38, 11, 0]}

def km(df):
    ts = np.sort(df.loc[df.event == 1, 'observed_time'].unique()); S = 1.0; st = []
    for t in ts:
        n = (df.observed_time >= t).sum(); d = ((df.observed_time == t) & (df.event == 1)).sum()
        S *= 1 - d / n; st.append((t, S))
    return st
def S_at(st, t):  # right-continuous step
    v = 1.0
    for u, s in st:
        if u <= t: v = s
        else: break
    return v
def rmst(st, tau):
    a, last, v = 0.0, 0.0, 1.0
    for u, s in st:
        if u > tau: break
        a += v * (u - last); last, v = u, s
    return a + v * (tau - last)

def run(csv):
    df = pd.read_csv(csv)
    sha = hashlib.sha256(open(csv, 'rb').read()).hexdigest()
    meas = json.load(open(f'{out}/measurements_primary.json'))
    res = {'csv': csv, 'sha256': sha, 'columns_ok': list(df.columns) == ['group', 'observed_time', 'event'],
           'arms': {}}
    TOL = 0.006  # ~4.5 px: 1-px reading (0.0013) + half-line antialias; drop-time uncertainty handled by +-2 column window
    for g in 'AB':
        d = df[df.group == g]; st = km(d)
        curve = {round(c['t'], 4): (c['S'], c['src']) for c in meas[g]['measure']['curve']}
        ct = sorted(curve)
        end = meas[g]['measure']['end_t']
        cmp = []
        for t in [0.5, 1, 2, 3, 4.5, 6, 7.5, 9, 10.5, 12, 13.5, 15, 16.5, 18, 20, 22, 24, 26, 28, 30, 32, 34, round(end - 0.1, 2)]:
            i = int(np.argmin(np.abs(np.array(ct) - t))); m, src = curve[ct[i]]
            win = [curve[ct[j]][0] for j in range(max(0, i - 2), min(len(ct), i + 3))]
            rec = S_at(st, t); resid = rec - m
            ok = abs(resid) <= TOL or (min(win) - TOL <= rec <= max(win) + TOL)
            cmp.append({'t': t, 'measured': round(m, 4), 'measured_source': src, 'recon': round(rec, 4),
                        'resid': round(resid, 4), 'status': ('pass' if ok else 'fail') if src == 'own' else ('pass' if ok else 'unresolved')})
        risk = []
        for t, n in zip(RT, RISK[g]):
            c = int((d.observed_time >= t).sum())
            risk.append({'t': t, 'table': n, 'recon': c, 'resid': c - n, 'status': 'pass' if c == n else 'fail'})
        res['arms'][g] = {'n': int(len(d)), 'n_expected': 100, 'n_ok': len(d) == 100,
                          'event_integer_ok': bool(d.event.isin([0, 1]).all()),
                          'times_ok': bool(np.isfinite(d.observed_time).all() and (d.observed_time >= 0).all()),
                          'events': int(d.event.sum()), 'supplied_event_total': 'unavailable (not in manifest)',
                          'max_time': float(d.observed_time.max()), 'curve_end_measured': end,
                          'curve_checks': cmp, 'risk_checks': risk, 'measure_tolerance': TOL}
    return res, df

if __name__ == '__main__':
    res, df = run(f'{out}/ipd.csv')
    try:
        sdf = pd.read_csv(f'{out}/sensitivity.csv'); tau = 35.0
        sens = {'horizon_months': tau, 'assumption': 'extra (tick-less) censorings spread uniformly over each risk interval instead of stacked on visible ticks'}
        for g in 'AB':
            p = km(df[df.group == g]); s = km(sdf[sdf.group == g])
            sens[g] = {'S_tau_primary': round(S_at(p, tau), 4), 'S_tau_sens': round(S_at(s, tau), 4),
                       'RMST_tau_primary': round(rmst(p, tau), 3), 'RMST_tau_sens': round(rmst(s, tau), 3),
                       'S12_primary': round(S_at(p, 12), 4), 'S12_sens': round(S_at(s, 12), 4),
                       'S24_primary': round(S_at(p, 24), 4), 'S24_sens': round(S_at(s, 24), 4),
                       'events_primary': int(df[df.group == g].event.sum()), 'events_sens': int(sdf[sdf.group == g].event.sum())}
        res['sensitivity'] = sens
    except FileNotFoundError:
        res['sensitivity'] = 'not run'
    json.dump(res, open(f'{out}/checks.json', 'w'), indent=1)
    for g in 'AB':
        a = res['arms'][g]
        print(g, a['n'], a['events'], [ (c['t'], c['resid'], c['status']) for c in a['curve_checks'] if c['status'] != 'pass'],
              [(r['t'], r['recon'], r['table']) for r in a['risk_checks']])
    print(res['sensitivity'])
