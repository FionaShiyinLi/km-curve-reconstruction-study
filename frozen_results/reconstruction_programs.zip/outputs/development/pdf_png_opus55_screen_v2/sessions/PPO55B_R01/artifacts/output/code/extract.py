"""Pixel extraction of KM step curves and censor ticks from ../input/figure.png.
Usage: python extract.py [path_to_figure] [outdir]"""
import sys, json, numpy as np
from PIL import Image
fig = sys.argv[1] if len(sys.argv) > 1 else '../input/figure.png'
out = sys.argv[2] if len(sys.argv) > 2 else 'output'
im = np.asarray(Image.open(fig).convert('RGB')).astype(int)
H, W, _ = im.shape
cols = {'A': (31, 119, 180), 'B': (255, 127, 14)}
# axis calibration: locate axis lines (dark pixels)
dark = (im.sum(2) < 150)
# y-axis: column with longest dark run in plot region; x-axis: row with longest dark run
xax_row = int(np.argmax(dark[:, 200:1750].sum(1)))
yax_col = int(np.argmax(dark[100:1000, :].sum(0)))
print('x-axis row', xax_row, 'y-axis col', yax_col)
# tick marks below x axis (labelled 0..36 by 6) and left of y axis (0..1 by .2)
below = dark[xax_row + 3:xax_row + 10, :].sum(0)
xt = [x for x in range(yax_col - 3, W) if below[x] > 4]
left = dark[:, yax_col - 10:yax_col - 3].sum(1)
yt = [y for y in range(H) if left[y] > 4]
def groups(v):
    g = []; 
    for p in v:
        if g and p - g[-1][-1] <= 1: g[-1].append(p)
        else: g.append([p])
    return [float(np.mean(a)) for a in g]
xt, yt = groups(xt), groups(yt)
print('x ticks px', xt); print('y ticks px', yt)
xt_lab = [0, 6, 12, 18, 24, 30, 36]; yt_lab = [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]
ax = np.polyfit(xt, xt_lab, 1); ay = np.polyfit(yt, yt_lab, 1)
print('x fit resid', np.array(xt_lab) - np.polyval(ax, xt), 'y fit resid', np.array(yt_lab) - np.polyval(ay, yt))
t_of = lambda x: float(np.polyval(ax, x)); s_of = lambda y: float(np.polyval(ay, y))
x0, x1 = int(round(xt[0])), int(round(xt[-1])); ytop = int(round(yt[0]))
res = {'calib': {'x_px': xt, 'x_lab': xt_lab, 'y_px': yt, 'y_lab': yt_lab, 'ax': list(ax), 'ay': list(ay)}}
for g, c in cols.items():
    m = (np.abs(im - np.array(c)).sum(2) < 90)
    m[:ytop - 15, :] = False; m[xax_row - 1:, :] = False; m[:, :x0] = False
    # horizontal-line pixels: set pixel with horizontal run >= 5 around it
    hr = np.zeros_like(m)
    for dx in range(-4, 1):
        ok = np.ones_like(m)
        for k in range(5):
            ok &= np.roll(m, -(dx + k), axis=1)
        hr |= ok
    level = np.full(W, np.nan); ticks = []; colinfo = {}
    for x in range(x0, x1 + 3):
        ys = np.where(hr[:, x])[0]
        if len(ys): level[x] = ys.max()  # lowest horizontal run (post-drop level at corners)
        allys = np.where(m[:, x])[0]
        colinfo[x] = (int(allys.min()) if len(allys) else -1, int(allys.max()) if len(allys) else -1)
    # centre of line thickness: use lower edge minus half thickness (~1)
    res[g] = {'level_px': {int(x): float(level[x]) for x in range(x0, x1 + 3) if not np.isnan(level[x])},
              'col_extent': {int(x): colinfo[x] for x in colinfo if colinfo[x][0] >= 0}}
json.dump(res, open(f'{out}/raw_pixels.json', 'w'))
