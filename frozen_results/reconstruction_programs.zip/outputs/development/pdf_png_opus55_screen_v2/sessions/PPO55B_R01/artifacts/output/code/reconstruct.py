"""KM -> approximate IPD reconstruction from pixel measurements (own implementation).
Usage: python reconstruct.py [outdir] [mode]; mode 'primary' (extra censorings at visible tick
positions) or 'sensitivity' (extra censorings spread uniformly over the risk interval)."""
import sys, json, os, hashlib, numpy as np
out = sys.argv[1] if len(sys.argv) > 1 else 'output'
mode = sys.argv[2] if len(sys.argv) > 2 else 'primary'
np.random.seed(452996545)  # supplied code seed; algorithm is deterministic
r = json.load(open(f'{out}/raw_pixels.json'))
ax, ay = r['calib']['ax'], r['calib']['ay']
t_of = lambda x: float(np.polyval(ax, x))
EDGE1 = 181.0   # lower edge of line drawn at S=1 (line ~4 px thick, centre = edge-1.5)
s_of = lambda e: float(np.polyval(ay, e - 1.5))
RT = [0, 6, 12, 18, 24, 30, 36]
RISK = {'A': [100, 72, 50, 32, 21, 9, 0], 'B': [100, 81, 59, 47, 38, 11, 0]}
NSIZE = {'A': 100, 'B': 100}

def measure(g):
    o = 'B' if g == 'A' else 'A'
    lv = {int(k): v for k, v in r[g]['level_px'].items()}
    lvo = {int(k): v for k, v in r[o]['level_px'].items()}
    ce = {int(k): v for k, v in r[g]['col_extent'].items()}
    xs = sorted(set(lv) | set(ce)); xend = max(xs)
    x0 = 270
    lev, src = [], []
    cur = EDGE1
    own_x = sorted(lv)
    for x in range(x0, xend + 1):
        if x in lv: cur = lv[x]; src.append('own')
        else:
            # occluded: adopt other arm's level only if it lies between own previous and own next visible level
            nxt = next((lv[u] for u in own_x if u > x), None)
            if x in lvo and lvo[x] >= cur - 1 and (nxt is None or lvo[x] <= nxt + 1):
                cur = lvo[x]; src.append('other')
            else: src.append('carry')
        lev.append(cur)
    lev = np.array(lev)
    # monotonicity check (no correction applied)
    viol = int(np.sum(np.diff(lev) < -1))
    # plateaus: runs of equal level; drops at level increases >= 3 px
    drops = []; prev = lev[0]
    for i in range(1, len(lev)):
        if lev[i] - prev >= 3:
            drops.append({'x': x0 + i, 't': t_of(x0 + i + 1.5), 'S_before': s_of(prev), 'S_after': s_of(lev[i]),
                          'occluded': src[i] != 'own'})
            prev = lev[i]
        elif abs(lev[i] - prev) >= 1 and abs(lev[i] - prev) < 3:
            prev = prev  # sub-3px wobble treated as antialias noise
    # merge drops occurring within 2 columns (riser partially split)
    md = []
    for d in drops:
        if md and d['x'] - md[-1]['x'] <= 3:
            md[-1]['S_after'] = d['S_after']
        else: md.append(d)
    # censor ticks: pixels >=5 px below lower edge and >=9 px above it
    tk = []
    for x in range(x0 + 2, xend + 1):
        if x in ce:
            L = lev[x - x0]
            Lb = lev[max(0, x - x0 - 8):x - x0 + 1].min()  # highest level over preceding 8 columns (pre-riser level)
            if (ce[x][1] >= L + 5 and ce[x][0] <= L - 9) or ce[x][0] <= Lb - 8: tk.append(x)
    groups = []
    for x in tk:
        if groups and x - groups[-1][-1] <= 1: groups[-1].append(x)
        else: groups.append([x])
    ticks = [{'x': float(np.mean(gp)), 't': t_of(np.mean(gp)), 'width': len(gp)} for gp in groups]
    curve = [{'x': x0 + i, 't': t_of(x0 + i), 'S': s_of(lev[i]), 'src': src[i]} for i in range(len(lev))]
    return {'drops': md, 'ticks': ticks, 'curve': curve, 'end_t': t_of(xend), 'monotonic_violations': viol,
            'occluded_cols': int(sum(s != 'own' for s in src))}

def simulate(n0, drops, cens, s0):
    """Forward KM with event drops (from measured ratio) and censor times. Events before censoring at ties."""
    n, S = n0, s0; ev = []; ce = []
    items = [(d['t'], 0, d) for d in drops] + [(c, 1, None) for c in cens]
    items.sort(key=lambda z: (z[0], z[1]))
    for t, kind, d in items:
        if n <= 0: break
        if kind == 0:
            q = 1 - d['S_after'] / S
            k = max(0, int(round(n * q)))  # cumulative rounding vs reconstructed S; sub-event fragments carry forward
            k = min(k, n)
            ev += [t] * k; n -= k; S *= (1 - k / (n + k))
        else:
            ce.append(t); n -= 1
    return n, S, ev, ce

def place(ticks_in, c, a, b):
    if c <= 0: return []
    if not ticks_in or mode == 'sensitivity':
        base = [t for t in ticks_in][:c] if (mode == 'sensitivity') else []
        rest = c - len(base)
        uni = list(a + (b - a) * (np.arange(rest) + 0.5) / rest) if rest > 0 else []
        return sorted(base + uni)
    if c <= len(ticks_in):
        idx = np.round(np.linspace(0, len(ticks_in) - 1, c)).astype(int)
        return sorted(ticks_in[i] for i in idx)
    out_ = list(ticks_in)
    extra = c - len(ticks_in)
    idx = np.floor((np.arange(extra) + 0.5) * len(ticks_in) / extra).astype(int) if extra <= len(ticks_in) \
        else np.arange(extra) % len(ticks_in)
    for i in idx: out_.append(ticks_in[i])
    return sorted(out_)

def reconstruct(g, m):
    N = RISK[g]; n = NSIZE[g]; S = 1.0; E, C = [], []; log = []
    end_t = m['end_t']
    for k in range(len(RT) - 1):
        a, b = RT[k], RT[k + 1]
        dr = [d for d in m['drops'] if a <= d['t'] < b]
        tk = [t['t'] for t in m['ticks'] if a <= t['t'] < b]
        target = N[k + 1]
        best = None
        for c in range(0, n + 1):
            cens = place(tk, c, a, min(b, end_t) if k == len(RT) - 2 else b)
            n1, S1, ev, ce = simulate(n, dr, cens, S)
            # last interval: remaining participants must be censored by curve end (display risk 0 at 36)
            score = (abs(n1 - target), abs(c - len(tk)))
            if best is None or score < best[0]: best = (score, c, n1, S1, ev, ce)
        score, c, n1, S1, ev, ce = best
        if k == len(RT) - 2 and n1 > 0:
            ce = ce + [max(tk) if tk else end_t] * n1; n1 = 0
        log.append({'interval': [a, b], 'n_start': n, 'n_end_recon': n1, 'n_end_table': target, 'events': len(ev),
                    'censored': len(ce), 'visible_ticks': len(tk), 'drops': len(dr)})
        E += ev; C += ce; n, S = n1, S1
    return E, C, log

res = {}
rows = []
for g in 'AB':
    m = measure(g)
    E, C, log = reconstruct(g, m)
    assert len(E) + len(C) == NSIZE[g], (g, len(E), len(C))
    rows += [(g, round(t, 4), 1) for t in E] + [(g, round(t, 4), 0) for t in C]
    res[g] = {'measure': m, 'log': log, 'n_events': len(E), 'n_cens': len(C)}
    print(g, 'events', len(E), 'cens', len(C), 'occluded cols', m['occluded_cols'], 'mono viol', m['monotonic_violations'])
    for l in log: print('  ', l)
fn = 'ipd.csv' if mode == 'primary' else 'sensitivity.csv'
tmp = f'{out}/.{fn}.tmp'
with open(tmp, 'w') as f:
    f.write('group,observed_time,event\n')
    for g, t, e in sorted(rows, key=lambda z: (z[0], z[1], -z[2])): f.write(f'{g},{t},{e}\n')
os.replace(tmp, f'{out}/{fn}')
json.dump(res, open(f'{out}/measurements_{mode}.json', 'w'), indent=1)
