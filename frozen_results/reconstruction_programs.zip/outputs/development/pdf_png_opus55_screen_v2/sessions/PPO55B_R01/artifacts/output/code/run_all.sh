#!/bin/sh
# Usage: sh output/code/run_all.sh [figure_path] [outdir]   (run from the work directory)
FIG=${1:-../input/figure.png}; OUT=${2:-output}
D=$(dirname "$0")
python3 "$D/extract.py" "$FIG" "$OUT" && python3 "$D/reconstruct.py" "$OUT" primary && \
python3 "$D/reconstruct.py" "$OUT" sensitivity && python3 "$D/checks.py" "$OUT"
