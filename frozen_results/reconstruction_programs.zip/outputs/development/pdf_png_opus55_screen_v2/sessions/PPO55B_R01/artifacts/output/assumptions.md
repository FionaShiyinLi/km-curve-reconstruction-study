# Reconstruction assumptions and limitations

**Inputs used:** `../input/figure.png` (raster, 1800x1350) and `../input/manifest.json` (n = 100 per arm, months, seed 452996545). The manifest gives no arm-specific event totals, so that check is marked unavailable. That absence was not read as zero events. The number-at-risk table (times 0, 6, ..., 36) was read visually from the figure: A 100/72/50/32/21/9/0 and B 100/81/59/47/38/11/0. The digits are clearly rendered, but they are still a manual reading.

**Calibration** (`code/extract.py`): the tick marks on the x axis (0-36 by 6) and y axis (0-1 by 0.2) were located from dark pixels. Both linear fits have zero residual (40 px/month; 750 px per unit of survival). The curve lines are about 4 px thick. Survival is read at the line centre (the lower edge minus 1.5 px). At time 0 the line is at exactly 1.0 for both arms. No global rescaling, reciprocal correction or running-minimum correction was applied; after the occlusion fix below, one residual monotonicity reversal in arm A is detected and reported but not corrected.

**Curve measurement** (`code/reconstruct.py`): arms were separated by RGB colour (blue = A, orange = B). For each column, the level is the lowest pixel row belonging to a horizontal run of at least 5 px. A drop is recorded when the level increases by 3 px or more; drops no more than 3 columns (0.075 months) apart were merged as one split riser. The drop time is the riser centre.
- **Occlusion:** arm A is hidden under arm B in 25 columns within the first 2 months. There, A takes B's level only if it lies between A's own previous and next visible levels; otherwise A's last level is carried forward. The number of events is constrained by A's own visible levels. Drop times in these columns are uncertain by about 0.1-0.2 months (for example, A's first two events are both placed at 0.30 months).

**Events:** at each drop, d = round(n_risk x (1 - S_measured_after / S_reconstructed_before)), with d = 0 allowed. Because the rounding is against the reconstructed curve, a sub-event fragment carries forward instead of being forced to d = 1. Multi-event drops (for example, B at about 26.2 months and A at about 12.2 months) receive several tied events. No drop was assumed to be a single event.

**Censoring:**
- **Tick detection:** a tick is a column with pixels at least 5 px below and at least 9 px above the line edge. A tick at a riser is detected by pixels at least 8 px above the highest level in the preceding 8 columns.
- **How many censorings, and where:** within each risk-table interval, the number censored is the value that makes the reconstructed number at risk equal the table. Visible ticks each receive one censoring. Extra censorings (A: 1 in 24-30 and 1 in 30-36; B: 5 in 24-30 and 1 in 0-6) are **assumed** to be tick multiplicity: they are stacked on evenly spaced visible ticks in the same interval.
- **Ties and the last interval:** events come before censorings at tied times. The displayed risk of 0 at 36 months is met by censoring everyone remaining at or before the end of the curve (A 35.21, B 35.86 months); no record is placed at 36.
- **What the figure cannot identify:** tick visibility does not identify tick multiplicity. The flat tails do not identify the censoring distribution beyond the ticks.

**Result:** A has 74 events and 26 censorings; B has 63 events and 37 censorings. All risk-table counts are reproduced exactly (records with observed_time >= t). The curve checks are in `checks.json`, computed from the reloaded CSV with a right-continuous Kaplan–Meier (KM) estimate.
- **Tolerance:** a check passes if |residual| <= 0.006 (about 4.5 px: 1-px resolution plus antialiasing), or if the reconstruction falls within the measured range over ±2 columns (±0.05 months, the uncertainty in drop timing).
- **Two checks pass only by the ±2-column rule:** A at 10.5 months and B at 3 months each sit next to a drop and have a pointwise residual of about 0.011.
- **Tail:** B's tail is 0.003 above the measured curve, within tolerance.

**Sensitivity** (`sensitivity.csv`, one alternative): extra censorings are spread uniformly over each risk interval instead of stacked on ticks. Over the common supported horizon of 35 months:
- A: S(35) and restricted mean survival time (RMST) are unchanged (0.198; RMST 15.72 months).
- B: S(35) is 0.282 (primary) vs 0.282 (sensitivity), and RMST is 19.68 vs 19.68 months.

This is a single alternative. It is not a confidence interval or a bound on reconstruction error.

**Limitations:**
- Timing is at raster resolution (about 0.025 months).
- Drop times under occlusion (A, 0-2 months) are uncertain.
- The allocation of tick multiplicity is assumed.
- A few censor ticks at risers may be missed or falsely detected. An example is the B tick at 1.41 months, which coincides with a riser.
- Three primary corrections were made after the first complete file; the task allows two. The fixes were a false early drop in A from the occlusion fill, missed or false ticks at risers, and riser fragments that had been forced to one event each. No counting convention or tolerance was changed to obtain a pass.

**Reproduce:** from the work directory, run `sh output/code/run_all.sh ../input/figure.png output`.
