# 已保存重建程序的提取策略审计

## 结论

本次审计覆盖论文相关的全部 **246 次正式登记**，其中 **240 次有完整重建记录**。
完整结果中，**104 次采用原生路径解析，136 次采用像素提取，0 次采用混合策略**。
另外 6 次没有完整结果，保留为不可评价，未强行按零散代码判定最终策略。
这些是执行次数，包含重复运行和补跑，不能当作新的独立数据集数量。

原生 PDF 的 104 次完整运行均直接读取曲线绘图路径；104 次 PNG300 运行和
32 次 image-only PDF 运行均从图像像素提取曲线。该结果为“模型实际利用了原生
PDF 中的曲线坐标信息”提供直接程序证据。它不能独立证明路径解析本身的因果效应，
因为本项目中曲线提取策略与输入格式完全对应。

survminer 条件下的 **16/16 次原生 PDF 运行仍采用路径解析**。因此，其误差上升
不能解释为模型改用了像素提取。更具体的线索是：保存坐标精度、轴标定以及删失符号
位置解释发生了变化；误差最大的 3 次运行均未统一校正删失符号文本框中心的水平偏移。
这一解释同时得到源代码、保存日志和既有重建记录的支持，但仍属于事后机制分析。

## 策略汇总

| 实验与输入 | 登记次数 | 完整结果 | 路径解析 | 像素提取 | 混合 | 不可评价 |
|---|---:|---:|---:|---:|---:|---:|
| 原始队列：原生 PDF | 40 | 40 | 40 | 0 | 0 | 0 |
| 原始队列：PNG300 | 41 | 40 | 0 | 40 | 0 | 1 |
| 新增独立队列：原生 PDF | 49 | 48 | 48 | 0 | 0 | 1 |
| 新增独立队列：PNG300 | 51 | 48 | 0 | 48 | 0 | 3 |
| Image-only PDF | 32 | 32 | 0 | 32 | 0 | 0 |
| Survminer：原生 PDF | 16 | 16 | 16 | 0 | 0 | 0 |
| Survminer：PNG300 | 17 | 16 | 0 | 16 | 0 | 1 |
| **合计** | **246** | **240** | **104** | **136** | **0** | **6** |

登记次数同时保留失败原运行及其单独登记的补跑。完整结果按主运行和预选重复运行
分别为：原始队列 64 + 16，新增队列（含运输故障补跑）64 + 32，两个探索实验
各 32。逐次表中标明主运行、重复、补跑及新增队列主分析资格，没有更改原分析规则。

分类针对**最终曲线坐标的来源**：PDF 内容流或绘图对象是路径解析；图像颜色或强度
是像素提取；只有两者共同生成最终曲线坐标才算混合。读取 PDF 风险表文字、读取
删失符号、生成预览图或对输出进行像素校验，均不单独改变曲线策略分类。
例如 RP32_R075 直接解析 PDF 内容流；部分 image-only PDF 程序直接取出 PDF
内嵌图片再分割颜色，仍属于像素提取。

## 同一组 16 个数据集的模板比较

既有正式评分显示，原生 PDF 的平均 TAAE 从原模板的 **0.00003145 个百分点**
上升到 survminer 模板的 **0.00092597 个百分点**。这里比较的是同一组 16 个
原始数据集，而非原队列全部 32 个数据集。绝对误差仍很小；survminer PNG300
的平均 TAAE 为 0.140611 个百分点。上述数值来自原封存评分，没有重新评分。

**坐标与时间精度。** 16 个替代模板 PDF 的曲线横坐标均落在 0.001 PDF point
网格上，并与 1/256 point 网格经三位小数保存后的形式一致；原模板不具有这种
统一的横坐标网格。生成程序使用 `survminer::ggsurvplot` 和 `cairo_pdf`
（`scripts/main_study/render_pdf_png300_survminer_template.R` 第 32–40、66–68 行）。
与参考记录按事件时间排序后比较，每个替代模板数据集的最大事件时间差为
0.000307–0.000359 个月，原模板对应范围为 0.00000520–0.00005496 个月。
这是保存坐标、轴标定和最终输出舍入共同作用的观察结果，不能仅凭网格形式
把全部误差归因于某一个绘图软件操作。

**删失符号位置。** 独立按轴刻度标定后，32 个替代模板组别的原始删失符号
文本框中心，相对参考删失时间的中位偏移为 −0.023175 至 −0.022850 个月。
符号文本框中心并不直接等于其应有的删失位置。11 个程序通过图例、曲线终点或
符号所在的平台约束进行了统一水平校正；5 个未统一校正，其中 1 个将符号限制在
相应平台内，另 1 个进行了局部位置移动。

**时间差与生存概率差分开检查。** 按累计事件数匹配曲线下降后的生存概率，并在
重建时间不超过 24 个月的范围内比较：10/16 个数据集的两组生存概率均与参考一致
（容差为生存概率 1e−12）；另 3 个最大偏差不超过 0.000215 个百分点；剩余 3 个
同时具有较大的 TAAE 和持续的生存概率偏差：

| 运行 | 数据集 | 每组人数 | TAAE（百分点） | 最大匹配生存概率差（百分点） | 保存程序中的相关操作 |
|---|---|---:|---:|---:|---|
| PP32SV_R011 | PP32_S4_D01 | 1000 | 0.003655 | 0.005490 | 使用未校正的符号中心；允许一个标记分配 0 个或多个删失记录 |
| PP32SV_R020 | PP32_S3_D06 | 1000 | 0.003214 | 0.005464 | 使用未统一校正的符号中心；局部移动标记以满足风险表或事件顺序 |
| PP32SV_R025 | PP32_S4_D03 | 1000 | 0.003338 | 0.005059 | 使用未校正的符号中心；删除部分标记或增加其他标记的删失次数 |

R011 的保存检查显示，B 组有 5 个标记分配为 0 次删失，另有 5 个标记分配为
2 次删失。R025 的保存日志显示，18–24 个月内 A/B 组分别删去 1/2 个标记，
24–30 个月内又分别增加 1/2 次重复删失。R020 的保存日志记录了 6 和 30 个月
风险表边界的标记移动，以及 30 个月后的局部移到事件时间的操作；后者发生在
主要 24 个月评价窗口之外，不能据此解释窗口内的全部误差。
对应证据分别为该运行的 `checks.json`、`recon_log_primary.json` 和
`work/recon_info_primary.json`；程序行号详见 `template_source_review.json`。

这 3 次运行的事件总数、删失总数以及风险表吻合，并不保证所有事件发生前的风险
人数都完全一致。删失与事件的相对排序仍会改变曲线下降幅度。没有统一水平校正的
另外 2 个程序（R010、R026）每组仅 100 人，其生存概率在上述匹配检查中完全一致。
这个反例必须保留：符号偏移的影响可能与事件密度、符号位置和分配方法有关，不能写成
“不校正符号就一定造成明显误差”。

## 审计方法与可复核性

在连接逐次误差评分前，完成并保存曲线策略分类；分类哈希锁在连接评分后登记，
分类标签未因评分改变。审查者已经知道论文的总体结果，
因此不声称完全盲法。随后进行的模板、删失符号及误差对应检查明确为结果已知的
探索审查。通过既有、输出字节完全一致的重放证据定位最终程序链，并静态审查其
提取方法、本地依赖和相关源代码。未在本次审计中运行模型生成的重建程序。
这是一次结构化审查，并非两位审查者独立编码，也不是对每一行程序的动态跟踪。

验证 726 个脚本、240 个最终记录文件和 246 个登记封存文件，共 1212 个归档哈希；
另核对 246 个登记及分配输入的绑定、240 个既有重放输出绑定、240 个封存评分映射。
所有评分文件与其原 `ANALYSIS_LOCK.json` 一致。针对模板进行的 64 个组别检查
（16 数据集 × 2 模板 × 2 组）只使用 observed time 和 event，未使用潜在真实
事件时间来评价结果。新计算的 32 组参考 KM 与原封存的 R 参考曲线一致；参考
记录及曲线也与原输入包封存哈希一致。所有输入和派生表哈希在审计锁中保存。

本次新增的诊断包括按顺序匹配的事件/删失时间差，以及相同累计事件数后的 KM
生存概率差。合并为同一下降的相邻事件，在合并后的累计事件数位置比较；时间与
概率的比较因此有各自明确的含义。它们不替代原 TAAE、RMST 或 Cox 评分。
5 项解析检查覆盖事件与删失同一时间、相邻事件合并、删失排序改变曲线、事件
总数不匹配和输入篡改拒绝。两次输出重建的一致性检查见 `FINAL_CHECKS.json`。

局限：策略与格式完全对应；替代模板运行时间及模型自行选择的重建方法也有变化。
模板仅包含原始队列中的 16 个数据集，不能增加独立样本。未随机分配校正方法，
未做统一算法下的渲染精度或符号位置干预，因此坐标精度和删失解释的相对贡献
仍未被因果分离。观察到的很小绝对误差也不意味着真实临床研究中能够同样精确。

## 文件与复现

- `run_strategies.csv`：246 次登记的分类、运行性质、现有 TAAE、脚本和行号证据。
- `strategy_counts.csv` / `strategy_table.md` / `strategy_table.tex`：汇总表及可插入论文的 LaTeX 表。
- `primary_strategy_accuracy.csv`：仅主运行的描述性误差；新增队列原分析与运输补跑分开。
  这是各格式完整输出的描述，不是论文成对差值分析的替代。
- `survminer_template_comparison.csv` / `template_table.md`：全部 16 个匹配数据集的对照。
- `survminer_arm_diagnostics.csv`：64 个组别的时间与生存概率诊断。
- `CLASSIFICATIONS.json` / `CLASSIFICATION_LOCK.json`：逐次曲线策略决定及连接评分前的分类锁。
  其中 `complete_primary_file` 表示完整最终记录文件；是否主运行以分配记录为准。
- `template_source_review.json`：16 个程序的轴标定、符号处理、输出精度与行号证据。
- `INPUT_LOCK.json` / `verification.json` / `AUDIT_LOCK.json`：输入、评分、复核证据及输出哈希。

在项目根目录运行：

```sh
source scripts/activate_environment.sh
python -m unittest tests.test_pdf_png300_extraction_strategy_audit
python scripts/main_study/audit_pdf_png300_extraction_strategies.py --output /private/tmp/km_strategy_audit_check
```

该命令读取现有归档并生成派生表；不调用模型，不执行保存的重建程序，不修改原数据、
官方评分、论文或 Overleaf。不可评价登记为 PP32B_R072、PP32SV_R023、RP32_R003、
RP32_R014、RP32_R064、RP32_R081，其单独登记的成功补跑计入完整输出。

## 可供后续论文整合的英文表述（尚未写入论文）

A retrospective audit of the saved programs showed that all 104 complete
native-PDF reconstructions extracted curve coordinates from PDF drawing paths
or content streams, whereas all 104 PNG300 and 32 image-only PDF reconstructions
used raster pixels. No complete reconstruction combined both sources for curve
coordinates. These counts include repeat and recovery runs and do not represent
additional independent datasets. All 16 native-PDF reconstructions under the
alternative plotting template retained path extraction. Their higher errors
therefore did not reflect a switch to raster extraction. Matched diagnostics
identified coarser saved coordinates and a displacement between censor-glyph
bounding-box centers and their intended positions. The three largest PDF errors
occurred in programs without a common horizontal correction for that displacement
and were accompanied by small persistent differences in KM survival levels.
Two smaller-sample programs without a common correction nevertheless recovered
the matched survival levels exactly, suggesting that any effects may depend
on event spacing and censor allocation. This result supports template-sensitive
coordinate and censor-mark interpretation as a mechanism hypothesis; the
retrospective audit did not isolate their causal contributions.
