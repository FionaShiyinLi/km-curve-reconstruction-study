| Experiment and input | Registrations | Complete outputs | Path parsing | Pixel extraction | Hybrid | Unevaluable |
|---|---:|---:|---:|---:|---:|---:|---:|
| Original cohort / native PDF | 40 | 40 | 40 | 0 | 0 | 0 |
| Original cohort / PNG300 | 41 | 40 | 0 | 40 | 0 | 1 |
| Independent replication / native PDF | 49 | 48 | 48 | 0 | 0 | 1 |
| Independent replication / PNG300 | 51 | 48 | 0 | 48 | 0 | 3 |
| Image-only PDF follow-up | 32 | 32 | 0 | 32 | 0 | 0 |
| Alternative template / native PDF | 16 | 16 | 16 | 0 | 0 | 0 |
| Alternative template / PNG300 | 17 | 16 | 0 | 16 | 0 | 1 |
| **Total** | **246** | **240** | **104** | **136** | **0** | **6** |
