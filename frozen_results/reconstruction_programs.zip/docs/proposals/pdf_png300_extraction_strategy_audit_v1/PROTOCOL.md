# Retrospective audit of saved extraction strategies

## Objective and scope

Classify how each retained PDF/PNG manuscript reconstruction obtained curve
coordinates, and examine whether the saved programs clarify the larger native-PDF
errors under the alternative survminer plotting template. This audit was requested
after the study results were known. It is an observational process audit, not a
randomized mechanism experiment or a new independent replication.

Include all 246 formal registrations from the original cohort (81, including
its repeat recovery), image-only PDF follow-up (32), alternative template (33,
including its startup recovery), and independent replication (100, including
startup and transport recoveries). Of these, 240 have complete participant files.
Preserve the six missing-output registrations in the run table, separately from
accuracy summaries. Development runs, the uniformly superseded eight-run batch,
and the separate task-validity study are outside this manuscript audit.

## Classification before linking individual scores

The reviewer knows the previously reported aggregate results. Source decisions
are recorded before joining individual-run accuracy scores; do not claim fully
blinded review. Verify saved source, participant-file, and admission hashes against
the original session seals. Use existing byte-identical replay evidence to identify
the final output-generating code chain; do not execute the model-written programs.

Classify **curve-coordinate extraction**, rather than filename or installed tools:

1. **Path parsing**: curve coordinates come from native PDF/SVG drawing objects
   or content-stream paths.
2. **Pixel segmentation**: curve coordinates come from raster pixel colors or
   intensities, including an embedded image extracted from an image-only PDF.
3. **Hybrid**: both native paths and raster measurements contribute to the
   curve coordinates in the final reconstruction (including different arm routes).
4. **Other/unclear**: evidence is insufficient for those three categories. A
   missing output or absent program is retained as unevaluable, not forced into a
   category.

Record text/risk-table extraction, censor-mark extraction, calibration, coordinate
rounding, and event-time adjustments separately. PDF previews and pixel-based
validation do not make native path extraction hybrid; PDF text extraction does
not make pixel curve extraction hybrid. Imports and unused fallback functions alone
are insufficient evidence. Source file hashes and line-numbered excerpts must
support every adjudication, including exceptions to automatic keyword screening.

## Summaries and targeted template review

Tabulate strategies by cohort/experiment, input format, and primary/repeat/recovery
status. All-run counts describe execution occasions, not independent datasets.
Summarize existing TAAE descriptively by strategy using primary assignments only;
keep retained-main and transport-completed replication views distinct. Do not fit
a causal model or perform a significance test of strategy effects: format, plotting
template, batch, model-selected algorithm, and strategy are not independently
assigned.

For all 16 native-PDF alternative-template programs, inspect calibration, numerical
precision, path selection, censor placement, and explicit adjustments to event
times. Compare each with its already available original-template primary result.
If the code indicates a numerical explanation, check it against saved intermediate
measurements or native input geometry using read-only calculations. Distinguish
confirmed operations, quantitative consistency, and untested causal explanations.
Do not tune, repair, replace, or rescore any reconstruction.

## Outputs and acceptance

Produce a per-registration CSV with source evidence, a grouped strategy table,
a 16-dataset template comparison, a concise report, and verification checks.
Record input and output hashes. Existing sources, raw data, frozen scores,
manuscript text, and Overleaf remain unchanged during this audit. There are no
new model calls, reconstruction runs, or research-data substitutions.
