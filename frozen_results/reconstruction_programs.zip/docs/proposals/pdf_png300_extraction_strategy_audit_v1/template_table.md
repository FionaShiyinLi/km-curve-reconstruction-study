| Native-PDF run | Dataset | Participants per arm | Censor-mark position treatment | Original TAAE (pp) | Alternative TAAE (pp) | Maximum matched-height difference (pp) |
|---|---|---:|---|---:|---:|---:|
| PP32SV_R001 | PP32_S2_D03 | 100 | Legend offset | 0.000064 | 0.000353 | 0.000000 |
| PP32SV_R004 | PP32_S3_D03 | 1000 | Curve-end offset | 0.000006 | 0.000378 | 0.000107 |
| PP32SV_R005 | PP32_S4_D08 | 1000 | Plateau-based offset | 0.000008 | 0.000363 | 0.000215 |
| PP32SV_R008 | PP32_S1_D02 | 100 | Curve-end offset | 0.000071 | 0.000330 | 0.000000 |
| PP32SV_R009 | PP32_S2_D02 | 100 | Curve-end offset | 0.000074 | 0.000345 | 0.000000 |
| PP32SV_R010 | PP32_S1_D07 | 100 | Raw center | 0.000006 | 0.000383 | 0.000000 |
| PP32SV_R011 | PP32_S4_D01 | 1000 | Raw center | 0.000005 | 0.003655 | 0.005490 |
| PP32SV_R012 | PP32_S3_D02 | 1000 | Legend offset | 0.000006 | 0.000365 | 0.000130 |
| PP32SV_R017 | PP32_S1_D01 | 100 | Curve-end offset | 0.000082 | 0.000398 | 0.000000 |
| PP32SV_R018 | PP32_S4_D02 | 1000 | Plateau-based offset | 0.000005 | 0.000343 | 0.000000 |
| PP32SV_R020 | PP32_S3_D06 | 1000 | Raw center; local moves | 0.000009 | 0.003214 | 0.005464 |
| PP32SV_R022 | PP32_S2_D06 | 100 | Curve-end offset | 0.000075 | 0.000377 | 0.000000 |
| PP32SV_R025 | PP32_S4_D03 | 1000 | Raw center | 0.000009 | 0.003338 | 0.005059 |
| PP32SV_R026 | PP32_S2_D01 | 100 | Raw center; plateau clamp | 0.000067 | 0.000314 | 0.000000 |
| PP32SV_R027 | PP32_S1_D04 | 100 | Fixed 0.023-month offset | 0.000009 | 0.000334 | 0.000000 |
| PP32SV_R029 | PP32_S3_D07 | 1000 | Legend offset | 0.000006 | 0.000327 | 0.000000 |
