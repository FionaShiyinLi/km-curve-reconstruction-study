# Approved budget amendment and uniform restart

Approved by the user on 2026-09-23, before any new-cohort model call or formal
accuracy scoring. The initial eight sessions were examined for execution,
identity, usage and structural completeness. R003 and R007 reached the 4,000,000
conservative token reservation ceiling; R005 had an upstream EOF. All eight
produced structurally complete two-arm CSVs. This amendment was informed by
operational evidence, not reference-based reconstruction accuracy.

## New execution cohort

`pdf_png300_32_budget_v2` uses the same 32 datasets, 64 input figures, order,
code seeds and repeat subset as the frozen input package. The session IDs are
PP32B_R001 through PP32B_R080. All 80 sessions run from fresh isolated contexts,
including all eight initial assignments, irrespective of their earlier status.
The original inputs are reused by hash; no new simulated data are generated.

The single-session cumulative token reservation ceiling changes from 4,000,000
to 16,000,000; the API-equivalent accounting ceiling changes from $100 to $200.
Across 80 sessions these ceilings are 1,280,000,000 and $16,000 respectively.
They are conservative accounting limits, not expected consumption or permission
to spend money. Extra paid spend remains $0, subscription-only access is verified
before every admission, and the existing five-hour capacity buffer remains 20%.
The request limit remains 32, maximum output per request 128,000, and wall time
3,600 seconds. Reservations are not refunded. P4, medium effort, model/client,
tools, isolation, correction rules, scoring, 16 repeat sessions and checkpoint
policy remain unchanged. The rendered prompt's appended session-limit values
necessarily change to state the amended limits; P4 itself does not change.

With the frozen $4/$20 accounting constants, 16 million reserved tokens and at
most 32 requests each reserving 128,000 output tokens imply an API-equivalent
upper bound of $177.152; $200 therefore does not impose an earlier independent
ceiling. These constants are bookkeeping conventions, not current price claims.

## Analysis and evidence

The old eight remain immutable in `outputs/evaluation/pdf_png300_32_v1/execution`.
`INITIAL_BATCH.json` binds all eight admission and result locks. All eight are
uniformly excluded from the new primary analysis, including successful attempts.
They are described as the initial execution batch superseded by this amendment,
not as a prospectively planned development sample. Historical development-screen
results and the medium selection are unchanged; no claim is made that medium was
reselected or proven optimal under the expanded budget.

The main analysis uses only the new 64 primary and 16 repeat assignments. A new
failure cannot be replaced by an old successful result. The old eight do not count
as the 16 repeat sessions. If old/new comparisons are later reported, they are
exploratory workflow sensitivity descriptions, not isolated causal budget effects.
Report 88 execution records across the initial and amended formal cohorts, in
addition to the separate pre-existing development screen. No results are selected
according to accuracy. Reuse the original statistical implementation unchanged.

Connection interruption and resource truncation remain distinct outcomes.
There are no automatic retries, replacement sessions or repair prompts. An
unexpected operational issue pauses the schedule for retain-only review. Normal
checkpoints remain 8,16,24,32,40,48,56,64,80. Existing approval covers the full new
80-session cohort; checkpoint reviews do not require renewed user authorization
unless a further scientific/resource change or another unresolved decision is needed.

## Reproduction and progress

Activate `scripts/activate_environment.sh`. The additive entry point is
`scripts/main_study/run_pdf_png300_budget_amendment.py`: `prepare` writes the
derived specification, `freeze` binds passing offline validation, `check` verifies
both cohorts without model calls, `supervise --authorization <receipt>` runs the
authorized prefix, `retain` preserves interruptions, and `score` requires all 80
new locked sessions. Frozen historical code and config are never edited.

A separate local read-only progress server counts new locked results out of 80,
shows current admission/request reservations, and labels checkpoints and errors.
It does not read reference accuracy, admit sessions, review exceptions or change
study state. The detached watcher owns completion/failure notification; a progress
page and a notification do not themselves resume an assistant conversation.
