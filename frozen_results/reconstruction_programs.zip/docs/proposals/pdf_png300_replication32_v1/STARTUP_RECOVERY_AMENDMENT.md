# R003: network failure before model startup; one authorized recovery

The user requested: “恢复原版界面并显示具体暂停原因；R003 要补跑，记录一项‘模型启动前网络故障’的处理修订”.
This is an additive operational amendment made after R001 and R002 completed,
but before any R003 model response or reconstruction existed. No reconstruction
accuracy is examined to select this recovery.

## Evidence and narrow exception

RP32_R003 was admitted at 2026-09-28T05:25:45.976641+00:00. The subsequent
subscription-usage check inside gateway construction raised a network timeout
at 05:25:58.947577+00:00. Its retained session directory contains only the
workspace receipt, configuration and prompt. There is no worker request,
process-launch receipt, initial model context or model-request journal. The
frozen control flow fails before creation of the local gateway or model worker.
These facts, together with the traceback and file hashes, establish zero model
requests for this specific interrupted registration.

Seal the original RP32_R003 as an infrastructure interruption without execution.
Do not delete its admission, refund its reservation, overwrite its files, or
reopen that conversation. Authorize exactly one fresh session RP32_R003R1 in a
separate recovery directory, immediately before the still-unadmitted R004.
Use the identical figure, public manifest, code seed, prompt, model, effort,
runtime, per-session budget and reconstruction instructions. This does not
authorize a general retry policy or replacements for subsequent failures.

The original 96 assignments remain frozen. One extra registration is authorized,
so the administrative maximum is 97 registrations with at most 96 model-started
sessions. The original unused reservation is retained and one separate session
reservation is added; extra paid spend remains $0. All other failures still pause
for review. The earlier failed login preflight consumed no registration.

## Analysis and disclosure

Use RP32_R003R1 once for the original R003 dataset/format/primary-assignment slot.
Do not count the startup interruption as a second reconstruction or increase the
32-dataset, 64-primary-session or 32-repeat-session denominators. Preserve both
the original 96-assignment scoring manifest and a clearly amended manifest;
the latter substitutes this single authorized recovery. Include a sensitivity
analysis of the original assignments with R003 left unscorable, using the same
frozen scorer. No error-based selection between the two versions is allowed.
Both reports explicitly disclose the exception and actual execution times.
The new-32 primary analysis, historical pooling, bootstrap seeds and repeat
comparisons are unchanged. Saved-code and method-adherence audit remain required.

## Interface and pause controls

Restore the previous dashboard style with a 96-slot grid, primary/repeat counts,
current session and subscription information, and explicit interruption reasons.
Keep the interrupted original registration visible separately from the 96 planned
result slots. A stopped, unsealed attempt is labelled interrupted; its elapsed
time stops at the recorded interruption, rather than increasing indefinitely.

“Pause after this session” prevents subsequent admissions while allowing the
current session to finish normally. “Continue” is available only when the same
live controller has acknowledged that voluntary pause, and causes fresh lock,
sign-in and capacity checks. It cannot override an operational failure, replay a
completed session, or restart a dead controller. The existing hard STOP keeps
its immediate-interruption semantics. Closing the page does not stop the study.

The original design, input, execution and analysis locks remain untouched.
STARTUP_RECOVERY_LOCK.json binds this amendment, recovery assignment, retained
evidence, new controller, restored dashboard and passing offline tests before
RP32_R003R1 is admitted. The new dashboard is separate from the originally locked
simplified page; neither the experiment nor the old study is edited to change its
appearance. The execution watcher and local notification mode remain unchanged.
