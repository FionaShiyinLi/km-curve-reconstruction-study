# One additional attempt after transport failure without reconstructed data

## Timing, purpose and authorization

The user authorized: “写好这项修订，再启动补跑”. This is an amendment made
after all 96 planned sessions and their numerical analyses were completed, and
before any recovery session under this amendment. It is not a prospective part
of the original confirmatory protocol. Selection uses operational records and
file availability, not reconstruction accuracy, effect estimates or significance.
Previously available results cannot be treated as blinded to the investigators.

The purpose is to examine how the format comparison changes when missing outputs
following documented transport interruptions are given one additional opportunity.
This does not establish performance under uninterrupted service: transport
interruptions may depend on request duration or task difficulty, and a new model
session is a new stochastic realization.

## Eligibility and fixed scope

Audit every original scheduled session using its sealed records. Eligibility
requires an initiated model session, failed execution, confirmed child-process
termination, a passed isolation probe, and no `output/ipd.csv`. Transport evidence
must be either (a) a final upstream request explicitly marked
`service_transport_failure` with `TimeoutError` or `BrokenPipeError`, or (b) a
client terminal API error exactly reporting `Request timed out`, with process exit
1 and a forwarded request marked `local_cancellation` / `TimeoutError` /
`host_stopped_attempt`. The latter distinguishes a client timeout followed by
host cleanup from an unsupported inference that every cancellation is a network
failure. It does not identify which network or service component caused the timeout.
Exclude sessions with any saved IPD, partial or complete, to avoid
discarding an existing reconstruction in favor of another. Exclude other kinds of
failure, zero-start interruptions, and prior recovery sessions. This rule applies
uniformly to the now-completed schedule; it is not an ongoing retry policy.

Exactly three originals qualify: RP32_R014 (primary, request 3 client timeout
with local cancellation during cleanup), RP32_R064
(primary, request 7 timeout), and RP32_R081 (repeat, request 5 broken pipe). Run
RP32_R014R1, RP32_R064R1, and RP32_R081R1 once each, in that order. RP32_R084 is
excluded because its IPD was already saved. The earlier zero-start R003 exception
remains separate and unchanged. The eligible set and full screening record are
hash-locked before recovery admission.

## Execution and stopping

Use the same assigned figure, public manifest, code seed, prompt, Opus 5.5 medium,
installed runtime, isolation, and per-session limits: 60 minutes, 32 requests,
16 million reserved tokens, and $200 API-equivalent resource accounting. This is
not paid-spend authorization: extra paid spend remains $0. Use fresh conversations
and workspaces without previous responses, partial code, reference data or scores.
The model service itself is stochastic and cannot be reproduced by a code seed.

Run sequentially after the original 96-session controller has exited. Hold the
original execution locks as well as the recovery lock to prevent concurrency.
Check subscription access and the existing 20% five-hour capacity buffer before
each admission. Add exactly three reservations; refund none. The combined maximum
is 100 registrations: 96 original, one earlier R003 recovery, and these three.
No recovery of a recovery, transport retry, output repair or replacement is
authorized. A failed or incomplete recovery is retained and pauses for review;
only remaining unadmitted recovery slots may subsequently continue. Record actual
times and preserve all original and recovery logs, outputs and locks.

## Analysis and reporting

Keep the existing 96-slot analysis (including the prior R003 amendment) and its
original-assignment sensitivity analysis unchanged. Keep all original failures
in execution-failure counts. Do not overwrite their CSVs, manifests or scores.

Create a separate supplementary 96-slot manifest. For the three prespecified slots,
use the corresponding recovery once, with the original dataset, format and
primary/repeat role. Preserve both session identities and timestamps in a mapping.
Apply the original arm-eligibility rules even if a recovery has an operational
failure; unavailable outputs remain missing. Never choose between realizations
by accuracy, plausibility, instruction adherence or statistical significance.

Use the existing frozen scorer, endpoint, bootstrap seeds, scenario weights and
historical pooling. Independently report the new-32 estimate, pooled secondary
estimate, missing-output bounds and repeat discrepancies. Report original and
recovery-augmented results separately, whether or not conclusions agree. Retain
32 independent replication datasets, 64 primary slots and 32 repeat slots;
additional attempts do not increase the independent sample size. The recovery of
R081 affects repeatability analysis, not a new independent observation.

Any directional support in this supplementary analysis is conditional on this
post-start recovery amendment; it does not retroactively satisfy the original
confirmatory stopping or missingness rules. The original and supplementary
results require saved-code replay, instruction-adherence review and review of
execution-period gaps. The dashboard must identify recovery work separately from
the completed 96-slot study. No manuscript or Overleaf claims are changed here.
