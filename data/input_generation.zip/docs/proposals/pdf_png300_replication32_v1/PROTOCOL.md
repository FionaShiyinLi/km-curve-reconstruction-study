# Independent 32-dataset replication of PDF versus PNG300

This prospective replication implements the user's 2026-09-27 decision. The
original 32-dataset results are already known. Only the **new 32 datasets** form
the confirmatory sample; the original plus new 64-dataset analysis is secondary.
No replication outcomes may be inspected before the design and analysis freeze.

## Scientific design

Generate eight new independent datasets in each original scenario: n=100 or
1,000 per arm crossed with proportional or crossing hazards. Preserve the
original event-time, recruitment, independent dropout, administrative censoring,
24-month evaluation window, risk-table and censor-mark rules, original plotting
template, and direct 300-dpi rendering. Use the existing generator and scorer.
Reserve separate L'Ecuyer-CMRG streams and all order, code, repeat-selection and
analysis seeds before generation. Compare streams and canonical observed records
with historical studies. Retain every dataset: no selection or redraw according
to appearance, difficulty or reconstruction results.

## Assignments and repeatability

There are 64 primary sessions, one fresh session per dataset and format. Eight
blocks each contain one dataset per scenario. Within each block, randomize the
order of the four datasets and run each PDF/PNG300 pair consecutively. Within
each scenario, exactly four pairs use PDF first and four use PNG300 first.
Run both formats during the same replication campaign; record actual times and
interruptions. A quota interruption can still separate a pair, and must be
reported rather than described as simultaneous execution.

Before generating data, randomly select four datasets per scenario (16 total)
for one additional session per format. These 32 repeat sessions follow the 64
primary sessions, in four scenario-balanced blocks, with two PDF-first and two
PNG-first repeat pairs per scenario. The total is 96 sessions. Repeats do not
replace or average primary results and do not increase the independent dataset
denominator. Report direct first-versus-repeat curve discrepancies and changes
in error against the reference separately. Later repeat timing remains a caveat.

## Workflow and stopping rules

Preserve Opus 5.5 medium, P4, installed general-purpose tools, fresh isolated
sessions, and the original amended ceilings: 60 minutes, 32 requests, 16 million
reserved tokens and $200 API-equivalent resource accounting per session. This
accounting is not permission to spend money: extra paid spend remains $0 and
subscription-only access is required. Concurrency is one. The model chooses its
reconstruction algorithm, as in the original study. The prompt's two-revision
limit remains an instruction evaluated by post-run audit, not a newly enforced
algorithmic cap. Adding a different cap would change the replicated workflow.

Stop after exactly 96 admitted attempts, or pause earlier for user stop, failed
capacity/authentication checks, changed frozen files, interrupted processes,
malformed or incomplete delivery, or an operational failure. Check included
capacity before each admission, preserving the existing 20% five-hour buffer.
No accuracy-based early stopping, sample-size expansion, transport retries,
automatic replacement, conversation restart or reservation refund is allowed.
All admitted failures and deviations are retained. Resume only the unadmitted
suffix after resolving and documenting an operational interruption. Failed
sessions require an explicit retain-only review; they are never silently rerun.
The execution controller may continue after normal sealed deliveries without
examining reference accuracy. Progress reports contain operational counts only.

## Locked analysis

Primary outcome: time-averaged absolute KM error over 0–24 months, averaged across
arms, against the original *observed* records. Primary contrast: PDF minus PNG300,
with equal weight for the four scenarios. The independent unit is the dataset.
Report the new 32 datasets first, using the existing 10,000-draw bootstrap that
resamples whole datasets within scenario. A negative difference with the upper
two-sided 95% percentile confidence limit below zero supports replication of the
directional finding. This is one primary contrast; no clinical-importance or
equivalence threshold is claimed. Report all secondary and subgroup outcomes
descriptively, without confirmatory interaction claims.

Complete records remain scored even if instruction adherence is imperfect.
Use the existing scorer's arm eligibility, unsupported-tail and Cox-failure
rules; show missingness, all assigned pair states and [0,1] primary-error bounds.
Missing pairs are not zero errors and repeats never substitute for them. An
unavailable primary interval or incomplete primary pairs prevents an unqualified
claim of confirmation; present the available-pair estimate and bounds explicitly.
Unadmitted work is pending, not a failed reconstruction; scoring refuses a
nonterminal schedule. Final scientific reporting additionally requires the
saved-code replay and instruction-adherence audit.

Then report the original 32 plus new 32 primary datasets, with unique dataset
identities and equal weights for cohort and scenario. Resample eight datasets
within each of the eight cohort-by-scenario strata, preserving paired formats.
Use 10,000 draws and a separate reserved seed. Report original and replication
cohort estimates alongside the pooled estimate. The pooled analysis is secondary
and does not retroactively make the original exploratory extensions confirmatory.
Only frozen original primary scores enter; old repeats, image-only PDFs and the
alternative-template runs are excluded from the pooled primary denominator.

## Freeze, reproducibility and progress

`DESIGN_LOCK.json` binds this protocol, generation rules, assignments, seeds,
analysis code, execution code and original primary inputs to the pooled analysis
before data generation. `INPUT_LOCK.json` binds generated records and paired
figures. `EXECUTION_LOCK.json` additionally binds passing offline verification,
runtime identity and exact rendered session prompts before any provider call.
Original inputs, scores, manuscript and earlier locks remain untouched.

The read-only local progress page shows primary sessions
(0/64), repeats (0/32), terminal counts, completed primary
pairs (0/32), active request/time counters, failures, and controller health.
Input preparation has a separate terminal progress bar; the status endpoint also
records preparation and complete-output counts.
Completion of execution is separate from statistical analysis and method audit.
The detached monitor saves a terminal report; it does not guarantee an automatic
return to this chat. No manuscript result is changed until actual results exist.
