# Follow-up conditions for the PDF versus PNG300 study: no censoring marks and a resolution gradient

Status (4 October 2026): inputs prepared, verified and hash-locked; **no model runs have been made**. Launching the runs below requires the user's authorization, the pinned execution environment, and budget under the current development amendment. This document fixes the design and analysis before any run so that the follow-up can be described as protocol-fixed; it is not a public registration.

## Why

The review of the manuscript identified two gaps that the existing data cannot close. First, the study has one raster condition (300 dpi, lossless), so it cannot describe how reconstruction error depends on resolution or compression, which is what the practical question about screenshots needs. Second, the paper's central explanation (a vector figure with per-participant censoring marks is, up to tie ordering, a complete record of the observed data) has not been tested by removing the marks. The deterministic decomposition in `outputs/evaluation/pdf_png300_guyot_exact_v1/` answers the second question for the Guyot algorithm; this follow-up answers both for the LLM workflow.

## Inputs (prepared)

`outputs/evaluation/pdf_png300_followup_inputs_v1/` holds, for each of the 32 original-cohort datasets (`pdf_png300_32_v1`), five files produced by `scripts/main_study/prepare_pdf_png300_followup_inputs.py`:

| Condition | File | Content |
|---|---|---|
| nomark-PDF | `nomark/<dataset>/figure.pdf` | native PDF, frozen ReportLab template, `marks_shown=False`; risk table and curves unchanged |
| nomark-PNG300 | `nomark/<dataset>/figure.png` | the nomark PDF rendered at 300 dpi (1,800 x 1,350) |
| res150 | `res150/<dataset>/figure.png` | the locked primary PDF rendered at 150 dpi (900 x 675) |
| res100 | `res100/<dataset>/figure.png` | the locked primary PDF rendered at 100 dpi (600 x 450) |
| jpeg100 | `jpeg100/<dataset>/figure.jpg` | the 100-dpi render saved as JPEG, quality 75, 4:2:0 |

Renderer: Poppler `pdftoppm` 22.02.0 with the primary study's flags (`-aa yes -aaVector yes -thinlinemode none`) plus explicit `-scale-to-x/-scale-to-y`. Before writing anything the script re-rendered every locked primary PDF at 300 dpi with these flags and asserted pixel identity with the locked primary PNG300 for all 32 datasets, so the renderer is interchangeable with the pinned build at the pixel level. Every file's SHA-256 and the pixel hash of every PNG are in `MANIFEST.json`; `INPUT_LOCK.json` carries the manifest hash. Pixel scales: 0.025 months and 0.133 pp per pixel at 300 dpi; 0.05 months and 0.267 pp at 150 dpi; 0.075 months and 0.4 pp at 100 dpi.

## Runs (not started)

One primary session per dataset and condition: 32 x 5 = 160 sessions. Same model identifier (`claude-opus-5-5`), medium effort, P4 prompt, isolation profile, resource limits (60 min, 32 requests, 16M reserved tokens, no paid spend) and session-manifest format as `pdf_png300_32_budget_v2`. The model receives only the assigned file, the two group sizes, the time unit and the dataset's original code seed. Order: eight blocks, each containing all four scenarios, with the five conditions of a dataset scheduled consecutively in randomized order within the block. Reuse of a dataset across conditions is a design feature (paired with its primary PDF and PNG300 results), not additional independent data; the independent sample stays 32.

Failure handling, recoveries and the [0,1] and observed-range missing-output summaries follow the second-cohort protocol verbatim. The revision limit remains stated in P4 and, as before, is not enforced; exceedances will be audited and reported by condition as in the main study.

## Prespecified analysis

Scorer: frozen `pp_session()` (TAAE over 24 months, maximum error, time above 2 pp, RMST(24) errors, Cox log HR error) plus the precision outcomes of `prepare_se_estimands.py` (SE(log HR), Greenwood SE(24), event counts). Reference: observed-data records, unchanged.

Primary contrasts, each as a paired difference against the dataset's primary result, equal scenario weights, 10,000 stratified bootstrap draws of eight datasets per scenario, type 1 percentile endpoints, new stated seed:

1. nomark-PDF minus primary native PDF (what the marks contribute to vector reconstruction). Hypothesis: TAAE rises from the output-rounding floor to the order of the exact-coordinate Guyot result (0.07 pp), and event counts stop being exact.
2. nomark-PNG300 minus primary PNG300 (what the marks contribute under raster input). Hypothesis: a smaller but same-signed change.
3. res150, res100 and jpeg100 minus primary PNG300 (resolution and compression gradient). Hypothesis: median TAAE scales approximately inversely with resolution (about 0.09, 0.18 and 0.27 pp expected from the pixel arithmetic at 300, 150 and 100 dpi), with JPEG adding error beyond its resolution; maximum errors and time above 2 pp grow faster than TAAE.

Secondary: the same contrasts for RMST(24) difference, log HR, SE(log HR) and event counts; a check of whether SE(log HR) stays within 1% at every resolution; extraction-strategy classification of the saved programs by condition; instruction adherence by condition. No equivalence margin; no multiplicity adjustment; descriptive subgroup estimates by scenario only. Smallest difference of practical interest, stated in advance for this follow-up: 0.5 pp in TAAE (one event in a 200-participant trial) and 2% in SE(log HR) (a 4% inverse-variance weight error).

## What would change in the manuscript

The Discussion paragraph on screenshots would be rewritten from the measured gradient rather than from arithmetic. The identification argument would be stated as tested if contrast 1 behaves as hypothesized, and revised if it does not.
