"""Fixed development template and observed-data input checks for Proposal 2.2."""
from __future__ import annotations

# Support direct execution from this workflow directory.
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_root = next((p for p in _BootstrapPath(__file__).resolve().parents
                        if (p / "pyproject.toml").is_file()), None)
if _bootstrap_root is not None:
    _bootstrap_sys.path[:0] = [str(_bootstrap_root), str(_bootstrap_root / "src")]


import bisect
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

TEMPLATE = {
    "version": "primary-development-v1",
    "protocol_frozen": False,
    "page_points": [432.0, 324.0],
    "page_inches": [6.0, 4.5],
    "plot_bbox_pdf_points": [64.8, 100.8, 410.4, 280.8],
    "bbox_convention": "PDF bottom-left origin, [left,bottom,right,top]",
    "time_limits": [0, 36], "survival_limits": [0, 1],
    "risk_times": list(range(0, 37, 6)),
    "survival_ticks": [0, .2, .4, .6, .8, 1],
    "font": "Bitstream Vera Sans", "axis_legend_font_pt": 9,
    "risk_table_font_pt": 8,
    "colors": {"A": "#1F77B4", "B": "#FF7F0E"},
    "curve_width_pt": 1.0, "curve_dash": [],
    "censor_symbol": "vertical line", "censor_height_pt": 4.0,
    "censor_width_pt": .65, "censor_survival": "post-drop at the observed censoring time",
    "axis_width_pt": .6, "background": "#FFFFFF",
    "grid": False, "confidence_bands": False, "smoothing": False,
    "path_simplification": False, "axis_tick_baseline_pt": 87.5,
    "time_label_baseline_pt": 70.5,
    "legend_baseline_pt": 301.0, "legend_line_y_pt": 304.0,
    "risk_title_baseline_pt": 51.0,
    "risk_row_baseline_pt": {"A": 34.0, "B": 20.0},
    "risk_group_label_right_pt": 49.0,
    "draw_order": ["axes", "curve_A", "curve_B", "censors_A", "censors_B", "legend", "risk_table"],
    "raster_dpi": [100, 300],
    "pdf_coordinate_verification_tolerance_pt": .0001,
}


def read_csv(path):
    with open(path, newline="") as stream:
        return list(csv.DictReader(stream))


def digest(path, algorithm="sha256"):
    return hashlib.new(algorithm, Path(path).read_bytes()).hexdigest()


def save_json(value, path):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def rgb(group):
    color = TEMPLATE["colors"][group].lstrip("#")
    return tuple(int(color[i:i+2], 16) / 255 for i in (0, 2, 4))


def xy(time, survival):
    left, bottom, right, top = TEMPLATE["plot_bbox_pdf_points"]
    return left + (right-left)*time/36, bottom + (top-bottom)*survival


def verify_source(source):
    status = json.loads((source / "validation/validation_status.json").read_text())
    if not status.get("passed") or status.get("stage") != "development_only":
        raise ValueError("A passing milestone-1 development run is required")
    entries = read_csv(source / "checksums.csv")
    for entry in entries:
        if digest(source / entry["file"], "md5") != entry["md5"]:
            raise ValueError(f"Milestone-1 output checksum mismatch: {entry['file']}")
    return len(entries)


def load_dataset(source, dataset_id):
    """Recompute steps/counts from Y and delta and cross-check retained references.

    No latent times are used to position curves or censor marks. Full-precision
    decimal CSV companions are read by Python; RDS remains canonical for R use.
    """
    root = source / "scoring_only"
    folder = root / dataset_id
    records = read_csv(folder / "records.csv")
    if {r["group"] for r in records} != {"A", "B"}:
        raise ValueError("Expected two groups A and B")
    risk_rows = read_csv(root / "risk_tables.csv")
    arms = {}
    for group in ("A", "B"):
        observed = [(float(r["observed_time"]), int(r["event"]))
                    for r in records if r["group"] == group]
        if any(not math.isfinite(t) or not 0 <= t <= 36 or d not in (0, 1) for t, d in observed):
            raise ValueError("Malformed observed records")
        counts = Counter(t for t, _ in observed)
        deaths = Counter(t for t, d in observed if d == 1)
        n_risk, survival = len(observed), 1.0
        expected_vertices = [(0.0, 1.0)]
        table = []
        for time in sorted(counts):
            before = survival
            survival *= 1 - deaths[time] / n_risk
            table.append((time, n_risk, deaths[time], counts[time]-deaths[time], before, survival))
            if deaths[time]:
                expected_vertices.extend([(time, before), (time, survival)])
            n_risk -= counts[time]
        endpoint = max(t for t, _ in observed)
        if expected_vertices[-1][0] < endpoint:
            expected_vertices.append((endpoint, survival))
        saved_table = read_csv(folder / f"km_{group}.csv")
        if len(table) != len(saved_table):
            raise ValueError("KM table length mismatch")
        fields = ("time", "n_risk", "n_event", "n_censor", "survival_before", "survival")
        for expected, saved in zip(table, saved_table):
            if any(abs(a - float(saved[k])) > 1e-12 for a, k in zip(expected, fields)):
                raise ValueError("Observed-data KM does not match saved reference")
        vertices = [(float(r["time"]), float(r["survival"]))
                    for r in read_csv(folder / f"step_coordinates_{group}.csv")]
        if len(vertices) != len(expected_vertices) or any(
            max(abs(a-c), abs(b-d)) > 1e-12
            for (a,b), (c,d) in zip(vertices, expected_vertices)
        ):
            raise ValueError("Saved step vertices differ from observed-data KM")
        risk = [sum(t >= tick for t, _ in observed) for tick in TEMPLATE["risk_times"]]
        saved_risk = {float(r["time"]): int(r["n_risk"]) for r in risk_rows
                      if r["dataset_id"] == dataset_id and r["group"] == group}
        if [saved_risk[t] for t in TEMPLATE["risk_times"]] != risk:
            raise ValueError("Risk table differs from observed records")
        km_times = [r[0] for r in table]
        censors = [(t, table[bisect.bisect_right(km_times, t)-1][-1])
                   for t, d in observed if d == 0]
        arms[group] = {"vertices": vertices, "censors": censors, "risk": risk,
                       "n": len(observed), "events": sum(d for _, d in observed),
                       "endpoint": endpoint, "terminal_survival": survival}
    return arms


def render_command(executable, pdf, prefix, dpi):
    return [str(executable), "-f", "1", "-l", "1", "-singlefile", "-png",
            "-r", str(dpi), "-aa", "yes", "-aaVector", "yes",
            "-thinlinemode", "none", str(pdf), str(prefix)]
