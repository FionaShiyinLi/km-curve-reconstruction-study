#!/usr/bin/env python3
"""Verify native geometry, visible data, physical sizes and exact PDF rasterization."""
from __future__ import annotations

# Support direct execution from this workflow directory.
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_root = next((p for p in _BootstrapPath(__file__).resolve().parents
                        if (p / "pyproject.toml").is_file()), None)
if _bootstrap_root is not None:
    _bootstrap_sys.path[:0] = [str(_bootstrap_root), str(_bootstrap_root / "src")]


import argparse
import copy
import hashlib
import json
import math
import shutil
import subprocess
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pdfplumber
from PIL import Image
from pypdf import PdfReader
from pypdf.generic import ContentStream

from km_analysis.figures import TEMPLATE, digest, load_dataset, render_command, rgb, save_json, verify_source, xy


def strokes_from_pdf(reader):
    state = {"color": (0., 0., 0.), "width": 1., "dash": []}
    stack, path, strokes = [], [], []
    operations = ContentStream(reader.pages[0].get_contents(), reader).operations
    for operands, op in operations:
        if op == b"q":
            stack.append(copy.deepcopy(state))
        elif op == b"Q":
            state = stack.pop()
        elif op == b"RG":
            state["color"] = tuple(float(v) for v in operands)
        elif op == b"w":
            state["width"] = float(operands[0])
        elif op == b"d":
            state["dash"] = list(operands[0])
        elif op == b"n":
            path = []
        elif op in (b"m", b"l"):
            path.append((op.decode(), tuple(float(v) for v in operands)))
        elif op == b"S":
            strokes.append({**copy.deepcopy(state), "path": path})
            path = []
        elif op in (b"c", b"v", b"y", b"W", b"W*", b"Do", b"INLINE IMAGE"):
            raise AssertionError(f"Unexpected smoothing, clipping or image operation: {op}")
    return strokes


def assert_close_points(got, expected, tolerance=.0001):
    assert len(got) == len(expected), (len(got), len(expected))
    error = max((max(abs(a-c), abs(b-d)) for (a,b), (c,d) in zip(got, expected)), default=0)
    assert error <= tolerance, error
    return error


def verify_pdf(pdf, arms):
    reader = PdfReader(pdf)
    assert len(reader.pages) == 1 and not reader.is_encrypted
    page = reader.pages[0]
    assert list(map(float, page.mediabox)) == [0, 0, 432, 324]
    assert list(map(float, page.cropbox)) == [0, 0, 432, 324]
    assert page.get("/Rotate", 0) == 0 and page.get("/UserUnit", 1) == 1
    assert not page.get("/Annots")
    assert not page["/Resources"].get("/XObject"), "Images/forms must not replace native paths"
    root = reader.trailer["/Root"]
    assert not any(k in root for k in ("/Names", "/Metadata", "/AcroForm", "/OpenAction", "/AA"))
    assert reader.metadata.title == "Kaplan-Meier curves"
    assert reader.metadata.author == "" and reader.metadata.subject == ""
    assert reader.metadata.get("/Keywords", "") == ""
    assert reader.metadata.creator == "KM benchmark figure renderer"
    fonts = [f.get_object() for f in page["/Resources"]["/Font"].values()]
    assert len(fonts) == 1
    assert "/FontFile2" in fonts[0]["/FontDescriptor"]

    strokes = strokes_from_pdf(reader)
    summaries = {}
    for group in ("A", "B"):
        colored = [s for s in strokes if max(abs(a-b) for a,b in zip(s["color"], rgb(group))) < 1e-6]
        curves = [s for s in colored if s["width"] == 1 and len(s["path"]) > 2]
        assert len(curves) == 1
        curve = curves[0]
        assert not curve["dash"]
        assert [op for op, _ in curve["path"]] == ["m"] + ["l"]*(len(curve["path"])-1)
        expected = [xy(t, s) for t, s in arms[group]["vertices"]]
        error = assert_close_points([p for _, p in curve["path"]], expected)
        marks = [s for s in colored if s["width"] == TEMPLATE["censor_width_pt"]]
        assert len(marks) == len(arms[group]["censors"])
        for mark, (time, survival) in zip(marks, arms[group]["censors"]):
            x, y = xy(time, survival)
            assert [op for op, _ in mark["path"]] == ["m", "l"] and not mark["dash"]
            error = max(error, assert_close_points([p for _, p in mark["path"]], [(x,y-2), (x,y+2)]))
        legend = [s for s in colored if s["width"] == 1 and len(s["path"]) == 2]
        assert len(legend) == 1 and all(p[1] > TEMPLATE["plot_bbox_pdf_points"][3] for _, p in legend[0]["path"])
        assert len(colored) == 2 + len(marks), "Unexpected colored annotations"
        summaries[group] = {"n": arms[group]["n"], "events": arms[group]["events"],
                            "native_curve_vertices": len(curve["path"]),
                            "native_censor_marks": len(marks),
                            "endpoint_months": arms[group]["endpoint"],
                            "terminal_survival": arms[group]["terminal_survival"],
                            "maximum_native_geometry_error_pt": error}
    black = [s for s in strokes if s["color"] == (0., 0., 0.)]
    # Two axes, seven x ticks and six y ticks: no grid, border or extra paths.
    assert len(black) == 15 and all(s["width"] == .6 and not s["dash"] for s in black)
    assert len(strokes) == len(black) + 4 + sum(len(a["censors"]) for a in arms.values())

    expected_words = [str(t) for t in TEMPLATE["risk_times"]]
    expected_words += [f"{s:.1f}" for s in TEMPLATE["survival_ticks"]]
    expected_words += "Time (months) Survival probability Number at risk".split()
    expected_words += "Group A Group B Group A Group B".split()
    expected_words += [str(v) for group in ("A", "B") for v in arms[group]["risk"]]
    assert Counter(page.extract_text().split()) == Counter(expected_words), "Unexpected/missing PDF text"

    with pdfplumber.open(pdf) as parsed:
        p = parsed.pages[0]
        assert len(p.images) == 0
        assert all(0 <= char["x0"] <= char["x1"] <= 432 and
                   0 <= char["top"] <= char["bottom"] <= 324 for char in p.chars), "Text outside page"
        assert len({char["fontname"] for char in p.chars}) == 1
        for char in p.chars:
            if char["upright"]:
                expected_size = 8 if char["top"] > 324-60 else 9
                assert math.isclose(char["size"], expected_size, abs_tol=1e-8)
        for group in ("A", "B"):
            baseline = TEMPLATE["risk_row_baseline_pt"][group]
            row = p.crop((0, 324-baseline-10, 432, 324-baseline+3))
            words = row.extract_words(x_tolerance=1)
            assert [w["text"] for w in words] == ["Group", group] + [str(v) for v in arms[group]["risk"]]
            for word, time in zip(words[2:], TEMPLATE["risk_times"]):
                assert abs((word["x0"]+word["x1"])/2 - xy(time, 0)[0]) < .0001
    return {"native_vector_only": True, "embedded_sans_font": True,
            "preserved_text": True, "risk_text_and_alignment_verified": True,
            "no_hidden_metadata_or_attachments": True, "arms": summaries}


def verify_png(path, pdf, dpi, executable):
    expected_size = (int(6*dpi), int(4.5*dpi))
    with Image.open(path) as im:
        im.load()
        assert im.format == "PNG" and im.mode == "RGB" and im.size == expected_size
        assert set(im.info) <= {"dpi"}, f"Unexpected PNG metadata: {im.info}"
        assert all(abs(v-dpi) < .02 for v in im.info["dpi"])
        # The complete outer pixel border is white: no clipped page-edge ink.
        width, height = im.size
        for box in ((0,0,width,1), (0,height-1,width,height), (0,0,1,height), (width-1,0,width,height)):
            assert im.crop(box).getextrema() == ((255,255), (255,255), (255,255))
        array = im.tobytes()
        metadata_dpi = im.info["dpi"]
    with tempfile.TemporaryDirectory(prefix="km_raster_verify_") as scratch:
        prefix = Path(scratch) / "direct"
        subprocess.run(render_command(executable, pdf, prefix, dpi), check=True, capture_output=True)
        with Image.open(prefix.with_suffix(".png")) as independent:
            assert independent.size == expected_size and independent.mode == "RGB"
            assert independent.tobytes() == array, "PNG is not an exact direct render of its assigned PDF"
    left, bottom, right, top = TEMPLATE["plot_bbox_pdf_points"]
    return {"width_px": expected_size[0], "height_px": expected_size[1], "mode": "RGB",
            "nominal_dpi": dpi, "stored_dpi": metadata_dpi,
            "pixel_array_sha256": hashlib.sha256(array).hexdigest(),
            "direct_rerender_pixel_identical": True,
            "plot_bbox_pixels_top_left_origin": [v*dpi/72 for v in (left, 324-top, right, 324-bottom)],
            "time_axis_width_px": (right-left)*dpi/72, "survival_axis_height_px": (top-bottom)*dpi/72}


def write_checksums(output):
    files = sorted(p for p in output.rglob("*") if p.is_file() and p.name != "checksums.json")
    save_json({str(p.relative_to(output)): digest(p) for p in files}, output / "scoring_only/checksums.json")


def verify_run(source, output, executable):
    verify_source(source)
    template = json.loads((output / "scoring_only/template.json").read_text())
    assert template == TEMPLATE, "Template differs from the version being verified"
    inputs = output / "inputs"
    pdfs = sorted(inputs.glob("*.pdf"))
    assert len(pdfs) == 4
    expected_files = {p.name for pdf in pdfs for p in
                      (pdf, pdf.with_name(pdf.stem+"_600x450.png"), pdf.with_name(pdf.stem+"_1800x1350.png"))}
    assert {p.name for p in inputs.iterdir()} == expected_files
    result = {"automated_checks_passed": True, "visual_review": {"completed": False}, "figures": []}
    for pdf in pdfs:
        print(f"Verifying {pdf.stem}: paths, censor marks, text, crop and exact raster arrays", flush=True)
        arms = load_dataset(source, pdf.stem)
        native = verify_pdf(pdf, arms)
        native.update({"file": str(pdf.relative_to(output)), "sha256": digest(pdf),
                       "media_box_points": [0,0,432,324], "crop_box_points": [0,0,432,324],
                       "plot_bbox_pdf_points": TEMPLATE["plot_bbox_pdf_points"]})
        rasters = []
        for dpi, suffix in ((100, "600x450"), (300, "1800x1350")):
            png = pdf.with_name(pdf.stem+"_"+suffix+".png")
            checked = verify_png(png, pdf, dpi, executable)
            checked.update({"file": str(png.relative_to(output)), "sha256": digest(png)})
            rasters.append(checked)
        result["figures"].append({"dataset_id": pdf.stem, "pdf": native, "pngs": rasters})
    save_json(result, output / "scoring_only/verification.json")
    lines = ["# Matched development figure verification", "",
             "Automated verification: **PASS**. Four native vector PDFs and eight matched PNGs were generated from the retained milestone-1 development records.", "",
             "Visual inspection: pending.", "",
             "| Dataset | A curve vertices | B curve vertices | A censor marks | B censor marks |",
             "|---|---:|---:|---:|---:|"]
    for figure in result["figures"]:
        a, b = figure["pdf"]["arms"]["A"], figure["pdf"]["arms"]["B"]
        lines.append(f"| {figure['dataset_id']} | {a['native_curve_vertices']} | {b['native_curve_vertices']} | {a['native_censor_marks']} | {b['native_censor_marks']} |")
    lines += ["", "## Fixed appearance", "",
              "The master is 432 × 324 PDF points (6 × 4.5 inches). Group A is blue #1F77B4; Group B is orange #FF7F0E. Both curves are solid 1-point step paths. Bitstream Vera Sans is embedded: axes and legend use 9 points; the risk table uses 8 points. Every observed censor is a 4-point vertical tick with 0.65-point stroke. The legend is above the plotting area. Background is white, with no grid, bands, effect annotations, smoothing or path simplification.", "",
              "Both PNGs are produced directly from the PDF by the same Poppler renderer, with text/vector antialiasing enabled and thin-line mode disabled. No crop, resize, sharpening or upscaling is applied. A fresh render of each PDF at each DPI was compared with the saved PNG pixel array; every comparison was identical.", "",
              "| Format | Full dimensions | Plot bounds, top-left pixel origin | Time-axis width | Survival-axis height |",
              "|---|---|---|---:|---:|",
              "| PDF | 432 × 324 pt | PDF bottom-left bounds: [64.8, 100.8, 410.4, 280.8] pt | 345.6 pt | 180 pt |",
              "| PNG, 100 DPI | 600 × 450 px | [90, 60, 570, 310] | 480 px | 250 px |",
              "| PNG, 300 DPI | 1800 × 1350 px | [270, 180, 1710, 930] | 1440 px | 750 px |", "",
              "## Checks against observed records", "",
              "The renderer independently reconstructs empirical KM steps from observed times and event indicators and compares them with the retained milestone-1 KM tables and ordered vertices. Risk counts are independently checked using Y ≥ t at months 0, 6, 12, 18, 24, 30 and 36. Censor positions use post-drop survival at each observed censoring time. The input checksum audit verifies all 42 milestone-1 outputs before figure generation.", "",
              "The PDF content streams are parsed to confirm every retained step vertex and every censor mark, including overlaps. Native coordinates agree within 0.0001 PDF point (less than 0.00042 pixel at 300 DPI), the verification tolerance for PDF decimal serialization. Path counts, solid 1-point strokes, endpoints, legend location, exact risk text, column alignment, font sizes, embedded font, page/crop bounds, and the absence of image objects and hidden attachments are checked. No curve is extended to month 36 or forced to zero. Every text bounding box lies within the page, and the entire outer PNG border is white.", "",
              "## Files and reproducibility", "",
              "The inputs directory contains only 12 assigned-input files, using neutral D0001–D0004 identifiers. Scenario labels, participant records, seeds, exact-coordinate sidecars and manifests are excluded from these files. PDF metadata is neutral; PNG metadata is limited to physical resolution. The filenames retain the existing development IDs and therefore provide no new blinding guarantee to someone who already knows the earlier mapping.", "",
              "The scoring_only directory retains the fixed template, software/font versions and hashes, exact render commands, PDF/PNG file hashes, decoded RGB pixel hashes, plotting dimensions, and verification results. It must not be exposed to an extraction session. The inputs directory holds sibling formats together for storage; a later runner must expose only one assigned file per isolated session.", "",
              "This template is fixed for these development figures and recorded before extraction. The main-study protocol remains unfrozen. Dense overlaps and sparse tails are retained as properties of the simulated records; individual censor ticks may overlap visually despite all being present as native paths. No extraction calls or provider-side image processing occurred at this milestone.", "",
              "Source: docs/archive/vector_raster_protocol_2026-09-12.docx, Section 2.2, Tables 2–3. Rendering uses [ReportLab native paths](https://docs.reportlab.com/reportlab/userguide/ch2_graphics/) and an [embedded TrueType font](https://docs.reportlab.com/reportlab/userguide/ch3_fonts/).", "",
              "Next step: configure and test the isolated extraction runner, then run the separate feasibility pilot."]
    (output / "verification_report.md").write_text("\n".join(lines)+"\n")
    write_checksums(output)
    print(f"Automated checks PASS; visual review required: {output / 'verification_report.md'}", flush=True)
    return result


def record_visual_review(output, inspected_pngs, notes):
    """Call only after a human or image-capable reviewer has viewed all PNGs."""
    result_path = output / "scoring_only/verification.json"
    result = json.loads(result_path.read_text())
    expected = {p["file"] for f in result["figures"] for p in f["pngs"]}
    assert set(inspected_pngs) == expected
    assert result["automated_checks_passed"] and notes.strip()
    result["visual_review"] = {"completed": True, "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
                               "inspected_pngs": sorted(inspected_pngs), "notes": notes}
    save_json(result, result_path)
    report = output / "verification_report.md"
    text = report.read_text()
    assert "Visual inspection: pending." in text
    report.write_text(text.replace("Visual inspection: pending.", "Visual inspection: **PASS**. " + notes))
    write_checksums(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("outputs/development/milestone1"))
    parser.add_argument("--output", type=Path, default=Path("outputs/development/matched_figures"))
    parser.add_argument("--pdftoppm", type=Path, default=shutil.which("pdftoppm"))
    args = parser.parse_args()
    verify_run(args.source, args.output, args.pdftoppm)
