#!/usr/bin/env python3
"""Check the installed project environment against the committed package inventory."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    prefix=Path(sys.prefix)
    inventory=json.loads((ROOT/'environment/conda-packages.json').read_text())
    actual={}
    for p in (prefix/'conda-meta').glob('*.json'):
        row=json.loads(p.read_text());actual[row['name']]=(row['version'],row['build'])
    expected={r['name']:(r['version'],r['build_string']) for r in inventory if r.get('channel')!='pypi'}
    differences={n:dict(expected=v,actual=actual.get(n)) for n,v in expected.items() if actual.get(n)!=v}
    extras=set(actual)-set(expected)
    if differences or extras: raise RuntimeError(f'Conda environment differs: {differences}; extra packages: {sorted(extras)}')
    cran=json.loads((ROOT/'environment/cran-packages.json').read_text())
    expression='cat(jsonlite::toJSON(lapply(c('+','.join(json.dumps(r['name']) for r in cran['packages'])+'), function(n) list(name=n,version=packageDescription(n)[["Version"]],path=find.package(n))), auto_unbox=TRUE))'
    result=subprocess.check_output([str(prefix/'bin/Rscript'),'--vanilla','-e',expression],text=True)
    versions={r['name']:r for r in json.loads(result)}
    for row in cran['packages']:
        if versions[row['name']]['version']!=row['version']: raise RuntimeError('CRAN version mismatch: '+row['name'])
        if not Path(versions[row['name']]['path']).is_relative_to(prefix): raise RuntimeError('R loaded a package outside Conda')
    if os.environ.get('CONDA_PREFIX')!=str(prefix): raise RuntimeError('Activate the project environment first')
    print(json.dumps(dict(passed=True,prefix=str(prefix),conda_packages=len(expected),cran_packages=len(versions))))


if __name__=='__main__': main()
