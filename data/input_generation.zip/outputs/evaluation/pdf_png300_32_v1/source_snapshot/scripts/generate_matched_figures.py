#!/usr/bin/env python3
"""Generate all three assigned inputs per development dataset, then verify them."""
from __future__ import annotations

# Support direct execution from this workflow directory.
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_root = next((p for p in _BootstrapPath(__file__).resolve().parents
                        if (p / "pyproject.toml").is_file()), None)
if _bootstrap_root is not None:
    _bootstrap_sys.path[:0] = [str(_bootstrap_root), str(_bootstrap_root / "src")]


import argparse
import importlib.metadata
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

from km_analysis.figures import TEMPLATE, digest, load_dataset, render_command, rgb, save_json, verify_source, xy

FONT = "KM-Vera"


def draw_pdf(path, arms, font_path, *, marks_shown=True, table_shown=True):
    pdfmetrics.registerFont(TTFont(FONT, str(font_path)))
    c = Canvas(str(path), pagesize=tuple(TEMPLATE["page_points"]),
               pageCompression=1, invariant=1, initialFontName=FONT, initialFontSize=9)
    # Neutral metadata only: no scenario, seed, participant identifiers or IPD.
    c.setTitle("Kaplan-Meier curves")
    c.setAuthor("")
    c.setSubject("")
    c.setKeywords("")
    c.setCreator("KM benchmark figure renderer")
    width, height = TEMPLATE["page_points"]
    c.setFillColorRGB(1, 1, 1)
    c.rect(0, 0, width, height, fill=1, stroke=0)
    left, bottom, right, top = TEMPLATE["plot_bbox_pdf_points"]
    c.setStrokeColorRGB(0, 0, 0)
    c.setFillColorRGB(0, 0, 0)
    c.setLineWidth(TEMPLATE["axis_width_pt"])
    c.setLineCap(0); c.setLineJoin(0); c.setDash([])
    c.line(left, bottom, right, bottom)
    c.line(left, bottom, left, top)
    c.setFont(FONT, 9)
    for tick in TEMPLATE["risk_times"]:
        x, _ = xy(tick, 0)
        c.line(x, bottom, x, bottom-3)
        c.drawCentredString(x, TEMPLATE["axis_tick_baseline_pt"], str(tick))
    for tick in TEMPLATE["survival_ticks"]:
        _, y = xy(0, tick)
        c.line(left-3, y, left, y)
        c.drawRightString(left-7, y-3, f"{tick:.1f}")
    c.drawCentredString((left+right)/2, TEMPLATE["time_label_baseline_pt"], "Time (months)")
    c.saveState()
    c.translate(18, (bottom+top)/2)
    c.rotate(90)
    c.drawCentredString(0, 0, "Survival probability")
    c.restoreState()
    # Native PDF m/l paths, one vertex per retained pre/post step coordinate.
    for group in ("A", "B"):
        c.setStrokeColorRGB(*rgb(group))
        c.setLineWidth(TEMPLATE["curve_width_pt"])
        path_obj = c.beginPath()
        for i, (time, survival) in enumerate(arms[group]["vertices"]):
            point = xy(time, survival)
            (path_obj.moveTo if i == 0 else path_obj.lineTo)(*point)
        c.drawPath(path_obj, stroke=1, fill=0)
    if marks_shown:
        for group in ("A", "B"):
            c.setStrokeColorRGB(*rgb(group))
            c.setLineWidth(TEMPLATE["censor_width_pt"])
            for time, survival in arms[group]["censors"]:
                x, y = xy(time, survival)
                half = TEMPLATE["censor_height_pt"] / 2
                c.line(x, y-half, x, y+half)
    # Legend is entirely above the plotting area.
    c.setFont(FONT, 9)
    label_widths = [pdfmetrics.stringWidth(f"Group {g}", FONT, 9) for g in ("A", "B")]
    legend_width = sum(label_widths) + 2*(18+6) + 28
    x = (left+right-legend_width)/2
    for group, text_width in zip(("A", "B"), label_widths):
        c.setStrokeColorRGB(*rgb(group)); c.setLineWidth(1)
        c.line(x, TEMPLATE["legend_line_y_pt"], x+18, TEMPLATE["legend_line_y_pt"])
        c.setFillColorRGB(0, 0, 0)
        c.drawString(x+24, TEMPLATE["legend_baseline_pt"], f"Group {group}")
        x += 24 + text_width + 28
    if table_shown:
        c.setFont(FONT, 8)
        c.drawString(left, TEMPLATE["risk_title_baseline_pt"], "Number at risk")
        for group in ("A", "B"):
            y = TEMPLATE["risk_row_baseline_pt"][group]
            c.drawRightString(TEMPLATE["risk_group_label_right_pt"], y, f"Group {group}")
            for time, count in zip(TEMPLATE["risk_times"], arms[group]["risk"]):
                c.drawCentredString(xy(time, 0)[0], y, str(count))
    c.showPage()
    c.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("outputs/development/milestone1"))
    parser.add_argument("--output", type=Path, default=Path("outputs/development/matched_figures"))
    parser.add_argument("--pdftoppm", type=Path, default=shutil.which("pdftoppm"))
    parser.add_argument("--font", type=Path, default=Path(reportlab.__file__).parent / "fonts/Vera.ttf")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Output already exists; choose a new directory")
    if args.pdftoppm is None or not args.pdftoppm.is_file():
        parser.error("Supply the installed Poppler pdftoppm executable with --pdftoppm")
    source_count = verify_source(args.source)
    pdf_ids = sorted(p.name for p in (args.source / "scoring_only").glob("D[0-9][0-9][0-9][0-9]") if p.is_dir())
    if len(pdf_ids) != 4:
        parser.error("This development run expects the four milestone-1 datasets")
    arms_by_id = {identifier: load_dataset(args.source, identifier) for identifier in pdf_ids}
    figures = args.output / "inputs"
    audit = args.output / "scoring_only"
    figures.mkdir(parents=True); audit.mkdir()
    save_json(TEMPLATE, audit / "template.json")
    commands = []
    for identifier, arms in arms_by_id.items():
        print(f"Generating {identifier}: native PDF and independent 100/300-DPI renders", flush=True)
        pdf = figures / f"{identifier}.pdf"
        draw_pdf(pdf, arms, args.font)
        for dpi, suffix in ((100, "600x450"), (300, "1800x1350")):
            prefix = figures / f"{identifier}_{suffix}"
            command = render_command(args.pdftoppm, pdf, prefix, dpi)
            run = subprocess.run(command, check=True, capture_output=True, text=True)
            commands.append({"dataset_id": identifier, "dpi": dpi, "argv": command,
                             "returncode": run.returncode, "stdout": run.stdout, "stderr": run.stderr,
                             "source_pdf_sha256": digest(pdf),
                             "crop": "full MediaBox, equal to CropBox", "resize": False,
                             "sharpen": False, "upscale": False, "antialias": {"text": True, "vector": True}})
    save_json(commands, audit / "render_log.json")
    version = subprocess.run([str(args.pdftoppm), "-v"], capture_output=True, text=True, check=True)
    source_files = [Path(__file__), Path(__file__).resolve().parents[1] / "src/km_analysis/figures.py",
                    Path(__file__).with_name("verify_matched_figures.py"), Path("docs/archive/vector_raster_protocol_2026-09-12.docx")]
    save_json({"created_at_utc": datetime.now(timezone.utc).isoformat(),
               "stage": "development_only", "protocol_frozen": False,
               "source": str(args.source.resolve()), "source_outputs_verified": source_count,
               "source_manifest_sha256": digest(args.source / "run_manifest.json"),
               "python": sys.version, "platform": platform.platform(),
               "packages": {p: importlib.metadata.version(p) for p in ("reportlab", "pypdf", "pdfplumber", "Pillow")},
               "renderer": {"executable": str(args.pdftoppm.resolve()), "version": (version.stdout+version.stderr).strip()},
               "font": {"path": str(args.font.resolve()), "sha256": digest(args.font), "embedded": True},
               "script_and_proposal_sha256": {str(p): digest(p) for p in source_files}},
              audit / "run_manifest.json")
    from scripts.verify_matched_figures import verify_run
    verify_run(args.source, args.output, args.pdftoppm)


if __name__ == "__main__":
    main()
