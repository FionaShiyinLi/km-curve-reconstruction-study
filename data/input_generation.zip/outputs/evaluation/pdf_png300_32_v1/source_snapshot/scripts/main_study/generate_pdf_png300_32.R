#!/usr/bin/env Rscript
# Reserve independent streams before generation. Never replace generated data.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args) == 3L, args[1] %in% c("streams", "generate"))
spec <- normalizePath(args[2]); out <- args[3]
for (f in c("protocol", "simulation", "reference", "io")) source(paste0("R/", f, ".R"))
plan <- jsonlite::read_json(file.path(spec, "plan.json"), simplifyVector=FALSE)
datasets <- read.csv(file.path(spec, "datasets.csv"), stringsAsFactors=FALSE)
stopifnot(nrow(datasets) == 32L, all(table(datasets$scenario) == 8L))
if (args[1] == "streams") {
  target <- file.path(spec, "rng_streams.json")
  if (file.exists(target)) stop("Reserved streams already exist")
  state <- initialize_rng(plan$seeds$data)
  streams <- lapply(datasets$dataset, function(id) {
    item <- list(dataset=id, rng_state=state)
    state <<- parallel::nextRNGStream(state)
    item
  })
  write_json(list(seed=plan$seeds$data, kind=RNGkind(), streams=streams,
                  next_unused_stream=state), target)
  quit(status=0)
}
streams <- jsonlite::read_json(file.path(spec,"rng_streams.json"), simplifyVector=FALSE)$streams
cfg <- plan$generator
cfg$risk_times <- as.numeric(unlist(cfg$risk_times))
if (dir.exists(file.path(out,"data"))) stop("Retaining existing data; no redraw/overwrite")
dir.create(file.path(out,"data/scoring_only"), recursive=TRUE)
risks <- checks <- manifest <- list()
for (i in seq_len(nrow(datasets))) {
  slot <- datasets[i,]
  stopifnot(identical(streams[[i]]$dataset, slot$dataset))
  state <- as.integer(unlist(streams[[i]]$rng_state))
  d <- generate_dataset(slot$n_per_group, slot$pattern, state, slot$dataset, cfg)
  end <- .Random.seed
  stopifnot(identical(d, generate_dataset(slot$n_per_group, slot$pattern, state, slot$dataset, cfg)))
  folder <- file.path(out,"data/scoring_only",slot$dataset); dir.create(folder)
  saveRDS(d,file.path(folder,"records.rds")); write_precise_csv(d,file.path(folder,"records.csv"))
  manifest[[i]] <- list(dataset=slot$dataset, rng_state=state, rng_end_state=end)
  for (g in c("A","B")) {
    dg <- d[d$group==g,]
    km <- km_from_observed(dg$observed_time,dg$event)
    fit <- survival::survfit(survival::Surv(observed_time,event)~1,data=dg,timefix=FALSE)
    stopifnot(max(abs(fit$surv-km$survival)) < 1e-12,
              identical(as.integer(fit$n.risk),as.integer(km$n_risk)))
    write_precise_csv(km,file.path(folder,paste0("km_",g,".csv")))
    write_precise_csv(step_coordinates(km),file.path(folder,paste0("step_coordinates_",g,".csv")))
    risks[[length(risks)+1L]] <- data.frame(dataset_id=slot$dataset,group=g,
      time=cfg$risk_times,n_risk=risk_counts(dg$observed_time,dg$event,cfg$risk_times))
    checks[[length(checks)+1L]] <- data.frame(dataset=slot$dataset,group=g,
      n=nrow(dg),censoring_fraction=mean(dg$event==0),km_crosscheck=TRUE)
  }
}
write_precise_csv(do.call(rbind,risks),file.path(out,"data/scoring_only/risk_tables.csv"))
write_precise_csv(do.call(rbind,checks),file.path(out,"data/scoring_only/generation_checks.csv"))
write_json(manifest,file.path(out,"data/scoring_only/seed_manifest.json"))
write_json(list(datasets=32,independent_arm_KM_checks=64,regeneration_verified=TRUE,
  redraws=0,R_version=R.version.string,survival_version=as.character(packageVersion("survival"))),
  file.path(out,"data/validation.json"))
cat("32 datasets generated; 64 independent arm-KM checks passed; zero redraws.\n")
