#!/usr/bin/env python3
"""Freeze/prepare/verify 32 new datasets and 80 assignments. No model execution."""
import argparse
from collections import Counter
import csv
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import random
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]
STUDY = "pdf_png300_32_v1"
SPEC = ROOT / "docs/proposals" / STUDY
OUT = ROOT / "outputs/evaluation" / STUDY
SEEDS = dict(data=2026092301, order=2026092302, code=2026092303,
             input_ids=2026092304, repeat_subset=2026092305, analysis_reserved=2026092306)
SCENARIOS = {"S1": (100, "noncrossing"), "S2": (100, "crossing"),
             "S3": (1000, "noncrossing"), "S4": (1000, "crossing")}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(value, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")


def write_csv(rows, path):
    with path.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def make_design():
    datasets = [dict(dataset=f"PP32_{s}_D{r:02d}", scenario=s, replicate=r,
                     n_per_group=n, pattern=pattern, dropout_rate=.005)
                for s, (n, pattern) in SCENARIOS.items() for r in range(1, 9)]
    subset_rng = random.Random(SEEDS["repeat_subset"])
    repeats = [d for s in SCENARIOS for d in subset_rng.sample([d for d in datasets if d["scenario"] == s], 2)]
    inputs = [{**d, "representation": f} for d in datasets for f in ("PDF", "PNG300")]
    random.Random(SEEDS["input_ids"]).shuffle(inputs)
    for i, row in enumerate(inputs, 1):
        row["input_id"] = f"I{i:03d}"
    order_rng = random.Random(SEEDS["order"])
    schedule = []
    for block in range(1, 9):
        rows = [{**r, "attempt": 1, "primary_attempt": True, "block": block}
                for r in inputs if r["replicate"] == block]
        order_rng.shuffle(rows); schedule.extend(rows)
    repeat_ids = {r["dataset"] for r in repeats}
    rows = [{**r, "attempt": 2, "primary_attempt": False, "block": 9}
            for r in inputs if r["dataset"] in repeat_ids]
    order_rng.shuffle(rows); schedule.extend(rows)
    codes = random.Random(SEEDS["code"]).sample(range(1, 2**31), 80)
    for i, row in enumerate(schedule, 1):
        row.update(session_id=f"PP32_R{i:03d}", code_seed=codes[i-1],
                   model="claude-opus-5-5", effort="medium")
    validate_design(datasets, inputs, repeats, schedule)
    return datasets, inputs, repeats, schedule


def validate_design(datasets, inputs, repeats, schedule):
    if (len(datasets), len(inputs), len(repeats), len(schedule)) != (32, 64, 8, 80):
        raise ValueError("Expected 32 datasets, 64 inputs, 8 repeat datasets and 80 sessions")
    by_dataset = {d["dataset"]: d for d in datasets}
    by_input = {r["input_id"]: r for r in inputs}
    repeat_ids = {r["dataset"] for r in repeats}
    if len(by_dataset) != 32 or len(by_input) != 64 or len(repeat_ids) != 8:
        raise ValueError("Duplicate identities")
    if Counter(d["scenario"] for d in datasets) != Counter({s: 8 for s in SCENARIOS}):
        raise ValueError("Dataset scenario balance changed")
    if Counter(d["scenario"] for d in repeats) != Counter({s: 2 for s in SCENARIOS}):
        raise ValueError("Repeat subset scenario balance changed")
    for d in datasets:
        if (d["n_per_group"], d["pattern"]) != SCENARIOS[d["scenario"]] or d["dropout_rate"] != .005:
            raise ValueError("Scientific scenario changed")
    if any(d != by_dataset.get(d["dataset"]) for d in repeats):
        raise ValueError("Repeat dataset mismatch")
    expected = {(d, f, 1) for d in by_dataset for f in ("PDF", "PNG300")}
    expected |= {(d, f, 2) for d in repeat_ids for f in ("PDF", "PNG300")}
    if {(r["dataset"], r["representation"], r["attempt"]) for r in schedule} != expected:
        raise ValueError("Missing/duplicated assignment or incorrect repeat subset")
    for i, r in enumerate(schedule, 1):
        if r["session_id"] != f"PP32_R{i:03d}" or r["attempt"] != (1 if i <= 64 else 2):
            raise ValueError("Session order/phase changed")
        if r["block"] != ((i-1)//8+1 if i <= 64 else 9):
            raise ValueError("Session block changed")
        if r["primary_attempt"] is not (r["attempt"] == 1):
            raise ValueError("Repeat must not become primary")
        if any(r[k] != by_dataset[r["dataset"]][k] for k in by_dataset[r["dataset"]]):
            raise ValueError("Dataset metadata mismatch")
        if any(r[k] != by_input[r["input_id"]][k] for k in by_input[r["input_id"]]):
            raise ValueError("Input assignment mismatch")
        if (r["model"], r["effort"]) != ("claude-opus-5-5", "medium"):
            raise ValueError("Configuration differs from selected model")
    if len({r["code_seed"] for r in schedule}) != 80:
        raise ValueError("Code seeds must be distinct")
    for block in range(1, 9):
        rows = [r for r in schedule if r["block"] == block]
        if Counter((r["scenario"], r["representation"]) for r in rows) != Counter((s, f) for s in SCENARIOS for f in ("PDF", "PNG300")):
            raise ValueError("Primary block balance changed")


def observed_signature(path):
    # Canonicalize observed data without dataset/participant labels or row order.
    with path.open() as handle:
        reader = csv.DictReader(handle)
        if not {"group", "observed_time", "event"} <= set(reader.fieldnames or []):
            return None
        rows = sorted((r["group"], float(r["observed_time"]).hex(), int(r["event"])) for r in reader)
    return hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()


def rng_states(value):
    if isinstance(value, list):
        if len(value) == 7 and all(type(x) is int for x in value) and value[0] % 100 == 7:
            return [tuple(value)]
        return [s for v in value for s in rng_states(v)]
    if isinstance(value, dict):
        return [s for v in value.values() for s in rng_states(v)]
    return []


def historical_exclusions():
    records, streams = [], []
    names = subprocess.check_output(["rg", "--files", "-uu", "outputs"], cwd=ROOT, text=True).splitlines()
    for name in sorted(names):
        p = ROOT / name
        if OUT in p.parents:
            continue
        if p.name == "records.csv":
            signature = observed_signature(p)
            if signature:
                records.append(dict(path=name, sha256=digest(p), observed_signature=signature))
        if p.name == "seed_manifest.json" or p.name.endswith("_streams.json") or p.name == "data_exclusions.json":
            streams.append(dict(path=name, sha256=digest(p), states=rng_states(load(p))))
    if not records or not streams:
        raise ValueError("Missing historical exclusion evidence")
    return dict(record_files=records, stream_sources=streams)


def freeze():
    if SPEC.exists() or OUT.exists():
        raise FileExistsError("Existing package retained; no refreeze")
    subprocess.run([sys.executable, str(ROOT / "scripts/check_environment.py")], check=True)
    datasets, inputs, repeats, schedule = make_design()
    screen = ROOT / "outputs/development/pdf_png_opus55_screen_v2"
    old_codes = {r["code_seed"] for r in load(screen / "schedule.json")}
    if old_codes & {r["code_seed"] for r in schedule}:
        raise ValueError("Development code seed reused")
    SPEC.mkdir(parents=True)
    plan = dict(study_id=STUDY, independent_datasets=32, unique_inputs=64,
        primary_sessions=64, repeat_sessions=16, total_sessions=80,
        seeds=SEEDS, generator={"lambda": math.log(2)/12, "noncrossing_ratio": .75,
        "crossing_early_ratio": 1.5, "crossing_late_ratio": .5, "hazard_change": 4,
        "entry_window": 12, "closure": 36, "dropout_rate": .005, "tau": 24,
        "risk_times": list(range(0, 37, 6))}, model="claude-opus-5-5", effort="medium",
        prompt="P4_image.txt", analysis_frozen=False, execution_frozen=False,
        live_execution_allowed=False, model_calls_authorized=0,
        order_rule="Eight randomized blocks, each covering all four scenarios and both formats; then 16 shuffled repeats",
        repeat_rule="Two datasets sampled without replacement per scenario before generation; repeats never replace/average primary results",
        generation_policy="No quality-based redraw or selection; existing data never overwritten",
        stopping_rule="Prepare exactly 32 datasets, 64 figures and 80 assignments; no model calls",
        resume_policy="Incomplete data generation requires review; locked data retained, verified identical rendering may resume")
    save(plan, SPEC / "plan.json")
    for name, rows in [("datasets", datasets), ("inputs", inputs), ("repeat_subset", repeats), ("schedule", schedule)]:
        write_csv(rows, SPEC / f"{name}.csv")
    shutil.copyfile(ROOT / "manuscript/PDF_VS_PNG300/PROTOCOL.md", SPEC / "PROTOCOL_AT_INPUT_FREEZE.md")
    prompt = screen / "P4_image.txt"
    if digest(prompt) != "920ab6c07fc4afd6e40a31cd2a6b5077f533941ee69aebf73224881acc1c56e2":
        raise ValueError("P4 changed")
    shutil.copyfile(prompt, SPEC / "P4_image.txt")
    prior = historical_exclusions(); save(prior, SPEC / "prior_exclusions.json")
    subprocess.run(["Rscript", "--vanilla", str(ROOT / "scripts/main_study/generate_pdf_png300_32.R"),
                    "streams", str(SPEC), str(OUT)], cwd=ROOT, check=True)
    states = rng_states(load(SPEC / "rng_streams.json"))
    old = {tuple(s) for item in prior["stream_sources"] for s in item["states"]}
    if len(states) != 33 or len(set(states)) != 33 or set(states) & old:
        raise ValueError("Reserved stream collision; no generation")
    sources = [Path(__file__), ROOT / "scripts/main_study/generate_pdf_png300_32.R",
        ROOT / "tests/test_pdf_png300_32_preparation.py", ROOT / "scripts/generate_matched_figures.py",
        ROOT / "scripts/verify_matched_figures.py", ROOT / "src/km_analysis/figures.py",
        *[ROOT / f"R/{f}.R" for f in ("protocol", "simulation", "reference", "io")],
        ROOT / "environment.yml", ROOT / "environment/conda-osx-arm64.lock",
        ROOT / "environment/cran-packages.json", ROOT / "environment/conda-packages.json",
        ROOT / "scripts/check_environment.py"]
    sources += sorted(p for p in SPEC.iterdir() if p.is_file())
    save(dict(study_id=STUDY, scope="inputs_and_assignment_only", before_data_generation=True,
        before_model_calls=True, baseline_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        files_sha256={str(p.relative_to(ROOT)): digest(p) for p in sources}), SPEC / "DESIGN_LOCK.json")
    print("32 data streams, 8 repeat datasets and 80 assignments frozen before generation.", flush=True)


def check_lock():
    lock = load(SPEC / "DESIGN_LOCK.json")
    for name, expected in lock["files_sha256"].items():
        if digest(ROOT / name) != expected:
            raise ValueError("Frozen source changed: " + name)
    return lock


def prepare():
    lock = check_lock()
    subprocess.run([sys.executable, str(ROOT / "scripts/check_environment.py")], check=True)
    if (OUT / "READY_INPUTS.json").exists():
        raise FileExistsError("Completed package retained; use verify")
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT / "data").exists():
        subprocess.run(["Rscript", "--vanilla", str(ROOT / "scripts/main_study/generate_pdf_png300_32.R"),
                        "generate", str(SPEC), str(OUT)], cwd=ROOT, check=True)
        save({str(p.relative_to(OUT)): digest(p) for p in sorted((OUT / "data").rglob("*")) if p.is_file()}, OUT / "GENERATION_LOCK.json")
    if not (OUT / "GENERATION_LOCK.json").exists():
        raise RuntimeError("Partial data generation retained; inspect, never redraw")
    for p, h in load(OUT / "GENERATION_LOCK.json").items():
        if digest(OUT / p) != h:
            raise ValueError("Generated data changed")
    from km_analysis.figures import load_dataset, render_command, TEMPLATE
    from scripts.generate_matched_figures import draw_pdf
    from scripts.verify_matched_figures import verify_pdf, verify_png
    from PIL import Image, ImageDraw
    import reportlab
    datasets, inputs, repeats, schedule = make_design()
    prior = load(SPEC / "prior_exclusions.json")
    old_signatures = {r["observed_signature"] for r in prior["record_files"]}
    old_states = {tuple(s) for row in prior["stream_sources"] for s in row["states"]}
    signatures = [observed_signature(OUT / "data/scoring_only" / d["dataset"] / "records.csv") for d in datasets]
    generated_states = rng_states(load(OUT / "data/scoring_only/seed_manifest.json"))
    if len(set(signatures)) != 32 or set(signatures) & old_signatures or set(generated_states) & old_states:
        raise ValueError("Historical or internal data/stream reuse")
    font = Path(reportlab.__file__).parent / "fonts/Vera.ttf"
    poppler = shutil.which("pdftoppm")
    if not poppler:
        raise FileNotFoundError("Pinned Poppler required")
    qa, tiles, rendered = [], [], {}
    (OUT / "qa").mkdir(exist_ok=True)
    for d in datasets:
        ds = d["dataset"]; arms = load_dataset(OUT / "data", ds)
        assigned = {r["representation"]: r["input_id"] for r in inputs if r["dataset"] == ds}
        pdf = OUT / "inputs" / assigned["PDF"] / "figure.pdf"
        png = OUT / "inputs" / assigned["PNG300"] / "figure.png"
        for p in (pdf, png): p.parent.mkdir(parents=True, exist_ok=True)
        if not pdf.exists(): draw_pdf(pdf, arms, font, marks_shown=True, table_shown=True)
        native = verify_pdf(pdf, arms)
        if not png.exists():
            subprocess.run(render_command(poppler, pdf, png.with_suffix(""), 300), check=True, capture_output=True)
        raster = verify_png(png, pdf, 300, poppler)
        for fmt, path in [("PDF", pdf), ("PNG300", png)]:
            rendered[assigned[fmt]] = dict(input=str(path.relative_to(OUT)), input_sha256=digest(path))
        qa.append(dict(dataset=ds, pdf=native, png=raster))
        with Image.open(png) as im:
            preview=im.convert("RGB"); preview.thumbnail((900, 675))
            tile=Image.new("RGB", (920, 705), "white"); tile.paste(preview, (10, 25))
            ImageDraw.Draw(tile).text((10, 6), ds, fill="black"); tiles.append(tile)
        print("Verified " + ds, flush=True)
    for offset in range(0, 32, 4):
        sheet=Image.new("RGB", (1840, 1410), "#dddddd")
        for i, tile in enumerate(tiles[offset:offset+4]): sheet.paste(tile, ((i%2)*920, (i//2)*705))
        sheet.save(OUT / "qa" / f"contact_{offset//4+1:02d}.png")
    for r in schedule:
        r.update(rendered[r["input_id"]])
        manifest=OUT / "session_manifests" / (r["session_id"] + ".json")
        public=dict(groups={"A":r["n_per_group"], "B":r["n_per_group"]}, time_unit="months", code_seed=r["code_seed"])
        if manifest.exists():
            if load(manifest) != public: raise ValueError("Changed session manifest")
        else: save(public, manifest)
        r.update(manifest=str(manifest.relative_to(OUT)), manifest_sha256=digest(manifest),
                 prompt="source_snapshot/docs/proposals/" + STUDY + "/P4_image.txt",
                 prompt_sha256=digest(SPEC / "P4_image.txt"))
    runtime=dict(python=sys.version, Rscript=shutil.which("Rscript"),
        packages={p:importlib.metadata.version(p) for p in ("reportlab", "pypdf", "pdfplumber", "Pillow")},
        poppler=poppler, poppler_sha256=digest(poppler), font_sha256=digest(font), template=TEMPLATE,
        render_options=["300 dpi", "full MediaBox", "text/vector antialiasing", "no resizing/cropping/sharpening"])
    products={"schedule.json":schedule, "figure_verification.json":qa, "runtime.json":runtime,
        "data_exclusions.json":dict(passed=True, prior_record_files=len(prior["record_files"]),
            prior_unique_datasets=len(old_signatures), prior_rng_states=len(old_states), new_unique_datasets=32,
            observed_signatures=signatures, no_historical_data_or_stream_reuse=True)}
    for name, value in products.items():
        if (OUT / name).exists():
            if load(OUT / name) != value: raise ValueError("Changed partial preparation: " + name)
        else: save(value, OUT / name)
    for name in lock["files_sha256"]:
        dest=OUT / "source_snapshot" / name; dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists(): shutil.copyfile(ROOT / name, dest)
        if digest(dest) != lock["files_sha256"][name]: raise ValueError("Snapshot changed")
    check_lock()
    save(dict(prepared=True, independent_datasets=32, unique_inputs=64, primary_sessions=64,
        repeat_sessions=16, total_sessions=80, model_calls=0, live_execution_allowed=False,
        analysis_frozen=False, execution_frozen=False, design_lock_sha256=digest(SPEC / "DESIGN_LOCK.json"),
        artifacts_sha256={str(p.relative_to(OUT)):digest(p) for p in sorted(OUT.rglob("*")) if p.is_file()}), OUT / "READY_INPUTS.json")
    print("Input package ready: 32 datasets, 64 figures, 80 assignments; zero model calls.", flush=True)


def verify():
    check_lock()
    ready=load(OUT / "READY_INPUTS.json")
    if digest(SPEC / "DESIGN_LOCK.json") != ready["design_lock_sha256"]:
        raise ValueError("Design lock changed")
    for name, h in ready["artifacts_sha256"].items():
        if digest(OUT / name) != h: raise ValueError("Artifact changed: " + name)
    datasets, inputs, repeats, expected=make_design()
    actual=load(OUT / "schedule.json")
    validate_design(datasets, inputs, repeats, actual)
    for a, e in zip(actual, expected):
        if any(a[k] != v for k,v in e.items()): raise ValueError("Frozen assignment changed")
        manifest=load(OUT / a["manifest"])
        if manifest != dict(groups={"A":a["n_per_group"],"B":a["n_per_group"]},time_unit="months",code_seed=a["code_seed"]):
            raise ValueError("Nonpublic/wrong manifest content")
        if digest(OUT / a["input"]) != a["input_sha256"] or digest(OUT / a["manifest"]) != a["manifest_sha256"]:
            raise ValueError("Session input binding changed")
    print(json.dumps(dict(passed=True,datasets=32,figures=64,primary_sessions=64,repeat_sessions=16,
                         artifacts_verified=len(ready["artifacts_sha256"]),model_calls=0)))


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=["freeze","prepare","verify"])
    args=parser.parse_args()
    {"freeze":freeze,"prepare":prepare,"verify":verify}[args.action]()
