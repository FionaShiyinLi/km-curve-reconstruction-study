"""Protect primary/repeat identity, information boundaries and no-overwrite rules."""
import copy
import csv
import json

import pytest

from scripts.main_study import prepare_pdf_png300_32 as study


def test_exact_primary_pairs_and_prespecified_repeats():
    datasets, inputs, repeats, rows = study.make_design()
    assert study.make_design() == (datasets, inputs, repeats, rows)
    for dataset in datasets:
        assigned = [r for r in rows if r["dataset"] == dataset["dataset"]]
        primary = [r for r in assigned if r["primary_attempt"]]
        assert {r["representation"] for r in primary} == {"PDF", "PNG300"}
        assert len(primary) == 2
        repeated = dataset in repeats
        assert len(assigned) == (4 if repeated else 2)
        if repeated:
            for fmt in ("PDF", "PNG300"):
                a, b = [r for r in assigned if r["representation"] == fmt]
                assert a["input_id"] == b["input_id"]
                assert a["code_seed"] != b["code_seed"]
                assert a["primary_attempt"] and not b["primary_attempt"]


@pytest.mark.parametrize("corruption", ["repeat_as_primary", "duplicate_seed", "wrong_input",
    "wrong_model", "duplicate_assignment", "repeat_in_primary_block", "changed_dropout", "changed_subset"])
def test_reject_invalid_design(corruption):
    datasets, inputs, repeats, rows = copy.deepcopy(study.make_design())
    if corruption == "repeat_as_primary": rows[64]["primary_attempt"] = True
    elif corruption == "duplicate_seed": rows[-1]["code_seed"] = rows[0]["code_seed"]
    elif corruption == "wrong_input": rows[0]["input_id"] = rows[1]["input_id"]
    elif corruption == "wrong_model": rows[-1]["effort"] = "high"
    elif corruption == "duplicate_assignment": rows[0] = rows[1].copy()
    elif corruption == "repeat_in_primary_block": rows[64]["block"] = 8
    elif corruption == "changed_dropout": datasets[0]["dropout_rate"] = .04
    elif corruption == "changed_subset": repeats[-1] = repeats[0].copy()
    with pytest.raises(ValueError): study.validate_design(datasets, inputs, repeats, rows)


def test_signature_detects_relabelled_and_reordered_old_data(tmp_path):
    a = tmp_path / "a.csv"; b = tmp_path / "b.csv"
    fields = ["dataset_id", "participant_id", "group", "observed_time", "event"]
    records = [["old", "p1", "A", "1.5", "1"], ["old", "p2", "B", "2.5", "0"]]
    for path, content in [(a, records), (b, [["new", "q2", "B", "2.5", "0"], ["new", "q1", "A", "1.5", "1"]])]:
        with path.open("w", newline="") as handle:
            writer = csv.writer(handle); writer.writerow(fields); writer.writerows(content)
    assert study.observed_signature(a) == study.observed_signature(b)


def test_freeze_refuses_existing_study_before_environment_or_generation(tmp_path, monkeypatch):
    existing = tmp_path / "frozen"; existing.mkdir()
    monkeypatch.setattr(study, "SPEC", existing)
    monkeypatch.setattr(study, "OUT", tmp_path / "new")
    with pytest.raises(FileExistsError): study.freeze()
    assert not (tmp_path / "new").exists()


def test_lock_rejects_changed_source(tmp_path, monkeypatch):
    spec = tmp_path / "spec"; spec.mkdir()
    source = tmp_path / "input.txt"; source.write_text("original")
    study.save({"files_sha256": {"input.txt": study.digest(source)}}, spec / "DESIGN_LOCK.json")
    monkeypatch.setattr(study, "ROOT", tmp_path); monkeypatch.setattr(study, "SPEC", spec)
    study.check_lock()
    source.write_text("changed")
    with pytest.raises(ValueError, match="Frozen source changed"): study.check_lock()


def test_save_never_overwrites_existing_evidence(tmp_path):
    target = tmp_path / "evidence.json"
    study.save({"original": True}, target)
    with pytest.raises(FileExistsError): study.save({"replacement": True}, target)
    assert json.loads(target.read_text()) == {"original": True}
