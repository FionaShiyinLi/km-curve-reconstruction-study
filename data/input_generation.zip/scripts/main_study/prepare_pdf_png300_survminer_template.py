#!/usr/bin/env python3
"""Freeze 16 observed-data survminer plots as 32 blinded PDF/PNG300 inputs."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import random
import re
import subprocess
import tempfile

from PIL import Image, ImageDraw
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[2]
NAME = "pdf_png300_survminer_template_v1"
SPEC = ROOT / "docs/proposals" / NAME
OUT = ROOT / "outputs/evaluation" / NAME
SOURCE = ROOT / "outputs/evaluation/pdf_png300_32_v1"
OLD_SCHEDULE = ROOT / "docs/proposals/pdf_png300_32_budget_v2/schedule.json"
OLD_ANALYSIS = ROOT / "outputs/evaluation/pdf_png300_32_budget_v2/analysis"
PLOTTER = ROOT / "scripts/main_study/render_pdf_png300_survminer_template.R"
RSCRIPT = Path(os.environ.get(
    "PDF_PNG300_SURVMINER_RSCRIPT",
    "Rscript"))
SELECT_SEED = 2026092401
ORDER_SEED = 2026092402
ID_SEED = 2026092403
RISK_TIMES = tuple(range(0, 37, 6))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def source_rows():
    lock = read(ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json")
    if sha(SOURCE / "schedule.json") != lock["artifacts_sha256"]["schedule.json"]:
        raise ValueError("Original input schedule changed")
    if sha(OLD_SCHEDULE) != read(
        ROOT / "docs/proposals/pdf_png300_32_budget_v2/WORKFLOW_LOCK.json"
    )["files_sha256"][str(OLD_SCHEDULE.relative_to(ROOT))]:
        raise ValueError("Original execution schedule changed")
    old_lock = read(OLD_ANALYSIS / "ANALYSIS_LOCK.json")
    for name in ("scores.csv", "dataset_pairs.csv"):
        if sha(OLD_ANALYSIS / name) != old_lock["files_sha256"][name]:
            raise ValueError("Original frozen analysis changed: " + name)
    rows = [row for row in read(OLD_SCHEDULE)
            if row["primary_attempt"] and row["representation"] == "PNG300"]
    if len(rows) != 32 or Counter(row["scenario"] for row in rows) != {
            scenario: 8 for scenario in ("S1", "S2", "S3", "S4")}:
        raise ValueError("Expected original 32 distinct primary PNG datasets")
    if len({row["dataset"] for row in rows}) != 32:
        raise ValueError("Repeated source dataset")
    for row in rows:
        dataset = row["dataset"]
        for name in ("records.csv", "km_A.csv", "km_B.csv"):
            rel = f"data/scoring_only/{dataset}/{name}"
            if sha(SOURCE / rel) != lock["artifacts_sha256"][rel]:
                raise ValueError("Original observed source changed: " + rel)
        manifest = read(SOURCE / row["manifest"])
        if manifest != {"groups": {"A": row["n_per_group"], "B": row["n_per_group"]},
                        "time_unit": "months", "code_seed": row["code_seed"]}:
            raise ValueError("Source public manifest differs from schedule")
    risk = "data/scoring_only/risk_tables.csv"
    if sha(SOURCE / risk) != lock["artifacts_sha256"][risk]:
        raise ValueError("Original risk table changed")
    return rows


def planned_schedule(rows):
    by_scenario = defaultdict(list)
    for row in rows:
        by_scenario[row["scenario"]].append(row)
    selector = random.Random(SELECT_SEED)
    selected = {scenario: sorted(selector.sample(
        sorted(by_scenario[scenario], key=lambda row: row["dataset"]), 4),
        key=lambda row: row["dataset"])
        for scenario in ("S1", "S2", "S3", "S4")}
    order = random.Random(ORDER_SEED)
    for scenario in selected:
        order.shuffle(selected[scenario])
    blocks = []
    for block in range(1, 5):
        batch = [(selected[scenario][block - 1], representation)
                 for scenario in ("S1", "S2", "S3", "S4")
                 for representation in ("PDF", "PNG300")]
        order.shuffle(batch)
        blocks.extend((block, row, representation) for row, representation in batch)
    ids = [f"SVI{i:03d}" for i in range(1, 33)]
    random.Random(ID_SEED).shuffle(ids)
    result = []
    for number, ((block, source, representation), input_id) in enumerate(zip(blocks, ids), 1):
        session = f"PP32SV_R{number:03d}"
        suffix = ".pdf" if representation == "PDF" else ".png"
        result.append(dict(
            session_id=session, dataset=source["dataset"], scenario=source["scenario"],
            n_per_group=source["n_per_group"], pattern=source["pattern"],
            representation=representation, primary_attempt=True, block=block,
            input_id=input_id, input=f"inputs/{input_id}/figure{suffix}",
            manifest=f"session_manifests/{session}.json",
            code_seed=source["code_seed"],
            source_png_primary_session=source["session_id"],
            model="claude-opus-5-5", effort="medium"))
    if len(result) != 32 or Counter(row["scenario"] for row in result) != {
            scenario: 8 for scenario in selected}:
        raise ValueError("Unbalanced schedule")
    return result


def render_png(pdf, png):
    png.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["pdftoppm", "-f", "1", "-singlefile", "-r", "300",
                    "-png", str(pdf), str(png.with_suffix(""))],
                   check=True, capture_output=True)


def check_pdf(path, dataset):
    reader = PdfReader(path)
    if len(reader.pages) != 1:
        raise ValueError("Expected one-page PDF: " + str(path))
    page = reader.pages[0]
    if (float(page.mediabox.width), float(page.mediabox.height)) != (432, 324):
        raise ValueError("Wrong PDF page dimensions: " + str(path))
    if len(page.images) or page.get("/Annots") or page.get("/Metadata"):
        raise ValueError("Unexpected raster image, annotation or metadata: " + str(path))
    text = page.extract_text()
    required = ("Group A", "Group B", "Number at risk", "Time (months)",
                "Survival probability")
    if (any(label not in text for label in required) or
        dataset in text or "PP32_" in text or
        re.search(r"(?:\bp\s*[=<]|95%\s*CI\b|confidence interval\b)", text, re.I)):
        raise ValueError("Missing public text or private/statistical text in PDF")
    operators = {operator for _, operator in page.get_contents().operations}
    if not {b"m", b"l"}.issubset(operators) or not ({b"Tj", b"TJ"} & operators):
        raise ValueError("Expected native vector curves and a text layer")
    if b"Do" in operators:
        raise ValueError("PDF contains an image XObject")
    metadata = str(reader.metadata or {})
    if dataset in metadata or "PP32_" in metadata:
        raise ValueError("Dataset identifier leaked in PDF metadata")


def check_pair(pdf, png, dataset, rerender=True):
    check_pdf(pdf, dataset)
    with Image.open(png) as image:
        if image.mode != "RGB" or image.size != (1800, 1350):
            raise ValueError("Expected full-page 300-dpi RGB PNG: " + str(png))
        original = image.tobytes()
    if rerender:
        with tempfile.TemporaryDirectory() as directory:
            second = Path(directory) / "figure.png"
            render_png(pdf, second)
            with Image.open(second) as image:
                if image.mode != "RGB" or image.size != (1800, 1350) or image.tobytes() != original:
                    raise ValueError("PNG is not a pixel-exact 300-dpi rendering of PDF")


def contact_sheets(schedule):
    by_dataset = {row["dataset"]: row for row in schedule if row["representation"] == "PNG300"}
    for scenario in ("S1", "S2", "S3", "S4"):
        canvas = Image.new("RGB", (1200, 940), "white")
        draw = ImageDraw.Draw(canvas)
        for index, row in enumerate(sorted(
                (row for row in by_dataset.values() if row["scenario"] == scenario),
                key=lambda row: row["dataset"])):
            x = (index % 2) * 600
            y = (index // 2) * 470
            draw.text((x + 8, y + 3), row["dataset"], fill="black")
            with Image.open(OUT / row["input"]) as picture:
                canvas.paste(picture.resize((600, 450)), (x, y + 20))
        target = OUT / "data/scoring_only/display_qa" / f"{scenario}.png"
        target.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(target)


def prepare():
    sources = source_rows()
    if OUT.exists() or (SPEC / "INPUT_LOCK.json").exists():
        raise FileExistsError("New-template package already exists; use verify")
    if not RSCRIPT.is_file():
        raise FileNotFoundError("Supplemental survminer R environment missing: " + str(RSCRIPT))
    rows = planned_schedule(sources)
    by_dataset = defaultdict(dict)
    for row in rows:
        by_dataset[row["dataset"]][row["representation"]] = row
    if len(by_dataset) != 16 or any(set(pair) != {"PDF", "PNG300"} for pair in by_dataset.values()):
        raise ValueError("Expected 16 exact PDF/PNG pairs")
    source_by_dataset = {row["dataset"]: row for row in sources}
    for dataset, pair in sorted(by_dataset.items()):
        pdf = OUT / pair["PDF"]["input"]
        png = OUT / pair["PNG300"]["input"]
        qa = OUT / "data/scoring_only/figure_qa" / f"{dataset}.json"
        pdf.parent.mkdir(parents=True, exist_ok=True)
        qa.parent.mkdir(parents=True, exist_ok=True)
        folder = SOURCE / "data/scoring_only" / dataset
        command = [str(RSCRIPT), "--vanilla", str(PLOTTER),
                   str(folder / "records.csv"), str(SOURCE / "data/scoring_only/risk_tables.csv"),
                   str(folder / "km_A.csv"), str(folder / "km_B.csv"), str(pdf), str(qa)]
        subprocess.run(command, check=True, capture_output=True, text=True)
        render_png(pdf, png)
        check_pair(pdf, png, dataset)
        quality = read(qa)
        if (quality["dataset"] != dataset or "4.5.2" not in quality["r"] or
            quality["survminer"] != "0.5.2" or
            quality["survival"] != "3.8.3" or quality["ggplot2"] != "4.0.3" or
            quality["risk_rows_verified"] != 14 or
            quality["reference_km_verified"] is not True or
            quality["confidence_interval"] is not False or
            quality["p_value"] is not False):
            raise ValueError("Figure-level R QA failed: " + dataset)
        print("Verified", dataset, flush=True)
    for row in rows:
        source = source_by_dataset[row["dataset"]]
        manifest = read(SOURCE / source["manifest"])
        write(OUT / row["manifest"], manifest)
        row["manifest_sha256"] = sha(OUT / row["manifest"])
        row["input_sha256"] = sha(OUT / row["input"])
    write(OUT / "schedule.json", rows)
    write(OUT / "selection.json", dict(
        selection_seed=SELECT_SEED, order_seed=ORDER_SEED, neutral_id_seed=ID_SEED,
        rule="sample four IDs per scenario without old scores; shuffle one per scenario into each of four balanced eight-session blocks",
        selected={scenario: sorted(dataset for dataset, pair in by_dataset.items()
                                   if pair["PDF"]["scenario"] == scenario)
                  for scenario in ("S1", "S2", "S3", "S4")}))
    contact_sheets(rows)
    write(OUT / "VALIDATION.json", dict(
        independent_datasets=16, scenarios={s: 4 for s in ("S1", "S2", "S3", "S4")},
        paired_inputs=16, vector_pdfs=16, pixel_exact_pdf_png_pairs=16,
        public_manifests=32, primary_sessions=32, model_calls=0,
        fixed_risk_times=RISK_TIMES, pdf_page_points=(432, 324),
        png_pixels=(1800, 1350), provider_execution_started=False,
        poppler=subprocess.check_output(["pdftoppm", "-v"],
                                        stderr=subprocess.STDOUT, text=True).splitlines()[0]))
    files = [SPEC / name for name in ("PROTOCOL.md", "ANALYSIS_PLAN.json",
                                      "PLOT_ENV.explicit.txt")]
    files += [Path(__file__), PLOTTER,
              ROOT / "R/reference.R", ROOT / "R/pdf_png300_scoring.R",
              ROOT / "R/pdf_png300_survminer_template.R",
              ROOT / "tests/test_pdf_png300_survminer_inputs.py",
              ROOT / "tests/test_pdf_png300_survminer_analysis.R",
              ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json",
              OLD_ANALYSIS / "ANALYSIS_LOCK.json",
              OLD_ANALYSIS / "scores.csv", OLD_ANALYSIS / "dataset_pairs.csv"]
    files += sorted(path for path in OUT.rglob("*") if path.is_file())
    write(SPEC / "INPUT_LOCK.json", dict(
        study_id=NAME, state="inputs_and_analysis_rules_frozen",
        model_calls=0, files_sha256={str(path.relative_to(ROOT)): sha(path) for path in files}))
    verify()
    print("Frozen 16 public survminer PDF/PNG pairs and 32 sessions; 0 model calls")


def verify():
    sources = source_rows()
    lock = read(SPEC / "INPUT_LOCK.json")
    if lock["study_id"] != NAME or lock["state"] != "inputs_and_analysis_rules_frozen":
        raise ValueError("Wrong input lock state")
    for relative, expected in lock["files_sha256"].items():
        if sha(ROOT / relative) != expected:
            raise ValueError("Frozen file changed: " + relative)
    rows = read(OUT / "schedule.json")
    planned = planned_schedule(sources)
    if len(rows) != 32 or any(
            {k: row[k] for k in expected} != expected
            for row, expected in zip(rows, planned)):
        raise ValueError("Schedule differs from seed-fixed plan")
    if Counter(row["scenario"] for row in rows) != {s: 8 for s in ("S1", "S2", "S3", "S4")}:
        raise ValueError("Scenario balance changed")
    pair = defaultdict(dict)
    for row in rows:
        if sha(OUT / row["input"]) != row["input_sha256"] or sha(OUT / row["manifest"]) != row["manifest_sha256"]:
            raise ValueError("Session file hash changed")
        pair[row["dataset"]][row["representation"]] = row
    if len(pair) != 16 or any(set(value) != {"PDF", "PNG300"} for value in pair.values()):
        raise ValueError("Pair map changed")
    for dataset, value in pair.items():
        if value["PDF"]["code_seed"] != value["PNG300"]["code_seed"]:
            raise ValueError("Paired code seeds differ")
        check_pair(OUT / value["PDF"]["input"], OUT / value["PNG300"]["input"], dataset)
    checks = read(OUT / "VALIDATION.json")
    if checks["model_calls"] != 0 or checks["pixel_exact_pdf_png_pairs"] != 16:
        raise ValueError("Validation state changed")
    print("Verified frozen survminer input package: 16 pairs, 32 sessions")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "verify"))
    command = parser.parse_args().action
    (prepare if command == "prepare" else verify)()
