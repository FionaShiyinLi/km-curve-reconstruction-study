#!/usr/bin/env python3
"""Freeze the 160-session follow-up schedule from the prepared, hash-locked inputs; never call a model.

Conditions on the 32 original-cohort datasets (inputs generated and verified by
prepare_pdf_png300_followup_inputs.py under outputs/evaluation/pdf_png300_followup_inputs_v1/):
  NOMARK_PDF     native PDF without censoring marks
  NOMARK_PNG300  its 300-dpi PNG
  PNG150         locked primary PDF at 150 dpi
  PNG100         locked primary PDF at 100 dpi
  JPEG100        the 100-dpi render as JPEG quality 75

This script copies the inputs into the study layout the frozen runner expects
(inputs/<input_id>/figure.<ext>), writes one public session manifest per
session (groups, time unit, code seed), a randomized block schedule, the
analysis plan reference and an INPUT_LOCK with every file hash. Code seeds reuse
the dataset's original primary seeds (PDF seed for NOMARK_PDF; PNG300 seed for
the four raster conditions), as the earlier figure experiments did.

Usage: python3 scripts/main_study/prepare_pdf_png300_followup.py prepare|verify
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import random
import shutil

ROOT = Path(__file__).resolve().parents[2]
NAME = "pdf_png300_followup_v1"
SPEC = ROOT / "docs/proposals" / NAME
OUT = ROOT / "outputs/evaluation" / NAME
INPUTS = ROOT / "outputs/evaluation/pdf_png300_followup_inputs_v1"
SOURCE = ROOT / "outputs/evaluation/pdf_png300_32_v1"
OLD_SCHEDULE = ROOT / "docs/proposals/pdf_png300_32_budget_v2/schedule.json"
OLD_ANALYSIS = ROOT / "outputs/evaluation/pdf_png300_32_budget_v2/analysis"
ORDER_SEED, ID_SEED = 2026100404, 2026100405
CONDITIONS = {"NOMARK_PDF": ("nomark/{ds}/figure.pdf", ".pdf", "PDF"),
              "NOMARK_PNG300": ("nomark/{ds}/figure.png", ".png", "PNG300"),
              "PNG150": ("res150/{ds}/figure.png", ".png", "PNG300"),
              "PNG100": ("res100/{ds}/figure.png", ".png", "PNG300"),
              "JPEG100": ("jpeg100/{ds}/figure.jpg", ".jpg", "PNG300")}
SCENARIOS = ("S1", "S2", "S3", "S4")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def source_rows():
    """Original primary assignments with verified locks; returns {dataset: {PDF: row, PNG300: row}}."""
    lock = read(ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json")
    if sha(SOURCE / "schedule.json") != lock["artifacts_sha256"]["schedule.json"]:
        raise ValueError("Original input schedule changed")
    if sha(OLD_SCHEDULE) != read(ROOT / "docs/proposals/pdf_png300_32_budget_v2/WORKFLOW_LOCK.json")[
            "files_sha256"][str(OLD_SCHEDULE.relative_to(ROOT))]:
        raise ValueError("Original execution schedule changed")
    old_lock = read(OLD_ANALYSIS / "ANALYSIS_LOCK.json")
    for name in ("scores.csv", "dataset_pairs.csv"):
        if sha(OLD_ANALYSIS / name) != old_lock["files_sha256"][name]:
            raise ValueError("Original frozen analysis changed: " + name)
    rows = [row for row in read(OLD_SCHEDULE) if row["primary_attempt"]]
    by = defaultdict(dict)
    for row in rows:
        by[row["dataset"]][row["representation"]] = row
    if len(by) != 32 or any(set(v) != {"PDF", "PNG300"} for v in by.values()):
        raise ValueError("Expected 32 datasets with one PDF and one PNG300 primary assignment")
    if Counter(v["PDF"]["scenario"] for v in by.values()) != {s: 8 for s in SCENARIOS}:
        raise ValueError("Original scenario balance changed")
    for ds, v in by.items():
        for rep, row in v.items():
            if sha(SOURCE / row["input"]) != row["input_sha256"]:
                raise ValueError("Frozen source input changed: " + row["input"])
            manifest = read(SOURCE / row["manifest"])
            if manifest != {"groups": {"A": row["n_per_group"], "B": row["n_per_group"]},
                            "time_unit": "months", "code_seed": row["code_seed"]}:
                raise ValueError("Source public manifest differs from schedule: " + row["session_id"])
    return by


def input_manifest():
    manifest = read(INPUTS / "MANIFEST.json")
    lock = read(INPUTS / "INPUT_LOCK.json")
    if sha(INPUTS / "MANIFEST.json") != lock["manifest_sha256"]:
        raise ValueError("Prepared input manifest changed")
    by = {row["dataset"]: row for row in manifest["datasets"]}
    if len(by) != 32 or manifest.get("model_calls") != 0:
        raise ValueError("Prepared inputs incomplete")
    for ds, row in by.items():
        for rel, info in row["files"].items():
            if sha(INPUTS / rel.replace("/", f"/{ds}/", 1)) != info["sha256"]:
                raise ValueError("Prepared input changed: " + ds + " " + rel)
        if row.get("primary_png300_pixel_identical_rerender") is not True:
            raise ValueError("Renderer identity check missing for " + ds)
    return manifest, by


def planned_schedule(sources, prepared):
    order = random.Random(ORDER_SEED)
    datasets = {s: sorted(ds for ds, v in sources.items() if v["PDF"]["scenario"] == s) for s in SCENARIOS}
    for s in SCENARIOS:
        order.shuffle(datasets[s])
    slots = []
    for block in range(1, 9):
        batch = [datasets[s][block - 1] for s in SCENARIOS]
        order.shuffle(batch)
        for ds in batch:
            conditions = list(CONDITIONS)
            order.shuffle(conditions)
            slots.extend((block, ds, c) for c in conditions)
    ids = [f"FUI{i:03d}" for i in range(1, 161)]
    random.Random(ID_SEED).shuffle(ids)
    rows = []
    for number, ((block, ds, condition), input_id) in enumerate(zip(slots, ids), 1):
        pattern, suffix, seed_source = CONDITIONS[condition]
        src = sources[ds][seed_source]
        session = f"PP32FU_R{number:03d}"
        rel = pattern.format(ds=ds)
        rows.append(dict(session_id=session, dataset=ds, scenario=src["scenario"], n_per_group=src["n_per_group"],
                         pattern=src["pattern"], representation=condition, condition=condition, primary_attempt=True,
                         block=block, input_id=input_id, input=f"inputs/{input_id}/figure{suffix}",
                         prepared_input=rel, prepared_input_sha256=prepared[ds]["files"][rel.replace(f"/{ds}/", "/", 1)]["sha256"],
                         manifest=f"session_manifests/{session}.json", code_seed=src["code_seed"],
                         code_seed_source_session=src["session_id"], model="claude-opus-5-5", effort="medium"))
    validate(rows)
    return rows


def validate(rows):
    if len(rows) != 160 or len({r["session_id"] for r in rows}) != 160 or len({r["input_id"] for r in rows}) != 160:
        raise ValueError("Schedule size or identifiers wrong")
    if Counter((r["dataset"], r["condition"]) for r in rows) != Counter({(d, c): 1 for d in {r["dataset"] for r in rows} for c in CONDITIONS}):
        raise ValueError("Each dataset must have each condition exactly once")
    for block in range(1, 9):
        rows_b = [r for r in rows if r["block"] == block]
        if len(rows_b) != 20 or Counter(r["scenario"] for r in rows_b) != {s: 5 for s in SCENARIOS}:
            raise ValueError("Block balance changed")
    for i in range(0, 160, 5):
        if len({r["dataset"] for r in rows[i:i + 5]}) != 1:
            raise ValueError("Conditions of a dataset must be consecutive")
    for i, r in enumerate(rows, 1):
        if r["session_id"] != f"PP32FU_R{i:03d}" or r["block"] != (i - 1) // 20 + 1:
            raise ValueError("Order changed")


def prepare():
    sources = source_rows()
    manifest, prepared = input_manifest()
    if OUT.exists() or (SPEC / "INPUT_LOCK.json").exists():
        raise FileExistsError("Follow-up study package already exists; use verify")
    rows = planned_schedule(sources, prepared)
    for row in rows:
        target = OUT / row["input"]
        target.parent.mkdir(parents=True)
        shutil.copyfile(INPUTS / row["prepared_input"], target)
        row["input_sha256"] = sha(target)
        if row["input_sha256"] != row["prepared_input_sha256"]:
            raise ValueError("Copy changed the input: " + row["session_id"])
        write(OUT / row["manifest"], {"groups": {"A": row["n_per_group"], "B": row["n_per_group"]},
                                      "time_unit": "months", "code_seed": row["code_seed"]})
        row["manifest_sha256"] = sha(OUT / row["manifest"])
    write(OUT / "schedule.json", rows)
    write(OUT / "VALIDATION.json", dict(
        independent_datasets=32, conditions=list(CONDITIONS), sessions=160, inputs_copied=160,
        copied_hashes_match_prepared_manifest=True, prepared_inputs_manifest_sha256=sha(INPUTS / "MANIFEST.json"),
        prepared_inputs_lock_sha256=sha(INPUTS / "INPUT_LOCK.json"), renderer=manifest["renderer"],
        source_input_package_lock_sha256=sha(ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json"),
        source_analysis_lock_sha256=sha(OLD_ANALYSIS / "ANALYSIS_LOCK.json"),
        provider_calls=0, analysis_run=False, live_execution_allowed=False))
    files = [SPEC / "PROTOCOL.md", SPEC / "ANALYSIS_PLAN.json", Path(__file__).resolve(),
             ROOT / "scripts/main_study/prepare_pdf_png300_followup_inputs.py",
             INPUTS / "MANIFEST.json", INPUTS / "INPUT_LOCK.json",
             ROOT / "R/reference.R", ROOT / "R/pdf_png300_scoring.R",
             ROOT / "manuscript/PDF_VS_PNG300/prepare_se_estimands.py",
             ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json",
             OLD_SCHEDULE, OLD_ANALYSIS / "ANALYSIS_LOCK.json", OLD_ANALYSIS / "scores.csv", OLD_ANALYSIS / "dataset_pairs.csv"]
    files += sorted(path for path in OUT.rglob("*") if path.is_file())
    write(SPEC / "INPUT_LOCK.json", dict(study_id=NAME, state="inputs_schedule_and_analysis_rules_frozen",
                                         model_calls=0, live_execution_allowed=False,
                                         files_sha256={str(p.relative_to(ROOT)): sha(p) for p in files}))
    verify()
    print("Frozen: 160 sessions, 32 datasets x 5 conditions, 0 model calls")


def verify():
    sources = source_rows()
    _, prepared = input_manifest()
    lock = read(SPEC / "INPUT_LOCK.json")
    for name, expected in lock["files_sha256"].items():
        if sha(ROOT / name) != expected:
            raise ValueError("Frozen follow-up file changed: " + name)
    rows = read(OUT / "schedule.json")
    validate(rows)
    expected = planned_schedule(sources, prepared)
    for row, plan in zip(rows, expected):
        if {k: v for k, v in row.items() if k not in ("input_sha256", "manifest_sha256")} != plan:
            raise ValueError("Schedule differs from the seeded plan: " + row["session_id"])
        if sha(OUT / row["input"]) != row["input_sha256"] or row["input_sha256"] != row["prepared_input_sha256"]:
            raise ValueError("Study input hash changed: " + row["session_id"])
        if sha(OUT / row["manifest"]) != row["manifest_sha256"]:
            raise ValueError("Session manifest changed: " + row["session_id"])
    print("Verified: 160 assignments, inputs, manifests and lock hashes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "verify"))
    prepare() if parser.parse_args().action == "prepare" else verify()
