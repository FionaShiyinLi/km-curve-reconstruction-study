#!/usr/bin/env python3
"""Freeze and generate 32 fresh datasets; never call a reconstruction model."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
from runner.task_validity_dispatch import digest, load, now, save
from scripts.main_study.prepare_pdf_png300_32 import observed_signature, rng_states

NAME = 'pdf_png300_replication32_v1'
SPEC = ROOT / 'docs/proposals' / NAME
OUT = ROOT / 'outputs/evaluation' / NAME
OLD = ROOT / 'outputs/evaluation/pdf_png300_32_budget_v2/analysis'
SEEDS = dict(data=2026092701, order=2026092702, code=2026092703,
             input_ids=2026092704, repeat_subset=2026092705,
             analysis_reserved=2026092706, combined=2026092707)
SCENARIOS = {'S1': (100, 'noncrossing'), 'S2': (100, 'crossing'),
             'S3': (1000, 'noncrossing'), 'S4': (1000, 'crossing')}


def make_design():
    datasets = [dict(dataset=f'RP32_{s}_D{i:02d}', scenario=s, replicate=i,
                     n_per_group=n, pattern=pattern, dropout_rate=.005)
                for s, (n, pattern) in SCENARIOS.items() for i in range(1, 9)]
    rng = random.Random(SEEDS['repeat_subset'])
    repeats = [r for s in SCENARIOS for r in rng.sample(
        [d for d in datasets if d['scenario'] == s], 4)]
    inputs = [{**d, 'representation': fmt} for d in datasets for fmt in ('PDF', 'PNG300')]
    random.Random(SEEDS['input_ids']).shuffle(inputs)
    for i, row in enumerate(inputs, 1):
        row['input_id'] = f'I{i:03d}'
    lookup = {(r['dataset'], r['representation']): r for r in inputs}
    order = random.Random(SEEDS['order'])
    first = {s: set(order.sample(range(1, 9), 4)) for s in SCENARIOS}
    repeat_first = {s: set(order.sample([r['dataset'] for r in repeats if r['scenario'] == s], 2))
                    for s in SCENARIOS}
    rows = []
    for attempt, pool, count, offset in [(1, datasets, 8, 0), (2, repeats, 4, 8)]:
        by_s = {s: [r for r in pool if r['scenario'] == s] for s in SCENARIOS}
        for b in range(count):
            block = [by_s[s][b] for s in SCENARIOS]
            order.shuffle(block)
            for d in block:
                pdf_first = (d['replicate'] in first[d['scenario']] if attempt == 1
                             else d['dataset'] in repeat_first[d['scenario']])
                formats = ('PDF', 'PNG300') if pdf_first else ('PNG300', 'PDF')
                for fmt in formats:
                    rows.append({**lookup[d['dataset'], fmt], 'attempt': attempt,
                                 'primary_attempt': attempt == 1, 'block': offset + b + 1})
    codes = random.Random(SEEDS['code']).sample(range(1, 2**31), 96)
    for i, row in enumerate(rows, 1):
        row.update(session_id=f'RP32_R{i:03d}', code_seed=codes[i-1],
                   model='claude-opus-5-5', effort='medium')
    validate_design(datasets, inputs, repeats, rows)
    return datasets, inputs, repeats, rows


def validate_design(datasets, inputs, repeats, rows):
    if (len(datasets), len(inputs), len(repeats), len(rows)) != (32, 64, 16, 96):
        raise ValueError('Incorrect replication denominators')
    if len({d['dataset'] for d in datasets}) != 32 or len({r['input_id'] for r in inputs}) != 64:
        raise ValueError('Duplicate datasets or inputs')
    if len({r['dataset'] for r in repeats}) != 16 or len({r['code_seed'] for r in rows}) != 96:
        raise ValueError('Duplicate repeat selections or code seeds')
    for pool, n in [(datasets, 8), (repeats, 4)]:
        if Counter(r['scenario'] for r in pool) != Counter({s: n for s in SCENARIOS}):
            raise ValueError('Scenario balance changed')
    expected = {(d['dataset'], f, 1) for d in datasets for f in ('PDF', 'PNG300')}
    expected |= {(d['dataset'], f, 2) for d in repeats for f in ('PDF', 'PNG300')}
    if {(r['dataset'], r['representation'], r['attempt']) for r in rows} != expected:
        raise ValueError('Missing or duplicate assignment')
    for i, r in enumerate(rows):
        if (r['session_id'] != f'RP32_R{i+1:03d}' or r['block'] != i//8+1 or
                r['primary_attempt'] != (i < 64) or r['attempt'] != (1 if i < 64 else 2)):
            raise ValueError('Phase or order changed')
    for a, b in zip(rows[::2], rows[1::2]):
        if a['dataset'] != b['dataset'] or {a['representation'], b['representation']} != {'PDF', 'PNG300'}:
            raise ValueError('Formats must be adjacent paired sessions')
    for attempt, n in [(1, 4), (2, 2)]:
        for s in SCENARIOS:
            firsts = [r for r in rows[::2] if r['scenario'] == s and r['attempt'] == attempt]
            if Counter(r['representation'] for r in firsts) != Counter(PDF=n, PNG300=n):
                raise ValueError('Format-first balance changed')
    for block in range(1, 13):
        if Counter((r['scenario'], r['representation']) for r in rows if r['block'] == block) != Counter(
                (s, f) for s in SCENARIOS for f in ('PDF', 'PNG300')):
            raise ValueError('Block balance changed')


def source_files():
    paths = [Path(__file__), ROOT/'scripts/main_study/run_pdf_png300_replication.py',
        ROOT/'scripts/main_study/pdf_png300_replication_progress.py',
        ROOT/'scripts/main_study/score_pdf_png300_replication.R',
        ROOT/'scripts/main_study/check_pdf_png300_replication.py',
        ROOT/'tests/test_pdf_png300_replication.py', ROOT/'tests/test_pdf_png300_replication.R',
        ROOT/'scripts/main_study/generate_pdf_png300_32.R',
        ROOT/'scripts/main_study/prepare_pdf_png300_32.py',
        ROOT/'scripts/main_study/run_pdf_png300_32.py',
        ROOT/'scripts/main_study/task_session_watchdog.py',
        ROOT/'scripts/main_study/check_pdf_png300_workflow.py',
        ROOT/'tests/test_task_validity_dispatch.py', ROOT/'tests/test_pdf_png300_scoring.R',
        ROOT/'scripts/generate_matched_figures.py', ROOT/'scripts/verify_matched_figures.py',
        ROOT/'src/km_analysis/figures.py', ROOT/'scripts/check_environment.py',
        ROOT/'scripts/activate_environment.sh', ROOT/'environment.yml',
        ROOT/'docs/proposals/pdf_png300_32_v1/P4_image.txt',
        ROOT/'docs/proposals/pdf_png300_32_budget_v2/execution_config.json']
    paths += [ROOT/f'R/{f}.R' for f in ('protocol', 'simulation', 'reference', 'io', 'pdf_png300_scoring')]
    paths += list((ROOT/'src/runner').glob('*.py'))
    paths += [p for p in (ROOT/'environment').glob('*') if p.is_file()]
    return paths


def freeze():
    if (SPEC/'DESIGN_LOCK.json').exists() or OUT.exists():
        raise FileExistsError('Existing replication retained; never refreeze or redraw')
    subprocess.run([sys.executable, str(ROOT/'scripts/check_environment.py')], check=True)
    datasets, inputs, repeats, rows = make_design()
    prior = dict(record_files=[], stream_sources=[])
    for name in subprocess.check_output(['rg', '--files', '-uu', 'outputs'], cwd=ROOT, text=True).splitlines():
        p = ROOT/name
        if p.name == 'records.csv':
            sig = observed_signature(p)
            if sig: prior['record_files'].append(dict(path=name, sha256=digest(p), observed_signature=sig))
        if p.name == 'seed_manifest.json' or p.name.endswith('_streams.json') or p.name == 'data_exclusions.json':
            prior['stream_sources'].append(dict(path=name, sha256=digest(p), states=rng_states(load(p))))
    if not prior['record_files'] or not prior['stream_sources']:
        raise ValueError('Historical exclusion evidence is missing')
    old_lock = load(OLD/'ANALYSIS_LOCK.json')
    for rel, h in old_lock['files_sha256'].items():
        if digest(OLD/rel) != h: raise ValueError('Original analysis changed: '+rel)
    plan = dict(study_id=NAME, independent_datasets=32, combined_independent_datasets=64,
        primary_sessions=64, repeat_sessions=32, total_sessions=96, seeds=SEEDS,
        generator={'lambda': math.log(2)/12, 'noncrossing_ratio': .75,
          'crossing_early_ratio': 1.5, 'crossing_late_ratio': .5, 'hazard_change': 4,
          'entry_window': 12, 'closure': 36, 'dropout_rate': .005, 'tau': 24,
          'risk_times': list(range(0, 37, 6))},
        primary_analysis='new32_only', pooled_analysis='secondary_cohort_by_scenario_bootstrap',
        stopping_rule='96 attempts; no accuracy-driven stop, expansion or replacement')
    save(SPEC/'plan.json', plan)
    save(SPEC/'prior_exclusions.json', prior)
    for name, records in [('datasets', datasets), ('inputs', inputs), ('repeat_subset', repeats), ('assignments', rows)]:
        save(SPEC/(name+'.json'), records)
    with (SPEC/'datasets.csv').open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(datasets[0]))
        writer.writeheader(); writer.writerows(datasets)
    subprocess.run(['Rscript', '--vanilla', str(ROOT/'scripts/main_study/generate_pdf_png300_32.R'),
                    'streams', str(SPEC), str(OUT)], cwd=ROOT, check=True)
    states = rng_states(load(SPEC/'rng_streams.json'))
    old_states = {tuple(s) for row in prior['stream_sources'] for s in row['states']}
    if len(states) != 33 or len(set(states)) != 33 or set(states) & old_states:
        raise ValueError('RNG stream collision; no generation')
    files = source_files() + list(SPEC.glob('*')) + [OLD/'ANALYSIS_LOCK.json', OLD/'scores.csv', OLD/'dataset_pairs.csv']
    save(SPEC/'DESIGN_LOCK.json', dict(recorded_utc=now(), before_generation=True,
        before_model_calls=True, analysis_frozen=True, baseline_commit=subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        files_sha256={str(p.relative_to(ROOT)): digest(p) for p in files}))
    print('Design, analysis, order and 16 repeat datasets frozen before generation.', flush=True)


def verify_lock(path):
    lock = load(path)
    for rel, h in lock['files_sha256'].items():
        if digest(ROOT/rel) != h: raise ValueError('Frozen file changed: '+rel)
    return lock


def prepare():
    verify_lock(SPEC/'DESIGN_LOCK.json')
    if (SPEC/'INPUT_LOCK.json').exists(): raise FileExistsError('Inputs already complete; use verify')
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT/'data').exists():
        subprocess.run(['Rscript', '--vanilla', str(ROOT/'scripts/main_study/generate_pdf_png300_32.R'),
                        'generate', str(SPEC), str(OUT)], cwd=ROOT, check=True)
        save(OUT/'GENERATION_LOCK.json', {str(p.relative_to(ROOT)): digest(p)
             for p in (OUT/'data').rglob('*') if p.is_file()})
    for rel, h in load(OUT/'GENERATION_LOCK.json').items():
        if digest(ROOT/rel) != h: raise ValueError('Partial generation changed; do not redraw')
    from km_analysis.figures import load_dataset, render_command
    from scripts.generate_matched_figures import draw_pdf
    from scripts.verify_matched_figures import verify_pdf, verify_png
    from PIL import Image, ImageDraw
    import reportlab
    datasets, inputs, repeats, rows = make_design()
    signatures = [observed_signature(OUT/'data/scoring_only'/d['dataset']/'records.csv') for d in datasets]
    prior = load(SPEC/'prior_exclusions.json')
    old = {r['observed_signature'] for r in prior['record_files']}
    if len(set(signatures)) != 32 or set(signatures) & old:
        raise ValueError('Historical or within-replication dataset reuse')
    font = Path(reportlab.__file__).parent/'fonts/Vera.ttf'
    poppler = shutil.which('pdftoppm')
    if not poppler: raise FileNotFoundError('Pinned Poppler required')
    (OUT/'qa').mkdir(exist_ok=True)
    rendered, checks, tiles = {}, [], []
    for i, d in enumerate(datasets, 1):
        arms = load_dataset(OUT/'data', d['dataset'])
        ids = {r['representation']: r['input_id'] for r in inputs if r['dataset'] == d['dataset']}
        pdf = OUT/'inputs'/ids['PDF']/'figure.pdf'
        png = OUT/'inputs'/ids['PNG300']/'figure.png'
        for p in (pdf, png): p.parent.mkdir(parents=True, exist_ok=True)
        if not pdf.exists(): draw_pdf(pdf, arms, font, marks_shown=True, table_shown=True)
        native = verify_pdf(pdf, arms)
        if not png.exists():
            subprocess.run(render_command(poppler, pdf, png.with_suffix(''), 300), check=True, capture_output=True)
        checks.append(dict(dataset=d['dataset'], pdf=native, png=verify_png(png, pdf, 300, poppler)))
        for fmt, p in [('PDF', pdf), ('PNG300', png)]:
            rendered[ids[fmt]] = dict(input=str(p), input_sha256=digest(p))
        with Image.open(png) as im:
            im.thumbnail((600, 450)); tile = Image.new('RGB', (620, 480), 'white')
            tile.paste(im.convert('RGB'), (10, 25)); ImageDraw.Draw(tile).text((10, 5), d['dataset'], fill='black')
            tiles.append(tile)
        save(OUT/'preparation_progress.json', dict(completed=i, expected=32, utc=now()), replace=True)
        print(f'Inputs [{"#"*i}{"-"*(32-i)}] {i}/32', flush=True)
    for offset in range(0, 32, 4):
        sheet = Image.new('RGB', (1240, 960), '#dddddd')
        for i, tile in enumerate(tiles[offset:offset+4]): sheet.paste(tile, ((i%2)*620, (i//2)*480))
        sheet.save(OUT/'qa'/f'contact_{offset//4+1:02d}.png')
    for row in rows:
        row.update(rendered[row['input_id']])
        path = OUT/'session_manifests'/(row['session_id']+'.json')
        public = dict(groups={'A': row['n_per_group'], 'B': row['n_per_group']}, time_unit='months', code_seed=row['code_seed'])
        if path.exists():
            if load(path) != public: raise ValueError('Changed public manifest')
        else: save(path, public)
        row.update(manifest=str(path), manifest_sha256=digest(path))
    save(OUT/'schedule.json', rows)
    save(OUT/'figure_verification.json', checks)
    save(OUT/'data_exclusions.json', dict(passed=True, new_unique_datasets=32,
         prior_unique_datasets=len(old), observed_signatures=signatures))
    files = [p for p in OUT.rglob('*') if p.is_file() and p.name != 'preparation_progress.json']
    save(SPEC/'INPUT_LOCK.json', dict(recorded_utc=now(), design_lock_sha256=digest(SPEC/'DESIGN_LOCK.json'),
        files_sha256={str(p.relative_to(ROOT)): digest(p) for p in files}))
    verify()


def verify():
    verify_lock(SPEC/'DESIGN_LOCK.json')
    inputs = verify_lock(SPEC/'INPUT_LOCK.json')
    if inputs['design_lock_sha256'] != digest(SPEC/'DESIGN_LOCK.json'): raise ValueError('Changed design binding')
    datasets, figures, repeats, expected = make_design()
    actual = load(OUT/'schedule.json')
    validate_design(datasets, figures, repeats, actual)
    for a, e in zip(actual, expected):
        if any(a[k] != v for k, v in e.items()): raise ValueError('Changed schedule')
        for key in ('input', 'manifest'):
            p = Path(a[key]); p.relative_to(OUT)
            if digest(p) != a[key+'_sha256']: raise ValueError('Changed assigned file')
    return actual


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'prepare', 'verify'])
    action = parser.parse_args().action
    result = {'freeze': freeze, 'prepare': prepare, 'verify': verify}[action]()
    if action == 'verify': print(json.dumps(dict(passed=True, datasets=32, sessions=len(result), model_calls=0)))
