#!/usr/bin/env python3
"""Prepare hash-locked inputs for the two follow-up conditions the review asked for.

Conditions, all on the 32 original-cohort datasets (pdf_png300_32_v1):
  nomark   native PDF drawn with the frozen ReportLab template but WITHOUT
           censoring marks (draw_pdf(..., marks_shown=False)), plus its 300-dpi
           PNG rendered with the same pdftoppm flags as the primary study
  res150   the locked primary native PDF rendered at 150 dpi (900 x 675 px)
  res100   the locked primary native PDF rendered at 100 dpi (600 x 450 px)
  jpeg100  the 100-dpi render saved as JPEG, quality 75, 4:2:0 subsampling
           (a screenshot-like lossy raster)

This script generates and verifies inputs only. It makes NO model calls and
does not touch any frozen study directory. The planned LLM runs (one per
dataset and condition, same P4 prompt, model, effort, isolation and resource
limits as the primary study) must be authorized and executed separately;
docs/proposals/pdf_png300_followup_v1/PROTOCOL.md states the design and the
prespecified analysis, and INPUT_LOCK.json records every file hash.

Renderer: the Poppler available in the preparation environment (version in the
manifest) with the primary study's antialiasing flags plus explicit output
dimensions (-scale-to-x/-scale-to-y), because this Poppler rounds 6 in x 300
dpi to 1801 px. With those flags its 300-dpi render of every locked primary PDF
is pixel-identical to the locked primary PNG300, which the script asserts
before writing any new input; geometry, metadata and white-border checks are
applied to every new PNG.

Usage (repository root): python3 scripts/main_study/prepare_pdf_png300_followup_inputs.py
Writes outputs/evaluation/pdf_png300_followup_inputs_v1/.
"""
from __future__ import annotations
import sys
from pathlib import Path
ROOT = next(p for p in Path(__file__).resolve().parents if (p / "pyproject.toml").is_file())
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

import hashlib, importlib.metadata, json, shutil, subprocess
from datetime import datetime, timezone
import reportlab
from PIL import Image
from pypdf import PdfReader
from km_analysis.figures import TEMPLATE, load_dataset, render_command
from scripts.generate_matched_figures import draw_pdf

SOURCE = ROOT / "outputs/evaluation/pdf_png300_32_v1"
OUT = ROOT / "outputs/evaluation/pdf_png300_followup_inputs_v1"
MANIFEST = ROOT / "outputs/evaluation/pdf_png300_32_budget_v2/scoring_manifest.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render(poppler, pdf, prefix, dpi):
    command = render_command(poppler, pdf, prefix, dpi)
    command[-2:-2] = ["-scale-to-x", str(int(6 * dpi)), "-scale-to-y", str(int(4.5 * dpi))]
    subprocess.run(command, check=True, capture_output=True)
    return command


def check_png(path, dpi):
    expected = (int(6 * dpi), int(4.5 * dpi))
    with Image.open(path) as im:
        im.load()
        assert im.format == "PNG" and im.mode == "RGB" and im.size == expected, (path, im.size)
        assert set(im.info) <= {"dpi"} and all(abs(v - dpi) < .05 for v in im.info["dpi"]), im.info
        w, h = im.size
        for box in ((0, 0, w, 1), (0, h - 1, w, h), (0, 0, 1, h), (w - 1, 0, w, h)):
            assert im.crop(box).getextrema() == ((255, 255), (255, 255), (255, 255)), "ink at page edge"
        return dict(width_px=w, height_px=h, pixel_sha256=hashlib.sha256(im.tobytes()).hexdigest())


def check_nomark_pdf(path, arms):
    reader = PdfReader(str(path))
    page = reader.pages[0]
    assert len(reader.pages) == 1 and list(map(float, page.mediabox)) == [0, 0, 432, 324]
    assert not page["/Resources"].get("/XObject"), "no raster objects allowed"
    text = page.extract_text() or ""
    # Curve geometry is checked by stroke count: two curves, no censor strokes.
    content = page.get_contents().get_data().decode("latin-1")
    strokes = content.count(" S\n") + content.count(" S\r")
    return dict(pages=1, text_chars=len(text), stroke_operators=strokes,
                expected_marks_if_drawn=sum(len(arms[g]["censors"]) for g in ("A", "B")))


def main():
    sessions = json.loads(MANIFEST.read_text())["sessions"]
    datasets = sorted({(a["dataset"], a["input"]) for a in sessions if a["representation"] == "PDF" and a["primary_attempt"]})
    assert len(datasets) == 32
    poppler = shutil.which("pdftoppm")
    assert poppler, "pdftoppm required"
    version = subprocess.run([poppler, "-v"], capture_output=True, text=True).stderr.strip().splitlines()[0]
    font = Path(reportlab.__file__).parent / "fonts/Vera.ttf"
    if OUT.exists():
        raise SystemExit(f"{OUT} exists; remove or rename before regenerating")
    OUT.mkdir(parents=True)
    rows = []
    png_of = {a["dataset"]: a["input"] for a in sessions if a["representation"] == "PNG300" and a["primary_attempt"]}
    import tempfile
    for ds, rel in datasets:
        source_pdf = SOURCE / rel
        arms = load_dataset(SOURCE / "data", ds)
        with tempfile.TemporaryDirectory() as scratch:
            render(poppler, source_pdf, Path(scratch) / "check", 300)
            with Image.open(Path(scratch) / "check.png") as a, Image.open(SOURCE / png_of[ds]) as b:
                assert a.size == b.size == (1800, 1350) and a.tobytes() == b.tobytes(), f"renderer not pixel-identical for {ds}"
        entry = dict(dataset=ds, scenario=ds.split("_")[1], source_pdf=str(rel), source_pdf_sha256=sha(source_pdf), files={})
        # nomark condition: redraw without censoring marks, render PNG300
        d = OUT / "nomark" / ds; d.mkdir(parents=True)
        pdf = d / "figure.pdf"; png = d / "figure.png"
        draw_pdf(pdf, arms, font, marks_shown=False, table_shown=True)
        render(poppler, pdf, png.with_suffix(""), 300)
        entry["files"]["nomark/figure.pdf"] = dict(sha256=sha(pdf), **check_nomark_pdf(pdf, arms))
        entry["primary_png300_pixel_identical_rerender"] = True
        entry["files"]["nomark/figure.png"] = dict(sha256=sha(png), dpi=300, **check_png(png, 300))
        # resolution gradient from the locked primary PDF
        for dpi in (150, 100):
            d = OUT / f"res{dpi}" / ds; d.mkdir(parents=True)
            png = d / "figure.png"
            render(poppler, source_pdf, png.with_suffix(""), dpi)
            entry["files"][f"res{dpi}/figure.png"] = dict(sha256=sha(png), dpi=dpi, **check_png(png, dpi))
        # lossy screenshot-like raster from the 100-dpi render
        d = OUT / "jpeg100" / ds; d.mkdir(parents=True)
        jpg = d / "figure.jpg"
        with Image.open(OUT / "res100" / ds / "figure.png") as im:
            im.convert("RGB").save(jpg, "JPEG", quality=75, subsampling=2, optimize=True)
        with Image.open(jpg) as im:
            assert im.format == "JPEG" and im.size == (600, 450)
        entry["files"]["jpeg100/figure.jpg"] = dict(sha256=sha(jpg), dpi=100, quality=75, subsampling="4:2:0",
                                                      width_px=600, height_px=450)
        rows.append(entry)
        print("prepared", ds, flush=True)
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), datasets=rows,
                    conditions=dict(nomark="native PDF without censoring marks + 300-dpi PNG", res150="primary PDF at 150 dpi",
                                    res100="primary PDF at 100 dpi", jpeg100="100-dpi render, JPEG q75 4:2:0"),
                    template=TEMPLATE, renderer=version, render_flags=render("echo", "X.pdf", "X", 300)[1:-2] if False else render_command("pdftoppm", "X.pdf", "X", 300)[1:-2] + ["-scale-to-x", "<6*dpi>", "-scale-to-y", "<4.5*dpi>"],
                    reportlab=importlib.metadata.version("reportlab"), pypdf=importlib.metadata.version("pypdf"),
                    pillow=importlib.metadata.version("Pillow"), font_sha256=sha(font),
                    primary_png300_pixel_identity_asserted_for_all_32=True, model_calls=0)
    (OUT / "MANIFEST.json").write_text(json.dumps(manifest, indent=1))
    (OUT / "INPUT_LOCK.json").write_text(json.dumps(dict(manifest_sha256=sha(OUT / "MANIFEST.json"),
        files=sum(len(r["files"]) for r in rows), datasets=len(rows), locked_utc=manifest["created_utc"]), indent=1))
    print(json.dumps(dict(datasets=len(rows), files=sum(len(r["files"]) for r in rows), renderer=version)))


if __name__ == "__main__":
    main()
