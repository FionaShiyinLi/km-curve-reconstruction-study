#!/usr/bin/env python3
"""Prepare and verify 32 lossless image-only PDF inputs; never call a model."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import subprocess
import tempfile

import numpy as np
from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject, NumberObject


ROOT = Path(__file__).resolve().parents[2]
NAME = "pdf_png300_raster_pdf_extension_v1"
SPEC = ROOT / "docs/proposals" / NAME
OUT = ROOT / "outputs/evaluation" / NAME
SOURCE = ROOT / "outputs/evaluation/pdf_png300_32_v1"
OLD = ROOT / "docs/proposals/pdf_png300_32_budget_v2"
OLD_ANALYSIS = ROOT / "outputs/evaluation/pdf_png300_32_budget_v2/analysis"
PAGE_POINTS = (432, 324)
PIXELS = (1800, 1350)
ORDER_SEED = 2026092307
ID_SEED = 2026092308


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")


def check_sources():
    old_lock = read(ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json")
    old_analysis = read(OLD_ANALYSIS / "ANALYSIS_LOCK.json")
    for name in ("schedule.json", "execution_config.json"):
        expected = read(OLD / "WORKFLOW_LOCK.json")["files_sha256"][f"{OLD.relative_to(ROOT)}/{name}"]
        if sha(OLD / name) != expected:
            raise ValueError(f"Original workflow changed: {name}")
    for name in ("scores.csv", "dataset_pairs.csv"):
        if sha(OLD_ANALYSIS / name) != old_analysis["files_sha256"][name]:
            raise ValueError(f"Original analysis changed: {name}")
    schedule = read(OLD / "schedule.json")
    png = [row for row in schedule if row["representation"] == "PNG300" and row["primary_attempt"]]
    if len(png) != 32 or len({row["dataset"] for row in png}) != 32:
        raise ValueError("Expected one original PNG primary input per dataset")
    if Counter(row["scenario"] for row in png) != {s: 8 for s in ("S1", "S2", "S3", "S4")}:
        raise ValueError("Original scenario balance changed")
    for row in png:
        name = row["input"]
        path = SOURCE / name
        if sha(path) != row["input_sha256"] or sha(path) != old_lock["artifacts_sha256"][name]:
            raise ValueError(f"Frozen source PNG changed: {name}")
    return png


def make_pdf(png_path, pdf_path):
    with Image.open(png_path) as image:
        if image.mode != "RGB" or image.size != PIXELS:
            raise ValueError(f"Expected an {PIXELS} RGB source PNG: {png_path}")
        pixels = image.tobytes()
    writer = PdfWriter()
    page = writer.add_blank_page(width=PAGE_POINTS[0], height=PAGE_POINTS[1])
    image_stream = DecodedStreamObject()
    image_stream.set_data(pixels)
    image_stream.update({
        NameObject("/Type"): NameObject("/XObject"),
        NameObject("/Subtype"): NameObject("/Image"),
        NameObject("/Width"): NumberObject(PIXELS[0]),
        NameObject("/Height"): NumberObject(PIXELS[1]),
        NameObject("/ColorSpace"): NameObject("/DeviceRGB"),
        NameObject("/BitsPerComponent"): NumberObject(8),
    })
    image_ref = writer._add_object(image_stream.flate_encode())
    page[NameObject("/Resources")] = DictionaryObject({
        NameObject("/XObject"): DictionaryObject({NameObject("/Im0"): image_ref})
    })
    content = DecodedStreamObject()
    content.set_data(b"q\n432 0 0 324 0 0 cm\n/Im0 Do\nQ\n")
    page[NameObject("/Contents")] = writer._add_object(content)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    with pdf_path.open("xb") as handle:
        writer.write(handle)


def check_pdf(pdf_path, png_path):
    reader = PdfReader(pdf_path)
    if len(reader.pages) != 1:
        raise ValueError(f"Not a one-page PDF: {pdf_path}")
    page = reader.pages[0]
    if tuple(float(x) for x in page.mediabox[2:]) != PAGE_POINTS:
        raise ValueError(f"Page size changed: {pdf_path}")
    resources = page["/Resources"]
    if set(resources) != {"/XObject"} or set(resources["/XObject"]) != {"/Im0"}:
        raise ValueError(f"Unexpected PDF resource or additional object: {pdf_path}")
    image = resources["/XObject"]["/Im0"].get_object()
    expected = {"/Type": "/XObject", "/Subtype": "/Image", "/Width": PIXELS[0],
                "/Height": PIXELS[1], "/ColorSpace": "/DeviceRGB", "/BitsPerComponent": 8}
    if any(image.get(k) != v for k, v in expected.items()) or image.get("/SMask") is not None:
        raise ValueError(f"Not a plain RGB image: {pdf_path}")
    if page.get_contents().get_data() != b"q\n432 0 0 324 0 0 cm\n/Im0 Do\nQ\n":
        raise ValueError(f"Unexpected page drawing or text operations: {pdf_path}")
    if page.get("/Annots") or page.get("/Metadata") or page.extract_text().strip():
        raise ValueError(f"Unexpected annotation, metadata, or text: {pdf_path}")
    with Image.open(png_path) as original:
        if original.mode != "RGB" or original.size != PIXELS:
            raise ValueError(f"Source PNG changed format: {png_path}")
        if image.get_data() != original.tobytes():
            raise ValueError(f"Embedded pixels differ from source PNG: {pdf_path}")


def make_schedule(png_rows):
    rows = sorted(png_rows, key=lambda row: row["dataset"])
    input_ids = [f"RI{i:03d}" for i in range(1, 33)]
    random.Random(ID_SEED).shuffle(input_ids)
    for row, input_id in zip(rows, input_ids):
        row["extension_input_id"] = input_id
    random.Random(ORDER_SEED).shuffle(rows)
    result = []
    for i, row in enumerate(rows, 1):
        result.append({
            "session_id": f"PP32RP_R{i:03d}", "dataset": row["dataset"],
            "scenario": row["scenario"], "representation": "RASTER_PDF",
            "primary_attempt": True, "source_png_session": row["session_id"],
            "source_png": row["input"], "source_png_sha256": row["input_sha256"],
            "input_id": row["extension_input_id"],
            "input": f"inputs/{row['extension_input_id']}/figure.pdf",
            "manifest": f"session_manifests/PP32RP_R{i:03d}.json",
            "code_seed": row["code_seed"], "model": "claude-opus-5-5", "effort": "medium",
            "n_per_group": row["n_per_group"], "pattern": row["pattern"]})
    return result


def display_qa(schedule):
    rows = []
    for row in schedule:
        with tempfile.TemporaryDirectory() as directory:
            stem = Path(directory) / "page"
            subprocess.run(["pdftoppm", "-f", "1", "-singlefile", "-r", "300", "-png",
                            str(OUT / row["input"]), str(stem)], check=True, capture_output=True)
            with Image.open(str(stem) + ".png") as rendered, Image.open(SOURCE / row["source_png"]) as original:
                if rendered.size != PIXELS or original.size != PIXELS:
                    raise ValueError(f"Rasterized display dimensions changed: {row['session_id']}")
                a = np.asarray(rendered.convert("RGB"), dtype=np.int16)
                b = np.asarray(original.convert("RGB"), dtype=np.int16)
                delta = np.abs(a - b)
                rows.append({"session_id": row["session_id"], "scenario": row["scenario"],
                             "rendered_pixels": list(rendered.size),
                             "mean_abs_channel_difference": round(float(delta.mean()), 6),
                             "changed_pixel_fraction": round(float(np.any(delta != 0, axis=2).mean()), 6),
                             "maximum_channel_difference": int(delta.max())})
    return {"purpose": "display QA only; embedded RGB bytes are checked exactly by check_pdf",
            "renderer": subprocess.check_output(["pdftoppm", "-v"], stderr=subprocess.STDOUT, text=True).splitlines()[0],
            "all_32_dimensions_correct": True, "all_32_rendered": True,
            "rendered_images_exactly_equal_to_source_png": all(r["changed_pixel_fraction"] == 0 for r in rows),
            "rows": rows}


def prepare():
    png = check_sources()
    if OUT.exists() or (SPEC / "INPUT_LOCK.json").exists():
        raise FileExistsError("Extension package already exists; use verify")
    schedule = make_schedule(png)
    for row in schedule:
        source = SOURCE / row["source_png"]
        target = OUT / row["input"]
        make_pdf(source, target)
        check_pdf(target, source)
        row["input_sha256"] = sha(target)
        old_manifest = read(SOURCE / f"session_manifests/{row['source_png_session'].replace('PP32B_', 'PP32_')}.json")
        if old_manifest != {"groups": {"A": row["n_per_group"], "B": row["n_per_group"]},
                            "time_unit": "months", "code_seed": row["code_seed"]}:
            raise ValueError("Original public manifest differs from schedule")
        write(OUT / row["manifest"], old_manifest)
        row["manifest_sha256"] = sha(OUT / row["manifest"])
    write(OUT / "schedule.json", schedule)
    display = display_qa(schedule)
    write(OUT / "DISPLAY_QA.json", display)
    write(OUT / "VALIDATION.json", {
        "independent_datasets": 32, "source_png_inputs": 32, "image_only_pdfs": 32,
        "pixel_exact_pairs": 32, "single_image_no_text_checks": 32,
        "rendered_page_dimension_checks": 32,
        "rendered_images_exactly_equal_to_source_png": display["rendered_images_exactly_equal_to_source_png"],
        "page_points": PAGE_POINTS, "pixels": PIXELS,
        "source_input_package_lock_sha256": sha(ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json"),
        "source_analysis_lock_sha256": sha(OLD_ANALYSIS / "ANALYSIS_LOCK.json"),
        "provider_calls": 0, "analysis_run": False, "live_execution_allowed": False})
    files = [SPEC / "PROTOCOL.md", SPEC / "ANALYSIS_PLAN.json", Path(__file__),
             ROOT / "tests/test_pdf_png300_raster_extension.py",
             ROOT / "R/reference.R", ROOT / "R/pdf_png300_scoring.R",
             ROOT / "docs/proposals/pdf_png300_32_v1/INPUT_PACKAGE_LOCK.json",
             OLD / "WORKFLOW_LOCK.json", OLD / "schedule.json", OLD / "execution_config.json",
             OLD_ANALYSIS / "ANALYSIS_LOCK.json", OLD_ANALYSIS / "scores.csv",
             OLD_ANALYSIS / "dataset_pairs.csv"]
    files += sorted(path for path in OUT.rglob("*") if path.is_file())
    write(SPEC / "INPUT_LOCK.json", {
        "study_id": NAME, "state": "inputs_and_analysis_rules_frozen",
        "model_calls": 0, "live_execution_allowed": False,
        "files_sha256": {str(path.relative_to(ROOT)): sha(path) for path in files}})
    verify()
    print("Frozen: 32 image-only PDFs, 32 matched inputs, 0 model calls")


def verify():
    png = check_sources()
    lock = read(SPEC / "INPUT_LOCK.json")
    for name, expected in lock["files_sha256"].items():
        if sha(ROOT / name) != expected:
            raise ValueError(f"Frozen extension file changed: {name}")
    schedule = read(OUT / "schedule.json")
    display = read(OUT / "DISPLAY_QA.json")
    if len(display["rows"]) != 32 or {r["session_id"] for r in display["rows"]} != {r["session_id"] for r in schedule}:
        raise ValueError("Display QA coverage changed")
    if len(schedule) != 32 or len({row["dataset"] for row in schedule}) != 32:
        raise ValueError("Extension schedule must have 32 distinct datasets")
    if Counter(row["scenario"] for row in schedule) != {s: 8 for s in ("S1", "S2", "S3", "S4")}:
        raise ValueError("Extension schedule scenario balance changed")
    old = {row["dataset"]: row for row in png}
    for i, row in enumerate(schedule, 1):
        source = old[row["dataset"]]
        if row["session_id"] != f"PP32RP_R{i:03d}" or row["source_png_sha256"] != source["input_sha256"]:
            raise ValueError("Extension assignment changed")
        if row["source_png"] != source["input"] or row["code_seed"] != source["code_seed"]:
            raise ValueError("Source pairing or code seed changed")
        check_pdf(OUT / row["input"], SOURCE / row["source_png"])
        if sha(OUT / row["input"]) != row["input_sha256"]:
            raise ValueError("Extension PDF hash changed")
        if sha(OUT / row["manifest"]) != row["manifest_sha256"]:
            raise ValueError("Extension manifest hash changed")
    print("Verified: 32 sources, image-only PDFs, pixels, assignments, and lock hashes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "verify"))
    action = parser.parse_args().action
    prepare() if action == "prepare" else verify()
