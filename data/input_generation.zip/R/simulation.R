# The generator retains latent data; the scorer accepts observed times/status only.
event_time_from_z <- function(z, group, pattern, cfg = protocol()) {
  stopifnot(group %in% c("A", "B"), pattern %in% c("noncrossing", "crossing"),
            all(is.finite(z)), all(z >= 0))
  if (group == "A") return(z / cfg$lambda)
  if (pattern == "noncrossing") return(z / (cfg$noncrossing_ratio * cfg$lambda))
  h1 <- cfg$crossing_early_ratio * cfg$lambda
  h2 <- cfg$crossing_late_ratio * cfg$lambda
  cutoff <- h1 * cfg$hazard_change
  ifelse(z <= cutoff, z / h1, cfg$hazard_change + (z - cutoff) / h2)
}

initialize_rng <- function(seed) {
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  set.seed(seed)
  get(".Random.seed", envir = .GlobalEnv)
}

generate_dataset <- function(n, pattern, rng_state, dataset_id, cfg = protocol()) {
  stopifnot(length(n) == 1L, is.finite(n), n >= 1, n == as.integer(n),
            pattern %in% c("noncrossing", "crossing"),
            length(rng_state) == 7L)
  assign(".Random.seed", rng_state, envir = .GlobalEnv)
  arms <- lapply(c("A", "B"), function(group) {
    # runif excludes both endpoints in R's default interval (0, 1).
    event_time <- event_time_from_z(-log(runif(n)), group, pattern, cfg)
    entry <- runif(n, 0, cfg$entry_window)
    dropout <- -log(runif(n)) / cfg$dropout_rate
    administrative <- cfg$closure - entry
    censor_time <- pmin(dropout, administrative)
    data.frame(dataset_id = dataset_id,
               participant_id = sprintf("%s_%s_%05d", dataset_id, group, seq_len(n)),
               group = group, event_time = event_time, entry = entry,
               dropout = dropout, administrative = administrative,
               censor_time = censor_time,
               observed_time = pmin(event_time, censor_time),
               event = as.integer(event_time <= censor_time))
  })
  do.call(rbind, arms)
}

make_development_plan <- function(cfg = protocol()) {
  state <- initialize_rng(cfg$development_seed)
  lapply(seq_len(nrow(cfg$scenarios)), function(i) {
    this_state <- state
    state <<- parallel::nextRNGStream(state)
    list(dataset_id = sprintf("D%04d", i), stage = "development",
         scenario = cfg$scenarios$scenario[i],
         n_per_group = cfg$scenarios$n_per_group[i],
         pattern = cfg$scenarios$pattern[i], rng_state = this_state)
  })
}
