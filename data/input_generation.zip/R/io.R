write_precise_csv <- function(x, path) {
  # CSV is a portable companion to lossless RDS. Seventeen significant digits
  # are sufficient for round-tripping finite IEEE double precision values.
  printable <- x
  for (name in names(x)) {
    if (is.double(x[[name]])) {
      printable[[name]] <- ifelse(is.na(x[[name]]), NA_character_, sprintf("%.17g", x[[name]]))
    }
  }
  write.table(printable, path, sep = ",", row.names = FALSE, col.names = TRUE,
              quote = TRUE, na = "")
}

write_json <- function(x, path) {
  jsonlite::write_json(x, path, pretty = TRUE, auto_unbox = TRUE, digits = NA,
                      na = "null", null = "null")
}
