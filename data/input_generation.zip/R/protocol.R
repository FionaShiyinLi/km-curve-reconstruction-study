# docs/archive/vector_raster_protocol_2026-09-12.docx, revised protocol dated 12 September 2026, Sections 2.1 and A1.
protocol <- function() {
  list(protocol_date = "2026-09-12", frozen = FALSE,
       lambda = log(2) / 12, noncrossing_ratio = 0.75,
       crossing_early_ratio = 1.5, crossing_late_ratio = 0.5,
       hazard_change = 4, entry_window = 12, closure = 36,
       dropout_rate = 0.005, tau = 24,
       risk_times = seq(0, 36, 6),
       scenarios = data.frame(
         scenario = c("n100_noncrossing", "n100_crossing",
                      "n1000_noncrossing", "n1000_crossing"),
         n_per_group = c(100L, 100L, 1000L, 1000L),
         pattern = c("noncrossing", "crossing", "noncrossing", "crossing")),
       development_seed = 20260912L, validation_seed = 20260913L,
       validation_datasets_per_scenario = 1000L)
}
