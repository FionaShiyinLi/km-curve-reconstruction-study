# Conventional PNG300 Guyot baseline

## Scope and timing

The user authorized one standard Guyot reconstruction on the same PNG300 inputs,
with the manuscript's TAAE and downstream scoring, on October 3, 2026 (Phoenix).
This is a follow-up comparator added after the existing LLM results were known.
The rules below and their source/input hashes are locked before these comparator
outputs or their reference-based accuracy are available. Existing datasets,
generation rules, LLM outputs, scores and manuscript sources remain unchanged.

## Inputs and method

- All 64 primary PNG300 inputs: the original 32 and independent replication 32,
  eight datasets in each cohort/scenario cell. No repeat or alternative-template
  input is counted as an additional dataset.
- Match the actual PNG bytes and public group sizes to the existing assignments.
  Never rerender from PDF, read PDF geometry, use exact KM vertices, obtain risk
  counts from scoring truth, or supply reference event/censor times.
- Reuse the existing fixed raster digitizer and owned OCR runtime. Axis labels,
  colored curves, legend group mapping and risk-table cells are read from PNG.
  This is automated digitization, not manual expert graph tracing. Save extraction
  coordinates, risk cells, diagnostics and the full OCR text. No per-image tuning.
- Run the ORIGINAL numerical algorithm from Guyot et al. (2012), Additional
  file 1, rather than substituting IPDfromKM's modified algorithm. Total events
  are unavailable in the assigned images and are not supplied. Censor marks are
  not used by the Guyot backend.
- The supplement's numerical iteration and IPD construction are transcribed
  verbatim into R/guyot_2012_core.R. The adapter replaces file input/output only.
  The supplement itself and complete extracted text are retained with checksums.
  Source: https://doi.org/10.1186/1471-2288-12-9; Additional file 1:
  https://media.springernature.com/original/springer-static/esm/art%3A10.1186%2F1471-2288-12-9/MediaObjects/12874_2011_700_MOESM1_ESM.PDF
  Copyright Guyot et al., 2012; Creative Commons Attribution 2.0.
- Input adaptation: retain post-drop coordinates at duplicate times so hist()
  has strictly increasing breaks. Insert displayed risk times into the digitized
  step curve by carrying its previous height forward. Use risk times strictly
  before the last visible curve coordinate as interval starts; a displayed row
  at/after that endpoint cannot start a follow-up interval and remains saved for
  audit. No interpolation uses reference values. Preserve the algorithm's own
  risk-count adjustments and diagnose them afterward rather than repairing them.

## Execution and stopping

One scientific execution per assigned PNG; 64 total, up to three independent
workers. Workers are confined to their assigned image, public sample sizes,
pinned implementation/runtime and owned output. They must demonstrate denied
reads of another assigned image and the actual reference records, in addition
to the existing comparator's denial probes. No network or model calls.

Retain the existing 120-second extraction and 240-second two-arm reconstruction
ceilings. There is no accuracy-driven retry, removal, manual correction, alternate
setting, seed search or recovery of method failures. The original Guyot algorithm
is deterministic and uses no reconstruction RNG. Partial valid arms are retained
for arm-level scores, while unavailable two-arm outcomes remain unavailable.

Save a per-case result and artifact checksums, structured progress.json, terminal
RESULTS.json, logs, extracted inputs, algorithm counts and reconstructed records.
An interrupted controller may skip verified sealed cases but must not rerun an
unsealed or failed case. An infrastructure abort stops admission and requires
investigation; it must not be disguised as a scientific failure or silently rerun.

## Scoring and comparisons

Only after all assigned reconstructions are sealed may the trusted evaluator
read the original observed data. Reuse R/reference.R and R/pdf_png300_scoring.R
without modifying endpoint definitions, follow-up, Cox settings or tail support.

Score TAAE through 24 months averaged over arms; arm TAAE; maximum curve error;
duration above two percentage points; absolute arm RMST error; absolute error
in the between-arm RMST difference; and absolute Cox log-hazard-ratio error.
Retain signed arm RMST discrepancies as diagnostics, exactly as in LLM scoring.

Report original and replication cohorts separately, then their secondary pooled
estimate. Use the existing 10,000-draw whole-dataset stratified bootstrap,
equal scenario weights and (when pooled) equal cohort/scenario weights. Preserve
the original, replication and pooled seeds: 2026092306, 2026092706 and 2026092707.
Report absolute errors for Guyot, LLM PNG300 and LLM native PDF; paired contrasts
are Guyot minus LLM PNG300 and LLM native PDF minus Guyot. Lower error is better.
Bootstrap failures/undefined intervals remain reported, never silently discarded.

The same baseline is compared with both the retained scheduled-main LLM outputs
(62 pooled complete format pairs) and the documented transport-completed set
(64 pairs); these are sensitivity views, not separate baseline executions.
Failures remain in assigned denominators; complete-pair accuracy and execution
success answer different questions. Do not claim clinical equivalence from a
small error or interpret this as a general evaluation of manual Guyot workflows.

## Acceptance checks

1. PNG hashes and cohort/scenario assignments match all 64 original inputs.
2. Source/environment locks hold; tests cover hand-calculated events, censoring,
   duplicate-coordinate adaptation and equal scoring/contrast definitions.
3. All attempted cases, logs, isolation probes and output checksums are retained.
4. Independent KM integration agrees with the existing TAAE/RMST scores and
   survival::survfit/Cox calculations agree with downstream scores.
5. Existing input, reference and LLM-result hashes remain unchanged; manuscript
   and Overleaf changes are a subsequent reporting task.
