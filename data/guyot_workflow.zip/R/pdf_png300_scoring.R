# Formal PDF/PNG scorer; observed data only. Source reference.R first.
pp_curve <- function(reference, reconstructed, tau=24) {
  r <- rmst_from_observed(reference$observed_time, reference$event, tau)
  empty <- c(taae=NA_real_, maximum=NA_real_, duration_above_002=NA_real_,
             signed_rmst_error=NA_real_, absolute_rmst_error=NA_real_)
  if (is.null(reconstructed)) return(list(values=empty, reason="missing_or_invalid_arm"))
  x <- rmst_from_observed(reconstructed$observed_time, reconstructed$event, tau)
  if (!r$available || !x$available) return(list(values=empty, reason="unsupported_nonzero_tail"))
  knots <- sort(unique(c(0,tau,r$km$time[r$km$time<=tau],x$km$time[x$km$time<=tau])))
  height <- function(k) c(1,k$survival)[findInterval(knots,k$time)+1L]
  delta <- height(x$km)-height(r$km); left <- head(delta,-1L); widths <- diff(knots)
  signed <- sum(widths*left)
  list(values=c(taae=sum(widths*abs(left))/tau, maximum=max(abs(delta)),
    duration_above_002=sum(widths[abs(left)>.02+32*.Machine$double.eps]),
    signed_rmst_error=signed, absolute_rmst_error=abs(signed)),reason="available")
}

pp_session <- function(reference, reconstructed, arms) {
  required <- c("group","observed_time","event")
  reference <- reference[required] # Never use latent T/E/D or generating hazards.
  # One malformed arm can make read.csv infer a text column for BOTH arms.
  # Convert values explicitly and validate each arm independently before fitting.
  if(!is.null(reconstructed)) {
    reconstructed <- reconstructed[required]
    for(field in c("observed_time","event"))
      reconstructed[[field]] <- suppressWarnings(as.numeric(reconstructed[[field]]))
    for(g in c("A","B")) if(isTRUE(arms[[g]])) {
      d <- reconstructed[reconstructed$group==g,]
      arms[[g]] <- isTRUE(tryCatch({validate_observed(d$observed_time,d$event);TRUE},error=function(e) FALSE))
    }
  }
  curves <- setNames(lapply(c("A","B"), function(g) pp_curve(reference[reference$group==g,],
    if (isTRUE(arms[[g]])) reconstructed[reconstructed$group==g,required] else NULL)),c("A","B"))
  values <- unlist(lapply(c("A","B"),function(g) setNames(curves[[g]]$values,paste0(names(curves[[g]]$values),"_",g))))
  values <- c(values,taae_mean=mean(values[c("taae_A","taae_B")]),
    absolute_rmst_difference_error=abs(values[["signed_rmst_error_B"]]-values[["signed_rmst_error_A"]]))
  cx <- cox_reference(reference)
  rec <- if (all(unlist(arms))) cox_reference(reconstructed[required]) else list(log_hr=NA_real_,status="missing_or_invalid_arm",warnings=character())
  values <- c(values,absolute_log_hr_error=abs(rec$log_hr-cx$log_hr))
  list(values=values,curve_status=vapply(curves,`[[`,character(1),"reason"),
       cox_status=c(reference=cx$status,reconstructed=rec$status),cox_warnings=c(cx$warnings,rec$warnings))
}

pp_bootstrap <- function(pairs, metrics, B=10000L, seed=2026092306L) {
  scenarios <- paste0("S",1:4)
  stopifnot(nrow(pairs)==32L,!anyDuplicated(pairs$dataset),all(table(factor(pairs$scenario,levels=scenarios))==8L))
  RNGkind("Mersenne-Twister","Inversion","Rejection");set.seed(seed)
  # All eight assigned datasets are resampled in each scenario, including missing
  # pairs. The same whole-dataset indices are shared by every metric and scope.
  picks <- lapply(scenarios,function(s) matrix(sample.int(8L,8L*B,replace=TRUE),nrow=8L))
  scopes <- list(all=scenarios,n100=c("S1","S2"),n1000=c("S3","S4"),
                 noncrossing=c("S1","S3"),crossing=c("S2","S4"))
  result <- list()
  for (metric in metrics) {
    means <- rep(NA_real_,4); complete <- integer(4); draws <- matrix(NA_real_,B,4)
    for (i in 1:4) {
      d <- pairs[pairs$scenario==scenarios[i],paste0(metric,"_PDF")]-pairs[pairs$scenario==scenarios[i],paste0(metric,"_PNG300")]
      complete[i] <- sum(is.finite(d))
      means[i] <- if(any(is.finite(d))) mean(d[is.finite(d)]) else NA_real_
      z <- matrix(d[picks[[i]]],nrow=8); counts <- colSums(is.finite(z)); z[!is.finite(z)] <- 0
      draws[,i] <- ifelse(counts>0,colSums(z)/counts,NA_real_)
    }
    for (scope in names(scopes)) {
      use <- match(scopes[[scope]],scenarios); estimate <- mean(means[use]); x <- rowMeans(draws[,use,drop=FALSE])
      undefined <- sum(!is.finite(x)); degenerate <- !undefined && length(unique(x))==1L
      status <- if(!is.finite(estimate)) "undefined_estimate" else if(undefined) "undefined_resamples" else if(degenerate) "degenerate_resamples" else "available"
      available <- status=="available"
      result[[length(result)+1L]] <- data.frame(metric=metric,scope=scope,estimate=estimate,
        complete_pairs=sum(complete[use]),
        pairs_S1=if(1 %in% use) complete[1] else NA_integer_,pairs_S2=if(2 %in% use) complete[2] else NA_integer_,
        pairs_S3=if(3 %in% use) complete[3] else NA_integer_,pairs_S4=if(4 %in% use) complete[4] else NA_integer_,
        lower=if(available) unname(quantile(x,.025,type=1)) else NA_real_,
        upper=if(available) unname(quantile(x,.975,type=1)) else NA_real_,
        standard_error=if(available) sd(x) else NA_real_,undefined_resamples=undefined,status=status,B=B,seed=seed)
    }
  }
  do.call(rbind,result)
}

pp_pairs <- function(scores) {
  primary <- scores[scores$primary_attempt,]
  if(nrow(primary)!=64L || anyDuplicated(primary[c("dataset","representation")])) stop("Invalid primary assignment table")
  metrics <- names(primary)[vapply(primary,is.numeric,logical(1))]
  metrics <- intersect(metrics,c("taae_mean","taae_A","taae_B","maximum_A","maximum_B",
    "duration_above_002_A","duration_above_002_B","absolute_rmst_error_A","absolute_rmst_error_B",
    "absolute_rmst_difference_error","absolute_log_hr_error"))
  cols <- c("dataset","scenario","status",metrics)
  p <- merge(primary[primary$representation=="PDF",cols],primary[primary$representation=="PNG300",cols],
    by=c("dataset","scenario"),suffixes=c("_PDF","_PNG300"),sort=TRUE)
  pdf <- is.finite(p$taae_mean_PDF); png <- is.finite(p$taae_mean_PNG300)
  p$pair_status <- ifelse(pdf & png,"both",ifelse(pdf,"PDF_only",ifelse(png,"PNG300_only","neither")))
  p$taae_difference <- p$taae_mean_PDF-p$taae_mean_PNG300
  p$lower_bound <- ifelse(pdf,p$taae_mean_PDF,0)-ifelse(png,p$taae_mean_PNG300,1)
  p$upper_bound <- ifelse(pdf,p$taae_mean_PDF,1)-ifelse(png,p$taae_mean_PNG300,0)
  list(pairs=p,metrics=metrics)
}
