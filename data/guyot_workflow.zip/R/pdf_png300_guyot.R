# PNG-derived coordinates only. Guyot et al. (2012), Additional file 1.
# The numerical body is transcribed separately without algorithm changes.
guyot_2012 <- function(coordinates, risk, n) {
  stopifnot(is.data.frame(coordinates), all(c('time','survival') %in% names(coordinates)),
    all(is.finite(as.matrix(coordinates))), all(diff(coordinates$time) >= 0),
    all(diff(coordinates$survival) <= 1e-12), all(coordinates$survival >= 0),
    all(coordinates$survival <= 1), coordinates$time[1] == 0,
    coordinates$survival[1] == 1, risk$time[1] == 0, risk$n_risk[1] == n,
    all(diff(risk$time) > 0), all(diff(risk$n_risk) <= 0), all(risk$n_risk >= 0))
  # The original hist() requires unique increasing time coordinates. For a
  # vertical step retain its lower (post-event) vertex; no reference is used.
  coordinates <- coordinates[!duplicated(coordinates$time, fromLast=TRUE), ]
  endpoint <- tail(coordinates$time, 1)
  # A risk entry at/after the observed endpoint cannot start a follow-up
  # interval. Retain it in the saved extraction, but not as an empty interval.
  risk_used <- risk[risk$time < endpoint, , drop=FALSE]
  stopifnot(nrow(risk_used) >= 2L)
  times <- sort(unique(c(coordinates$time, risk_used$time)))
  survival <- coordinates$survival[findInterval(times, coordinates$time)]
  t.S <- times; S <- survival
  t.risk <- risk_used$time; n.risk <- risk_used$n_risk
  lower <- match(t.risk, t.S)
  upper <- c(lower[-1L]-1L, length(t.S))
  n.int <- length(n.risk); n.t <- length(t.S)
  stopifnot(all(lower <= upper), all(diff(t.S) > 0), lower[1] == 1L)
  tot.events <- 'NA'; arm.id <- 1L
  original_n_risk <- n.risk
  source('R/guyot_2012_core.R', local=environment())
  records <- data.frame(time=t.IPD, event=event.IPD)
  stopifnot(nrow(records) == n, all(is.finite(records$time)),
    all(records$time >= 0 & records$time <= endpoint), all(records$event %in% c(0,1)),
    all(is.finite(d)), all(d >= 0), all(is.finite(cen)), all(cen >= 0))
  list(records=records, coordinates=data.frame(time=t.S,survival=S),
    risk=data.frame(time=t.risk, displayed=original_n_risk, algorithm=n.risk,
      reconstructed=vapply(t.risk, function(t) sum(records$time >= t), integer(1))),
    counts=data.frame(time=t.S, n_risk=n.hat[seq_len(n.t)], events=d, censors=cen),
    endpoint_risk_rows_not_used=sum(risk$time >= endpoint))
}
