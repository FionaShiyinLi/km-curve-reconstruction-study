validate_observed <- function(time, event) {
  if (!is.numeric(time) || !length(time) || length(time) != length(event) ||
      anyNA(time) || any(!is.finite(time)) || any(time < 0) ||
      !(is.numeric(event) || is.logical(event)) || anyNA(event) ||
      any(!event %in% c(0, 1))) {
    stop("Observed data require nonempty finite nonnegative times and binary event indicators.")
  }
}

km_from_observed <- function(time, event) {
  validate_observed(time, event)
  ord <- order(time)
  y <- time[ord]
  delta <- as.integer(event[ord])
  blocks <- rle(y)
  count <- blocks$lengths
  end <- cumsum(count)
  start <- c(1L, head(end, -1L) + 1L)
  cumulative_events <- c(0L, cumsum(delta))
  deaths <- cumulative_events[end + 1L] - cumulative_events[start]
  risk <- length(y) - start + 1L
  survival <- cumprod(1 - deaths / risk)
  data.frame(time = blocks$values, n_risk = risk, n_event = deaths,
             n_censor = count - deaths,
             survival_before = c(1, head(survival, -1L)), survival = survival)
}

rmst_from_observed <- function(time, event, tau = 24) {
  if (length(tau) != 1L || !is.finite(tau) || tau <= 0) stop("tau must be positive.")
  km <- km_from_observed(time, event)
  endpoint <- max(time)
  zero_tail <- any(km$time <= tau & km$survival == 0)
  supported <- endpoint >= tau || zero_tail
  if (!supported) {
    return(list(rmst = NA_real_, available = FALSE,
                reason = "unsupported_nonzero_tail", endpoint = endpoint, km = km))
  }
  # Each interval uses the post-drop value at its LEFT endpoint. Vertical
  # drops (including an event at tau) contribute zero area.
  inside <- km$time < tau
  boundaries <- c(0, km$time[inside], tau)
  heights <- c(1, km$survival[inside])
  list(rmst = sum(diff(boundaries) * heights), available = TRUE,
       reason = if (endpoint < tau) "supported_zero_tail" else "supported_followup",
       endpoint = endpoint, km = km)
}

risk_counts <- function(time, event, times = seq(0, 36, 6)) {
  validate_observed(time, event)
  if (!is.numeric(times) || anyNA(times) || any(!is.finite(times)) || any(times < 0)) {
    stop("Risk times must be finite and nonnegative.")
  }
  vapply(times, function(t) sum(time >= t), integer(1))
}

step_coordinates <- function(km) {
  # Ordered pre/post vertices preserve vertical drops. End at actual support;
  # never append the common 36-month axis or an artificial terminal zero.
  out <- data.frame(time = 0, survival = 1)
  for (i in which(km$n_event > 0)) {
    out <- rbind(out, data.frame(time = rep(km$time[i], 2),
                               survival = c(km$survival_before[i], km$survival[i])))
  }
  endpoint <- tail(km$time, 1)
  if (tail(out$time, 1) < endpoint) {
    out <- rbind(out, data.frame(time = endpoint, survival = tail(km$survival, 1)))
  }
  out
}

score_dataset <- function(records, cfg = protocol()) {
  required <- c("group", "observed_time", "event")
  if (!all(required %in% names(records)) || anyNA(records$group) ||
      !setequal(unique(records$group), c("A", "B"))) stop("Exactly groups A and B are required.")
  # Deliberately select only observed data. Hidden T, E, D never enter scoring.
  observed <- records[required]
  arms <- setNames(lapply(c("A", "B"), function(g) {
    d <- observed[observed$group == g, ]
    fit <- rmst_from_observed(d$observed_time, d$event, cfg$tau)
    fit$n <- nrow(d)
    fit$events <- sum(d$event)
    fit$censoring_fraction <- mean(d$event == 0)
    fit$risk <- data.frame(time = cfg$risk_times,
                          n_risk = risk_counts(d$observed_time, d$event, cfg$risk_times))
    fit$coordinates <- step_coordinates(fit$km)
    fit
  }), c("A", "B"))
  available <- arms$A$available && arms$B$available
  list(arms = arms, reference_available = available,
       rmst_difference_B_minus_A = if (available) arms$B$rmst - arms$A$rmst else NA_real_,
       reference_status = if (available) "available" else "reference_unavailable")
}

# Proposal A extensions. The legacy score_dataset entry point remains unchanged.
# Zero-survival Greenwood terms use their continuous boundary value of zero.
arm_inference <- function(time, event, tau = 24) {
  a <- rmst_from_observed(time, event, tau)
  k <- a$km
  at <- which(k$time <= tau)
  s <- if (length(at)) k$survival[tail(at, 1)] else 1
  use <- which(k$n_event > 0 & k$time <= tau & k$n_risk > k$n_event)
  gw <- k$n_event[use] / (k$n_risk[use] * (k$n_risk[use] - k$n_event[use]))
  # Backward integration from each observation through tau, including censor rows.
  inside <- which(k$time <= tau)
  areas <- if (length(inside)) rev(cumsum(rev(
    diff(c(k$time[inside], tau)) * k$survival[inside]))) else numeric()
  variance <- if (a$available) sum(areas[match(use, inside)]^2 * gw) else NA_real_
  crossed <- which(k$survival <= .5)
  c(rmst = a$rmst, se_rmst = sqrt(variance),
    survival = if (a$available) s else NA_real_,
    se_survival = if (!a$available) NA_real_ else if (s == 0) 0 else s * sqrt(sum(gw)),
    median = if (length(crossed)) k$time[crossed[1]] else NA_real_,
    events = sum(event))
}

cox_reference <- function(records) {
  z <- data.frame(time = records$observed_time, event = records$event,
                  treatment = as.integer(records$group == "B"))
  warnings <- character()
  fail <- function(reason) list(log_hr = NA_real_, se_log_hr = NA_real_,
                                status = reason, warnings = warnings)
  if (!sum(z$event)) return(fail("no_events"))
  if (length(unique(z$treatment[z$event == 1])) < 2L)
    return(fail("events_in_one_group"))
  fit <- tryCatch(withCallingHandlers(
    survival::coxph(survival::Surv(time, event) ~ treatment, data = z, ties = "efron",
      control = survival::coxph.control(timefix = FALSE, eps = 1e-11, iter.max = 100)),
    warning = function(w) { warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning") }),
    error = function(e) e)
  if (inherits(fit, "error")) return(fail(paste0("cox_error: ", conditionMessage(fit))))
  if (any(grepl("infinite|converg", warnings, ignore.case = TRUE)))
    return(fail("nonfinite_or_nonconverged_cox"))
  beta <- unname(fit$coefficients[1]); se <- unname(sqrt(fit$var[1, 1]))
  if (!is.finite(beta) || !is.finite(se) || se <= 0) return(fail("unidentified_cox"))
  list(log_hr = beta, se_log_hr = se, status = "available", warnings = warnings)
}

score_proposal_a <- function(records, tau = 24) {
  # Validate with the established observed-record scorer; discard latent columns.
  cfg <- protocol(); cfg$tau <- tau
  base <- score_dataset(records, cfg)
  d <- records[c("group", "observed_time", "event")]
  arms <- lapply(c("A", "B"), function(g) {
    x <- d[d$group == g, ]; arm_inference(x$observed_time, x$event, tau)
  }); names(arms) <- c("A", "B")
  cx <- cox_reference(d)
  values <- c(rmst_difference = base$rmst_difference_B_minus_A,
    se_rmst_difference = sqrt(arms$A["se_rmst"]^2 + arms$B["se_rmst"]^2),
    log_hr = cx$log_hr, se_log_hr = cx$se_log_hr)
  names(values)[2] <- "se_rmst_difference"
  for (g in c("A", "B")) {
    a <- arms[[g]]; names(a) <- paste0(names(a), "_", g); values <- c(values, a)
  }
  status <- ifelse(is.finite(values), "available", "unavailable")
  names(status) <- names(values)
  status[c("log_hr", "se_log_hr")] <- cx$status
  for (g in c("A", "B")) {
    if (!base$arms[[g]]$available) {
      status[paste0(c("rmst", "se_rmst", "survival", "se_survival"), "_", g)] <-
        "unsupported_nonzero_tail"
    }
    if (is.na(values[paste0("median_", g)])) status[paste0("median_", g)] <- "median_not_reached"
  }
  if (!base$reference_available) status[c("rmst_difference", "se_rmst_difference")] <- "unsupported_nonzero_tail"
  list(values = values, status = status, cox_warnings = cx$warnings, tau = tau)
}

# Per-measure availability: invalid reconstructed SE is a failure, not a missing
# reference or a clipped ratio. Raw differences remain available for finite zeros.
score_reconstruction_loss <- function(reference, reconstructed = NULL) {
  ref <- reference$values
  rec <- setNames(rep(NA_real_, length(ref)), names(ref))
  if (!is.null(reconstructed)) rec[] <- reconstructed$values[names(ref)]
  is_se <- startsWith(names(ref), "se_")
  ref_ok <- is.finite(ref) & (!is_se | ref > 0)
  rec_ok <- is.finite(rec) & (!is_se | rec > 0)
  usable <- ref_ok & rec_ok
  signed <- rec - ref
  z <- ratio <- rep(NA_real_, length(ref))
  z[usable & is_se] <- log(rec[usable & is_se]) - log(ref[usable & is_se])
  ratio[usable & is_se] <- rec[usable & is_se] / ref[usable & is_se]
  loss <- abs(signed); loss[is_se] <- abs(z[is_se]); loss[!usable] <- NA_real_
  data.frame(estimand = names(ref), reference = unname(ref), reconstructed = unname(rec),
    reference_available = unname(ref_ok), usable = unname(usable),
    status = ifelse(!ref_ok, "reference_unavailable", ifelse(!rec_ok, "unusable_output", "usable")),
    signed_error = unname(signed), loss = unname(loss), se_ratio = ratio, signed_log_se_ratio = z,
    standardized_log_hr_error = ifelse(names(ref) == "log_hr" & is.finite(ref["se_log_hr"]) &
      ref["se_log_hr"] > 0, signed / ref["se_log_hr"], NA_real_), row.names = NULL)
}

# Keep usable single-arm estimands when reconstruction of the other arm fails.
score_reconstructed_arms <- function(fits, tau = 24) {
  good <- vapply(fits[c("A", "B")], function(x) isTRUE(x$usable), logical(1))
  if (all(good)) {
    d <- do.call(rbind, lapply(c("A", "B"), function(g) data.frame(group = g,
      observed_time = fits[[g]]$records$time, event = fits[[g]]$records$event)))
    return(score_proposal_a(d, tau))
  }
  metrics <- c("rmst_difference", "se_rmst_difference", "log_hr", "se_log_hr",
    unlist(lapply(c("A", "B"), function(g) paste0(c("rmst", "se_rmst", "survival", "se_survival", "median", "events"), "_", g))))
  values <- setNames(rep(NA_real_, length(metrics)), metrics)
  status <- setNames(rep("reconstruction_failure", length(metrics)), metrics)
  for (g in c("A", "B")[good]) {
    d <- fits[[g]]$records; a <- arm_inference(d$time, d$event, tau)
    names(a) <- paste0(names(a), "_", g); values[names(a)] <- a
    status[names(a)] <- ifelse(is.finite(a), "available", "unavailable")
  }
  list(values = values, status = status, cox_warnings = character(), tau = tau)
}

accuracy_at_tolerance <- function(loss, epsilon) {
  stopifnot(length(epsilon) == 1, is.finite(epsilon), epsilon >= 0)
  # Machine-roundoff allowance only, so mathematically equal anchor boundaries
  # do not switch classification when expressed as log(a/b) vs log(a)-log(b).
  within <- loss$usable & !is.na(loss$loss) &
    loss$loss <= epsilon + 32 * .Machine$double.eps * max(1, abs(epsilon))
  denominator <- sum(loss$reference_available); successes <- sum(within)
  usable <- sum(loss$usable); silent <- usable - successes
  data.frame(tolerance = epsilon, denominator = denominator, successes = successes,
    Q = if (denominator) successes/denominator else NA_real_, usable = usable,
    silent_errors = silent, silent_error_rate = if (usable) silent/usable else NA_real_)
}
