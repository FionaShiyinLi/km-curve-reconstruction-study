// JSON-lines OCR service. Only image pixels are supplied; no scoring data.
const fs = require('fs');
const readline = require('readline');
const { createWorker } = require(process.env.CODEX_NODE_MODULES + '/tesseract.js');
(async () => {
  const worker = await createWorker('eng', 1, {
    langPath: process.argv[2], cacheMethod: 'none', gzip: false,
    logger: () => {},
  });
  await worker.setParameters({ tessedit_pageseg_mode: '11', user_defined_dpi: '300', classify_enable_learning: '0' });
  for await (const line of readline.createInterface({input: process.stdin})) {
    try {
      const q = JSON.parse(line);
      await worker.setParameters({tessedit_pageseg_mode: q.psm || '11', tessedit_char_whitelist: q.digits ? '0123456789.' : ''});
      const result = await worker.recognize(Buffer.from(q.image, 'base64'), {}, {tsv: true, text: true});
      process.stdout.write(JSON.stringify({text: result.data.text, tsv: result.data.tsv})+'\n');
    } catch (e) { process.stdout.write(JSON.stringify({error: String(e)})+'\n'); }
  }
  await worker.terminate();
})();
