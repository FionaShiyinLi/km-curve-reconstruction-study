#!/usr/bin/env python3
"""Worker confined to a single figure, public caption, and output directory."""
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
from km_analysis.deterministic_extraction import OCR, extract


def validate(extraction, caption):
    if not extraction['usable']:
        return
    if set(extraction['arms']) != {'A', 'B'}:
        raise ValueError('missing_or_ambiguous_arm')
    for g, a in extraction['arms'].items():
        xy = np.asarray(a['coordinates'], dtype=float)
        if (xy.ndim != 2 or xy.shape[1] != 2 or len(xy) < 2 or not np.isfinite(xy).all()
                or (xy[:, 0] < 0).any() or (np.diff(xy[:, 0]) < 0).any()
                or (xy[:, 1] < 0).any() or (xy[:, 1] > 1).any()
                or (np.diff(xy[:, 1]) > 1e-12).any()):
            raise ValueError('invalid_curve_' + g)
        risk = a.get('risk')
        if not risk:
            raise ValueError('missing_risk_table_' + g)
        t, n = np.asarray(risk['time']), np.asarray(risk['n_risk'])
        if (len(t) != len(n) or len(t) < 2 or not np.isfinite(t).all() or not np.isfinite(n).all()
                or t[0] != 0 or (np.diff(t) <= 0).any() or (np.diff(n) > 0).any()
                or (n < 0).any() or (n != np.floor(n)).any() or n[0] != caption[g]
                or a['n'] != caption[g]):
            raise ValueError('invalid_risk_table_' + g)


def main():
    assigned, request, output = map(Path, sys.argv[1:4])
    q = json.loads(request.read_text())
    # Probes run before extraction, including on failed images. Missing files are
    # not evidence of confinement: only PermissionError counts as a denied read.
    probes = {}
    for name, path in q['deny_probes'].items():
        try:
            with open(path, 'rb') as f:
                f.read(1)
            probes[name] = False
        except PermissionError:
            probes[name] = True
    if not all(probes.values()):
        raise RuntimeError('Isolation probe failed')
    ocr = None
    try:
        if assigned.suffix.lower() != '.pdf':
            ocr = OCR()
        result = extract(assigned, q['caption'], ocr)
        try:
            validate(result, q['caption'])
        except ValueError as e:
            result.update(usable=False, reason=str(e))
        result['isolation_probes'] = probes
        output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    finally:
        if ocr:
            ocr.close()


if __name__ == '__main__':
    main()
