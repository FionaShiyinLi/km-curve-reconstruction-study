#!/usr/bin/env python3
"""One original-Guyot reconstruction per PNG300; scoring follows sealed outputs."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT/'src'), str(ROOT)]
import runner
from scripts.main_study import run_comparator as comparator
from scripts.main_study.run_task_validity_comparator import extraction_command

SPEC = ROOT/'docs/proposals/pdf_png300_guyot_baseline_v1'
OUT = ROOT/'outputs/evaluation/pdf_png300_guyot_baseline_v1'
SCORER = ROOT/'scripts/main_study/score_pdf_png300_guyot.R'
BACKEND = ROOT/'scripts/main_study/reconstruct_pdf_png300_guyot.R'
ORIGINAL = ROOT/'outputs/evaluation/pdf_png300_32_budget_v2'
NEW = ROOT/'outputs/evaluation/pdf_png300_replication32_v1'
EXTRA_SOURCES = ['R/guyot_2012_core.R','R/pdf_png300_guyot.R',
    'scripts/main_study/reconstruct_pdf_png300_guyot.R',
    'scripts/main_study/run_task_validity_comparator.py',
    'scripts/main_study/run_pdf_png300_guyot.py',
    'scripts/main_study/score_pdf_png300_guyot.R',
    'R/reference.R','R/pdf_png300_scoring.R',
    'scripts/main_study/score_pdf_png300_replication.R',
    'docs/proposals/pdf_png300_guyot_baseline_v1/PROTOCOL.md',
    'docs/proposals/pdf_png300_guyot_baseline_v1/guyot_2012_supplement.pdf',
    'docs/proposals/pdf_png300_guyot_baseline_v1/guyot_2012_supplement.txt']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value, replace=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if replace:
        temp = path.with_suffix(path.suffix+'.tmp')
        temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
        temp.replace(path)
    else:
        with path.open('x') as stream:
            json.dump(value,stream,indent=2,allow_nan=False); stream.write('\n')


def now():
    return datetime.now(timezone.utc).isoformat()


def manifest():
    result = []
    schedules = [json.loads((ROOT/'docs/proposals/pdf_png300_32_budget_v2/schedule.json').read_text()),
        json.loads((NEW/'schedule.json').read_text())]
    for cohort, rows in zip(('original','replication'),schedules):
        selected = sorted((r for r in rows if r['primary_attempt'] and r['representation']=='PNG300'),
            key=lambda r:r['dataset'])
        if len(selected)!=32 or len({r['dataset'] for r in selected})!=32:
            raise ValueError('Expected 32 unique PNG primary datasets per cohort')
        source = ROOT/'outputs/evaluation/pdf_png300_32_v1' if cohort=='original' else NEW
        for r in selected:
            path = Path(r['input'])
            if not path.is_absolute(): path = source/path
            if path.suffix != '.png' or sha(path)!=r['input_sha256']:
                raise ValueError('Assigned PNG input changed')
            public = Path(r['manifest'])
            if not public.is_absolute(): public = source/public
            caption = json.loads(public.read_text())['groups']
            if caption != {'A':r['n_per_group'],'B':r['n_per_group']}:
                raise ValueError('Public sample sizes differ')
            result.append(dict(id=r['dataset'],dataset=r['dataset'],cohort=cohort,scenario=r['scenario'],
                path=str(path),sha256=r['input_sha256'],caption=caption,
                reference=str(source/'data/scoring_only'/r['dataset']/'records.csv')))
    if len({r['dataset'] for r in result})!=64: raise ValueError('Dataset reuse')
    for c in ('original','replication'):
        for s in ('S1','S2','S3','S4'):
            if sum(r['cohort']==c and r['scenario']==s for r in result)!=8:
                raise ValueError('Unbalanced cohort/scenario mapping')
    return result


def prepare():
    rows = manifest()
    # References enter only the trusted manifest/scorer, never the worker input.
    files = [ROOT/p for p in comparator.SOURCES+EXTRA_SOURCES]
    files += [Path(r[k]) for r in rows for k in ('path','reference')]
    files += [ROOT/'docs/proposals/pdf_png300_32_budget_v2/schedule.json',NEW/'schedule.json',
        ORIGINAL/'analysis/scores.csv',NEW/'analysis/scores.csv',NEW/'transport_recovery/analysis/scores.csv',
        SPEC/'manifest.json', SPEC/'PREFLIGHT.json',
        ROOT/'scripts/main_study/verify_pdf_png300_guyot.py',
        ROOT/'tests/test_pdf_png300_guyot.py',ROOT/'tests/test_pdf_png300_guyot.R']
    if (SPEC/'PLAN_LOCK.json').exists():
        lock = json.loads((SPEC/'PLAN_LOCK.json').read_text())
        repair_path = SPEC/'SCORING_EXPORT_REPAIR_LOCK.json'
        repaired = {}
        if repair_path.exists():
            repair = json.loads(repair_path.read_text())
            if repair['original_plan_sha256']!=sha(SPEC/'PLAN_LOCK.json'):
                raise ValueError('Scoring repair belongs to a different run')
            for p,d in repair['evidence_sha256'].items():
                if sha(ROOT/p)!=d: raise ValueError('Repair evidence changed: '+p)
            repaired = repair['revised_sources_sha256']
            if set(repaired)!={str(SCORER.relative_to(ROOT)),str(Path(__file__).relative_to(ROOT))}:
                raise ValueError('Repair exceeds the documented export-only scope')
        if json.loads((SPEC/'manifest.json').read_text())!=rows: raise ValueError('Mapping changed')
        for p,d in lock['files_sha256'].items():
            if sha(ROOT/p)!=repaired.get(p,d): raise ValueError('Frozen source or input changed: '+p)
        return rows, lock
    if OUT.exists(): raise FileExistsError('Output exists before freeze')
    save(SPEC/'manifest.json',rows)
    lock = dict(recorded_utc=now(),datasets=64,arms=128,model_calls=0,
        method='automated PNG digitization + original Guyot 2012 algorithm',
        workers=3,no_scientific_retries=True,bootstrap_B=10000,
        bootstrap_seeds=dict(original=2026092306,replication=2026092706,pooled=2026092707),
        files_sha256={str(p.relative_to(ROOT)):sha(p) for p in dict.fromkeys(files)})
    save(SPEC/'PLAN_LOCK.json',lock)
    return rows, lock


def run_baseline(rows, lock):
    comparator.verify()
    by_id = {r['id']:r for r in rows}
    original_run = comparator.run
    comparator.SOURCES = list(dict.fromkeys(comparator.SOURCES+EXTRA_SOURCES))

    def baseline_worker(command, *args, **kwargs):
        if len(command)>1 and command[1]==str(ROOT/'scripts/main_study/extract_comparator.py'):
            request = Path(command[3]); q = json.loads(request.read_text())
            q['deny_probes']['assigned_reference'] = by_id[request.parent.name]['reference']
            request.write_text(json.dumps(q,indent=2)+'\n')
            command = extraction_command(command)
        elif len(command)>2 and command[2]==str(ROOT/'scripts/main_study/reconstruct_comparator.R'):
            command = [*command[:2],str(BACKEND),*command[3:]]
        return original_run(command,*args,**kwargs)

    comparator.run = baseline_worker
    OUT.mkdir(parents=True,exist_ok=True)
    progress = dict(started_utc=now(),pid=__import__('os').getpid(),expected=64,completed=0,
        success=0,failed=0,state='running',plan_sha256=sha(SPEC/'PLAN_LOCK.json'))
    save(OUT/'progress.json',progress,replace=True)
    results = []
    try:
        pending = []
        for row in rows:
            work = OUT/'work'/row['id']; receipt = work/'result.json'
            if receipt.exists():
                r = json.loads(receipt.read_text())
                for p,d in r['files_sha256'].items():
                    if sha(work/p)!=d: raise ValueError('Sealed output changed')
                if r['status']=='infrastructure_abort': raise RuntimeError('Retained infrastructure abort')
                results.append(r)
            elif work.exists():
                raise RuntimeError('Unsealed work retained; do not rerun: '+str(work))
            else: pending.append(row)
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = {pool.submit(comparator.run_case,row,OUT,
                Path(next(q['path'] for q in rows if q['id']!=row['id']))):row for row in pending}
            for future in as_completed(futures):
                try:
                    result = future.result()
                except Exception:
                    for other in futures: other.cancel()
                    raise
                results.append(result)
                progress.update(completed=len(results),success=sum(r['usable'] for r in results),
                    failed=sum(not r['usable'] for r in results),updated_utc=now(),latest=result['id'])
                save(OUT/'progress.json',progress,replace=True)
                count = len(results); bar = '#'*int(30*count/64)+'.'*(30-int(30*count/64))
                print(f'[{bar}] {count}/64 {result["id"]}: {result["status"]}',flush=True)
        order = {r['id']:i for i,r in enumerate(rows)}
        results.sort(key=lambda r:order[r['id']])
        prepare()  # All frozen code, PNGs, references and old scores still match.
        save(OUT/'RESULTS.json',dict(completed=True,inputs=64,model_calls=0,
            success=sum(r['usable'] for r in results),results=results))
        progress.update(state='reconstruction_complete',updated_utc=now())
        save(OUT/'progress.json',progress,replace=True)
    except Exception as e:
        progress.update(state='aborted',reason=str(e),updated_utc=now())
        save(OUT/'progress.json',progress,replace=True)
        raise
    finally:
        comparator.run = original_run


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','run','score'))
    args=parser.parse_args()
    subprocess.run([sys.executable,str(ROOT/'scripts/check_environment.py')],check=True)
    rows,lock=prepare()
    if args.mode=='run': run_baseline(rows,lock)
    if args.mode in ('run','score'):
        if not (OUT/'RESULTS.json').exists(): raise RuntimeError('Reconstruction not sealed')
        if (OUT/'analysis').exists(): raise FileExistsError('Scored results already retained')
        subprocess.run(['Rscript','--vanilla',str(SCORER),str(SPEC/'manifest.json'),str(OUT)],
            cwd=ROOT,check=True)
        from scripts.main_study.verify_pdf_png300_guyot import verify
        verify()
        prepare()
        save(OUT/'ANALYSIS_LOCK.json',dict(recorded_utc=now(),plan_sha256=sha(SPEC/'PLAN_LOCK.json'),
            export_repair_sha256=sha(SPEC/'SCORING_EXPORT_REPAIR_LOCK.json') if (SPEC/'SCORING_EXPORT_REPAIR_LOCK.json').exists() else None,
            files_sha256={str(p.relative_to(OUT)):sha(p) for p in sorted((OUT/'analysis').rglob('*')) if p.is_file()}))
        p=json.loads((OUT/'progress.json').read_text());p.update(state='scored',updated_utc=now())
        save(OUT/'progress.json',p,replace=True)
    print(json.dumps(dict(mode=args.mode,datasets=len(rows),plan_sha256=sha(SPEC/'PLAN_LOCK.json'))))


if __name__=='__main__': main()
