#!/usr/bin/env Rscript
# Isolated reconstruction: receives only the saved PNG extraction.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==3L)
setwd(args[3])
source('R/pdf_png300_guyot.R')
x <- jsonlite::read_json(args[1], simplifyVector=FALSE)
stopifnot(isTRUE(x$usable), setequal(names(x$arms),c('A','B')))
fits <- lapply(c('A','B'), function(g) {
  a <- x$arms[[g]]; warnings <- character()
  result <- tryCatch(withCallingHandlers({
    xy <- as.data.frame(do.call(rbind,lapply(a$coordinates,unlist)))
    names(xy) <- c('time','survival')
    risk <- data.frame(time=unlist(a$risk$time),n_risk=unlist(a$risk$n_risk))
    f <- guyot_2012(xy,risk,a$n)
    c(list(usable=TRUE,reason='success'),f)
  },warning=function(w) { warnings <<- c(warnings,conditionMessage(w)); invokeRestart('muffleWarning') }),
    error=function(e) list(usable=FALSE,reason=conditionMessage(e)))
  result$warnings <- warnings; result
})
names(fits) <- c('A','B')
saveRDS(fits,file.path(args[2],'arm_fits.rds'))
ok <- all(vapply(fits,function(x) isTRUE(x$usable),logical(1)))
# Preserve any valid arm even when the other arm fails.
valid <- names(fits)[vapply(fits,function(x) isTRUE(x$usable),logical(1))]
if(length(valid)) {
  records <- do.call(rbind,lapply(valid,function(g) data.frame(group=g,
    observed_time=fits[[g]]$records$time,event=fits[[g]]$records$event)))
  write.csv(records,file.path(args[2],'records.csv'),row.names=FALSE)
}
jsonlite::write_json(list(usable=ok,
  arms=lapply(fits,function(f) f[c('usable','reason','warnings','endpoint_risk_rows_not_used')]),
  algorithm='Guyot 2012 original supplementary code; no total event count',
  seed=NULL),file.path(args[2],'backend.json'),auto_unbox=TRUE,pretty=TRUE,na='null')
