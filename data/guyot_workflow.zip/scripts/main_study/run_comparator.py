#!/usr/bin/env python3
"""Run the fixed figure-only comparator; never load IPD truth or call a model."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from runner.isolation import profile, run
from scripts.main_study.prepare_comparator_runtime import DEST, verify

SOURCES = ['scripts/main_study/run_comparator.py', 'scripts/main_study/extract_comparator.py',
    'scripts/main_study/reconstruct_comparator.R', 'scripts/main_study/prepare_comparator_runtime.py',
    'src/km_analysis/deterministic_extraction.py', 'src/km_analysis/__init__.py',
    'src/runner/geometry.py', 'src/runner/__init__.py', 'src/runner/isolation.py',
    'src/runner/deadline.py', 'scripts/deterministic/proposal_a_ocr.cjs', 'R/reconstruction_a.R',
    'environment/comparator-ocr-lock.json', 'environment/conda-osx-arm64.lock',
    'environment/conda-packages.json', 'environment/cran-packages.json', 'scripts/check_environment.py']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(value, path):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')


def run_case(m, output, sibling):
    assigned = Path(m['path']).resolve()
    if digest(assigned) != m['sha256']:
        raise ValueError('Input checksum mismatch')
    if not m['id'].replace('_', '').isalnum():
        raise ValueError('Invalid input identifier')
    work = output / 'work' / m['id']
    work.mkdir(parents=True)
    (work / 'tmp').mkdir()
    request = work / 'request.json'
    # Existing forbidden files are chosen without reading their contents.
    probes = dict(sibling_figure=str(sibling), reference_manifest=str(ROOT /
        'outputs/development/proposal_a_figures_v1/scoring_only/truth.json'),
        new_study_data=str(ROOT / 'docs/proposals/task_validity_192_v1/datasets.csv'))
    if not all(Path(p).is_file() for p in probes.values()):
        raise FileNotFoundError('Isolation probe target missing')
    save(dict(caption=m['caption'], deny_probes=probes), request)
    files = [ROOT / p for p in SOURCES] + [assigned, request, ROOT, ROOT / 'pyproject.toml',
        ROOT / 'scripts', ROOT / 'scripts/main_study', ROOT / 'scripts/deterministic',
        ROOT / 'src', ROOT / 'src/km_analysis', ROOT / 'src/runner', ROOT / 'R']
    # R refuses a TMPDIR containing spaces; the repository path contains spaces.
    temporary = tempfile.TemporaryDirectory(prefix='km-comparator-')
    sb = work / 'worker.sb'
    sb.write_text(profile([Path(sys.prefix), DEST], files, [work, Path(temporary.name)]))
    env = dict(PATH=str(Path(sys.prefix) / 'bin') + ':/usr/bin:/bin', HOME=str(work),
        TMPDIR=temporary.name, LANG='en_US.UTF-8', LC_ALL='en_US.UTF-8',
        PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0',
        OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
        CODEX_PRIMARY_DEPS=str(DEST), KM_OCR_LANGUAGE_DIR=str(DEST / 'language'),
        R_LIBS_USER=str(Path(sys.prefix) / 'lib/R/library'),
        R_LIBS_SITE=str(Path(sys.prefix) / 'lib/R/library'))
    start = time.monotonic()
    extraction = work / 'extraction.json'
    code, timeout = run([sys.executable, str(ROOT / 'scripts/main_study/extract_comparator.py'),
        str(assigned), str(request), str(extraction)], sb, work, env,
        work / 'extract_stdout.txt', work / 'extract_stderr.txt', timeout=120)
    result = dict(id=m['id'], input_sha256=m['sha256'], status='extraction_failure',
        stage='extraction', usable=False, timeout=timeout, exit_code=code)
    if timeout:
        result['reason'] = 'extraction_timeout_120_seconds'
    elif code != 0 or not extraction.exists():
        # No silent unsandboxed retry and no scientific failure label for broken admission.
        result.update(status='infrastructure_abort', reason='worker_failed_before_valid_result')
    else:
        ext = json.loads(extraction.read_text())
        if not ext.get('isolation_probes') or not all(ext['isolation_probes'].values()):
            raise RuntimeError('Isolation evidence missing')
        result['reason'] = ext['reason']
        if ext['usable']:
            result['stage'] = 'reconstruction'
            code, timeout = run([str(Path(sys.prefix) / 'bin/Rscript'), '--vanilla',
                str(ROOT / 'scripts/main_study/reconstruct_comparator.R'), str(extraction),
                str(work), str(ROOT)], sb, work, env,
                work / 'backend_stdout.txt', work / 'backend_stderr.txt', timeout=240)
            result.update(status='reconstruction_failure', timeout=timeout, exit_code=code)
            if timeout:
                result['reason'] = 'two_arm_reconstruction_timeout_240_seconds'
            elif code != 0 or not (work / 'backend.json').exists():
                result.update(status='infrastructure_abort', reason='backend_process_failure')
            else:
                backend = json.loads((work / 'backend.json').read_text())
                result.update(usable=backend['usable'], reason=backend['arms'],
                    status='success' if backend['usable'] else 'reconstruction_failure')
    result['seconds'] = time.monotonic() - start
    temporary.cleanup()
    result['files_sha256'] = {str(p.relative_to(work)): digest(p) for p in sorted(work.rglob('*')) if p.is_file()}
    save(result, work / 'result.json')
    if result['status'] == 'infrastructure_abort':
        raise RuntimeError('Infrastructure abort; inspect ' + str(work))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    verify()
    subprocess.run([sys.executable, str(ROOT / 'scripts/check_environment.py')], check=True)
    before = {s: digest(ROOT / s) for s in SOURCES}
    lock_path = ROOT / 'docs/proposals/task_validity_192_v1/WORKFLOW_LOCK.json'
    if lock_path.exists():
        for rel, sha in json.loads(lock_path.read_text())['files_sha256'].items():
            if digest(ROOT / rel) != sha:
                raise ValueError('Frozen workflow changed: ' + rel)
    manifest = json.loads(args.manifest.read_text())
    if len(manifest) < 2 or len({m['id'] for m in manifest}) != len(manifest):
        raise ValueError('At least two uniquely identified inputs required for isolation probes')
    for m in manifest:
        suffix = Path(m['path']).suffix.lower()
        if suffix not in ('.pdf', '.png') or set(m['caption']) != {'A', 'B'}:
            raise ValueError('Unsupported input or public caption')
        if any(type(n) is not int or n <= 0 for n in m['caption'].values()):
            raise ValueError('Invalid public group sizes')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    save(manifest, out / 'manifest.json'); save(before, out / 'source_hashes.json')
    results = []
    for m in manifest:
        sibling = next(Path(q['path']).resolve() for q in manifest if q['path'] != m['path'])
        result = run_case(m, out, sibling)
        results.append(result)
        print(m['id'], result['status'], flush=True)
    if before != {s: digest(ROOT / s) for s in SOURCES}:
        raise RuntimeError('Source changed during comparator run')
    verify()
    save(dict(completed=True, inputs=len(results), success=sum(r['usable'] for r in results),
        failed=sum(not r['usable'] for r in results), model_calls=0, results=results), out / 'RESULTS.json')


if __name__ == '__main__':
    main()
