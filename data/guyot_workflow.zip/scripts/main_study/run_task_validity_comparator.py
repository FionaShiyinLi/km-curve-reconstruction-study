#!/usr/bin/env python3
"""Use the frozen comparator with explicit maintained-package loading in its worker.

The frozen extractor imports a module that prepends the repository root. A user
directory named runner can then shadow src/runner. Preload the allowed package
inside the same sandbox; do not grant access to the unrelated directory.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
import runner
from scripts.main_study import run_comparator as frozen

CHILD_BOOTSTRAP = """import runpy, sys
from pathlib import Path
entry = Path(sys.argv[1]).resolve()
root = entry.parents[2]
sys.path[:0] = [str(root / 'src'), str(root)]
import runner
assert Path(runner.__file__).resolve() == root / 'src/runner/__init__.py'
sys.argv = sys.argv[1:]
runpy.run_path(str(entry), run_name='__main__')
"""


def extraction_command(command):
    expected = [sys.executable, str(ROOT / 'scripts/main_study/extract_comparator.py')]
    if command[:2] == expected:
        return [sys.executable, '-c', CHILD_BOOTSTRAP, *command[1:]]
    return command


def main():
    assert Path(runner.__file__).resolve() == ROOT / 'src/runner/__init__.py'
    original_run = frozen.run

    def maintained_run(command, *args, **kwargs):
        return original_run(extraction_command(command), *args, **kwargs)

    # The existing entry owns all admission, timeout, sandbox, seed and output rules.
    frozen.run = maintained_run
    try:
        frozen.main()
    finally:
        frozen.run = original_run


if __name__ == '__main__':
    main()
