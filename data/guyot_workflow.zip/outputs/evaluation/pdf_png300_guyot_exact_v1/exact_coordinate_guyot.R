#!/usr/bin/env Rscript
# Guyot (2012) algorithm on EXACT vector coordinates, without censoring marks.
#
# For each of the 64 primary datasets this script feeds the frozen, transcribed
# Guyot algorithm (R/pdf_png300_guyot.R + R/guyot_2012_core.R, unchanged) the
# information a perfect vector extraction of the ReportLab figure would yield
# when censoring marks are ignored: the exact Kaplan-Meier step vertices
# (step_coordinates() from R/reference.R) and the displayed numbers at risk at
# months 0, 6, ..., 36 (risk_counts()). No total event count is supplied, as in
# the PNG-based comparator. The output is scored with the frozen pp_session()
# against the same observed-data reference. No model calls; no frozen export
# is modified. This isolates the algorithm stage from the digitization stage
# and gives the conventional-algorithm ceiling for vector input without marks.
#
# Usage: Rscript exact_coordinate_guyot.R <refs dir> <out dir>
#   refs dir: PP32/<dataset>.csv and RP32/<dataset>.csv reference records
suppressPackageStartupMessages(library(survival))
args <- commandArgs(trailingOnly = TRUE)
refs <- args[1]; out <- args[2]
source("R/reference.R"); source("R/pdf_png300_scoring.R"); source("R/pdf_png300_guyot.R")
dir.create(file.path(out, "work"), recursive = TRUE, showWarnings = FALSE)
files <- c(list.files(file.path(refs, "PP32"), full.names = TRUE),
           list.files(file.path(refs, "RP32"), full.names = TRUE))
rows <- list(); diagnostics <- list()
for (f in files) {
  ds <- sub("\\.csv$", "", basename(f))
  ref <- read.csv(f, check.names = FALSE, stringsAsFactors = FALSE)
  ref <- ref[c("group", "observed_time", "event")]
  recon <- list(); diag <- list()
  for (g in c("A", "B")) {
    a <- ref[ref$group == g, ]
    km <- km_from_observed(a$observed_time, a$event)
    coords <- step_coordinates(km)
    risk <- data.frame(time = seq(0, 36, 6), n_risk = risk_counts(a$observed_time, a$event))
    fit <- guyot_2012(coords, risk, nrow(a))
    recon[[g]] <- data.frame(group = g, observed_time = fit$records$time, event = fit$records$event)
    diag[[g]] <- data.frame(dataset = ds, group = g, n = nrow(a), vertices = nrow(coords),
                            true_events = sum(a$event), reconstructed_events = sum(fit$records$event),
                            risk_rows_not_used = fit$endpoint_risk_rows_not_used,
                            max_abs_risk_diff = max(abs(fit$risk$displayed - fit$risk$reconstructed)))
  }
  reconstructed <- do.call(rbind, recon)
  wd <- file.path(out, "work", ds); dir.create(wd, showWarnings = FALSE)
  write.csv(reconstructed, file.path(wd, "records.csv"), row.names = FALSE)
  s <- pp_session(ref, reconstructed, list(A = TRUE, B = TRUE))
  v <- as.list(s$values)
  rows[[ds]] <- data.frame(dataset = ds, cohort = if (startsWith(ds, "PP32")) "original" else "second",
                           scenario = strsplit(ds, "_")[[1]][2], status = "success",
                           curve_status_A = s$curve_status[["A"]], curve_status_B = s$curve_status[["B"]],
                           cox_status = s$cox_status[["reconstructed"]], as.data.frame(v, check.names = FALSE))
  diagnostics[[ds]] <- do.call(rbind, diag)
  cat(sprintf("%s TAAE=%.6f pp logHR err=%.5f\n", ds, 100 * v$taae_mean, v$absolute_log_hr_error))
}
scores <- do.call(rbind, rows); rownames(scores) <- NULL
write.csv(scores, file.path(out, "scores.csv"), row.names = FALSE)
write.csv(do.call(rbind, diagnostics), file.path(out, "diagnostics.csv"), row.names = FALSE)
cat(sprintf("\n%d datasets; mean TAAE %.5f pp; all available: %s\n", nrow(scores), 100 * mean(scores$taae_mean),
            all(scores$curve_status_A == "available" & scores$curve_status_B == "available" & scores$cox_status == "available")))
writeLines(c(R.version.string, paste("survival", as.character(packageVersion("survival")))), file.path(out, "session.txt"))
