"""Deterministic development E1/E2; functions receive only a figure and caption.
No renderer, record files, original vertices, or sibling figures are imported.
"""
from __future__ import annotations

# Support direct execution from this workflow directory.
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_root = next((p for p in _BootstrapPath(__file__).resolve().parents
                        if (p / "pyproject.toml").is_file()), None)
if _bootstrap_root is not None:
    _bootstrap_sys.path[:0] = [str(_bootstrap_root), str(_bootstrap_root / "src")]

import base64, csv, io, json, os, re, subprocess, sys, time
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage, signal
from scipy.optimize import isotonic_regression
import pdfplumber
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from runner.geometry import inspect_pdf, raster_tick_positions

CONFIG={'version':'development-e1-e2-v2-refined','color_alpha_min':.22,'color_saturation_min':.12,'color_residual_max':.30,
 'palette':{'A':[31,119,180],'B':[255,127,14]},'trace_quantum_pixels':.5,
 'trace_median_width_pt':1.2,'maximum_gap_fraction_width':.035,
 'mark_min_height_stroke_ratio':2.5,'mark_side_stroke_ratio':1.1,
 'mark_adjacent_drop_stroke_ratio':1.0,'ocr':'Tesseract.js LSTM eng, PSM11',
 'mark_flank_radius_strokes':.75,'mark_peak_prominence_strokes':.05,'mark_peak_distance_strokes':.8,'drop_connector_width_strokes':1.5,'drop_connector_height_strokes':1.25,'connector_flank_strokes':1.0,'mark_peak_height_strokes':.15,'ocr_min_width':1800,'protocol_frozen':False}

def runs(mask):
    edges=np.diff(np.r_[False,np.asarray(mask,bool),False].astype(int))
    return list(zip(np.where(edges==1)[0],np.where(edges==-1)[0]-1))

def fit_axis(pairs):
    a=np.asarray(pairs,float)
    if len(a)<3 or len(set(a[:,0]))!=len(a): raise ValueError('calibration: fewer than three distinct labeled ticks')
    slope,intercept=np.polyfit(a[:,0],a[:,1],1)
    if abs(slope)<1e-9 or max(abs(a[:,1]-(slope*a[:,0]+intercept)))>2: raise ValueError('calibration: inconsistent tick labels')
    return float(slope),float(intercept)

def extract_pdf(path,caption):
    inv=inspect_pdf(path); axes=inv['axis_candidates']
    if len(axes['horizontal'])!=1 or len(axes['vertical'])!=1: raise ValueError('calibration: ambiguous PDF axes')
    xs,ys=inv['x_tick_pairs'],inv['y_tick_pairs']; sx,ix=fit_axis(xs);sy,iy=fit_axis(ys)
    ytop=min(p for v,p in ys);ybottom=max(p for v,p in ys)
    result={'extractor':'E1','axes':{'x_ticks':xs,'y_ticks':ys},'arms':{}}
    with pdfplumber.open(path) as pdf:
        page=pdf.pages[0]; words=page.extract_words()
        for g in ('A','B'):
            labels=[]
            for w in words:
                if w['text']!='Group':continue
                matches=[q for q in words if q['text']==g and 0<=q['x0']-w['x1']<12 and abs(q['top']-w['top'])<2]
                if len(matches)==1: labels.append(w)
            legend=[w for w in labels if w['bottom']<ytop]
            if len(legend)!=1: raise ValueError('legend: missing or ambiguous group')
            l=legend[0]
            keys=[q for q in page.lines if abs(q['top']-q['bottom'])<1e-6 and 8<q['x1']-q['x0']<60 and 0<l['x0']-q['x1']<20 and l['top']-3<q['top']<l['bottom']+3]
            if len(keys)!=1:raise ValueError('legend: line key missing')
            color=keys[0]['stroking_color']
            curves=[c for c in page.curves if c.get('stroking_color')==color and len(c.get('pts',[]))>=2]
            if len(curves)!=1:raise ValueError('trace: ambiguous PDF path')
            points=[]
            for x,y in curves[0]['pts']:
                t=(x-ix)/sx;s=(y-iy)/sy
                if abs(t)<1e-8:t=0.
                if abs(s-1)<1e-8:s=1.
                if abs(s)<1e-8:s=0.
                points.append([float(t),float(s)])
            marks=sorted((q['x0']-ix)/sx for q in page.lines if q.get('stroking_color')==color
                and abs(q['x0']-q['x1'])<1e-6 and 1<q['bottom']-q['top']<10
                and q['top']>=ytop-5 and q['bottom']<=ybottom+5)
            rows=[w for w in labels if w['top']>ybottom+15];risk=None
            if rows:
                if len(rows)!=1:raise ValueError('risk_table: ambiguous row')
                y=(rows[0]['top']+rows[0]['bottom'])/2;counts=[]
                for value,px in xs:
                    cells=[w for w in words if w['text'].isdigit() and abs((w['top']+w['bottom'])/2-y)<2 and abs((w['x0']+w['x1'])/2-px)<3]
                    if len(cells)!=1:raise ValueError('risk_table: unreadable PDF cell')
                    counts.append(int(cells[0]['text']))
                risk={'time':[v for v,p in xs],'n_risk':counts}
            result['arms'][g]={'n':int(caption[g]),'coordinates':points,'marks':list(map(float,marks)),
                'endpoint':points[-1][0],'risk':risk,'diagnostics':{}}
    return result

class OCR:
    def __init__(self):
        root=Path(__file__).resolve().parents[2]
        runtime=Path(os.environ.get('CODEX_PRIMARY_DEPS',str(Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies')))
        env=os.environ.copy();env['CODEX_NODE_MODULES']=str(runtime/'node/node_modules')
        language=Path(os.environ.get('KM_OCR_LANGUAGE_DIR',str(root/'.runner/proposal-a-ocr')))
        self.process=subprocess.Popen([str(runtime/'node/bin/node'),str(root/'scripts/deterministic/proposal_a_ocr.cjs'),str(language)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
    def words(self,image,number=False):
        scale=max(1,100/image.height) if number else max(1,CONFIG['ocr_min_width']/image.width)
        resized=image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
        buf=io.BytesIO();resized.save(buf,format='PNG')
        self.process.stdin.write(json.dumps({'image':base64.b64encode(buf.getvalue()).decode(),'psm':'7' if number else '11','digits':False})+'\n');self.process.stdin.flush()
        line=self.process.stdout.readline()
        if not line:raise RuntimeError('OCR process stopped: '+self.process.stderr.read())
        data=json.loads(line)
        if 'error' in data:raise RuntimeError(data['error'])
        words=[]
        for r in csv.DictReader(io.StringIO(data['tsv']),delimiter='\t',fieldnames=['level','page','block','par','line','word','left','top','width','height','conf','text']):
            if r.get('text','').strip() and int(r['level'])==5:
                x,y,w,h=[float(r[k])/scale for k in ('left','top','width','height')]
                words.append(dict(text=r['text'].strip(),x0=x,x1=x+w,top=y,bottom=y+h,conf=float(r['conf'])))
        return words,data['text']
    def number(self,image):
        _,text=self.words(image,number=True)
        clean=text.strip()
        if not re.fullmatch(r'\d+(?:\.\d+)?',clean):raise ValueError('calibration_or_risk_table: unreadable numeric crop '+repr(clean))
        return float(clean)
    def close(self):
        self.process.stdin.close();self.process.wait(timeout=30)
        self.process.stdout.close();self.process.stderr.close()

def raster_axes(image,words,ocr):
    a=np.asarray(image.convert('RGB'),dtype=float);h,w=a.shape[:2]
    neutral=(a.max(2)-a.min(2)<35)&(a.mean(2)<150)
    horizontal=ndimage.binary_opening(neutral,structure=np.ones((1,int(.35*w))))
    vertical=ndimage.binary_opening(neutral,structure=np.ones((int(.25*h),1)))
    hr=np.where(horizontal.sum(1)>.35*w)[0];vc=np.where(vertical.sum(0)>.25*h)[0]
    if not len(hr) or not len(vc):raise ValueError('calibration: axes not found')
    y0=int(round(np.median(hr)));x0=int(round(np.median(vc)))
    hcols=np.where(horizontal[y0])[0];vrows=np.where(vertical[:,x0])[0]
    ticks=raster_tick_positions(image,dict(position=y0,end=int(hcols[-1])),dict(position=x0,start=int(vrows[0])))
    nums=[dict(q,value=float(q['text'])) for q in words if re.fullmatch(r'\d+(?:\.\d+)?',q['text'])]
    xs=[];ys=[];scale=h/324
    for px in ticks['x_pixels']:
        crop=image.crop((round(px-18*scale),round(y0+4*scale),round(px+18*scale),round(y0+17*scale)))
        xs.append([ocr.number(crop),px])
    for py in ticks['y_pixels']:
        crop=image.crop((round(x0-30*scale),round(py-6*scale),round(x0-6*scale),round(py+6*scale)))
        ys.append([ocr.number(crop),py])
    xs=sorted(xs);ys=sorted(ys);sx,ix=fit_axis(xs);sy,iy=fit_axis(ys)
    # Both limits must have actual OCR labels matched to visible endpoint ticks.
    if abs(xs[0][1]-x0)>.015*w or abs(xs[-1][1]-hcols[-1])>.015*w or abs(ys[0][1]-y0)>.015*h or abs(ys[-1][1]-vrows[0])>.025*h:
        raise ValueError('calibration: missing endpoint labels')
    return a,nums,xs,ys,(sx,ix,sy,iy)

def collapse_connectors(rows,stroke):
    rows=rows.copy();changes=np.where(np.diff(rows)>0)[0]+1
    width=max(1,int(round(CONFIG['drop_connector_width_strokes']*stroke)))
    merged=0;k=0
    while k<len(changes):
        end=k
        # A bounded group, never chain together a long declining staircase.
        while end+1<len(changes) and changes[end+1]-changes[k]<=width and changes[end+1]-changes[end]<=max(1,round(stroke)):
            end+=1
        span=max(2,round(CONFIG['connector_flank_strokes']*stroke))
        lo=int(changes[k]);hi=int(changes[end])
        left=rows[max(0,lo-span):lo];right=rows[hi:min(len(rows),hi+span)]
        stable=len(left)>=span and len(right)>=span and np.ptp(left)<=.5 and np.ptp(right)<=.5
        if end>k and stable and rows[hi]-rows[lo-1]>=CONFIG['drop_connector_height_strokes']*stroke:
            lo=int(changes[k]);hi=int(changes[end]);mid=(lo+hi)//2
            before=rows[lo-1];after=rows[hi]
            rows[lo:mid]=before;rows[mid:hi+1]=after;merged+=end-k
        k=end+1
    return rows,merged

def detect_marks(mask,weights,center,stroke):
    radius=max(1,round(CONFIG['mark_flank_radius_strokes']*stroke))
    score=np.zeros(len(center));height=mask.shape[0]
    for j in range(len(center)):
        lo=max(0,j-radius);hi=min(len(center)-1,j+radius)
        upper=min(center[lo],center[hi]);lower=max(center[lo],center[hi])
        # Exclude the horizontal stroke and demand evidence beyond BOTH flanks.
        top=max(0,int(np.floor(upper-.8*stroke)))
        bottom=min(height,int(np.ceil(lower+.8*stroke)))
        reach=max(2,round(2.5*stroke))
        above=weights[max(0,top-reach):top,j].sum()
        below=weights[bottom:min(height,bottom+reach),j].sum()
        score[j]=min(above,below)
    peaks,props=signal.find_peaks(np.r_[0,score,0],height=CONFIG['mark_peak_height_strokes']*stroke,
        prominence=CONFIG['mark_peak_prominence_strokes']*stroke,
        distance=max(1,round(CONFIG['mark_peak_distance_strokes']*stroke)),plateau_size=True)
    positions=[]
    for i,p in enumerate(peaks):
        left=props['left_edges'][i]-1;right=props['right_edges'][i]-1
        positions.append((left+right)/2)
    return positions,{'mark_peak_count':len(positions),'mark_evidence_columns':int(np.sum(score>=CONFIG['mark_peak_height_strokes']*stroke))}

def extract_raster(path,caption,ocr):
    image=Image.open(path).convert('RGB');words,text=ocr.words(image)
    a,nums,xs,ys,(sx,ix,sy,iy)=raster_axes(image,words,ocr);h,w=a.shape[:2]
    x0=int(round(ix));xmax=int(round(max(p for v,p in xs)));top=int(round(min(p for v,p in ys)));bottom=int(round(max(p for v,p in ys)))
    palette=np.array(list(CONFIG['palette'].values()),float)/255;pixels=a/255
    distances=[];alphas=[]
    for color in palette:
        direction=1-color;alpha=((1-pixels)*direction).sum(2)/(direction**2).sum()
        residual=np.sqrt(((pixels-(1-alpha[...,None]*direction))**2).sum(2))
        distances.append(residual);alphas.append(alpha)
    assignment=np.argmin(distances,axis=0)
    result={'extractor':'E2','axes':{'x_ticks':xs,'y_ticks':ys},'ocr_text':text,'arms':{}}
    table_numbers=[q for q in nums if q['top']>bottom+.12*h and q['x0']>x0-.035*w]
    row_y=[]
    for q in sorted(table_numbers,key=lambda q:q['top']):
        y=(q['top']+q['bottom'])/2
        if not row_y or y-row_y[-1]>.012*h:row_y.append(y)
    if row_y and len(row_y)!=2:raise ValueError('risk_table: wrong number of numeric rows')
    for gi,g in enumerate(('A','B')):
        mask=(assignment==gi)&(alphas[gi]>CONFIG['color_alpha_min'])&(distances[gi]<CONFIG['color_residual_max'])&((pixels.max(2)-pixels.min(2))>CONFIG['color_saturation_min'])
        # Confirm the fixed palette's group mapping against the visible legend.
        label=[q for q in words if q['text'].replace(' ','') in (g,'Group'+g) and q['bottom']<top]
        if len(label)!=1:raise ValueError('legend: OCR group label missing')
        legend=mask[:max(0,top-10),:]
        ys_key,xs_key=np.where(legend)
        if not len(xs_key) or not 0<label[0]['x0']-np.max(xs_key)<.15*w:raise ValueError(f'legend: palette mapping inconsistent {g}, label={label[0]}, key_max={np.max(xs_key) if len(xs_key) else None}, top={top}')
        pad=max(2,round(h/324*3));roi=mask[max(0,top-pad):bottom+1,x0:xmax+1]
        first_y=max(0,top-pad)
        occupied=np.any(roi,axis=0);columns=np.where(occupied)[0]
        if not len(columns) or columns[0]>.01*w:raise ValueError('trace: start not visible')
        last=int(columns[-1]);missing=runs(~occupied[:last+1])
        if missing and max(r-l+1 for l,r in missing)>CONFIG['maximum_gap_fraction_width']*w:raise ValueError('trace: unsupported long gap')
        measured=[]
        for x in columns:
            ys_col=np.where(roi[:,x])[0]+first_y
            # Same-color disconnected JPEG speckles are removed by selecting
            # the longest contiguous run in a column.
            rr=runs(roi[:,x]);lo,hi=max(rr,key=lambda z:z[1]-z[0])
            measured.append(first_y+(lo+hi)/2)
        rows=np.interp(np.arange(last+1),columns,measured)
        width=max(1,int(round(h/324*CONFIG['trace_median_width_pt']))|1)
        rows=ndimage.median_filter(rows,size=width,mode='nearest')
        rows=isotonic_regression(rows,increasing=True).x
        rows=np.round(rows/CONFIG['trace_quantum_pixels'])*CONFIG['trace_quantum_pixels']
        # Bounding to calibrated survival limits is a documented raster
        # stroke-center convention, never a correction using reference curves.
        rows=np.clip(rows,top,bottom)
        stroke=max(1.,h/324)
        # Collapse the finite-width rasterization of a vertical connector into
        # one jump. Separate plateaus wider than a stroke remain separate.
        marker_rows=rows.copy()
        rows,merged=collapse_connectors(rows,stroke)
        change=np.where(np.diff(rows)>0)[0]+1
        points=[[0.,1.]];previous=1.
        for j in np.r_[0,change]:
            t=max(0.,(x0+j-ix)/sx);s=float(np.clip((rows[j]-iy)/sy,0,1))
            if s<previous:
                points.extend([[float(t),previous],[float(t),s]]);previous=s
        endpoint=float((x0+last-ix)/sx)
        if points[-1][0]<endpoint:points.append([endpoint,previous])
        # Use both flanks of the curve: a drop must not masquerade as a mark.
        weights=np.clip(alphas[gi],0,1)*mask
        weights=weights[max(0,top-pad):bottom+1,x0:x0+last+1]
        positions,mark_diagnostics=detect_marks(roi[:,:last+1],weights,marker_rows-first_y,stroke)
        mark_times=[max(0.,float((x0+j-ix)/sx)) for j in positions]
        risk=None
        if row_y:
            counts=[]
            for value,px in xs:
                scale=h/324
                crop=image.crop((round(px-13*scale),round(row_y[gi]-6*scale),round(px+13*scale),round(row_y[gi]+6*scale)))
                try:value=ocr.number(crop)
                except ValueError as e:raise ValueError(f'risk_table: {g} tick={value} row={row_y[gi]}: {e}')
                if value!=int(value):raise ValueError('risk_table: noninteger cell')
                counts.append(int(value))
            risk={'time':[v for v,p in xs],'n_risk':counts}
        result['arms'][g]={'n':int(caption[g]),'coordinates':points,'marks':mark_times,'endpoint':endpoint,'risk':risk,
            'diagnostics':{'missing_columns':int((~occupied[:last+1]).sum()),'detected_drops':len(points)//2,'connector_changes_collapsed':merged,**mark_diagnostics}}
    return result

def extract(path,caption,ocr=None):
    start=time.monotonic()
    try:
        value=extract_pdf(path,caption) if Path(path).suffix.lower()=='.pdf' else extract_raster(path,caption,ocr)
        value.update(usable=True,reason='success')
    except (ValueError,RuntimeError) as e:value={'usable':False,'reason':str(e),'arms':{}}
    value['seconds']=time.monotonic()-start
    return value
