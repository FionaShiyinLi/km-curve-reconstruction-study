"""Figure-derived calibration and lossless step geometry; no benchmark constants."""
import math
import numpy as np

TOL=1e-8


def _fit_ticks(ticks, name, extent, tolerance):
    a=np.asarray(ticks,dtype=float)
    if a.ndim!=2 or a.shape[1]!=2 or len(a)<3 or not np.isfinite(a).all():
        raise ValueError(name+': provide at least three finite [visible label value, pixel position] pairs')
    values,pixels=a[:,0],a[:,1]
    if len(set(values))!=len(values) or np.any(pixels<0) or np.any(pixels>=extent):
        raise ValueError(name+': duplicate labels or ticks outside image')
    slope,intercept=np.polyfit(values,pixels,1)
    residual=float(np.max(np.abs(pixels-(slope*values+intercept))))
    if abs(slope)<TOL or residual>tolerance:
        raise ValueError(name+': tick values/positions are inconsistent with a linear axis')
    return float(slope),float(intercept),residual


def calibration_from_ticks(x_ticks,y_ticks,image_size,evidence,pixel_tolerance=1.5):
    """Ticks are read from the assigned image, never from risk-table cells."""
    width,height=image_size
    if not evidence.strip():raise ValueError('Describe visible tick-label evidence')
    sx,ix,rx=_fit_ticks(x_ticks,'x',width,pixel_tolerance)
    sy,iy,ry=_fit_ticks(y_ticks,'y',height,pixel_tolerance)
    if sx<=0 or sy>=0:raise ValueError('Time must increase right; survival must increase up')
    xv=[p[0] for p in x_ticks];yv=[p[0] for p in y_ticks]
    if min(xv)!=0 or min(yv)!=0 or max(yv)!=1:
        raise ValueError('Include the visible zero time tick and survival 0 and 1 ticks')
    maximum=max(xv)
    anchors={'x_zero':ix,'x_max':ix+sx*maximum,'y_zero':iy,'y_one':iy+sy}
    if not (0<=anchors['x_zero']<anchors['x_max']<width and 0<=anchors['y_one']<anchors['y_zero']<height):
        raise ValueError('Fitted axis anchors are outside image')
    return {'basis':'visible_axis_ticks','evidence':evidence,'anchors':anchors,
            'x_ticks':x_ticks,'y_ticks':y_ticks,'image_size':list(image_size),
            'max_tick_residual_pixels':{'x':rx,'y':ry},'x_max_value':maximum}


def _neutral_ink(image):
    rgb=np.asarray(image.convert('RGB')).astype(int)
    return (rgb.max(axis=2)<210)&(rgb.max(axis=2)-rgb.min(axis=2)<25)


def _runs(bits):
    edges=np.diff(np.r_[False,bits,False].astype(int))
    return list(zip(np.flatnonzero(edges==1),np.flatnonzero(edges==-1)-1))


def spine_candidates(image):
    """Suggest neutral straight spines, without assigning numerical axis values."""
    ink=_neutral_ink(image);h,w=ink.shape
    def scan(mask,min_length):
        candidates=[]
        for pos,row in enumerate(mask):
            for lo,hi in _runs(row):
                if hi-lo+1>=min_length:
                    if candidates and pos-candidates[-1]['position']<=3 and abs(lo-candidates[-1]['start'])<=3 and abs(hi-candidates[-1]['end'])<=3:
                        continue
                    candidates.append({'position':int(pos),'start':int(lo),'end':int(hi)})
        return sorted(candidates,key=lambda c:c['end']-c['start'],reverse=True)[:12]
    return {'horizontal':scan(ink,max(20,w*.3)),'vertical':scan(ink.T,max(20,h*.25)),
            'note':'Candidates only. Match visible numeric tick labels; grids or multi-panel plots may be ambiguous.'}


def verify_tick_ink(image,calibration):
    """Fail closed for supported neutral-axis plots; this is not OCR."""
    ink=_neutral_ink(image);h,w=ink.shape;a=calibration['anchors']
    if list(image.size)!=calibration.get('image_size'):raise ValueError('Calibration/image dimensions differ')
    x0=int(round(a['x_zero']));y0=int(round(a['y_zero']));x1=int(round(a['x_max']));y1=int(round(a['y_one']))
    def crop(xa,xb,ya,yb):return ink[max(0,ya):min(h,yb),max(0,xa):min(w,xb)]
    horizontal=crop(x0,x1+1,y0-2,y0+3)
    vertical=crop(x0-2,x0+3,y1,y0+1)
    hs=float(np.any(horizontal,axis=0).mean()) if horizontal.size else 0
    vs=float(np.any(vertical,axis=1).mean()) if vertical.size else 0
    if min(hs,vs)<.85:raise ValueError('Calibration does not follow the visible neutral axis spines')
    # Check marks outside the plotting area, not just the spine intersection.
    for _,pos in calibration['y_ticks']:
        q=int(round(pos));mark=crop(x0-9,x0-2,q-2,q+3)
        if mark.size==0 or np.any(mark,axis=0).sum()<2:
            raise ValueError('A declared survival tick lacks visible outward tick-mark evidence')
    for _,pos in calibration['x_ticks']:
        q=int(round(pos));mark=crop(q-2,q+3,y0+2,y0+10)
        if mark.size==0 or np.any(mark,axis=1).sum()<2:
            raise ValueError('A declared time tick lacks visible outward tick-mark evidence')
    return {'horizontal_spine_fraction':hs,'vertical_spine_fraction':vs,'ticks_checked':len(calibration['x_ticks'])+len(calibration['y_ticks'])}


def data_to_pixel(point,axes,calibration):
    t,s=point;a=calibration['anchors']
    return [a['x_zero']+t/axes['x_max']*(a['x_max']-a['x_zero']),
            a['y_zero']+s*(a['y_one']-a['y_zero'])]


def native_vertices(points,anchors,x_max):
    """Affine conversion preserves order and every pre/post vertex. No binning."""
    a=anchors
    if a['x_max']<=a['x_zero'] or a['y_zero']<=a['y_one'] or x_max<=0:
        raise ValueError('Invalid native top-origin axis anchors')
    result=[];snaps=[]
    for i,(px,py) in enumerate(points):
        t=(px-a['x_zero'])*x_max/(a['x_max']-a['x_zero'])
        s=(a['y_zero']-py)/(a['y_zero']-a['y_one'])
        if not math.isfinite(t+s):raise ValueError('Nonfinite native coordinate')
        original=[t,s]
        # Fixed arithmetic-roundoff normalization only, recorded explicitly.
        for target in (0.,float(x_max)):
            if abs(t-target)<=TOL:t=target
        for target in (0.,1.):
            if abs(s-target)<=TOL:s=target
        if [t,s]!=original:snaps.append({'vertex':i,'before':original,'after':[t,s]})
        result.append([t,s])
    validate_steps(result,x_max)
    return result,{'operation':'affine_native_conversion','input_vertices':len(points),
                   'output_vertices':len(result),'roundoff_tolerance':TOL,'roundoff_snaps':snaps,
                   'binning':False,'sorting':False,'duplicate_time_averaging':False}


def validate_steps(points,x_max):
    if not isinstance(points,list) or len(points)<2:raise ValueError('At least two step vertices required')
    for p in points:
        if len(p)!=2 or not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in p):
            raise ValueError('Finite [time,survival] vertices required')
        if not (0<=p[0]<=x_max+TOL and 0<=p[1]<=1):raise ValueError('Step coordinate out of bounds')
    if points[0]!=[0,1]:raise ValueError('Preserve explicit pre-event [0,1]; do not replace it with the first post-drop value')
    for a,b in zip(points,points[1:]):
        if b[0]<a[0] or b[1]>a[1]+TOL:raise ValueError('Steps must have increasing time and nonincreasing survival')
        if abs(b[0]-a[0])>TOL and abs(b[1]-a[1])>TOL:raise ValueError('Diagonal segment: retain both pre/post-drop vertices')


def steps_from_plateaus(plateaus,x_max):
    """Join figure-derived [left_time,right_time,survival] plateaus, without smoothing."""
    result=[];previous=None
    for left,right,survival in plateaus:
        if right<left:raise ValueError('Reversed plateau')
        if previous is not None and left!=previous:raise ValueError('Plateaus must meet at a supported transition; do not fill unknown gaps')
        result.extend([[left,survival],[right,survival]]);previous=right
    validate_steps(result,x_max)
    return result


def pdf_axis_candidates(page):
    def neutral(c):
        if c is None:return False
        if isinstance(c,(int,float)):return c<.85
        return len(c)==3 and max(c)-min(c)<.05 and max(c)<.85
    lines=[l for l in page.lines if neutral(l.get('stroking_color'))]
    horizontal=[l for l in lines if abs(l['top']-l['bottom'])<1e-6 and l['x1']-l['x0']>page.width*.3]
    vertical=[l for l in lines if abs(l['x0']-l['x1'])<1e-6 and l['bottom']-l['top']>page.height*.25]
    keys=('x0','x1','top','bottom')
    return {'horizontal':[{k:l[k] for k in keys} for l in horizontal],
            'vertical':[{k:l[k] for k in keys} for l in vertical]}


def pdf_tick_pairs(page,horizontal,vertical):
    """Match numeric words to short outward tick lines adjacent to chosen spines."""
    import re
    words=[w for w in page.extract_words() if re.fullmatch(r'-?\d+(?:\.\d+)?',w['text'])]
    x0=vertical['x0'];y0=horizontal['top'];x_ticks=[];y_ticks=[]
    for line in page.lines:
        if abs(line['x0']-line['x1'])<1e-6 and abs(line['top']-y0)<1e-5 and 1<line['bottom']-line['top']<12:
            px=line['x0']
            candidates=[w for w in words if abs((w['x0']+w['x1'])/2-px)<3 and y0<w['top']<y0+18]
            if len(candidates)==1:x_ticks.append([float(candidates[0]['text']),px])
        if abs(line['top']-line['bottom'])<1e-6 and abs(line['x1']-x0)<1e-5 and 1<line['x1']-line['x0']<12:
            py=line['top']
            candidates=[w for w in words if abs((w['top']+w['bottom'])/2-py)<3 and x0-40<w['x0'] and w['x1']<x0-2]
            if len(candidates)==1:y_ticks.append([float(candidates[0]['text']),py])
    return sorted(x_ticks),sorted(y_ticks)


def inspect_pdf(path):
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        if len(pdf.pages)!=1:raise ValueError('Inspect one assigned page at a time')
        page=pdf.pages[0];axes=pdf_axis_candidates(page)
        result={'page_size':[page.width,page.height],'axis_candidates':axes,
            'curves':[{'index':i,'vertices':len(c.get('pts',[])),'stroke_color':c.get('stroking_color'),
                       'bbox':[c['x0'],c['top'],c['x1'],c['bottom']]} for i,c in sorted(enumerate(page.curves),key=lambda v:len(v[1].get('pts',[])),reverse=True)[:12]],
            'words':page.extract_words(),
            'note':'Curve indices and axis candidates are suggestions. Match the visible legend and labels before selecting.'}
        if len(axes['horizontal'])==len(axes['vertical'])==1:
            xs,ys=pdf_tick_pairs(page,axes['horizontal'][0],axes['vertical'][0])
            result['x_tick_pairs']=xs;result['y_tick_pairs']=ys
        return result


def raster_tick_positions(image,horizontal,vertical):
    """Locate outward marks beside selected neutral spines; labels still need reading."""
    ink=_neutral_ink(image);h,w=ink.shape
    x0=vertical['position'];y0=horizontal['position'];x1=horizontal['end'];y1=vertical['start']
    xa=max(0,x0-3);xb=min(w,x1+4);# A curve stroke may cover the very top of the vertical spine. Search a
    # small image-relative margin above the detected neutral run for its top tick.
    ya=max(0,y1-max(8,round(h*.04)));yb=min(h,y0+4)
    # Skip the spine's stroke thickness, then use only the two nearest outward
    # pixels. A wider band can accidentally include the tops of tick-label digits.
    yy=y0
    while yy<min(h,y0+12) and ink[yy,max(0,x0):min(w,x1+1)].mean()>.75:yy+=1
    xx=x0
    while xx>max(0,x0-12) and ink[max(0,y1):min(h,y0+1),xx].mean()>.75:xx-=1
    xs=np.any(ink[yy:min(h,yy+2),xa:xb],axis=0)
    ys=np.any(ink[ya:yb,max(0,xx-1):min(w,xx+1)],axis=1)
    return {'x_pixels':[float((lo+hi)/2+xa) for lo,hi in _runs(xs)],
            'y_pixels':[float((lo+hi)/2+ya) for lo,hi in _runs(ys)],
            'note':'Associate each position with its visible numeric label; no label values are inferred.'}
